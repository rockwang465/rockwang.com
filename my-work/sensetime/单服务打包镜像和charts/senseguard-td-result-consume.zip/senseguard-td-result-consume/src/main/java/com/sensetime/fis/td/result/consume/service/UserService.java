package com.sensetime.fis.td.result.consume.service;

import com.sensetime.fis.td.result.consume.vo.UserDeviceVo;

/**
 * UserService
 *
 * @author lizhengguang_vendor
 * @date 2019-1-16 11:30:52
 */
public interface UserService {

    /**
     * 根据设备id查询在线用户
     *
     * @return UserDeviceVo
     */
    UserDeviceVo getOnlineUsersByDeviceId(Long deviceId);
}
