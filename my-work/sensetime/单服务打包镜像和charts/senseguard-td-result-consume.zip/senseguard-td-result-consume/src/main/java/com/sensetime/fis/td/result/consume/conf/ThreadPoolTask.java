package com.sensetime.fis.td.result.consume.conf;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * @author zhangyp
 * @date 2019/7/2
 */
public class ThreadPoolTask {
    private static ThreadPoolTaskExecutor THREAD_POOL = null;

    public synchronized static ThreadPoolTaskExecutor getInstance() {
        if (null == THREAD_POOL) {
            THREAD_POOL = new ThreadPoolTaskExecutor();
            THREAD_POOL.initialize();
        }
        return THREAD_POOL;
    }

}
