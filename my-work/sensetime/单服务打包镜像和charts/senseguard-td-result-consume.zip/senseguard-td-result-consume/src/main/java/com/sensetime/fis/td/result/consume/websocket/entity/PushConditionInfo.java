package com.sensetime.fis.td.result.consume.websocket.entity;

import lombok.Data;

import java.util.List;

/**
 * 用于存放用户推送过滤信息，SessionId固定长度为8位
 *
 * @author lizhengguang_vendor
 * @date 2019-1-17 13:59:22
 */
@Data
public class PushConditionInfo {

    /**
     * 设备id
     */
    private List<Long> deviceIds;

    /**
     * 对比类型
     */
    private List<Integer> compareTypes;

    /**
     * 任务id列表
     */
    private List<Long> taskIds;

    /**
     * 用户 id
     */
    private Long userId;

    /**
     * 任务id,仅用于迎宾建立 webSocket 连接时的条件
     */
    private Long ruleId;

    /**
     * 浏览器WebSocket SessionId，长度固定为8位
     */
    private String sessionId;
}
