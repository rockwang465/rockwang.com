package com.sensetime.fis.td.result.consume.websocket.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sensetime.fis.td.result.consume.websocket.entity.PushConditionInfo;
import com.sensetime.fis.td.result.consume.websocket.utils.ResultKeyUtils;
import com.sensetime.rws.commonapis.Commonapis.MsgType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.sensetime.fis.td.result.consume.websocket.utils.ResultKeyUtils.REDIS_EXPIRE_TIME_ONE_DAY;


/**
 * @author lizhengguang_vendor
 * @date 2019-1-17 17:34:14
 */
@Controller
public class StompWebSocketController {

    @Autowired
    private StringRedisTemplate redisTemplate;

    private ObjectMapper objectMapper = new ObjectMapper();
    private Logger logger = LoggerFactory.getLogger(StompWebSocketController.class);

    @MessageMapping("/filter_condition")
    public void filterCondition(PushConditionInfo pushConditionInfo) throws JsonProcessingException {

        String sessionId = pushConditionInfo.getSessionId();
        if (StringUtils.isEmpty(sessionId)) {
            logger.error("接收过滤条件失败,{},不能为空！", sessionId);
            return;
        }

        /** 设置对比类型过滤条件 */
        setCompares(pushConditionInfo);

        String pushConditionJson = objectMapper.writeValueAsString(pushConditionInfo);
        logger.info("接收到的pushConditionJson:{}", pushConditionJson);

        String key = ResultKeyUtils.SENSETIME_RESULT_CONSUME_TD_WEBSOCKET_PREFIX + sessionId;
        /** 将过滤条件存储到redis,并设置过期时间  */
        redisTemplate
                .opsForValue()
                .set(key, pushConditionJson, REDIS_EXPIRE_TIME_ONE_DAY, TimeUnit.SECONDS);
    }

    /**
     * 设置对比类型过滤条件
     *
     * @param pushConditionInfo
     */
    private void setCompares(PushConditionInfo pushConditionInfo) {
        List<Integer> compareTypes = pushConditionInfo.getCompareTypes();
        if (compareTypes != null && compareTypes.size() > 0) {
            final int rwType = 99999;
            List<Integer> compares = new ArrayList<>();
            for (Integer compareType : compareTypes) {
                switch (compareType) {
                    case 1:
                        compares.add(MsgType.MATCH_VALUE);
                        break;
                    case 2:
                        compares.add(MsgType.INACTIVE_VALUE);
                        compares.add(MsgType.OUT_OF_TIMEZONE_VALUE);
                        compares.add(MsgType.ONLY_HAVE_BADGE_VALUE);
                        compares.add(MsgType.NO_DEVICE_PERMISSIONS_VALUE);
                        break;
                    case 3:
                        compares.add(9);
                        break;
                    case 4:
                        compares.add(MsgType.STRANGER_VALUE);
                        break;
                    case 5:
                        compares.add(MsgType.NON_BODY_DETECT_VALUE);
                        break;
                    case 6:
                        compares.add(MsgType.PASSWD_ERROR_VALUE);
                        break;
                    /**
                     * 结构化任务
                     */
                    case rwType:
                        compares.add(rwType);
                        break;
                    default:
                        break;
                }
            }
            pushConditionInfo.setCompareTypes(compares);
        }
    }
}
