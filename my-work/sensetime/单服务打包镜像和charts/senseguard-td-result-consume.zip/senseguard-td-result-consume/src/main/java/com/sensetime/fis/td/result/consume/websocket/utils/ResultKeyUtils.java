package com.sensetime.fis.td.result.consume.websocket.utils;

/**
 * ResultKeyUtils
 *
 * @author lizhengguang_vendor
 * @date 2019-1-17 20:14:31
 */
public class ResultKeyUtils {

    /**
     * 获取所有key
     */
    public static final String SENSETIME_RESULT_CONSUME_TD_WEBSOCKET =
            "sensetime:result:consume:td:websocket*";
    /**
     * key前缀
     */
    public static final String SENSETIME_RESULT_CONSUME_TD_WEBSOCKET_PREFIX =
            "sensetime:result:consume:td:websocket-";
    /**
     * 过期时间
     */
    public static final int REDIS_EXPIRE_TIME_ONE_DAY = 3600 * 24;
}
