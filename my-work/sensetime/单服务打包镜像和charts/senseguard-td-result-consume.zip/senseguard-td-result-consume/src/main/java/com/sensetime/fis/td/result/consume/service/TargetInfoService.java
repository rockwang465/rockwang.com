package com.sensetime.fis.td.result.consume.service;

import com.sensetime.fis.result.consume.common.module.TargetInfo;

/**
 * TargetInfoService
 *
 * @author lizhengguang_vendor
 * @date 2019-1-14 13:36:13
 */
public interface TargetInfoService {

    /**
     * 获取人像信息
     *
     * @param featureId 特征id
     * @return TargetInfo
     */
    TargetInfo getTargetInfo(String featureId);
}
