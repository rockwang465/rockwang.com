package com.sensetime.fis.td.result.consume.utils;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 线程池单例
 *
 * @author liqitian3344
 * @program opencv
 * @description {类描述}
 * @create 2019-07-26 16:23
 */
@Slf4j
public class ThreadPoolUtils {

    private static ThreadPoolExecutor executorService = null;

    public synchronized static ThreadPoolExecutor getInstance() {
        if (executorService == null) {
            executorService = new ThreadPoolExecutor(
                    20, 30, 60, TimeUnit.SECONDS,
                    new LinkedBlockingQueue<>(1024),
                    new ThreadFactoryBuilder().setNameFormat("async-thread-%d").build(),
                    new ThreadPoolExecutor.AbortPolicy());
        }
        return executorService;
    }

    private ThreadPoolUtils() {

    }

    public static void execute(Runnable runnable) {
        executorService.execute(runnable);
    }

}
