package com.sensetime.fis.td.result.consume.service.impl;

import com.sensetime.fis.td.result.consume.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * RedisServiceImpl
 *
 * @author Hyatt
 * @date 2019/9/12
 */
@Slf4j
@Service
public class RedisServiceImpl implements RedisService {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Override
    public boolean setNX(String key, String value, long timeout, TimeUnit timeUnit) {
        boolean locked = redisTemplate.opsForValue().setIfAbsent(key, value);
        if (locked) {
            expire(key, timeout, timeUnit);
        } else {
            log.info("暂未获取到key:{}锁", key);
        }
        return locked;
    }

    @Override
    public void expire(String key, long timeout, TimeUnit timeUnit) {
        redisTemplate.expire(key, timeout, timeUnit);
    }

    @Override
    public void delete(String key) {
        redisTemplate.delete(key);
    }

    @Override
    public void unLock(String key) {
        String value = redisTemplate.opsForValue().get(key);
        if (value != null) {
            log.info("手动释放redis锁,key:{}", key);
            delete(key);
        }
    }
}
