package com.sensetime.fis.td.result.consume.vo.web;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 底层摄像头内部唯一表识
 *
 * @author lizhengguang_vendor
 * @date 2018-12-28 14:40:42
 */
@Data
@ApiModel(description = "底层摄像头内部唯一表识")
public class InternalId {
    @ApiModelProperty(
            name = "regionId",
            required = true,
            example = "1",
            notes = "摄像头所属区域id, 0号id系统保留, 范围：[1, 16383].")
    private int regionId;

    @ApiModelProperty(
            name = "cameraIdx",
            required = true,
            example = "1",
            notes = "摄像头在区域region_id内的下标, 0号id系统保留, 范围：[1, 127].")
    private int cameraIdx;
}
