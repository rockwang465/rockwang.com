package com.sensetime.fis.td.result.consume;

import com.sensetime.fis.common.core.annotation.EnableRedis;
import com.sensetime.fis.common.core.annotation.EnableTracer;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动类 SenseguardTdResultConsumeApplication.
 *
 * @author lizhengguang_vendor
 * @date 2019-1-3 20:53:51
 */
@SpringBootApplication
@EnableTracer
@EnableRedis
@MapperScan("com.sensetime.fis.result.consume.common.mapper")
public class SenseguardTdResultConsumeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SenseguardTdResultConsumeApplication.class, args);
    }
}
