package com.sensetime.fis.td.result.consume.vo.response;

import lombok.Data;

/**
 * @ClassName GreetGuestsResponse
 * @Description 迎宾
 * @Author wangyuezheng
 * @Date 2019/12/30 17:11
 */
@Data
public class GreetGuestsResponse {
    /**
     * 一个访客的到访次数
     */

    private long visitTimes;
    /**
     * 迎宾活动的实际到访人数
     */
    private long actualVisitor;

}
