package com.sensetime.fis.td.result.consume.service;

import com.sensetime.fis.result.consume.common.entity.Task;
import com.sensetime.fis.result.consume.common.module.TaskInfo;
import org.elasticsearch.tasks.TaskId;

/**
 * TaskInfoService
 *
 * @author lizhengguang_vendor
 * @date 2019-1-14 13:37:28
 */
public interface TaskInfoService {

    /**
     * 获取任务信息
     *
     * @param platformTaskId 底层任务id
     * @return TaskInfo
     */
    TaskInfo getTaskInfo(String platformTaskId);

    /**
     * 判断推送记录是否为迎宾
     *
     * @param task      任务信息
     * @param libraryId 人像库id
     * @param score     比对分数
     * @return true=是迎宾记录，false=不是迎宾记录
     */
    boolean isWelcome(Task task, Long libraryId, Float score);
}
