package com.sensetime.fis.td.result.consume.service;

import java.util.concurrent.TimeUnit;

/**
 * RedisService
 *
 * @author Hyatt
 * @date 2019/9/12
 */
public interface RedisService {

    /**
     * <p>
     * 加锁并设置失效时间
     * </p>
     *
     * @param key
     * @param value
     * @param timeout
     * @param timeUnit
     * @return boolean
     * @throws
     */
    boolean setNX(String key, String value, long timeout, TimeUnit timeUnit);

    /**
     * <p>
     * 设置失效时间
     * </p>
     *
     * @param key
     * @param timeout
     * @param timeUnit
     * @throws
     */
    void expire(String key, long timeout, TimeUnit timeUnit);

    /**
     * <p>
     * 删除key
     * </p>
     *
     * @param key
     * @throws
     */
    void delete(String key);

    /**
     * <p>
     * 释放锁
     * </p>
     *
     * @param key
     * @throws
     */
    void unLock(String key);

}
