package com.sensetime.fis.td.result.consume.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @program: senseguard-device-management
 * @description:
 * @author: liqitian.
 * @create: 2019-08-28 18:00
 **/

@Data
@ApiModel
@AllArgsConstructor
@NoArgsConstructor
public class PushDataResponse {
    @ApiModelProperty(
            required = true,
            value = "code 200-服务正常,498参数无效",
            notes = "code 200-服务正常,498参数无效",
            example = "200")
    private Integer code;

    @ApiModelProperty(required = true, value = "desc 错误详细描述", notes = "desc 错误详细描述", example = "OK")
    private String desc;

    @ApiModelProperty(required = true, value = "message 简要描述", notes = "message 简要描述", example = "OK")
    private String message;

}

