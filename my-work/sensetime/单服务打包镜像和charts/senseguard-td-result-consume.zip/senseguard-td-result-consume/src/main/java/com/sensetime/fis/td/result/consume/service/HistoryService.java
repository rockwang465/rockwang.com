package com.sensetime.fis.td.result.consume.service;

import org.elasticsearch.action.search.SearchResponse;

import java.io.IOException;

/**
 * HistoryService
 *
 * @author lizhengguang_vendor
 * @date 2019-1-14 14:33:32
 */
public interface HistoryService {

    /**
     * 生成索引名称indexName
     *
     * @param historyName 索引类型：achistory,tdhistory
     * @return
     */
    String indexName(String historyName);

    /**
     * 判断索引是否存在isExistIndex
     *
     * @param indexName 索引名称
     * @param alias     索引別名
     * @return
     */
    boolean isExistIndex(String indexName, String alias);

    /**
     * 创建索引createHistoryIndex
     *
     * @param indexName   索引名称
     * @param historyType 索引类型
     * @return boolean
     */
    boolean createHistoryIndex(String indexName, String historyType);

    /**
     * 判断文档是否存在isExistDocument
     *
     * @param index 索引名称
     * @param type  索引类型
     * @param id    索引id
     * @return
     */
    boolean isExistDocument(String index, String type, String id);

    /**
     * 创建文档
     *
     * @param indexName   索引名称
     * @param historyType 索引类型
     * @param historyInfo 历史记录
     * @return boolean
     */
    boolean createDocument(String indexName, String historyType, String historyInfo);

    /**
     * 创建文档,人工设置id
     *
     * @param id
     * @param indexName
     * @param historyType
     * @param historyInfo
     * @return
     */
    boolean createDocument(String id, String indexName, String historyType, String historyInfo);

    /**
     * 根据 條件 查询ES数据
     *
     * @param indexName
     * @param historyType
     * @param trackId
     * @param taskId
     * @param objectId
     * @return
     * @throws IOException
     */
    SearchResponse selectDataByParams(String indexName, String historyType, Long trackId, Long taskId, String objectId) throws IOException;

    /**
     * 删除文档
     *
     * @param id
     * @param indexName
     * @param historyType
     * @param historyInfo
     * @return
     */
    boolean updateDocument(String id, String indexName, String historyType, String historyInfo);

    /**
     * 删除文档
     *
     * @param index
     * @param type
     * @param id
     * @return
     */
    boolean deleteDocument(String index, String type, String id);
}
