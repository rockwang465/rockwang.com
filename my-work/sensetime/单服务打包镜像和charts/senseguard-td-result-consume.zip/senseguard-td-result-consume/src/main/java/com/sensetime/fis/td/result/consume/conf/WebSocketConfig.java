package com.sensetime.fis.td.result.consume.conf;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * WebSocketMessageBroker
 *
 * @author lizhengguang_vendor
 * @date 2019-1-3 19:46:32
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    private Logger logger = LoggerFactory.getLogger(WebSocketConfig.class);

    /**
     * StompEndpointRegistry @param registry
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        logger.info("StompEndpointRegistry is OK ! ");
        /** 客户端WebSocket链接端点，new SockJS("/stomp") */
        registry.addEndpoint("/stomp").setAllowedOrigins("*").withSockJS();
    }

    /**
     * MessageBrokerRegistry @param registry
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        /** 接收WebSocket的send方法前缀 */
        registry.setApplicationDestinationPrefixes("/app");
        /** 发送WebSocket数据的后缀 */
        registry.enableSimpleBroker("/user", "/queue", "/topic");
        registry.setUserDestinationPrefix("/user");
        registry.setPreservePublishOrder(true);
        logger.info("MessageBrokerRegistry is OK ! ");
    }
}
