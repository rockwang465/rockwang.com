package com.sensetime.fis.td.result.consume.service.impl;

import com.sensetime.fis.result.consume.common.entity.Device;
import com.sensetime.fis.result.consume.common.entity.DeviceGroup;
import com.sensetime.fis.result.consume.common.mapper.DeviceGroupMapper;
import com.sensetime.fis.result.consume.common.mapper.DeviceMapper;
import com.sensetime.fis.result.consume.common.mapper.FloorMapper;
import com.sensetime.fis.result.consume.common.mapper.RegionMapper;
import com.sensetime.fis.result.consume.common.module.DeviceInfo;
import com.sensetime.fis.td.result.consume.service.DeviceInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * DeviceInfoServiceImpl
 *
 * @author lizhengguang_vendor
 * @date 2019-1-14 13:39:36
 */
@Service
public class DeviceInfoServiceImpl implements DeviceInfoService {

    @Autowired
    private DeviceMapper deviceMapper;
    @Autowired
    private DeviceGroupMapper deviceGroupMapper;
    @Autowired
    private RegionMapper regionMapper;
    @Autowired
    private FloorMapper floorMapper;

    private Logger logger = LoggerFactory.getLogger(DeviceInfoServiceImpl.class);

    /**
     * 获得设备相关信息 getDeviceInfo
     *
     * @param cameraIdx 区域中的相机ID
     * @param regionId  区域ID
     * @return
     */
    @Override
    public DeviceInfo getDeviceInfo(int cameraIdx, int regionId) {
        logger.info("query parameter [ cameraIdx: " + cameraIdx + " , regionId: " + regionId + " ]");
        Device device = deviceMapper.selectByIdentifier(regionId, cameraIdx);
        if (device == null) {
            return null;
        }
        DeviceGroup deviceGroup = deviceGroupMapper.selectByPrimaryKey(device.getGroupId());
        DeviceInfo deviceInfo = new DeviceInfo();
        deviceInfo.setDevice(device);
        deviceInfo.setDeviceGroup(deviceGroup);
        return deviceInfo;
    }
}
