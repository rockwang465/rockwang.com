package com.sensetime.fis.td.result.consume.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author lizhengguang_vendor
 * @date 2019-1-30 20:21:48
 */
@Data
@ApiModel
public class ErrorMessage {
    @ApiModelProperty("错误码，eg:401001")
    private String code;

    @ApiModelProperty("错误消息，eg:参数不能为空")
    private String message;

    @ApiModelProperty("资源路径，eg:/api/v1/login")
    private String path;

    @ApiModelProperty("资源方法，eg:POST")
    private String method;
}
