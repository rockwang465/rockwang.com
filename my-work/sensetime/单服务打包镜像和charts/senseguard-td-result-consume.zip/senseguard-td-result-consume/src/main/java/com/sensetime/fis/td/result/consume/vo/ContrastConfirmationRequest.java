package com.sensetime.fis.td.result.consume.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ContrastConfirmationRequest Module.
 *
 * @author lizhengguang_vendor
 * @date 2019-1-3 19:37:53
 */
@Data
@ApiModel
public class ContrastConfirmationRequest {

    @ApiModelProperty(value = "记录序列号")
    private String id;

    @ApiModelProperty(
            value = "对比状态：0:默认状态, 1:查看/取消比中, 2:比中, 3:未比中",
            notes = "对比状态：0:默认状态, 1:查看/取消比中, 2:比中, 3:未比中",
            example = "0")
    private int confirmationStatus;
}
