package com.sensetime.fis.td.result.consume.utils;

import org.springframework.util.ResourceUtils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * 读取classpath文件工具
 *
 * @author lizhengguang_vendor
 * @date 2019-1-8 13:28:41
 */
public class ClassPathFileReader {

    /**
     * 读历史记录映射文件json
     *
     * @param fileName
     * @return
     * @throws IOException
     */
    public static String historyMapping(String fileName) throws IOException {
        File file = ResourceUtils.getFile(fileName);
        FileInputStream fileInputStream = new FileInputStream(file);
        BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
        Long length = file.length();
        byte[] bytes = new byte[length.intValue()];
        bufferedInputStream.read(bytes);
        fileInputStream.close();
        bufferedInputStream.close();
        return new String(bytes, "utf-8");
    }
}
