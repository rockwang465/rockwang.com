package com.sensetime.fis.td.result.consume.service.impl;

import com.sensetime.fis.result.consume.common.entity.HotRegion;
import com.sensetime.fis.result.consume.common.entity.RelationTaskAttribute;
import com.sensetime.fis.result.consume.common.entity.Task;
import com.sensetime.fis.result.consume.common.entity.TaskAttribute;
import com.sensetime.fis.result.consume.common.mapper.*;
import com.sensetime.fis.result.consume.common.module.TaskInfo;
import com.sensetime.fis.result.consume.common.module.WelcomeRemarks;
import com.sensetime.fis.td.result.consume.service.TaskInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * TaskInfoServiceImpl
 *
 * @author lizhengguang_vendor
 * @date 2019-1-14 13:38:05
 */
@Service
public class TaskInfoServiceImpl implements TaskInfoService {

    @Autowired
    private TaskMapper taskMapper;
    @Autowired
    private TaskAttributeMapper taskAttributeMapper;
    @Autowired
    private RelationTaskAttributeMapper relationTaskAttributeMapper;
    @Autowired
    private HotRegionMapper hotRegionMapper;

    private Logger logger = LoggerFactory.getLogger(TaskInfoServiceImpl.class);

    /**
     * 获取任务信息
     *
     * @param platformTaskId 底层任务id
     * @return
     */
    @Override
    public TaskInfo getTaskInfo(String platformTaskId) {
        Task task = taskMapper.selectByPlatformTaskId(platformTaskId);
        if (task == null) {
            logger.error("not found task where platformTaskId=[{}]", platformTaskId);
            return null;
        }
        HotRegion hotRegion = hotRegionMapper.selectByTaskId(task.getTaskId());
        List<RelationTaskAttribute> attributeList =
                relationTaskAttributeMapper.selectByTaskId(task.getTaskId());
        if (attributeList == null) {
            return null;
        }
        List<Long> attributeIds = new ArrayList<>();
        attributeList.forEach(taskAttributes -> attributeIds.add(taskAttributes.getTaskAttributeId()));

        TaskInfo taskInfo = new TaskInfo();
        taskInfo.setTask(task);
        taskInfo.setHotRegion(hotRegion);
        if (!CollectionUtils.isEmpty(attributeIds)) {
            List<TaskAttribute> taskAttributes = taskAttributeMapper.selectByAttributeIds(attributeIds);
            taskInfo.setTaskAttributes(taskAttributes);
        }
        return taskInfo;
    }

    @Override
    public boolean isWelcome(Task task, Long libraryId, Float score) {
        if (task == null || libraryId == null) {
            return false;
        }
        Float compareScore = score == null ? 0f : score;
        List<WelcomeRemarks> welcomeRemarksList = taskMapper.selectByTaskIdToInfoWelcome(task.getTaskId());
        if (!CollectionUtils.isEmpty(welcomeRemarksList)) {
            for (WelcomeRemarks welcomeRemarks : welcomeRemarksList) {
                if (welcomeRemarks.getLibraryId().equals(libraryId) && compareScore >= task.getThreshold()) {
                    return true;
                }
            }
        }
        return false;
    }


}
