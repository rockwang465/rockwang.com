package com.sensetime.fis.td.result.consume.service.impl;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Timestamp;
import com.googlecode.protobuf.format.JsonFormat;
import com.sensetime.fis.common.core.utils.JsonUtil;
import com.sensetime.fis.result.consume.common.entity.ConfirmationInfo;
import com.sensetime.fis.result.consume.common.entity.Device;
import com.sensetime.fis.result.consume.common.entity.Task;
import com.sensetime.fis.result.consume.common.mapper.TaskMapper;
import com.sensetime.fis.result.consume.common.module.*;
import com.sensetime.fis.td.result.consume.service.*;
import com.sensetime.fis.td.result.consume.utils.IdWorker;
import com.sensetime.fis.td.result.consume.vo.web.request.RuleCheckParameter;
import com.sensetime.fis.td.result.consume.vo.web.response.RuleCheckResponse;
import com.sensetime.fis.td.result.consume.vo.web.response.RuleCheckUserInfo;
import com.sensetime.fis.td.result.consume.vo.web.result.RuleResult;
import com.sensetime.nebula.commonapis.Commonapis.*;
import com.sensetime.nebula.image_process.EngineImageProcessService.FaceAnnotation;
import com.sensetime.nebula.image_process.EngineImageProcessService.ObjectAnnotation;
import com.sensetime.nebula.image_process.EngineImageProcessService.ObjectInfo;
import com.sensetime.nebula.image_process.EngineImageProcessService.TrackEvent;
import com.sensetime.nebula.static_feature_db.StaticFeatureDb.FeatureBatchSearchMultiRequest.SearchConfig;
import com.sensetime.nebula.static_feature_db.StaticFeatureDb.FeatureBatchSearchResponse.SimilarResult;
import com.sensetime.nebula.static_feature_db.StaticFeatureDb.FeatureItem;
import com.sensetime.rws.commonapis.Commonapis.MonitorMultiDBSearchResults;
import com.sensetime.rws.commonapis.Commonapis.MsgType;
import com.sensetime.rws.commonapis.Commonapis.OneDBSearchResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * ResultConsumeServiceImpl
 *
 * @author lizhengguang_vendor
 * @date 2019-1-9 16:06:32
 */
@Slf4j
@Service
public class ResultConsumeServiceImpl implements ResultConsumeService {

    @Value("${elastic.history.type}")
    private String historyType;

    @Value("${elastic.history.name}")
    private String historyAlias;

    @Value("${osg-images.imagePrefix}")
    private String imagePrefix;

    @Value("${api.lib-auth.rule-check}")
    private String ruleCheckUrl;

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private HistoryService historyService;
    @Autowired
    private TaskInfoService taskInfoService;
    @Autowired
    private DeviceInfoService deviceInfoService;
    @Autowired
    private TargetInfoService targetInfoService;

    private JsonFormat jsonFormat = new JsonFormat();
    private Calendar calendar = Calendar.getInstance();
    private IdWorker idWorker = new IdWorker(1, 1);
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    public String consumeMessage(ConsumerRecord<?, ?> record) {
        log.debug("consume kafka message>>>start>>>");

        Instant message2HistoryInfoTime = Instant.now();
        HistoryInfo historyInfo = message2HistoryInfo(record);
        log.info("kafka message convert to HistoryInfo, cost {}ms", ChronoUnit.MILLIS.between(message2HistoryInfoTime, Instant.now()));

        if (historyInfo == null) {
            log.error("historyInfo cannot be null");
            return null;
        }

        DetectInfo detectInfo = historyInfo.getDetectInfo();
        FaceInfo faceInfo = (null == detectInfo) ? null : detectInfo.getFaceInfo();

        DeviceInfo deviceInfo = historyInfo.getDeviceInfo();
        Device device = (null == deviceInfo) ? null : deviceInfo.getDevice();
        Task task = (null == historyInfo.getTaskInfo()) ? null : historyInfo.getTaskInfo().getTask();

        if (null == faceInfo || null == device || null == task) {
            log.error("faceInfo or device or task is null...historyInfo:{}", JsonUtil.toJsonString(historyInfo));
            return null;
        }

        //tdhistory-2019-12-30
        String indexName = historyService.indexName(historyAlias);

        /** 判断索引是否存在，不存在索引则需要创建索引。 */
        boolean existIndex = historyService.isExistIndex(indexName, historyAlias);
        if (!existIndex) {
            log.info("create es index: {}", indexName);
            boolean createIndex = historyService.createHistoryIndex(indexName, historyAlias);
            if (!createIndex) {
                log.error("create es index error, historyInfo={}", historyInfo);
                return null;
            }
        }

        return handleHistoryInfo(indexName, historyInfo);
    }


    /**
     * 处理数据 未获取到redis锁 手动抛出异常来标识,需要重试操作
     *
     * @param indexName
     * @param historyInfo
     * @return String
     */
    private String handleHistoryInfo(String indexName, HistoryInfo historyInfo) {

        // v2.2.0 推送策略调整，去除图片替换机制
        String historyJson = history2Json(historyInfo);
        Instant now = Instant.now();
        historyService.createDocument(indexName, historyType, historyJson);
        log.info("create document cost {}ms", ChronoUnit.MILLIS.between(now, Instant.now()));
        return historyJson;
    }

    /**
     * HistoryInfo转JsonString
     *
     * @param historyInfo
     * @return
     */
    private String history2Json(HistoryInfo historyInfo) {
        String serialNumber = idWorker.nextId() + "";
        historyInfo.setSerialNumber(serialNumber);
        String historyJson = JsonUtil.toJsonString(historyInfo);
        log.debug("After HistoryInfo conversion {}", historyJson);
        return historyJson;
    }

    /**
     * 转换kafka消息到History
     *
     * @param record kafka消息
     */
    private HistoryInfo message2HistoryInfo(ConsumerRecord<?, ?> record) {

        log.debug("转译kafka数据为HistoryInfo对象");
        byte[] bytes = (byte[]) record.value();
        log.debug("Kafka data before conversion [ " + record + " ]");
        MonitorMultiDBSearchResults multiDBSearchResults = null;
        try {
            multiDBSearchResults = MonitorMultiDBSearchResults.parseFrom(bytes);
        } catch (InvalidProtocolBufferException e) {
            log.error("kafka data parse happen error: ", e);
        }

        log.debug("Converted Kafka data : {}", jsonFormat.printToString(multiDBSearchResults));

        HistoryInfo historyInfo = new HistoryInfo();
        if (multiDBSearchResults == null) {
            return historyInfo;
        }
        ObjectInfo objectInfo = multiDBSearchResults.getObject();

        String objectId = objectInfo.getObject().getObjectId();
        historyInfo.setObjectId(objectId);

        // set trackEvent
        TrackEvent trackEvent = objectInfo.getTrackEvent();
        TrackEventInfo trackEventInfo = new TrackEventInfo();
        trackEventInfo.setDescriptor(trackEvent.getValueDescriptor().getName());
        trackEventInfo.setEventNum(trackEvent.getNumber());
        historyInfo.setTrackEvent(trackEventInfo);

        // setDeviceInfo
        CameraInfo cameraInfo = objectInfo.getCameraInfo();
        CameraIdentifier internalId = cameraInfo.getInternalId();
        int cameraIdx = internalId.getCameraIdx();
        int regionId = internalId.getRegionId();
        //定位设备信息
        Instant deviceTime = Instant.now();
        DeviceInfo deviceInfo = deviceInfoService.getDeviceInfo(cameraIdx, regionId);
        log.info("query device info cost {}ms", ChronoUnit.MILLIS.between(deviceTime, Instant.now()));
        historyInfo.setDeviceInfo(deviceInfo);
        deviceInfo.getDevice().getDeviceCode();

        // DetectInfo
        DetectInfo detectInfo = new DetectInfo();

        // CaptureTime
        //    Timestamp capturedTime = objectInfo.getCapturedTime();
        Timestamp receivedTime = objectInfo.getReceivedTime();

        //    long capturedTime1 = capturedTime.getSeconds() * 1000;
        long receivedTime1 = receivedTime.getSeconds() * 1000;
        detectInfo.setCapturedTime(receivedTime1);
        detectInfo.setReceivedTime(receivedTime1);

        log.debug("kafka 抓拍时间到接收耗时 {} ms", System.currentTimeMillis() - receivedTime1);

        calendar.setTimeInMillis(receivedTime1);
        detectInfo.setCaptureDate(simpleDateFormat.format(calendar.getTime()));

        // FaceAnnotation
        ObjectAnnotation objectAnnotation = objectInfo.getObject();
        FaceAnnotation faceAnnotation = objectAnnotation.getFace();
        Angle angle = faceAnnotation.getAngle();
        AngleInfo angleInfo = new AngleInfo();
        angleInfo.setYaw(angle.getYaw());
        angleInfo.setRoll(angle.getRoll());
        angleInfo.setPitch(angle.getPitch());

        FaceInfo faceInfo = new FaceInfo();
        faceInfo.setAngleInfo(angleInfo);
        faceInfo.setQuality(faceAnnotation.getQuality());

        /**
         * 支持抓拍机返回alive_type字段
         * alive_type为非活体时，抓拍人脸比对类型为【非活体攻击】
         * 一旦打开了活体检测  那么非活体攻击比对类型的,优先级高于其他比对类型!!!
         */
        Map<String, String> map = faceAnnotation.getAttributesMap();
        if (map != null) {
            String aliveType = map.get("alive_type");
            String nonAlive = "non-alive";
            if (aliveType != null && nonAlive.equals(aliveType)) {
                historyComparedType(historyInfo, MsgType.NON_BODY_DETECT);
            }
        }

        // 人脸跟踪ID
        faceInfo.setTrackId(faceAnnotation.getTrackId());
        faceInfo.setAttribute(faceAnnotation.getAttributesMap());

        PortraitImageInfo portraitImageInfo = new PortraitImageInfo();
        setPortraitImageInfo(
                objectInfo, detectInfo, objectAnnotation, faceAnnotation, faceInfo, portraitImageInfo);

        Image portraitImage = objectInfo.getPortraitImage();
        portraitImageInfo.setUrl(imagePrefix + portraitImage.getUrl());

        faceInfo.setPortraitImageInfo(portraitImageInfo);
        detectInfo.setFaceInfo(faceInfo);

        int objectIndexInFrame = objectInfo.getObjectIndexInFrame();
        detectInfo.setIndexFrame(Long.valueOf(objectIndexInFrame));

        // 设置taskInfo
        String taskId = multiDBSearchResults.getTaskId();
        Instant taskTime = Instant.now();
        TaskInfo taskInfo = taskInfoService.getTaskInfo(taskId);
        log.info("query task info cost {}ms", ChronoUnit.MILLIS.between(taskTime, Instant.now()));
        historyInfo.setTaskInfo(taskInfo);


        TargetInfo targetInfo = null;
        // 非活体攻击比对类型，不执行调用lib-auth逻辑
        if (historyInfo.getComparedType() != MsgType.NON_BODY_DETECT.getNumber()) {

            List<OneDBSearchResult> searchResultsList = multiDBSearchResults.getSearchResultsList();

            /** 调用lib-auth接口获取比对类型 */
            RuleCheckParameter checkParameter = new RuleCheckParameter();
            List<RuleResult> ruleResults = new ArrayList<>();
            /** 获取任务阈值 */
            for (OneDBSearchResult oneDBSearchResult : searchResultsList) {
                RuleResult ruleResult = new RuleResult();
                SearchConfig configs = oneDBSearchResult.getConfigs();
                List<SimilarResult> similarResults = oneDBSearchResult.getSimilarsList();
                /** 判断搜索结果是否为空？结果为空，表示没有搜索结果。为陌生人，0分 */
                if (similarResults != null && similarResults.size() > 0) {
                    /** 每个库只取top1 */
                    SimilarResult similarResult = similarResults.get(0);
                    float score = similarResult.getScore();
                    FeatureItem featureItem = similarResult.getItem();
                    String featureId = featureItem.getId();

                    ruleResult.setScore(score);
                    ruleResult.setFeatureId(featureId);
                    ruleResult.setColId(configs.getColId());
                    ruleResults.add(ruleResult);
                }
            }
            checkParameter.setType(1);
            checkParameter.setTaskId(taskId);
            checkParameter.setResults(ruleResults);

            log.debug("ruleResults:{}", JsonUtil.toJsonString(ruleResults));

            Instant callTime = Instant.now();
            ResponseEntity<RuleCheckResponse> responseEntity =
                    restTemplate.postForEntity(ruleCheckUrl, checkParameter, RuleCheckResponse.class);
            log.info("调用lib-auth接口耗时{} ms", ChronoUnit.MILLIS.between(callTime, Instant.now()));

            if (responseEntity.getStatusCode().equals(HttpStatus.OK)) {
                RuleCheckResponse ruleCheckResponse = responseEntity.getBody();
                RuleCheckUserInfo userInfo = ruleCheckResponse.getRuleCheckUserInfo();
                if (userInfo != null) {
                    String colId = userInfo.getColId();
                    for (RuleResult ruleResult : ruleResults) {
                        if (colId.equals(ruleResult.getColId())) {
                            detectInfo.setFeatureId(ruleResult.getFeatureId());
                            break;
                        }
                    }
                    detectInfo.setScore(userInfo.getScore());
                }
                /** 设置对比类型 */
                setComparedType(historyInfo, ruleCheckResponse.getCode());
            }

            /** 设置人像信息 */
            String featureId = detectInfo.getFeatureId();
            if (!StringUtils.isEmpty(featureId)) {
                Instant targetTime = Instant.now();
                targetInfo = targetInfoService.getTargetInfo(featureId);
                log.info("query target info cost {}ms", ChronoUnit.MILLIS.between(targetTime, Instant.now()));
                historyInfo.setTargetInfo(targetInfo);
            } else {
                log.error("featureId为空无法查询用户信息");
                return null;
            }
        }

        // 设置是否为迎宾记录，超过阈值且在库里即为迎宾记录
        if (taskInfo != null && targetInfo != null && targetInfo.getLibrary() != null) {
            boolean welcome = taskInfoService.isWelcome(taskInfo.getTask(), targetInfo.getLibrary().getLibraryId(), detectInfo.getScore());
            historyInfo.setWelcome(welcome);
        }

        historyInfo.setDetectInfo(detectInfo);
        return historyInfo;
    }

    /**
     * 设置对比类型
     *
     * @param historyInfo
     * @param code
     */
    private void setComparedType(HistoryInfo historyInfo, int code) {
        switch (code) {
            //
            case 0:
                historyComparedType(historyInfo, MsgType.MATCH);
                break;
            case 1:
                /** 总库，设置为没权限 */
                historyComparedType(historyInfo, MsgType.NO_DEVICE_PERMISSIONS);
                break;
            case 2:
                historyComparedType(historyInfo, MsgType.OUT_OF_TIMEZONE);
                break;
            case 3:
                historyComparedType(historyInfo, MsgType.STRANGER);
                break;
            case 4:
                historyComparedType(historyInfo, MsgType.INACTIVE);
                break;
            case 7:
                /** 黑名单类型：from 8->9 */
                historyInfo.setComparedType(9);
                historyInfo.setDescription("Black Library");
                break;
            default:
                break;
        }
    }

    /**
     * 历史记录对比类型
     *
     * @param historyInfo
     * @param match
     */
    private void historyComparedType(HistoryInfo historyInfo, MsgType match) {
        historyInfo.setComparedType(match.getNumber());
        historyInfo.setDescription(match.name());
    }

    /**
     * 设置小图信息
     *
     * @param objectInfo
     * @param detectInfo
     * @param objectAnnotation
     * @param faceAnnotation
     * @param faceInfo
     * @param portraitImageInfo
     */
    private void setPortraitImageInfo(
            ObjectInfo objectInfo,
            DetectInfo detectInfo,
            ObjectAnnotation objectAnnotation,
            FaceAnnotation faceAnnotation,
            FaceInfo faceInfo,
            PortraitImageInfo portraitImageInfo) {
        // 全景图
        PortraitImageLocation portraitImageLocation =
                setPortraitImageLocation(objectInfo, detectInfo, objectAnnotation);

        BoundingPoly rectangle = faceAnnotation.getRectangle();
        List<Vertex> rectangleVerticesList = rectangle.getVerticesList();
        Vertex rectangleStart = rectangleVerticesList.get(0);
        Vertex rectangleEnd = rectangleVerticesList.get(1);
        VertexInfo startTmp = new VertexInfo();
        startTmp.setX(rectangleStart.getX());
        startTmp.setY(rectangleStart.getY());
        faceInfo.setStart(startTmp);
        VertexInfo endTmp = new VertexInfo();
        endTmp.setY(rectangleEnd.getY());
        endTmp.setX(rectangleEnd.getX());
        faceInfo.setEnd(endTmp);

        // 可选, 抓拍对象相对于大图的位置. 当本字段非空时, 应使用本字段获取抓拍对象在大图中的位置, 并且此时 portrait_image_in_panoramic可能为空, 且小图可能不属于大图的子区域.
        BoundingPoly portraitInPanoramic = portraitImageLocation.getPortraitInPanoramic();
        //抓拍小图相对全景大图的位置
        BoundingPoly portraitImageInPanoramic = portraitImageLocation.getPortraitImageInPanoramic();
        VertexInfo endInfo = new VertexInfo();
        VertexInfo startInfo = new VertexInfo();
        if (portraitInPanoramic != null && !CollectionUtils.isEmpty(portraitInPanoramic.getVerticesList())) {
            log.info("Small chart information processing：The capture object is not empty relative to the larger figure[portraitInPanoramic not Empty]{}",portraitImageInfo.getUrl());
            List<Vertex> verticesList = portraitInPanoramic.getVerticesList();
            if (verticesList != null && !verticesList.isEmpty()) {
                Vertex start = verticesList.get(0);
                Vertex end = verticesList.get(1);
                endInfo.setX(end.getX());
                endInfo.setY(end.getY());
                startInfo.setY(start.getY());
                startInfo.setX(start.getX());
            }

        } else {
            if (portraitImageInPanoramic != null && !CollectionUtils.isEmpty(portraitImageInPanoramic.getVerticesList())) {
                log.info("Small chart information processing：The position of the capture small plot relative to the panoramic large rand[portraitImageInPanoramic not Empty]{}",portraitImageInfo.getUrl());

                // 人脸在抓拍大图的坐标：左上点位(start)=抓拍小图左上点位+人脸左上点位，右下点位(end)=抓拍小图做上点位+人脸右下点位
                List<Vertex> panoramicVerticesList = portraitImageInPanoramic.getVerticesList();
                Vertex start = panoramicVerticesList.get(0);
                startInfo.setX(rectangleStart.getX() + start.getX());
                startInfo.setY(rectangleStart.getY() + start.getY());

                endInfo.setX(rectangleEnd.getX() + start.getX());
                endInfo.setY(rectangleEnd.getY() + start.getY());
            }
        }

        portraitImageInfo.setEnd(endInfo);
        portraitImageInfo.setStart(startInfo);
    }

    /**
     * 设置大图信息
     *
     * @param objectInfo
     * @param detectInfo
     * @param objectAnnotation
     * @return
     */
    private PortraitImageLocation setPortraitImageLocation(
            ObjectInfo objectInfo, DetectInfo detectInfo, ObjectAnnotation objectAnnotation) {
        Image panoramicImage = objectInfo.getPanoramicImage();
        PortraitImageLocation portraitImageLocation = objectAnnotation.getPortraitImageLocation();
        Size panoramicImageSize = portraitImageLocation.getPanoramicImageSize();
        ImageInfo imageInfo = new ImageInfo();
        imageInfo.setHeight(panoramicImageSize.getHeight());
        imageInfo.setWidth(panoramicImageSize.getWidth());
        imageInfo.setUrl(imagePrefix + panoramicImage.getUrl());
        detectInfo.setImage(imageInfo);
        return portraitImageLocation;
    }
}
