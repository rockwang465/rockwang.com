package com.sensetime.fis.td.result.consume.service.impl;

import com.sensetime.fis.td.result.consume.service.HistoryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.admin.indices.alias.Alias;
import org.elasticsearch.action.admin.indices.alias.IndicesAliasesRequest;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequest;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.get.GetIndexRequest;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.GetAliasesResponse;
import org.elasticsearch.client.IndicesClient;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.FetchSourceContext;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Collectors;

/**
 * HistoryServiceImpl
 *
 * @author lizhengguang_vendor
 * @date 2019-1-7 15:50:45
 */
@Slf4j
@Service
public class HistoryServiceImpl implements HistoryService {

    /**
     * rest restHighLevelClient
     */
    @Autowired
    private RestHighLevelClient restHighLevelClient;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * 判断索引是否存在
     */
    @Override
    public boolean isExistIndex(String indexName, String indexAlias) {

        GetIndexRequest getIndexRequest = new GetIndexRequest();
        getIndexRequest.indices(indexName);

        try {
            boolean indexExists = restHighLevelClient.indices().exists(getIndexRequest, RequestOptions.DEFAULT);
            if (indexExists) {
                if (StringUtils.isNotBlank(indexAlias)) {
                    log.info("index[{}] exists, judge whether alias[{}] exists.", indexName, indexAlias);
                    GetAliasesRequest getAliasesRequest = new GetAliasesRequest();
                    getAliasesRequest.indices(indexName);
                    getAliasesRequest.aliases(indexAlias);

                    GetAliasesResponse getAliasesResponse = restHighLevelClient.indices().getAlias(getAliasesRequest, RequestOptions.DEFAULT);
                    if (getAliasesResponse.status() == RestStatus.OK) {
                        log.info("index[{}] exists, alias[{}] exists.", indexName, indexAlias);
                        return true;
                    } else {
                        log.info("for index[{}] add alias[{}]", indexName, indexAlias);
                        IndicesAliasesRequest aliasesRequest = new IndicesAliasesRequest();
                        aliasesRequest.addAliasAction(IndicesAliasesRequest.AliasActions.add().index(indexName).alias(indexAlias));
                        boolean relateAlias = restHighLevelClient.indices().updateAliases(aliasesRequest, RequestOptions.DEFAULT).isAcknowledged();
                        log.info("index[{}] add alias[{}], success or failure flag[{}]", indexName, indexAlias, relateAlias);
                    }
                }
                return true;
            }
        } catch (IOException e) {
            log.error("judge whether es index exists error：ex:{}", e.getMessage());
        }
        return false;
    }

    /**
     * 判断文档是否存在
     *
     * @param index 索引名称
     * @param type  索引类型
     * @param id    索引id
     * @return
     */
    @Override
    public boolean isExistDocument(String index, String type, String id) {
        GetRequest getRequest = new GetRequest(index, type, id);
        FetchSourceContext context = new FetchSourceContext(false);
        getRequest.fetchSourceContext(context);
        getRequest.storedFields("_none_");
        boolean exists = false;
        try {
            exists = restHighLevelClient.exists(getRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error("judge whether es document exists error, ex：{}", e.getMessage());
        }
        return exists;
    }

    /**
     * @param indexName    索引名称
     * @param historyAlias 别名
     */
    @Override
    public boolean createHistoryIndex(String indexName, String historyAlias) {
        if (isExistIndex(indexName, historyAlias)) {
            log.info("index[{}] already exists", indexName);
            return true;
        }
        String historyMapping = getMappingOrSetting("history_mapping.json");
        String historySetting = getMappingOrSetting("history_setting.json");

        CreateIndexRequest createIndexRequest = new CreateIndexRequest(indexName);
        createIndexRequest.settings(historySetting, XContentType.JSON);
        createIndexRequest.alias(
                new Alias(historyAlias)).mapping("history", historyMapping, XContentType.JSON);
        try {
            long start = System.currentTimeMillis();
            IndicesClient indicesClient = restHighLevelClient.indices();
            if (null == indicesClient) {
                log.error("connect es client error...");
                return false;
            }
            CreateIndexResponse createIndexResponse = indicesClient.create(createIndexRequest, RequestOptions.DEFAULT);
            log.info("create es index[{}] success, cost {}ms", createIndexResponse.index(), (System.currentTimeMillis() - start));
        } catch (IOException e) {
            log.error("create es index[{}] error,ex:{}", indexName, e.getMessage());
            return false;
        }
        return true;
    }

    String getMappingOrSetting(String path) {
        String collect = null;
        try {
            ClassPathResource cpr = new ClassPathResource(path);
            InputStream inputStream = cpr.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            collect = bufferedReader.lines().collect(Collectors.joining(System.lineSeparator()));
            bufferedReader.close();
        } catch (IOException e) {
            log.error("e:{}", e.getMessage());
        }
        return collect;
    }


    /**
     * indexName生成history index name
     */
    @Override
    public String indexName(String historyName) {
        return historyName + "-" + sdf.format(new Date());
    }

    /**
     * 创建elasticsearch文档
     *
     * @param indexName   索引名称
     * @param historyType 索引类型
     * @param historyInfo 历史记录
     * @return
     */
    @Override
    public boolean createDocument(String indexName, String historyType, String historyInfo) {
        return createDocument(null, indexName, historyType, historyInfo);
    }

    @Override
    public boolean createDocument(String id, String indexName, String historyType, String historyInfo) {
        IndexRequest indexRequest = new IndexRequest(indexName, historyType);
        indexRequest.source(historyInfo, XContentType.JSON);
        if (StringUtils.isNotBlank(id)) {
            log.info("assign document id: {}", id);
            indexRequest.id(id);
        }
        try {

            IndexResponse response = restHighLevelClient.index(indexRequest, RequestOptions.DEFAULT);
            return response.status() == RestStatus.CREATED;
        } catch (Exception e) {
            log.error("HistoryInfo failed to create a document : {}", e.getMessage());
        }
        return false;
    }

    @PreDestroy
    public void destroyClient() {
        try {
            restHighLevelClient.close();
        } catch (IOException e) {
            log.info("RestHighLevelClient close happen error.ex:{}", e.getMessage());
        }
    }

    @Override
    public SearchResponse selectDataByParams(String indexName, String historyType, Long trackId, Long taskId, String objectId) throws IOException {

        log.info("retrieving es data>>>,trackId:{},taskId:{},objectId:{}", trackId, taskId, objectId);
        SearchRequest searchRequest = new SearchRequest(indexName);
        searchRequest.types(historyType);

        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        QueryBuilder qb = QueryBuilders.boolQuery();
        ((BoolQueryBuilder) qb).must(QueryBuilders.termQuery("detectInfo.faceInfo.trackId", trackId))
                .must(QueryBuilders.termQuery("objectId", objectId))
                .must(QueryBuilders.termQuery("taskInfo.task.taskId", taskId));

        sourceBuilder.query(qb).sort(new FieldSortBuilder("detectInfo.capturedTime").order(SortOrder.DESC));
        sourceBuilder.from(0);
        sourceBuilder.size(10);
        searchRequest.source(sourceBuilder);
        long start = System.currentTimeMillis();
        SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        log.info("retrieving es data cost:{}ms", (System.currentTimeMillis() - start));
        return response;
    }

    @Override
    public boolean updateDocument(String id, String indexName, String historyType, String historyInfo) {

        log.info("update es document...dataId:{},indexName:{},historyType:{}", id, indexName, historyType);
        try {

            UpdateRequest updateRequest = new UpdateRequest(indexName, historyType, id);
            IndexRequest indexRequest = new IndexRequest(indexName, historyType);
            indexRequest.source(historyInfo, XContentType.JSON);
            updateRequest.doc(indexRequest);
            long start = System.currentTimeMillis();
            UpdateResponse response = restHighLevelClient.update(updateRequest, RequestOptions.DEFAULT);
            log.info("update es document cost: {}ms", (System.currentTimeMillis() - start));
            if (response.getResult() == DocWriteResponse.Result.UPDATED) {
                log.info("update es document success");
                return true;
            }
            log.info("update es document failure");
            return false;
        } catch (IOException e) {
            log.error("update es document error, ex:{}", e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteDocument(String index, String type, String id) {
        DeleteRequest deleteRequest = new DeleteRequest(index, type, id);
        try {
            DeleteResponse response = restHighLevelClient.delete(deleteRequest, RequestOptions.DEFAULT);
            if (response.getResult() == DocWriteResponse.Result.DELETED) {
                log.info("delete es document[{}] success", id);
                return true;
            }
        } catch (IOException e) {
            log.error("delete es document error, index:{}, type:{}, id:{}, ex:{}", index, type, id, e.getMessage());
        }
        return false;
    }
}
