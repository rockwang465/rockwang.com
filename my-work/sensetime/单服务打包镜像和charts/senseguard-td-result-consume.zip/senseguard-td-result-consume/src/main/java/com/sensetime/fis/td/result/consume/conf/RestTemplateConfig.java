package com.sensetime.fis.td.result.consume.conf;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;

/**
 * RestTemplate配置文件
 *
 * @author lizhengguang_vendor
 * @date 2019-1-16 13:20:24
 */
@Slf4j
@Configuration
public class RestTemplateConfig {

    @Value("${restTemplate.readTimeout:3000}")
    private int readTimeout;

    @Value("${restTemplate.connectTimeout:3000}")
    private int connectTimeout;

    @Value("${restTemplate.connectionRequestTimeout:3000}")
    private int connectionRequestTimeout;

    @Bean
    RestTemplate restTemplate() {
        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory =
                new HttpComponentsClientHttpRequestFactory();
        httpComponentsClientHttpRequestFactory.setConnectTimeout(connectTimeout);
        httpComponentsClientHttpRequestFactory.setConnectionRequestTimeout(connectionRequestTimeout);
        httpComponentsClientHttpRequestFactory.setReadTimeout(readTimeout);

        // 忽略ssl
        ignoreSSL(httpComponentsClientHttpRequestFactory);

        RestTemplate restTemplate = new RestTemplate(httpComponentsClientHttpRequestFactory);
        return restTemplate;
    }

    private HttpComponentsClientHttpRequestFactory ignoreSSL(HttpComponentsClientHttpRequestFactory factory) {
        try {
            TrustStrategy acceptingTrustStrategy = (x509Certificates, authType) -> true;
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            SSLConnectionSocketFactory connectionSocketFactory = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());

            HttpClientBuilder httpClientBuilder = HttpClients.custom();
            httpClientBuilder.setSSLSocketFactory(connectionSocketFactory);
            CloseableHttpClient httpClient = httpClientBuilder.build();

            factory.setHttpClient(httpClient);
        } catch (Exception e) {
            log.error("e:{}", e);
        }
        return factory;
    }
}
