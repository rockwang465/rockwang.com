package com.sensetime.fis.td.result.consume.kafka.listener;

import com.sensetime.fis.td.result.consume.service.DataPushService;
import com.sensetime.fis.td.result.consume.service.ResultConsumeService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * KafkaMessageReceiver
 *
 * @author lizhengguang_vendor
 * @date 2019-1-3 17:00:01
 */
@Component
public class KafkaMessageReceiver {

    @Autowired
    private StringRedisTemplate redisTemplate;
    
    /**
     * ResultConsumeService
     */
    @Autowired
    private ResultConsumeService resultConsumeService;
    @Autowired
    private DataPushService dataPushService;
    /**
     * topicName
     */
    @Value("${kafka.topic-name}")
    private String topicName;

    @Value("${redis.channel}")
    private String channel;

    @Value("${websocket.destination}")
    private String destination;


    private Logger logger = LoggerFactory.getLogger(KafkaMessageReceiver.class);

    /**
     * kafka consume message @param record
     */
    @KafkaListener(
            groupId = "group-td",
            topics = {"${kafka.topic-name}"},
            concurrency = "${kafka.listen.concurrency:16}",
            autoStartup = "${kafka.listen.auto.start:true}")
    public void consumeMessage(ConsumerRecord<?, ?> record) {
        String historyInfo = null;
        long receiveTimeMillis = System.currentTimeMillis();
        try {
            historyInfo = resultConsumeService.consumeMessage(record);
        } catch (Exception e) {
            logger.error("kafka[{}] message handling exception：{}", topicName, e.getMessage());
        }

       if (!StringUtils.isEmpty(historyInfo)) {

           // 数据推送redis，解决websocket HA问题
           redisTemplate.convertAndSend(channel, historyInfo);

           /**
            * 数据推送[sent to kafka]
            */
           dataPushService.sentToKafka(historyInfo);
        }
        long currentTimeMillis = System.currentTimeMillis();
        logger.info("received kafka message time is {}ms, process data cost {}ms", receiveTimeMillis, currentTimeMillis - receiveTimeMillis);
    }
}
