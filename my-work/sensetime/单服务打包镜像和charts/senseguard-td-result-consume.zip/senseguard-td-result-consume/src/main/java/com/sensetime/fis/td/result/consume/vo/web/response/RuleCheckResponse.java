package com.sensetime.fis.td.result.consume.vo.web.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 规则校验结果
 *
 * @author lizhengguang_vendor
 * @date 2018-12-28 15:33:38
 */
@Data
@ApiModel
public class RuleCheckResponse {
    @ApiModelProperty(
            value =
                    "code [MATCH(0, \"OK\"), NO_DEVICE_PERMISSIONS(1, \"NO_DEVICE_PERMISSIONS\"), OUT_OF_TIME(2, \"OUT_OF_TIME\"), BELOW_THE_THRESHOLD(3, \"BELOW_THE_THRESHOLD\"), INACTIVATED(4, \"INACTIVATED\"), NO_PORTRAIT_RECORD(5, \"NO_PORTRAIT_RECORD\"), HAPPEN_EXCEPTION(6, \"HAPPEN_EXCEPTION\"), BLACK_LIBRARY(7, \"BLACK_LIBRARY\")]",
            notes = "响应code")
    private int code;

    @ApiModelProperty(value = "error", notes = "响应error")
    private String error;

    @ApiModelProperty(
            value = "keeper/pass提示消息（长度限制：13个中文字符或23个英文字符）")
    private String entryHint;

    @ApiModelProperty(value = "RuleCheckUserInfo", notes = "RuleCheckUserInfo")
    private RuleCheckUserInfo ruleCheckUserInfo;
}
