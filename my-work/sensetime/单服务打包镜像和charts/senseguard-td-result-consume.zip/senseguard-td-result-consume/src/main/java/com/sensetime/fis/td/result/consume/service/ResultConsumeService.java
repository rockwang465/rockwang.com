package com.sensetime.fis.td.result.consume.service;

import com.google.protobuf.InvalidProtocolBufferException;
import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * ResultConsumeService
 *
 * @author lizhengguang_vendor
 * @date 2019-1-9 16:05:57
 */
public interface ResultConsumeService {

    /**
     * consumeMessage
     *
     * @param record
     * @return
     * @throws InvalidProtocolBufferException
     */
    String consumeMessage(ConsumerRecord<?, ?> record) throws InvalidProtocolBufferException;
}
