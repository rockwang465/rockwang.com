package com.sensetime.fis.td.result.consume.vo.web.result;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author lizhengguang_vendor
 * @date 2019-1-7 18:47:40
 */
@Data
@ApiModel
public class RuleResult {
    @ApiModelProperty(value = "静态库id", notes = "静态库id", required = true, allowEmptyValue = true)
    private String colId;

    @ApiModelProperty(value = "人像特征Id", notes = "人像特征Id", required = true, allowEmptyValue = true)
    private String featureId;

    @ApiModelProperty(value = "人像分数：0-1", notes = "人像分数：0-1", required = true, example = "0")
    private float score;

    @ApiModelProperty(
            value = "第三方通过过来的身份ID或者自定义证件号",
            notes = "第三方通过过来的身份ID或者自定义证件号",
            required = true,
            example = "0")
    private String identity;

    @ApiModelProperty(
            value = "证件类型，A-大陆身份证（可以继续扩展）",
            notes = "证件类型，A-大陆身份证（可以继续扩展）",
            required = true,
            example = "0")
    private String identityType;
}
