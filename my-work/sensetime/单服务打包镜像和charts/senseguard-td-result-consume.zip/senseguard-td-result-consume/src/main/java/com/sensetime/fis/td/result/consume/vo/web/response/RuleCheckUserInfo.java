package com.sensetime.fis.td.result.consume.vo.web.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * info_target 人员信息表
 *
 * @author lizhengguang_vendor
 * @date 2019-1-8 11:24:18
 */
@Data
@ApiModel
public class RuleCheckUserInfo {

    @ApiModelProperty(value = "用户id")
    private Long targetId;

    @ApiModelProperty(value = "第三方通过过来的身份ID或者自定义证件号")
    private String identity;

    @ApiModelProperty(value = "用户名（长度限制：13个英文字母或８个中文字符）")
    private String name;

    @ApiModelProperty(value = "韦根控制器用户卡ID，非韦根控制方式可不填")
    private String userCardId;

    @ApiModelProperty(value = "最高分：0-1", notes = "最高分：0-1")
    private float score;

    @ApiModelProperty(value = "静态库id", notes = "静态库id", required = true, allowEmptyValue = true)
    private String colId;
}
