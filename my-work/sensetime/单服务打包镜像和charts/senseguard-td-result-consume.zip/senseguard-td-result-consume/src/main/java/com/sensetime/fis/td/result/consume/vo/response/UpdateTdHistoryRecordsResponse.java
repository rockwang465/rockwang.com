package com.sensetime.fis.td.result.consume.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author lizhengguang_vendor
 * @date 2019-2-15 13:09:14
 */
@Data
@ApiModel
public class UpdateTdHistoryRecordsResponse {
    @ApiModelProperty("记录序列号")
    private String id;
}
