package com.sensetime.fis.td.result.consume.constant;

/**
 * Constants
 *
 * @author Hyatt
 * @date 2019/9/12
 */
public class Constants {

    private static final String SENSEGUARD_TD_RESULT_CONSUME = "SenseTime:SenseGuard:TD:Result:Consume:";

    public static final String SENSEGUARD_TD_RESULT_CONSUME_LOCK_KEY = SENSEGUARD_TD_RESULT_CONSUME + "%s";

    public static final String SENSEGUARD_TD_RESULT_CONSUME_INDEX_EXIST_KEY = SENSEGUARD_TD_RESULT_CONSUME + "index";

    public static final String AES_KEY_CODE = "aes-key";

}
