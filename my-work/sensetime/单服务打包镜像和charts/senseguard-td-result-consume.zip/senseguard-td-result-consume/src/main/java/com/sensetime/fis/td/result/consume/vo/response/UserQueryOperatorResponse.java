package com.sensetime.fis.td.result.consume.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author lizhengguang_vendor
 * @date 2019-1-22 17:08:01
 */
@Data
@ApiModel
public class UserQueryOperatorResponse {

    @ApiModelProperty(value = "用户Id")
    private int userId;

    @ApiModelProperty(value = "用户名")
    private String username;

    @ApiModelProperty(value = "真实姓名")
    private String realName;

    @ApiModelProperty(value = "部门id")
    private int orgId;

    @ApiModelProperty(value = "部门名称")
    private String orgName;

    @ApiModelProperty(value = "手机号")
    private String telephone;
}
