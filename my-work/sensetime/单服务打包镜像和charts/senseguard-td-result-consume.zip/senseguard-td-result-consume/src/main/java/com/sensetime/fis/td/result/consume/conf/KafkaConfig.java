package com.sensetime.fis.td.result.consume.conf;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka configuration.
 *
 * @author lizhengguang_vendor
 * @date 2019-1-3 16:40:28
 */
@Configuration
@EnableKafka
public class KafkaConfig {

    @Value(value = "${kafka.group-id-config}")
    private String groupIdConfig;

    @Value(value = "${kafka.bootstrap-servers-config}")
    private String bootstrapServersConfig;

    @Value(value = "${kafka.enable-auto-commit-config}")
    private String enableAutoCommitConfig;

    @Value(value = "${kafka.auto-commit-interval-ms-config}")
    private String autoCommitIntervalMsConfig;

    @Value(value = "${kafka.session-timeout-ms-config}")
    private String sessionTimeoutMsConfig;

    @Value(value = "${kafka.key-deserializer-class-config}")
    private String keyDeserializerClassConfig;

    @Value(value = "${kafka.value-deserializer-class-config}")
    private String valueDeserializerClassConfig;

    @Value(value = "${kafka.max-pool-records-config:50}")
    private String maxPoolRecordsConfig;

    private Logger logger = LoggerFactory.getLogger(KafkaConfig.class);

    /**
     * ConcurrentKafkaListenerContainerFactory
     */
    @Bean
    ConcurrentKafkaListenerContainerFactory<Integer, String> kafkaListenerContainerFactory() {
        logger.info("ConcurrentKafkaListenerContainerFactory isOK!");
        ConcurrentKafkaListenerContainerFactory factory = new ConcurrentKafkaListenerContainerFactory();
        factory.setConsumerFactory(consumeFactory());
        factory.setConcurrency(3);
        factory.getContainerProperties().setPollTimeout(3000);
        return factory;
    }

    /**
     * ConsumerFactory
     */
    @Bean
    public ConsumerFactory<Integer, String> consumeFactory() {
        logger.info("ConsumerFactory isOK!");
        return new DefaultKafkaConsumerFactory<>(consumeConfigs());
    }

    /**
     * consumeConfigs
     */
    @Bean
    public Map<String, Object> consumeConfigs() {
        Map<String, Object> props = new HashMap<>(16);
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServersConfig);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupIdConfig);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, enableAutoCommitConfig);
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, autoCommitIntervalMsConfig);
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeoutMsConfig);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, keyDeserializerClassConfig);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, valueDeserializerClassConfig);
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxPoolRecordsConfig);
        return props;
    }
}
