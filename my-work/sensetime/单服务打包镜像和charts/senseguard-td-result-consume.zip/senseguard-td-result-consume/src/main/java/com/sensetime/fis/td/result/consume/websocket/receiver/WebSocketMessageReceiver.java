package com.sensetime.fis.td.result.consume.websocket.receiver;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sensetime.fis.common.core.utils.AESUtil;
import com.sensetime.fis.result.consume.common.entity.*;
import com.sensetime.fis.result.consume.common.mapper.SystemSettingsMapper;
import com.sensetime.fis.result.consume.common.mapper.TaskMapper;
import com.sensetime.fis.result.consume.common.module.*;
import com.sensetime.fis.td.result.consume.constant.Constants;
import com.sensetime.fis.td.result.consume.service.UserService;
import com.sensetime.fis.td.result.consume.vo.UserDeviceVo;
import com.sensetime.fis.td.result.consume.vo.response.GreetGuestsResponse;
import com.sensetime.fis.td.result.consume.websocket.entity.PushConditionInfo;
import com.sensetime.fis.td.result.consume.websocket.utils.ResultKeyUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * MessageReceiver
 *
 * @author lizhengguang_vendor
 * @date 2019-1-15 17:47:20
 */
@Slf4j
@Service
public class WebSocketMessageReceiver {

    @Value("${websocket.destination}")
    private String destination;
    @Resource
    private TaskMapper taskMapper;
    @Autowired
    private UserService userService;
    @Autowired
    private StringRedisTemplate redisTemplate;
    @Autowired
    private SimpMessagingTemplate messagingTemplate;
    @Autowired
    private SystemSettingsMapper systemSettingsMapper;

    private Gson gson = new Gson();
    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 消息处理方法，推送消息到WebSocket
     */
    public void receiveMessage(String message) throws IOException {
        long receiveTime = System.currentTimeMillis();
        log.debug("receive message：{}", message);

        HistoryInfo historyInfo = objectMapper.readValue(message, HistoryInfo.class);
        DeviceInfo deviceInfo = historyInfo.getDeviceInfo();
        if (deviceInfo == null || deviceInfo.getDevice() == null || null == deviceInfo.getDevice().getDeviceId()) {
            log.error("HistoryInfo设备记录不存在：{}", historyInfo);
            return;
        }

        Device device = deviceInfo.getDevice();
        Long deviceId = device.getDeviceId();

        TaskInfo taskInfo = historyInfo.getTaskInfo();
        if (taskInfo == null || null == taskInfo.getTask()) {
            log.error("当前消息推送失败，失败原因{}", "taskInfo为空>>>>>>>>>>>");
            return;
        }

        /** 根据deviceId获取在线大的用户token */
        UserDeviceVo userDeviceVo = userService.getOnlineUsersByDeviceId(deviceId);
        if (userDeviceVo == null || CollectionUtils.isEmpty(userDeviceVo.getUserIds())) {
            log.error("当前消息推送失败，失败原因{}", "获取在线用户信息失败>>>>>>>>>>>");
            return;
        }
        log.debug("在线用户信息：{}", userDeviceVo.getUserIds());
        List<Long> userIds = userDeviceVo.getUserIds();

        /** 获取到所有在线的websocket客户端sessionId */
        Set<String> keys = redisTemplate.keys(ResultKeyUtils.SENSETIME_RESULT_CONSUME_TD_WEBSOCKET);

        log.debug("current userIds: {}", gson.toJson(userIds), "current keys: {}", gson.toJson(keys));

        //判断该条消息是否是 迎宾消息
        Task task = taskInfo.getTask();
        Long taskId = task.getTaskId();
        Long libraryId = -1L;
        if (null != historyInfo.getTargetInfo() && null != historyInfo.getTargetInfo().getLibrary()) {
            libraryId = historyInfo.getTargetInfo().getLibrary().getLibraryId();
        }
        List<WelcomeRemarks> welcomeRemarksList = taskMapper.selectByTaskIdToInfoWelcome(taskId);

        /**
         * 比中分数
         *
         */
        DetectInfo detectInfo = historyInfo.getDetectInfo();
        Float score = (detectInfo == null || null == detectInfo.getScore()) ? 0f : detectInfo.getScore();
        boolean isWelcome = false;
        GreetGuestsResponse greetGuestsResponse = new GreetGuestsResponse();
        if (welcomeRemarksList != null && !welcomeRemarksList.isEmpty()) {
            log.debug("迎宾接收到的关键数据：taskId： {} libraryId: {}", taskId, libraryId);
            /**
             * 查询 规则阈值
             */
            Task dbTask = taskMapper.selectByPlatformTaskId(task.getPlatformTaskId());
            if (dbTask != null) {
                /**
                 * 在根据libraryId 为消息赋 欢迎语及背景图
                 */
                for (WelcomeRemarks welcomeRemarks : welcomeRemarksList) {
                    if (welcomeRemarks.getLibraryId().equals(libraryId) && score >= dbTask.getThreshold()) {
                        historyInfo.setWelcome(true);
                        isWelcome = true;
                        historyInfo.setWelcomeRemarks(welcomeRemarks);
                        //迎宾实际到访计数
                        actualCount(dbTask, historyInfo.getTargetInfo().getTarget().getTargetId(), greetGuestsResponse);
                    }
                }

            }


        }
        //end
        /** 转换WebSocket结果 */
        String pushMessage;
        if (isWelcome) {
            pushMessage = objectMapper.writeValueAsString(pushResult(historyInfo, greetGuestsResponse));
        } else {
            pushMessage = objectMapper.writeValueAsString(pushResult(historyInfo));
        }

        log.debug("Json pushMessage: {}", pushMessage);

        if (null == keys || keys.isEmpty()) {
            log.error("获取到所有在线的websocket客户端sessionId列表为空.结束业务处理...");
        } else {

            for (String key : keys) {
                String pushInfoJson = redisTemplate.opsForValue().get(key);
                PushConditionInfo pushConditionInfo =
                        objectMapper.readValue(pushInfoJson, PushConditionInfo.class);
                Long userId = pushConditionInfo.getUserId();
                List<Long> deviceIds = pushConditionInfo.getDeviceIds();
                List<Long> taskIds = pushConditionInfo.getTaskIds();
                Long ruleId = pushConditionInfo.getRuleId();
                List<Integer> compareTypes = pushConditionInfo.getCompareTypes();

                /** 开始过滤推送消息，是否满足推送条件 */
                int comparedType = historyInfo.getComparedType();
                if (StringUtils.isEmpty(comparedType + "")) {
                    log.error("当前消息推送失败，失败原因:记录对比类型不能为空>>>>>>>>>>>");
                    return;
                }
                /** 1.对比类型过滤 */
                if (!CollectionUtils.isEmpty(compareTypes) && !compareTypes.contains(comparedType)) {
                    continue;
                }
                /** 2.任务过滤 */
                if (!CollectionUtils.isEmpty(taskIds) && !taskIds.contains(taskId)) {
                    continue;
                }
                /** 3.迎宾任务过滤 */
                if (ruleId != null && !ruleId.equals(taskId)) {
                    continue;
                }
                /** 4.设备过滤 */
                if (!CollectionUtils.isEmpty(deviceIds)) {
                    for (Long id : deviceIds) {
                        if (id.equals(deviceId)) {
                            pushMessage(pushMessage, userIds, key, userId);
                        }
                    }
                } else {
                    pushMessage(pushMessage, userIds, key, userId);
                }
            }
        }

        log.info("redis channel received message and push message to websocket, cost {}ms", System.currentTimeMillis() - receiveTime);
    }

    /**
     * 这是为了迎宾实时监控实际到访人数做了一步封装
     *
     * @param historyInfo
     * @param greetGuestsResponse
     * @return
     */
    private Map<Object, Object> pushResult(HistoryInfo historyInfo, GreetGuestsResponse greetGuestsResponse) {
        Map<Object, Object> objectObjectMap = pushResult(historyInfo);
        objectObjectMap.put("greetGuestsInfo", greetGuestsResponse);
        return objectObjectMap;
    }

    private GreetGuestsResponse actualCount(Task dbTask, String targetId, GreetGuestsResponse greetGuestsResponse) {

        String key = "SenseTime:SenseGuard:TdResultConsume:GreetGuests_" + dbTask.getTaskId() + "_" + dbTask.getPlatformTaskId() + "_" + targetId;
        String totalKey = "SenseTime:SenseGuard:TdResultConsume:GreetGuests_" + dbTask.getTaskId() + "_" + dbTask.getPlatformTaskId();

        //将增加当前迎宾得访问次数
        long visitTimes = redisTemplate.boundValueOps(key).increment(1);
        long actualVisitor = 0L;
        //统计当前实际到访得迎宾人数
        if (visitTimes == 1) {
            actualVisitor = redisTemplate.boundValueOps(totalKey).increment(1);
        } else {
            actualVisitor = Long.valueOf(redisTemplate.opsForValue().get(totalKey));
        }

        greetGuestsResponse.setActualVisitor(actualVisitor);
        greetGuestsResponse.setVisitTimes(visitTimes);

        return greetGuestsResponse;
    }

    /**
     * 打包webSocket推送结果
     *
     * @param historyInfo
     * @return
     */
    private Map<Object, Object> pushResult(HistoryInfo historyInfo) {

        if (null == historyInfo) {
            return null;
        }
        DetectInfo detectInfo = historyInfo.getDetectInfo();
        FaceInfo faceInfo = detectInfo.getFaceInfo();
        TargetInfo targetInfo = historyInfo.getTargetInfo();
        Device device = historyInfo.getDeviceInfo().getDevice();
        // 楼层id
        Long floorId = device.getFloorId();
        // 比对分数
        Float score = detectInfo.getScore();
        // 设备id
        Long deviceId = device.getDeviceId();
        // 设备名称
        String deviceName = device.getDeviceName();
        // 记录序号
        String serialNumber = historyInfo.getSerialNumber();
        // 抓拍类型
        int comparedType = historyInfo.getComparedType();
        // 抓拍时间
        String captureDate = detectInfo.getCaptureDate();

        String preCaptureDate = detectInfo.getPreCaptureDate();
        // 抓拍大图
        String imageUrl = detectInfo.getImage().getUrl();
        // 抓拍图
        String url = faceInfo.getPortraitImageInfo().getUrl();

        // 记录确认信息
        ConfirmationInfo confirmationInfo = historyInfo.getConfirmationInfo();
        // 记录确认状态
        int confirmationStatus = confirmationInfo.getConfirmationStatus();
        String name = "";
        String identity = "";
        String cipherText = "";
        String picUrl = "";
        String targetId = "";
        String libraryName = "";
        if (targetInfo != null) {
            Target target = targetInfo.getTarget();
            // 人员姓名
            name = target.getName();
            // 人员ID
            identity = target.getIdentity();
            // identity进行脱敏处理
            if (StringUtils.isNotEmpty(identity)) {
                cipherText = identity;
                identity = aesDecryptIdentity(identity);
            }
            // 人像底图
            picUrl = targetInfo.getTargetImage().getPicUrl();
            targetId = target.getTargetId();
            Library library = targetInfo.getLibrary();
            libraryName = library.getName();
        }

        Map<Object, Object> result = new HashMap<>(16);
        Map<Object, Object> record = new HashMap<>(16);

        /**
         * 迎宾信息
         */
        WelcomeRemarks welcomeRemarks = historyInfo.getWelcomeRemarks();
        if (welcomeRemarks != null) {
            result.put("welcome", true);
            result.put("welcomeRemarks", welcomeRemarks);
        }

        record.put("name", name);
        record.put("floorId", floorId);
        record.put("score", score);
        record.put("deviceId", deviceId);
        record.put("deviceName", deviceName);
        record.put("identity", identity);
        record.put("cipherText", cipherText);
        record.put("serialNumber", serialNumber);
        record.put("comparedType", comparedType);
        record.put("captureDate", captureDate);
        record.put("imageUrl", imageUrl);
        record.put("url", url);
        record.put("picUrl", picUrl);
        record.put("confirmationStatus", confirmationStatus);

        // 设置跟踪状态
        TrackEventInfo trackEvent = historyInfo.getTrackEvent();
        record.put("eventNum", trackEvent.getEventNum());
        record.put("eventDescriptor", trackEvent.getDescriptor());
        result.put("record", record);

        Map<String, Object> recordDetail = new HashMap<>(16);

        // 抓拍大图
        Map<String, Object> bigPicture = new HashMap<>(16);
        ImageInfo image = detectInfo.getImage();
        Integer height = image.getHeight();
        Integer width = image.getWidth();

        bigPicture.put("height", height);
        bigPicture.put("width", width);
        bigPicture.put("imgUrl", imageUrl);

        // 抓拍小图
        PortraitImageInfo portraitImageInfo = faceInfo.getPortraitImageInfo();
        VertexInfo start = portraitImageInfo.getStart();
        VertexInfo end = portraitImageInfo.getEnd();

        // 人脸坐标
        Map<String, Object> portraitImageCoordinateInfo = new HashMap<>(16);
        portraitImageCoordinateInfo.put("startX", start.getX());
        portraitImageCoordinateInfo.put("startY", start.getY());
        portraitImageCoordinateInfo.put("endX", end.getX());
        portraitImageCoordinateInfo.put("endY", end.getY());
        bigPicture.put("portraitImageCoordinateInfo", portraitImageCoordinateInfo);
        recordDetail.put("bigPicture", bigPicture);

        // 对比结果描述
        String description = historyInfo.getDescription();
        recordDetail.put("captureDate", captureDate);
        recordDetail.put("preCaptureDate", preCaptureDate);

        recordDetail.put("compareType", String.valueOf(comparedType));
        recordDetail.put("confirmationStatus", confirmationStatus);
        recordDetail.put("description", description);

        // 地图url
        String mapUrl = device.getUrl();
        Map<String, Object> devicePlaceInfo = new HashMap<>(16);
        devicePlaceInfo.put("id", deviceId);
        devicePlaceInfo.put("url", mapUrl);
        devicePlaceInfo.put("name", deviceName);
        devicePlaceInfo.put("floorId", floorId);
        devicePlaceInfo.put("deviceCode", device.getDeviceCode());

        // 设备点位
        String point = device.getPoint();
        if (StringUtils.isNotBlank(point) && point.length() > 1) {

            String positionArray = point.substring(1, point.length() - 1);
            String[] split = positionArray.split(",");
            if (split.length > 1) {

                Map<String, Object> position = new HashMap<>();
                position.put("lng", split[0]);
                position.put("lat", split[1]);
                devicePlaceInfo.put("position", position);
            }
        }

        // 操作人名称
        OperatorInfo operatorInfo = confirmationInfo.getOperatorInfo();
        String operatorName = (operatorInfo == null) ? "" : operatorInfo.getName();

        recordDetail.put("devicePlaceInfo", devicePlaceInfo);
        recordDetail.put("id", identity);
        recordDetail.put("operatorName", operatorName);
        recordDetail.put("picUrl", picUrl);
        recordDetail.put("place", deviceName);

        // 任务
        TaskInfo taskInfo = historyInfo.getTaskInfo();
        Long taskId = (null == taskInfo.getTask()) ? null : taskInfo.getTask().getTaskId();
        String taskName = (null == taskInfo.getTask()) ? null : taskInfo.getTask().getTaskName();

        //任务ID推送给前端
        recordDetail.put("taskId", taskId);
        recordDetail.put("taskName", taskName);
        recordDetail.put("score", score);
        recordDetail.put("serialNumber", serialNumber);

        // 人像id
        recordDetail.put("targetId", targetId);
        recordDetail.put("targetLibraryName", libraryName);
        recordDetail.put("url", url);
        recordDetail.put("userName", name);
        // 跟踪trackId
        recordDetail.put("trackId", faceInfo.getTrackId());
        recordDetail.put("objectId", historyInfo.getObjectId());
        // 人脸属性faceAttribute
        Map<String, String> attribute = faceInfo.getAttribute();
        Map<String, Object> faceAttribute = new HashMap<>(16);
        //    性别
        faceAttribute.put("gender", attributeValue(attribute, "gender_code"));
        //    年龄分类
        String stAge = attributeValue(attribute, "st_age");
        String substring = stAge.length() == 0 ? "" : stAge.substring(stAge.indexOf("_") + 1);
        faceAttribute.put("age", substring);
        //    年龄
        faceAttribute.put("ageValue", attributeValue(attribute, "st_age_value"));

        //v1.5.0 去掉藏疆、帽子、肤色属性
        //    肤色
        //faceAttribute.put("skinColor", attributeValue(attribute, "skin_color"));
        //    帽子
        //faceAttribute.put("capStyle", attributeValue(attribute, "cap_style"));
        //    胡子
        faceAttribute.put("mustacheStyle", attributeValue(attribute, "mustache_style"));
        //    口罩颜色
        faceAttribute.put("respiratorColor", attributeValue(attribute, "respirator_color"));
        // 安全帽
        faceAttribute.put("helmetStyle", attributeValue(attribute, "st_helmet_style"));
        //    眼镜
        faceAttribute.put("glassesStyle", attributeValue(attribute, "glass_style"));
        //    疆藏
        //faceAttribute.put("ethicCode", attributeValue(attribute, "ethic_code"));
        //    表情
        faceAttribute.put("expression", attributeValue(attribute, "st_expression"));
        recordDetail.put("faceAttributeInfo", faceAttribute);


        result.put("recordDetail", recordDetail);
        return result;
    }

    /**
     * 获取属性值
     *
     * @param attribute
     * @param key
     * @return
     */
    private String attributeValue(Map<String, String> attribute, String key) {
        boolean isEmpty = isEmpty(attribute);
        if (isEmpty) {
            return "";
        }
        String value = attribute.get(key);
        if (value == null || value.length() < 0) {
            return "";
        }
        return value;
    }

    /**
     * 判断属性是否为空
     *
     * @param attribute
     * @return
     */
    private boolean isEmpty(Map<String, String> attribute) {
        return attribute == null || attribute.size() <= 0;
    }

    /**
     * 推送消息
     *
     * @param message
     * @param userIds
     * @param key
     * @param userId
     */
    private void pushMessage(String message, List<Long> userIds, String key, Long userId) {
        for (Long uid : userIds) {
            /** 在线用户有当前设备，推送记录 */
            if (uid.equals(userId)) {
                /** 获取WebSocket SessionId */
                String sessionId = key.split("-")[1];
                /** 客户端订阅地址/td-result/123456/topic */
                String destination = "/queue/" + sessionId;
                log.debug("Current push address：" + destination);
                messagingTemplate.convertAndSend(destination, message);
            }
        }
    }

    /**
     * Identity字段进行解密并进行脱敏处理
     *
     * @param secret 脱敏数据(例: 310*********234)
     * @return
     */
    private String aesDecryptIdentity(String secret) {
        SystemSettings systemSettings = systemSettingsMapper.selectByCode(Constants.AES_KEY_CODE);
        if (systemSettings == null) {
            log.error("DB未配置AES-KEY");
            return secret;
        }

        String decryptIdentity = AESUtil.decrypt(secret, systemSettings.getValue());
        if (decryptIdentity == null) {
            log.error("AES解密异常");
            return secret;
        }

        return AESUtil.processPlaintext(decryptIdentity);
    }

}
