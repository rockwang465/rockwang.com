package com.sensetime.fis.td.result.consume.service;

import com.sensetime.fis.result.consume.common.module.DeviceInfo;

/**
 * DeviceInfoService
 *
 * @author lizhengguang_vendor
 * @date 2019-1-14 13:35:32
 */
public interface DeviceInfoService {

    /**
     * 获得deviceInfo
     *
     * @param cameraIdx 区域中的相机ID
     * @param regionId  区域ID
     * @return
     */
    DeviceInfo getDeviceInfo(int cameraIdx, int regionId);
}
