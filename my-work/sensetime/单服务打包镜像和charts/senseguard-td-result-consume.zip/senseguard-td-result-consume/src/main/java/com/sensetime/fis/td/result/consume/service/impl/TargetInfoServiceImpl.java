package com.sensetime.fis.td.result.consume.service.impl;

import com.sensetime.fis.result.consume.common.entity.*;
import com.sensetime.fis.result.consume.common.mapper.*;
import com.sensetime.fis.result.consume.common.module.TargetInfo;
import com.sensetime.fis.td.result.consume.service.TargetInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * TargetInfoServiceImpl
 *
 * @author lizhengguang_vendor
 * @date 2019-1-14 13:38:55
 */
@Service
public class TargetInfoServiceImpl implements TargetInfoService {

    @Value("${osg-images.imagePrefix}")
    private String imagePrefix;

    @Value("${osg-images.watchlistFaceBucketName}")
    private String watchlistFaceBucketName;

    @Autowired
    private TargetMapper targetMapper;
    @Autowired
    private LibraryMapper libraryMapper;
    @Autowired
    private TargetImageMapper targetImageMapper;
    @Autowired
    private SystemSettingsMapper systemSettingsMapper;
    @Autowired
    private RelationTargetLibraryMapper relationTargetLibraryMapper;

    private Logger logger = LoggerFactory.getLogger(TargetInfoServiceImpl.class);

    /**
     * 获取人像信息
     *
     * @param featureId 特征id
     * @return
     */
    @Override
    public TargetInfo getTargetInfo(String featureId) {
        RelationTargetLibrary targetLibrary = relationTargetLibraryMapper.selectByFeatureId(featureId);
        if (targetLibrary == null) {
            logger.info("根据featureId={}没有查询到人像相关的信息", featureId);
            return null;
        }
        Target target = targetMapper.selectByPrimaryKey(targetLibrary.getTargetId());
        Library library = libraryMapper.selectByPrimaryKey(targetLibrary.getLibraryId());
        TargetImage targetImage = targetImageMapper.selectByTargetId(targetLibrary.getTargetId());
        /** 设置图片url */
        SystemSettings systemSettings = systemSettingsMapper.selectByCode(watchlistFaceBucketName);
        String watchlistFace = systemSettings.getValue();
        String picUrl = imagePrefix + watchlistFace + "/" + targetImage.getPicUrl();
        targetImage.setPicUrl(picUrl);

        TargetInfo targetInfo = new TargetInfo();
        targetInfo.setTargetImage(targetImage);
        targetInfo.setLibrary(library);
        targetInfo.setTarget(target);
        return targetInfo;
    }
}
