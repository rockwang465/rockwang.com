package com.sensetime.fis.td.result.consume.service;

/**
 * @author liqitian.
 * @program senseguard-device-management
 * @description
 * @create 2019-08-27 11:00
 **/
public interface DataPushService {
    /**
     * 推送数据到kafka
     *
     * @param historyInfo
     */
    void sentToKafka(String historyInfo);
}
