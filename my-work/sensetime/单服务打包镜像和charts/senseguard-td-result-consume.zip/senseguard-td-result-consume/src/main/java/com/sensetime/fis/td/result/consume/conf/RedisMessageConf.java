package com.sensetime.fis.td.result.consume.conf;

import com.sensetime.fis.td.result.consume.websocket.receiver.WebSocketMessageReceiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author lizhengguang_vendor
 * @date 2019-1-30 17:15:12
 */
@Configuration
public class RedisMessageConf {

    @Value("${redis.channel}")
    private String channel;

    @Autowired
    private WebSocketMessageReceiver webSocketMessageReceiver;
    @Autowired
    private LettuceConnectionFactory lettuceConnectionFactory;

    private Logger logger = LoggerFactory.getLogger(RedisMessageConf.class);

    /**
     * redisMessageListenerContainer
     *
     * @return
     */
    @Bean
    RedisMessageListenerContainer redisMessageListenerContainer() {
        RedisMessageListenerContainer messageListenerContainer = new RedisMessageListenerContainer();
        messageListenerContainer.setConnectionFactory(lettuceConnectionFactory);
        messageListenerContainer.addMessageListener(listenerAdapter(), new PatternTopic(channel));
        messageListenerContainer.setTaskExecutor(redisMessageListenerTaskExecutor());
        return messageListenerContainer;
    }

    /**
     * 消息监听器适配器，绑定消息处理器，利用反射技术调用消息处理器的业务方法
     *
     * @return MessageListenerAdapter
     */
    @Bean
    public MessageListenerAdapter listenerAdapter() {
        logger.info("MessageListenerAdapter isOK!");
        return new MessageListenerAdapter(webSocketMessageReceiver, "receiveMessage");
    }

    /**
     * 自定义RedisMessageListenerContainer TaskExecutor
     *
     * @return Executor
     */
    @Bean("redisMessageListenerTaskExecutor")
    public Executor redisMessageListenerTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(20);
        executor.setQueueCapacity(1024);
        executor.setKeepAliveSeconds(60);
        executor.setThreadNamePrefix("customRedisMessageListenerTaskExecutor-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        return executor;
    }

}
