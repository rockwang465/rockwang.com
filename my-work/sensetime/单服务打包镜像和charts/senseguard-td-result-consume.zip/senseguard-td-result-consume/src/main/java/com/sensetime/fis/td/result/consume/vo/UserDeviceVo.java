package com.sensetime.fis.td.result.consume.vo;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * UserDeviceVo
 *
 * @author lizhengguang_vendor
 * @date 2019-1-17 21:30:44
 */
@Data
@ApiModel
public class UserDeviceVo {
    private List<Long> userIds;
}
