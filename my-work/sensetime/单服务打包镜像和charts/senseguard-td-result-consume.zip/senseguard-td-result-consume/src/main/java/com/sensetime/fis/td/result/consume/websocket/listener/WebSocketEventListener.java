package com.sensetime.fis.td.result.consume.websocket.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sensetime.fis.common.core.utils.JsonUtil;
import com.sensetime.fis.td.result.consume.websocket.entity.PushConditionInfo;
import com.sensetime.fis.td.result.consume.websocket.utils.ResultKeyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.sensetime.fis.td.result.consume.websocket.utils.ResultKeyUtils.REDIS_EXPIRE_TIME_ONE_DAY;

/**
 * WebSocketEventListener监听器，监听链接的建立和断开。用于推送和清理推送筛选条件
 *
 * @author lizhengguang_vendor
 * @date 2019-1-17 20:35:24
 */
@Component
public class WebSocketEventListener {

    @Autowired
    private StringRedisTemplate redisTemplate;
    private Logger logger = LoggerFactory.getLogger(WebSocketEventListener.class);

    /**
     * 从连接中获取到用户token和浏览器sessionId保存到redis
     */
    @EventListener
    public void sessionConnectedEvent(SessionConnectEvent sessionConnectEvent)
            throws JsonProcessingException {
        MessageHeaders headers = sessionConnectEvent.getMessage().getHeaders();
        Object simpSessionId = headers.get("simpSessionId");
        Object nativeHeader = headers.get("nativeHeaders");

        if (null == nativeHeader) {
            logger.error("获取用户nativeHeader失败，当前的sessionId={}", simpSessionId);
            return;
        }
        Map<String, LinkedList<String>> nativeHeaders = (Map<String, LinkedList<String>>) nativeHeader;
        LinkedList<String> tokenList = nativeHeaders.get("userId");
        if (nativeHeaders.size() == 0 || tokenList == null || tokenList.size() == 0) {
            logger.error("获取用户userId失败，当前的sessionId={}", simpSessionId);
            // 后面操作不再执行
            return;
        }

        /** nativeHeaders 链表结构获取第一个值 */
        logger.info("tokenList:{}", JsonUtil.toJsonString(tokenList));
        Long userId = Long.valueOf(tokenList.get(0));
        logger.info("userId:{}", userId);
        PushConditionInfo pushConditionInfo = new PushConditionInfo();
        pushConditionInfo.setUserId(userId);
        ObjectMapper objectMapper = new ObjectMapper();
        String pushInfoJson = objectMapper.writeValueAsString(pushConditionInfo);

        logger.info("userId:{},simpSessionId:{}", userId, simpSessionId);
        /** 保存accessToken到redis */
        String key = ResultKeyUtils.SENSETIME_RESULT_CONSUME_TD_WEBSOCKET_PREFIX + simpSessionId;
        redisTemplate.opsForValue().set(key, pushInfoJson, REDIS_EXPIRE_TIME_ONE_DAY, TimeUnit.SECONDS);
    }

    /**
     * 客户端关闭时，获取浏览器sessionId用于清除redis缓存的token信息
     */
    @EventListener
    public void sessionDisconnectEvent(SessionDisconnectEvent sessionDisconnectEvent) {
        String sessionId = sessionDisconnectEvent.getSessionId();
        /** 关闭连接删除key */
        String key = ResultKeyUtils.SENSETIME_RESULT_CONSUME_TD_WEBSOCKET_PREFIX + sessionId;
        redisTemplate.delete(key);
        logger.info("当前连接已关闭，sessionId={}", sessionId);
    }
}
