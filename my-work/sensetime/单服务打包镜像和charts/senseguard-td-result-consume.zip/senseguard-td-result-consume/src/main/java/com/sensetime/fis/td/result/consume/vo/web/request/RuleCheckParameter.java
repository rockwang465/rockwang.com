package com.sensetime.fis.td.result.consume.vo.web.request;

import com.sensetime.fis.td.result.consume.vo.web.result.RuleResult;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 规则校验参数
 *
 * @author lizhengguang_vendor 2018-12-28 13:47:43
 */
@Data
@ApiModel
public class RuleCheckParameter {
    @ApiModelProperty(value = "任务Id", required = true)
    private String taskId;

    @ApiModelProperty(value = "任务类型，默认为AC任务type=0，type=1时为td任务")
    private int type;

    @ApiModelProperty(value = "处理时间", required = true, allowEmptyValue = true)
    private String captureTime;

    @ApiModelProperty(value = "处理结果", required = true, allowEmptyValue = true)
    private List<RuleResult> results;
}
