package com.sensetime.fis.td.result.consume.service.impl;

import com.sensetime.fis.common.base.entity.websocket.PushMessageData;
import com.sensetime.fis.common.base.enums.MessageSourceEnum;
import com.sensetime.fis.common.base.enums.PushMessageTypeEnum;
import com.sensetime.fis.common.core.utils.JsonUtil;
import com.sensetime.fis.td.result.consume.service.DataPushService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * @program: senseguard-device-management
 * @description:
 * @author: liqitian.
 * @create: 2019-08-27 11:01
 **/
@Service
@Slf4j
public class DataPushServiceImpl implements DataPushService {

    @Autowired
    private KafkaTemplate kafkaTemplate;

    @Autowired
    RestTemplate restTemplate;

    @Value("${kafka.td.product.topic-name}")
    private String topicName;

    @Override
    @Async
    public void sentToKafka(String historyInfo) {

        try {
            PushMessageData data = new PushMessageData(PushMessageTypeEnum.FACE, MessageSourceEnum.TD, historyInfo);
            kafkaTemplate.send(topicName, JsonUtil.toJsonString(data));
        } catch (Exception e) {
            log.error("sent to kafka error...e:{}", e.getMessage());
        }

    }

}
