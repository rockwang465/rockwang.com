package com.sensetime.fis.td.result.consume.service.impl;

import com.sensetime.fis.result.consume.common.entity.UserDevice;
import com.sensetime.fis.result.consume.common.mapper.UserDeviceMapper;
import com.sensetime.fis.result.consume.common.mapper.UserTokenMapper;
import com.sensetime.fis.td.result.consume.service.UserService;
import com.sensetime.fis.td.result.consume.vo.UserDeviceVo;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 用户管理Service
 *
 * @author lizhengguang_vendor
 * @date 2019-1-16 11:34:19
 */
@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserDeviceMapper userDeviceMapper;
    @Resource
    private UserTokenMapper userTokenMapper;


    @Override
    public UserDeviceVo getOnlineUsersByDeviceId(Long deviceId) {
        Set<Long> userIds = new HashSet<>(16);
        UserDevice userDevice = new UserDevice();
        userDevice.setDeviceId(deviceId);
        List<UserDevice> userDevices = userDeviceMapper.selectList(userDevice);
        if (!CollectionUtils.isEmpty(userDevices)) {
            userDevices.stream().forEach(ud -> {
                userIds.add(ud.getUserId());
            });
        }
        // 添加在线管理员的token
        addAdminTokens(userIds);

        UserDeviceVo userDeviceVo = new UserDeviceVo();
        userDeviceVo.setUserIds(new ArrayList<>(userIds));

        return userDeviceVo;
    }

    /**
     * 添加在线管理员的Token
     *
     * @param userIds
     */
    private void addAdminTokens(Set<Long> userIds) {
        List<Long> adminIds = this.userTokenMapper.selectUserIdByDefaultRole();
        userIds.addAll(adminIds);
    }

}
