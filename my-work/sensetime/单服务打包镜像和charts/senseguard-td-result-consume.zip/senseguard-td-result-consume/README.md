# senseguard-td-result-consume 

## 模块描述

### 读取tailing-detction-comparison-worker-service模块写入的kafka消息，从数据库查询相关数据，并调用senseguard-lib-auth模块rule_check接口获取比对结果，将处理后的结果存储到elasticsearch .



## 相关类图

### 1.com.sensetime.fis.td.result.consume.service

![](doc/images/KafkaMessageReceive.png)

### 2.com.sensetime.fis.td.result.consume.websocket

![](doc/images/websocket.png)



## 模块依赖

![](doc/images/td-module-dependencies1.jpg)


## 流程图

![](doc/images/td-flow.jpg)
