//var host = "http://10.151.3.81"
// var host = "http://10.151.3.73"
var host = ""

var hostName = window.location.host;
var protocolStr = window.location.protocol;
var wsProtocol = 'wss://';
if(protocolStr == "http:"){
  wsProtocol = 'ws://';
}
if(protocolStr == "https:"){
  wsProtocol = 'wss://';
}

window.globalConfig={
  host            :host,
  map             :host + "/senseguard-map-management/api/v1",
  dashboard       :host + "/senseguard-dashboard/api/v1/dashboard",
  heatMap         :host + "/senseguard-lbs/api/v1",
  timezoneHost    :host + '/senseguard-timezone-management',
  deviceHost      :host + '/senseguard-device-management',
  acHost          :host + '/senseguard-rule-management',
  login           :host + "/senseguard-oauth2/api/v1",
  role            :host + "/senseguard-uums/api/v1",
  log             :host + "/senseguard-log/api/v1",
  user            :host + "/senseguard-uums/api/v1",
  portrait        :host + "/senseguard-watchlist-management/api/v1",
  portraitExport  :host + "/senseguard-target-export/api/v1",
  portraitUpdate  :host + "/senseguard-bulk-tool/api/v1",
  device          :host + "/senseguard-device-management/api/v1",
  visitor         :host + "/senseguard-guest-management/api/v1",
  visitorWS       :host + "/senseguard-guest-management",
  history         :host + "/senseguard-face-search/api/v1", //wangpan liyuyuan
  record          :host + "/senseguard-records-management/api/v1", //wangpan lihui
  tdConsume       :host + "/senseguard-td-result-consume/api/v1", //wangpan lihui
  // messageCenter   :"http://10.11.197.127:8080" + "/senseguard-message-center/websocket/", //wangpan liyuyuan
  historyExport   :host + "/senseguard-records-export/api/v1/records", //wangpan yongpeng
  download        :host+"/senseguard-message-center/api/v1/msgcenter/download", //wangpan yongpeng
  retryExport     :host+"/senseguard-message-center/api/v1/msgcenter/optTask", //wangpan yongpeng
  generateTrack   :host+"/senseguard-lbs/api/v1",
  toolHost        :host+"/senseguard-tools/api/v1/tools",
  messageCenter   :host+ "/senseguard-message-center/websocket/", //wangpan liyuyuan
  visitor         :host + "/senseguard-guest-management/api/v1", //visitor api
  attendance      :host + "/senseguard-attendance-management/api/v1", //visitor api
  frontendCompare :host + "/senseguard-frontend-comparison/v1",
  link            :host + "/senseguard-integrated-adapter/api/v1",
  streamedianHost :wsProtocol+hostName+'/rtsp-over-ws',
  tdwsHost:host,
  acwsHost:host,
  // streamedianHost:'wss://aurora.com/rtsp-over-ws',
  //monitor module default video frame or not
  monitorVideoFrame:false,
  acThreshold:0.85,
  wsAlarmListNum:50,
  dev_host:"https://localhost:8088",
  refreshTokenTime:5*60*1000,//ms
  isCheckPushFrequency:true,//是否开启推送过快优化
  alarmCheckFrequency:600,//ms 推送刷图频率
}
//接口路径 //协议：域名/api/版本/模块名/接口名/功能
//wss://localhost:8080/senseguard-message-center/websocket/967/0ol2vy3i/websocket?userId=104
