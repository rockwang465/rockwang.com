import i18n from "../src/lang/index";


export const passForm = {
  // deviceRunTypeList:[{value: 1, name: '运行'}, {value: 2, name: '停机'}],
  deviceRunTypeList:[{value: 1, name: i18n.t('devicemanagement.contOperation')}, {value: 2, name: i18n.t('devicemanagement.contHalt')}],
  // modeSelectionList:[{value: 1, name: '闸机模式'},{value: 2, name: '门禁模式'}],
  modeSelectionList:[{value: 1, name: i18n.t('devicemanagement.contBrakeMachine')},{value: 2, name: i18n.t('devicemanagement.contAccessControl')}],
  modeSelectionList2:[{value: 3, name: i18n.t('devicemanagement.contSolo')},{value: 4, name: i18n.t('devicemanagement.contMulti')}],
  // modeSelectionList2:[{value: 3, name: '单人模式'},{value: 4, name: '多人模式'}],
  checkPatternList:[{value: 9, name: i18n.t('devicemanagement.contHumanFace')},{value: 10, name: i18n.t('devicemanagement.contHumanFaceOrQrCodeOrSwipeCard')},{value: 2, name: i18n.t('devicemanagement.contHumanFaceAndSwipeCard')},{value: 11, name: i18n.t('devicemanagement.contSwipeIdCard')},{value: 3, name: i18n.t('devicemanagement.contHumanFaceOrSwipeIdCard')},{value: 4, name: i18n.t('devicemanagement.contHumanFaceAndSwipeIdCard')}],
  // checkPatternList:[{value: 9, name: '人脸'},{value: 10, name: '人脸或二维码或刷卡'},{value: 2, name: '刷脸且刷卡'},{value: 11, name: '刷身份证'},{value: 3, name: '刷脸或刷身份证'},{value: 4, name: '刷脸且刷身份证'}],
  checkPatternList2:[{value: 1, name: i18n.t('devicemanagement.contPassOptions')},{value: 2, name: i18n.t('devicemanagement.contHumanFaceAndSwipeCard')},{value: 9, name: i18n.t('devicemanagement.contHumanFace')},{value: 10, name: i18n.t('devicemanagement.contHumanFaceOrQrCodeOrSwipeCard')},],

  switchList:[{value: 1, name: i18n.t('devicemanagement.contOpen')},{value: 0, name: i18n.t('devicemanagement.contClose')}],//开关
  // switchList:[{value: 1, name: '开启'},{value: 0, name: '关闭'}],//开关
  showUserInfoList:[{value: 0, name: i18n.t('devicemanagement.contJobNumber')},{value: 1, name: i18n.t('devicemanagement.contDept')},{value: 2, name: i18n.t('devicemanagement.contJob')},{value: 3, name: i18n.t('devicemanagement.contIdNumber')},{value: 4, name: i18n.t('devicemanagement.contTips')}],//识别成功页额外展示字段
  // showUserInfoList:[{value: 0, name: '工号'},{value: 1, name: '部门'},{value: 2, name: '职位'},{value: 3, name: '身份证号'},{value: 4, name: '自定义提示语'}],//识别成功页额外展示字段
  openDoorTypeList:[{value: 0, name: i18n.t('devicemanagement.contLocalRelay')},{value: 4, name: i18n.t('devicemanagement.contNetRelay')},{value: 1, name: i18n.t('devicemanagement.contWiggins26')},{value: 2, name: i18n.t('devicemanagement.contWiggins32')},{value: 3, name: i18n.t('devicemanagement.contWiggins34')},{value: 5, name: i18n.t('devicemanagement.contWiggins262')}],//开门方式
  // openDoorTypeList:[{value: 0, name: '本地继电器'},{value: 4, name: '网络继电器'},{value: 1, name: '韦根26（24bit ID）'},{value: 2, name: '韦根32'},{value: 3, name: '韦根34'},{value: 5, name: '韦根26（8+164bit ID）'}],//开门方式
  gpioA:[{value: 1, name: i18n.t('devicemanagement.contWithout')},{value: 2, name: i18n.t('devicemanagement.contDoorbell')},{value: 3, name: i18n.t('devicemanagement.contSiren')}],
  // gpioA:[{value: 1, name: '无'},{value: 2, name: '门铃'},{value: 3, name: '报警器'}],
  gpioB:[{value: 1, name:i18n.t('devicemanagement.contWithout')},{value: 2, name: i18n.t('devicemanagement.contDoorSensor')},{value: 3, name: i18n.t('devicemanagement.contPushButton')},{value: 4, name: i18n.t('devicemanagement.contFireSignal')}],
  // gpioB:[{value: 1, name: '无'},{value: 2, name: '门磁'},{value: 3, name: '出门按钮'},{value: 4, name: '消防信号'}],
  gpioC:[{value: 1, name: i18n.t('devicemanagement.contWithout')},{value: 2, name: i18n.t('devicemanagement.contDoorSensor')},{value: 3, name: i18n.t('devicemanagement.contPushButton')},{value: 4, name: i18n.t('devicemanagement.contFireSignal')}],
  // gpioC:[{value: 1, name: '无'},{value: 2, name: '门磁'},{value: 3, name: '出门按钮'},{value: 4, name: '消防信号'}],
  wiganInputList:[{value: 1, name: i18n.t('devicemanagement.contWithout')},{value: 2, name: i18n.t('devicemanagement.contWiggins26')},{value: 3, name: i18n.t('devicemanagement.contWiggins262')},{value: 4, name: i18n.t('devicemanagement.contWiggins32')},{value: 5, name: i18n.t('devicemanagement.contWiggins34')}],//韦根输入口
  // wiganInputList:[{value: 1, name: '无'},{value: 2, name: '韦根26（24bit ID）'},{value: 3, name: '韦根26（8+164bit ID）'},{value: 4, name: '韦根32'},{value: 5, name: '韦根34'}],//韦根输入口
  languageTypeList:[{value: 1, name: '中文'},{value: 2, name: 'English'},{value: 3, name: '繁體'}],
};
