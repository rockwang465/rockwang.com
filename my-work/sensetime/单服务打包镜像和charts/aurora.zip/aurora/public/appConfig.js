export default {
  appList:{
    use:['icon-shikuang','icon-kanban1','icon-record1','icon-visitor','icon-kaoqin','icon-welcome','icon-ditu2','icon-facetest','icon-zu','icon-facevalue'],
    set:['icon-device1','icon-renxiangku','icon-task','icon-zu1','icon-character','icon-map1','icon-timer','icon-diary']
  },
  nameList:{
    use:['video','dashboard','recode','visitor','attendance','metting','labelHeatMap','face1','face2','face3'],
    set:['device','portrait','task','user','role','map','time','log']
  },
  routerList:{
    use:['/monitor','/dashboard','/retrival','/visitor','/attendance','/welcome','/heatMap','tools/face-verification','tools/score-detection','tools/test-detection'],
    set:['/manage/device','/manage/portrait','/manage/task','/manage/user','/manage/role','/manage/map','/manage/timezone','/manage/log']
  },

}
