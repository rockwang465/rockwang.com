import router from './router/index';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import { Message } from 'element-ui';
import { Cache } from '@/utils/cache';
import { Route } from 'vue-router';
import { LoginModule } from '@/store/modules/login';

const whiteList = ['/login'];

router.beforeEach((to: Route, from: Route, next: any) => {
  //console.log(to,from,next)
  NProgress.start();
  let isLogin = Cache.sessionGet('isLogin') ;
  if(Cache.localGet("isLogin")){
    Cache.sessionSet('modulecodes',Cache.localGet("modulecodes"));
    Cache.sessionSet('isLogin',Cache.localGet("isLogin"));
    Cache.sessionSet('userInfo',Cache.localGet("userInfo"));
  }
  if (Cache.sessionGet("isLogin")) {
      if (to.path === '/login') {//如果是login页面
        next({ path: '/' });
        NProgress.done();
      }else{
          if(Cache.sessionGet("userInfo").first==0){//如果第一次登录
            if(to.path !== '/center/personInfo'){
              next('/center/personInfo')
            }else{//非第一次登录
              next()
            }
          }else{
            next()
          }
          NProgress.done();
      }
  }else{
    if (whiteList.indexOf(to.path) !== -1) {
      next();
    } else {
      next(`/login?redirect=${to.path}`); // 否则全部重定向到登录页
      NProgress.done();
    }
  }
});

router.afterEach(() => {
  NProgress.done();
});
