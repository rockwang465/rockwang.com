import { VuexModule, Module, MutationAction, Mutation, Action, getModule } from 'vuex-module-decorators';
import visitorApi from '@/api/visitor';
import store from '@/store';

@Module({ dynamic: true, store, name: 'visitor' })
class Visitor extends VuexModule {
  visitStatistics={}

  @Mutation
  set_visitStatistics(data) {
    this.visitStatistics = data;
  }


    //获取访客概览列表
  @Action({})
  getVisitorStatistics() {
    visitorApi.getVisitorStatistics().then((obj)=>{
      this.set_visitStatistics(obj)
    })
  }
}

export const VisitorModule = getModule(Visitor);

