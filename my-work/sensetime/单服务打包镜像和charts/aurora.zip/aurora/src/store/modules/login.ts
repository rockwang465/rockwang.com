import { VuexModule, Module, MutationAction, Mutation, Action, getModule } from 'vuex-module-decorators';
import request from '@/api/login';
import { getToken, setToken, removeToken } from '@/utils/auth';
import store from '@/store';
import { Cache } from '@/utils/cache';

export interface LoginState {
  token: string;
  name: string;
  avatar: string;
  roles: string[];
}

@Module({ dynamic: true, store, name: 'login' })
class Login extends VuexModule implements LoginState {
  token = '';
  name = '';
  avatar = '';
  roles = [];

  @Mutation
  SET_TOKEN(token: string) {
    this.token = token;
  }

  @Action({ commit: 'SET_TOKEN' })
  async Login(userInfo: { username: string, password: string, verifyCode: string, timestamp: string,rememberMe:boolean }) {
    const username = userInfo.username.trim();
    try {
      const data = await request.login(username, userInfo.password, userInfo.verifyCode, userInfo.timestamp,userInfo.rememberMe);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async validateToken() {
    try {
      const data = await request.validateToken();
      return data;
    } catch (err) {
      throw err
    }
  }

  // @Action({ commit: 'SET_TOKEN' })
  // async FedLogOut() {
  //   removeToken();
  //   return '';
  // }

  // @MutationAction({ mutate: [ 'roles', 'name', 'avatar' ] })
  // async GetInfo() {
  //   const token = getToken();
  //   if (token === undefined) {
  //     throw Error('GetInfo: token is undefined!');
  //   }
  //   const { data } = await request.validateToken();
  //   if (data.roles && data.roles.length > 0) {
  //     return {
  //       roles: data.roles,
  //       name: data.name,
  //       avatar: data.avatar,
  //     };
  //   } else {
  //     throw Error('GetInfo: roles must be a non-null array!');
  //   }
  // }

  @Action({})
  async LogOut() {
    await request.logout();
  }
}

export const LoginModule = getModule(Login);

export function logout() {
  request.logout().then(() => {

  }).finally(() => {
    Cache.localClear();
    Cache.sessionClear();
    location.reload(); // 为了重新实例化vue-router对象 避免bug
  });
}
