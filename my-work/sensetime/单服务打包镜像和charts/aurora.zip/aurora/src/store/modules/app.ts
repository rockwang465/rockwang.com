import Cookies from 'js-cookie';
import { VuexModule, Module, Mutation, Action, getModule } from 'vuex-module-decorators';
import store from '@/store';

export enum DeviceType {
  Mobile,
  Desktop,
  language,
}

export interface IAppState {
  device: DeviceType;
  language:string;
  sidebar: {
    opened: boolean;
    withoutAnimation: boolean;
  };
  badgePos:any,
  fullScreen:boolean;
}

@Module({ dynamic: true, store, name: 'app' })
class App extends VuexModule implements IAppState {
  sidebar = {
    opened: Cookies.get('sidebarStatus') !== 'closed',
    withoutAnimation: false,
  };
  language = Cookies.get('language') || 'zh';
  device = DeviceType.Desktop;
  badgePos:any;
  fullScreen = false;

  @Mutation
  TOGGLE_SIDEBAR(withoutAnimation: boolean) {
    if (this.sidebar.opened) {
      Cookies.set('sidebarStatus', 'closed');
    } else {
      Cookies.set('sidebarStatus', 'opened');
    }
    this.sidebar.opened = !this.sidebar.opened;
    this.sidebar.withoutAnimation = withoutAnimation;
  }
  @Mutation
  TOGGLE_FULLSCREEN(withoutAnimation: boolean) {
    this.fullScreen = !this.fullScreen;
  }
  // @Mutation
  // CLOSE_SIDEBAR(withoutAnimation: boolean) {
  //   Cookies.set('sidebarStatus', 'closed');
  //   this.sidebar.opened = false;
  //   this.sidebar.withoutAnimation = withoutAnimation;
  // }
  @Mutation
  TOGGLE_DEVICE(device: DeviceType) {
    this.device = device;
  }

  @Mutation
  SET_LANGUAGE(language: string) {
    this.language = language;
    Cookies.set('language', language)
  }
  @Mutation
  SET_BADGEPOS(badgePos: any) {
    this.badgePos = badgePos;
  }

  @Action({ commit: 'TOGGLE_SIDEBAR' })
  ToggleSideBar(withoutAnimation: boolean) {
    return withoutAnimation;
  }

  @Action({ commit: 'TOGGLE_FULLSCREEN' })
  ToggleFullScreen(withoutAnimation: boolean) {
    return withoutAnimation;
  }
  // @Action({ commit: 'CLOSE_SIDEBAR' })
  // CloseSideBar(withoutAnimation: boolean) {
  //   return withoutAnimation;
  // }
  @Action({ commit: 'TOGGLE_DEVICE' })
  ToggleDevice(device: DeviceType) {
    return device;
  }
  @Action({ commit: 'SET_BADGEPOS' })
  setBadgePos(badgePos: any) {
    return badgePos;
  }
  //i18n-setting
  @Action({ commit: 'SET_LANGUAGE' })
  async SetLanguage(language: string) {
    return language;
  }
}

export const AppModule = getModule(App);
