import {VuexModule, Module, MutationAction, Mutation, Action, getModule} from 'vuex-module-decorators';
import request from '@/api/device';
import store from '@/store';

export interface RoleState {
  token: string;
}

@Module({dynamic: true, store, name: 'device'})
class Role extends VuexModule implements RoleState {
  token = '';

  @Mutation
  SET_TOKEN(token: string) {
    this.token = token;
  }

  @Action({})
  async GetGroupList(params: Object) {
    try {
      const data = await request.getGroupList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async getDevicesTree(params: Object) {
    try {
      const data = await request.getDevicesTree(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async AddDeviceGroup(params: Object) {
    try {
      const data = await request.addGroup(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpdateDeviceGroup(obj: { params: Object, id: number }) {
    try {
      const data = await request.updateGroup(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeleteDeviceGroup(id: number) {
    try {
      const data = await request.deleteGroup(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeviceGroupDetailById(id: number) {
    try {
      const data = await request.deviceGroupDetailById(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetDeviceList(params: Object) {
    try {
      const data = await request.getDeviceList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async AddDevice(params: Object) {
    try {
      const data = await request.addDevice(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpdateDevice(objData: { params: Object, id: number }) {
    try {
      const data = await request.updateDevice(objData.params, objData.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeleteDevice(id: number) {
    try {
      const data = await request.deleteDevice(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeleteDeviceBatch(params: any) {
    try {
      const data = await request.deleteDeviceBatch(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetDeviceDetail(id: number) {
    try {
      const data = await request.getDeviceDetail(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpdateDeviceStatus(params: { state: number, id: number }) {
    try {
      const data = await request.updateDeviceStatus({state: params.state}, params.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpdateDeviceStatusBatch(params: Object) {
    try {
      const data = await request.updateDeviceStatusBatch(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeviceAddGroupBatch(params: Object) {
    try {
      const data = await request.deviceAddGroupBatch(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeviceAddUserBatch(params: Object) {
    try {
      const data = await request.deviceAddUserBatch(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetDeviceTaskById(id: number) {
    try {
      const data = await request.getDeviceTaskById(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  //搜索设备
  @Action({})
  async queryDevice(params: Object) {
    try {
      const data = await request.queryDevice(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  //获取厂商列表
  @Action({})
  async queryFirms(params: Object) {
    try {
      const data = await request.queryFirms(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  //设备导出
  @Action({})
  async deviceExport(params: Object) {
    try {
      const data = await request.deviceExport(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  //获取M设备关联人像库列表
  @Action({})
  async getLibrarys(params: Object) {
    try {
      const data = await request.getLibrarys(params);
      return data;
    } catch (err) {
      throw err
    }
  }
}

export const DeviceModule = getModule(Role);
