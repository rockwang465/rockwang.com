import { VuexModule, Module, MutationAction, Mutation, Action, getModule } from 'vuex-module-decorators';
import {CenterMessage} from '@/api/message-center';
import store from '@/store';
var _ = require('lodash/lang');
var historyDownload = window.globalConfig.historyDownload
var retrivalDownload = window.globalConfig.retrivalDownload 
import { Cache } from '@/utils/cache';

interface historyType {
  // captureLib:any;
  // facialLib:any;
  // historyRecord:any;
  // exportList:exportItem[];
  exportMessage:any;
  uploadMessage:any;
}
// interface exportItem {
//   type:Number;//1为历史记录导出,2以图搜图人像库导出,3以图搜图抓拍库导出,4top100导出
//   name:string; //当前导出的名字
//   data:[
//     {
//       name:string;
//       percent:number;
//       status:string;//"1"导出中，"2"成功 ，"3"失败
//       resource:string;//成功后的资源
//     }
//   ]
// }

@Module({ dynamic: true, store, name: 'messagecenter' })
class MessageCenter extends VuexModule implements historyType {
  // captureLib={};
  // facialLib={};
  // historyRecord={};
  // top100Lib={};
  // exportList:any=[]; 
  // uploadList=[];
  newMessage="";
  exportMessage=[];
  uploadMessage=[];

  // @Mutation 
  // add_export_task(data) {
  //   let isInsert=false;
  //   this.exportList.forEach((val,key) => {
  //     if(this.exportList.length===0){ //如果长度为0
  //       isInsert=true;
  //       this.exportList.unshift(data);
  //     }else if(val.type===data.type){
  //       isInsert=true;        
  //       this.exportList[key].data.unshift(data.data[0])
  //     }
  //   });
  //   if(!isInsert){
  //     this.exportList.unshift(data)
  //   }
  //   // let i=0;
  //   // while(true){
  //   //   if(this.exportList.length===0){ //如果长度为0
  //   //     this.exportList.unshift(data);
  //   //     break;
  //   //   }else if(this.exportList[i]&&this.exportList[i].type===data.type){//如果已经存在
  //   //       this.exportList[i].data.unshift(data.data[0])
  //   //       break;
  //   //   }else if(i===this.exportList.length-1){ //如果不存在
  //   //     this.exportList.unshift(data)
  //   //     break;
  //   //   }else if(i>this.exportList.length){
  //   //     break;
  //   //   }
  //   // i++
  //   // }
  // }

  @Mutation 
  set_upload_message(data) {
    this.uploadMessage = data;
  }
  @Mutation 
  set_export_message(data) {
    this.exportMessage = data;
  } 
  @Mutation 
  set_new_message(data) {
    this.newMessage = data;
  }
  // @Mutation 
  // set_msg(data) {
  //   this.top100Lib = data;
  // } 
  // @Mutation 
  // set_top100_lib(data) {
  //   this.top100Lib = data;
  // } 
  // @Mutation 
  // set_capture_lib(data) {
  //   this.captureLib = data;
  // } 
  // @Mutation 
  // set_facial_lib(data) {
  //   this.facialLib = data;
  // } 
  // @Mutation  
  // set_history_record(data) {
  //   this.historyRecord = data;
  // } 
  // @Mutation  
  // reset_msg_count() {
  //   this.newMessage = 0;
  // } 
  // @Mutation  
  // add_msg_count() {
  //   this.newMessage++;
  // }
  
  // //top100抓拍库抓拍库导出
  // @Action({ commit:'set_top100_lib' })
  // ExportTop100Lib({subAds, sendAds, data}) {
  //   let item = {
  //     type:4,
  //     name:"top100导出",
  //     data:[{
  //       name:"",
  //       percent:0,
  //       status:1,
  //       resource:""
  //     }]
  // }
  //   let socket = new Top100LibSock()
  //   socket.connect(subAds,sendAds, data).then((res)=>{  
  //     let data = JSON.parse(res.body)
  //     item.data[0].status=data.status
  //     if(data.status===1){
  //       item.data[0].percent=data.progress
  //       item.data[0].name=data.description
  //     }else if(data.status===2){
  //       item.data[0].resource=retrivalDownload+"/"+data.downloadId
  //       socket.disconnect()
  //     }
  //   }).once((fram)=>{
  //     this.add_msg_count()//消息提示+1
  //     this.add_export_task(item)
  //   })
  // }

  // //以图收图抓拍库导出
  // @Action({ commit:'set_capture_lib' }) 
  // ExportCaptureLib({subAds, sendAds, data}) {
  //   let item = {
  //     type:3,
  //     name:"以图搜图抓拍库导出",
  //     data:[{
  //       name:"",
  //       percent:0,
  //       status:1,
  //       resource:""
  //     }]
  //   }
  //   let socket = new CaptureLibSock()
  //   socket.connect(subAds,sendAds, data).then((res)=>{
  //     let data = JSON.parse(res.body)
  //     item.data[0].status=data.status
  //     if(data.status===1){
  //       item.data[0].percent=data.progress
  //       item.data[0].name=data.description
  //     }else if(data.status===2){
  //       item.data[0].resource=retrivalDownload+"/"+data.downloadId
  //       // item.data[0].resource=data.downloadId
  //       socket.disconnect()
  //     }
  //   }).once((fram)=>{
  //     this.add_msg_count()//消息提示+1
  //     this.add_export_task(item)
  //   })
  // }
  //  //以图收图人像库导出
  //  @Action({ commit:'set_facial_lib' })
  //  ExportFacialLib({subAds, sendAds, data}){
  //    let item = {
  //     type:2,
  //     name:"以图搜图人像库导出",
  //     data:[{
  //       name:"导出111",
  //       percent:0,
  //       status:1,
  //       resource:""
  //     }]
  //   }
  //    let socket = new FacialLibSock()
  //    socket.connect(subAds,sendAds, data).then((res)=>{
  //       let data = JSON.parse(res.body)
  //       item.data[0].status=data.status
  //       if(data.status===1){
  //         item.data[0].percent=data.progress
  //         item.data[0].name=data.description
  //       }else if(data.status===2){
  //         item.data[0].resource=retrivalDownload+"/"+data.downloadId
  //         socket.disconnect()
  //       }
  //    }).once((fram)=>{
  //     this.add_msg_count()//消息提示+1
  //     this.add_export_task(item)
  //   })
  //  }  

    //连接消息中心 
  @Action({})
  linkCenterMessage() {
    let userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";
    let socket = new CenterMessage(userId)
    socket.connect("/topic/msg/subscribe/"+userId+"/","/app/records/export",{}).then((res)=>{
      let data = JSON.parse(res.body)
      if(data.code===1){
        this.set_new_message("new")
      }
      if(data.userMsgVoList.length==0){
        this.set_export_message([])
        this.set_upload_message([])
      }else {
        data.userMsgVoList.forEach((val)=>{
          this.set_export_message(val.dataList)
          // if(val.msgType==0){
          //   this.set_export_message(val.dataList)
          // }else if(val.msgType==1){
          //   this.set_upload_message(val.dataList)
          // }
        })
      }
      
    }).once((fram)=>{
    }) 
  }
  //历史记录导出
  // @Action({ commit:'set_history_record' })
  // exportHistoryRecord({subAds, sendAds, data}) {
  //   let socket = new HistoryRecordSock()
  //   let item = {
  //     type:1,
  //     name:"历史记录导出",
  //     data:[{
  //       name:"",
  //       percent:0,
  //       status:0,
  //       resource:""
  //     }]
  //   }
  //   socket.connect(subAds,sendAds, data).then((res)=>{
  //     let data = JSON.parse(res.body)
  //     item.data[0].status=data.status
  //     if(data.status===1){
  //       item.data[0].percent=data.progress
  //       item.data[0].name=data.description
  //     }else if(data.status===2){
  //       item.data[0].resource=historyDownload+"/"+data.downloadId
  //       socket.disconnect()
  //     }
  //   }).once((fram)=>{
  //     this.add_msg_count()//消息提示+1 
  //     this.add_export_task(item)
  //   })
  // }
}

export const messageCenter = getModule(MessageCenter);
