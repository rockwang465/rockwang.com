import {VuexModule, Module, MutationAction, Mutation, Action, getModule} from 'vuex-module-decorators';
import request from '@/api/role';
import {getToken, setToken, removeToken} from '@/utils/auth';
import store from '@/store';

export interface RoleState {
  token: string;
}

@Module({dynamic: true, store, name: 'role'})
class Role extends VuexModule implements RoleState {
  token = '';

  @Mutation
  SET_TOKEN(token: string) {
    this.token = token;
  }

  @Action({})
  async GetRoleList(params: Object) {
    try {
      const data = await request.getRoleList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async ExportRoleList(params: Object) {
    try {
      const data = await request.exportRoleList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetPermissions(params: Object) {
    try {
      const data = await request.getPermissions(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async AddRole(params: Object) {
    try {
      const data = await request.addRole(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpdateRole(obj: { params: Object, id: number }) {
    try {
      const data = await request.updateRole(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeleteRole(id: number) {
    try {
      const data = await request.deleteRole(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DetailRolePermissions(id: number) {
    try {
      const data = await request.detailRolePermissions(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpdateRoleStatus(params: { state: number, id: number }) {
    try {
      const data = await request.updateRoleStatus({state: params.state}, params.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetRoleRelate() {
    try {
      const data = await request.getRoleRelate();
      return data;
    } catch (err) {
      throw err
    }
  }
}

export const RoleModule = getModule(Role);
