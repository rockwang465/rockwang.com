import { VuexModule, Module, MutationAction, Mutation, Action, getModule } from 'vuex-module-decorators';
import request from '@/api/history-record';
import store from '@/store';
var _ = require('lodash/lang');

export interface searchCondition {
  deviceIds: number[];
  captureTimeEnd: string;
  captureTimeStart:string;
  compareTypes: any[];
  enabledSimilaritySoft: string;
  enabledTimeSoft: string;
  faceDatabases: number[];
  floorIds: any[];
  imageFaceBase64: string;
  operateStatus: any[];
  operaterDeptIds: any[];
  taskIds: any[];
  similarity: string;
  similaritySoft?: string;
  timeSoft?: string;

  //TODO:核实两个类型保留哪个
  respiratorColors:any[];
  wearStatus:string[];
}

interface historyType {
  condition: searchCondition;
}

@Module({ dynamic: true, store, name: 'history' })
class history extends VuexModule implements historyType {
  condition={
    deviceIds:[],
    captureTimeEnd:"",
    captureTimeStart:"",
    compareTypes:[],
    enabledSimilaritySoft: "",
    enabledTimeSoft: "",
    faceDatabases: [],
    floorIds: [],
    imageFaceBase64: "",
    operateStatus: [],
    operaterDeptIds: [],
    taskIds: [],
    similarity: "0",
    respiratorColors:[],
    wearStatus:[]
  };
  @Mutation
  set_condition(data) {
    this.condition = data;
  }
  @Mutation
  reset_condition() {
    this.condition = {
      deviceIds:[],
      captureTimeEnd:"",
      captureTimeStart:"",
      compareTypes:[],
      enabledSimilaritySoft: "",
      enabledTimeSoft: "",
      faceDatabases: [],
      floorIds: [],
      imageFaceBase64: "",
      operateStatus: [],
      operaterDeptIds: [],
      taskIds: [],
      similarity: "0",
      respiratorColors:[],
      wearStatus:[]
    };
  }

  @Action({})
  async searchCaptureLib(condition) {
    try{
      let param= condition? condition:this.condition
      const data  = await request.searchCaptureLib(param);
      return data;
    }catch (err){
      throw err
    }
  }
  @Action({})
  async searchFacialLib(condition) {
    try{
      let param= condition? condition:this.condition
      const data  = await request.searchFacialLib(param);
      return data;
    }catch (err){
      throw err
    }
  }
  // @Action({})
  // async getCaptureTrack(param) {
  //   try{
  //     const data  = await request.getCaptureTrack(param);
  //     return data;
  //   }catch (err){
  //     throw err
  //   }
  // }
  @Action({})
  async getLibraryTrack(param) {
    try{
      const data  = await request.getLibraryTrack(param);
      return data;
    }catch (err){
      throw err
    }
  }
}

export const historyStore = getModule(history);
