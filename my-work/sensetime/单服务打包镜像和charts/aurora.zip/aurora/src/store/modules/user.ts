import {VuexModule, Module, MutationAction, Mutation, Action, getModule} from 'vuex-module-decorators';
import request from '@/api/user';
import {getToken, setToken, removeToken} from '@/utils/auth';
import store from '@/store';

export interface UserState {
  token: string;
}

@Module({dynamic: true, store, name: 'user'})
class User extends VuexModule implements UserState {
  token = '';

  @Mutation
  SET_TOKEN(token: string) {
    this.token = token;
  }

  @Action({})
  async GetUserList(params: Object) {
    try {
      const data = await request.getUserList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetUserDetails(dataObj: { params: Object, userId: Number }) {
    try {
      console.log(dataObj.userId)
      const data = await request.getUserDetails(dataObj.params, dataObj.userId);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async getOneUserDetail(userId: Number ) {
    try {
      const data = await request.getOneUserDetail(userId);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UserAdd(params) {
    try {
      const data = await request.userAdd(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UserDelete(dataObj: { params: Object, userId: Number }) {
    try {
      const data = await request.userDelete(dataObj.params, dataObj.userId);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetUserGroup(params) {
    try {
      const data = await request.getUserGroup(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async AddUserGroup(params) {
    try {
      const data = await request.addUserGroup(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpdateGroup(obj: { params: Object, id: number }) {
    try {
      const data = await request.updateGroup(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeleteGroup(id: number) {
    try {
      const data = await request.deleteGroup(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetGroupDetails(id: number) {
    try {
      const data = await request.getGroupDetails(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async EditUser(obj: { params: Object, id: number }) {
    try {
      const data = await request.editUser(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async SearchUseList(params: Object) {
    try {
      const data = await request.searchUseList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async UpDataState(obj: { params: Object, id: number }) {
    try {
      const data = await request.upDataState(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async ResetPassWord(obj: { params: Object, id: number }) {
    try {
      const data = await request.resetPassWord(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async updataPassWord(obj: { params: Object, id: number }) {
    try {
      const data = await request.updataPassWord(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeleteAll(userIds) {
    try {
      const data = await request.deleteAll(userIds);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async ExportUserList(params: Object) {
    try {
      const data = await request.exportUserList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetOrgUserTree() {
    try {
      const data = await request.getOrgUserTree();
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async BatchStopUser(userIds) {
    try {
      const data = await request.batchStopUser(userIds);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async BatchStartUser(userIds) {
    try {
      const data = await request.batchStartUser(userIds);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async BatchMoveUser(params: Object) {
    try {
      const data = await request.batchMoveUser(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async BatchUpdataRole(params: Object) {
    try {
      const data = await request.batchUpdataRole(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async updateUserLanguage(params: Object) {
    try {
      const data = await request.updateUserLanguage(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async queryModule(params: Object) {
    try {
      const data = await request.queryModule(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async getPortraitId(params: Object) {
    try {
      const data = await request.getPortraitId(params);
      return data;
    } catch (err) {
      throw err
    }
  }
}

export const UserModule = getModule(User);
