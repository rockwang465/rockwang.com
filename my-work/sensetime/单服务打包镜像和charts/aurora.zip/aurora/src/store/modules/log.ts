import {VuexModule, Module, MutationAction, Mutation, Action, getModule} from 'vuex-module-decorators';
import request from '@/api/log';
import {getToken, setToken, removeToken} from '@/utils/auth';
import store from '@/store';

export interface LogState {
  token: string;
}

@Module({dynamic: true, store, name: 'log'})
class Log extends VuexModule implements LogState {
  token = '';

  @Mutation
  SET_TOKEN(token: string) {
    this.token = token;
  }

  @Action({})
  async GetLogList(params: any) {
    try {
      const data = await request.getLogList(params.query, params.orgIds);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetLogSearchCondition(params: any) {
    try {
      const data = await request.getLogSearchCondition(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async ExportLog(params: any) {
    try {
      const data = await request.exportLog(params);
      return data;
    } catch (err) {
      throw err
    }
  }

}

export const LogModule = getModule(Log);
