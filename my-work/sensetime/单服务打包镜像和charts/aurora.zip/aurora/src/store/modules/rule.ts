import { VuexModule, Module, Mutation, Action, getModule } from 'vuex-module-decorators';
import store from '@/store';



export interface IRuleState {
  keyword:string
}

@Module({ dynamic: true, store, name: 'rule' })
class Rule extends VuexModule implements IRuleState {
  keyword = '';
  
  @Mutation
  SET_KEYWORD(keyword: string) {
    this.keyword = keyword;
  }
  
}

export const RuleModule = getModule(Rule);
