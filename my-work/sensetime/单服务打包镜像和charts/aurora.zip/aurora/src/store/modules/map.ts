import { VuexModule, Module, MutationAction, Mutation, Action, getModule } from 'vuex-module-decorators';
import request from '@/api/map';
import { getToken, setToken, removeToken } from '@/utils/auth';
import store from '@/store';

export interface mapState {
  token: string;
  name: string;
  floorId: string;
  roles: string[];
}

@Module({ dynamic: true, store, name: 'floor' })
class Map extends VuexModule implements mapState {
  token = '';
  name = '';
  floorId = '';
  roles = [];

  @Mutation
  SET_TOKEN(token: string) {
    this.token = token;
  }
  @Mutation
  SET_FLOORID(floorId: string){
    this.floorId = "11"
  }

  @Action({ commit: 'SET_TOKEN' })
  async Map(floorInfo: { parentId: string, name: string}) {
    const name = floorInfo.name.trim();
    try{
      const data  = await request.mapTreeAdd(floorInfo);
      return data;
    }catch (err){
      throw err
    }
  }
  @Action({})
  async storeMapUpload(mapInfo) {
    try{
      const data  = await request.mapUpload(mapInfo.id);
      return data;
    }catch (err){
      throw err
    }
  }
  @Action({ commit: 'SET_FLOORID' })
  SetFloorid(floorid: string) {
    return floorid;
  }

  @Action({ commit: 'SET_FLOORID' })
  async TreeList() {
    try{
      const data  = await request.floorList();
      return data;
    }catch (err){
      throw err
    }
  }

  @Action({ commit: 'SET_TOKEN' })
  async FedLogOut() {
    removeToken();
    return '';
  }

  @MutationAction({ mutate: [ 'roles', 'name', 'floorId' ] })
  async GetInfo() {
    const token = getToken();
    if (token === undefined) {
      throw Error('GetInfo: token is undefined!');
    }
    const { data } = await request.validateToken();
    if (data.roles && data.roles.length > 0) {
      return {
        roles: data.roles,
        name: data.name,
        floorId: data.floorId,
      };
    } else {
      throw Error('GetInfo: roles must be a non-null array!');
    }
  }

  @MutationAction({ mutate: [ 'token', 'roles' ] })
  async LogOut() {
    await request.logout();
    return {
      token: '',
      roles: [],
    };
  }
}

export const MapModule = getModule(Map);
