import { VuexModule, Module, Mutation, Action, getModule } from 'vuex-module-decorators';
import store from '@/store';
import request from "@/api/system";

export interface systemState {
  system: Object;
}


@Module({ dynamic: true, store, name: 'system' })
class System extends VuexModule {
  logo = '' as any;
  system = {
    logo:''
  }

  @Mutation
  SET_LOGO(logo: any) {
    this.logo = logo;
  }

  //获取系统信息
  @Action({})
  async getSystemInfo() {
    try {
      const data = await request.getSystemInfo();
      return data;
    } catch (err) {
      throw err
    }
  }
  //获取系统logo
  @Action({})
  async getSystemLogo() {
    try {
      const data = await request.getSystemLogo();
      return data;
    } catch (err) {
      throw err
    }
  }
  //更改系统信息
  @Action({})
  async updateSystemInfo(params:Object) {
    try {
      const data = await request.updateSystemInfo(params);
      return data;
    } catch (err) {
      // throw err
    }
  }
  //更改系统信息
  @Action({})
  async getStrangerPhoto() {
    try {
      const data = await request.getStrangerPhoto();
      return data;
    } catch (err) {
      // throw err
    }
  }
  //更改比对信息
  @Action({})
  async updateGuestInterimLibraryExtract(params) {
    try {
      const data = await request.updateGuestInterimLibraryExtract(params);
      return data;
    } catch (err) {
      // throw err
    }
  }

  //获取比对信息系统信息
  @Action({})
  async getUpdateGuestInterimLibraryExtract() {
    try {
      const data = await request.getUpdateGuestInterimLibraryExtract();
      return data;
    } catch (err) {
      // throw err
    }
  }

  //获取推送信息
  @Action({})
  async showAlarmPushInfo() {
    try {
      const data = await request.getAlarmUrlInfo();
      return data;
    } catch (err) {
      // throw err
    }
  }

  //更新推送开关信息
  @Action({})
  async updateAlarmPushOnOff(params) {
    try {
      const data = await request.switchAlarm(params);
      return data;
    } catch (err) {
      // throw err
    }
  }

  //更新推送url信息
  @Action({})
  async updateAlarmPushUrl(params) {
    try {
      const data = await request.updateAlarmUrl(params);
      return data;
    } catch (err) {
      // throw err
    }
  }

  //查询口罩安全帽对应开关信息
  // @Action({})
  // async getAllSwitchEventInfo() {
  //   try {
  //     const data = await request.getAllEventSwitchInfo();
  //     return data;
  //   } catch (err) {
  //     // throw err
  //   }
  // }

}

export const getSystem = getModule(System);
