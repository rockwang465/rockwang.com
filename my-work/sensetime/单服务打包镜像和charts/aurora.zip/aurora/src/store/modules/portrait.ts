import {VuexModule, Module, MutationAction, Mutation, Action, getModule} from 'vuex-module-decorators';
import request from '@/api/portrait';
import {getToken, setToken, removeToken} from '@/utils/auth';
import store from '@/store';

export interface PortraitState {
  token: string;
}

@Module({dynamic: true, store, name: 'portrait'})
class Portrait extends VuexModule implements PortraitState {
  token = '';
  pics = {} as any;
  activationTime = "" as any;
  expirationTime = "" as any;
  len1 = 0;
  num = 0;
  inp = null as any;
  userId=null;//批量上传数据
  taskId=0;//批量上传数据
  groupName = '' as any;//批量上传数据
  currentLibraryGroup = null;//批量上传数据
  worb = false;
  currentLibrary = "" as any;
  isShow = false;
  strTips = '';

  @Mutation
  SET_ISSHOW() {
    this.isShow = !this.isShow;
  }

  @Mutation
  SET_TOKEN(token: string) {
    this.token = token;
  }

  @Mutation
  SET_PICS(format: any,id: any) {
    this.pics.id = format;
  }

  @Mutation
  SET_TASK_ID(id: any) {
    this.taskId = id;
  }
  @Mutation
  SET_INP(inp: any) {
    this.inp = inp;
    this.num = inp.length;
  }
  @Mutation
  SET_NUM(num: any) {
    this.num = num;
  }
  @Mutation
  SET_PARAMS(params: any) {
    // this.taskId = params.taskId;
    this.currentLibraryGroup = params.currentLibraryGroup;
    this.userId = params.userId;
    this.currentLibrary = params.currentLibrary;
    this.worb = params.worb;
    this.activationTime = params.form.activationTime;
    this.expirationTime = params.form.expirationTime;
    this.groupName = params.groupName;
    this.strTips = params.strTips;
  }
  @Mutation
  fILES_UPDATA(fn,str){
    let that = this as any;
    let base = 20 as any;//按数量上传
    let numNow = -1;//按体积大小上传
    let time = 0;//按体积大小上传
    let go = true;//按体积大小上传
    let cubage = 17301504;//16.5M

    console.log(that)
    // let timer = 1 as any;
    // debugger
    updata();

    //按数量上传
    // function updata(){
    //   let num2 = 0;
    //   if (that.num - that.len1 >= base){
    //     num2 = that.len1 + base;
    //   } else{
    //     num2 = that.num
    //   }
    //   //console.log('num2',num2)
    //   let formdata = new FormData() as any;
    //   for(let i = that.len1;i < num2;i++){
    //     formdata.append("img", that.inp[i]);
    //   }
    //
    //
    //   formdata.append('taskId',that.taskId);
    //   formdata.append('libraryId',that.value);
    //   formdata.append('userId',that.userId);
    //   formdata.append('libraryType',that.value1);
    //   formdata.append('activationDate',that.worb?that.activationTime:'');
    //   formdata.append('expirationDate',that.worb?that.expirationTime:'');
    //   formdata.append('currentRequestNum',Math.ceil(num2/base));//当前请求数
    //   formdata.append('requestTotalNum',Math.ceil(that.num/base));//请求总数
    //   formdata.append('fileTotalNumber',that.num);//文件总数
    //   formdata.append('groupName',that.groupName);
    //
    //   console.log(Math.ceil(num2/base),Math.ceil(that.num/base),that.num)
    //
    //   // this.updateBatch(formdata);
    //   that.len1 += base;
    //   if (that.len1 - that.num > base){
    //     // inp.value = '';
    //     // inp.outerHTML=inp.outerHTML;//清空input的files
    //     request.protraitGetLostFile(that.taskId).then((data)=>{
    //       console.log(data);
    //     })
    //     cancleUpdata();
    //     fn({
    //       // message: "上传成功",
    //       message:that.strTips,
    //       type: 'success'
    //     });
    //     // that.taskId = null;
    //     // that.len1 = 0;
    //     // that.num = 0;
    //     // that.inp = null;
    //     return;
    //   } else{
    //     // dispatch("protraitAddTargetBulkTool",formdata).then((data)=>{
    //     request.protraitAddTargetBulkTool(formdata).then((data)=>{
    //       console.log(data);
    //       return updata();
    //     }).catch((err) => {
    //       updata();
    //       // cancleUpdata();
    //     });
    //   }
    //
    //   function cancleUpdata() {
    //     // alert(2)
    //     that.taskId = null;
    //     that.len1 = 0;
    //     that.num = 0;
    //     that.inp = null;
    //   }
    //
    // }

    //按体积大小上传
    function updata(){
      let base = 100 as any;
      let len = 0 as any;
      time ++;
      let formdata = new FormData() as any;
      let size = 0;
      for(let i = (numNow+1);i < that.inp.length;i++){
        if (that.inp[i].size >= cubage){
          // numNow = i + 1;
          console.log(that.inp[i].name,'尺寸过大',that.inp[i].size);
          numNow = i;
        }else{
          if(i == that.inp.length - 1){//上传的最后一张照片
            numNow = i;
          }
          size += that.inp[i].size;
          len += 1;
          if (size < cubage && len <= 100){
            formdata.append("img", that.inp[i]);
            if (len == 100){
              numNow = i;//记录此次上传到哪
              len = 0;
              break;
            }
            // that.inp[i] = null;
          }else if (size >=cubage) {
            numNow = i - 1;//记录此次上传到哪
            len = 0;
            break;
          } else{
            numNow = i;//记录此次上传到哪
            len = 0;
            break;
          }
        }

      }





      formdata.append('taskId',that.taskId);
      formdata.append('libraryId',that.currentLibraryGroup);
      formdata.append('userId',that.userId);
      formdata.append('libraryType',that.currentLibrary);
      formdata.append('activationDate',that.worb?that.activationTime:'');
      formdata.append('expirationDate',that.worb?that.expirationTime:'');
      formdata.append('currentRequestNum',Math.ceil(time));//当前请求数
      formdata.append('requestTotalNum',Math.ceil(numNow+1));//请求总数
      formdata.append('fileTotalNumber',that.num);//文件总数
      formdata.append('groupName',that.groupName);


      // this.updateBatch(formdata);

      if (!go){
        let params = {
          taskId:that.taskId,
          userId:that.userId
        }
        request.protraitGetLostFile(that.taskId,that.userId).then((data)=>{
          console.log(data);
        })
        cancleUpdata();
        fn({
          // message: "上传成功",
          showClose:true,
          message:that.strTips,
          type: 'success'
        });
        return;
      } else{
        // dispatch("protraitAddTargetBulkTool",formdata).then((data)=>{
        request.protraitAddTargetBulkTool(formdata).then((data:any)=>{
          console.log(data);
          console.log(numNow);
          if (data.code == "408010"||data.code == "419002") {
            console.log('-------被占用----------',data);
            cancleUpdata();
            return;
          }
          if (numNow == that.inp.length - 1){
            go = false;
          }
          return updata();
        }).catch((err) => {
          if (numNow == that.inp.length - 1){
            go = false;
          }
          updata();
        });
      }

      function cancleUpdata() {
        // alert(2)
        that.taskId = null;
        that.len1 = 0;
        that.num = 0;
        that.inp = null;
      }

    }

  }

  @Action({})
  async SearchLibraries(params: Object) {
    try {
      const data = await request.searchLibraries(params);
      return data;
    } catch (err){
      throw err
    }
  }

  @Action({})
  async AddPortraitNode(params: Object) {
    try {
      const data = await request.addPortraitNode(params);
      return data;
    } catch (err){
      throw err
    }
  }

  @Action({})
  async ReviseGroup(obj: { params: Object, id: number }) {
    try {
      const data = await request.reviseGroup(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async DeleteGroups(id: number) {
    try {
      const data = await request.deleteGroups(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GroupDetails(id: number) {
    try {
      const data = await request.groupDetails(id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async GetPortraitList(params: Object) {
    try {
      const data = await request.getPortraitList(params);
      return data;
    } catch (err){
      throw err
    }
  }

  @Action({})
  async PortraitDetails(id: number) {
    try {
      const data = await request.portraitDetails(id);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async PortraitAdd(params: Object) {
    try {
      const data = await request.portraitAdd(params);
      return data;
    } catch (err){
      throw err
    }
  }

  @Action({})
  async ProtraitDelete(obj: { params: Object, id: number }) {
    try {
      const data = await request.protraitDelete(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async ProtraitDeleteAll(obj: { params: Object}) {
    try {
      const data = await request.protraitDeleteAll(obj.params);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async protraitCopyList(params: Object) {
    try {
      const data = await request.protraitCopyList(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async protraitEditData(obj: { params: Object, id: number }) {
    try {
      const data = await request.protraitEditData(obj.params, obj.id);
      return data;
    } catch (err) {
      throw err
    }
  }

  @Action({})
  async protraitNameList(params: Object) {
    try {
      const data = await request.protraitNameList(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async protraitQueryNextFileName(uuid:Number) {
    try {
      const data = await request.protraitQueryNextFileName(uuid);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async protraitAddTargetBulkTool(params: any) {
    try {
      const data = await request.protraitAddTargetBulkTool(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async protraitGetLostFile(str: any,str2:any) {
    try {
      const data = await request.protraitGetLostFile(str,str2);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async protraitQueryTaskList(params: Object) {
    try {
      const data = await request.protraitQueryTaskList(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  @Action({})
  async protraitQueryDateTimeList(params: Object) {
    try {
      const data = await request.protraitQueryDateTimeList(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  //导出人像
  @Action({})
  async protraitBuildDownloadData(params: Object) {
    try {
      const data = await request.protraitBuildDownloadData(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  //统计上传失败人像数量
  @Action({})
  async protraitUpFailCount(params: Object) {
    try {
      const data = await request.protraitUpFailCount(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  //分页查询上传失败人像列表
  @Action({})
  async protraitUpFailList(params: Object) {
    try {
      const data = await request.protraitUpFailList(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  //根据ID查询人像详情
  @Action({})
  async protraitIdDetails(params: Object) {
    try {
      const data = await request.protraitIdDetails(params);
      return data;
    } catch (err) {
      throw err
    }
  }
  //检测图片人脸信息
  @Action({})
  async protraitDetection(params: Object) {
    try {
      const data = await request.protraitDetection(params);
      return data;
    } catch (err) {
      throw err
    }
  }

  //判断此时是否有用户在批量上传
  @Action({})
  async protraitCheckUploadState() {
    try {
      const data = await request.protraitCheckUploadState();
      return data;
    } catch (err) {
      throw err
    }
  }

  //改变人像启用状态
  @Action({})
  async updateEnableStateByTargetId(params: Object) {
    try {
      const data = await request.updateEnableStateByTargetId(params);
      return data;
    } catch (err) {
      throw err
    }
  }
//一键清空失败人像
  @Action({})
  async removeAllFailPicture(params: Object) {
    try {
      const data = await request.removeAllFailPicture(params);
      return data;
    } catch (err) {
      throw err
    }
  }
//批量删除失败人像
  @Action({})
  async BatchRemoveFailPicture(params: Object) {
    try {
      const data = await request.BatchRemoveFailPicture(params);
      return data;
    } catch (err) {
      throw err
    }
  }

}

export const PortraitModule = getModule(Portrait);
