import { VuexModule, Module, MutationAction, Mutation, Action, getModule } from 'vuex-module-decorators';
import request from '@/api/monitor';
import store from '@/store';

export interface monitorState {
  human: Object;
  roles: string[];
}

@Module({ dynamic: true, store, name: 'monitor' })
class Monitor extends VuexModule implements monitorState {
  human = {
    url:"",
    deviceId:"",
    floorId:""
  }
  roles = [];

  @Mutation
  SET_HUMAN(human: any) {
    this.human = human;
  }

  @Action({ commit: 'SET_HUMAN' })
  SetHuman(human: any) {
    return human;
  }

  @MutationAction({ mutate: [ 'human', 'roles' ] })
  async LogOut() {
    //await request.logout();
    return {
      human: '',
      roles: [],
    };
  }
}

export const MonitorModule = getModule(Monitor);
