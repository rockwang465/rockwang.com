//import Vue from 'vue';
import { Vue } from 'vue-property-decorator';
import Vuex from 'vuex';
import { IAppState } from './modules/app';
import { LoginState } from './modules/login';
import { mapState } from './modules/map';
import { monitorState } from './modules/monitor';
import { systemState } from './modules/system';

Vue.use(Vuex);

export interface IRootState {
  app: IAppState;
  login: LoginState;
  floor: mapState;
  monitor: monitorState;
  system: systemState;
}

// Declare empty store first, dynamically register all modules later.
export default new Vuex.Store<IRootState>({});
