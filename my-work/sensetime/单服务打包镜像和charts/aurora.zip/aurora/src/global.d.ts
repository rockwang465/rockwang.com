
import { Vue } from 'vue-property-decorator';
//import L from 'leaflet';

declare module 'vue/types/vue' {
  interface Vue {
    $permission(code?:String): boolean,
    $modulePermission(code?:String): boolean,
  }

}
declare module 'vue/types/vue' {
  interface Vue {
    $_: any, //lodash
  }
}
// export class movingMarker extends L.Marker {
//   constructor(options?: any);
// }

