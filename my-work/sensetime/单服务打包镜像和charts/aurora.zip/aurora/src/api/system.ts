import request from '@/utils/request';

var url = window.globalConfig.log

export default{
  getSystemLogo() {
    return request({
      url: `${url}/system-logo`,
      method: 'get'
    });
  },
  getSystemInfo() {
    return request({
      url: `${url}/system-info`,
      method: 'get'
    });
  },
  updateSystemInfo(params) {
    return request({
      url: `${url}/system-info`,
      method: 'post',
      data:params
    });
  },
  getStrangerPhoto(){
    return request({
      url: `${url}/stranger_ratio_switch`,
      method: 'get',
    });
  },
  setStrangerPhoto(params){
    return request({
      url: `${url}/stranger_ratio_switch`,
      method: 'put',
      data:params
    });
  },
  updateGuestInterimLibraryExtract(params){
    return request({
      url: `${url}/update_guest_interim_library_extract`,
      method: 'put',
      data:params
    });
  },
  getUpdateGuestInterimLibraryExtract(){
    return request({
      url: `${url}/show_guest_interim_library_extract`,
      method: 'get',
    });
  },

  getAlarmUrlInfo(){
    return request({
      url: `${url}/show_alarm_push_info`,
      method: 'get',
    });
  },
  switchAlarm(params){
    console.log(params)
    return request({
      url: `${url}/alarm_push_on_off`,
      method: 'put',
      data:params
    });
  },
  updateAlarmUrl(params){
    return request({
      url: `${url}/alarm_push_url`,
      method: 'put',
      data:params
    });
  },
  getAllEventSwitchInfo(){
    return request({
      url: `${url}/all_event_switch_info`,
      method: 'get',
    });
  },
  // setHelmetSwitch(params) {
  //   //安全帽开关
  //   return request({
  //     url: `${url}/helmet_on_off`,
  //     method: 'put',
  //     data:{eventSwitch:params}
  //   });
  // },
  // setRespiratorSwitch(params) {
  //   //口罩开关
  //   return request({
  //     url: `${url}/respirator_on_off`,
  //     method: 'put',
  //     data:{eventSwitch:params}
  //   });
  // }
  setBaseEventsSwitch(code, eventSwitch) {
    //全部接口开关
    // code: 事件类型 1:陌生人比中开关，2:临时访客库是否为前端比对库 3:口罩告警推送开关 4: 安全帽告警推送开关
    // eventSwitch: 通用事件开关 0代表关闭，1代表开启 默认为关闭
    return request({
      url: `${url}/base_events_switch`,
      method: 'put',
      data:{code , eventSwitch}
    });
  }
}
