import request from '@/utils/request';
const host = window.globalConfig.timezoneHost;
const ruleHost = window.globalConfig.acHost;
const deviceHost = window.globalConfig.deviceHost;
const libraryHost = window.globalConfig.portrait;

export function getDevicesTreeData(params) {//获取设备树deviceType 1-Camera，2-SenseKeeper，空值表示查询所有设备， 20-keeper和无感门禁设备
  return request({//filter 过滤绑定过任务的设备，1-是，0-否，默认值0
    url: deviceHost+'/api/v1/device-groups/devices/tree',
    method: 'get',
    params:params
  });
}
export function getTDTasks(data) {//TD tasks
  return request({
    url: ruleHost+'/api/v1/td/tasks/query',
    method: 'post',
    data:{...data}
  });
}
export function getACTasks(data) {//AC tasks
  return request({
    url: ruleHost+'/api/v1/ac/tasks/query',
    method: 'post',
    data:{...data}
  });
}
export function getPCTasks(data) {//PC tasks

  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks/query',
    method: 'post',
    data:{...data}
  });
}
export function getPAITasks(data) {//PAI tasks
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks/query',
    method: 'post',
    data:{...data}
  });
}
export function getVPITasks(data) {//VPI tasks
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks/query',
    method: 'post',
    data:{...data}
  });
}

export function getCSTasks(data) {//VPI tasks
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks/query',
    method: 'post',
    data:{...data}
  });
}


export function addPCTasks(data) {//PC tasks
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks',
    method: 'post',
    data:{...data}
  });
}

export function addPAITasks(data) {//PAI tasks
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks',
    method: 'post',
    data:{...data}
  });
}

export function addVPITasks(data) {//VPI tasks
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks',
    method: 'post',
    data:{...data}
  });
}
export function addCSTasks(data) {//VPI tasks
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks',
    method: 'post',
    data:{...data}
  });
}

export function startTDTask(taskId) {//start TD task
  return request({
    url: ruleHost+'/api/v1/td/tasks/start/'+taskId,
    method: 'post',
    data:{}
  });
}
export function stopTDTask(taskId) {//stop TD task
  return request({
    url: ruleHost+'/api/v1/td/tasks/stop/'+taskId,
    method: 'post',
    data:{}
  });
}

export function startACTask(taskId) {//start AC task
  return request({
    url: ruleHost+'/api/v1/ac/tasks/start/'+taskId,
    method: 'post',
    data:{}
  });
}
export function stopACTask(taskId) {//stop AC task
  return request({
    url: ruleHost+'/api/v1/ac/tasks/stop/'+taskId,
    method: 'post',
    data:{}
  });
}

export function startPCTask(taskId) {//start PC task
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks/start/'+taskId,
    method: 'post',
    data:{}
  });
}
export function stopPCTask(taskId) {//stop PC task
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks/stop/'+taskId,
    method: 'post',
    data:{}
  });
}

export function startPAITask(taskId) {//start PAI task
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks/start/'+taskId,
    method: 'post',
    data:{}
  });
}
export function stopPAITask(taskId) {//stop PAI task
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks/stop/'+taskId,
    method: 'post',
    data:{}
  });
}

export function startVPITask(taskId) {//start VPI task
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks/start/'+taskId,
    method: 'post',
    data:{}
  });
}
export function stopVPITask(taskId) {//stop VPI task
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks/stop/'+taskId,
    method: 'post',
    data:{}
  });
}
export function startCSTask(taskId) {//start CS task
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks/enable/'+taskId,
    method: 'put',
    data:{}
  });
}
export function stopCSTask(taskId) {//stop CS task
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks/disable/'+taskId,
    method: 'put',
    data:{}
  });
}
export function deleteTDTask(taskId) {//delete td
  return request({
    url: ruleHost+'/api/v1/td/tasks/'+taskId,
    method: 'delete'
  });
}
export function deleteACTask(taskId) {//delete ac
  return request({
    url: ruleHost+'/api/v1/ac/tasks/'+taskId,
    method: 'delete'
  });
}
export function deletePCTask(taskId) {//delete pc
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks/'+taskId,
    method: 'delete'
  });
}
export function deletePAITask(taskId) {//delete pai
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks/'+taskId,
    method: 'delete'
  });
}
export function deleteVPITask(taskId) {//delete vpi
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks/'+taskId,
    method: 'delete'
  });
}
export function deleteCSTask(taskId) {//delete CS
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks/'+taskId,
    method: 'delete'
  });
}

export function startTDTasksBatch(taskIds) {//batch start td task
  return request({
    url: ruleHost+'/api/v1/td/tasks/batch/start',
    method: 'post',
    data:{taskIds}
  });
}
export function stopTDTasksBatch(taskIds) {//batch stop td task
  return request({
    url: ruleHost+'/api/v1/td/tasks/batch/stop',
    method: 'post',
    data:{taskIds}
  });
}
export function deleteTDTasksBatch(taskIds) {//delete stop td task
  return request({
    url: ruleHost+'/api/v1/td/tasks/batch',
    method: 'delete',
    data:{taskIds}
  });
}

export function startACTasksBatch(taskIds) {//batch start AC task
  return request({
    url: ruleHost+'/api/v1/ac/tasks/batch/start',
    method: 'post',
    data:{taskIds}
  });
}
export function stopACTasksBatch(taskIds) {//batch stop AC task
  return request({
    url: ruleHost+'/api/v1/ac/tasks/batch/stop',
    method: 'post',
    data:{taskIds}
  });
}
export function deleteACTasksBatch(taskIds) {//delete stop AC task
  return request({
    url: ruleHost+'/api/v1/ac/tasks/batch/delete',
    method: 'delete',
    data:{taskIds}
  });
}

export function startPCTasksBatch(taskIds) {//batch start PC task
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks/batch/start',
    method: 'post',
    data:{taskIds}
  });
}
export function stopPCTasksBatch(taskIds) {//batch stop PC task
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks/batch/stop',
    method: 'post',
    data:{taskIds}
  });
}
export function deletePCTasksBatch(taskIds) {//delete stop PC task
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks/batch/delete',
    method: 'delete',
    data:{taskIds}
  });
}

export function startPAITasksBatch(taskIds) {//batch start PAI task
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks/batch/start',
    method: 'post',
    data:{taskIds}
  });
}
export function stopPAITasksBatch(taskIds) {//batch stop PAI task
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks/batch/stop',
    method: 'post',
    data:{taskIds}
  });
}

export function startVPITasksBatch(taskIds) {//batch start VPI task
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks/batch/start',
    method: 'post',
    data:{taskIds}
  });
}
export function stopVPITasksBatch(taskIds) {//batch stop VPI task
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks/batch/stop',
    method: 'post',
    data:{taskIds}
  });
}
export function startCSTasksBatch(taskIds) {//batch start CS task
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks/batch/enable',
    method: 'put',
    data:{taskIds}
  });
}
export function stopCSTasksBatch(taskIds) {//batch stop CS task
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks/batch/disable',
    method: 'put',
    data:{taskIds}
  });
}
export function deletePAITasksBatch(taskIds) {//delete PAI task batch
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks/batch/delete',
    method: 'delete',
    data:{taskIds}
  });
}
export function deleteVPITasksBatch(taskIds) {//delete VPI task batch
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks/batch/delete',
    method: 'delete',
    data:{taskIds}
  });
}
export function deleteCSTasksBatch(taskIds) {//delete CS task batch
  return request({
    url: ruleHost+'/api/v1/crowd/surveillance/tasks/batch/delete',
    method: 'delete',
    data:{taskIds}
  });
}
export function getPCTaskDetail(taskId) {//PC tasks detail
  return request({
    url: ruleHost+`/api/v1/pedestrian_cross/tasks/query_details/${taskId}`,
    method: 'get',
    params:{}
  });
}

export function getPAITaskDetail(taskId) {//PC tasks detail
  return request({
    url: ruleHost+`/api/v1/pedestrians/tasks/query_details/${taskId}`,
    method: 'get',
    params:{}
  });
}

export function getVPITaskDetail(taskId) {//PC tasks detail
  return request({
    url: ruleHost+`/api/v1/car_violate_stop/tasks/query_details/${taskId}`,
    method: 'get',
    params:{}
  });
}
export function getCSTaskDetail(taskId) {//PC tasks detail
  return request({
    url: ruleHost+`/api/v1/crowd/surveillance/tasks/query/detail/${taskId}`,
    method: 'get',
    params:{}
  });
}


export function editPCTask(params) {//edit PC task
  return request({
    url: ruleHost+'/api/v1/pedestrian_cross/tasks',
    method: 'put',
    data:{...params}
  });
}
export function editPAITask(params) {//edit PAI task
  return request({
    url: ruleHost+'/api/v1/pedestrians/tasks',
    method: 'put',
    data:{...params}
  });
}

export function editVPITask(params) {//edit PAI task
  return request({
    url: ruleHost+'/api/v1/car_violate_stop/tasks',
    method: 'put',
    data:{...params}
  });
}
export function editCSTask(params) {//edit CS task
  return request({
    url: ruleHost + '/api/v1/crowd/surveillance/tasks',
    method: 'put',
    data:{...params}
  });
}

//rules
// export function getACRule(params) {//获取ac rule 列表（包括检索）
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/group',
//     method: 'get',
//     params: {...params}
//   });
// }
// export function addACRule(params) {//新增timezone-intervals
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks',
//     method: 'post',
//     data:{...params}
//   });
// }
// export function getSpecialAttrs(type) {//获取特殊属性 0-ac 1-td
//   return request({
//     url: ruleHost+'/api/v1/common/tasks/attributes/'+type,
//     method: 'get',
//   });
// }
// export function getDevices(params) {//获取设备列表（联调用）
//   return request({
//     url: deviceHost+'/api/v1/devices',
//     method: 'get',
//     params: {...params}
//   });
// }
// export function editGroupName(params) {//修改组名称（ac、td）
//   return request({
//     url: ruleHost+'/api/v1/common/tasks/group',
//     method: 'put',
//     data:{...params}
//   });
// }
// export function deleteRulesGroup(groupId) {//删除group
//   return request({
//     url: ruleHost+'/api/v1/common/tasks/group/'+groupId,
//     method: 'delete'
//   });
// }
// export function getRuleDetail(ruleId) {//获取ac规则详情
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/'+ruleId,
//     method: 'get'
//   });
// }
// export function editRuleAC(params,acRuleId) {//修改ac rule
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/'+acRuleId,
//     method: 'put',
//     data:{...params}
//   });
// }
// export function deleteRuleAc(ruleId) {//删除group
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/'+ruleId,
//     method: 'delete'
//   });
// }
// export function getRulesACList(data,groupId) {//获取AC tasks
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/group/'+groupId,
//     method: 'post',
//     data:{...data}
//   });
// }
// export function addTDRule(params) {//create rule td
//   return request({
//     url: ruleHost+'/api/v1/td/tasks',
//     method: 'post',
//     data:{...params}
//   });
// }
// export function addTDRulesMultiple(params) {//批量create rules td
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/batch',
//     method: 'post',
//     data:{...params}
//   });
// }
// export function getRuleListByKeepers(deviceIds) {//根据keeper获取AC rule
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/list',
//     method: 'post',
//     data:{deviceIds}
//   });
// }
// export function startRuleAC(ruleId) {//开启ac rule
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/start/'+ruleId,
//     method: 'post',
//     data:{}
//   });
// }
// export function stopRuleAC(ruleId) {//关闭ac rule
//   return request({
//     url: ruleHost+'/api/v1/ac/tasks/stop/'+ruleId,
//     method: 'post',
//     data:{}
//   });
// }
// export function startRuleTD(ruleId) {//开启td rule
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/start/'+ruleId,
//     method: 'post',
//     data:{}
//   });
// }
// export function stopRuleTD(ruleId) {//关闭td rule
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/stop/'+ruleId,
//     method: 'post',
//     data:{}
//   });
// }
// export function deleteRuleTD(ruleId) {//删除rule TD
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/'+ruleId,
//     method: 'delete'
//   });
// }
// export function startRuleTDBatch(taskIds) {//批量开启td rule
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/batch/start',
//     method: 'post',
//     data:{taskIds}
//   });
// }
// export function stopRuleTDBatch(taskIds) {//批量关闭td rule
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/batch/stop',
//     method: 'post',
//     data:{taskIds}
//   });
// }
// export function deleteRuleTDBatch(taskIds) {//批量删除rule TD
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/batch',
//     method: 'delete',
//     data:{taskIds}
//   });
// }
// export function getRulesTDList(data,groupId) {//获取td组内规则
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/group/'+groupId,
//     method: 'post',
//     data:{...data}
//   });
// }
// export function getGroupsTDList(data) {//获取td组内规则
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/group',
//     method: 'get',
//     params:{...data}
//   });
// }
// export function getLibsList(keywords?) {//获取人像库列表
//   return request({
//     url: libraryHost+'/libraries',
//     method: 'get',
//     params:{keywords}
//   });
// }
// export function getRuleTDDetail(taskId) {//获取td详情
//   return request({
//     url: ruleHost+'/api/v1/td/tasks/'+taskId,
//     method: 'get',
//   });
// }
// export function getDevicesTreeData(params) {//获取设备树deviceType 1-Camera，2-SenseKeeper，空值表示查询所有设备， 20-keeper和无感门禁设备
//   return request({//filter 过滤绑定过任务的设备，1-是，0-否，默认值0
//     url: deviceHost+'/api/v1/device-groups/devices/tree',
//     method: 'get',
//     params:params
//   });
// }
// export function updateRuleTd(params) {//修改td rule
//   return request({
//     url: ruleHost+'/api/v1/td/tasks',
//     method: 'put',
//     data:params
//   });
// }
// export function getDevicesGroupTreeData() {//获取设备分组树deviceType
//   return request({
//     url: deviceHost+'/api/v1/device-groups/tree',
//     method: 'get',
//   });
// }
