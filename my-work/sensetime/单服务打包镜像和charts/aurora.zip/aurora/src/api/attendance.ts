import request from '@/utils/request';
var url = window.globalConfig.attendance;

export default {
  //公司考勤按月导出
  exportCompany(params:any){
    return request({
      url: `${url}/attendance/exportCompanyData`,
      // url: `http://10.11.172.82:8088/senseguard-attendance-management/api/v1/attendance/exportCompanyData`,
      method: 'post',
      data:params
    });
  },
  //公司考勤按日导出
  exportCompanyDataDay(params:any){
    return request({
      url: `${url}/attendance/export_company_data_day`,
      method: 'post',
      data:params
    });
  },
  //个人考勤导出
  exportPersonalData(params){
    return request({
      url: `${url}/attendance/exportPersonalData`,
      method: 'post',
      data:params
    });
  },
  //考勤配置
  attendanceConfig(params){
    return request({
      url: `${url}/attendance/config`,
      method: 'post',
      data:params
    });
  },
  //考勤配置列表
  attendanceListConfig(params){
    return request({
      url: `${url}/attendance/listConfig`,
      method: 'post',
      params
    });
  },
  //变更员工考勤状态
  modifyAttendanceInfoRequest(params){
    return request({
      //url: `${url}/attendance/modifyAttendanceInfoRequest`,
      url: `${url}/attendance/modifyAttendanceStatus`,
      method: 'post',
      data:params
    });
  },

  //考勤总览数据
  attendanceGlobal(params:any){
    return request({
      url: `${url}/attendance/queryGlobalAttendceStatis`,
      method: 'post',
      params
    });
  },

  //考勤列表数据
  attendanceList(params:any){
    return request({
      url: `${url}/attendance/queryAttendanceStatisList`,
      method: 'post',
      data:params
    });
  },

  //员工考勤记录
  attendanceStaffList(params:any){
    return request({
      url: `${url}/attendance/queryStaffAttendanceList`,
      method: 'post',
      params
    });
  },

  //员工某天考勤详情
  attendanceStaffDetail(params:any){
    return request({
      url: `${url}/attendance/listStaffAttendanceDetail`,
      method: 'post',
      params
    });
  },

  //员工某天考勤详情
  attendanceStaffInfo(params:any){
    return request({
      url: `${url}/attendance/queryStaffStaticsInfo`,
      method: 'post',
      params
    });
  },

  //考勤状态列表（timeFlag：考勤时段标识,0:上午,1:下午）
  listAttendanceStatus(params){
    return request({
      url: `${url}/attendance/listAttendanceStatus`,
      method: 'post',
      params
    });
  },

  //当天全部考勤
  queryAttendanceList(params) {
    return request({
      url: `${url}/attendance/queryAttendanceList`,
      method: 'post',
      data:params
    });
  }

}
