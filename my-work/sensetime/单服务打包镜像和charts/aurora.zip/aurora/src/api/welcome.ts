import request from '@/utils/request';
const ruleHost = window.globalConfig.acHost;
const login = window.globalConfig.login;

export function getWelcomeList(params) {
    return request({
      url: ruleHost+`/api/v1/greet/guests/list`,
      method: 'get',
      params
    });
  }

  export function startTDTask(taskId) {//start TD task
    return request({
      url: ruleHost+'/api/v1/td/tasks/start/'+taskId,
      method: 'post',
      data:{}
    });
  }
  export function stopTDTask(taskId) {//stop TD task
    return request({
      url: ruleHost+'/api/v1/td/tasks/stop/'+taskId,
      method: 'post',
      data:{}
    });
  }
  export function getWelcomeGuestNumber(taskId) {
    return request({
      url: ruleHost+`/api/v1/greet/guests/${taskId}`,
      method: 'get',
      params:{}
    });
  }

  export function refreshToken() {
    return request({
      url: login+`/refresh_token`,
      method: 'post',
      params:{}
    });
  }
  