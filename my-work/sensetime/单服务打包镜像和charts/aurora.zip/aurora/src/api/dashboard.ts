import request from '@/utils/request';

let dashboard = window.globalConfig.dashboard;

export default {
  //库容统计
  capacityCount(params:any) {
    return request({
      url: `${dashboard}/capacity/count`,
      method: 'get',
      params
    });
  },
 
  //今日抓拍统计
  captureCount(params:any) {
    return request({
      url: `${dashboard}/capture/count`,
      method: 'get',
      data: params
    });
  },

  //设备统计
  deviceCount(params:any) {
    return request({
      url: `${dashboard}/device/count`,
      method: 'get',
      params
    });
  },

  //事件告警
  eventAlarmCount(params:any) {
    return request({
      url: `${dashboard}/event/alarm/count`,
      method: 'get',
      params
    });
  },
}
