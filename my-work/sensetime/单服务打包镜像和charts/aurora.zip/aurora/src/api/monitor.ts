import request from '@/utils/request';
const deviceHost = window.globalConfig.deviceHost;
const ruleHost = window.globalConfig.acHost;
const toolHost = window.globalConfig.toolHost;

export default {
  getDevicesTreeData(params) {//获取设备树deviceType 1-Camera，2-SenseKeeper，空值表示查询所有设备
    return request({//filter 过滤绑定过任务的设备，1-是，0-否，默认值0
      url: deviceHost+'/api/v1/device-groups/devices/tree',
      method: 'get',
      params:params
    });
  },
  getRuleGroups() {
    return request({
      url: ruleHost+'/api/v1/common/tasks/group',
      method: 'get',
    });
  },
  getVideoPathWithFrame(deviceId){
    return request({
      url:deviceHost+`/api/v1/devices/${deviceId}/rtsp_preview_address`,
      method: 'get',
    });
  },
  getDisplayWarnLimit(deviceId){
    return request({
      url:deviceHost+`/api/v1/devices/display_warn_limit/${deviceId}`,
      method: 'get',
    });
  },
  getTasks(taskTypes){//
    return request({// 任务类型列表,任务类型 0–门禁 1–布控 2–区域入侵 3–行人越线 4–车辆违停
      url: ruleHost+`/api/v1/common/tasks/query_tasks_by_type`,
      method: 'post',
      data:{taskTypes}
    });
  },
  getServerTime(){
    return request({
      url:toolHost+`/current_time`,
      method: 'get',
    });
  }
}

