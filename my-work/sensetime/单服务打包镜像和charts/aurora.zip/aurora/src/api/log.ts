import request from '@/utils/request';

var url = window.globalConfig.log

export default {
  //获取日志列表
  getLogList(params, str) {
    return request({
      url: str == '' ? `${url}/logs` : `${url}/logs?orgIds=` + str,
      method: 'get',
      params
    });
  },

  //获取日志检索条件
  getLogSearchCondition(params) {
    return request({
      url: `${url}/logs/modules`,
      method: 'get',
      params
    });
  },

  //获取日志检索条件
  exportLog(params) {
    return request({
      url: `${url}/logs/export-query`,
      method: 'post',
      data: params
    });
  }
}
