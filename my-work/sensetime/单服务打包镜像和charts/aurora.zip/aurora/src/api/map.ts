import request from '@/utils/request';
var host = window.globalConfig;
//console.log(host)

export default {

  //楼层列表
  floorList(){
    return request({
      url: `${host.map}/floor/list`,
      method: 'post',
      data: {},
    });
  },

  //创建楼层
  mapTreeAdd(formData:any){
    return request({
      url: `${host.map}/floor`,
      method: 'post',
      data: {
        name:formData.name,
        parentId:formData.parentId,
        floorId:formData.floorId,
      },
    });
  },

  //修改楼层
  mapTreeEdit(formData:any){
    return request({
      url: `${host.map}/floor`,
      method: 'put',
      data: {
        name:formData.name,
        parentId:formData.parentId,
        floorId:formData.floorId,
      },
    });
  },

  //删除楼层
  mapTreeDelete(formData:any){
    return request({
      url: `${host.map}/floor/${formData.floorId}/${formData.state}`,
      method: 'delete',
      data: {
        id:formData.floorId,
        state:formData.state,
      },
    });
  },

  //上传地图
  mapUpload(param: any){
    if(param.type =="change"){
      return `${host.map}/floor/update/${param.id}/1`
    }else{
      return `${host.map}/floor/upload/${param.id}`
    }
  },

  //更换地图
  mapImgUpdate(formData:any){
    return request({
      url: `${host.map}/floor/update/${formData.id}/${formData.state}`,
      method: 'post',
      data: {
        id:formData.id,
        state:formData.state,
      },
    });
  },

  //删除地图
  mapImgDelete(formData:any){
    return request({
      url: `${host.map}/floor/map/${formData.id}/${formData.state}`,
      method: 'delete',
      data: {
        id:formData.id,
        state:formData.state,
      },
    });
  },

  //获取地图数据
  getMapGeojson(floorId:any){
    return request({
      url: `${host.map}/floor/map/${floorId.id}`,
      method: 'get',
      data: {
        id:floorId
      }
    });
  },

  //是否叶子节点
  getisLeaf(floorInfo:any){
    return request({
      url: `${host.map}/floor/children/${floorInfo.id}`,
      method: 'get',
      data: {
        id:floorInfo.id
      }
    });
  },

  //获取热力图数据
  getHeatMap(floorId:any){
    return request({
      url: `${host.heatMap}/heatMap/${floorId}`,
      method: 'get',
      data: {
        id:floorId
      }
    });
  },

  //上传地图
  getMapData(id: string){
    return `${host.map}/floor/map/${id}`
  },

//区域操作

  //区域绘制
  regionCreate(regionInfo:any){
    return request({
      url: `${host.map}/region/draw`,
      method: 'post',
      data: {
        name      :regionInfo.areaName,
        type      :regionInfo.type,
        floorId   :regionInfo.floorId,
        region    :[regionInfo.region],
        labelList :regionInfo.tagList,
      },
    });
  },

  //区域绘制
  regionUpdate(regionInfo:any){
    console.log(regionInfo)
    return request({
      url: `${host.map}/region/update`,
      method: 'post',
      data: {
        id        :regionInfo.id,
        name      :regionInfo.areaName,
        type      :regionInfo.type,
        floorId   :regionInfo.floorId,
        region    :[regionInfo.region],
        labelList :regionInfo.tagList,
      },
    });
  },

  //区域删除
  regionDelect(regionInfo:any){
    return request({
      url: `${host.map}/region/delete/${regionInfo.id}/${regionInfo.state}`,
      method: 'DELETE',
      //data: regionInfo,
    });
  },

  //获取区域标签
  getRegionTagList(){
    return request({
      url: `${host.map}/region/labels`,
      method: 'get',
      data: {}
    });
  },

  //导出轨迹
  exportTrack(param:any){
    return request({
      url: `${host.historyExport}/trajectoryExport`,
      method: 'post',
      data: param
    });
  },
  //
  validateToken() {
    return request({
      url: `${host}/userInfo`,
      method: 'get',
    });
  },

  logout() {
    return request({
      url: '${host}/logout`',
      method: 'post',
    });
  }
}
