import request from '@/utils/request'
const libraryHost = window.globalConfig
  .portrait
const visitorHost = window.globalConfig
  .visitor
export default {
  getLibsList(keywords?) {
    //获取人像库列表
    return request({
      url: libraryHost + '/libraries',
      method: 'get',
      params: { keywords }
    })
  },

  getVisitorList(data) {
    //获取访客列表
    return request({
      url: visitorHost + '/guest/queryListByPage',
      method: 'post',
      data
    })
  },
  addVisitorRecord(params) {
    //添加访客
    return request({
      url: visitorHost + '/guest/addGuest',
      method: 'post',
      data: params
    })
  },
  addReservation(params) {
    //添加预约信息
    return request({
      url: visitorHost + '/guest/addReservation',
      method: 'post',
      data: params
    })
  },
  updateVisitInfo(params) {
    //修改到访信息
    return request({
      url: visitorHost + '/guest/visit_info',
      method: 'post',
      data: params
    })
  },
  updateReservation(params) {
    //修改预约信息
    return request({
      url: visitorHost + '/guest/updateReservation',
      method: 'post',
      data: params
    })
  },
  getVisitorStatistics() {
    //获取访客统计信息
    return request({
      url: visitorHost + '/guest/guestCount',
      method: 'get'
    })
  },
  delGuest(id) {
    //删除访客
    return request({
      url: visitorHost + '/guest/delGuest/' + id,
      method: 'delete'
    })
  },
  queryGuestInfoByGuestId(id) {
    //查询访客详情
    return request({
      url: visitorHost + '/guest/queryGuestInfoByGuestId/' + id,
      method: 'get'
    })
  },
  exportVisitorData(params) {
    //查询访客详情
    return request({
      url: visitorHost + '/guest/export',
      method: 'post',
      data: params
    })
  },
  deleteGuestBatch(params) {
    return request({
      url: visitorHost + '/guest/batch',
      method: 'delete',
      data: params
    })
  }
}
