import request from '@/utils/request';
const host = window.globalConfig.timezoneHost;
const ruleHost = window.globalConfig.acHost;
const deviceHost = window.globalConfig.deviceHost;
const libraryHost = window.globalConfig.portrait;

//timezone
export function getHolidayList(iden: number) {
  return request({
    url: host+'/api/v1/holidays',
    method: 'get',
    params: {iden}
  });
}
export function addHoliday(holidayName: string,hdate:string,order:number) {
  return request({
    url: host+'/api/v1/holidays',
    method: 'post',
    data: {holidayName,hdate,iden:0,order}//iden = 0 holiday
  });
}
export function editHoliday(params,holidayId,iden) {//可修改 holidayName hdate 两个字段 iden:0 h  iden:1 w
  return request({
    url: host+'/api/v1/holidays',
    method: 'put',
    data: {...params,holidayId:holidayId,iden}
  });
}
export function addWorkday(holidayName: string,hdate:string,order:number) {
  return request({
    url: host+'/api/v1/holidays',
    method: 'post',
    data: {holidayName,hdate,iden:1,order}//iden = 1 workday
  });
}
export function editWorkday(params,workdayId) {//可修改 holidayName hdate 两个字段
  return request({
    url: host+'/api/v1/holidays',
    method: 'put',
    data: {...params,holidayId:workdayId}
  });
}
export function deleteDay(id) {//删除 holiday 或 workday
  return request({
    url: host+'/api/v1/holidays/'+id,
    method: 'delete',
  });
}
export function getTimezone() {//查询timezone name（只用name）
  return request({
    url: host+'/api/v1/timezones',
    method: 'get',
  });
}
export function getTimezoneWithIntervals() {//查询timezone(含有interval) name（只用name）
  return request({
    url: host+'/api/v1/query_timezone_except_intervals',
    method: 'get',
  });
}
export function editTimezone(params,timeZoneId) {//修改timezone name
  return request({
    url: host+'/api/v1/timezones/'+timeZoneId,
    method: 'put',
    data:{...params}
  });
}
export function addTimezone(timeZoneName) {//新增timezone
  return request({
    url: host+'/api/v1/timezones',
    method: 'post',
    data:{timeZoneName}
  });
}
export function deleteTimezone(timezoneId) {//删除timezone
  return request({
    url: host+'/api/v1/timezones/'+timezoneId,
    method: 'delete',
  });
}
export function getTimezoneIntervals(timeZoneId) {//查询timezone-intervals
  return request({
    url: host+'/api/v1/intervals',
    method: 'get',
    params:{timeZoneId}
  });
}
export function addTimezoneIntervals(params) {//新增timezone-intervals
  return request({
    url: host+'/api/v1/intervals',
    method: 'post',
    data:{...params}
  });
}
export function editTimezoneIntervals(params) {//修改timezone-intervals
  return request({
    url: host+'/api/v1/intervals',
    method: 'put',
    data:{...params}
  });
}
export function deleteTimezoneIntervals(intervalId) {//删除timezone-intervals
  return request({
    url: host+'/api/v1/intervals/'+intervalId,
    method: 'delete',
  });
}
//rules
export function getACRule(params) {//获取ac rule 列表（包括检索）
  return request({
    url: ruleHost+'/api/v1/ac/tasks/group',
    method: 'get',
    params: {...params}
  });
}
export function addACRule(params) {//新增timezone-intervals
  return request({
    url: ruleHost+'/api/v1/ac/tasks',
    method: 'post',
    data:{...params}
  });
}
export function getSpecialAttrs(type) {//获取特殊属性 0-ac 1-td
  return request({
    url: ruleHost+'/api/v1/common/tasks/attributes/'+type,
    method: 'get',
  });
}
export function getDevices(params) {//获取设备列表（联调用）
  return request({
    url: deviceHost+'/api/v1/devices',
    method: 'get',
    params: {...params}
  });
}
export function editGroupName(params) {//修改组名称（ac、td）
  return request({
    url: ruleHost+'/api/v1/common/tasks/group',
    method: 'put',
    data:{...params}
  });
}
export function deleteRulesGroup(groupId) {//删除group
  return request({
    url: ruleHost+'/api/v1/common/tasks/group/'+groupId,
    method: 'delete'
  });
}
export function getRuleDetail(ruleId) {//获取ac规则详情
  return request({
    url: ruleHost+'/api/v1/ac/tasks/'+ruleId,
    method: 'get'
  });
}
export function editRuleAC(params,acRuleId) {//修改ac rule
  return request({
    url: ruleHost+'/api/v1/ac/tasks/'+acRuleId,
    method: 'put',
    data:{...params}
  });
}
export function deleteRuleAc(ruleId) {//删除group
  return request({
    url: ruleHost+'/api/v1/ac/tasks/'+ruleId,
    method: 'delete'
  });
}
export function getRulesACList(data,groupId) {//获取AC组内规则
  return request({
    url: ruleHost+'/api/v1/ac/tasks/group/'+groupId,
    method: 'post',
    data:{...data}
  });
}
export function addTDRule(params) {//create rule td
  return request({
    url: ruleHost+'/api/v1/td/tasks',
    method: 'post',
    data:{...params}
  });
}
export function addTDRulesMultiple(params) {//批量create rules td
  return request({
    url: ruleHost+'/api/v1/td/tasks/batch',
    method: 'post',
    data:{...params}
  });
}
export function getRuleListByKeepers(deviceIds) {//根据keeper获取AC rule
  return request({
    url: ruleHost+'/api/v1/ac/tasks/list',
    method: 'post',
    data:{deviceIds}
  });
}
export function startRuleAC(ruleId) {//开启ac rule
  return request({
    url: ruleHost+'/api/v1/ac/tasks/start/'+ruleId,
    method: 'post',
    data:{}
  });
}
export function stopRuleAC(ruleId) {//关闭ac rule
  return request({
    url: ruleHost+'/api/v1/ac/tasks/stop/'+ruleId,
    method: 'post',
    data:{}
  });
}
export function startRuleTD(ruleId) {//开启td rule
  return request({
    url: ruleHost+'/api/v1/td/tasks/start/'+ruleId,
    method: 'post',
    data:{}
  });
}
export function stopRuleTD(ruleId) {//关闭td rule
  return request({
    url: ruleHost+'/api/v1/td/tasks/stop/'+ruleId,
    method: 'post',
    data:{}
  });
}
export function deleteRuleTD(ruleId) {//删除rule TD
  return request({
    url: ruleHost+'/api/v1/td/tasks/'+ruleId,
    method: 'delete'
  });
}
export function startRuleTDBatch(taskIds) {//批量开启td rule
  return request({
    url: ruleHost+'/api/v1/td/tasks/batch/start',
    method: 'post',
    data:{taskIds}
  });
}
export function stopRuleTDBatch(taskIds) {//批量关闭td rule
  return request({
    url: ruleHost+'/api/v1/td/tasks/batch/stop',
    method: 'post',
    data:{taskIds}
  });
}
export function deleteRuleTDBatch(taskIds) {//批量删除rule TD
  return request({
    url: ruleHost+'/api/v1/td/tasks/batch',
    method: 'delete',
    data:{taskIds}
  });
}
export function getRulesTDList(data,groupId) {//获取td组内规则
  return request({
    url: ruleHost+'/api/v1/td/tasks/group/'+groupId,
    method: 'post',
    data:{...data}
  });
}
export function getGroupsTDList(data) {//获取td组内规则
  return request({
    url: ruleHost+'/api/v1/td/tasks/group',
    method: 'get',
    params:{...data}
  });
}
export function getLibsList(keywords?) {//获取人像库列表
  return request({
    url: libraryHost+'/libraries',
    method: 'get',
    params:{keywords}
  });
}
export function getRuleTDDetail(taskId) {//获取td详情
  return request({
    url: ruleHost+'/api/v1/td/tasks/'+taskId,
    method: 'get',
  });
}
export function getDevicesTreeData(params) {//获取设备树deviceType 1-Camera，2-SenseKeeper，空值表示查询所有设备， 20-keeper和无感门禁设备
  return request({//filter 过滤绑定过任务的设备，1-是，0-否，默认值0
    url: deviceHost+'/api/v1/device-groups/devices/tree',
    method: 'get',
    params:params
  });
}
export function updateRuleTd(params) {//修改td rule
  return request({
    url: ruleHost+'/api/v1/td/tasks',
    method: 'put',
    data:params
  });
}
export function getDevicesGroupTreeData() {//获取设备分组树deviceType
  return request({
    url: deviceHost+'/api/v1/device-groups/tree',
    method: 'get',
  });
}
