import request from '@/utils/request';
// import config from '../../config.js';
// var url = config.url.login;
var url = window.globalConfig.history
var exportUrl = window.globalConfig.retrivalExport
const acHost = window.globalConfig.acHost;
const portrait = window.globalConfig.portrait;
const device = window.globalConfig.device;
const role = window.globalConfig.role;
const record = window.globalConfig.record;
const generateTrack = window.globalConfig.generateTrack;
const mapHost = window.globalConfig.map;
const historyExport = window.globalConfig.historyExport;
export default {
  searchCaptureLib(data){
    return request({
      url: `${url}/face/timespace/search`,
      method: 'post',
      data,
    });
  },
  searchFacialLib(data){
    return request({
      url: `${url}/face/static/search`,
      method: 'post',
      data,
    });
  },
  fetchCaptureRecordTop100(data){
    return request({
      url: `${url}/face/target/detail`,
      method: 'post',
      data,
    });
  },
  fetchRuleName(){
    return request({
      url: acHost+'/api/v1/common/tasks/group',
      method: 'get',
    });
  },
  fetchDepartment(){
    return request({
      url: role+'/orgs/tree',
      method: 'get',
    });
  },
  fetchLibrary(){
    return request({
      url: portrait+'/libraries',
      method: 'get',
    });
  },
  fetchDevice(){
    return request({
      url: device+'/device-groups/devices/tree?filter=0',
      method: 'get',
    });
  },
  fetchLocation(){
    return request({
      url: mapHost+'/floor/list',
      method: 'post',
      data:{}
    });
  },
  fetchRecordList(data){
    return request({
      url: record+"/query_records",
      method: 'post',
      data,
    });
  },
  fetchRecordDetail(data){
    return request({
      url: record+"/query_records_details",
      method: 'post',
      data,
    });
  },
  checkCompareStatus(data){ //type :  '1'(行人) , '2'(非机动车) , '3'(机动车)
    return request({
      url: record+"/histories",
      method: 'post',
      data,
    });
  },
  // getCaptureTrack(data){
  //   return request({
  //     url: generateTrack+"/snap-trajector",
  //     method: 'post',
  //     data,
  //   });
  // },
  getLibraryTrack(data){
    return request({
      url: generateTrack+"/library-trajector",
      method: 'post',
      data,
    });
  },

  //轨迹-每天
  // /senseguard-lbs/api/v1/day-library-trajector/{dayTime}/{uuidSerial}
  getTrackDay(param:any){
    //console.log(param)
    return request({
      url: `${generateTrack}/day-library-trajector`,
      method: 'post',
      data:param
    });
  },

  //轨迹-每天-楼层
  // /senseguard-lbs/api/v1/point-trajector/{dayTime}/{uuidSerial}/{floorId}
  getTrackDayFloor(param:any){
    return request({
      url: `${generateTrack}/point-trajector`,
      method: 'post',
      data:param
    });
  },
  exportHistoryRecord(data){
    return request({
      url: historyExport+"/export",
      method: 'post',
      data,
    });
  },
  exportHistoryDetail(data){
    return request({
      url:historyExport+"/exportDetail",
      method: 'post',
      data,
    });
  },
  exportCapture(data){
    return request({
      url: `${url}/face/timespace/export`,
      method:'post',
      data,
    });
  },
  exportFacial(data){
    return request({
      url: `${url}/face/target/export`,
      method: 'post',
      data,
    });
  },
  exportTop100(data){
    return request({
      url: `${url}/face/target/detail/export`,
      method: 'post',
      data,
    });
  },
  getPedestrians(data){ //行人
    return request({
      url: `${record}/pedestrians/query_records`,
      method: 'post',
      data,
    });
  },
  getVehiclesRecords(data){ // 车辆
    return request({
      url: `${record}/vehicles/query_records`,
      method: 'post',
      data,
    });
  },
  getNonVehiclesRecords(data){ //非机动车
    return request({
      url: `${record}/non_vehicles/query_records`,
      method: 'post',
      data,
    });
  },
  getCrowData(data){ //人群
    return request({
      url: `${record}/crow/query_records`,
      method: 'post',
      data,
    });
  },

  //查看任务名称列表
  getQueryTasksByType(data){ //[0,1]人脸,[2,3]行人, [4]机动车
    return request({
      url: `${acHost}/api/v1/common/tasks/query_tasks_by_type`,
      method: 'post',
      data,
    });
  },

  //行人导出
  exportPedestrian(data){
    return request({
      url: historyExport+"/pedestrian/export",
      method: 'post',
      data,
    });
  },

  //车辆导出
  exportVehicles(data){
    return request({
      url: historyExport+"/vehicles/export",
      method: 'post',
      data,
    });
  },

  //非机动车导出
  exportNonVehicles(data){
    return request({
      url: historyExport+"/non_vehicles/export",
      method: 'post',
      data,
    });
  },

  //人群导出
  exportCrowd(data){
    return request({
      url: historyExport+"/crowd/export",
      method: 'post',
      data,
    });
  },

  //人体以图搜图
  searchBodyByImage(data){
    return request({
      url: url+"/body/searchByImage",
      method: 'post',
      data,
    });
  },

  //人体以图搜图导出
  exportImageSearchResultRecord(data){
    return request({
      url: url+"/body/export/capture",
      method: 'post',
      data,
    });
  },

  //人体轨迹数据
  getLocusData(data){
    return request({
      url: generateTrack+"/pedestrianTrajectory",
      method: 'post',
      data,
    });
  },

  //人体轨迹导出
  trajectoryExport(data){
    return request({///api/v1/records/pedestrian/trajectory/export
      url: historyExport+`/pedestrian/trajectory/export`,
      method: 'post',
      data,
    });
  },
}
