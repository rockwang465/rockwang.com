import request from '@/utils/request';

var url = window.globalConfig.role

export default {
  //获取角色列表
  getRoleList(params) {
    return request({
      url: `${url}/roles`,
      method: 'get',
      params
    });
  },

  //导出角色
  exportRoleList(params) {
    return request({
      url: `${url}/roles/export`,
      method: 'post',
      params
    });
  },

  //获取所有的角色
  getPermissions(params) {
    return request({
      url: `${url}/roles/module/permissions`,
      method: 'get',
      params
    });
  },

  //添加角色
  addRole(params) {
    return request({
      url: `${url}/roles`,
      method: 'post',
      data: params
    });
  },

  //修改角色
  updateRole(params, id) {
    return request({
      url: `${url}/roles/` + id,
      method: 'put',
      data: params
    });
  },

  //删除角色
  deleteRole(id) {
    return request({
      url: `${url}/roles/` + id,
      method: 'delete',
    });
  },

  //查询角色权限
  detailRolePermissions(id) {
    return request({
      url: `${url}/roles/` + id + `/permissions`,
      method: 'get',
    });
  },

  //修改角色状态
  updateRoleStatus(params, id) {
    return request({
      url: `${url}/roles/` + id + `/update_state`,
      method: 'put',
      data:params
    });
  },

  //修改角色状态
  getRoleRelate() {
    return request({
      url: `${url}/roles/module/buttons`,
      method: 'get',
    });
  }
}
