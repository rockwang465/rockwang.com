import request from '@/utils/request';

var url = window.globalConfig.portrait;
var url2 = window.globalConfig.portraitUpdate;
var url3 = window.globalConfig.portraitExport;

export default {
    //获取人像黑白名单列表
  searchLibraries(params) {
    return request({
      url: `${url}/libraries`,
      method: 'get',
      params
    });
  },
  //添加树节点接口
  addPortraitNode(params){
    return request({
      url: `${url}/libraries`,
      method: 'post',
      data:params
    });
  },
  //修改分组
  reviseGroup(params, id) {
    return request({
      url: `${url}/libraries/` + id,
      method: 'put',
      data: params
    });
  },
  //删除分组
  deleteGroups(id){
    return request({
      url: `${url}/libraries/` + id,
      method: 'delete',
      timeout:100000
    });
  },
  //分组详情
  groupDetails(id) {
    return request({
      url: `${url}/libraries/` + id,
      method: 'get',
    });
  },
  //获取人像库列表
  getPortraitList(params){
    return request({
      url: `${url}/targets`,
      method: 'get',
      params,
      timeout:10000
    });
  },
  //查询人像详情
  portraitDetails(id) {
    return request({
      url: `${url}/targets/` + id,
      method: 'get',
    });
  },
  //人像添加
  portraitAdd(params){
    return request({
      url: `${url}/targets`,
      // url: `http://10.11.228.83:8080/senseguard-watchlist-management/api/v1/targets`,
      method: 'post',
      data:params
    });
  },
  //删除人像
  protraitDelete(params,id){
    return request({
      url: `${url}/targets/` + id,
      method: 'delete',
      data: params
    });
  },
  //批量删除人像
  protraitDeleteAll(params){
    return request({
      url: `${url}/targets/batch`,
      method: 'delete',
      data:params
    });
  },
  //批量复制人像到多个人像库
  protraitCopyList(params){
    return request({
      url: `${url}/targets/batch/duplicate`,
      method: 'post',
      data:params
    });
  },
  //编辑人像信息
  protraitEditData(params,id){
    return request({
      url: `${url}/targets/` + id,
      method: 'put',
      data:params
    });
  },
  //添加总照片名字
  protraitNameList(params){
    return request({
      url: `${url2}/target/addTotalFileName`,
      // url: `http://192.168.2.99:10218/senseguard-bulk-tool/api/v1/target/addTotalFileName`,
      method: 'post',
      data:params,
      timeout:60000,
    });
  },
  //查询下批次文件名
  protraitQueryNextFileName(uuid){
    return request({
      url: `${url2}/target/queryNextFileName?taskId=` + uuid,
      method: 'get',
    });
  },
  //添加批量上传人像库
  protraitAddTargetBulkTool(params){
    return request({
      url: `${url2}/target/addTargetBulkTool`,
      // url: `http://10.151.106.187:8080/senseguard-bulk-tool/api/v1/target/addTargetBulkTool`,
      method: 'post',
      data:params,
      timeout:300000,
    });
  },
  //添加批量上传人像库
  protraitGetLostFile(str:any,str2:any){
    return request({
      url: `${url2}/target/get_lost_file_names/`+ str + '/' + str2,
      method: 'get',
    });
  },

  //查询失败列表
  protraitQueryTaskList(params){
    return request({
      url: `${url2}/target/queryTaskList`,
      method: 'get',
      params
    });
  },
  //时间查询失败列表
  protraitQueryDateTimeList(params){
    return request({
      url: `${url2}/target/queryDateTimeList`,
      method: 'get',
      params
    });
  },
  //导出人像
  protraitBuildDownloadData(params){
    return request({
      url: `${url3}/target/library/build_download_data`,
      method: 'post',
      data:params
    });
  },
  //统计上传失败人像数量
  protraitUpFailCount(params){
    return request({
      url: `${url}/targets/fail/count`,
      method: 'get',
      params
    });
  },
  //分页查询上传失败人像列表
  protraitUpFailList(params){
    return request({
      url: `${url}/targets/fail/list`,
      method: 'get',
      params
    });
  },
  //根据ID查询人像详情
  protraitIdDetails(params){
    return request({
      url: `${url}/targets/detail`,
      method: 'get',
      params
    });
  },
  //检测图片人脸信息
  protraitDetection(params){
    return request({
      url: `${url}/targets/detection`,
      method: 'post',
      data:params
    });
  },
  //判断此时是否有用户在批量上传
  protraitCheckUploadState(){
    return request({
      url: `${url2}/target/checkUploadState`,
      // url: `http://10.5.3.19:8080/senseguard-bulk-tool/api/v1/target/checkUploadState`,
      method: 'post'
    });
  },
  //改变人像启用状态
  updateEnableStateByTargetId(params){
    return request({
      url: `${url}/targets/updateEnableStateByTargetId`,
      method: 'post',
      data:params
    });
  },

  //一键清空失败人像
  removeAllFailPicture(params){
    return request({
      url: `${url}/targets/a_key_to_remove_fail_picture`,
      method: 'delete',
      data:params
    });
  },

  //批量删除失败人像
  BatchRemoveFailPicture(params){
    return request({
      url: `${url}/targets/batch_delete_fail_picture`,
      method: 'delete',
      data:params
    });
  },
  getPortraitAsyncImages(params){
    return request({
      url: `${url}/link/targets`,
      method: 'get',
      params
    });
  },
  exportAsyncFailTargets(){
    return request({
      url: `${url3}/target/link/build_download_data`,
      method: 'post',
    });
  }
}
