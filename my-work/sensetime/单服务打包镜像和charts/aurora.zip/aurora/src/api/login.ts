import request from '@/utils/request'
var url = window.globalConfig.login;
var log = window.globalConfig.log;
export default {
  login(
    username: string,
    password: string,
    validCode: string,
    timestamp: string,
    rememberMe: boolean
  ) {
    return request({
      url: `${url}/vaildCodeLogin`,
      method: 'post',
      data: {
        username,
        password,
        validCode,
        timestamp,
        rememberMe
      }
    })
  },
  validateToken() {
    return request({
      url: `${url}/userInfo`,
      method: 'get'
    })
  },
  logout() {
    return request({
      url: `${url}/logout`,
      method: 'post'
    })
  },
  getSystemInfo(language) {
    return request({
      url: `${log}/system-name?language=${language}`,
      method: 'get'
    })
  }
}
