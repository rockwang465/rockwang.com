import request from '@/utils/request';
var host = window.globalConfig;
export default {


    getHotMap(){
      return request({
        url: `${host.map}/floor/crowd/crowdHeatMapGroupList`,
        method: 'get',
      });
    },
    getCrowdHeatMapInfo(floorId){
      return request({
        url: `${host.map}/floor/crowd/crowdHeatMapInfo/${floorId}`,
        method: 'get',
      });
    },
    getStatistics(floorId){
      return request({
        url: `${host.map}/floor/crowd/statistics/${floorId}`,
        method: 'get',
      });
    },
}
