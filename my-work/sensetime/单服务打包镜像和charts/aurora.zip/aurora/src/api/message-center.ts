import request from '@/utils/request';
import stompjs from 'stompjs';
import { SnPromise } from '@/utils/small-tool';
var download = window.globalConfig.download
var retryExport = window.globalConfig.retryExport
var messageCenter = window.globalConfig.messageCenter
// import '@/utils/sockjs.min.js'
import SockJS from "sockjs-client";
//top100导出
// export class Top100LibSock {
//   sock:any;
//   stompClient:any
//   constructor() {
//     this.sock = new SockJS(RetrivalExport)
//     this.stompClient= stompjs.over(this.sock)
//   }
//   connect(subscribeAdress, sendAdress, sendData){
//     var self = this;
//     return SnPromise((resolve,resolveOnce, reject)=>{
//       self.stompClient.connect({}, function (frame) {

//         self.stompClient.subscribe(subscribeAdress, function (response) {
//             resolveOnce(frame)//建立导出任务
//             resolve(response);//解析json字符串为对象
//         });
//         self.stompClient.send(sendAdress, {},JSON.stringify(sendData));
//       });
//     })
//   }
//   disconnect() {
//     var self = this;
//     if (self.stompClient !== null) {
//       self.stompClient.disconnect();
//     }
//   }
// }

//历史记录导出
// export class HistoryRecordSock {
//   sock:any;
//   stompClient:any
//   constructor() {
//     this.sock = new SockJS(exportRecordUrl)
//     this.stompClient= stompjs.over(this.sock)
//   }
//   connect(subscribeAdress, sendAdress, sendData){
//     var self = this;
//     return SnPromise((resolve,resolveOnce, reject)=>{
//       self.stompClient.connect({}, function (frame) {

//         self.stompClient.subscribe(subscribeAdress, function (response) {
//             resolveOnce(frame)//建立导出任务
//             resolve(response);//解析json字符串为对象
//         });
//         self.stompClient.send(sendAdress, {},JSON.stringify(sendData));
//       });
//     })
//   }
//   disconnect() {
//     var self = this;
//     if (self.stompClient !== null) {
//       self.stompClient.disconnect();
//     }
//   }
// }

//以图搜图抓拍库导出
// export class CaptureLibSock {
//   sock:any;
//   stompClient:any
//   constructor() {
//     this.sock = new SockJS(RetrivalExport)
//     this.stompClient= stompjs.over(this.sock)
//   }
//   connect(subscribeAdress, sendAdress, sendData){
//     var self = this;
//     return SnPromise((resolve,resolveOnce, reject)=>{
//       self.stompClient.connect({}, function (frame) {
//         self.stompClient.subscribe(subscribeAdress, function (response) {
//           resolveOnce(frame)//建立导出任务
//           resolve(response);//解析json字符串为对象
//         });
//         self.stompClient.send(sendAdress, {},JSON.stringify(sendData));
//       });
//     })
//   }
//   disconnect() {
//     var self = this;
//     if (self.stompClient !== null) {
//       self.stompClient.disconnect();
//     }
//   }
// }

//以图搜图人像库导出
// export class FacialLibSock {
//   sock:any;
//   stompClient:any
//   constructor() {
//     this.sock = new SockJS(RetrivalExport)
//     this.stompClient= stompjs.over(this.sock)
//   }
//   connect(subscribeAdress, sendAdress, sendData){
//     var self = this;
//     return SnPromise((resolve, resolveOnce, reject)=>{
//       self.stompClient.connect({}, function (frame) {
//         self.stompClient.subscribe(subscribeAdress, function (response) {
//             resolveOnce(frame)//建立导出任务
//             resolve(response);//解析json字符串为对象
//         });
//         self.stompClient.send(sendAdress, {},JSON.stringify(sendData));
//       });
//     })
//   }
//   disconnect() {
//     var self = this;
//     if (self.stompClient !== null) {
//       self.stompClient.disconnect();
//     }
//   }
// }

// export function download(param){
//   return request({
//     url: retrivalDownload+"/"+param,
//     method: 'get',
//     headers: {'Accept': 'text/html'},
//     onUploadProgress: function (progressEvent) {
//       console.log(progressEvent)
//     },
//   });
// }

export function exportDownload(param){
  return request({
    url: retryExport,
    method: 'post',
    data:param,
    // headers: {'Content-Type': "application/octet-stream"},
    responseType:'arraybuffer',
  });
}

//消息中心
export class CenterMessage {
  sock:any;
  stompClient:any
  constructor(userId) {
    this.sock = new SockJS(messageCenter+"?userId="+userId)
    this.stompClient= stompjs.over(this.sock)
    this.stompClient.debug=null
  }
  connect(subscribeAdress, sendAdress, sendData){
    var self = this;
    return SnPromise((resolve,resolveOnce, reject)=>{
      self.stompClient.connect({}, function (frame) {
        self.stompClient.subscribe(subscribeAdress, function (response) {
          // resolveOnce(frame)//建立导出任务
          resolve(response);//解析json字符串为对象
        });
        // self.stompClient.send(sendAdress, {},JSON.stringify(sendData));
      });
    })
  }
  disconnect() {
    var self = this;
    if (self.stompClient !== null) {
      self.stompClient.disconnect();
    }
  }
}


