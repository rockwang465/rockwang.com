import request from '@/utils/request'

var url = window.globalConfig.user

export default {
  //获取用户列表
  getUserList(params) {
    return request({
      url: `${url}/users`,
      method: 'get',
      params
    })
  },
  //获取用户详情
  getUserDetails(params, str) {
    return request({
      url: `${url}/users/` + str,
      method: 'get',
      params
    })
  },
  //获取单个用户详情
  getOneUserDetail(id) {
    return request({
      url: `${url}/users/` + id,
      method: 'get'
    })
  },
  //用户添加
  userAdd(params) {
    return request({
      url: `${url}/users`,
      method: 'post',
      data: params
    })
  },
  //用户单个删除
  userDelete(params, str) {
    return request({
      url: `${url}/users/` + str,
      method: 'delete',
      params
    })
  },
  //获取左边部门节点
  getUserGroup(params) {
    return request({
      url: `${url}/orgs/tree`,
      method: 'get',
      params
    })
  },
  //添加部门
  addUserGroup(params) {
    return request({
      url: `${url}/orgs`,
      method: 'post',
      data: params
    })
  },
  //修改分组
  updateGroup(params, id) {
    return request({
      url: `${url}/orgs/` + id,
      method: 'put',
      data: params
    })
  },
  //删除分组
  deleteGroup(id) {
    return request({
      url: `${url}/orgs/` + id,
      method: 'delete'
    })
  },
  //分组详情
  getGroupDetails(id) {
    return request({
      url: `${url}/orgs/` + id,
      method: 'get'
    })
  },
  //编辑用户
  editUser(params, id) {
    return request({
      url: `${url}/users/` + id,
      method: 'put',
      data: params
    })
  },
  //用户组检索用户列表
  searchUseList(params) {
    return request({
      url: `${url}/users`,
      method: 'get',
      params
    })
  },
  //启用/禁用接口
  upDataState(params, id) {
    return request({
      url: `${url}/users/` + id + '/' + 'update_state',
      method: 'put',
      data: {
        state: params.state
      }
    })
  },
  //重置密码
  resetPassWord(params, id) {
    return request({
      url: `${url}/users/` + id + '/' + 'reset_pwd',
      method: 'put',
      params
    })
  },
  //修改密码
  updataPassWord(params, id) {
    return request({
      url: `${url}/users/` + id + '/' + 'update_pwd',
      method: 'put',
      data: params
    })
  },
  //批量删除接口
  deleteAll(userIds) {
    return request({
      url: `${url}/users/batch`,
      method: 'delete',
      data: {
        userIds: userIds
      }
    })
  },
  //导出用户
  exportUserList(params) {
    return request({
      url: `${url}/users/export`,
      method: 'get',
      params
    })
  },
  //导出用户的树结构
  getOrgUserTree() {
    return request({
      url: `${url}/orgs/users/tree`,
      method: 'get'
    })
  },
  //批量禁用用户
  batchStopUser(userIds) {
    return request({
      url: `${url}/users/batch/disable`,
      method: 'put',
      data: {
        userIds: userIds
      }
    })
  },
  //查询用户具有查看权限的模块及对应的类型
  batchStartUser(userIds) {
    return request({
      url: `${url}/users/batch/enable`,
      method: 'put',
      data: {
        userIds: userIds
      }
    })
  },
  //批量移动用户分组
  batchMoveUser(params) {
    return request({
      url: `${url}/users/batch/move_group`,
      method: 'put',
      data: params
    })
  },
  //批量修改角色
  batchUpdataRole(params) {
    return request({
      url: `${url}/users/batch/update_role`,
      method: 'put',
      data: params
    })
  },
  //更新用户选择语言
  updateUserLanguage(params) {
    return request({
      url: `${url}/users/update_user_language`,
      method: 'put',
      data: params
    })
  },

  //批量修改角色
  queryModule(params) {
    return request({
      url: `${url}/users/${params}/query_module`,
      method: 'get'
    })
  },

  //根据密码获取人像id
  getPortraitId(params) {
    return request({
      url: `${url}/decrypt/aes_decrypt`,
      method: 'post',
      data: params
    })
  }
}
