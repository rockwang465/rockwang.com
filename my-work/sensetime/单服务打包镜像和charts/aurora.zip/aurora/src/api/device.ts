import request from '@/utils/request';

var url = window.globalConfig.device;
const frontendCompareHost = window.globalConfig.frontendCompare;
const libraryHost = window.globalConfig.portrait;
const timezoneHost = window.globalConfig.timezoneHost;
const linkHost = window.globalConfig.link;

export default {
  updateDeviceFirmware(params) {//下发更新固件命令
    return request({
      url: frontendCompareHost+'/update_apk',
      method: 'get',
      params
    });
  },
  getDeviceFirmwareInfo(params) {//获取固件信息
    return request({
      url: frontendCompareHost+'/query_device_apk_version',
      method: 'get',
      params
    });
  },
  //获取设备分组列表
  getGroupList(params) {
    return request({
      url: `${url}/device-groups/tree`,
      method: 'get',
      params
    });
  },
  //查询设备分组及设备树形列表
  getDevicesTree(params) {
    return request({
      url: `${url}/device-groups/devices/tree`,
      method: 'get',
      params
    });
  },

  //添加分组
  addGroup(params) {
    return request({
      url: `${url}/device-groups`,
      method: 'post',
      data: params
    });
  },

  //修改分组
  updateGroup(params, id) {
    return request({
      url: `${url}/device-groups/` + id,
      method: 'put',
      data: params
    });
  },

  //删除分组
  deleteGroup(id) {
    return request({
      url: `${url}/device-groups/` + id,
      method: 'delete',
    });
  },

  //获取设备列表
  getDeviceList(params) {
    return request({
      url: `${url}/devices`,
      method: 'get',
      params
    });
  },

  //添加设备
  addDevice(params) {
    return request({
      url: `${url}/devices`,
      method: 'post',
      data: params
    });
  },

  //修改设备
  updateDevice(params, id) {
    return request({
      url: `${url}/devices/` + id,
      method: 'put',
      data: params
    });
  },

  //删除设备
  deleteDevice(id) {
    return request({
      url: `${url}/devices/` + id,
      method: 'delete',
    });
  },

  //查看设备详情
  getDeviceDetail(id) {
    return request({
      url: `${url}/devices/` + id,
      method: 'get',
    });
  },


  //批量删除设备
  deleteDeviceBatch(params) {
    return request({
      url: `${url}/devices/batch`,
      method: 'delete',
      data: {deviceIds: params},
    });
  },

  //修改设备状态
  updateDeviceStatus(params, id) {
    return request({
      url: `${url}/devices/` + id + `/update_state`,
      method: 'put',
      params
    });
  },

  //批量修改设备状态
  updateDeviceStatusBatch(params) {
    return request({
      url: `${url}/devices/batch/update_state`,
      method: 'put',
      data: params
    });
  },

  //批量添加分组
  deviceAddGroupBatch(params) {
    return request({
      url: `${url}/devices/batch/move_group`,
      method: 'put',
      data: params
    });
  },

  //批量添加用户
  deviceAddUserBatch(params) {
    return request({
      url: `${url}/devices/batch/add_user`,
      method: 'post',
      data: params
    });
  },

  //获取设备分组详情
  deviceGroupDetailById(id) {
    return request({
      url: `${url}/device-groups/${id}`,
      method: 'get'
    });
  },

  //获取设备统计数据
  deviceStatistics(params) {
    return request({
      url: `${url}/devices/statistics`,
      method: 'get',
      data: params
    });
  },

  //获取设备列表
  floorDeviceList(params) {
    return request({
      url: `${url}/devices/${params.id}/list`,
      method: 'get',
      data: params
    });
  },

  //获取设备任务
  getDeviceTaskById(id) {
    return request({
      url: `${url}/devices/${id}/rules`,
      method: 'get',
    });
  },

  //搜索设备
// /api/v1/devices/query_device
  queryDevice(params){
    return request({
      url: `${url}/devices/query_device`,
      method: 'post',
      data: params
    });
  },

  //获取厂商列表
  queryFirms(params){
    return request({
      url: `${url}/devices/query_firms`,
      method: 'get',
      params
    });
  },

  getDeviceSyncPeopleList(deviceId,params){
    return request({
      url: `${url}/devices/${deviceId}`,
      method: 'post',
      data: params
    });
  },

  //设备导出
  deviceExport(params){
    return request({
      url: `${url}/devices/export`,
      method: 'post',
      data: params
    });
  },
  //人像库列表
  getLibsList(keywords?) {//获取人像库列表
    return request({
      url: libraryHost+'/libraries',
      method: 'get',
      params:{keywords}
    });
  },
  //时间条件列表
  getTimezoneWithIntervals() {//查询timezone(含有interval) name（只用name）
    return request({
      url: timezoneHost+'/api/v1/query_timezone_except_intervals',
      method: 'get',
    });
  },
  //查询设备人员下发情况
  getDeviceImagesSync(params){
    return request({
      url: linkHost+'/link/device/personinfo',
      method: 'get',
      params: params
    });
  },
  exportdeviceAsyncFailTargets(deviceId){
    return request({
      url: `${linkHost}/link/download_personinfo`,
      method: 'post',
      data: {
        "condition": "",
        "id": deviceId,
        "pageNumber": 1,
        "pageSize": 99999,
        "status": 3,
        "sync": 1
      }
    })
  },
  getDeviceSyncLibraryList(deviceId){
    return request({
      url: `${url}/devices/librarys/${deviceId}`,
      method: 'get',
      data: {}
    });
  },
  //获取M设备关联人像库列表
  getLibrarys(params){
    return request({
      url: `${url}/devices/librarys/`+params,
      method: 'get',
    });
  },
  exportMFailPeople(params){
    return request({
      url: `${url}/device/target/fail/export`,
      method: 'post',
      data: params
    });
  }
}
