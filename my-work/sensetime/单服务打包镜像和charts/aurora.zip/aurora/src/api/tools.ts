import request from '@/utils/request';
const toolHost = window.globalConfig.toolHost;

export function compareTwoFaces(oneImgBase64,otherImgBase64) {
  return request({
    url: toolHost+'/one_to_one_face_compare',
    method: 'post',
    data: {oneImgBase64,otherImgBase64}
  });
}
export function detectQuality(imgBase64) {
  return request({
    url: toolHost+'/check_one_img_quality',
    method: 'post',
    data: {imgBase64}
  });
}
export function faceAttributeDetection(imgBase64) {
  return request({
    url: toolHost+'/face_attribute_detection',
    method: 'post',
    data: {imgBase64}
  });
}
