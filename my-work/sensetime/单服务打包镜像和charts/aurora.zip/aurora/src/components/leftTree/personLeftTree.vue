<template>
  <div class="side-tree" style="height: calc(100% - 3px);">
    <el-input
      size="small" class="search-input"
      @focus="inputFocus"
      @blur="inputBlur"
      v-model="filterText">
      <span class="suffix-icon" slot="suffix">
        <Icon
          v-if="showSearchClose"
          type="ele"
          size="15"
          cursor="pointer"
          name="circle-close"
          @click="clickClearKeywords"
        />
            <Icon
              type="ele"
              size="15"
              cursor="pointer"
              name="search"
              style="color: #000"
              @click="onFilterTextChange"
            />
          </span>
    </el-input>
    <!--@node-contextmenu="contextmenuNode"-->
    <!-- <div class="person-left-tree" style=""></div> -->
      <el-tree
        ref="tree2"
        class="filter-tree"
        node-key="id"
        :data="treeData"
        :props="defaultProps"
        :current-node-key="1"
        :filter-node-method="filterNode"
        @node-click="clickLocalNode"
        :render-content="renderContent"
        style="height:calc(100% - 75px); overflow-y: auto;min-height:50px;"
      />

    <div id="menu"  @mouseleave="clearTB"  v-show="$permission('008303') || $permission('008102') || $permission('008204') || $permission('008405')">
      <ul>
        <!--创建同级-->
        <li v-if="leftTreeData.actionArray[0] == 1 && $permission('008303')" v-show="isShow" class="menu" @click="addData('level')"><i class="iconfont icon-peer"></i>{{$t('imagemanagement.listPeerGroupCreate')}}</li>
        <!--创建下一级-->
        <li v-if="leftTreeData.actionArray[1] == 1 && $permission('008303')" v-show="!isShow" class="menu" @click="addData('next')"><i class="iconfont icon-create_child_node"></i>{{$t('imagemanagement.listSubGroupCreate')}}</li>
        <!--详情-->
        <li v-if="leftTreeData.actionArray[2] == 1 && $permission('008102')" v-show="isShow" class="menu" @click="showDetail"><i class="iconfont icon-view"></i>{{$t('imagemanagement.listDetail')}}</li>
        <!--重命名-->
        <li v-if="leftTreeData.actionArray[3] == 1 && $permission('008204')" v-show="isShow" class="menu" @click="updateData"><i class="iconfont icon-edit"></i>{{$t('imagemanagement.listRename')}}</li>
        <!--删除-->
        <li v-if="leftTreeData.actionArray[4] == 1 && $permission('008405')" v-show="isShow" class="menu" @click="deleteData"><i class="iconfont icon-delete"></i>{{$t('imagemanagement.listDelete')}}</li>
      </ul>
    </div>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {Tree as ElTree} from 'element-ui';
  import {isEmpty} from '@/utils/validate';
  import Icon from '@/components/icon-wrap/index.vue';
  import {EventBus} from '@/utils/eventbus';

  @Component({
    components: {
      Icon
    }
  })
  export default class Tree extends Vue {
    @Prop({default: []}) treeData!: any[];
    @Prop(Object) leftTreeData!: any[];
    @Prop(String) topKeyWords!: any;
    focusEnter = false;
    showSearchClose = false;
    isShow = true;
    localHandleData = {
      isChild: false
    };
    filterText = '';
    defaultProps = {
      children: 'children',
      label: 'libraryName',
    };
    treeWidth: any = "";
    actionHeight = '0px';
    isFirst = false;

    mounted() {
      EventBus.$on('search-person',()=>{
        console.log((this.$refs.tree2 as any).getCurrentKey());;
        (this.$refs.tree2 as any).setCurrentKey(1,true);
      })
      let data = this.leftTreeData as any;
      // this.defaultProps.label = data.label;
      let index = 0;
      for (let i = 0; i < data.actionArray.length; i++) {
        if (data.actionArray[i] == 1) {
          index++;
        }
      }
      this.actionHeight = index * 40 + 'px'
      //给页面添加点击事件使功能框消失
      window.onclick = function (e) {
        let menu = document.getElementById('menu') as any;
        if(menu){
          menu.style.display = 'none';
        }
      }
      this.$nextTick(function () {
        let menuPos = (this.$refs.tree2 as ElTree).$el.getBoundingClientRect()
        this.treeWidth = menuPos.width + menuPos.left;
      })
    }

    @Watch('topKeyWords')
    onTopKeyWordsChange(val: string) {
      this.filterText = '';
      if (val == ''){
        this.clickClearKeywords();
      }
    }
    @Watch('filterText')
    onFilterTextChanges(val: any) {
      if (!isEmpty(val)) {
        this.showSearchClose = true
      }
      if (val == ''){
        this.showSearchClose = false;
        this.onFilterTextChange();
      }
    }

    //清空右边搜索文字
    inputFocus(){
      this.focusEnter = true;
      this.clickClearKeywords()
      this.$emit("filterNode");
      this.$emit("inpFocus");
      let that = this as any;
      window.document.onkeydown = function(event){
        if (that.focusEnter) {
          if (event.keyCode == 13){
            that.onFilterTextChange();
          }
        }

      }
    }

    inputBlur(){
      this.focusEnter = false;
    }

    clearTB() {
      let menu = document.getElementById('menu') as any;
      menu.style.display = 'none';
    }

    //监听搜索框的值,检索
    onFilterTextChange() {
      this.isFirst = true;
      (this.$refs.tree2 as ElTree).filter(this.filterText);
      this.$emit("actionMethod", 1);
    }

    clickClearKeywords() {
      this.filterText = '';
      this.showSearchClose = false;
      (this.$refs.tree2 as ElTree).filter(this.filterText);
      this.$emit("actionMethod", 1);
    }

    //根据值过滤掉不匹配的分支
    filterNode(value: string, data: any) {
      console.log(data,value)
      if (!value) {
        return true;
      }
      let flag = data.libraryName.indexOf(value) !== -1;
      if (flag && this.isFirst) {
        this.$emit("clickVal", data);
        this.isFirst = false
      }
      return flag;
    }

    //右键事件,弹出事件框,设置好位置  event鼠标右键点击的参数
    contextmenuNode(event: any, localData: any) {
      this.localHandleData = localData
      let menu = document.getElementById("menu") as any;
      menu.style.left = event.clientX + 'px';
      menu.style.top = event.clientY + 'px';
      menu.style.width = '120px';
    }

    //项目初始化默认组显示内容
    showInitData(obj: any) {
      let that = this as any;
      let par = {} as any;
      for (let i = 0; i < obj.length; i++) {
        if (obj[i].id == 1) {
          par = obj[i];
          break;
        }
      }
      if (!isEmpty(par.id)) {
        /* (that.$refs.tree2 as any).setCurrentKey(par.id);*/
        that.$emit("clickVal", par);
      }
    }

    clickLocalNode(localData: any,node,data) {
      console.log('TreeCurrent',localData,node,data)
      let menu = document.getElementById('menu') as any;
      menu.style.display = 'none';

      //把currentTreeData的父节点数据添加上
      localData.isLeaf = node.isLeaf
      if(node.level > 1){
        localData.parent = node.parent
      }


      this.$emit("clickVal", localData);

    }

    //查看详情
    showDetail() {
      let menu = document.getElementById('menu') as any
      menu.style.display = 'none';
      this.$emit("showDetail", this.localHandleData);
    }

    //修改数据
    updateData() {
      let menu = document.getElementById('menu') as any
      menu.style.display = 'none';
      this.$emit("updateData", this.localHandleData);
    }

    //添加数据
    addData(flag) {
      let menu = document.getElementById('menu') as any
      menu.style.display = 'none';
      this.$emit("addData", flag, this.localHandleData);
    }

    //删除数据
    deleteData() {
      this.$emit("deleteData", this.localHandleData);
    }

    renderContent(h, {node, data, store}) {
      let that = this as any;
      let str = node.label.length < 15 ? node.label : (node.label.substring(0, 15) + '...')
      let str2 = '' as any;
      if(this.topKeyWords != ''){
        str2 = str+ ' ' + (data.targetCount ? '(' + data.targetCount + ')' : '')
      }else{
        str2 = str
      }
      let hi;
      // if (node.label.length > 10) {
      //   hi = [
      //     h("el-tooltip", {
      //       props: {
      //         content: node.label,
      //         placement: 'top-start'
      //       }
      //     }, [
      //       h("span", {}, str2)
      //     ])
      //   ]
      // } else {
      //   hi = str2
      // }
      hi = [
        node.isLeaf && data.extractFeature == '0'? h("i", {
          class:'iconfont icon-fontend',
          style: {
            left:'0px',
            top:'0px',
            position:'absolute',
          },
        }, ''):'',
        h("div", {
          attrs: {
            title: node.label,
          },
        }, str2)
      ]

      return h('div', {
        style: {
          width: '90%'
        },
      }, [
        h("div", {
          style: {
            width: '75%',
            float: 'left',
            position:'relative',
            'padding-left':node.isLeaf?'20px':''
          },
          on: {
            'mouseenter': (event) => {
              let menu = document.getElementById("menu") as any;
              menu.style.display = 'none';
            },
          }
        }, hi),
        h("div", {
          style: {
            width: '24%',
            float: 'left',
            textAlign: 'right',
            paddingRight: '5px'
          },
          on: {
            'mouseenter': (event) => {
              // debugger
              let num = 0;
              if (!node.data.libraryId){
                // 如果是一级菜单
                this.isShow = false;
                num = 4;
              } else{
                this.isShow = true;
                num = 1;
              }
              this.localHandleData = data;
              let menu = document.getElementById("menu") as any;
              menu.style.left = this.treeWidth + "px";
              let x = event.clientY - event.offsetY;
              // let num = 5 - this.getNum();
              if (window.innerHeight - x < (250 - num * 36)) {
                menu.style.top = x - 180 + (num * 36) + 'px';
              } else {
                menu.style.top = x + 'px';
              }
              // menu.style.top = event.clientY - event.offsetY + 'px';
              menu.style.display = 'block';
            }
          }
        }, '︙'),
      ]);
    }

    getNum() {
      //判断有几个button权限
      let that = this as any;
      let num = 0;
      for (let i = 0; i < that.leftTreeData.actionArray.length; i++) {
        if (that.leftTreeData.actionArray[i]) {
          num++;
        }
      }
      return num;
    }

  }
</script>
<style scoped lang="scss">
  #menu {
    overflow: hidden; /*隐藏溢出的元素*/
    box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.2);
    position: fixed; /*自定义菜单相对与body元素进行定位*/
    background: #fff;
    z-index: 9999;
    border-top: 2px solid #2a5af5;
    /*padding: 8px;*/
    /* width: 140px; */
    white-space : nowrap;
    display: none;
  }

  .menu {
    cursor: pointer;
    height: 36px;
    line-height: 36px;
    border-bottom: 1px solid #c2cad850;
    padding-left: 4px;
    padding-right: 8px;
  }
  .menu:hover {
    background-color:#f4f4f4;
  }
  .el-tree{
    background: transparent;
  }
  #menu li{
    padding:0 8px;
    box-sizing: content-box;
  }
  #menu li:last-child{border-bottom: none;
    padding-bottom: 8px;}
  #menu li:first-child{border-bottom: none;
    padding-top: 8px;}
  #menu .menu .iconfont{margin-right: 16px;}
  ::v-deep .is-current > .el-tree-node__content:first-child {
    /*background-color: #6d7c96;*/
    background-color: #011C50;
    border-color: #011C50;
    color: #ffffff;

  .el-checkbox {
  .el-checkbox__inner::before {
    content: "\e65b";
  }
  }
  }



</style>

