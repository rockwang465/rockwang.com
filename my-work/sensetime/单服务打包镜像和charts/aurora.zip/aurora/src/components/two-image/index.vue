<template>
    <div @click.self="viewDetail"  class="two-image-container" :class="[compareTypeCard,cardType]" id="two-img">
      <div  ref="imageContainer" class="image-container">
        <div class="compareType" v-if="compareTypeCard!='unliveAtrack'|| compareTypeCard!='passwordAtrack'">{{$t(i18nCompareType(compareTypeCard))}}</div>
        <!-- <div :class="['maskType',item.faceAttributeInfo.respiratorColor  == 'color_type_none'?'isMask':'']">
          <i class="iconfont icon-mask"></i>
          <i class="iconfont icon-separator"></i>
           <span>{{item.faceAttributeInfo.respiratorColor  == 'color_type_none'?'未戴口罩':'佩戴口罩'}}</span>
        </div> -->
        <span class="view-state">{{$t(i18nOperateType(cardType))}}</span>
        <div @click="viewDetail"  class="target-image" >
          <img :src="processImgurl(targetImg)" alt="">
        </div>
        <div ref="percentage" class="percentage">
          <span v-if="this.compareType=='2'|| this.compareType=='3'" ref="percentageCircle" class="font-wrap no-percent">
            <span style="fontSize:26px">?</span>
            <!-- <span>{{percentage[1]}}</span> -->
          </span>
          <span v-else ref="percentageCircle" class="font-wrap">
            <span style="fontSize:26px">{{percentage[0]}}</span>
            <span>{{percentage[1]==='' ? '.0%' :'.' + percentage[1]}}</span>
          </span>

          <div style="z-index:1" v-if="canOperate && this.$permission('009304')" class="image-btn">
            <div v-if="compareType=='2'">
              <!-- <el-button
                class="btn-check"
                type="info"
                size="mini">
                {{$t("records.contFaceSpoof")}}
              </el-button> -->
            </div>
            <!-- 陌生人比中 -->
            <!-- <div v-else-if="compareType=='1'"></div> -->
            <!-- 陌生人比中 -->
            <div v-else-if="compareType=='3'">
              <!-- <el-button
                class="btn-check"
                type="info"
                size="mini">
                {{$t("records.contPassAttack")}}
              </el-button> -->
            </div>
            <div
              style="text-align:center;"
              v-else-if="cardType==='' || cardType==='viewed'"
              >
            <el-button
              class="btn-check"
              type="primary"
              @click="handleSuccess"
              size="mini">
              {{$t("records.contMatch")}}
            </el-button>
            <el-button
              class="btn-check"
              type="primary"
              @click="handleFailed"
              size="mini">
              {{$t("records.contUnmatch")}}
            </el-button>
            </div>

            <div v-else>
              <el-button
                v-if="cardType==='success'"
                class="btn-check"
                type="success"
                @click="cancelSuccess"
                style="top: 30px;"
                size="mini">
                {{$t("records.contResetMatch")}}
              </el-button>
              <el-button
                v-if="cardType==='failed'"
                class="btn-check btn-unmatch"
                type="primary"
                @click="cancelFailed"
                style="top: 30px;"
                size="mini">
                {{$t("records.contResetUnmatch")}}
              </el-button>
            </div>
          </div>

          </div>
        <div @click="viewDetail"  class="origin-image">
          <div v-if="!originImg || (compareType=='1' && !strangerRatioSwitch)" class="vanished">
            <img src="/images/noPerson.svg" alt="">
          </div>
          <img v-else :src="processImgurl(originImg)"  alt="">
        </div>
      </div>
      <div @click="viewDetail" v-if="hasText" class="info-content">
        <span v-if="compareType == '1' && !strangerRatioSwitch">
          <div class="time" >{{$t('records.contTime')}}:{{time}}</div>
          <div class="username">{{$t('records.none')}}</div>
          <div class="location" >{{$t('records.contDevice')}}:
            <!-- {{device}} -->
            {{ item.deviceInfo && item.deviceInfo.device && item.deviceInfo.device.subDevice && item.deviceInfo.device.subDevice.deviceName  ? item.deviceInfo.device.subDevice.deviceName : device}}
            </div>
          <div class="id">{{$t('records.none')}}</div>
        </span>
        <span v-else>
          <div class="time" >{{$t('records.contTime')}}:{{time}}</div>
          <div class="username" >{{$t('records.contName')}}:{{name}}</div>
          <div class="location" >{{$t('records.contDevice')}}:
            <!-- {{device}} -->
            {{ item.deviceInfo && item.deviceInfo.device && item.deviceInfo.device.subDevice && item.deviceInfo.device.subDevice.deviceName  ? item.deviceInfo.device.subDevice.deviceName : device}}
            </div>
          <div class="id" >{{$t('records.contID')}}:{{id}}</div>
        </span>
        <!-- 口罩与安全帽 -->
        <div v-if="respiratorSwitch && item.faceAttributeInfo.respiratorColor" :class="['AllSwitch',item.faceAttributeInfo.respiratorColor  == 'color_type_none'?'isMask':'']">
          <i class="iconfont icon-mask"></i>
          <span>{{item.faceAttributeInfo.respiratorColor  == 'color_type_none'? $t("records.noMask"):$t("records.ownMask")}}</span>
        </div>

        <div v-if="helmetSwitch && item.faceAttributeInfo.helmetStyle" :class="['AllSwitch',item.faceAttributeInfo.helmetStyle  == 'st_helmet_style_type_none'?'isOwn':'']">
          <i class="iconfont icon-anquanmao"></i>
          <span>{{item.faceAttributeInfo.helmetStyle  == 'st_helmet_style_type_none'? $t("records.noHelmet"): $t("records.ownHelmet")}}</span>
        </div>

        <!-- <div v-if="item.tempInfo" :class="['AllSwitch',getTempData(item).class]">
          <span>{{getTempData(item).text}}</span>
        </div> -->
        <!-- <mark style="position:relative;z-index:111">{{item.faceAttributeInfo}}</mark> -->
        <!-- 口罩与安全帽 -->
        <!-- <div v-if="respiratorSwitch && item.faceAttributeInfo.respiratorColor" :class="['AllSwitch',item.faceAttributeInfo.respiratorColor  == 'color_type_none'?'isMask':'']">
          <strong>
          <i class="iconfont icon-mask"></i>
          <span>{{item.faceAttributeInfo.respiratorColor  == 'color_type_none'? $t("records.noMask"):$t("records.ownMask")}}</span>
          </strong>
        </div>
        <div v-if="helmetSwitch && item.faceAttributeInfo.helmetStyle" :class="['AllSwitch',item.faceAttributeInfo.helmetStyle  == 'none'?'isOwn':'']">
          <strong>
          <i class="iconfont icon-anquanmao"></i>
          <span>{{item.faceAttributeInfo.helmetStyle  == 'none'? $t("records.noHelmet"): $t("records.ownHelmet")}}</span>
          </strong>
        </div> -->

        <!-- 温度 -->
        <div v-if="item.tempInfo && item.tempInfo.temp" :class="['AllSwitch',item.tempInfo.tempStatus  !== 0 && item.tempInfo.tempStatus  !== 3 ?'isFever':'']">
          <strong>
          {{item.tempInfo.temp}}{{$t('records.tempUnitSymbol')[item.tempInfo.tempUnit]}} {{$t('records.tempStatus')[item.tempInfo.tempStatus]}}
          </strong>
        </div>

      </div>
      <div :class="load"></div>
    </div>
</template>

  <script lang="ts">
  import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
  import { Switch } from 'element-ui';
  import { processImgurl } from '@/utils/image';
  import  Icon from '@/components/icon-wrap/index.vue';
  import {Cache} from '@/utils/cache';
  interface Two{
    percentageSize:number
  }

  @Component({
    components: {
      Icon
    },
    // props:{
    //   canOperate:{
    //     type:Boolean,
    //     default:true,
    //   },
    //   loading:{
    //     type:Boolean,
    //     default:false,
    //   },
    //   items:{
    //     type:Object,
    //     default(){
    //       return {};
    //     },
    //   },
    //   item:{
    //     type:Object,
    //     default(){
    //       return {};
    //     },
    //   },
    //   percentage:{//比中百分比
    //     type:Array || String,
    //     default:"",
    //   },
    //   percentageSize:{//比中文字大小
    //     type:Number,
    //     default:16,
    //   },
    //   name:{
    //     type:String,
    //     default:""
    //   },
    //   time:{
    //     type:String,
    //     default:""
    //   },
    //   id:{
    //     type:String,
    //     default:""
    //   },
    //   location:{
    //     type:String,
    //     default:""
    //   },
    //   device:{
    //     type:String,
    //     default:""
    //   },
    //   originImg:{//人像库图片
    //     type:String,
    //     default:""
    //   },
    //   targetImg:{//抓拍库图片
    //     type:String,
    //     default:""
    //   },
    //   cardType:{ //操作类型,"success" 成功 "failed" 失败 "viewed" 查看 ""未查看
    //     type:String,
    //     default:""
    //   },
    //    compareType:{ //比对状态,"9" 黑名单告警 "0" 白名单比中 "4" 白名单异常  "1" 陌生人告警 "3" 密码攻击 "2" 非活体攻击
    //     type:String,
    //     default:""
    //   },
    //   hasText:{ //图片下面是否有文字信息
    //     type:Boolean,
    //     default:true,
    //   }
    // }

  })
  export default class TwoImage  extends Vue{
    @Prop({default:true}) canOperate!:boolean;
    @Prop({default:false}) loading!:boolean;
    @Prop({default(){return {}}}) items!:object;
    @Prop({default(){return {}}}) item!:object;
    @Prop({default:""}) percentage!:[] | string;
    @Prop({default:16}) percentageSize!:number;
    @Prop({default:""}) name!:string;
    @Prop({default:""}) time!:string;
    @Prop({default:""}) id!:string;
    @Prop({default:""}) location!:string;
    @Prop({default:""}) device!:string;
    @Prop({default:""}) originImg!:string;
    @Prop({default:""}) targetImg!:string;
    @Prop({default:""}) cardType!:string;
    @Prop({default:""}) compareType!:string;
    @Prop({default:true}) hasText!:boolean;
    // item:any;
    // items:any;
    // percentageSize:any
    // cardType:any;
    // compareType:any;
    // hasText:any;
    provisonal="";
    load="";
    compareTypeCard="";
    strangerRatioSwitch=false
    respiratorSwitch = true
    helmetSwitch = true
    processImgurl=processImgurl;
    // @Watch('cardType')
    // cardTypeChanged(val: string, oldVal?: string) {
    //   this.provisonal=val //设置样式
    // }
    @Watch("loading")
    onloading(val){
      if(val){
        this.load="cover"
      }else{
        this.load=""
      }
    }
    @Watch("compareType")
    onCompareTypeChange(val){
      //console.log(val)
     switch(val){
       case "0":
       this.compareTypeCard="whitelistSucess"
       break;
       case "1":
          if(this.strangerRatioSwitch){
            this.compareTypeCard="strangeWarn";
          }else{
            this.compareTypeCard="strangeWarn2";
          }
       break;
       case "2":
       this.compareTypeCard="unliveAtrack";
       break;
       case "3":
       this.compareTypeCard="passwordAtrack";
       break;
       case "4":
       case "6":
       case "7":
       case "8":
       this.compareTypeCard="whitelistWarn";
       break;
       case "9":
       this.compareTypeCard="blacklistWarn";
       break;
     }
    }
    i18nCompareType(val){
      switch(val){
       case "whitelistSucess":
       return "records.listNotifyTypeNormal";
       case "strangeWarn":
       case "strangeWarn2":
       return "records.listNotifyTypeStranger";
       case "unliveAtrack":
       return "records.listNotifyTypeFaceSpoof";
       case "passwordAtrack":
       return "records.listNotifyTypePassAttack";
       case "whitelistWarn":
       return "records.listNotifyTypeAbnormal";
       case "blacklistWarn":
       return "records.listNotifyTypeBlacklist";
     }
    }
     i18nOperateType(val){
      switch(val){
       case "viewed":
       return "records.lsitOperationTypeRead";
       case "success":
       return "records.lsitOperationTypeMatched";
       case "failed":
       return "records.lsitOperationTypeUnmatched";
       case "":
       return "";
     }
    }
    mounted(){
      // console.log(this.percentage);

      //设置百分比字体大小
      (this.$refs.percentage as any).style .fontSize=this.percentageSize+"px";
      // let width = (this.$refs.percentageCircle as any).clientWidth;
      // (this.$refs.percentageCircle as any).style.height = width+"px";
      // (this.$refs.percentageCircle as any).style.lineHeight = width+"px";
      if(!this.hasText){//如果卡片没有文本，图片高度100%
        (this.$refs.imageContainer as any).style.height="100%"
      }
      this.strangerRatioSwitch = Cache.localGet('strangerRatioSwitch') == true;
      //console.log(Cache.localGet('respiratorSwitch'))

      this.respiratorSwitch = Cache.localGet('respiratorSwitch') == true;
      this.helmetSwitch = Cache.localGet('helmetSwitch') == true;
      this.onCompareTypeChange(this.compareType)


    }

    @Emit()//点击取消比中
    cancelSuccess(){
      return this.item
    }

    @Emit() //点击取消未比中
    cancelFailed(){
      return this.item
    }

    @Emit("success") //点击比中
    handleSuccess(){
     return this.item
    }

    @Emit("failed") //点击未比中
    handleFailed(){
      return this.item
    }

    @Emit() //点击图片查看详情
    viewDetail(){
      return { items:this.items,item:this.item }
    }
    getTempData(item:any){
      if(item.tempInfo){
        let key = item.tempInfo.tempStatus;//0-正常 1-疑似发热 2-确认发热 3-复核正常 11-体温异常

        //TODO:提取国际化
        switch (key) {
          case 0:
            return {class:'temp-style-normal',text:`${item.tempInfo.temp} 正常`};
          case 1:
            return {class:'temp-style-abnormal',text:`${item.tempInfo.temp} 疑似发热`};
          case 2:
            return {class:'temp-style-abnormal',text:`${item.tempInfo.temp} 确认发热`};
          case 3:
            return {class:'temp-style-normal',text:`${item.tempInfo.temp} 复核正常`};
          case 11:
            return {class:'temp-style-abnormal',text:`${item.tempInfo.temp} 体温异常`};
          default:
            return {class:'',text:''};
        }
      }else{
        return {class:'',text:''}
      }
    }
  }

  </script>

  <style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  @media screen and (max-width: 1366px) {
      .two-image-container {
        padding: 24px 10px 5px 10px !important;

        .compareType {
          width: 76px !important;
          font-size: 12px
        }
        .font-wrap {
          span:nth-child(1) {

            font-size: 16px !important

          }
        }
        .target-image {
          margin-left: 0px !important
        }
      }
  }

    .two-image-container{
      width: 100%;
      height:100%;

      display: inline-block;
      background:#fff;
      border:1px solid rgba(194,202,216,1);
      padding:32px 0px 5px 16px;
      position: relative;
      border:1px solid rgba(223,223,224,1);
      box-shadow:0px 3px 6px rgba(0,0,0,0.16);
      opacity:1;
      border-radius:4px;
      .cover{
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background: rgba(255,255,255,.2);
        z-index: 10;
      }
      .view-state{
        // color: $--color-white;
         color: #B4B4B4;
        position: absolute;
        z-index: 1;
        // left: 50%;
        // transform: translate(-50%,-22px);
        // left: 78%;
        // transform: translate(0%,-42px);
        // padding: 3px 15px;
        // border--radius: 3px;
        // border-bottom-left-radius: 3px;
        // border-bottom-right-radius: 3px;
        right:5% ;
        transform: translate(0,-25px);
      };
      .image-container{
        display: flex;
        // height: 75%;
        height:62%;
        align-items: stretch;
        // margin-top: 26px;//??merge
        img {
          width:100%;
          height:100%;
          object-fit: cover;
          border:1px solid rgba(224,224,224,1);
        };
        .target-image{
          cursor: pointer;
          // height:100%;
          // width:43%;
          // width:96px;
          // height:128px;
          width:104px;
          height:104px;
          overflow: hidden;
          // margin-left: 3%;
          margin-left: 1%;
          img:hover{
            transform: scale(1.1,1.1);
            transition: all 1s;
          }
        };
        .origin-image{
          cursor: pointer;
          // height:100%;
          // width:43%;
          // width:96px;
          // height:128px;
          width:104px;
          height:104px;
          overflow: hidden;
          // margin-right: 26px;
          img:hover{
            transform: scale(1.1,1.1);
            transition: all 1s;
          }
          .vanished{
            height: 100%;
            width: 100%;
            background: #b3c1d2;
            position: relative;
            overflow: hidden;
            img{
              width: 100%;
              height: 100%;
              position: absolute;
              bottom: 0;
              left: 50%;
              transform: translate(-50%,0);
            }

            // .icon{
            //   position: absolute;

            //   bottom: -10px;
            //   left: 50%;
            //   transform: translate(-50%,0);
            //   color: #6d7c96;
            // }
          }
        };
        .percentage{
          width:32%;
          display: flex;
          justify-content: flex-end;
          flex-direction: column;
          align-items: center;
          position: relative;

          .font-wrap{
            position: absolute;
            top:0px;
            // color: $--color-white;
            display: block;
            // min-width: 120%;
            width: 100%;
            border-radius: 50%;
            text-align: center;
            z-index: 1;
            // background: $--color-reserved-5;
            opacity: 0.9;
            // box-shadow: 0 0 0 3px rgba($--color-reserved-5,.3);
            height: 86px ;
            // line-height: 86px ;
            line-height: 50px ;
            font-weight: 700;
          }

          .image-btn {
            position: absolute;
            // top: 66px;
            top: 39px;
            // div {
            //   display: flex;
            //   flex-direction: column;
            // }
          }
          .no-percent{
            font-size: 25px;
            font-weight: bolder;
          }
          .btn-check{
            z-index: 1;
            margin-top:10px;
            margin-left:0;
            min-width: 76%;
            padding: 5px 0px;
            background:rgba(231,234,239,1);
            color:#28354D;
            border: none;
            position: relative;
          }
          .btn-unmatch{
            // background: #6d7c96;
            // border-color: #6d7c96;
          }
        };
      }
      .info-content{
        margin: 5px -5px;
        font-size: 12px;
        position: relative;
        div{
          padding: 2px 0;
          margin-right:3px;
          box-sizing: border-box;
          display: inline-block;
          max-width:50%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space:nowrap;

          .text-circle{
            display: inline-block;
            height: 1px;
            width: 1px;
            border: 2px solid #fc3d1a;
            border-radius: 50%;
            margin-right: 2px;
            margin-bottom: 2px;
          }
        }
        .time{
          width: 50%;
          display: inline-block;
          padding-left: 5px;

        }
        .username{
          width: 44%;
          display: inline-block;
          margin-right: 10px;
          padding-left: 40px;

        }
        .location{
          width: 50%;
          padding-left: 5px;

        }
        .id{
          width: 46%;
          padding-left: 40px;

        }
        .AllSwitch {
          background-color: #EDF0F2;
          color: #7C8B93;
          line-height: 20px;
          // height: 24px;
          padding: 0 5px ;
          border-radius: 5px;
          font-size: 12px;
          margin-left: 5px;
          i {
            font-size: 12px;
          }
        }
        .isOwn {
          background-color:rgba(255,83,3,.15);
          color: #ff851b;
        }
        .isFever{
          background:rgba(245,19,0,.15);
          color: #F51300;
        }
        .isMask {
          background-color:rgba(72, 133, 255, .15);
          color: #4885FF;
        }
        .temp-style-abnormal{
          background-color: #fedbd9;
          color: #f51300;
        }
      }

      .maskType {
        position: absolute;
        top: 0px;
        left: 116px;
        width: 95px;
        background-color: #D3D3D3;
        line-height: 30px;
        height: 30px;
        text-align: center;
        &::after {
          content: '';
          position: absolute;
          // width: 20px;
          // height: 30px;
          right: -20px;
          top: 0;
          // transform: rotate(-45deg);
          border-top:30px solid transparent;
          border-left:0px solid transparent;
          border-right:20px solid transparent;
          border-bottom:0px solid transparent;
          border-top-color: #d3d3d3;
          border-left-color:  #D3D3D3;
        }
        &::before {
          content: '';
          position: absolute;
          // width: 20px;
          // height: 30px;
          left: -20px;
          top: 0;
          // transform: rotate(-45deg);
          border-top:0px solid transparent;
          border-left:20px solid transparent;
          border-right:0px solid transparent;
          border-bottom:30px solid transparent;
          // border-top: 15px solid transparent;
          border-bottom-color: #d3d3d3;
          // border-left: 15px solid transparent;
          border-right-color: #d3d3d3;
        }
      }

      .maskType {
        position: absolute;
        top: 0px;
        left: 116px;
        width: 95px;
        background-color: #D3D3D3;
        line-height: 30px;
        height: 30px;
        text-align: center;
        &::after {
          content: '';
          position: absolute;
          // width: 20px;
          // height: 30px;
          right: -20px;
          top: 0;
          // transform: rotate(-45deg);
          border-top:30px solid transparent;
          border-left:0px solid transparent;
          border-right:20px solid transparent;
          border-bottom:0px solid transparent;
          border-top-color: #d3d3d3;
          border-left-color:  #D3D3D3;
        }
        &::before {
          content: '';
          position: absolute;
          // width: 20px;
          // height: 30px;
          left: -20px;
          top: 0;
          // transform: rotate(-45deg);
          border-top:0px solid transparent;
          border-left:20px solid transparent;
          border-right:0px solid transparent;
          border-bottom:30px solid transparent;
          // border-top: 15px solid transparent;
          border-bottom-color: #d3d3d3;
          // border-left: 15px solid transparent;
          border-right-color: #d3d3d3;
        }
      }
      // .isMask {
      //   background-color: #FFD905;
      //   &::after {
      //     border-top-color: #FFD905;
      //     border-left-color:  #FFD905;
      //   }
      //   &::before {
      //     border-bottom-color: #FFD905;
      //     border-right-color: #FFD905;
      //   }
      // }
    }
    #two-img.success{
      border-color: $--color-reserved-6;
      .view-state{
        // background: #0f9d58;
      }
    }
     #two-img.failed{
      // border-color: $--color-reserved-6;
      .view-state{
        // background: #6d7c96;
      }
    }
     #two-img.viewed{
      // border-color: $--color-warning;
      .view-state{
        // background: #39cccc;
      }
    }
    #two-img.whitelistSucess{
      // background: rgba(35,165,247,0.2);
      // border: 4px solid #23a5f7;
      .compareType{
        background: #23a5f7;
        .arrow{
         border-right-color: #23a5f7;
        }
      }
    }
    #two-img.strangeWarn{
      // background: #ead4c4;
      // border: 4px solid #ff851b;
      .font-wrap{
        // background: #ff851b;
        // box-shadow: 0 0 0 3px rgba(#ff851b,.3);
      }

      .compareType{
        background: #ff851b;
        .arrow{
          border-right-color: #ff851b;
        }
      }
    }
    #two-img.strangeWarn2{
      // background: #ead4c4;
      // border: 4px solid #ff851b;
      .font-wrap{
        // background: #ff851b;
        // box-shadow: 0 0 0 3px rgba(#ff851b,.3);
      }

      .compareType{
        background: #ff851b;
        .arrow{
          border-right-color: #ff851b;
        }
      }
      .image-btn{
        display: none;
      }
      .font-wrap{
        &::before{
          content: '?';
          color: #9099B7;
          font-size: 36px;
        }
        span{display: none;}
      }
    }
    #two-img.unliveAtrack{
      // background: #d2bdce;
      // border: 4px solid #85144b;
       .font-wrap{
        // background: #85144b;
        // box-shadow:  0 0 0 3px rgba(#85144b,.3);
      }
      .el-button{
        background: #85144b;
        color: #fff;
        border:none;
      }
      .compareType{
        background: #85144b;
        .arrow{
          border-right-color: #85144b;
        }
      }
    }
    #two-img.passwordAtrack{
      // background: #dabbe7;
      // border: 4px solid #b10dc9;
      .font-wrap{
        // background: #b10dc9;
        // box-shadow: 0 0 0 3px rgba(#b10dc9,.3);
      }
      .el-button{
        background: #b10dc9;
        color: #fff;
        border:none;
      }
      .compareType{
        background: #b10dc9;
        .arrow{
          border-right-color: #b10dc9;
        }
      }
    }
    #two-img.whitelistWarn{
      // background: rgba(109,124,150,0.2);
      // border: 4px solid #6d7c96;
      .font-wrap{
        // background:  #6d7c96;
        // box-shadow: 0 0 0 3px rgba( #6d7c96,.3),;
      }
      .compareType{
        background: #6d7c96;
        .arrow{
          border-right-color: #6d7c96;
        }
      }
    }
    #two-img.blacklistWarn{
      // background: rgba(252,61,26,0.2);
      // border: 4px solid #fc3d1a;
      .font-wrap{
        // background:  #fc3d1a;
        // box-shadow: 0 0 0 3px rgba( #fc3d1a,.3);
      }
      .compareType{
        background: #fc3d1a;
        .arrow{
          border-right-color: #fc3d1a;
        }

      }
    }
    .compareType{
      color: #fff;
      line-height: 20px;
      height: 20px;
      // line-height: 30px;
      // height: 30px;
      position: absolute;
      overflow: visible;
      // right: 0;
      // top: 2px;
      top: 0px;
      left: 0px;
      width: 126px;
      // width: 111px;
      // width: 133px;
      text-align: center;
      // padding-left: 16px;
      // text-align: left ;
      border-top-left-radius:4px;
      // &::after {
      //   content: '';
      //   position: absolute;
      //   // width: 20px;
      //   // height: 30px;
      //   right: 0;
      //   top: 0;
      //   // border-top: 15px solid transparent;
      //   // border-bottom: 15px solid #fff;
      //   // border-left: 15px solid transparent;
      //   // border-right: 15px solid #fff;
      //   border-top: 30px solid transparent;
      //   border-bottom: 0px solid #fff;
      //   border-left: 0px solid transparent;
      //   border-right: 20px solid #fff;
      // }
      .arrow{
        position: absolute;
        z-index: 1;
        top: 0;
        left: -16px;
        border: 8px solid  transparent;
      }
    }
  </style>
