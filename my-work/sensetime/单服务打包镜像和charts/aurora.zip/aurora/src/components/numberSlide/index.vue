<template>
  <div ref="numberSlide" class="number-slide" :style="'transform:scale('+scaleValue+')'">
    <i v-for="item in numberList" :style="'transform:translateY(-' +item + 'em)'" :key="item.key">{{item}}</i>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';

  @Component({})
  export default class NumberGrow extends Vue {
    @Prop({ default: '' }) growValue!: any;
    numberList:any = []
    scaleValue = 1;

    @Watch('growValue')
    onValueChanged(n, o) {
      this.creatNumber();
      if(n.toString().length > 7){
        this.scaleValue = 0.8;
      }
    };
    mounted(){
      this.creatNumber();
      if(this.growValue.toString().length > 7){
        this.scaleValue = 0.8;
      }
    }
    creatNumber(){
      let arr = String(this.growValue).split('');
      this.numberList = arr;
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.number-slide {
  font-size: 22px;
  overflow: hidden;
  line-height:1;
  height: 1em;
  width: 100%;
  text-align: center;
  color: rgba(255, 255, 255, 0);
  i{
    font-style: normal;
    position: relative;
    // width: 1em;
    display: inline-block;
    transition: all 1.5s ease 0s;
    &::after{
      content:'0 1 2 3 4 5 6 7 8 9';
      position:absolute;
      color:#fff;
      font-weight: normal;
      display: block;
      width: 1em;
      line-height: 1em;
      left: -0.25em;
      top: 0;
    }
  }
}
@media (max-width: 1440px){
  .number-slide {
    font-size: 20px;
  }
}
</style>
