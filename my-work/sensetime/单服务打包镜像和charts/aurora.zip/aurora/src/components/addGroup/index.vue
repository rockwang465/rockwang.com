<template>
  <div v-if="dialogShowVisible">
    <el-dialog :title="dataObj.title" :visible.sync="dialogShowVisible" width="584px">
      <br>
      <el-input
        style="width:296px"
        size="medium"
        suffix-icon="el-icon-search"
        v-model="filterText">
      </el-input>
      <br>
      <div style="height: 150px;overflow: auto;width: 296px;">
        <el-tree
          ref="tree"
          :data="dataObj.treeData"
          :props="defaultProps"
          :filter-node-method="filterNode"
          node-key="id"
          :render-content="renderContent"
        />
      </div>
      <div class="timezone-timezone-footer">
        <el-button type="primary" :loading="loading" @click="confirmData">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {isEmpty} from '@/utils/validate';
  import {DeviceModule} from '@/store/modules/device';

  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      }
    }
  })
  export default class AddGroup extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    filterText = "";
    loading = false;
    defaultProps = {
      children: 'children',
      label: 'name',
    };
    checkLabel = "";
    @Prop(Object) dataObj!: any[];

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.loading = false;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeEdit")
        this.filterText = '';
      }
    }

    //监听搜索框的值,检索
    @Watch('filterText')
    onFilterTextChange(val: string) {
      (this.$refs.tree as any).filter(val);
    }

    //根据值过滤掉不匹配的分支
    filterNode(value: string, data: any) {
      if (!value) {
        return true;
      }
      return data.name.indexOf(value) !== -1;
    }

    confirmData() {
      let that = this as any;
      that.loading = true;
      let deviceIds = that.getDeviceIds(that.dataObj.multipleSelection)
      if (isEmpty(deviceIds) || deviceIds.size == 0) {
        that.$message({
          showClose: true,
          message: that.$t('devicemanagement.chooseDevice'),
          type: 'error'
        });
        that.dialogShowVisible = false;
        return
      }
      switch (that.dataObj.type) {
        case "addGroup":
          if (isEmpty(that.checkLabel)) {
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.chooseGroup'),
              type: 'error'
            });
            that.dialogShowVisible = false;
            return
          }
          DeviceModule.DeviceAddGroupBatch({deviceIds: deviceIds, groupId: that.checkLabel}).then((data: any) => {
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.devicesMoveGroupSuccess'),
              type: 'success'
            });
            that.dialogShowVisible = false;
            that.loading = false;

          }).catch((err) => {
            console.log(err)
            that.loading = false;
          });
          break;
      }
    }


    getDeviceIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        ids.push(array[i].deviceId);
      }
      return ids;
    }

    renderContent(h, {node, data, store}) {
      let that = this as any;
      switch (that.dataObj.type) {
        case "addGroup":
          if (isEmpty(data.children)) {
            return h('div', {
              style: {
                width: '100%'
              },
            }, [
              h("el-radio", {
                on: {
                  input: function (event) {
                    that.checkLabel = event
                  }
                },
                props: {
                  value: that.checkLabel,
                  label: data.id,
                  key: data.id
                },
              }, node.label)
            ]);
          } else {
            return h('div', {
              style: {
                width: '100%'
              },
            }, [
              h("el-radio", {
                on: {
                  input: function (event) {
                    that.checkLabel = event
                  }
                },
                props: {
                  value: that.checkLabel,
                  label: data.id,
                  key: data.id
                },
              }, node.label)
            ])
          }
      }
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .timezone-timezone-footer {
    text-align: center;
    padding: 20px;
  }

  .cancel {
    background-color: rgba(162, 176, 199, 0.3) !important;
  }
</style>
