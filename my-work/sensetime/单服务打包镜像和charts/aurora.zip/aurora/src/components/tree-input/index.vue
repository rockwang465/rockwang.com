<template>
    <div  class="tree-input">
      <span
        v-if="name"
        class="title"
      >
        {{name}}
      </span>
    <el-dropdown
      trigger="click"
      placement="bottom-start"
      @visible-change="handleDropdown"
      ref="messageDrop"
    >
      <el-input
        :class="count?'':'isCount'"
        :value="inputText"
      >
       <span class="suffix-icon" slot="suffix">
         <Icon
          v-show="IconShow"
           type="ele"
           size="15"
           cursor="pointer"
           name="circle-close"
          @click="clkShow"
         />
       </span>
      </el-input>

      <el-dropdown-menu class="tree-container" slot="dropdown">
        <div class="filter-input">
          <el-input
            prefix-icon="el-icon-search"
            placeholder=""
            v-model="filterWord"
          >
          </el-input>
        </div>

      <el-checkbox v-if="isShowCheckedAll" class="select-all" v-model="checked" @change="checkedAll">{{$t('records.contSelectAll')}}</el-checkbox>

        <el-tree
          show-checkbox
          :data="data"
          :props="defaultProps"
          :filter-node-method="filterNode"
          @check-change="handleCheckChange"
          ref="tree"
          :node-key="nodeKey"
          @check='pitchOn'
        >
        </el-tree>
      </el-dropdown-menu>
    </el-dropdown>
    </div>
</template>

  <script lang="ts">
  import { Component,Prop, Vue, Watch, Emit } from 'vue-property-decorator';
  import  Icon from '@/components/icon-wrap/index.vue';
  import {EventBus} from '@/utils/eventbus';
  var _ = require('lodash/lang');

  @Component({
    components:{
      Icon
    }
  })
  export default class TreeInput  extends Vue{
    @Prop({default:[]}) data!:Array<String>
    @Prop({default:""}) name!:String
    @Prop({default:"id"}) nodeKey!:String
    @Prop({default:"label"}) label!:String
    @Prop({default:"children"}) children!:String
    @Prop({default:""}) map!:String
    @Prop({default:""}) valText!:String

    filterWord="";
    count:any=0;
    checked:boolean = false;
    filterList = [] as any;
    newArr :any[] = []
    isShowCheckedAll:boolean = true
    get inputText(){
        return this.valText && !this.count ? this.valText : this.$t("records.contSelected",{number:this.count})
    }
    get defaultProps(){
      return {
        children: this.children,
        label: this.label,
        id:this.nodeKey,
      }
    }
    IconShow :boolean= false;

    @Watch("loading")
    onloading(val){
    }
    @Watch("filterWord")
    filterTree(val){
      (this.$refs.tree as any).filter(val);
      this.isShowCheckedAll = false
      if(val === '') {
        this.isShowCheckedAll = true
      }
      // this.pitchOn()
    }

    @Emit("dropDown") //下拉框事件
    handleDropdown(val){
      return val;
    }
    @Emit("checkout")
    handleCheckChange(data, checked, indeterminate) {//选择复选框事件
        let key=(this.$refs.tree as any) .getCheckedKeys(true)
        // console.log(key)

        let reg = /^g_/
        key = key.filter((val)=>{
          return !reg.test(val)
        })
        this.count = key.length
        if(this.count == 0){
          this.IconShow = false
        }else {
          this.IconShow = true
        }
        return key
    }
    //设置选中为空
    clearCheckout() {
        let key=(this.$refs.tree as any).setCheckedKeys([])
    }
    mounted(){
      //console.log("data类型",this.data)
      // let obj = (this.$refs.tree as any).store.nodesMap
      // for (const key in obj) {
      //   if (obj.hasOwnProperty(key)) {
      //     // const element = object[key];
      //     console.log(obj[key].data);
      //     // if(obj[key].data.isShow) {
      //     //   this.newArr.push(obj[key].data)
      //     // }
      //     obj[key].data.isShow = true
      //   }
      // }
    }


    created() {
      EventBus.$on('clearAll' , (data :boolean)=> {
        this.checked = data
        this.filterWord = ''
      })
    }

    filterNode(value, data) {
      // console.log(this.data)
      // data.isShow = true
      // console.log(value);

      // data.disabled = false

      if((data[this.label+'']).indexOf(value) == -1) {
        // console.log(data.name.indexOf(value));
        data.isShow = false
        data.disabled = true
        if((data[this.nodeKey as string] + '').indexOf('g_') == -1) {
          data.disabled = true;
        }
        if(data.children && data.children.length != 0) {
          data.disabled = false;
        }
      }else {
        data.isShow = true
        data.disabled = false
      }

      // if(value == '' ) {
      //   data.disabled = false
      // }

      // console.log(data.name , data.isShow);
      // let strId = data.id +''
      // console.log(strId);

      // if(strId.indexOf('g_') == -1 ) {
      //   if (data.name.indexOf(value) == -1 && !data.children){
      //      data.disabled = true;
      //   }
      //     data.disabled = false;
      //     // this.filterList = [];

      // } else {
        // if ((data[this.label+'']).indexOf(value) == -1 && (data[this.nodeKey+'']).indexOf('g_') == -1){
        //   data.disabled = true;
        // }else  {
        //   data.disabled = false;
        //   // this.filterList = [];
        // }
      // }

      // console.log(this.nodeKey+'');

      // return data.name.indexOf(value) !== -1;
      if (!value) return true;
      // console.log(this.label);

      // data.disabled = !(data[this.label+''].indexOf(value) !== -1)
      return data[this.label+''].indexOf(value) !== -1;
    }

    getNewArr () {
      let obj = (_.cloneDeep((this.$refs.tree as any).store.nodesMap))
      // let newArr :any[] = []
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          // const element = object[key];
          // console.log(obj[key].data);
          if(obj[key].data.isShow) {
            this.newArr.push(obj[key].data)
          }
        }
      }
    }

    //全选
    checkedAll() {
      // this.getNewArr()
      // console.log(this.newArr);

      if(this.checked) {
        // console.log('this.filterWord ------------' ,this.filterWord);

        if(this.filterWord === '') {
          return (this.$refs.tree as any).setCheckedNodes(this.data)

        }
          // (this.$refs.tree as any).setCheckedNodes(this.filterList)
        // (this.$refs.tree as any).setCheckedNodes(this.newArr)
      }else {
        (this.$refs.tree as any).setCheckedNodes([])
      }
      this.newArr = []
    }


    pitchOn(){
      // console.log(this.$refs.tree);
        // this.getNewArr()

        let data = this.filterWord === '' ? this.data:this.newArr
        // console.log(data);

        let fData :any= []
        data.forEach(item => {
          // console.log((this.$refs.tree as any) .getNode(item));

          fData.push((this.$refs.tree as any) .getNode(item).checked)
        });

        // console.log(fData);
       let check = fData.length == 0 ? 'false' :fData.every(item=>item)
      //  console.log(check);

       this.checked = check
        this.newArr = []
    }

    clkShow(e){
      this.IconShow = false;
      e.stopPropagation();
      (this.$refs.tree as any).setCheckedNodes([]);
      this.checked= false
    }

    messageDrophide () {

      (this.$refs.messageDrop as any).hide();

    }

  }
  </script>

  <style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
    .tree-input{
      display: flex;
      // padding: 3px 10px;
      .title{
        padding-right:3px;
        padding-left:10px;
        display: inline-block;
        /*line-height: 28px;*/
        white-space:nowrap;
      }
    }
    .tree-container{
      max-height:400px;
      overflow: scroll;
    }
    .filter-input{
      padding: 5px 15px;
    }
    ::v-deep .select-all{
      margin-left: 24px;
      .el-checkbox__input{
        margin-right:8px;
      }
    }
    ::v-deep .el-checkbox__label {
      padding: 0px;
    }

    ::v-deep .isCount .el-input__inner {
      color: #c0c4cc;
    }
    // #c0c4cc
  </style>

