<template>
  <div class="treeselsect-container" :style="{width:inputWidth}">
    <el-popover
      ref="treeselsect-popover"
      placement="bottom"
      trigger="click"
      v-model="visible">
        <div slot="reference"  class="treeselsect-selected" >
          <el-input type="text" v-if="type==='border'" :placeholder="$t('form.texterrSelectDeviceGroup')" v-model="inputText" />
          <div v-else class="treeselsect-selected-text" tabindex="-1">
            <div  :class="['treeselsect-selected-contents',type==='border'?'treeselsect-selected-contents-border':'']" :style="{width:`calc(${inputWidth} - 15px)`}" >{{ selectedNodes.length>0 ? $t('rule.textboxNumberSelected',{number:selectedNodes.length}):$t('rule.contPleaseSelect')}}</div>
            <span  :class="['treeselsect-selected-icon',type==='border'?'treeselsect-selected-icon-border':'']" >
              <i class="el-icon-arrow-down" v-show="type==='border'" ></i>
            </span>
          </div>
        </div>
        <div class="treeselsect-content">
          <el-input
            :placeholder="$t('liveservice.contDeviceSearch')"
            v-model="filterText">
          </el-input>
          <div >
            <el-tree
              @check-change="treeCheck"
              v-bind="$attrs"
              :data="data"
              :node-key="nodeKey"
              ref="tree"
              class="treeselsect-tree"
              :filter-node-method="filterNode"
              default-expand-all
              :props="{label:'name'}"
              :default-checked-keys="defaultChechedKeys"
              :render-content="renderContent"
              :show-checkbox="multiple"
              >
            </el-tree>
          </div>

          <div class="treeselsect-btns" >
            <el-button size="mini" type="text" @click="visible = false">{{$t('rule.buttonCancel')}}</el-button>
            <el-button type="primary" size="mini" @click=" ensureSelect ">{{$t('rule.buttonOK')}}</el-button>
          </div>
        </div>
    </el-popover>
  </div>
</template>

<script lang="tsx">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import { setTimeout } from 'timers';

@Component({
  components: {

  },
})
export default class TreeSelect extends Vue {

  /* props */
  @Prop(Array) data!: any[];
  @Prop({default: [] }) defaultChechedKeys!: any[];//默认选中
  @Prop({default: 'auto' }) inputWidth!: string;//宽度  默认100%
  @Prop({default: '',required:false }) type!: string;//border 表示 有框  默认无框
  @Prop({default:true,required:false}) multiple !: boolean;//是否可以多选 默认可以多选
  // @Prop({default:false,required:false}) viewModel !: boolean;//是否可以多选 默认可以多选
  @Prop({default:false,required:false}) alarmType !: boolean;//修复默认选中的设备问题（只针对告警推送页面）

  /* watch */
  @Watch('visible', { immediate: false, deep: false })
  onVisibleChanged(val: boolean, oldVal: boolean) {
    this.multiple
    ?this.$refs.tree.setCheckedKeys(this.defaultChechedKeys)
    :(this.defaultChechedKeys.length == 1?this.setRadioChecked(this.defaultChechedKeys[0]):'')
  }
  @Watch('filterText', { immediate: false, deep: false })
  onDataChanged(val: string, oldVal: string) {
    this.$refs.tree.filter(val);
  }
  @Watch('defaultChechedKeys', { immediate: true, deep: true })
  ondefaultChechedKeysChanged(val: any, oldVal: any) {
    if(val.length == 0){
      this.selectedNodes=[];
      this.setInputText();
    }
    this.alarmType && this.$refs && this.$refs.tree && this.$refs.tree.setCheckedKeys(val);//修复默认选中的设备问题
  }

  /* data */
  $refs!: {
    tree: HTMLFormElement
  };
  visible:boolean=false;
  inputText:string='';
  filterText:string='';
  selectedNodes:any[]=[];

  nodeKey:string=this.$attrs['node-key'] || 'id';

  radioModel:any={};
  /* methods */
  mounted() {
    this.radioModel={};
  }
  filterNode(value, data) {
    if(data.name.indexOf(value) == -1 && data.type == 1){
      data.disabled = true;
    }else{
      data.disabled = false;
    }
    if (!value) return true;
    return data.name.indexOf(value) !== -1;
  }
  // setDisabled(data,node){
  //   if(this.viewModel){
  //     return true;
  //   }else{
  //     node.isLeaf = data.type == 1;
  //     return this.multiple && data.children && data.children.length>0 ?false:!node.isLeaf;
  //   }
  // }
  setRadioChecked(checkedKey){
    let node:any = this.$refs.tree.getNode(checkedKey);
    if(node && node.data){
      this.radioModel = node.data;
    }
  }
  ensureSelect(){
    //单选判断
    let selectedData =this.multiple? this.$refs.tree.getCheckedNodes(true):[this.radioModel];
    // if(!this.multiple &&  selectedData.length>1){
    //   this.$message({
    //     message: '只能选中一个',
    //     type: 'warning'
    //   });
    //   return ;
    // };
    this.selectedNodes = selectedData;
    let data = this.selectedNodes;
    this.$emit('selected',data);
    this.visible = false;
    this.setInputText();
  }
  setInputText(){
    this.inputText = this.selectedNodes.length>0 ?  this.$t('rule.contSelected',{number:this.selectedNodes.length}) as any :this.$tc('rule.contPleaseSelect');
  }
  treeCheck(data,val){
    this.selectedNodes = this.$refs.tree.getCheckedNodes(true);
    // this.setInputText();
  }
  renderContent(h,{node,data,store}){
    node.isLeaf = data.type == 1;
    return  this.multiple
            ?<span title={data.name}  >{data.name}</span>
            : (data.type == 1 ?<el-radio v-model={this.radioModel} label={data}>{data.name}</el-radio>:<span title={data.name}>{data.name}</span>)
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .treeselsect-container{
    display: inline-block;
    position: relative;
    background-color: #fff;
  }
  .treeselsect-selected{
    // padding: 5px 0;
    position: relative;
    .treeselsect-selected-contents{
      width: 158px;
      text-align: left;
      text-indent: 15px;
      // padding: 0px 58px;
      display: inline-block;
    }
    .treeselsect-selected-icon{
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 5px 0 6px;
    }
    .treeselsect-selected-contents-border{
      padding: 0px 25px 0px 10px;
      display: inline-block;
      border: 1px solid $--color-text-placeholder;
    }
    .treeselsect-selected-icon-border{
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 12px 0 13px;
      position: relative;
      left: -15px;
    }
    .treeselsect-selected-text{
      border:1px solid #c2cad8;
      padding: 5px 0;
    }
    .treeselsect-selected-text:focus{
      border-color:#2a5af5;
    }
  }
  .treeselsect-content{
    .treeselsect-btns{
      width: 100%;
      text-align: right;
    }
    .treeselsect-tree{
      max-width:300px;
      min-height: 200px;
      max-height: 300px;
      overflow: auto;
    }

  }
</style>
