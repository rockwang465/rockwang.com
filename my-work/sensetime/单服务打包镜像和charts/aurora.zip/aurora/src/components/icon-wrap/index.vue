<template>
   <i v-if="type==='icon'" class="iconfont" :class="iconName" :style="style" @click="handleClick"></i>
   <i v-else-if="type==='ele'" class="el-input__icon" :class="iconName" :style="style" @click="handleClick"></i>
</template>

  <script lang="ts">
  import { Component,Prop, Vue, Watch, Emit } from 'vue-property-decorator';

  @Component({

  })

  export default class Icon  extends Vue{
    @Prop({default:"icon"}) type !: String
    @Prop({default:""})     name !: String
    @Prop({default:"16"})   size !: String
    @Prop({default:""})   cursor !: String
    style:any={fontSize:""};

    //  @Watch('size')
    //   onSizeChanged(val: string, oldVal: string) {
    //     console.log(val)
    //   }

     get iconName(){
      if(this.type=="ele"){
        return "el-icon-"+this.name
      }else {
        return "icon-"+this.name
      }
    }
    mounted(){
      this.style.fontSize=this.size+"px";
      this.style.cursor=this.cursor;
    }

    @Emit('click')
    handleClick(){

    }
  }
  </script>

  <style rel="stylesheet/scss" lang="scss" scoped>

  </style>

