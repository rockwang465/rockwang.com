<template>
  <div class="treeselsect-container" style="width:100%">
    <el-popover
      ref="treeselsect-popover"
      placement="bottom"
      width="300"
      :disabled="disabled"
      trigger="click"
      v-model="visible">
      <div slot="reference" class="treeselsect-selected">
        <!--请选择，已选择N个-->
        <div class="add-user-tree" :class="disabled?'add-user-tree-disabled':''">{{dataObj.userIds.length>0 ?$t('records.contSelected',{number:dataObj.userIds.length}):$t('records.contPleaseSelect')}}</div>
        <!--<div class="add-user-tree">{{dataObj.userIds.length>0 ? '已选'+dataObj.userIds.length+'个':'请选择'}}</div>-->
      </div>
      <div class="treeselsect-content">
        <el-input
          size="small"
          v-model="filterText">
        </el-input>
        <el-tree v-if="visible"
          ref="tree"
          :data="data"
          :props="defaultProps"
          :filter-node-method="filterNode"
          :default-expanded-keys="dataObj.defaultIds"
          :default-checked-keys="dataObj.defaultIds"
          node-key="id"
          @check="checkChange"
          show-checkbox
        />
        <div class="treeselsect-btns">
          <el-button size="mini" type="info" @click="visible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
          <el-button type="primary" size="mini" @click="ensureSelect">{{$t('devicemanagement.buttonOK')}}</el-button>
        </div>
      </div>
    </el-popover>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Prop, Watch} from 'vue-property-decorator';

  @Component({
    components: {},
  })
  export default class TreeSelect extends Vue {

    /* props */
    @Prop(Array) data!: any[];
    @Prop({default: []}) dataObj!: any;//默认选中
    @Prop({default:false,required:false}) disabled !: boolean;

    defaultProps = {
      children: 'children',
      label: 'name',
    };

    mounted(){
    }
    @Watch('visible')
    onVisibleChange(val: any) {
      this.filterText = '';
    }

    @Watch('filterText', {immediate: false, deep: false})
    onDataChanged(val: string, oldVal: string) {
      if (val){
        this.$refs.tree.filter(val);
      } else{
        this.$refs.tree.filter('');
      }
    }

    filterNode(value, data) {
      if (data.name.indexOf(value) == -1&&data.type == 1){
        data.disabled = true;
      }else if (data.adminRole != 1) {
        data.disabled = false;
      }
      return data.name.indexOf(value) !== -1;
    }

    checkChange(){

    }


    /* data */
    $refs!: {
      tree: HTMLFormElement
    };

    visible: boolean = false;
    filterText: string = '';


    ensureSelect() {
      let userIds = this.getUserIds(this.$refs.tree.getCheckedKeys());
      this.$emit("selected", {userIds: userIds, defaultIds: this.$refs.tree.getCheckedKeys()})
      this.visible = false;
    }

    getUserIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        let arr = (array[i] + '').split('_');
        arr.length == 1 ? ids.push(arr[0]) : ''
      }
      return ids;
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";

  .el-input {
    width: 224px
  }

  .el-tree{
    max-height: 300px;
    overflow: auto;
  }

  .treeselsect-container {
    display: inline-block;
    position: relative;
    background-color: #fff;
  }

  .treeselsect-selected {
    position: relative;

    .treeselsect-selected-contents {

      padding: 0px 5px;
      display: inline-block;
    }

    .treeselsect-selected-icon {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 5px 0 6px;
    }

    .treeselsect-selected-contents-border {
      padding: 0px 25px 0px 10px;
      display: inline-block;
      border: 1px solid $--color-text-placeholder;
    }

    .treeselsect-selected-icon-border {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 12px 0 13px;
      position: relative;
      left: -15px;
    }
  }

  .treeselsect-content {
    .treeselsect-btns {
      width: 100%;
      text-align: right;
    }

    .treeselsect-tree {
      min-height: 200px;
      max-height: 300px;
      overflow: auto;
    }
  }

  .add-user-tree {
    height: 32px;
    width: 224px;
    border: 1px solid #c0c4cc;
    cursor: pointer;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    line-height: 32px;
    letter-spacing: 0px;
    color: #28354d;
    padding-left: 13px;
    border-radius: 4px;
  }
  .add-user-tree-disabled{
    background-color: #6d7c96;
    border-color: #cfd6e0;
    color: #c0c4cc;
    cursor: not-allowed;
  }

</style>
