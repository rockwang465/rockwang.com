<template>
  <div class="treeselsect-container" style="width:100%">
    <el-popover
      ref="treeselsect-popover"
      placement="bottom"
      width="300"
      :disabled="disabled"
      trigger="click"
      v-model="visible">
      <div slot="reference" class="treeselsect-selected">
        <el-tooltip v-if="checkedLabelV&&checkedLabelV.length>16" class="item" effect="dark" :content="checkedLabelV" placement="top">
          <!-- <div class="add-user-tree">{{checkedLabelV}}</div> -->
          <el-input size="small" :disabled="disabled" v-model="checkedLabelV"></el-input>
        </el-tooltip>
        <el-input size="small" v-else :disabled="disabled" v-model="checkedLabelV"></el-input>
        <!-- <div class="add-user-tree" v-else>{{checkedLabelV}}</div> -->
      </div>
      <div class="treeselsect-content">
        <el-input
          size="small"
          v-model="filterText">
        </el-input>
        <el-tree v-if="visible"
                 ref="tree"
                 :data="selectGroupObj.treeData"
                 :props="defaultProps"
                 :filter-node-method="filterNode"
                 node-key="id"
                 :render-content="renderContent"
        />
        <div class="treeselsect-btns">
          <el-button size="mini" type="info" @click="visible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
          <el-button type="primary" size="mini" @click="ensureSelect">{{$t('devicemanagement.buttonOK')}}</el-button>
        </div>
      </div>
    </el-popover>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Prop, Watch} from 'vue-property-decorator';
  import {isEmpty} from '@/utils/validate';

  @Component
  export default class TreeSelect extends Vue {
    $refs!: {
      tree: HTMLFormElement
    };
    visible: boolean = false;
    filterText: string = '';
    @Prop({default: []}) selectGroupObj!: any[];
    @Prop({default:false,required:false}) disabled !: boolean;
    defaultProps = {
      children: 'children',
      label: 'name',
    };
    checkLabel = "";
    checkedLabelV = "";

    mounted() {
      let that = this as any;
      that.checkLabel = that.selectGroupObj.checked
      that.checkedLabelV = that.selectGroupObj.checkedLabel
    }

    @Watch('visible')
    onVisibleChanged(val: string) {
      let that = this as any;
      that.checkLabel = that.selectGroupObj.checked
      that.checkedLabelV = that.selectGroupObj.checkedLabel
    }

    @Watch('filterText')
    onDataChanged(val: string) {
      this.$refs.tree.filter(val);
    }

    filterNode(value, data) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1;
    }

    ensureSelect() {
      let al = this.checkLabel
      this.visible = false
      if (!isEmpty(al)) {
        let arr = al.split(',');
        this.checkedLabelV = arr[1]
        this.$emit('selected', arr[0], arr[1])
      } else {
        this.$emit('selected', '', '')
        this.checkedLabelV = '请选择'
      }
    }

    renderContent(h, {node, data, store}) {
      let that = this as any;
      //if (isEmpty(data.children)) {
      return h('div', {
        style: {
          width: '100%'
        },
      }, [
        h("el-radio", {
          on: {
            input: function (event) {
              that.checkLabel = event
            }
          },
          props: {
            value: that.checkLabel,
            label: data.id + ',' + node.label,
            key: data.id + '' + node.label
          },
        }, node.label)
      ]);
      /* } else {
         return h('div', {
           style: {
             width: '100%'
           },
         }, [node.label])
       }*/
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .treeselsect-container .el-input {
    width: 224px;
  }

  .el-tree {
    max-height: 300px;
    overflow: auto;
  }

  .treeselsect-container {
    display: inline-block;
    position: relative;
    background-color: #fff;
  }

  .treeselsect-selected {
    position: relative;

    .treeselsect-selected-contents {

      padding: 0px 5px;
      display: inline-block;
    }

    .treeselsect-selected-icon {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 5px 0 6px;
    }

    .treeselsect-selected-contents-border {
      padding: 0px 25px 0px 10px;
      display: inline-block;
      border: 1px solid $--color-text-placeholder;
    }

    .treeselsect-selected-icon-border {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 12px 0 13px;
      position: relative;
      left: -15px;
    }
  }

  .treeselsect-content {
    .treeselsect-btns {
      width: 100%;
      text-align: right;
    }

    .treeselsect-tree {
      min-height: 200px;
      max-height: 300px;
      overflow: auto;
    }
  }

  .add-user-tree {
    height: 32px;
    width: 224px;
    border: 1px solid #c0c4cc;
    cursor: pointer;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    line-height: 32px;
    letter-spacing: 0px;
    color: #28354d;
    padding-left: 13px;
    overflow: hidden; /*超出部分隐藏*/
    text-overflow: ellipsis; /* 超出部分显示省略号 */
    white-space: nowrap; /*规定段落中的文本不进行换行 */
  }

</style>
