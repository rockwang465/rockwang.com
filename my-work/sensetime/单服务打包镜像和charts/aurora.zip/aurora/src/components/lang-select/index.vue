<template>
  <el-dropdown trigger="click" class="international" @command="handleSetLanguage">
    <slot>
      <div class="el-dropdown-link">
        <i ref="icon" class="iconfont icon-en" :style="'font-size:'+size"></i>
      </div>
    </slot>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item :disabled="language==='zh'" command="zh">中文</el-dropdown-item>
      <el-dropdown-item :disabled="language==='en'" command="en">English</el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</template>

<script lang="ts">
import { Component, Vue,Prop, Watch,Inject } from 'vue-property-decorator';
import { RouteRecord } from 'vue-router';
//import pathToRegexp from 'path-to-regexp';
import { AppModule } from '@/store/modules/app';
import { getSystem } from "@/store/modules/system";
import { imageOverlay } from 'leaflet';
import {UserModule} from '@/store/modules/user';
import {Cache} from '@/utils/cache';

@Component({

})
export default class LangSelect extends Vue {
  @Prop({default:"14px"}) size!:string
  levelList: RouteRecord[] = [];
  get language() {
    return AppModule.language;
  }
  //@Watch('$route')
  //('reload')
  // inject:{
  //   reload :'reload'
  // }
  //inject = ['reload']

  created() {

  }
  mounted(){
    //return this.$store.getters.language;
    document.documentElement.classList.add(this.language);
    document.documentElement.setAttribute('lang',this.language);

    //(this.$refs.icon as any).style.fontSize=this.size;
  }

  handleSetLanguage(lang:string) {
    let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');

    // getSystem.updateSystemInfo(params).then((data:any)=>{
    //   console.log(data)
    // }).catch((err) => {

    // });


    document.documentElement.classList.remove(this.$i18n.locale);
    document.documentElement.classList.add(lang);
    this.$i18n.locale = lang;
    //this.$store.dispatch('setLanguage', lang);
    AppModule.SetLanguage(lang).then((result) => {
      this.$emit("changeLang")
    }).catch((err) => {

    });
    this.$message({
      showClose: true,
      message: this.$tc('switchLang'),
      type: 'success',
      duration:800
    })

    if (user){
      let userId = user.userId;
      let params = {
        language:lang == "zh"?1:2,
        userId:userId
      } as any;

      UserModule.updateUserLanguage(params).then(res=>{
        //console.log(res);
      }).finally(()=>{
        window.location.reload()
      })
    }else{
      window.location.reload()
    }

    //this.reload()
    //console.log(this.$parent.$parent)
  }
}

</script>

<style scoped>
.icon-duoyuyan{font-size: 24px;color: #fff;}
.international{
  /* position: absolute; */
  /* width: 30px; */

  }
.international .icon-en{font-size: 16px;color: #fff}
.international-icon {
  font-size: 20px;
  cursor: pointer;
  vertical-align: -5px!important;
}
</style>

