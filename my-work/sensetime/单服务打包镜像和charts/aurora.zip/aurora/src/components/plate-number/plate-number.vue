<template>
  <el-input class="input-with-select"  v-model="carNumber" @blur="verifyCarNumber" :maxlength="numberLength">
    <el-select class="plate-select" v-model="select" value="select" slot="prepend" :placeholder="$t('visitor.visitorlist.labelProvince')" popper-class="plate-number" @change="selectCode" clearable @clear="clearData">
      <el-option-group>
<!--        新能源-->
        <el-checkbox v-model="isNewEnergy" @change="newEnergy">{{$t('visitor.visitorlist.cleanResource')}}</el-checkbox>
        <!-- <el-button class="clear" @click="clearData" size="mini">清除</el-button> -->
      </el-option-group>
      <el-option-group>
        <el-option
          v-for="(item,i) in provinceCode"
          :key="i"
          :label="item"
          :value="item">
        </el-option>
      </el-option-group>
    </el-select>
  </el-input>
</template>

<script lang="ts">
import { Component, Vue, Watch,Prop } from 'vue-property-decorator';

@Component({
})
export default class PlateNumber extends Vue {
  @Prop({ default: '' }) length!: any;
  @Prop({ default: '' }) oldCarNumber!: any;
  carNumber= '';
  select= '';
  isNewEnergy = false;
  numberLength = 6;
  errorMsg="";
  isProvince = true;
  provinceCode = ["京","沪","浙","苏","粤","鲁","晋","冀","豫","川","渝","辽","吉","黑","皖","鄂","津","贵","云","桂","琼","青","新","藏","蒙","宁","甘","陕","闽","赣","湘","使","领","其他"]
  //@Watch('$route')
  created() {

  }
  mounted(){

    if(this.oldCarNumber){
      //console.log("编辑:车牌号",this.oldCarNumber);
      if(this.provinceCode.includes(this.oldCarNumber.substring(0,1))){
        this.select = this.oldCarNumber.substring(0,1);
        this.carNumber = this.oldCarNumber.substring(1);
      }

    }else{
      this.select = '';
      this.carNumber = '';
    }
  }
  clearData(){
    this.select = '';
    this.$emit('getCarNumber','');
  }
  selectCode(e){
    //console.log(e)
    this.isProvince=true;
    this.select = e;
    this.errorMsg ="";
    if(e){
      this.isProvince = false
    }

  }
  verifyCarNumber(){
    this.errorMsg = "";
    if(this.carNumber.length > 0){
      let reg= /^[A-Z]/;
      console.log(this.carNumber,!reg.test(this.carNumber))
      if(!this.select){
        this.errorMsg ="请选择省份";
      }
      if (!reg.test(this.carNumber)){
        this.errorMsg = "第一个字符需为大写字母";
      }
      if(this.carNumber.length < this.numberLength){
        this.errorMsg = "格式输入不正确";
      }
    }else{
      this.errorMsg ="请输入车牌号";
    }
    //console.log('getCarNumber==>',this.select+this.carNumber,this.errorMsg)
    // this.$emit('getCarNumber',{carNumber:this.select+this.carNumber,isNewEnergy:this.isNewEnergy},this.errorMsg);
    this.$emit('getCarNumber',this.select+this.carNumber,this.errorMsg);
  }
  newEnergy(e){
    this.isNewEnergy = e;
    //console.log("新能源:",this.isNewEnergy)
    if(e){
      this.numberLength = 7;
    }else{
      this.numberLength = 6;
    }
    //this.verifyCarNumber()
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.input-with-select{
  .el-input-group__prepend{
    background-color:#EAF4FF;
    color:#28354D;
    padding:0;
    min-width:62px;
    .el-select{
      margin: 0;
      .el-input__inner{
        padding: 0;
        padding-right: 16px;
        height: 30px;
      }
    }
  }
  .el-input--suffix .el-input__inner{
    text-align:center;
  }
  .plate-select{
    display: block;
  }
}
.clear{position:absolute;right: 8px;top: 0px;padding: 3px 8px;}
.plate-number{
  border: solid 1px #dee5f0;
  .el-select-group__wrap:not(:last-of-type)::after{
    left: 0px;
    right: 8px;
    bottom:8px;
    height: 2px;
  }
  .el-select-group__wrap:not(:last-of-type){
    padding-bottom:14px;
  }

  .el-select-dropdown__list{
    width:260px; justify-content:flex-start;padding:8px;padding-right:0;padding-bottom:0;
  }
  .el-select-group{
    display:flex;
    flex-wrap:wrap;
  }
  .el-select-dropdown__item.hover{
    background-color:#EAF4FF
  }
  .el-select-dropdown__item{
    padding:0 6px;border:1px solid #EAF4FF;margin-right:8px;margin-bottom:8px;color:#28354D;
    line-height:28px;
    border-radius:2px;
    overflow:hidden;
    height:28px;
    font-weight:normal;
    .hover,&:hover{
      border-radius:2px;
      background-color:#2A5AF5;
      color:#fff;
    }
  }

}
</style>

