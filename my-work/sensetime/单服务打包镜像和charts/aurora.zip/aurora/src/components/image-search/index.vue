<template>
  <div class="image-search">
    <el-input v-if="!dragBoxVisible"
      type="text"
      v-model="inputKeyword"
      :placeholder="placeholderText">
      <span v-if="hasImg" slot="prefix">
        <img :src="base64Data" alt="">
        <i class="el-icon-error" @click="cancelImageSearch"></i>
      </span>
      <div slot="suffix">
        <i v-show="inputKeyword" @click="(e)=>{e.preventDefault(),inputKeyword = '',searchKeyword()}" style="cursor: pointer;" class="el-input__icon el-icon-circle-close"></i>
        <div style="position: relative;cursor: pointer;display:inline">
          <i class="el-input__icon iconfont icon-camera" ></i>
          <input class="file-input" type="file" ref="fileInput" @change="getImge" title="上传本地图片">
        </div>
        <i class="iconfont icon-separator"></i>
        <i class="el-input__icon iconfont icon-search" @click="searchKeyword"></i>
      </div>
    </el-input>

    <div v-if="dragBoxVisible" class="drag-area" ref="dragArea">
      <textarea name="dropBox">
      </textarea>
      <div class="drag-tips">
        <template v-if="isDargLoading">
          <i class="el-icon-loading"></i>
          {{tips.droping}}
        </template>
        <template v-else>
          <i class="el-icon-upload"></i>
          {{tips.dropbefore}}
        </template>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import {fileValidate} from '@/utils/validate.ts';
import i18n from '@/lang/index'
@Component({
  components: {

  },
})
export default class ImageSelect extends Vue {
  /* watch */
  @Watch('base64Data', { immediate: false, deep: false })
  onBase64DataChanged(n,o) {
    this.showImage=n?true:false;
  }

  dragBoxVisible= false;
  /* data */
  $refs!:{
    fileInput:HTMLFormElement,
    imagebox:HTMLFormElement,
    dragArea:HTMLDivElement
  };
  showImage:boolean=false;
  sourceType = 'web'
  base64Data:any='';
  inputKeyword=''
  tips = {
    dropbefore:i18n.t('records.dropbefore'),
    droping:i18n.t('records.droping')
  }
  isDargLoading = false
  hasImg = false;
  placeholderText = i18n.t('records.textboxEnterKeywordT')
  /* methods */
  //图片转化base64
  imgToBase64(url){
   return  new Promise((resolve,reject)=>{
      let img = new Image;
      img.crossOrigin="Anonymous";
      img.src = url;
      let reg = /^data:image/
      let canvas = document.createElement("canvas");
      // img.onload=function(){
      //   canvas.width = img.width;
      //   canvas.height = img.height;
      //   let ctx = canvas.getContext("2d");
      //   (ctx as any).drawImage(img, 0,0,img.width,img.height)
      //   resolve(canvas.toDataURL("image/jpeg"))
      // }
      if(!reg.test(url)){
        img.onload=function(){
          canvas.width = img.width;
          canvas.height = img.height;
          let ctx = canvas.getContext("2d");
          (ctx as any).drawImage(img, 0,0,img.width,img.height)
          resolve(canvas.toDataURL("image/jpeg"))
        }
      }else{
        resolve(url)
      }
    })
  }
  //验证图片类型
  verifyImgType(type){
    let reg = /^image\/(jpeg)|(png)|(bmp)$/
    if(!reg.test(type)){
      this.$message({
        showClose: true,
        message:this.$t("tools.errmsgImageType") as any,
        type: 'error',
        duration: 3 * 1000,
      });
      return false;
    }else{
      return true;
    }
  }
  borderRun(){
    //console.log(this.$refs)
    if(!this.$refs.dragArea.classList.contains('border-run')){
      this.$refs.dragArea.classList.add('border-run')
    }
  }
  borderStop(){
    //console.log(this.$refs.dragArea)
    if(this.$refs.dragArea.classList.contains('border-run')){
      this.$refs.dragArea.classList.remove('border-run')
    }
  }
  //验证图片大小
  verifyImgSize(size){
    let targetSize = 16*1024*1024
    if(size>targetSize){
      this.$message({
        showClose: true,
        message:this.$t("tools.errmsgImageSize") as any,
        type: 'error',
        duration: 3 * 1000,
      });
      return false;
    }else{
      return true;
    }
  }
  showLoad(){
    this.dragBoxVisible = true;
    this.isDargLoading = true
  }
  //拖拽上传图片搜索
  dragDrop(event,imgResultData?){
    this.isDargLoading = true
    // console.log(imgResultData)
    // console.log(event)
    this.dragBoxVisible=false
    event.preventDefault();
    var fileList = event.dataTransfer.files;
    new Promise((resolve,reject)=>{
      if(fileList.length===0){ //拖拽web图片
        //console.log('web图片',imgResultData)
        let img = event.dataTransfer.getData("text")
        //console.log(img)
        var substr = img.match(/src="(\S*)"/);
        // this.imageUrl =substr[1]
        // this.imgToBase64(substr[1]).then((base64)=>{
        //   resolve(base64)
        // })
        if(imgResultData){
          resolve(imgResultData)
        }
      }else{//拖拽本地资源
        var file = new FileReader()

        let fileReader = file.readAsDataURL(fileList[0])
        //if(this.verifyImgType(fileList[0].type)&&this.verifyImgSize(fileList[0].size)){}
        file.onload=(e)=>{
          let imageUrl = (e.target as any).result;
          resolve(imageUrl)
          // this.imgToBase64(imageUrl).then((data)=>{
          //   resolve(data)
          // })
        }
      }
    }).then((data)=>{
      //console.log(data);
      // (this.imageUrl as any) = data;
      this.$emit("imgData",data)
      this.hasImg = true;
      this.placeholderText = ''
      this.base64Data = data;
      //this.retrivalImg()//开始以图搜图
    }).then(()=>{
      this.isDargLoading = false
    })
  }
  getBase64Image(file){
    let self = this;
    let isValidatePic = this.beforePicUpload(file);
    // console.log(isValidatePic)
    if(!isValidatePic){
      return false;
    }
    this.isDargLoading = true
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend=()=> {
      let dataURL = reader.result;
      //console.log(dataURL)
      this.base64Data = dataURL;
      this.$emit('imgData',dataURL);
      this.hasImg = true;
      this.placeholderText = ''
      //reset input value after submit
      this.base64Data = dataURL;
      this.$refs.fileInput.value=null;
      self.isDargLoading = false
    };
  }
  searchKeyword(){
    this.$emit("keyWord",this.inputKeyword)
  }
  identifying(){
    //console.log('identifying')
    this.isDargLoading = true
  }
  //拖拽到目标区域
  showDragBox(){
    this.dragBoxVisible=true;
    this.isDargLoading = false
  }
  hideDragBox(){
    this.dragBoxVisible=false
  }
  dragenter(event){
    event.preventDefault();
    //this.showHeader();
    this.dragBoxVisible=true
  }
  //拖动结束时候触发
  dragend(event){
    event.preventDefault();
    this.dragBoxVisible=false
  }
  //拖拽离目标区域
  dragleave(event){
  }

  initData(){
    this.showImage=false;
    this.base64Data='';
  }
  handleClick(){
    this.$refs.fileInput.click();
  }
  dragover(evt){
    evt.stopPropagation();
    evt.preventDefault();
  }
  drop(evt){
    evt.stopPropagation();
    evt.preventDefault();
    let picLink = evt.dataTransfer.getData("text/plain") || evt.dataTransfer.getData("URL");
    if(picLink){
      this.getSrclinkImage(picLink);
    }else{
      let file = evt.dataTransfer.files[0];
      this.getBase64Image(file);
    }
  }
  getImge(e){
    let file = e.target.files[0];
    file && this.getBase64Image(file);
    this.$emit("sourceType","local")
  }
  beforePicUpload(file){
    let isFile = fileValidate(file,['png','jpg','jpeg','bmp'],16);
    if(!isFile.type){
      this.$refs.fileInput.value=null;
      this.$message.error({showClose: true,message:this.$tc('tools.errmsgImageType')} );
      return false;
    }
    if (!isFile.size) {
      this.$refs.fileInput.value=null;
      this.$message.error({showClose: true,message:this.$tc('tools.errmsgImageSize')});
      return false;
    }
    return true ;
  }
  //取消以图搜图
  cancelImageSearch(){
    this.hasImg=false;  //搜索框图片消失
    this.placeholderText = this.$t('records.textboxEnterKeywordT')
    this.$emit('cancel')
  }

  getSrclinkImage(url){
    let base64Data:any = '';
    // this.getBase64FromUrlImage(url,'png',(base64)=>{
    //   base64Data = base64;
    //   this.base64Data = base64Data;
    //   this.$emit('select',base64Data);
    // });
    this.getImageBase64FromSrc(url)

  }
  // getBase64FromUrlImage(url, ext, callback) {
  //   let canvas:any = document.createElement("canvas");
  //   let ctx:any = canvas.getContext("2d");
  //   let img = new Image;
  //   img.crossOrigin = 'Anonymous';
  //   img.src = url;
  //   img.onload = ()=> {
  //     canvas.width = img.width;
  //     canvas.height = img.height;
  //     ctx.drawImage(img, 0, 0, img.width, img.height);
  //     let dataURL = canvas.toDataURL("image/" + ext);
  //     callback.call(this, dataURL);
  //     canvas = null;
  //   };
  // }
  closeImage(){
    this.initData();
    this.$emit('select','');
  }
  getImageBlob(url, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open("get", url, true);
    xhr.responseType = "blob";
    xhr.onload = function() {
      if (this.status == 200) {
        if(cb) cb(this.response);
      }
    };
    xhr.send();
  }
  getImageBase64FromSrc(url){
    this.getImageBlob(url,(Blob)=>{
      // let reader = new FileReader();
      // reader.readAsDataURL(Blob);
      // reader.onloadend=()=> {
      //   let dataURL = reader.result;
      //   this.base64Data = dataURL;
      //   this.$emit('select',dataURL);
      //   //reset input value after submit
      //   this.$refs.fileInput.value=null;
      // };
      this.getBase64Image(Blob);
    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.image-search{
  color: #999;
  display: inline-block;
  width: 100%;
  min-height: 32px;
  //height: 32px;
  position: relative;
  .el-input__suffix{
    position: relative;
    z-index: 1;
    .icon-camera{
      cursor: pointer;
    }
    .file-input{
      position: absolute;
      width: 18px;
      height: 18px;
      left: 0;
      opacity: 0;
      // top: 0.45em;
      top: 0;
      cursor: pointer;
    }
    input[type="file"] {
      cursor: pointer;
    }
    .icon-search{
      cursor: pointer;
    }
  }
  .drag-area{
    //position: absolute;
    width: 100%;
    height: 70px;
    // top: -25%;
    left: 0;
    z-index: 99;
    display: flex;
    justify-content: center;
    align-items: center;
    border: 1px solid #011C50;
    border-radius: 4px;
    overflow: hidden;
    box-shadow: 0 0 10px rgba(0,0,0,.1);

    textarea{
      position: absolute;
      width: 100%;
      height: 60px;
      border: none;
      opacity: 0;
      cursor:default;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      &:focus{
        outline: none;
      }

    }
    .drag-tips{
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      background: #fff;
      text-align: center;
      line-height: 100%;
      i{margin-right: 4px;}
    }
  }
  .border-run{
    border: 1px dashed transparent;
    background: repeating-linear-gradient(135deg, transparent, transparent 3px, rgb(1, 28, 80,.5) 3px, rgb(1, 28, 80,.5) 8px);
    animation: shine 1s infinite linear;
  }
}
::v-deep .el-input--suffix .el-input__inner{padding-right: 65px;}
@keyframes shine {
  0% { background-position: -12px -12px;}
  100% { background-position: -1px -1px;}
}
::v-deep .el-input__prefix{
  max-width: 40px;
  background: #c2cad8;
  left: 0;
  padding: 0 5px;
  border-radius: 4px 0 0 4px;
  img{
    height: 30px;
    margin: 1px;
  }
  .el-icon-error{
    position: absolute;
    right: -1em;
    top: 9px;
    cursor: pointer;
    color: #999;
    border-radius: 1em;
    word-spacing: 0;
    &::before{
      position: relative;
      z-index: 1;
    }
    &::after{
      content: '';
      background: #fff;
      width: .6em;
      height: .6em;
      position: absolute;
      z-index: 0;
      left: .2em;
      top: .2em;
      display: block;
    }
    &:hover{
      color: #011C50;
    }
  }
}
</style>
