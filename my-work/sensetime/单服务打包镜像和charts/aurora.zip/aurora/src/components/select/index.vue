<template>
    <div class="selsect-container">
        <div :class="['selsect-box']"  v-clickoutside="clickoutside">
            <el-input :value ="selectedKeys.length>0?$t('rule.textboxNumberSelected',{number:selectedKeys.length}):''" class="selsect-input" :size="size1" ref="input" :placeholder="placeholder?placeholder:$t('rule.textboxNumberSelected',{number:0})" @focus="focus" readonly>
                <span slot="suffix">
                    <i style="margin-right:8px;" class="el-icon-circle-close" @click="clear" v-if="selectedKeys.length>0" ></i>
                    <i  :class="['el-icon-arrow-down',showDropdown?'selsect-icon-rotate':'']"></i>
                </span>
            </el-input>
            <transition name="fade">
                <div class="selsect-dropdown__wrap" v-show="showDropdown" ref="dropdownbox" :style="{top:topToInput+'px'}">
                    <!-- <el-input :placeholder="$t('form.texterrSelectKey')" v-model="filterText"  :clearable="true" @clear="clearFilterText"/> -->
                    <el-input v-model="filterText"  :clearable="true" @clear="clearFilterText"/>
                    <div class="selsect-dropdown">
                        <el-tree
                        ref="tree"
                        :data="data"
                        node-key="id"
                        :filter-node-method="filterNode"
                        :default-checked-keys="checkedKeys||[]"
                        :render-content="renderContent"
                        show-checkbox>
                        </el-tree>
                    </div>
                    <div class="selsect-dropdown-footer">
                        <el-button type="text" @click="cancle">{{$t('rule.buttonCancel')}}</el-button>
                        <el-button type="primary" @click="sure">{{$t('rule.buttonOK')}}</el-button>
                    </div>
                </div>
            </transition>
        </div>
    </div>
</template>

<script lang="tsx">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import { setTimeout } from 'timers';
import Clickoutside from 'element-ui/src/utils/clickoutside';

@Component({
    components: {

    },
    directives:{
        Clickoutside
    }
})
export default class Select extends Vue {

    /* props */
    @Prop(Array) data!: any[];
    @Prop({type:Array,required:false,default:[]}) checkedKeys!: any[];
    @Prop({default:'mini'}) size1!: string;
    @Prop({default:'',required:false}) listType!: string;//list  -> leafOnly
    @Prop({default:'',required:false}) placeholder!: string;//list  -> leafOnly

    /* watch */
    @Watch('checkedKeys', { immediate: true, deep: false })
    onCheckedKeysChanged(val, oldVal) {
        val && (this.selectedKeys = val);
        val && this.$refs.tree && this.$refs.tree.setCheckedKeys(val);
        if(val && val.length == 0 && this.$refs.tree){
            this.$refs.tree.setCheckedKeys([]);
        }
        if(val && val.length > 0 && this.$refs.tree){
            this.$refs.tree.setCheckedKeys(val);
        }
    }
    @Watch('filterText', { immediate: false, deep: false })
    onFilterTextChanged(val, oldVal) {
        this.$refs.tree && this.$refs.tree.filter(val);
    }

    /* data */
    $refs!: {
        input: HTMLFormElement,
        tree: HTMLFormElement,
        dropdownbox:HTMLFormElement
    };
    showDropdown:boolean=false;
    selectedKeys:any[]=[];
    filterText:string='';
    topToInput:number=40;
    /* methods */
    renderContent(h,{node,data,store}){
        node.isLeaf = this.listType === 'list'?true:data.id>0;
        return <div class="select-component-leafcontent"  title={data.name}  >{data.name}</div>;
    }
    clear(){
        this.$refs.tree.setCheckedKeys([]);
        this.selectedKeys = [];
        this.$emit('ensure',[])
        this.showDropdown = false;
    }
    focus(){
        this.showDropdown = true;
    }
    sure(){
        let keys = this.$refs.tree.getCheckedKeys(true)||[];//leafOnly
        this.selectedKeys = keys;
        this.$emit('ensure',keys)
        this.showDropdown = false;
    }
    cancle(){
        this.showDropdown = false;
    }
    clickoutside(){
        this.showDropdown = false;
    }
    filterNode(value, data){
        if(data.name.indexOf(value) < 0 && data.id > 0){
            data.disabled = true;
        }else{
            data.disabled = false;
        }
        return data.name.indexOf(value) !== -1;
    }
    clearFilterText(){
        this.$refs.tree.filter('')
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
    .selsect-box{
        position: relative;
        .selsect-dropdown__wrap{
            padding:8px;
            position: absolute;
            // top:50px;style
            z-index: 9999999;
            min-width: 150px;
            min-height: 150px;
            border: solid 1px #cfd6e0;
            border-radius: 2px;
            background-color: #fff;
            width: 100%;
            .selsect-dropdown{
                max-height: 200px;
                overflow: auto;
            }
            .selsect-dropdown-footer{
                padding-top: 8px;
                display: flex;
                justify-content: flex-end;
                width: 100%;
            }
        }
        .el-icon-circle-close{
            cursor: pointer;
            &:hover{
                color: #28354d;
            }
        }
        .el-icon-arrow-down{
            transition: transform .5s;
        }
        .selsect-icon-rotate{
            transform:rotate(180deg);
        }
    }
    .fade-enter-active, .fade-leave-active {
        transition: opacity .5s;
    }
    .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
        opacity: 0;
    }
    ::v-deep .selsect-input.el-input .el-input__inner{ 
            height: 32px;
        }
    ::v-deep .el-tree .el-tree-node__content .select-component-leafcontent{
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }
</style>
