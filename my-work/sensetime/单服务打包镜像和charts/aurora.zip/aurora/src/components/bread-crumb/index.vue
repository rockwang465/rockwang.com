<template>
  <el-breadcrumb class="app-breadcrumb hide" separator-class="el-icon-arrow-right">
    <transition-group name="breadcrumb">
      <el-breadcrumb-item v-for="(item,index) in levelList" :key="item.path" v-if="item.meta.title && item.meta.breadcrumb!==false">
        <span v-if="item.redirect==='noredirect'||index==levelList.length-1" class="no-redirect"><i class="iconfont color-gray" v-bind:class=generateTitle(item.meta.icon)></i>{{ generateTitle(item.meta.title) }}</span>
        <a v-else @click.prevent="handleLink(item)"><i class="iconfont" v-bind:class=generateTitle(item.meta.icon)></i>{{ generateTitle(item.meta.title) }}</a>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import { RouteRecord } from 'vue-router';
import pathToRegexp from 'path-to-regexp';

@Component
export default class Breadcrumb extends Vue {
  levelList: RouteRecord[] = [];

  created() {
    this.getBreadcrumb();
  }

  @Watch('$route')
  onRouteChange() {
    this.getBreadcrumb();
  }

  getBreadcrumb() {
    let matched = this.$route.matched.filter((item) => {
      if (item.name) {
        return true;
      }
    });
    const first = matched[0];
    if (first && first.name !== 'dashboard') {
      matched = [{ path: '/dashboard', meta: { title: 'home',icon: 'icon-home' }} as RouteRecord].concat(matched);
    }
    this.levelList = matched;
  }

  pathCompile(path: string) {
    // To solve this problem https://github.com/PanJiaChen/vue-element-admin/issues/561
    const { params } = this.$route;
    const toPath = pathToRegexp.compile(path);
    console.log(toPath)
    console.log(toPath(params))
    return toPath(params);
  }

  handleLink(item: any) {
    const { redirect, path } = item;
    if (redirect) {
      this.$router.push(redirect);
      return;
    }
    this.$router.push(this.pathCompile(path));
  }

  generateTitle(title:string) {
    const hasKey = this.$te('navbar.' + title);
    if (hasKey) {
      // $t :this method from vue-i18n, inject in @/lang/index.js
      const translatedTitle = this.$t('navbar.' + title)
      return translatedTitle
    }
    return title
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .app-breadcrumb.el-breadcrumb {
    font-size: 14px;
    line-height: 24px;
    padding: 8px 16px;
    background: rgba(229,232,239,0.5);
    .el-breadcrumb__inner{
      a{
        color: rgba(40,53,77,0.4);
      }
      i.iconfont{
        font-size: 14px;
        margin-right: 4px;
      }
    }
    .no-redirect {
      .color-gray{
        color: rgba(40,53,77,0.4);
      }
      color: #28354d;
      cursor: text;
    }
  }
</style>
