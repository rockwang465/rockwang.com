<template>
  <div class="imageselsect-container">
    <input type="file" ref="fileInput" @change="getImge" style="display:none" >
    <div class="imageselsect-radius" >
      <i class="el-icon-plus" ></i>
    </div>
    <div class="imageselsect-imagebox"
      :style="{backgroundColor:showImage?'black':''}"
      ref="imagebox"
      @click="handleClick"
      @dragover="dragover"
      @drop="drop" >
      <img v-show="showImage" draggable="true" :src="base64Data" alt="" srcset="" style="max-width:100%;max-height:100%;">
      <div class="imageselsect-imagebox-change" v-show="showImage" >{{$t('tools.buttonChangeImage')}}</div>
      <div v-if="showClose" class="imageselsect-imagebox-close" v-show="showImage" @click.stop="closeImage" >
        <i class="iconfont icon-close"  ></i>
      </div>
    </div>

  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import { setTimeout } from 'timers';
import {fileValidate} from '@/utils/validate.ts';

@Component({
  components: {

  },
})
export default class ImageSelect extends Vue {

  /* props */
  @Prop({ default: 16 }) sizelimit!: number;
  @Prop({ default: '' }) defaultImgUrl!: string;
  @Prop({ default: true }) showClose!: boolean;

  /* watch */
  @Watch('base64Data', { immediate: false, deep: false })
  onBase64DataChanged(n,o) {
    this.showImage=n?true:false;
  }
  @Watch('defaultImgUrl', { immediate: true, deep: false })
  onDefaultImgUrlChanged(n,o) {
    // n && (this.base64Data = n);
    this.base64Data = n
  }

  /* data */
  $refs!:{
    fileInput:HTMLFormElement,
    imagebox:HTMLFormElement
  };
  showImage:boolean=false;
  base64Data:any='';

  /* methods */
  mounted(){

  }
  initData(){
    this.showImage=false;
    this.base64Data='';
  }
  handleClick(){
    this.$refs.fileInput.click();
  }
  dragover(evt){
    evt.stopPropagation();
    evt.preventDefault();
  }
  drop(evt){
    evt.stopPropagation();
    evt.preventDefault();
    let picLink = evt.dataTransfer.getData("text/plain") || evt.dataTransfer.getData("URL");
    if(picLink){
      this.getSrclinkImage(picLink);
    }else{
      let file = evt.dataTransfer.files[0];
      this.getBase64Image(file);
    }

  }
  getImge(e){
    let file = e.target.files[0];
    file && this.getBase64Image(file);
  }
  beforePicUpload(file){
    let isFile = fileValidate(file,['png','jpg','jpeg','bmp'],this.sizelimit);
    if(!isFile.type){
      this.$refs.fileInput.value=null;
      this.$message.error({showClose: true,message:this.$tc('tools.errmsgImageType')} );
      return false;
    }
    if (!isFile.size) {
      this.$refs.fileInput.value=null;
      this.$message.error({showClose: true,message:this.$tc('tools.errmsgImageSize')});
      return false;
    }
    return true ;
  }
  getBase64Image(file){
    let isValidatePic = this.beforePicUpload(file);
    if(!isValidatePic){
      return false;
    }
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend=()=> {
      let dataURL = reader.result;
      this.base64Data = dataURL;
      this.$emit('select',dataURL);
      //reset input value after submit
      this.$refs.fileInput.value=null;
    };
  }
  getSrclinkImage(url){
    let base64Data:any = '';
    // this.getBase64FromUrlImage(url,'png',(base64)=>{
    //   base64Data = base64;
    //   this.base64Data = base64Data;
    //   this.$emit('select',base64Data);
    // });
    this.getImageBase64FromSrc(url)

  }
  // getBase64FromUrlImage(url, ext, callback) {
  //   let canvas:any = document.createElement("canvas");
  //   let ctx:any = canvas.getContext("2d");
  //   let img = new Image;
  //   img.crossOrigin = 'Anonymous';
  //   img.src = url;
  //   img.onload = ()=> {
  //     canvas.width = img.width;
  //     canvas.height = img.height;
  //     ctx.drawImage(img, 0, 0, img.width, img.height);
  //     let dataURL = canvas.toDataURL("image/" + ext);
  //     callback.call(this, dataURL);
  //     canvas = null;
  //   };
  // }
  closeImage(){
    this.initData();
    this.$emit('select','');
  }
  getImageBlob(url, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open("get", url, true);
    xhr.responseType = "blob";
    xhr.onload = function() {
      if (this.status == 200) {
        if(cb) cb(this.response);
      }
    };
    xhr.send();
  }
  getImageBase64FromSrc(url){
    this.getImageBlob(url,(Blob)=>{
      // let reader = new FileReader();
      // reader.readAsDataURL(Blob);
      // reader.onloadend=()=> {
      //   let dataURL = reader.result;
      //   this.base64Data = dataURL;
      //   this.$emit('select',dataURL);
      //   //reset input value after submit
      //   this.$refs.fileInput.value=null;
      // };
      this.getBase64Image(Blob);
    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.imageselsect-container{
  width: 108px;
  height: 144px;
  border:1px dashed  #ccc;
  display: flex;
  justify-content:center;
  align-items:center;
  position: relative;
  .imageselsect-radius{
    width: 48px;
    height: 48px;
    border-radius: 50%;
    border:1px dashed #ccc;
    margin:0 auto;
    text-align: center;
    line-height: 48px;
    font-size: 20px;
  }
  .imageselsect-imagebox{
    width: 100%;
    height: 100%;
    display:flex;
    justify-content:center;
    align-items:center;
    position: absolute;
    .imageselsect-imagebox-change{
      position: absolute;
      display: none;
      background-color:  rgba($color: #011C50, $alpha: .6);
      color:$--color-white;
      width: 100%;
      text-align: center;
      padding: 4px 0;
      bottom: 0;
      user-select: none;
    }
    .imageselsect-imagebox-close{
      display: none;
      position: absolute;
      top:0px;
      right: 1px;
      color: white;
      background-color: #1989FA;
      border-radius: 50%;
      line-height: 25px;
      text-align: center;
      width: 25px;
      height: 25px;
      font-size: 8px;
      transform: scale(0.7);
      transform-origin:center;
      cursor: pointer;
      &>i.iconfont{
        font-size: 2px;
        &::before{transform: scale(0.5);}
      }
      // &:hover{
      //   color: $--color-primary;
      // }
    }
    &:hover{
      .imageselsect-imagebox-change{
        display: block;
      }
      .imageselsect-imagebox-close{
        display: block;
      }
    }
  }
}
</style>
