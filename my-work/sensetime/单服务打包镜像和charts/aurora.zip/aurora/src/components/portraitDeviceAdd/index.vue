<template>
  <div class="treeselsect-container" style="width:60%">
    <el-popover
      ref="treeselsect-popover"
      placement="bottom"
      width="300"
      trigger="click"
      v-model="visible">
      <div slot="reference" class="treeselsect-selected">
        <!--请选择，已选择N个-->
        <div class="add-user-tree">{{dataObj.userIds.length>0 ?$t('rule.contSelected',{number:dataObj.userIds.length}):$t('records.contPleaseSelect')}}</div>
      </div>
      <div class="treeselsect-content">
        <el-input
          size="small"
          prefix-icon="el-icon-search"
          placeholder=" "
          v-model="filterText">
        </el-input>
        <el-tree v-if="visible"
                 ref="tree"
                 :data="data"
                 :props="defaultProps"
                 :filter-node-method="filterNode"
                 :default-expanded-keys="dataObj.defaultIds"
                 :default-checked-keys="dataObj.defaultIds"
                 node-key="id"
                 @check="checkChange"
                 show-checkbox
        />
        <div class="treeselsect-btns">
          <el-button size="mini" type="text" @click="cancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
          <el-button type="primary" size="mini" @click=" ensureSelect ">{{$t('imagemanagement.buttonOK')}}</el-button>
        </div>
      </div>
    </el-popover>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Prop, Watch} from 'vue-property-decorator';

  @Component({
    components: {},
  })
  export default class TreeSelect extends Vue {

    /* props */
    @Prop(Array) data!: any[];
    @Prop({default: []}) dataObj!: any;//默认选中

    filterList = [] as any;//筛选出来的数组集合;
    nodes = [] as any;//选择后未保存前的被选中节点集合;
    defaultProps = {
      children: 'children',
      label: 'libraryName',
    };
    type = 0 as any;

    created(){
      // this.initNode();
    }
    @Watch('visible')
    onVisibleChange(val: any) {
      this.initNode();
      this.filterText = '';
      this.type = this.dataObj.type  === 1?'w' :this.dataObj.type  === 2?'b': 0;
      if (val == false){
        this.data[0].id = 1
        if (this.data.length==2){
          this.data[1].id = 2
        }
      }
    }

    @Watch('filterText', {immediate: false, deep: false})
    onDataChanged(val: string, oldVal: string) {
      this.filterList = [] as any;
      this.$refs.tree.filter(val);
    }

    filterNode(value, data) {
      console.log(data);
      if (!value) return true;
      if (data.libraryName.indexOf(value) !== -1) {
        this.filterList.push(data)//过滤出来的数组，不包含父级，只适用于两层结构
      }
      return data.libraryName.indexOf(value) !== -1;
    }
    initNode(){
      // if (this.data.length == 2){
      this.data[0].disabled = false
      this.data[0].id = 'w'
      if (this.data[0].children){
        this.data[0].id = 'w'
        this.data[0].children.forEach((item)=>{
          item.disabled = false
          item.id = item.libraryId
        });
      }
      if (this.data.length == 2) {
        this.data[1].disabled = false
        this.data[1].id = 'b'
        if (this.data[1].children){
          this.data[1].id = 'b'
          this.data[1].children.forEach((item)=>{
            item.disabled = false
            item.id = item.libraryId
          });
        }
      }
    }
    checkChange(a,b){
      let name = this.$refs.tree.getCurrentNode()
      let nodes = this.$refs.tree.getCheckedNodes()
      console.log(nodes,name,a,b);
      // debugger
      if (this.nodes.length == this.filterList.length&&this.nodes.length != 0){//如果上次的所选项与过滤结果一致
        let bool = true;
        for (let i = 0;i <this.nodes.length;i++){
          if (this.nodes[i].id != this.filterList[i].id){
            bool = false
          }
        }
        if (bool){//如果一致，表示再次点击已经多选后的父级按钮，则将目前多选的选项清空
          this.$refs.tree.setCheckedNodes([]);
          this.nodes = [];
          return;
        }
      }
      if (this.filterText.length>0&&nodes.length -1>this.filterList.length){//判断筛选后，如果不是单选，则拿过滤出来的数组作为基础来选择
        nodes = this.filterList;
      }
      console.log(nodes);
      // console.log(a,b)
      // console.log('changeCheck')

      // 判断黑白名单
      if (nodes.length == 0){
        this.initNode();
        this.type = 0;
      }else if(this.type == 0){//第一次点击
        if (nodes[0].children) {
            this.type = nodes[0].id
        }
        if (nodes[0].libraryType) {//如果单选
          if (nodes[0].libraryType == 1){
            this.type = 'w'
          }
          if (nodes[0].libraryType == 2){
            this.type = 'b'
          }
        }
      }
      // 判断黑白名单 //

        if (this.type == 'w'){
          let arr = [] as any;
          for(let i = 0;i < nodes.length;i++){
            if (nodes[i].children){
              if (nodes[i].id != 'b') {
                arr.push(nodes[i]);
              }
            }
            if (nodes[i].libraryType){
              if (nodes[i].libraryType != 2){
                arr.push(nodes[i]);
              }
            }
          }
          console.log(arr)
          this.$refs.tree.setCheckedNodes(arr)
        }
        if (this.type == 'b'){
          let arr = [] as any;
          for(let i = 0;i < nodes.length;i++){
            if (nodes[i].children){
              if (nodes[i].id != 'w') {
                arr.push(nodes[i]);
              }
            }
            if (nodes[i].libraryType){
              if (nodes[i].libraryType != 1){
                arr.push(nodes[i]);
              }
            }
          }
          this.$refs.tree.setCheckedNodes(arr)
        }
      this.nodes = this.$refs.tree.getCheckedNodes();

    }


    /* data */
    $refs!: {
      tree: HTMLFormElement
    };

    visible: boolean = false;
    filterText: string = '';


    ensureSelect() {
      let userIds = this.getUserIds(this.$refs.tree.getCheckedNodes());
      this.$emit("selected", {userIds: userIds, defaultIds: this.$refs.tree.getCheckedKeys(),type:this.type == 'w'?1:this.type == 'b'?2:null})
      this.visible = false;
      // this.initNode();
    }
    cancel(){
      this.visible = false;
      // this.initNode();
    }

    getUserIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        let arr = array[i]
        if (arr.id != 'w' && arr.id != 'b'){
          ids.push(array[i].id + '')
        }
        // ids.push(array[i])
      }
      return ids;
    }

  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";

  .el-input {
    width: 224px
  }

  .el-tree{
    max-height: 300px;
    overflow: auto;
  }

  .treeselsect-container {
    display: inline-block;
    position: relative;
    background-color: #fff;
  }

  .treeselsect-selected {
    position: relative;

    .treeselsect-selected-contents {

      padding: 0px 5px;
      display: inline-block;
    }

    .treeselsect-selected-icon {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 5px 0 6px;
    }

    .treeselsect-selected-contents-border {
      padding: 0px 25px 0px 10px;
      display: inline-block;
      border: 1px solid $--color-text-placeholder;
    }

    .treeselsect-selected-icon-border {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 12px 0 13px;
      position: relative;
      left: -15px;
    }
  }

  .treeselsect-content {
    .treeselsect-btns {
      width: 100%;
      text-align: right;
    }

    .treeselsect-tree {
      min-height: 200px;
      max-height: 300px;
      overflow: auto;
    }
  }

  .add-user-tree {
    height: 32px;
    border: 1px solid #c0c4cc;
    cursor: pointer;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    line-height: 32px;
    letter-spacing: 0px;
    color: #28354d;
    padding-left: 13px;
  }

</style>
