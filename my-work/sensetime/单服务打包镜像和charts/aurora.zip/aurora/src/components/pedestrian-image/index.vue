<template>
  <div class="pedestrianImage" @click="viewDetail" @dragenter="dragenter">
    <!-- <img :src="processImgurl(item.imgUrl)" alt=""> -->
    <div class="pedestrianImage-left">
      <div class="pt-state" :style="[bgcStyle]">{{$t(i18nCompareType(item.alertType))}}</div>
      <el-image
        :src="processImgurl(item.imgUrl)"
         fit="contain" :data-imgcrop="JSON.stringify(item)">
        <div slot="error" class="image-slot">
          <i class="el-icon-picture-outline"
          style="color: aliceblue;
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%,-50%);"
          ></i>
        </div>
        <em></em>
      </el-image>
    </div>
    <div class="pedestrianImage-right" >
      <!-- {{item.attributes}} -->
      <!-- <ul v-if="item.attributes && item.attributes.length!= 0"> -->
        <!-- <li v-for="item in item.attributes.slice(0,4)" :key="item.key">
          <Icon type='icon' cursor="pointer" name='maozi'/>
          <div  :style="{background:dressUpperColor}">{{item}}</div>
        </li> -->
        <!-- <li v-for="item in item.sortAttributeInfoVos.slice(0,4)" :key="item.key">
          <Icon type='icon' cursor="pointer" :name="sortAttributeInfoVos(item)"/>
          <div class="A" :class="dressUpper(item.attributeInfo , 'color')">{{ dressUpper(item.attributeInfo , 'style')}}</div>
        </li> -->

      <!-- </ul> -->
      <!-- <ul v-else class="nullAttributes">
        <li>
          <Icon type='icon' cursor="pointer" name='maozi' />
          <div>{{$t('pedestrian.no')}}</div>
        </li>
        <li>
          <Icon type='icon' cursor="pointer" name='shangyi'/>
          <div>{{$t('pedestrian.no')}}</div>
        </li>
        <li>
          <Icon type='icon' cursor="pointer" name='faxing'/>
          <div>{{$t('pedestrian.no')}}</div>
        </li>
        <li>
          <Icon type='icon' cursor="pointer" name='kuzi'/>
          <div>{{$t('pedestrian.no')}}</div>
        </li>
      </ul> -->
      <div class="pedestrianImage-bt">
        <div>{{$t('pedestrian.title')}}:<span>{{item.deviceName}}</span></div>
        <div>{{$t('pedestrian.site')}}:<span>{{item.placeName}}</span></div>
        <div>{{$t('pedestrian.time')}}:<span>{{item.captureTime}}</span></div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch ,Emit , Prop} from "vue-property-decorator";
  import { processImgurl } from "@/utils/image";
  import Icon from '@/components/icon-wrap/index.vue';

  @Component({
    // props: {
    //   items: {
    //     type: Object,
    //     default() {
    //       return [];
    //     }
    //   },
    //   item: {
    //     type: Object,
    //     default() {
    //       return [];
    //     }
    //   }
    // },
    components:{
      Icon
    }
  })
  export default class pedestrianImage extends Vue {
    @Prop({default:()=>{return []}}) item!:object
    @Prop({default:()=>{return []}}) items!:object
    // item: any;
    // items: any;
    IconName='maozi';
    // item2=[{0:1},{0:2},{0:3},{0:4},{0:5}];
    processImgurl = processImgurl;
    dressUpperColor ='transparent' ;
    bgcStyle= {
      background :''
    }
    mounted() {
      // console.log(this.$props.items);
      // console.log("行人记录单个", this.$props.item);
      // console.log(this.$props.item.dressUpperColor);

      this.dressUpperColor = this.$props.item.dressUpperColor
    }

    @Emit() //点击图片查看详情
    viewDetail(){
      console.log('-------------点击图片查看详情--------');

      return { items:this.items,item:this.item }
    }

    @Emit('dragenter')
    dragenter(event){
      event.preventDefault();
      return {event ,item: this.item}
    }


    i18nCompareType(val) {
      let compareType = ""
     switch(val){
       case "0":
       compareType = 'pedestrian.unknown';
       this.bgcStyle.background = '#FF9800'
       break;
       case "1":
       compareType="pedestrian.pedestrianRecord"; //$t('pedestrian.search')
       this.bgcStyle.background = '#1989fa'
       break;
       case "2":
       compareType="pedestrian.vehicleRecord";
       this.bgcStyle.background = '#1989fa'
       break;
       case "3":
      //  compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
      //  compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
      //  compareType="records.listNotifyTypeBlacklist";
       break;
       case "10":
       compareType="pedestrian.pedestrianCrossingWarning";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "11":
       compareType="pedestrian.pedestriansInvasion";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "20":
       compareType="pedestrian.parkedVehicles";
       this.bgcStyle.background = '#ED3A33'
       break;
     }
     return compareType

    }

    sortAttributeInfoVos(val) {
      // console.log(val);
      let name = val.attrType
      let IconName = ''

        switch (name) {
        case "coat_style-coat_color":
          IconName = 'shangyi'
            // return '上衣'
          break;
        case "trousers_color-trousers_len":
          IconName = 'kuzi'
            // return '裤子'
          break;
        case "hair_style-hair_color":
          IconName = 'faxing'
            // return '发型'
          break;
        case "shoes_style-shoes_color":
          IconName = 'xie'
            // return '鞋子'
          break;
        case "gender_code":
          IconName = 'xingbie'
            // return '性别'
          break;
        case "st_pedestrian_angle":
          IconName = 'jiaodu'
            // return '角度'
          break;
        case "coat_length-st_coat_pattern":
          IconName = 'shangyi'
          //上衣
          break;
        case "trousers_len-st_trousers_pattern":
          IconName = 'kuzi'
          //裤子
          break;
        case "st_hold_object_in_front":
          IconName = 'baowu'
          //胸前抱东西
          break;
        case "respirator_color":
          IconName = 'kouzhao'
            //口罩
          break;
        case "bag_style-bag_color":
          IconName = 'xiangbao'
            //包
          break;
        case "st_age":
          IconName = 'nianling1'
            //年龄
          break;
        case "umbrella_color":
          IconName = 'yusan'
            // 雨伞
          break;
        case "cap_style-cap_color":
          IconName = 'maozi'
            // 帽子
          break;
        default :
            return '假数据'
          break;
      }
      return IconName
    }

    dressUpper(item , val) {
      let color = ''
      // console.log(val);
      let style = ''

      let IconName = ''
      item.forEach(ele => {
        // console.log(ele);
        if(ele.coat_color || ele.coat_style){
          IconName = 'shangyi'
          if(ele.coat_color) {
            color = ele.coat_color

          }
          if(ele.coat_style) {
            style = ele.coat_style

          }
        }
        if(ele.trousers_color || ele.trousers_len){
          IconName = 'kuzi'
          if(ele.trousers_color) {
            color = ele.trousers_color
          }
          if(ele.trousers_len) {
            style = ele.trousers_len
          }
          // console.log('----------------------------',color);

        }
        if(ele.cap_color || ele.cap_style){
          if (ele.cap_color ) {

            color = ele.cap_color
          }
          if (ele.cap_style) {

            style = ele.cap_style
          }
        }
        if(ele.hair_color || ele.hair_style){
          if (ele.hair_color) {
            color = ele.hair_color

          }
          if(ele.hair_style) {

            style = ele.hair_style
          }
        }
        if(ele.bag_color || ele.bag_style){
          if (ele.bag_color) {

            color = ele.bag_color
          }else{
            style = ele.bag_style

          }

        }
        if(ele.shoes_color || ele.shoes_style){
          if (ele.shoes_color) {

            color = ele.shoes_color
          }else{
            style = ele.shoes_style

          }
        }

        if(ele.gender_code){
          style = ele.gender_code
        }

        if(ele.st_age){
          style = ele.st_age
        }

        if(ele.gender_code){
          style = ele.gender_code
        }

        if(ele.umbrella_color){
          color = ele.umbrella_color
        }

        if(ele.st_pedestrian_angle){
          style = ele.st_pedestrian_angle
        }

        if(ele.st_coat_pattern){
          style = ele.st_coat_pattern
        }

        if(ele.st_trousers_pattern){
          style = ele.st_trousers_pattern
        }

        if(ele.st_hold_object_in_front){
          style = ele.st_hold_object_in_front
        }

        if(ele.respirator_color){
          color = ele.respirator_color
        }

      })

      if(val == 'color') {
        return color.toLowerCase()
      }
      if(val == 'style'){
        // console.log(style);
        return style ? this.$t('pedestrian.'+style.toLowerCase()) : ''
      }
      if(val == 'IconName'){
        // console.log(style);
        return IconName
      }
    }

  }
</script>

<style lang="scss" scoped>
@media screen and (max-width: 1600px){
  .pedestrianImage-right {
    padding: 32px 4px 10px 4px !important;
    ul {
      li {
        // padding: 0 2px 0 2px;
        div {
          margin-left: 0px !important;
        }
        &:nth-child(2n) {
        // padding: 0 2px 0 2px;
        i {
          margin-left: 2px !important;
        }
        }
      }
    }
    .pedestrianImage-bt {
      span {
            max-width: 70% !important;
      }
    }

  }
}

.pedestrianImage {
  width: 100%;
  height: 100%;
  // background-color: pink;
  // position: relative;
  display: flex;
  cursor:pointer;
  margin: 0.5%;
  display: flex;
  background:rgba(255,255,255,1);
  border:1px solid rgba(223,223,224,1);
  box-shadow:0px 3px 6px rgba(0,0,0,0.16);
  opacity:1;
  border-radius:4px;
  overflow: hidden;

  .pedestrianImage-left {
    height: 100%;
    width: 38%;
    background:rgba(242,246,253,1);
    padding: 10px;
    position: relative;
    padding-top: 30px;
    .pt-state {
      position: absolute;
      width: 100%;
      height: 20px;
      text-align: center;
      line-height: 20px;
      // background-color: pink;
      color: #fff;
      border-radius: 4px 0 0 0 ;
      top: 0px;
      left: 0px;
    }
    .el-image {
      width:113.95px;
      height:160px;
      background-color: #DFEAFC;
      border: 1px dashed #CDE1FD;
    }

  }

  .pedestrianImage-right {
    height: 100%;
    width: 62%;
    // background-color:skyblue;
    // padding: 32px 10px 10px 10px;
    ul {
      display: flex;
      flex-wrap: wrap;
      height: 50%;
      overflow: hidden;
      li {
        display: flex;
        width: 50%;
        height: 50%;
        overflow: hidden;
        text-align: center;
        line-height: 24px;

        div {
          width: 64px;
          height: 24px;
          // background-color: pink;
          margin-left: 5px;
          // border: 1px solid #DFDFE0;
          border-radius: 4px;
          font-size: 12px;
        }


      }
    }
    .nullAttributes {
      div {
        border: 1px solid #DFDFE0;
      }
    }

    .pedestrianImage-bt {
      position: relative;
      // height: 100%;
      top: 50%;
      transform: translateY(-50%);
      margin-left: 15px;
      div {
        // margin-top: 10px;
        display: flex;
        line-height: 24px;
        span {
          margin-left: 3px;
          max-width: 75%;
          display: block;
          overflow: hidden;
          text-overflow: ellipsis;
          -ms-text-overflow: ellipsis;
          white-space: nowrap;

        }
      }
    }
  }


  .purple {
    background-color: #673AB7;
    color: #fff;
  }
  .red {
    background-color: #ED3A33;
    color: #fff;
  }
  .brown {
    background-color: #795548;
    color: #fff;
  }
  .yellow {
    background-color: #FF9800;
    color: #fff;
  }
  .green {
    background-color: #8BC34A;
    color: #fff;
  }
  .blue {
    background-color: #1989FA;
    color: #fff;
  }
  .pink {
    background-color: #FFCDD2;
    color: #000;
  }
  .white {
    background-color: #FFFFFF;
    color: #000;
    border: 1px solid #DFDFE0;
  }
  .gray {
    background-color: #DFDFE0;
    color: #000;
  }
  .black {
    background-color: #2B2B2B;
    color: #fff;
  }

}
</style>
