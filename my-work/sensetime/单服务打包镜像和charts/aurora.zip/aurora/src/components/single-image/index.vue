<template>
    <div :class="{checked:isChecked}"  class="single-image-container" :id="provisonal">
      <div class="selected">
        <Icon
          type="ele"
          name="success"
        />
      </div>
      <div class="origin-image">
        <img :src="processImgurl(img)" @click="viewDetail" alt="">
      </div>
      <!-- <div class="library-type">{{libraryType}}</div> -->
      <div class="percentage">{{this.toPercent(percentage)}}</div>
    </div>
  </template>

  <script lang="ts">
  import { Component, Vue, Watch, Emit } from 'vue-property-decorator';
  import  Icon from '@/components/icon-wrap/index.vue';
  import {toPercent } from '@/utils/small-tool';
  import { processImgurl } from '@/utils/image';
  @Component({
    props:{
      item:{
        type:Object,
        default(){
          return {};
        },
      },
       percentage:{//比中百分比
        type:String,
        default:"",
      },
      libraryType:{//比中百分比
        type:String,
        default:"",
      },
      img:{//人像库图片
        type:String,
        default:""
      },
      isChecked:{
        type:Boolean,
        default:false
      }
    },
    components: {
      Icon,
    }
  })
  export default class SingleImage  extends Vue{
    item:any;
    items:any;
    percentageSize:any
    viewState:any;
    provisonal="";
    libraryType:any;
    toPercent=toPercent;
    processImgurl=processImgurl;
    @Watch('viewState')
    viewStateChanged(val: string, oldVal?: string) {
      this.provisonal=val //设置样式
    }
    @Emit('viewDetail') //点击图片查看详情
    viewDetail(){
      return { items:this.items,item:this.item }
    }
    mounted(){
      //设置百分比字体大小
      this.viewStateChanged(this.viewState)
    }
  }

  </script>

  <style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
    .single-image-container{
      display: inline-block;
      width: auto;
      margin:10px;
      position: relative;
      .selected{
        position:absolute;
        top: -10px;
        left: 0;
        display: none;
        color: $--color-success;

      };
      .origin-image{
        height: 100%;
        width:100%;
        img{
          height: 100%;
          width:100%;
          object-fit: cover;
        }
      };
      // .library-type{
      //   position:absolute;
      //   right:0;
      //   padding:2px;
      //   bottom: 20px;
      //   height: 20px;
      //   width:60%;
      //   line-height: 20px;
      //   color: $--color-white;
      //   background: $--color-warning;
      //   text-align: center;
      // };
      .percentage{
        position:absolute;
        bottom: 0;
        height: 20px;
        width: 100%;
        line-height: 20px;
        color: $--color-white;
        background: #011C50;
        text-align: center;
      }

    }
    .checked{
      border: 2px solid $--color-success;
      .selected{
        display: inline;
      }
    }

  //  .VueCarousel-slide{
      // .single-image-container{
      //   display: inline-block;
      //   width: auto;
      //   margin:10px;
      //   position: relative;
      //   .selected{
      //     position:absolute;
      //     top: -10px;
      //     left: 0;
      //     display: none;
      //     color: $--color-success;

      //   };
      //   .origin-image{
      //     height: 100%;
      //     width:100%;
      //     img{
      //       height: 100%;
      //       width:100%;
      //       object-fit: cover;
      //     }
      //   };
      //   // .library-type{
      //   //   position:absolute;
      //   //   right:0;
      //   //   padding:2px;
      //   //   bottom: 20px;
      //   //   height: 20px;
      //   //   width:60%;
      //   //   line-height: 20px;
      //   //   color: $--color-white;
      //   //   background: $--color-warning;
      //   //   text-align: center;
      //   // };
      //   .percentage{
      //     position:absolute;
      //     bottom: 0;
      //     height: 20px;
      //     width: 100%;
      //     line-height: 20px;
      //     color: $--color-white;
      //     background: #011C50;
      //     text-align: center;
      //   }

      // }

      // &:nth-child(n) {
      //   .percentage {
      //     background: #BE0000
      //   }
      // }
      // &:nth-child(2n) {
      //   .percentage {
      //     background: #6D7C96
      //   }
      // }
      // &:nth-child(3n) {
      //   .percentage {
      //     background: #23A5F7
      //   }
      // }
  // }

    .checked{
      border: 2px solid $--color-success;
      .selected{
        display: inline;
      }
    }
  </style>

