<template>
  <div class="dashboard-map-layer">
    <l-map ref="elMap" style="height: 100%; width: 100%;"
      :min-zoom="mapSet.minZoom"
      :max-zoom="mapSet.maxZoom"
      :zoom="mapSet.zoom"
      :center="mapSet.center"
      v-loading="loading"
      :key="mapSet.key"
      :options="mapOptions"
      :crs="crs">
      <!-- <l-geo-json
        :geojson="geojson"
        :style="geoJsonStyle"
      >
      </l-geo-json> -->
      <l-image-overlay className="svg-img"
        v-if="hasbg"
        :url="mapSet.bgUrl"
        :bounds="mapSet.bounds"/>
      <!-- <l-image-overlay
        v-if="hasbg"
        :url="mapSet.bgUrl"
        :bounds="mapSet.bounds"/>
      <div v-else class="no-map">
        <div class="no-map-tips">
          <img src="/images/nomap.png" width="260" alt="no map" >
          <div class="nomap-info">
            <div class="no-map-msg">{{$t('liveservice.contBlankPage')}}</div>
            <h4>{{$t('liveservice.contInstruction.Title')}}</h4>
            <ol>
              <li v-html="$t('liveservice.contInstruction.First')"></li>
              <li v-html="$t('liveservice.contInstruction.Second')"></li>
              <li v-html="$t('liveservice.contInstruction.Third')"></li>
            </ol>
          </div>
        </div>
      </div>
      <div v-if="hasbg">
        <l-marker v-for="item in deviceList"
          :lat-lng.sync="item.position"
          :icon="item.icon"
          :key="item.name">
          <l-popup>
            <p>
              <strong>{{$tc('map.deviceType')}}</strong>
              {{item.deviceType == 1 ? "Camera" : item.deviceType == 2 ? "SenseKeeper" : item.deviceType == 4 ? "SenseDLC" : "未知"}}
            </p>
            <p><strong>{{$tc('map.deviceName')}}</strong>{{item.deviceName}}</p>
            <p v-if="item.id"><strong>{{$tc('map.deviceId')}}</strong>{{item.id}}</p>
            <p class="text-right"><el-button type="primary" icon="el-icon-view" @click="viewLiveVideo(item.deviceId)">{{$tc('map.viewLive')}}</el-button></p>
          </l-popup>
          <l-tooltip v-if="item.isShow" :options="showOption" :key="item.key">
            <div class="show-human">
              <span v-if="item.isLoad">loading</span>
              <img v-else :src="item.human.url" alt="">
              <div class="post-deviceName">{{item.deviceName}}</div>
            </div>
          </l-tooltip>
        </l-marker>
      </div> -->
    </l-map>
  </div>
</template>
<script lang="ts">
import { Component, Vue,Watch,Prop } from 'vue-property-decorator';
import L from 'leaflet';
import { LMap, LImageOverlay,LTooltip ,LIcon, LMarker, LPopup,LPolyline,LGeoJson,LControl,LControlScale,LControlZoom } from 'vue2-leaflet';

import SelectTree from './SelectTree.vue';
import DeviceSelect from './DeviceSelect.vue';
import request from '@/utils/request';

//地图基础配置
import {drawSetting, markerIcon, localDeviceList, mapBase, mapBaseOptions} from '@/views/manage/map/mapConfig';

@Component({
  components: {
    LMap, LImageOverlay, LMarker, LPopup,LPolyline,
    LGeoJson,
  }
})
export default class MapDevice extends Vue {
  loading = false;

  //地图基础配置信息
  crs     = L.CRS.Simple;
  hasbg = true;
  mapOptions:any = Object.assign(mapBaseOptions)
  mapSet:any = Object.assign(mapBase,{
    //key     : +new Date(),
    bgUrl   : '/images/map.svg',
    //dataUrl : '/mock/countries.geo.json',
    reset   : true,
    zoom:-1.5,
    center:[600,960]
    //center:[0,0]
  });
  geojson = null;

  //设备相关配置
  deviceList:any=[]

  mounted(){
    //this.getGeojson()
    this.$nextTick(()=>{
      this.resizeWidth()
    })

    window.onresize = ()=>{
      this.resizeWidth()
    }
  }
  resizeWidth(){
    if(document.body.offsetWidth < 1440){
      this.mapSet.zoom = -2;
      this.mapSet.center = [600,930];
    }else{
      this.mapSet.zoom = -1.5;
      this.mapSet.center = [600,960];
    }
  }
  getGeojson(){
    request.get(this.mapSet.dataUrl).then((resp:any)=>{
      this.geojson = resp
    })
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
  @import "src/assets/style/leaflet.scss";
  .dashboard-map-layer{
    width: 100%;
    height: 100%;
    .svg-img{border: none;background: transparent;}
    .leaflet-control-zoomslider{display: none;}
  }
</style>
