<template>
  <div class="text-timepocker-container" >
    <i class="iconfont icon-timezone-times" style="margin-right:2px;font-size:14px"></i>
    <span @click="showTimePicker" >{{formatGetTime(time)}}</span>
    <div class="text-timepocker-picker" >
      <el-time-picker v-bind="$attrs" @change="timechange" v-model="time"  ref="texttimepicker"></el-time-picker>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component({
  components: {
    
  },
})
export default class TextTimepicker extends Vue {

  /* props */
  @Prop({default:'',required:false}) timesValue!: string;
  /* watch */
  // @Watch('timesValue', { immediate: true, deep: true })
  // ontimesValueChange(n,o){
  //   console.log(n)
  // }
  /* data */
  $refs!:{
    texttimepicker:any
  };
  // time:any=this.$attrs['timesValue'] || '';
  time=this.timesValue;
  timePicker = this.timesValue;
  timeType:any = this.$attrs['is-range'];

  /* methods */
  
  showTimePicker(e){
    this.$refs.texttimepicker.focus();
  }
  formatGetTime(time){
    let times:any = '';
    if(this.isArray(time)){
      times = time[0]+'-'+time[1];
    }
    if(this.isString(time)){
      times = time.split(',')[0]+'-'+time.split(',')[1];
    }
    return times;
  }
  formatTimes(times){
    let isrange = this.timeType == '' ||  this.timeType  == true;
    this.timeType === undefined && (isrange = false);
    return isrange?times[0]+'-'+times[1]:times;
  }
  timechange(time){
    // this.time = time;
    this.$emit('changetime',time)
  }
  isArray(obj){ 
    return (typeof obj=='object')&&obj.constructor==Array; 
  } 
  isString(str){ 
    return (typeof str=='string')&&str.constructor==String; 
  } 
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .text-timepocker-container{
    width: 100%;
    position: relative;
    .text-timepocker-picker{
      position: absolute;
      height: 0;
      width: 0;
      overflow: hidden;
    }
  }

</style>
