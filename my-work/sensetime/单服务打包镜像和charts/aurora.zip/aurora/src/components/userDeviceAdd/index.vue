<template>
  <div class="treeselsect-container" style="width:100%">
    <!--background-color: #6d7c96-->
    <el-popover
      :disabled="isAdmin"
      ref="treeselsect-popover"
      placement="bottom"
      width="300"
      trigger="click"
      v-model="visible">
      <div slot="reference" class="treeselsect-selected">
        <!--请选择，已选择N个-->
        <div v-if="isAdmin" :style="{background:'#6d7c96',color:'#6d7c96'}" class="add-user-tree">&nbsp;</div>
        <div v-else :style="{background:isAdmin?'#6d7c96':'#fff',color:isAdmin?'#c0c4cc':'#000'}" class="add-user-tree">{{dataObj.userIds.length>0 ?$t('rule.contSelected',{number:dataObj.userIds.length}):$t('records.contPleaseSelect')}}</div>
      </div>
      <div class="treeselsect-content">
        <el-input
          size="small"
          prefix-icon="el-icon-search"
          placeholder=" "
          v-model="filterText">
        </el-input>
        <el-tree v-if="visible"
          ref="tree"
          :data="data"
          :props="libraryName?libraryProps:defaultProps"
          :filter-node-method="filterNode"
          :default-expanded-keys="dataObj.defaultIds"
          :default-checked-keys="dataObj.defaultIds"
           @check="checkChange"
          node-key="id"
          show-checkbox
        />
        <div class="treeselsect-btns">
          <el-button size="mini" type="text" @click="visible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
          <el-button type="primary" size="mini" @click=" ensureSelect ">{{$t('imagemanagement.buttonOK')}}</el-button>
        </div>
      </div>
    </el-popover>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Prop, Watch} from 'vue-property-decorator';
  import {setTimeout} from 'timers';

  @Component({
    components: {},
  })
  export default class TreeSelect extends Vue {

    /* props */
    @Prop(Array) data!: any[];
    @Prop(Boolean) libraryName!: any;
    @Prop({default: false}) isAdmin!: any;
    @Prop({default: []}) dataObj!: any[];//默认选中

    defaultProps = {
      children: 'children',
      label: 'name',
    };
    libraryProps = {
      children: 'children',
      label: 'libraryName',
    };
    filterList = [] as any;
    nodes = [] as any;


    mounted(){
    }

    // @Watch('isAdmin')
    // onAdminChange(val:any){
    //   if (val){
    //     this.$emit("selected", {userIds: [], defaultIds: []})
    //   }
    // }

    @Watch('visible')
    onVisibleChange(val: any) {
      this.filterText = '';
    }

    @Watch('filterText', {immediate: false, deep: false})
    onDataChanged(val: string, oldVal: string) {
      this.filterList = [] as any;
      this.$refs.tree.filter(val);
    }

    filterNode(value, data) {
      // console.log(data.name);
      if (!value) return true;
      if (data.name.indexOf(value) !== -1) {
        this.filterList.push(data)//过滤出来的数组，不包含父级，只适用于两层结构
      }
      return data.name.indexOf(value) !== -1;
    }

    checkChange(){
      let nodes = this.$refs.tree.getCheckedNodes();
      console.log(nodes);
      console.log(this.filterList);
      if (this.nodes.length == this.filterList.length&&this.nodes.length != 0){//如果上次的所选项与过滤结果一致
        let bool = true;
        for (let i = 0;i <this.nodes.length;i++){
          if (this.nodes[i].id != this.filterList[i].id){
            bool = false
          }
        }
        if (bool){//如果一致，表示再次点击已经多选后的父级按钮，则将目前多选的选项清空
          this.$refs.tree.setCheckedNodes([]);
          this.nodes = [];
          return;
        }
      }
      if (this.filterText.length>0&&nodes.length -1>this.filterList.length){//判断筛选后，如果不是单选，则拿过滤出来的数组作为基础来选择
        let list = this.filterList;
        console.log(nodes,list)
        if (nodes[0].children.length>0) {
          let arr = [] as any;
          for(let i = 0;i < list.length;i++){
            for(let j = 0;j < nodes.length;j++){
              if (list[i].id == nodes[j].id){
                arr.push(list[i]);
              }
            }
          }
          console.log(arr);
          this.$refs.tree.setCheckedNodes(arr)
        }
      }
      this.nodes = this.$refs.tree.getCheckedNodes();
    }


    /* data */
    $refs!: {
      tree: HTMLFormElement
    };

    visible: boolean = false;
    filterText: string = '';


    ensureSelect() {
      let userIds = this.getUserIds(this.$refs.tree.getCheckedKeys());
      this.$emit("selected", {userIds: userIds, defaultIds: this.$refs.tree.getCheckedKeys()})
      this.visible = false;
    }

    getUserIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        let arr = (array[i] + '').split('_');
        arr.length == 1 ? ids.push(arr[0]) : ''
      }
      return ids;
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";

  .el-input {
    width: 224px
  }

  .el-tree{
    max-height: 300px;
    overflow: auto;
  }

  .treeselsect-container {
    display: inline-block;
    position: relative;
    background-color: #fff;
  }

  .treeselsect-selected {
    position: relative;

    .treeselsect-selected-contents {

      padding: 0px 5px;
      display: inline-block;
    }

    .treeselsect-selected-icon {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 5px 0 6px;
    }

    .treeselsect-selected-contents-border {
      padding: 0px 25px 0px 10px;
      display: inline-block;
      border: 1px solid $--color-text-placeholder;
    }

    .treeselsect-selected-icon-border {
      background-color: rgba(162, 176, 199, 0.48);
      cursor: pointer;
      color: #28354d;
      padding: 12px 0 13px;
      position: relative;
      left: -15px;
    }
  }

  .treeselsect-content {
    .treeselsect-btns {
      width: 100%;
      text-align: right;
    }

    .treeselsect-tree {
      min-height: 200px;
      max-height: 300px;
      overflow: auto;
    }
  }

  .add-user-tree {
    height: 32px;
    width: 100%;
    border: 1px solid #c0c4cc;
    cursor: pointer;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    line-height: 32px;
    letter-spacing: 0px;
    color: #28354d;
    padding-left: 13px;
    border-radius: 4px;
  }

</style>
