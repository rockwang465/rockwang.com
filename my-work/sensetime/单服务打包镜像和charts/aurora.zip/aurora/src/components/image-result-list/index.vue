<template>
  <div class="result-paper">
    <div class="image-result-list" v-for="(items, key) in lists" :key="key">
      <div class="image-item" v-for="(item, subkey) in items.data" :key="subkey">
        <slot name="listCollapse" :items="items"  :item="item"></slot>
        <i v-if="item.isFocus" ref="arrow" class="arrow"></i>
      </div>
      <slot name="detail" :items="items"></slot>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
@Component({
  components: {

  },
})
export default class ImageResultList extends Vue {
  @Prop({default(){return []}}) lists!:any[]
  @Prop({default:false}) collapse!:false

  mounted(){

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.result-paper{
  height: calc(100% - 43px);
  overflow-y: auto;
  padding-bottom: 4px;
  margin-right: -10px;
  padding-left: 4px;

}
  .image-result-list{
    display: flex;
    flex-wrap:wrap;
    margin-bottom: 8px;

    .image-item{
      position: relative;
      min-width: 60px;
      width: 8%;
      box-sizing: border-box;
      height:156px;
      box-shadow: 0 5px 9px rgba(109, 124, 150, .5);
      margin:8px 0.5% 0;
      .arrow{
        position: absolute;
        border: 12px solid transparent;
        display: inline-block;
        bottom: -13px;
        left: 45%;
        z-index: 1;
        border-bottom-color:rgba(223,223,224,1);
        &::before {
          content:'';
          position: absolute;
          border: 10px solid transparent;
          display: inline-block;
          bottom: -12px;
          left: -10px;
          z-index: 1;
          border-bottom-color: rgba(242,246,253,1);
        }
      }
    }
    .record-detail{
      margin-left: 8px;
    }
  }
</style>
