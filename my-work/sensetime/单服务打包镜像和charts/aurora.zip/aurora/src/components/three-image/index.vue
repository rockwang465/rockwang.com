<template>
  <div class="current-compare">
    <!-- <div class="current-title">抓拍记录</div> -->
    <div id="compareTypeCard" :class="compareTypeCard">
            {{$t(CompareTypeconvert(capture.compareType))}}
    </div>
    <div class="three-Image">
      <img :src="processImgurl(capture.url)" alt />
    </div>
    <div class="current-compare-detail">
      <div class="detail-item">
        <p>
          <b>{{$t("records.contDevice")}}:</b>
          <el-popover
            placement="right-start"
            trigger="hover"
            width="200"
          >
          <span slot="reference" class="line-clamp" style="cursor: pointer;">
            <!-- {{capture.devicePlaceInfo.name}} -->
            {{ capture.deviceInfo && capture.deviceInfo.device && capture.deviceInfo.device.subDevice && capture.deviceInfo.device.subDevice.deviceName  ? capture.deviceInfo.device.subDevice.deviceName : capture.devicePlaceInfo.name}}
            </span>
            <div style="word-break: break-all">
              <!-- <p>{{ capture.devicePlaceInfo.name}}</p> -->
              <p>
                {{ capture.deviceInfo &&  capture.deviceInfo.device && capture.deviceInfo.device.subDevice && capture.deviceInfo.device.subDevice.deviceName  ? capture.deviceInfo.device.subDevice.deviceName : capture.devicePlaceInfo.name}}
              </p>
            </div>
          </el-popover>
        </p>

      </div>
      <div class="detail-item">
        <p>
          <b>{{$t("records.contLocation")}}:</b>
          <el-popover
            placement="right-start"
            trigger="hover"
            width="200"
          >
          <span slot="reference" style="cursor: pointer;">{{capture.place}}</span>
            <div style="word-break: break-all">
              <p>{{capture.place}}</p>
            </div>
          </el-popover>
        </p>
      </div>
      <div class="detail-item">
        <p>
          <b>{{$t("records.contTime")}}:</b>
          <span class="line-clamp">
            <i v-if="capture.preCaptureDate">
                  {{capture.preCaptureDate}} <br/>
            </i>
            {{capture.captureDate}}
          </span>
        </p>
        <p>
          <b>{{$t("pedestrian.mission")}}:</b>
          <el-popover
            placement="right-start"
            trigger="hover"
            width="200"
          >
          <span slot="reference" style="cursor: pointer;">{{capture.taskName}}</span>
            <div style="word-break: break-all">
              <p>{{capture.taskName}}</p>
            </div>
          </el-popover>
        </p>
      </div>

      <div class="detail-item">
        <p>
          <b>{{$t("records.contName")}}:</b>
          <el-popover
            placement="right-start"
            trigger="hover"
            width="200"
          >
          <span slot="reference" style="cursor: pointer;">{{capture.userName}}</span>
            <div style="word-break: break-all">
              <p>{{capture.userName}}</p>
            </div>
          </el-popover>
        </p>
        <p>

          <b>{{$t("records.contID")}}:</b>
          <el-popover
            placement="right-start"
            trigger="hover"
            width="200"
          >
          <span slot="reference" style="cursor: pointer;">{{capture.id}}</span>
            <div style="word-break: break-all">
              <p>{{capture.id}}</p>
            </div>
          </el-popover>
        </p>
      </div>
      <div class="detail-item">
        <p>
          <b :style="language ?'display: contents;':''">{{$t("records.contImageLibrary")}}:</b>
          <el-popover
            placement="right-start"
            trigger="hover"
            width="200"
          >
          <span slot="reference" style="cursor: pointer;">{{capture.targetLibraryName}}</span>
            <div style="word-break: break-all">
              <p>{{capture.targetLibraryName}}</p>
            </div>
          </el-popover>
        </p>

      </div>

      <div  class="detail-item" >
        <p style="font-size:12px;color:#2A5AF5" v-if="capture.faceAttributeInfo && capture.faceAttributeInfo.age">
          <el-popover
            placement="right-start"
            trigger="hover"
          >
            <!-- <b slot="reference">{{$t("records.moreAttr")}}</b> -->
              <div>
                <p>{{$t("records.age")}}：{{$t("records."+capture.faceAttributeInfo.age)}}</p>
                <p>{{$t("records.gender")}}：{{$t("records."+capture.faceAttributeInfo.gender)}}</p>
              </div>
            <b slot="reference" style="cursor: pointer;">{{$t("records.moreAttr")}}</b>
          </el-popover>
          <!-- <div :class="['maskType',capture.faceAttributeInfo.respiratorColor  = 'color_type_none'?'isMask':'']">
            <i class="iconfont icon-mask"></i>
            <i class="iconfont icon-separator"></i>
            <span>{{capture.faceAttributeInfo.respiratorColor  = 'color_type_none'?'未戴口罩':'佩戴口罩'}}</span>
          </div> -->
           <i style="margin-left: 3px;font-size: 14px;line-height: 14px;" class="iconfont icon-gengduo"> </i>
        </p>

        <!-- 口罩与安全帽 -->
        <div v-if="respiratorSwitch && capture.faceAttributeInfo.respiratorColor" :class="['AllSwitch',capture.faceAttributeInfo.respiratorColor  == 'color_type_none'?'isMask':'']">
          <strong>
          <i class="iconfont icon-mask"></i>
          <span>{{capture.faceAttributeInfo.respiratorColor  == 'color_type_none'?$t("records.noMask"):$t("records.ownMask")}}</span>
          </strong>
        </div>
        <!-- <div v-if="helmetSwitch && capture.faceAttributeInfo.helmetStyle" :class="['AllSwitch',capture.faceAttributeInfo.helmetStyle  == 'none'?'isOwn':'']">
          <strong>
          <i class="iconfont icon-anquanmao"></i>
          <span>{{capture.faceAttributeInfo.helmetStyle  == 'none'?$t("records.noHelmet"):$t("records.ownHelmet")}}</span>
          </strong>
        </div> -->
        <div v-if="helmetSwitch && capture.faceAttributeInfo.helmetStyle" :class="['AllSwitch',capture.faceAttributeInfo.helmetStyle  == 'st_helmet_style_type_none'?'isOwn':'']">
          <strong>
          <i class="iconfont icon-anquanmao"></i>
          <span>{{capture.faceAttributeInfo.helmetStyle  == 'st_helmet_style_type_none'?$t("records.noHelmet"):$t("records.ownHelmet")}}</span>
          </strong>
        </div>

        <!-- 温度 -->
        <div v-if="capture.tempInfo&&capture.tempInfo.temp" :class="['AllSwitch',capture.tempInfo.tempStatus  !== 0 && capture.tempInfo.tempStatus  !== 3 ? 'isFever':'']">
          <strong>
          {{capture.tempInfo.temp}}{{$t('records.tempUnitSymbol')[capture.tempInfo.tempUnit]}} {{$t('records.tempStatus')[capture.tempInfo.tempStatus]}}
          </strong>
        </div>

      </div>

    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop } from "vue-property-decorator";
import { processImgurl } from "@/utils/image";
import { CompareTypeconvert } from "@/utils/CompareTypeconvert";
import {Cache} from '@/utils/cache';
import { AppModule } from '@/store/modules/app';

@Component({
  // props: {
  //   capture: {
  //     type: Object
  //   }
  // }
})
export default class currentCompare extends Vue {
  @Prop() capture !:object;
  // capture:any =capture;
  processImgurl = processImgurl;
  compareTypeCard = '';
  compareType:any;
  respiratorSwitch = true
  helmetSwitch = true

  // @Watch("compareType")
  // onCompareTypeChange(val){
  //   console.log(val);
  //    switch(val){
  //      case "0":
  //      this.compareTypeCard="whitelistSucess"
  //      break;
  //      case "1":
  //      this.compareTypeCard="strangeWarn";
  //      break;
  //      case "2":
  //      this.compareTypeCard="unliveAtrack";
  //      break;
  //      case "3":
  //      this.compareTypeCard="passwordAtrack";
  //      break;
  //      case "4":
  //      case "6":
  //      case "7":
  //      case "8":
  //      this.compareTypeCard="whitelistWarn";
  //      break;
  //      case "9":
  //      this.compareTypeCard="blacklistWarn";
  //      break;
  //    }
  // }

    get language() {
      return AppModule.language == 'en';
    }

  // 是否查看
  convertOperateType(val) {
    switch (val) {
      case 0:
        return "";
      case 1:
        return "records.lsitOperationTypeRead";
      case 2:
        return "records.lsitOperationTypeMatched";
      case 3:
        return "records.lsitOperationTypeUnmatched";
    }
  }

  // 比对类型
  CompareTypeconvert(val) {
    // let compareType = "";
    switch (val) {
      case "0":
         this.compareType = "records.listNotifyTypeNormal";
         this.compareTypeCard="whitelistSucess";
        break;
      case "1":
         this.compareType = "records.listNotifyTypeStranger";
         this.compareTypeCard="strangeWarn";
        break;
      case "2":
         this.compareType = "records.listNotifyTypeFaceSpoof";
         this.compareTypeCard="unliveAtrack";
        break;
      case "3":
         this.compareType = "records.listNotifyTypePassAttack";
         this.compareTypeCard="passwordAtrack";
        break;
      case "4":
      case "6":
      case "8":
         this.compareType = "records.listNotifyTypeAbnormal";
         this.compareTypeCard="whitelistWarn";
        break;
      case "9":
         this.compareType = "records.listNotifyTypeBlacklist";
         this.compareTypeCard="blacklistWarn";
        break;
    }
    return  this.compareType;
  }

  created() {
    // console.log(this.$props.capture);
  }

  mounted() {

    //登录调用是否有权限问题: 接口为个人中心，无权限问题
    this.respiratorSwitch = Cache.localGet('respiratorSwitch') == true;
    this.helmetSwitch = Cache.localGet('helmetSwitch') == true;
  }
  getTempData(item:any){
    if(item.tempInfo){
      let key = item.tempInfo.tempStatus;//0-正常 1-疑似发热 2-确认发热 3-复核正常 11-体温异常
      switch (key) {
        case 0:
          return {class:'temp-style-normal',text: item.tempInfo.temp+''+this.$tc('faceStyle.temperatureNormal')};
        case 1:
          return {class:'temp-style-abnormal',text:item.tempInfo.temp+''+this.$tc('faceStyle.temperatureSuspectedFever')};
        case 2:
          return {class:'temp-style-abnormal',text:item.tempInfo.temp+''+ this.$tc('faceStyle.temperatureConfirmFever')};
        case 3:
          return {class:'temp-style-normal',text:item.tempInfo.temp+''+ this.$tc('faceStyle.temperatureNormalRecheck')};
        case 11:
          return {class:'temp-style-abnormal',text:item.tempInfo.temp+''+ this.$tc('faceStyle.temperatureAbnormal')};
        default:
          return {class:'',text:''};
      }
    }else{
      return {class:'',text:''}
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/styles/variables.scss";
@media (max-width: 1440px){
  .current-compare {
    padding: 16px 16px 0px !important;

    .three-Image {
      height: 209px !important;
    }


  }
}

.current-compare {
  background: rgba(255, 255, 255, 1);
  // border: 1px solid rgba(223, 223, 224, 1);
  // box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
  margin-left: 9%;
  height: 92% ;
  width: 12.5%;
  padding: 20px 25px 0;
  overflow:inherit !important;
  word-wrap: break-word;
  position: relative;
  margin-top: 25px;

  .current-title {
    width: 53%;
    height: 24px;
    line-height: 24px;
    background-color: $--color-primary;
    text-align: center;
    position: absolute;
    top: 0px;
    left: 50%;
    transform: translateX(-50%);
    font-weight: bold;
    // color: #fff;
  }
  .three-Image {
    width: 100%;
    height: 256px;
    margin: 0 auto;
    text-align: center;
    border: 1px solid rgba(223, 223, 224, 1);
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
  // .current-compare {
    // border-radius: 0px 0px 4px 4px;
    // width: 100%;
    // margin: 0 auto;
    // padding:10px 0;
    // .detail-item {
      // margin: 10px 5px;
      // display: flex;
      // word-wrap:break-word;
      // position: relative;
      /*   p{
              display: flex;
              width:50%;
              word-wrap:break-word;
              b{
                word-wrap:break-word;
                padding: 3px;
                white-space:nowrap;
                font-weight: 600;
              }
              span{
                word-wrap:break-word;
                padding: 3px;
                display: block;
                width:80%;
                i{
                  font-style:normal;
                }

              }

            } */
    // }
    #compareTypeCard {
          width: 100%;
          display: inline-block;
          height: 26px;
          line-height: 26px;
          text-align: center;
          position: absolute;
          top: -22px;
          right: 0px;
          // background-color: #FC561A;
          color: aliceblue;
          font-size: 12px;
          padding:0 10px;
          border-radius: 4px 0px 0px 0px;
          // &::before {
          //   display:block;
          //   content:'';
          //   border-width:11px 11px 11px 11px;
          //   border-style:solid;
          //   // border-color:transparent  #FC561A transparent transparent;

          //   /* 定位 */
          //   position:absolute;
          //   left:-22px;
          //   top:0px;
          // }
    }

    #compareTypeCard.whitelistSucess{
      background: #23a5f7;
      &::before {
        border-color:transparent  #23a5f7 transparent transparent;
      }
    }
    #compareTypeCard.strangeWarn{
      background: #ff851b;
      &::before {
        border-color:transparent  #ff851b transparent transparent;
      }
    }
    #compareTypeCard.unliveAtrack{
      background: #85144b;
      &::before {
        border-color:transparent  #85144b transparent transparent;
      }
    }
    #compareTypeCard.passwordAtrack{
      background: #b10dc9;
      &::before {
        border-color:transparent  #b10dc9 transparent transparent;
      }
    }
    #compareTypeCard.whitelistWarn{
      background: #6d7c96;
      &::before {
        border-color:transparent  #6d7c96 transparent transparent;
      }
    }
    #compareTypeCard.blacklistWarn{
      background: #fc3d1a;
      &::before {
        border-color:transparent  #fc3d1a transparent transparent;
      }
    }
  // }
  .current-compare-detail-other {
    // width: 400px;
    // height:100px;
    // margin: 0 auto;
    // padding:10px 0;
    // border-top: 1px solid transparent;
    .detail-item {
      b {
        // padding: 3px;
        // white-space:nowrap;
        // font-weight: 600;
      }
    }
  }
}

.detail-item {
  // margin-bottom: 8px;
  p {
    margin: 10px 0px;
    display: flex;
    b {
      min-width: 50px;

      height: 100%;
      // flex: 2;
      white-space: nowrap;
      font-weight: 700;
      font-family: "Source Han Sans CN";
    }
    span {
      // flex: 6;
      // word-wrap:break-word;
      display: inline-block;
      // width: 65%;
      overflow:hidden;
      text-overflow:ellipsis;
      display:-webkit-box;
      /*! autoprefixer: ignore next */
      -webkit-box-orient: vertical;
      -webkit-line-clamp:1;
      i{
        font-style: normal;
      }
    }
    .line-clamp {
      overflow:hidden;
      text-overflow:ellipsis;
      display:-webkit-box;
      /*! autoprefixer: ignore next */
      -webkit-box-orient: vertical;
      -webkit-line-clamp:2;
    }
  }
  .maskType {
    width: 90px;
    padding-left: 5px;
    background-color:  #D3D3D3;
    line-height: 20px;
    i {
      font-size: 14px;
      line-height: 20px;
    }
    span {
      font-size: 12px;
    }
  }
  .isMask {
     background-color:  #FFD905;
  }


  // .maskType {
  //   width: 90px;
  //   padding-left: 5px;
  //   background-color:  #D3D3D3;
  //   line-height: 20px;
  //   i {
  //     font-size: 14px;
  //     line-height: 20px;
  //   }
  //   span {
  //     font-size: 12px;
  //   }
  // }
  // .isMask {
  //    background-color:  #FFD905;
  // }
      .AllSwitch {
        background-color: #EDF0F2;
        color: #7C8B93;

        line-height: 20px;
        // height: 24px;
        padding: 0 5px ;
        border-radius: 5px;
        font-size: 12px;
        margin-right: 5px;
        display: inline-block;
        i {
          font-size: 12px;
        }
      }
      .isOwn {
        background-color:rgba(255,83,3,.15);
        color: #ff851b;
      }
      .isFever{
        background:rgba(245,19,0,.15);
        color: #F51300;
      }
      .isMask {
        background-color:rgba(72, 133, 255, .15);
        color: #4885FF;
      }
      .temp-style-abnormal{
          background-color: #fedbd9;
          color: #f51300;
        }
}

</style>

