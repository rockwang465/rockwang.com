<template>
  <div class="image-result-card" @click="viewDetail" @dragenter="dragenter">
    <el-image
      :src="processImgurl(item.imgUrl)" fit="cover" :data-imgcrop="JSON.stringify(item)">
      <div slot="error" class="image-slot">
        <i class="iconfont icon-img_error"></i><br>
        加载失败
      </div>
    </el-image>
    <span class="label" v-if="item.score">{{toPercent(item.score)}}</span>
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch ,Emit , Prop} from "vue-property-decorator";
  import { processImgurl } from "@/utils/image";
  import Icon from '@/components/icon-wrap/index.vue';
  import { toPercent } from '@/utils/small-tool';
  import { dressUpper } from '../../views/retrival/component/processInfo';

  @Component({
    // props: {
    //   items: {
    //     type: Object,
    //     default() {
    //       return [];
    //     }
    //   },
    //   item: {
    //     type: Object,
    //     default() {
    //       return [];
    //     }
    //   }
    // },
    components:{
      Icon
    }
  })
  export default class ImageItem extends Vue {
    @Prop({default:()=>{return []}}) item!:object
    @Prop({default:()=>{return []}}) items!:object
    // item: any;
    // items: any;
    IconName='maozi';
    // item2=[{0:1},{0:2},{0:3},{0:4},{0:5}];
    processImgurl = processImgurl;
    dressUpperColor ='transparent' ;
    bgcStyle= {
      background :''
    }
    toPercent = toPercent
    dressUpper = dressUpper
    mounted() {
      // console.log(this.$props.items);
      // console.log("行人记录单个", this.$props.item);
      // console.log(this.$props.item.dressUpperColor);

      this.dressUpperColor = this.$props.item.dressUpperColor
    }

    @Emit() //点击图片查看详情
    viewDetail(){
      console.log('-------------点击图片查看详情--------');

      return { items:this.items,item:this.item }
    }

    @Emit('dragenter')
    dragenter(event){
      event.preventDefault();
      return {event ,item: this.item}
    }

    i18nCompareType(val) {
      let compareType = ""
     switch(val){
       case "0":
       compareType = 'pedestrian.unknown';
       this.bgcStyle.background = '#FF9800'
       break;
       case "1":
       compareType="pedestrian.pedestrianRecord"; //$t('pedestrian.search')
       this.bgcStyle.background = '#1989fa'
       break;
       case "2":
       compareType="pedestrian.vehicleRecord";
       this.bgcStyle.background = '#1989fa'
       break;
       case "3":
      //  compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
      //  compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
      //  compareType="records.listNotifyTypeBlacklist";
       break;
       case "10":
       compareType="pedestrian.pedestrianCrossingWarning";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "11":
       compareType="pedestrian.pedestriansInvasion";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "20":
       compareType="pedestrian.parkedVehicles";
       this.bgcStyle.background = '#ED3A33'
       break;
     }
     return compareType

    }

    sortAttributeInfoVos(val) {
      // console.log(val);
      let name = val.attrType
      let IconName = ''

        switch (name) {
        case "coat_style-coat_color":
          IconName = 'shangyi'
            // return '上衣'
          break;
        case "trousers_color-trousers_len":
          IconName = 'kuzi'
            // return '裤子'
          break;
        case "hair_style-hair_color":
          IconName = 'faxing'
            // return '发型'
          break;
        case "shoes_style-shoes_color":
          IconName = 'xie'
            // return '鞋子'
          break;
        case "gender_code":
          IconName = 'xingbie'
            // return '性别'
          break;
        case "st_pedestrian_angle":
          IconName = 'jiaodu'
            // return '角度'
          break;
        case "coat_length-st_coat_pattern":
          IconName = 'shangyi'
          //上衣
          break;
        case "trousers_len-st_trousers_pattern":
          IconName = 'kuzi'
          //裤子
          break;
        case "st_hold_object_in_front":
          IconName = 'baowu'
          //胸前抱东西
          break;
        case "respirator_color":
          IconName = 'kouzhao'
            //口罩
          break;
        case "bag_style-bag_color":
          IconName = 'xiangbao'
            //包
          break;
        case "st_age":
          IconName = 'nianling1'
            //年龄
          break;
        case "umbrella_color":
          IconName = 'yusan'
            // 雨伞
          break;
        case "cap_style-cap_color":
          IconName = 'maozi'
            // 帽子
          break;
        default :
            return '假数据'
          break;
      }
      return IconName
    }

  }
</script>

<style lang="scss" scoped>
.image-result-card{
  height: 100%;
    width: 100%;
}
.el-image{
    height: 100%;
    width: 100%;
  }
  .image-slot{
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    text-align: center;
  }
  .label{
    position: absolute;
    display: inline-block;
    width: 100%;
    left: 0;
    bottom: 0;
    line-height: 1.8;
    background: rgba(109, 124, 150, .7);
    padding-left: 8px;
    z-index: 1;
    color: #fff;
    font-weight: bold;
  }

</style>
