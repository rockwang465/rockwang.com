<template>
  <div>
    <el-dialog :title="$t('imagemanagement.buttonAddtoGroup')" :visible.sync="dialogShowVisible" width="584px">
      <br>
      <el-input
        style="width:296px"
        size="medium"
        suffix-icon="el-icon-search"
        v-model="filterText">
      </el-input>
      <br>
      <div style="height: 150px;overflow: auto;width: 296px;">
        <el-tree  v-if="dialogShowVisible"
                  ref="tree"
                  :data="obj"
                  :props="defaultProps"
                  :filter-node-method="filterNode"
                  node-key="libraryId"
                  show-checkbox
        />
      </div>
      <div class="timezone-timezone-footer">
        <el-button type="primary" :loading="loading" @click="confirmData">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {isEmpty} from '@/utils/validate';
  import {PortraitModule} from '@/store/modules/portrait';
  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      }
    }
  })
  export default class AddPersonGroup extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    filterText = "";
    defaultProps = {
      children: 'children',
      label: 'libraryName',
    };
    loading = false;
    obj = [] as any;
    checkLabel = "";
    @Prop(Number) type!: any;
    @Prop(Object) dataObj!: any;
    @Prop(Array) idArr!: any[];
    @Prop(Array) propTreeData!: any[];

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.obj = [];
      for(let i = 0;i < this.propTreeData.length;i++){
        if (this.propTreeData[i].id == this.type){
          this.obj.push(this.propTreeData[i]);
        }
      }
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.filterText = '';
        this.$emit("closeEdit")
      }
    }

    //监听搜索框的值,检索
    @Watch('filterText')
    onFilterTextChange(val: string) {
      (this.$refs.tree as any).filter(val);
      // if (val){
      //   (this.$refs.tree as any).filter(val);
      // } else{
      //   (this.$refs.tree as any).filter('');
      // }
    }

    //根据值过滤掉不匹配的分支
    filterNode(value: string, data: any) {
      // if (!value) {
      //   return true;
      // }
      // return data.libraryName.indexOf(value) !== -1;
      if (data.libraryName.indexOf(value) == -1&&data.libraryType){
        data.disabled = true;
      }else if (data.adminRole != 1) {
        data.disabled = false;
      }
      return data.libraryName.indexOf(value) !== -1;
    }


    confirmData() {
      let that = this as any;
      let userIds = (this.$refs.tree as any).getCheckedKeys();

          for(let i = 0;i < userIds.length;i ++){
            if (userIds[i] == undefined){
              userIds.splice(i,1);
            }
          }
      console.log(userIds,'人像库id组');
      if(userIds.length === 0){
        that.$message({
          showClose: true,
          // message: "请选择分组",
          message: that.$t('usermanagement.titleSelectGroup'),
          type: 'error'
        });
        return;
      }
      this.loading = true;
          let dataObj = {
            libraryIds:userIds,
            targetIds:this.idArr
          }
          console.log(dataObj,'dataObj')
      PortraitModule.protraitCopyList(dataObj).then((data: any) => {
        // console.log("列表数据",data);
        if (!data.code) {
          this.$message({
            showClose: true,
            // message: "所选人像添加到分组成功",
            message: that.$t('globaltip.tipmsgImageAddtoGroup'),
            type: 'success'
          })
          this.dialogShowVisible = false;
        }
      }).catch((err) => {

      }).finally(()=>{
        this.loading = false;
      })
    }

    getUserIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        let arr = (array[i] + '').split('_');
        arr.length == 1 ? ids.push(arr[0]) : ''
      }
      return ids;
    }

    getDeviceIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        ids.push(array[i].deviceId);
      }
      return ids;
    }
  }

</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .timezone-timezone-footer {
    text-align: center;
    padding: 20px;
  }

  .cancel {
    background-color: rgba(162, 176, 199, 0.3) !important;
  }
</style>
