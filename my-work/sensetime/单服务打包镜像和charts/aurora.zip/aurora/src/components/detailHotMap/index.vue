<template>
   <div class="canvasHotMap">
       <canvas id="myCanvas" ref="cvs" >
       </canvas>
   </div>
</template>

<script lang="ts">
import { Component, Vue, Watch , Emit, Prop} from "vue-property-decorator";
import log from "../../api/log";

   @Component
   export default class detailHotMap extends Vue {
    @Prop({default(){return []}}) hotMapList!:any[]
    //  hotMapList = [
    //     { x: 1020, y: 360 ,value :1},
    //     { x: 936, y: 480 ,value :1},
    //     { x: 960, y: 480 ,value :1},
    //     { x: 1032, y: 480 ,value :1},
    //     { x: 1056, y: 480 ,value :1}
    // ]

    mounted() {
      // console.log(this.hotMapList);
      this.getHotMap()
    }

    @Watch('hotMapList',{ immediate: true,deep:true })
    onhotMapList(val,old) {
      // console.log(val,old);
      this.getHotMap()
    }

    getHotMap() {
        if(!this.hotMapList) {
          return
        }
        // let i =1
        this.hotMapList.forEach((item:any)=>{
          item.value = 1
          // i= i+1
        })
        let _this = this as any;
        // 0. 创建Canvas并获取上下文
        this.$nextTick(()=>{
          let canvas = _this.$refs.cvs as any;
          // let canvas = document.getElementById("myCanvas") as any;
          canvas.width = 1920;
          canvas.height = 1080;
          let context = canvas.getContext("2d") as any;
          context.clearRect(0,0,canvas.width,canvas.height);
          // 1.2.3. 根据热力值绘制辐射圆
          let min = 0;
          let max = _this.hotMapList.reduce((max, data) => {
              return Math.max(max, data.value?data.value:1);
          }, 0);
          _this.hotMapList.slice(0).forEach(data => _this.drawRadiation(context, {
              x: data.x,
              y: data.y,
              radius: 70, //圆半径
              weight: Math.max(Math.min((data.value?data.value:1 - min) / (max - min), 1), 0)
          }));

          // 4. 颜色映射
          let palette = _this.createPalette();
          // document.body.appendChild(palette.canvas);

          let { width, height } = canvas;
          let imageData = context.getImageData(0, 0, width, height) as any;
          let data = imageData.data;
          for (let i = 3; i < data.length; i += 4) {
              let alpha = data[i];
              let color = palette.pickColor(alpha);
              data[i - 3] = color[0];
              data[i - 2] = color[1];
              data[i - 1] = color[2];
          }
          context.putImageData(imageData, 0, 0);
          // console.log('绘制结束1');
        })

    }
       // 绘制辐射圆
     drawRadiation(context, opts) {
        let { x, y, radius, weight } = opts;
        radius = Math.round(radius * weight);

        // 设置填充色
        let rGradient = context.createRadialGradient(x, y, 0, x, y, radius);
        rGradient.addColorStop(0, "rgba(0, 0, 0, 1)");
        rGradient.addColorStop(1, "rgba(0, 0, 0, 0)");
        context.fillStyle = rGradient;

        // 设置globalAlpha
        context.globalAlpha = weight;

        // 绘制圆形
        context.beginPath();
        context.arc(x, y, radius, 0, 2 * Math.PI);
        context.closePath();

        // 填充
        context.fill();
        // console.log('绘制结束2');
    }

    // 创建调色盘
     createPalette() {
        let colorStops = {
            // 0: "#0ff",
            // 0.2: "#0f0",
            // 0.4: "#ff0",
            // 1: "#f00",

          .4: "#00f",
          0.95: "#0f0",
          // 0.95: "#ff0",
          1: "#f00"
        };
        let width = 256, height = 20;

        // 创建canvas
        let palatteCanvas = document.createElement("canvas");
        palatteCanvas.width = width;
        palatteCanvas.height = height;
        let ctx = palatteCanvas.getContext("2d") as any;

        // 创建线性渐变色
        let linearGradient = ctx.createLinearGradient(0, 0, width, 0);
        for (const key in colorStops) {
            linearGradient.addColorStop(key as any, colorStops[key]);
        }

        // 绘制渐变色条
        ctx.fillStyle = linearGradient;
        ctx.fillRect(0, 0, width, height);

        // 读取像素值
        let imageData = ctx.getImageData(0, 0, width, 1).data as any;
        // console.log('绘制结束3');
        return {
            canvas: palatteCanvas,
            pickColor: function (position) {
                return imageData.slice(position * 4, position * 4 + 3)
            }
        }
    }
   }
</script>

<style lang="scss" scoped>
  .canvasHotMap{
    canvas {
      width: 100%;
      height: 100%;
      // background: rgba(0,0,256,.3);
    }
  }
</style>
