<template>
  <div>
    <el-dialog :title="$t('usermanagement.buttonMoveGroup')" :visible.sync="dialogShowVisible" width="584px">
      <br>
      <el-input
        style="width:296px"
        size="medium"
        suffix-icon="el-icon-search"
        v-model="filterText">
      </el-input>
      <br>
    <div style="height: 150px;overflow: auto;width: 296px;">
      <el-tree
        ref="tree"
        :data="dataObj.treeData"
        :props="defaultProps"
        :filter-node-method="filterNode"
        node-key="id"
        :render-content="renderContent"
      />
    </div>

      <div class="timezone-timezone-footer">
        <el-button type="primary" @click="confirmData">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {isEmpty} from '@/utils/validate';
  import {UserModule} from '@/store/modules/user';
  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      }
    }
  })
  export default class AddGroup extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    filterText = "";
    defaultProps = {
      children: 'children',
      label: 'name',
    };
    checkLabel = "";
    @Prop(Object) dataObj!: any[];

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      console.log(this.dataObj)
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeEdit")
      }
    }

    //监听搜索框的值,检索
    @Watch('filterText')
    onFilterTextChange(val: string) {
      (this.$refs.tree as any).filter(val);
      console.log(this.dataObj)
    }

    //根据值过滤掉不匹配的分支
    filterNode(value: string, data: any) {
      if (!value) {
        return true;
      }
      return data.name.indexOf(value) !== -1;
    }

    confirmData() {
      let that = this as any;
      switch (that.dataObj.type) {
        case "addGroup":
          if (isEmpty(that.checkLabel)) {
            that.$message({
              showClose: true,
              // message: "请选择分组",
              message: that.$t('usermanagement.titleSelectGroup'),
              type: 'error'
            });
            // that.dialogShowVisible = false;
            return
          }
            let userArr = [] as any;
            (this.dataObj as any).checkList.forEach((item)=>{
              userArr.push(item.userId);
            });
          let params = {
            userIds:userArr,
            orgId:that.checkLabel
          } as any;
          UserModule.BatchMoveUser(params).then((data: any) => {
            that.$message({
              showClose: true,
              // message: '添加成功',
              message: that.$t('globaltip.tipmsgUserAddtoGroup'),
              type: 'success'
            });
            that.dialogShowVisible = false;
            that.$emit("inIt");
          }).catch((err) => {
            console.log(err)
          });
          break;
      }
    }


    getDeviceIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        ids.push(array[i].deviceId);
      }
      return ids;
    }

    renderContent(h, {node, data, store}) {
      let that = this as any;
      switch (that.dataObj.type) {
        case "addGroup":
          // if (isEmpty(data.children)) {
            return h('div', {
              style: {
                width: '100%'
              },
            }, [
              h("el-radio", {
                on: {
                  input: function (event) {
                    that.checkLabel = event
                  }
                },
                props: {
                  value: that.checkLabel,
                  label: data.id,
                  key: data.id
                },
              }, node.label)
            ]);
          // }
          // else {
          //   return h('div', {
          //     style: {
          //       width: '100%'
          //     },
          //   }, [node.label])
          // }
      }
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .timezone-timezone-footer {
    text-align: center;
    padding: 20px;
  }

  .cancel {
    background-color: rgba(162, 176, 199, 0.3) !important;
  }
</style>
