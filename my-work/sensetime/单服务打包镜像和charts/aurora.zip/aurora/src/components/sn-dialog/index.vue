<template>
  <div>
    <el-dialog
      v-bind="props"
      :title="title"
      :visible.sync="visible"
      width="30%">
      <slot></slot>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch, Emit} from 'vue-property-decorator';
  import { Dialog } from 'element-ui';
  var props = (Dialog as any).props
  @Component({
    props: {
      title:{
        type:String,
        default:"",
      },
      ...props
    }
  })
  export default class SnDialog extends Vue {
    visible:boolean=false;
     get props(){
        return (this as any)._props
    }

    @Emit()
    cancel(){
      
    }
    @Emit()
    confirm(){

    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

</style>
