<template>
  <div class="mediaplayer" ref="mediaplayer" @mouseenter="hoverVideoEnter" @mouseleave="hoverVideoLeave" :style="{height:defaultHeight+'px'}">
  <!-- <div class="mediaplayer" ref="mediaplayer" @mouseenter="hoverVideoEnter" @mouseleave="hoverVideoLeave" > -->
    <video class="mediaplayer-video" v-if="(type==='1' || type==='2')" :id="playerId" autoplay ></video>
    <img v-if="type == '3'" :src="currentKeeperAlarmImgSrc" class="mediaplayer-imgplayer">
    <div v-if="type =='2' && frameArr.length>0" class="mediaplayer-video-overlays" ref="media-videoOverlays" id="media-videoOverlays"  >
      <div  v-for="(frame,frameIndex) in frameArr" :key="frame.trackId+'-'+frameIndex"
        class="media-videoOverlays--video_frame"
        :style="{left:frame.left,top:frame.top,width:frame.width,height:frame.height}"
      ></div>
    </div>
    <div v-show="showLoading" v-if="type==='1' || type==='2'" class="mediaplayer-donut"></div>
    <div class="mediaplayer-empty" v-show="showEmpty">
      <span v-if="playerNosourceText == 'monitor'">{{$t('liveservice.contVideoPlayer')}}</span>
      <span v-else >No source</span>
    </div>
    <div class="mediaplayer-camerainfo" v-show="isMouseEnter && showControl" >
      <p v-show="!!parentName"><span>{{parentName}}</span></p>
      <p><span class="mediaplayer-green-point" ></span> {{ name}}</p>
      <div v-show="pause "  :class="['mediaplayer-play']" @click.stop="handleClickToPause" > <i class="iconfont icon-play1" ></i> </div>
      <div v-show="!pause "  :class="['mediaplayer-pause']" @click.stop="handleClickToPause" ><i class="iconfont icon-gf-pauseCircle" ></i></div>
      <div class="mediaplayer-fullscreen-btn" @click="fullScreen" >{{$t('liveservice.contEnlargeScreen')}}</div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch} from 'vue-property-decorator';
import '@/assets/js/streamedian/streamedian.min.js';
import 'protobufjs/dist/protobuf.min.js';
import '@/assets/js/streamedian/previewinfo_static.js';
import { setInterval, setTimeout } from 'timers';
import { Stomp } from "stompjs/lib/stomp.min.js";
import {Cache} from '@/utils/cache';
import { processImgurl } from '@/utils/image';
import SockJS from 'sockjs-client';
const tdwsHost = window.globalConfig.tdwsHost;
const host = window.globalConfig.host;
const protobuf = window.protobuf;
const config = window.globalConfig;
const Streamedian = window.Streamedian;


@Component({
  components: {

  },
})
export default class Mediaplayer extends Vue {
  /* props */
  @Prop({ default: '1' }) type!: string; //type=1 video without frame , type=2 video with frame ,type=3 images
  @Prop({ default: '' ,required:false}) url!: string;//rtsp地址
  @Prop({ default: '' }) name!: string;//设备name
  @Prop({ default: '' }) parentName!: string;//设备parentName
  @Prop({ default: false,required:false }) showControl!: boolean;//是否显示底部control
  @Prop({ default: '',required:false }) keeperId!: string;//图片播放器keeperid
  @Prop({ default: '',required:false }) playerNosourceText!: string;//无资源提示语 1、''(空) 2、monitor

  /* watch */
  @Watch('type', { immediate: false, deep: false })
  onTypeChanged(n:string, o:string) {
    this.typeChange(n,o)
  };
  @Watch('url', { immediate: false, deep: false })
  onUrlChanged(n:string, o:string) {
    if(n) {
      this.showEmpty = false;
      this.playSource()
      }else{
      this.showEmpty = true;
    }
  };
  @Watch('keeperId', { immediate: false, deep: false })
  onKeeperIdChanged(n:string, o:string) {
    n && this.initPicturePlayer();
  };

  /* data */
  $refs!: {
    mediaplayer: HTMLFormElement
  };
  playerId:string =this.getRandomId();;
  playerClient :any;
  switching =false;
  playerElement :any;
  loopId :number= 0;
  PreviewInfoSEIID= '';
  PreviewInfo: any;
  trackIds:number[] = [];
  frameArr: any[] = [];
  showLoading=false;
  pause:boolean=false;
  defaultRate:number=1920/1080;
  defaultHeight:number=0;
  isMouseEnter:boolean=false;
  showEmpty:boolean = true;
  //图片播放器
  timer:any=null;
  sessionIdAC:string='';
  socketAC:any=null;
  socketClientAC:any=null;
  currentKeeperAlarm:any={};
  currentKeeperAlarmImgSrc:string="";

  sessionIdTD:string='';
  socketTD:any=null;
  socketClientTD:any=null;
  /* methods */
  created() {
    // this.playerId = this.getRandomId();
  }
  mounted() {
    if(this.type == '2' || this.type == '1'){
      this.setDefaultHeight();
      this.initPreviewInfo();
      this.initPlayer()
    }
    if(this.type == '3' && this.keeperId){
      this.initPicturePlayer();
    }

  }
  connectCameraWS(){
    this.sessionIdTD = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socketTD = new SockJS(`${tdwsHost}/senseguard-td-result-consume/stomp`,[], {
      sessionId: ()=>{
       return this.sessionIdTD;
      }
    });
    this.socketClientTD = Stomp.over(this.socketTD);
    this.socketClientTD.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    this.socketClientTD.connect(
      {userId},
      (frame)=> {
        this.socketClientTD.subscribe(`/queue/${this.sessionIdTD}`,  (res) =>{
          res = JSON.parse(res.body).record ;
          console.log(this.keeperId,res)
          if(res.deviceId+'' == this.keeperId){
            this.currentKeeperAlarm = res;
            this.currentKeeperAlarmImgSrc = processImgurl(res.imageUrl);
          }

        });
        //send DLC id
        this.socketClientTD && this.sendmsgTD();
      },(error)=> {}
    );
    this.socketTD.onclose=()=>{//HA reconnect
      if(this.$route.path === '/monitor'){
        try {
          setTimeout(()=>{
            this.connectCameraWS();
          },5000)//5s
        } catch (error) {}

      }
    }
  }
  connectKeeperWS(){
    this.sessionIdAC = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socketAC = new SockJS(`${tdwsHost}/senseguard-ac-result-consume/stomp`,[], {
      sessionId: ()=>{
       return this.sessionIdAC;
      }
    });
    this.socketClientAC = Stomp.over(this.socketAC);
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    this.socketClientAC.connect(
      {userId},
      (frame)=> {
        this.socketClientAC.subscribe(`/queue/${this.sessionIdAC}`,  (res) =>{
          res = JSON.parse(res.body).record ;
          if(res.deviceId+'' == this.keeperId){
            this.currentKeeperAlarm = res;
            this.currentKeeperAlarmImgSrc = processImgurl(res.imageUrl);
          }

        });
        //send keeperid
        this.socketClientAC && this.sendmsg();
      },(error)=> {}
    );
    this.socketAC.onclose=()=>{//HA reconnect
      if(this.$route.path === '/monitor'){
        try {
          setTimeout(()=>{
            this.connectKeeperWS();
          },5000)//5s
        } catch (error) {}

      }
    }
  }
  sendmsg() {
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    const requestBodyAC =JSON.stringify({
      sessionId:this.sessionIdAC,
      deviceIds:[this.keeperId],
      userId
    });
    this.socketClientAC.send(`/app/filter_condition_ac`,{},requestBodyAC);
  }
  sendmsgTD() {
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    const requestBodyTD =JSON.stringify({
      sessionId:this.sessionIdTD,
      deviceIds:[this.keeperId],
      userId
    });
    this.socketClientTD.send(`/app/filter_condition`,{},requestBodyTD);
  }
  setDefaultHeight(){
    let w = this.$refs.mediaplayer.offsetWidth;
    this.defaultHeight = w*(1/this.defaultRate);
  }
  typeChange(n:string,o:string){
    //type change  do`t change overLays DOM
    if(n == '1' && this.playerElement) this.cancelVideoFrameFun(this.playerElement);
    if(n == '2' && this.playerElement) this.addVideoFrameFun(this.playerElement);
  }
  getRandomId(){
    return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, c => {
      const r = (Math.random() * 16) | 0,v = c == "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  };
  initPlayer(){
    if (this.playerClient) {
      this.playerClient.destroy();
      this.playerClient = null;
    }
    if (this.url ) {
      if(document.getElementById(this.playerId)){
        this.showEmpty = false;
        this.playerClient = Streamedian.player(this.playerId, {
          socket: config.streamedianHost,
          reconnectHandler:this.reconnectHandler,
          errorHandler:this.errorHandler
        });
        this.showLoading = true;
        this.playerClient.errorHandler = this.errorHandler;
        this.playerClient.queryCredentials = this.queryCredentialsHandler(this.playerClient);
        this.playSource();
        this.playerElement = document.getElementById(this.playerId);
        this.playerElement.muted = true;
        let overLays = document.getElementById('media-videoOverlays');
        this.addVideoEventsListener(this.playerElement,overLays);

      }else{
        this.timer = null;
        //当从picture模式切换到camera模式时 会出现无法播放 原因是 ：video dom不存在 解决方法：1、 延时重试 2、video dom  v-show 替换v-if
        this.timer = setTimeout(()=>{
          this.initPlayer();
        },500)
      }

    }
  }
  reconnectHandler(e){
    return new Promise((resolve,reject)=>{
      this.$message.error({showClose: true,message:`Failure to start player: code ${e.code} message:${e.msg}`});
      reject();
    })
  }
  errorHandler(e){
    let message = e.message?{code:e.message.code,msg:e.message.body}:{code:null,msg:null};
    this.$message.error({showClose: true,message: e.message.code?`Failure to start player: code ${message.code} message:${message.msg}`:e.message });
  }
  addVideoEventsListener(videoElement:any,overLays:any){
    window.onresize = (e)=>{
      overLays && (overLays.style.width = this.playerElement.clientWidth+'px');
      overLays && (overLays.style.height = this.playerElement.clientHeight+'px');
    };
    videoElement.onloadstart = (e:any)=>{
      this.showLoading = true;
    };
    videoElement.oncanplay = (e:any)=>{
      this.showLoading = false;
      overLays && (overLays.style.width = this.playerElement.clientWidth+'px');
      overLays && (overLays.style.height = this.playerElement.clientHeight+'px');
      this.type =='2' && this.addVideoFrameFun(videoElement);
    }
    videoElement.onloadedmetadata=(e:any)=>{
      this.setFrameBoxHeight(e.target)
      let s_ = true;
      s_ && this.delayReconnect(this.playerElement,()=>{s_ = false});
      this.$nextTick(()=>{
        this.$emit('loadedmetadata',e)
      })
    }
    videoElement.onerror = (e:any)=>{
      this.showLoading = false;
    }
    videoElement.onplaying = (e:any)=>{
      this.showLoading = false;
    }
  }
  setFrameBoxHeight(video){
    let w = video.videoWidth,h = video.videoHeight;
    let w_c = this.$refs.mediaplayer.offsetWidth;
    if(w && h && w_c){
      this.defaultRate = w/h;
      this.defaultHeight = w_c*(1/this.defaultRate);
    }
  }
  addVideoFrameFun(videoElement:any){
    cancelAnimationFrame(this.loopId);
    let v_w = videoElement.videoWidth,
        c_w = videoElement.clientWidth,
        scale=c_w/v_w;
    // console.log(videoElement);
    this.loopId = requestAnimationFrame(()=>{
      this.setFrameBox(0,scale)
    })
  }
  cancelVideoFrameFun(videoElement:any){
    cancelAnimationFrame(this.loopId);
    this.trackIds=[];
    this.frameArr=[];
    this.loopId = 0;
  }
  initPreviewInfo(){
    this.PreviewInfoSEIID = (new Uint8Array([0x7d, 0x4b, 0x4e, 0xb8, 0xcc, 0xab, 0x49, 0x0f, 0xa8, 0x18, 0x76, 0x92, 0x9f,0xbf, 0xdd, 0xd8])).toString();
    this.PreviewInfo = protobuf.roots["default"].sensetime.viper.video_process.preview_info.PreviewInfo;
  };
  playSource(){
    if(this.playerClient){
      if(document.getElementById(this.playerId)){
        this.showLoading = true;
        cancelAnimationFrame(this.loopId);
        this.playerClient.setSource(this.url,'rtsp');
      }else{
        this.initPlayer();
      }
    }else{
      this.initPlayer();
    }
  };
  destroyed() {
    this.destroyePlayer();
    this.socketAC && this.socketAC.close();
    this.socketTD && this.socketTD.close();
  }
  destroyePlayer() {
    this.trackIds=[];
    this.frameArr=[];
    this.loopId = 0;
    if (this.playerClient) {
      this.playerClient.destroy();
      this.playerClient = null;
    }
    this.socketClientAC && this.socketClientAC.disconnect();
    this.socketClientTD && this.socketClientTD.disconnect();
  }
  queryCredentialsHandler(client:any){
    return new Promise((resolve,reject)=>{
      resolve()
    })
  }
  setFrameBox(count:number,scale:number){
    if(count >= 1000){count = 0;}
    count ++ ;
    let ev = this.playerClient ? this.playerClient.pullOOBData(this.playerElement.currentTime+0.020):[];
    // console.log('setFrameBox:===',this.playerClient,ev)
    if(ev.length>0){
      let lasted = ev[ev.length-1],pi = ev.length>0 ?this.PreviewInfo.decode(lasted.payload.subarray(16)):null,seiID = lasted.payload.subarray(0,16).toString();
      if (lasted.seenIDR && this.PreviewInfo && (seiID == this.PreviewInfoSEIID) && pi !== null && pi.objects !==undefined && pi.objects.length>0) {
        count = 0;
        this.setFrame(pi.objects,scale);
      }
    }else if( count >= 7 ){
      this.trackIds = [];this.frameArr = [];
    }else{

    }
    //always doing
    this.loopId = requestAnimationFrame(()=>{
      this.setFrameBox(count,scale)
    })
  }
  setFrame(objs:any,scale:number){
    let newFrameArr:any = [], newTrackIds :any[];
    newTrackIds = [];
    for(let i = 0;i<objs.length;i++){
      let e = objs[i],frameInfo = this.getFrameInfo(e,scale),low:number=e.trackId.low;
      newTrackIds.push(low)
      newFrameArr.push(e)
      if(!this.trackIds.includes(low)){
        //add
        this.trackIds.push(low);
        this.frameArr.push(frameInfo);
      }else{
        //update
        this.frameArr.map((frame:any,index)=>{
          if(frame.trackId.low === e.trackId.low){Vue.set(this.frameArr,index,frameInfo)}
        })
      }
    }
    //delete
    this.frameArr.map((frame:any,index)=>{
      if(!newTrackIds.includes(frame.trackId.low)){
        this.trackIds.splice(index,1)
        this.frameArr.splice(index,1)
      }
    });
  }
  getFrameInfo(e:any,scale:number){
    let f_w = (e.bounding.vertices[1].x - e.bounding.vertices[0].x)*scale,
    f_h = (e.bounding.vertices[1].y - e.bounding.vertices[0].y)*scale,
    f_x = (e.bounding.vertices[0].x)*scale,
    f_y = (e.bounding.vertices[0].y)*scale,
    trackId = e.trackId,
    params = {left:f_x+'px',top:f_y+'px',width:f_w+'px',height:f_h+'px',trackId};
    return params;
  }
  handleClickToPause(){
    this.pause = !this.pause;
    this.pause && this.playerClient && this.playerElement.pause();
    !this.pause && this.playerClient && this.playSource();
  }
  hoverVideoEnter(){
    this.isMouseEnter = true;

  }
  hoverVideoLeave(){
    this.isMouseEnter = false;

  }
  fullScreen() {
    let ele = this.playerElement;
    if(ele){
      if (ele.requestFullscreen) {
        ele.requestFullscreen();
      } else if (ele .mozRequestFullScreen) {
        ele.mozRequestFullScreen();
      } else if (ele .webkitRequestFullScreen) {
        ele.webkitRequestFullScreen();
      }
    }
  }
  //图片播放器
  initPicturePlayer(){
    this.showEmpty = false;
    this.currentKeeperAlarmImgSrc = '';
    this.socketClientAC && this.socketClientAC.disconnect();
    this.socketClientTD && this.socketClientTD.disconnect();
    this.connectKeeperWS();
    this.connectCameraWS();
  }
  delayReconnect(videoElement:any,cal:any){
    let DELAT_TIME = 5;//s
    cal && cal();
    let init_currentTime = new Date().getTime();
    videoElement.ontimeupdate = (e:any)=>{
      let current_init_currentTime = new Date().getTime();
      let play_time = (current_init_currentTime - init_currentTime)/1000;
      let currentTime = videoElement.currentTime;
      let delay_time_ = Math.abs(currentTime - play_time);
      if(delay_time_ >= DELAT_TIME && currentTime>10 && delay_time_<(DELAT_TIME+15)){//初始播放超过10s 有延时的时候才去重连
        this.initPlayer();
      }
    }
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .mediaplayer{
    width: 100%;
    position: relative;
    background-color: $--color-black;
    .mediaplayer-video-overlays{
      position: absolute;
      left: 0;
      top:0;
      z-index: 11;
      width: 100%;
      height: 100%;
      .media-videoOverlays--video_frame{
        position: absolute;
        // transition: left 20ms,top 20ms;
        background: linear-gradient(to left, #f00, #f00) left top no-repeat,
                    linear-gradient(to bottom, #f00, #f00) left top no-repeat,
                    linear-gradient(to left, #f00, #f00) right top no-repeat,
                    linear-gradient(to bottom, #f00, #f00) right top no-repeat,
                    linear-gradient(to left, #f00, #f00) left bottom no-repeat,
                    linear-gradient(to bottom, #f00, #f00) left bottom no-repeat,
                    linear-gradient(to left, #f00, #f00) right bottom no-repeat,
                    linear-gradient(to left, #f00, #f00) right bottom no-repeat;
        background-size: 1px 25%, 25% 2px, 2px 25%, 25% 2px;
      }
    }
    .mediaplayer-video{
      width: 100%;
      display: block;
      margin: 0 auto;
      height: 100%;
    }
    .mediaplayer-camerainfo{
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      padding: 2px 0;
      z-index: 2;
      background:linear-gradient(to top,rgba(24, 22, 22, 0.5),rgba(136, 132, 132,0.5));
      color: white;
      font-size: 14px;
      p{
        margin: 5px;
        text-indent: 20px;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
        line-height: 18px;
      }
      .mediaplayer-green-point{
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #50cb04;
      }
      .mediaplayer-play,.mediaplayer-pause{
        position: absolute;
        top: -14px;
        opacity: .7;
        left:calc(50% - 15px);
        width: 30px;
        height: 30px;
        border-radius: 50%;
        text-align: center;
        line-height: 30px;
        color: $--color-primary;
        background-color: white;
        .iconfont{
          font-size: 35px;
          position: relative;
          left: -2px;
          top: 0px;
        }
        cursor: pointer;
        transition: opacity 1s linear;
      }
      .mediaplayer-play{
        animation: play-stop 1s ;
      }
      .mediaplayer-pause{
        animation: play-stop 1s ;
      }
      .mediaplayer-fullscreen-btn{
        background-color: #2a5af5;
        color: #fff;
        cursor: pointer;
        position: absolute;
        top: 5px;
        right: 10px;
        padding: 2px;
      }
    }
    .mediaplayer-donut{
      position: absolute;
      top: calc(50% - 25px);
      left: calc(50% - 25px);
      z-index: 2;
      border: 4px solid rgba(250, 244, 244, 0.5);
      border-left-color: #080808;
      border-radius: 50%;
      width: 50px;
      height: 50px;
      animation: donut-spin 1.2s linear infinite;
      transition: all 1s;
    }
    .mediaplayer-empty{
      position: absolute;
      width: 100%;
      height: 100%;
      background-color: #212121;
      color: #fff;
      left: 0;
      top: 0;
      z-index: 5;
      display: flex;
      justify-content: center;
      align-items:center;
      box-shadow: -1px -1px 1px rgb(206, 191, 191);
    }
    @keyframes donut-spin {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }
    @keyframes play-stop {
      0% {
        opacity: 0;
      }
      100% {
        opacity: 1;
      }
    }
    .mediaplayer-imgplayer{
      height: 100%;
      margin: 0;
      padding: 0;
      display: block;
      margin: 0 auto;
    }
  }
  video::-webkit-media-controls-timeline,video::-webkit-media-controls-current-time-display,video::-webkit-media-controls-mute-button {
    display: none;
  }
</style>
