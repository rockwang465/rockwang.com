<template>
  <div>
    <el-dialog :title="dataObj.title" :visible.sync="dialogShowVisible" width="584px">
      <br>
      <el-input
        style="width:296px"
        size="medium"
        suffix-icon="el-icon-search"
        v-model="filterText">
      </el-input>
      <br>
      <div style="height: 150px;overflow: auto;width: 296px;">
        <el-tree v-if="dialogShowVisible"
                 ref="tree"
                 :data="dataObj.treeUserData"
                 :props="defaultProps"
                 :filter-node-method="filterNode"
                 node-key="id"
                 show-checkbox
        />
      </div>
      <div class="timezone-timezone-footer">
        <el-button type="primary" :loading="loading" @click="confirmData">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {isEmpty} from '@/utils/validate';
  import {DeviceModule} from '@/store/modules/device';

  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      }
    }
  })
  export default class AddGroup extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    filterText = "";
    loading = false;
    defaultProps = {
      children: 'children',
      label: 'name',
    };
    checkLabel = "";
    @Prop(Object) dataObj!: any[];

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.loading = false;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeEdit")
        this.filterText = '';
      }
    }

    //监听搜索框的值,检索
    @Watch('filterText')
    onFilterTextChange(val: string) {
      (this.$refs.tree as any).filter(val);
    }

    //根据值过滤掉不匹配的分支
    filterNode(value: string, data: any) {
      if (data.name.indexOf(value) == -1&&data.type == 1){
        data.disabled = true;
      }else {
        data.disabled = false;
      }
      return data.name.indexOf(value) !== -1;
    }

    confirmData() {
      let that = this as any;
      let deviceIds = that.getDeviceIds(that.dataObj.multipleSelection);
      this.loading = true;

      if (isEmpty(deviceIds) || deviceIds.size == 0) {
        that.$message({
          showClose: true,
          message: that.$t('devicemanagement.chooseDevice'),
          type: 'error'
        });
        that.dialogShowVisible = false;
        return
      }
      switch (that.dataObj.type) {
        case "addUser":
          let userIds = this.getUserIds((this.$refs.tree as any).getCheckedKeys());
          if (isEmpty(userIds) || userIds.length == 0) {
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.chooseUser'),
              type: 'error'
            });
            that.dialogShowVisible = false;
            return
          }
          DeviceModule.DeviceAddUserBatch({deviceIds: deviceIds, userIds: userIds}).then((data: any) => {
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.devicesAddUserSuccess'),
              type: 'success'
            });
            that.dialogShowVisible = false;
            that.loading = false;

          }).catch((err) => {
            console.log(err)
            that.loading = false;
          });
          break;

        //   let userArr = [] as any;
        //   this.dataObj.checkList.forEach((item)=>{
        //       userArr.push(item.userId);
        //   });
        //   let orgId = this.getUserIds((this.$refs.tree as any).getCheckedKeys());
        // let params = {
        //   userIds:userArr,
        //   orgId:orgId
        // } as any;
        //   UserModule.BatchMoveUser(params).then((data: any) => {
        //     that.$message({
        //       message: '添加成功',
        //       type: 'success'
        //     });
        //     that.dialogShowVisible = false;
        //   }).catch((err) => {
        //     console.log(err)
        //   });
        //   break;
      }
    }

    getUserIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        let arr = (array[i] + '').split('_');
        arr.length == 1 ? ids.push(arr[0]) : ''
      }
      return ids;
    }

    getDeviceIds(array) {
      let ids = [] as any;
      for (let i = 0; i < array.length; i++) {
        ids.push(array[i].deviceId);
      }
      return ids;
    }
  }

</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .timezone-timezone-footer {
    text-align: center;
    padding: 20px;
  }

  .cancel {
    background-color: rgba(162, 176, 199, 0.3) !important;
  }
</style>
