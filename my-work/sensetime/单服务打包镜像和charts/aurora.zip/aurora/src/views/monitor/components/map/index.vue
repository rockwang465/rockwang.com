<template>
  <div class="map-container map-monitor" @mousemove.prevent="(e)=>{debounce(handleMouseMove(e),300)}">
    <div class="map-header-box side-title">
      <i class="iconfont icon-map-full-screen" ></i>
      <span>{{$t('liveservice.labelMapView')}}</span>
    </div>
    <div class="device-panel"  ref="devicePanel">
      <div class="move-bar" @mousedown="handleMouseDown" @mouseup="handleMouseUp">:::</div>
      <dl>
        <dt>{{$t('liveservice.contTotalDevice')}}</dt>
        <dd>
          <i class="iconfont icon-device"></i>
          <strong>{{totalDevice.total}}</strong>
        </dd>
      </dl>
      <dl>
        <dt>{{$t('liveservice.contOnlineDevice')}}</dt>
        <dd>
          <i class="iconfont icon-online"></i>
          <strong>{{totalDevice.onlineCount}}</strong>
        </dd>
      </dl>
      <dl>
        <dt>{{$t('liveservice.contOfflineDevice')}}</dt>
        <dd>
          <i class="iconfont icon-offline"></i>
          <strong>{{totalDevice.offlineCount}}</strong>
        </dd>
      </dl>
    </div>

    <div v-if="noMapData" class="no-map">
      <div class="no-map-tips">
        <img src="/images/nomap.png" width="260" alt="no map" >
        <div class="nomap-info">
          <h3>{{$t('liveservice.contBlankPage')}}</h3>
          <h4>{{$t('liveservice.contInstruction.Title')}}</h4>
          <ol>
            <li v-html="$t('liveservice.contInstruction.First')"></li>
            <li v-html="$t('liveservice.contInstruction.Second')"></li>
            <li v-html="$t('liveservice.contInstruction.Third')"></li>
          </ol>
        </div>
        <!-- <div v-html="$t('liveservice.contInstruction')"></div> -->
      </div>
    </div>
    <div v-if="!noMapData" class="map_layer">
      <div class="device-select">
        <device-select @nodeData="getNodeData" :key="searchKey" class="select-tree"/>
      </div>
      <div class="selectBar">
        <i class="iconfont icon-place"></i>
        <span>{{$t('devicemanagement.contLocation')}}：</span>
        <select-tree class="select-tree"
          @postTree="treeSelect"
          v-model="selectedOptions"
          :options="treeData"
          :defaultVal="selectedOptions"
          :key="selectTreeKey"
          :props="defaultProps" />
        <!-- <el-checkbox v-model="postStranger" disabled>推送陌生人记录</el-checkbox> -->
      </div>
      <l-map ref="elMap" style="height: 100%; width: 100%;"
        :min-zoom="mapSet.minZoom"
        :max-zoom="mapSet.maxZoom"
        :zoom="mapSet.zoom"
        :center="mapSet.center"
        v-loading="loading"
        :key="mapSet.key"
        :options="mapOptions"
        :crs="crs">
        <l-image-overlay
          v-if="hasbg"
          :url="mapSet.bgUrl"
          :bounds="mapSet.bounds"/>
        <div v-else class="no-map">
          <div class="no-map-tips">
            <img src="/images/nomap.png" width="260" alt="no map" >
            <div class="nomap-info">
              <div class="no-map-msg">{{$t('liveservice.contBlankPage')}}</div>
              <h4>{{$t('liveservice.contInstruction.Title')}}</h4>
              <ol>
                <li v-html="$t('liveservice.contInstruction.First')"></li>
                <li v-html="$t('liveservice.contInstruction.Second')"></li>
                <li v-html="$t('liveservice.contInstruction.Third')"></li>
              </ol>
            </div>
          </div>
        </div>
        <div v-if="hasbg">
          <div class="heatmaplayer" v-if="deviceLi">
            <l-marker v-for="item in deviceLi"
              :lat-lng.sync="item.position"
              :zIndexOffset="-1"
              :key="item.deviceId">
              <l-icon class="mmmm" :icon="mydivIcon">&nbsp;
                <div class="heatmap-numbers fadein">{{item.heatCount}}</div>
              </l-icon>
              <!-- <l-tooltip v-if="item.heatNumber" :options="showOption2">
                {{item.heatCount}}
              </l-tooltip> -->
            </l-marker>
          </div>
          <l-marker v-for="item in deviceList"
            :lat-lng.sync="item.position"
            :icon="item.icon"
            :key="item.name">
            <l-popup>
              <p>
                <strong>{{$tc('map.deviceType')}}</strong>
                {{item.deviceType == 1 ? "Camera" : item.deviceType == 2 ? "SenseKeeper" : item.deviceType == 4 ? "SenseDLC" : "未知"}}
              </p>
              <p><strong>{{$tc('map.deviceName')}}</strong>{{item.deviceName}}</p>
              <!-- <p v-if="item.deviceId"><strong>{{$tc('map.deviceId')}}</strong>{{item.deviceId}}</p> -->
              <p v-if="item.id"><strong>{{$tc('map.deviceId')}}</strong>{{item.id}}</p>
              <p class="text-right"><el-button type="primary" icon="el-icon-view" @click="viewLiveVideo(item.deviceId)">{{$tc('map.viewLive')}}</el-button></p>
            </l-popup>
            <l-tooltip v-if="item.isShow" :options="showOption" :key="item.key">
              <div class="show-human">
                <span v-if="item.isLoad">loading</span>
                <img v-else :src="item.human.url" alt="">
                <div class="post-deviceName">{{item.deviceName}}</div>
              </div>
            </l-tooltip>
          </l-marker>
        </div>
        <!-- <l-control-zoom class="aurora-zoom" position="bottomright"></l-control-zoom> -->
        <!-- <l-control position="topleft" class="aurora-control"></l-control> -->
      </l-map>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import L from 'leaflet';
import { LMap, LImageOverlay,LTooltip ,LIcon, LMarker, LPopup,LPolyline,LGeoJson,LControl,LControlScale,LControlZoom } from 'vue2-leaflet';
import SelectTree from './SelectTree.vue';
import DeviceSelect from './DeviceSelect.vue';
import { processImgurl } from '@/utils/image.ts';

//热力图模块
import 'leaflet.heat';

import api from '@/api/map';
import api_device from '@/api/device';
import { MapModule } from '@/store/modules/map';
import '@/assets/js/plugins/L.Control.Zoomslider.js';

import debounce from 'lodash';



//地图基础配置
import {drawSetting,markerIcon,localDeviceList} from '@/views/manage/map/mapConfig';

let heatLayer = L.heatLayer([],{
  radius: 50,
  blur:50,
  minOpacity :0.7,
  maxZoom :10,
  //gradient: {0.2: 'blue', 0.25: 'lime', 0.5: 'red'}
});
//console.log(L)
import {Cache} from '@/utils/cache';
import {transport} from '@/utils/image';

const host = window.globalConfig.host;
// const token = Cache.sessionGet("accessToken");

@Component({
  components: {
    LMap, LImageOverlay, LMarker, LPopup,LPolyline,
    LGeoJson,
    LControl,
    LControlScale,
    LControlZoom,
    SelectTree,
    DeviceSelect,
    LTooltip,
    LIcon
  },
})
export default class MonitorMap extends Vue {
  processImgurl:any=processImgurl;
  mydivIcon = L.divIcon({className: 'heat-numbers'});
  noMapData=false
  showParagraph = false
  defaultProps = {
    children: 'children',
    label: 'name',
    value: 'name',
  };
  loading = true
  floorId = "";
  map:any = "";
  crs     = L.CRS.Simple;
  mapOptions= {
    attributionControl: false,
    zoomSnap: false,
    zoomControl: false,
    drawControl: false,
    zoomsliderControl: true,
  };
  mapSet:any = {
    bounds  : [[0,0], [1080, 1920]],
    minZoom : -3,
    maxZoom : 2,
    center  : [540,960],
    zoom    : -1,
    bgUrl   : '/images/floor00.png',
    dataUrl : '/mock/floor0.json',
    reset   : true
  };
  deviceList:any   = [];
  deviceLi:any   = [];
  deviceListId:any=[];
  hasbg = true;
  treeData:any=[];
  selectedOptions:String='';
  postStranger = true;
  heatLayer:any = null;
  timer:any = null;
  totalDevice={}
  nowHuman={}
  showOption = {
    permanent: false,
    interactive: false,
    direction:"top",
    opacity:"0.91"
  }
  showOption2 = {
    permanent: true,
    interactive: true,
    direction:"bottom",
    opacity:"0.91"
  }
  heatData:any=[]
  imgObj = new Image();
  selectTreeKey=0
  searchKey=0

  $refs !:{
    devicePanel:HTMLFormElement,
    elMap:any
  }
  debounce = debounce;
  isDown:boolean=false;
  x:number=0;
  y:number=0;
  l:number=0;
  t:number=0;
  get _heatData() {
    return this.deviceLi;
  }
  @Watch('_heatData', { immediate: true ,deep: false})
  updateHeatData(newVal,oldVal){
    //console.log(newVal,oldVal)
  }

  get _nowHuman() {
    return this.$store.state.monitor.human
  }

  @Watch('_nowHuman', { immediate: true ,deep: false})
  showHumap(newVal,oldVal){

    let _this =this;
    this.showOption.permanent = true;
    if(newVal){
      if(newVal.deviceId && this.deviceListId.includes(newVal.deviceId)){
        //console.log(newVal,oldVal)
        _this.deviceList.map((item,index)=>{
          if((item.deviceId == newVal.deviceId)){
            let imgSrc = processImgurl(`${newVal.url}`);
            this.imgObj.src = imgSrc;
            item.human = newVal;

            // 图片加载成功后把地址给原来的img
            this.imgObj.onload = () => {
              item.human.url = imgSrc;
              item.isShow = true;
              Vue.set(_this.deviceList,index,item);
            }
            setTimeout(()=>{
              item.isShow = false;
              _this.showOption.permanent = false;
            },5000)
          }
        });
      }
    }
  }

  mounted(){
    let _this =this;
    this.map = (this.$refs.elMap as any).mapObject;
    this.treeInit();
    this.getDeviceInfo()
    this.map.addLayer(heatLayer);
    this.$permission.length
  }

  viewLiveVideo(id){
    //console.log(id);
    this.$router.push({ path: 'monitor/video', query: { deviceid: id }})
  }

  treeInit(){
    let _this = this;
    MapModule.TreeList().then((resp:any) => {
      if(resp.data){
        this.treeData = resp.data;
        if(this.treeData[0].children){
          this.selectedOptions = this.treeData[0].children[0].name;
          this.treeData[0].children[0].bgUrl = transport(this.treeData[0].children[0].url)+'v='+new Date()
          this.mapSet = Object.assign(this.mapSet, this.treeData[0].children[0]);
        }else{
          this.selectedOptions = this.treeData[0].name;
          this.treeData[0].bgUrl = transport(this.treeData[0].url)
          this.mapSet = Object.assign(this.mapSet, this.treeData[0]);
        }
        //console.log(this.selectedOptions);
        if(this.treeData[0].id){
          this.hasbg = true;
          this.floorId = this.treeData[0].id;
          if(this.mapSet.bgUrl){
            this.floorId = this.mapSet.id;
            //this.heatMapinit();
          }
        }else{
          this.noMapData = true;
          this.hasbg = false;
        }
      }
    }).then(()=>{
      this.treeSelect(this.mapSet)
      //this.getFloorDeviceList()
    });
  }
  getDeviceInfo(){
    api_device.deviceStatistics({}).then((resp)=>{
      this.totalDevice = resp
    })
  }
  getFloorDeviceList(deviceObj){
    this.deviceList = [];
    api_device.floorDeviceList({id:this.floorId}).then((resp)=>{
      resp.data.map((item,i)=>{
        let deviceIcon = markerIcon.default;
        if(item.accessState =='0'){
          deviceIcon = markerIcon.offLine
        }

        if(item.deviceId == deviceObj.deviceId){
          item.icon = markerIcon.warning
        }else{
          item.icon = markerIcon.default
        }

        if(item.point){
          let pointStr = item.point.substring(1,item.point.length-1);
          let pointArr = pointStr.split(',');
          let newJson = {
            id:item.ID,
            deviceId:item.deviceId,
            deviceType:item.deviceType,
            deviceName:item.deviceName,
            isShow:false,
            icon:item.icon,
            position :{
              lng:pointArr[0],
              lat:pointArr[1],
            }
          }
          this.deviceList.push(newJson)
        }

        this.deviceListId.push(item.deviceId)
      })
    }).then(()=>{
      //console.log(this.deviceList)
    })
  }

  getNodeData(nodeData){
    console.log(nodeData)
    if(nodeData.floorId){
      nodeData.id = nodeData.floorId;
      nodeData.name = nodeData.floorName;
      nodeData.url = '/senseguard-map-management/api/v1/floor/check/'+ nodeData.floorId;
      Vue.set(nodeData,name,nodeData.floorName);
      this.treeSelect(nodeData)
    }
  }

  treeSelect(treeData){
    let _this =this;
    let mapapi = api.getMapData(treeData.id)
    this.mapSet.floorID = treeData.id;
    let timestamp = +new Date();
    this.heatData = [];
    this.loading = true;

    this.mapSet = {
      bgUrl : transport(treeData.url)+'?timestamp='+timestamp,
      bounds  : [[0,0], [1080, 1920]],
      minZoom : -1,
      maxZoom : 2,
      center  : [540,960],
      zoom    : -0.5,
      iconUrl : '/images/icon-camera.png',
      dataUrl : mapapi
    }

    if(!treeData.url){
      this.floorId = treeData.id;
      clearInterval(_this.timer);
      heatLayer.setLatLngs([]);
      this.timer = null;
      this.hasbg = false;
      this.loading = false;
    }else{
      //console.log("加载设备及热力")
      this.heatMapinit()
      this.hasbg = true
      this.floorId = treeData.id;
      this.getFloorDeviceList({deviceId:treeData.deviceId});
    }
    this.selectedOptions = treeData.name;
    if(!treeData.deviceId){
      this.searchKey = +new Date();
    }else{
      setTimeout(()=>{
        _this.selectTreeKey = +new Date();
        //console.log(_this.selectedOptions,treeData.name)
      },400)
    }
    //this.$router.labelModel = treeData.deviceName;
  }

  beforeDestroy (){
    clearInterval(this.timer)
  }

  heatMapinit(){
    let _this = this
    this.loadHeatMap();
    if(!this.timer){
      this.timer = setInterval(()=>{
        _this.loadHeatMap();
      },5000)
    }
  }

  loadHeatMap(){
    let _this = this;
    this.deviceLi = JSON.parse(JSON.stringify(_this.deviceList));
    //console.log(this.deviceLi)
    api.getHeatMap(this.floorId).then((resp:any)=>{

      //模拟数据
      // let deviceInfo_mock = [
      //   {"deviceId":331,"deviceName":"深圳模拟视频","peopleNumber":26,"type":1,"point":[722,720.69]},
      //   {"deviceId":340,"deviceName":"深圳模拟视频","peopleNumber":6,"type":1,"point":[830.02,452.28]},
      // ]
      let deviceInfo = resp.data;
      this.heatData = [];
      if(deviceInfo){
        for(let i=0;i<deviceInfo.length;i++){
          let newPoint = deviceInfo[i].point;
          [newPoint[0],newPoint[1]] = [newPoint[1],newPoint[0]]
          let nowNum:any = (deviceInfo[i].peopleNumber/10000).toFixed(4);
          newPoint.push(nowNum);
          for(let n=0;n<deviceInfo[i].peopleNumber;n++){
            this.heatData.push(newPoint)
          }
          _this.deviceLi.map((item,index)=>{
            if(item.deviceId == deviceInfo[i].deviceId){
              item.heatCount = deviceInfo[i].peopleNumber;
              Vue.set(_this.deviceLi,index,item);
            }
          })
        }
      }
    }).then(()=>{
      setTimeout(()=>{
        _this.loading= false;
      },800)

      //console.log("heatmapData:==",this.heatData.length,this.deviceList)
      heatLayer.setLatLngs(this.heatData);
      //console.log(heatLayer);
    })
  }

  //move panel
  handleMouseDown(e){
    let dv = this.$refs.devicePanel;
    this.x = e.clientX;
    this.y = e.clientY;
    this.l = dv?dv.offsetLeft:0;
    this.t = dv?dv.offsetTop:0;
    this.isDown = true;
    this.$refs.devicePanel && (this.$refs.devicePanel.style.cursor = 'move');
  }
  handleMouseMove(e){
    if (this.isDown == false) {
        return;
    }
    let dv= this.$refs.devicePanel;
    let nx = e.clientX;
    let ny = e.clientY;
    let nl = nx - (this.x - this.l);
    let nt = ny - (this.y - this.t);
    dv && (dv.style.left = nl + 'px');
    dv && (dv.style.top = nt + 'px');
  }
  handleMouseUp(e){
    this.isDown = false;
    this.$refs.devicePanel && (this.$refs.devicePanel.style.cursor = 'default');
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
@import "src/assets/style/leaflet.scss";
.map-header-box{
  padding: 14px 8px;
  font-size: 14px;
  font-weight: bold;
  color: #28354D;
  .iconfont{
    color: #28354D;
  }
  span{
    &::after{
      background: transparent;
    }
  }
}
.text-right{
  text-align: right;
}
.heatmap-numbers{
  color: #011C50;
  font-size: 12px;
  width: 50px;
  text-align: center;
  margin-left: -20px;
  margin-top: -12px;
  -webkit-transition: opacity 2s linear;
  -moz-transition: opacity 2s linear;
  -o-transition: opacity 2s linear;
  transition: opacity 2s linear;
  opacity:0;
  filter:alpha(opacity=0);
}
.fadein {
  opacity: 100;
  filter: alpha(opacity=100);
}
.map_layer{
  //border: 1px dashed rgba(6,77,41,.5);
  height:calc(100% - 46px);
  background-color: #fff;
  position: relative;
  .leaflet-container{
    z-index: 0;
  }
  @include shadowBox();
}
.selectBar{
  position: absolute;
  z-index: 1;
  left: 24px;
  top: 24px;
  .el-checkbox{padding-left: 12px;}
  >*{
    vertical-align: middle
  }
  .select-tree{display: inline-block;}
}

  .map-container{
    position: relative;
    width: 100%;
    height: 100%;
    padding: 16px 0 16px 8px;
    padding-top: 0;
    box-sizing: border-box;
  }
  .device-panel{
    width: 120px;
    border: 1px solid #c2cad8;
    position: absolute;
    left: 32px;
    top:calc(100% - 330px) ;//bottom will cause bug
    background: #fff;
    z-index: 1;
    @include shadowBox();
    overflow: hidden;
  }
  .move-bar{
    min-height: 16px;
    border-bottom: 1px solid #c2cad8;
    background-color: #011C50;
    padding-left:5px;
    font-weight: 600;
    line-height: 16px;
    color: rgba(179,193,210,1);

  }
  .device-panel dl{padding: 8px;margin: 0;}
  .device-panel dl dt{font-size: 14px;font-weight: bold;}
  .device-panel dl dd{
    min-height: 50px;
    line-height: 50px;
    border-bottom:1px solid #c7cedb;
    margin-inline-start: 5px;
    display: flex;
    justify-content:space-between;
    padding-right:30px;
  }
  .device-panel dl dd .iconfont{font-size: 24px;}
  .device-panel dl dd strong{font-size: 32px;padding-left: 8px;}
  .device-panel dl:last-child dd{
    border-bottom:none;
  }
  .show-human{
    padding: 2px;text-align: center;background: #2a5af5;color: #fff;border-radius: 2px;font-size: 12px;
    line-height: 0;
    width: 94px;
    height: 150px;
    line-height: 124px;
    img{
      width: 90px;
      height: 124px;
      display: block;
    }
    .post-deviceName{width: 100%;height: 24px;line-height: 22px; overflow: hidden;text-overflow: ellipsis;font-size: 12px;}
  }
  .show-human:before{
    position: absolute;
    pointer-events: none;
    border: 6px solid transparent;
    background: transparent;
    content: "";
    bottom: 0;
    margin-bottom: -12px;
    border-top-color: #2a5af5;
    left: 50%;
	  margin-left: -6px;
  }
  .device-select{
    position: absolute;
    z-index: 1;
    right: 24px;
    top: 24px;
  }
  .leaflet-clickable{
    color:#011C50;
    font-size:14px;
    width:100px;
    text-align: center;
    box-shadow:none;
    background: transparent;
    padding: 0;
    margin: 0;
    margin-left: -50px;
    &::before{
      content: none;
      border:none;
    }
  }

</style>
