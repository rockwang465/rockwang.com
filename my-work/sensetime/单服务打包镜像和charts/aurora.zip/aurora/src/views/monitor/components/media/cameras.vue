<template>
  <div class="cameras-container">
    <div class="cameras-title">
      <el-form ref="form" v-if="splitScreenModelValue == 1" :inline="true"  :label-width="language === 'en'?'90px':'88px'">
        <el-form-item :label="$tc('liveservice.titleTaskList')+'：'" style="margin-bottom:0">
          <el-select v-model="taskValue" :placeholder="$tc('liveservice.contPleaseSelect')" clearable @clear="taskClear" @change="taskValueChange">
            <el-option
              v-for="itemTask in taskList"
              :key="itemTask.taskId"
              :label="itemTask.taskName"
              :value="itemTask.taskId">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="" style="margin-bottom:0">
          <el-checkbox v-model="isLine"  @change="warningLineChange" v-if="showWarningLineCheckbox" :disabled="isClick || !taskValue">
            <span> <i class="iconfont icon-gaojing_xiantiao" ></i> <span>{{$tc('liveservice.showLine')}}</span> </span>
          </el-checkbox>
          <el-checkbox v-model="lockFace" @change="handleLockFaceCheckChange" v-if="showLockFaceCheck && !isLockLive" :disabled="(splitScreenModelValue>1 || disableLockFace || !currentMediaPlayers[0]) || !taskValue || isLockFaceLoading">
            <span> <i class="iconfont icon-lock-face" ></i> <span>{{$tc('liveservice.lockTarget')}}</span> </span>
          </el-checkbox>
          <el-checkbox v-if="isLockLive" v-model="lockLive"  @change="getLockLive" :disabled="isClick || !taskValue">
            <span> <i class="iconfont icon-hot" ></i> <span>{{$tc('heatMap.seeDiagram')}}</span> </span>
          </el-checkbox>
        </el-form-item>
      </el-form>

    </div>

    <div class="cameras-header" >
      <div>
        <!-- <i class="iconfont icon-device-pes" ></i>  -->
        <span>{{$tc('liveservice.contLiveTitle')}}</span> &nbsp;&nbsp;&nbsp;&nbsp;<span class="cameras-currenttime">{{currentDateTime}}</span>
        <span v-if="showHotspotQuantity && isLockLive"> {{$tc('heatMap.RealtimeNumber')}}:{{hotspotQuantity ?hotspotQuantity : 0}}</span>
      </div>
      <div>
        <!-- <el-checkbox v-model="isLine"  @change="warningLineChange" :disabled="isClick">
          <span> <i class="iconfont icon-gaojing_xiantiao" ></i> <span>{{$tc('liveservice.showLine')}}</span> </span>
        </el-checkbox>
        <el-checkbox v-model="lockFace" @change="handleLockFaceCheckChange" :disabled="splitScreenModelValue>1 || disableLockFace || !currentMediaPlayers[0]">
          <span> <i class="iconfont icon-lock-face" ></i> <span>{{$tc('liveservice.lockTarget')}}</span> </span>
        </el-checkbox> -->
        <span :class="['cameras-modelicon',splitScreenModelValue == 1 ?'cameras-modelicon-active':'']" @click="screenModelChange(1)" >
          <i class="iconfont icon-preview-one" style="font-size:16px;position:relative;top:-1px;" ></i>
        </span>
        <span :class="['cameras-modelicon',splitScreenModelValue == 4 ?'cameras-modelicon-active':'']" @click="screenModelChange(4)">
          <i class="iconfont icon-preview-img" ></i>
        </span>
      </div>

    </div>
    <div class="cameras-contents" ref="cameras">

      <!-- 一屏 splitScreenModelValue==1 -->
      <div class="cameras-items" v-if="splitScreenModelValue==1" :key="1" @mousemove="(e)=>handleMouseMove(e)">
        <el-row style="padding:0px 0;background-color:#000;">
          <el-col :span="24" class="cameras-play-box" ref="cHeight" style="overflow:hidden;" @drop.native="(e)=>drop(e,splitScreenModelValue,0)" @dragover.native.prevent>
              <canvas id="canvas"
                style="position: absolute;
                  z-index:99;
                  left: 50%;
                  transform: translateX(-50%);"
                  :width='width'
                  :height='height'
              ></canvas>
              <MediaPlayer ref="mediaplayer" playerNosourceText="monitor" @loadedmetadata='loadedmetadata' :type="currentMediaPlayers[0] && (currentMediaPlayers[0].deviceType == 2 || currentMediaPlayers[0].deviceType == 4 ) ?'3':mediaPlayerType" :keeperId="currentMediaPlayers[0]?currentMediaPlayers[0].keeperId:''" :name="currentMediaPlayers[0] && currentMediaPlayers[0].name" :parentName="currentMediaPlayers[0] && currentMediaPlayers[0].parentName"
                :url="currentMediaPlayers[0]?(currentMediaPlayers[0].videoPathWithFrame?(currentMediaPlayers[0].videoPathWithFrame):currentMediaPlayers[0].videoPath):''" />
          </el-col>
        </el-row>
        <div class="cameras-items-titlebox" >
          <div style="text-overflow: ellipsis;overflow: hidden;white-space: nowrap;">
            <span class="mediaplayer-green-point" v-show="currentMediaPlayers[0] && currentMediaPlayers[0].name" ></span>
            {{currentMediaPlayers[0] && currentMediaPlayers[0].name}}
          </div>
          <el-button
            v-if="splitScreenModelValue==1 && currentMediaPlayers[0]"
            type="primary"
            @click="fullScreen"
            icon="iconfont icon-fullscreen"
            style="background-color:rgba(25, 137, 250, 1)">{{$tc('liveservice.contEnlargeScreen')}}</el-button>
        </div>
        <div v-if="lockLive && isShowlive" ref="taskHotMap" class="taskHotMap" @mousedown="e=>taskHotMapMouseDown(e)" @mouseup="e=>taskHotMapMouseUp(e)">
             <div class="taskHotMap-title">
               <span>{{$tc('heatMap.CrowdHeatMap')}}</span>
               <i class="el-icon-close" @click="()=>{lockLive =false;taskHotMapLoading= true}"></i>
             </div>
             <div style="" v-loading="taskHotMapLoading">
               <detailHotMap
                 :hotMapList='socketLive[0].headPosition'/>
             </div>
        </div>
      </div>


      <!-- 四屏 splitScreenModelValue==4 -->
      <div class="cameras-items" v-if="splitScreenModelValue==4" :key="2" >
        <el-row style="overflow:hidden;">
          <el-col :span="12" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,0)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[0] && (currentMediaPlayers[0].deviceType == 2 || currentMediaPlayers[0].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[0]?currentMediaPlayers[0].keeperId:''" :name="currentMediaPlayers[0] && currentMediaPlayers[0].name" :parentName="currentMediaPlayers[0] && currentMediaPlayers[0].parentName" :url="currentMediaPlayers[0] && currentMediaPlayers[0].videoPath || ''" />
          </el-col>
          <el-col :span="12" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,1)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[1] && (currentMediaPlayers[1].deviceType == 2 || currentMediaPlayers[1].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[1]?currentMediaPlayers[1].keeperId:''" :name="currentMediaPlayers[1] && currentMediaPlayers[1].name" :parentName="currentMediaPlayers[1] && currentMediaPlayers[1].parentName" :url="currentMediaPlayers[1] && currentMediaPlayers[1].videoPath || ''" />
          </el-col>
          <el-col :span="12" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,2)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[2] && (currentMediaPlayers[2].deviceType == 2 || currentMediaPlayers[2].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[2]?currentMediaPlayers[2].keeperId:''" :name="currentMediaPlayers[2] && currentMediaPlayers[2].name" :parentName="currentMediaPlayers[2] && currentMediaPlayers[2].parentName" :url="currentMediaPlayers[2] && currentMediaPlayers[2].videoPath || ''" />
          </el-col>
          <el-col :span="12" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,3)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[3] && (currentMediaPlayers[3].deviceType == 2 || currentMediaPlayers[3].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[3]?currentMediaPlayers[3].keeperId:''" :name="currentMediaPlayers[3] && currentMediaPlayers[3].name" :parentName="currentMediaPlayers[3] && currentMediaPlayers[3].parentName" :url="currentMediaPlayers[3] && currentMediaPlayers[3].videoPath || ''" />
          </el-col>
        </el-row>
      </div>


      <!-- 八屏 splitScreenModelValue==8 -->
      <div class="cameras-items" v-if="splitScreenModelValue==8" :key="3" >
        <el-row>
          <el-col :span="18" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,0)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[0] && (currentMediaPlayers[0].deviceType == 2 || currentMediaPlayers[0].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[0]?currentMediaPlayers[0].keeperId:''" :name="currentMediaPlayers[0] && currentMediaPlayers[0].name" :url="currentMediaPlayers[0] && currentMediaPlayers[0].videoPath || ''" />
          </el-col>
          <el-col :span="6">
            <el-row>
              <el-col :span="24" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,1)" @dragover.native.prevent>
                <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[1] && (currentMediaPlayers[1].deviceType == 2 || currentMediaPlayers[1].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[1]?currentMediaPlayers[1].keeperId:''" :name="currentMediaPlayers[1] && currentMediaPlayers[1].name" :url="currentMediaPlayers[1] && currentMediaPlayers[1].videoPath || ''" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,2)" @dragover.native.prevent>
                <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[2] && (currentMediaPlayers[2].deviceType == 2 || currentMediaPlayers[2].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[2]?currentMediaPlayers[2].keeperId:''" :name="currentMediaPlayers[2] && currentMediaPlayers[2].name" :url="currentMediaPlayers[2] && currentMediaPlayers[2].videoPath || ''" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,3)" @dragover.native.prevent>
                <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[3] && (currentMediaPlayers[3].deviceType == 2 || currentMediaPlayers[3].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[3]?currentMediaPlayers[3].keeperId:''" :name="currentMediaPlayers[3] && currentMediaPlayers[3].name" :url="currentMediaPlayers[3] && currentMediaPlayers[3].videoPath || ''" />
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,4)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[4] && (currentMediaPlayers[4].deviceType == 2 || currentMediaPlayers[4].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[4]?currentMediaPlayers[4].keeperId:''" :name="currentMediaPlayers[4] && currentMediaPlayers[4].name" :url="currentMediaPlayers[4] && currentMediaPlayers[4].videoPath || ''" />
          </el-col>
          <el-col :span="6" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,5)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[5] && (currentMediaPlayers[5].deviceType == 2 || currentMediaPlayers[5].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[5]?currentMediaPlayers[5].keeperId:''" :name="currentMediaPlayers[5] && currentMediaPlayers[5].name" :url="currentMediaPlayers[5] && currentMediaPlayers[5].videoPath || ''" />
          </el-col>
          <el-col :span="6" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,6)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[6] && (currentMediaPlayers[6].deviceType == 2 || currentMediaPlayers[6].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[6]?currentMediaPlayers[6].keeperId:''" :name="currentMediaPlayers[6] && currentMediaPlayers[6].name" :url="currentMediaPlayers[6] && currentMediaPlayers[6].videoPath || ''" />
          </el-col>
          <el-col :span="6" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,7)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[7] && (currentMediaPlayers[7].deviceType == 2 || currentMediaPlayers[7].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[7]?currentMediaPlayers[7].keeperId:''" :name="currentMediaPlayers[7] && currentMediaPlayers[7].name" :url="currentMediaPlayers[7] && currentMediaPlayers[7].videoPath || ''" />
          </el-col>
        </el-row>
      </div>


      <!-- 九分屏 splitScreenModelValue==9 -->
      <div class="cameras-items" v-if="splitScreenModelValue==9" :key="4" >
        <el-row>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,0)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[0] && (currentMediaPlayers[0].deviceType == 2 || currentMediaPlayers[0].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[0]?currentMediaPlayers[0].keeperId:''" :name="currentMediaPlayers[0] && currentMediaPlayers[0].name" :url="currentMediaPlayers[0] && currentMediaPlayers[0].videoPath || ''" />
          </el-col>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,1)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[1] && (currentMediaPlayers[1].deviceType == 2 || currentMediaPlayers[1].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[1]?currentMediaPlayers[1].keeperId:''" :name="currentMediaPlayers[1] && currentMediaPlayers[1].name" :url="currentMediaPlayers[1] && currentMediaPlayers[1].videoPath || ''" />
          </el-col>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,2)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[2] && (currentMediaPlayers[2].deviceType == 2 || currentMediaPlayers[2].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[2]?currentMediaPlayers[2].keeperId:''" :name="currentMediaPlayers[2] && currentMediaPlayers[2].name" :url="currentMediaPlayers[2] && currentMediaPlayers[2].videoPath || ''" />
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,3)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[3] && (currentMediaPlayers[3].deviceType == 2 || currentMediaPlayers[3].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[3]?currentMediaPlayers[3].keeperId:''" :name="currentMediaPlayers[3] && currentMediaPlayers[3].name" :url="currentMediaPlayers[3] && currentMediaPlayers[3].videoPath || ''" />
          </el-col>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,4)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[4] && (currentMediaPlayers[4].deviceType == 2 || currentMediaPlayers[4].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[4]?currentMediaPlayers[4].keeperId:''" :name="currentMediaPlayers[4] && currentMediaPlayers[4].name" :url="currentMediaPlayers[4] && currentMediaPlayers[4].videoPath || ''" />
          </el-col>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,5)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[5] && (currentMediaPlayers[5].deviceType == 2 || currentMediaPlayers[5].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[5]?currentMediaPlayers[5].keeperId:''" :name="currentMediaPlayers[5] && currentMediaPlayers[5].name" :url="currentMediaPlayers[5] && currentMediaPlayers[5].videoPath || ''" />
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,6)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[6] && (currentMediaPlayers[6].deviceType == 2 || currentMediaPlayers[6].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[6]?currentMediaPlayers[6].keeperId:''" :name="currentMediaPlayers[6] && currentMediaPlayers[6].name" :url="currentMediaPlayers[6] && currentMediaPlayers[6].videoPath || ''" />
          </el-col>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,7)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[7] && (currentMediaPlayers[7].deviceType == 2 || currentMediaPlayers[7].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[7]?currentMediaPlayers[7].keeperId:''" :name="currentMediaPlayers[7] && currentMediaPlayers[7].name" :url="currentMediaPlayers[7] && currentMediaPlayers[7].videoPath || ''" />
          </el-col>
          <el-col :span="8" class="cameras-play-box" @drop.native="(e)=>drop(e,splitScreenModelValue,8)" @dragover.native.prevent>
            <MediaPlayer playerNosourceText="monitor" :type="currentMediaPlayers[8] && (currentMediaPlayers[8].deviceType == 2 || currentMediaPlayers[8].deviceType == 4 ) ?'3':'1'" :keeperId="currentMediaPlayers[8]?currentMediaPlayers[8].keeperId:''" :name="currentMediaPlayers[8] && currentMediaPlayers[8].name" :url="currentMediaPlayers[8] && currentMediaPlayers[8].videoPath || ''" />
          </el-col>
        </el-row>
      </div>

    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import MediaPlayer from '@/components/media-player/index.vue';
import { setInterval } from 'timers';
import {cloneDeep} from 'lodash';
import monitorFetchs from '@/api/monitor';
import {EventBus} from "@/utils/eventbus";
import { AppModule } from '@/store/modules/app';
import detailHotMap from "@/components/detailHotMap/index.vue";
import {getCSTaskDetail} from '@/api/task';
import log from '../../../../api/log';
const config = window.globalConfig;

@Component({
  components: {
    MediaPlayer,
    detailHotMap
  },

})
export default class Cameras extends Vue {
  /* props */


  /* watch */
  @Watch('mediaPlayerType', { immediate: false, deep: false })
  onMediaPlayerTypeChanged(n:string, o:string) {
    if(n == '3'){
      this.disableLockFace = true;
    }else{
      this.disableLockFace = false;
    };
  };
  @Watch('currentMediaPlayers', { immediate: false, deep: true })
  onCurrentMediaPlayersChanged(n:any[], o:any[]) {
    n.length>0 && this.filterCurrentMediaPlayersActive(n);
  };

  get language() {
    return AppModule.language;
  }

  /* data */
  mediaPlayerType= config.monitorVideoFrame?'2':'1';
  lockFace= this.mediaPlayerType == '2'?true:false;
  currentMediaPlayers:any[]=new Array(1);
  currentMediaPlayersActive:any[]=[];
  currentPlayer:any[]=[];
  splitScreenModel=[{id:1,name:'一分屏'},{id:4,name:'四分屏'},{id:8,name:'八分屏'},{id:9,name:'九分屏'}];
  //1:一分屏,4:四分屏,8:八分屏,9:九分屏
  splitScreenModelValue:number=1;
  currentDateTime:string='';
  setIntervalLoopId:any=null;
  disableLockFace:boolean=false;
  treeNodeClickOrder:number=0;
  deviceId = '';
  isLine = false;
  width = '300';
  height='500';
  isClick = true;
  taskValue:any='';
  taskList:any[]=[];
  showWarningLineCheckbox:boolean=true;
  isLockFaceLoading:boolean=false;
  showLockFaceCheck:boolean=true;
  hotspotQuantity = '';
  showHotspotQuantity = false ;
  isLockLive = false;
  lockLive = false;
  isShowlive = false;
  socketLive:any= [{headPosition:''}];
  taskHotMapLoading = true;
  x = 0;
  y = 0;
  l = 0;
  t = 0;
  w = 0;
  h = 0;
  isDown = false;
  /* methods */
  mounted() {
    //play
    EventBus.$on('monitor-camera-treeclick',(data)=>{this.deviceTreeNodeClick(data)});
    EventBus.$on('monitor-map-clickdevice',(data)=>{this.mapDeviceClick(data)});
    EventBus.$on('getDeviceId',(data)=>{
      this.deviceId =  data.id
      // this.hotspotQuantity = '';
      this.clearCanvas()
      this.lockLive = false
      // this.isLine=false
    });
    EventBus.$on('getAlarm',(data)=>{

      if(this.socketLive.length >= 1) {
        this.socketLive.pop()
      }
      if(this.lockLive) {
        this.taskHotMapLoading = false
        this.socketLive.push(data)
      } else {
        this.taskHotMapLoading = true
        this.socketLive = [{headPosition:''}]
      }
      // console.log(data);
      this.hotspotQuantity =data.hotspotQuantity;
    })
    this.getserverTime();

  }
  showTaskList(deviceId){
    this.taskValue = '';
    this.taskList = [];
    deviceId && monitorFetchs.getDisplayWarnLimit(deviceId).then((data :any)=>{
      data && data.displayWarnLimitVoList && (this.taskList = this.formatForTaskList(data.displayWarnLimitVoList));
    }).catch(err=>{}).finally(()=>{this.showWarningLineCheckbox = true;})
  }
  formatForTaskList(list){
    let arr:any[]=[];
    list && list.length>0 && list.map(item=>{
      arr.push({
        taskName:item.taskName,
        taskId:item.taskId,
        taskType:item.taskType
      })
    });
    return arr;
  }
  taskClear(){
    // console.log(this.taskValue)
  }
  taskValueChange(v){
    this.isLine = false;
    this.lockFace = false;
    this.lockLive = false;
    this.showWarningLineCheckbox = (this.getTaskTypeByTaskId(v) == 0 || this.getTaskTypeByTaskId(v) == 1)?false:true;// 0--门禁, 1--布控 ,大于 1 是结构化
    this.isLockLive = this.getTaskTypeByTaskId(v) == 5?true:false; // 5为人群任务
    this.hotspotQuantity = '';
    EventBus.$emit( 'getLockLive', this.taskValue )
    this.warningLineChange();
    this.handleLockFaceCheckChange(false);
  }
  getTaskTypeByTaskId(taskId){
    let task = this.taskList.find(item=>{
      return item.taskId == taskId;
    });
    return task?task.taskType:'';
  }
  setFrame(v){
    if(this.splitScreenModelValue == 1 && this.mediaPlayerType == '2' && v){
      let device =  cloneDeep(this.currentMediaPlayers[0]);
      if(device && device.id){
        // monitorFetchs.getVideoPathWithFrame(device.id).then((res:any)=>{
        this.taskValue && (this.isLockFaceLoading = true) && monitorFetchs.getVideoPathWithFrame(this.taskValue).then((res:any)=>{
          if(res.rtspPreviewAddress){
            this.lockFace = true;
            device['videoPathWithFrame'] = res.rtspPreviewAddress;
            this.currentMediaPlayers.shift();
            this.currentMediaPlayers.push(device);
          }else{
            device['videoPathWithFrame'] = '';
            this.lockFace = false;
            this.showLockFaceCheck = false;
          };
          Vue.set(this.currentMediaPlayers,0,device);
        }).catch((err)=>{
          this.lockFace = false;
          this.showLockFaceCheck = false;
        }).finally(()=>{
          this.isLockFaceLoading = false;
          this.showLockFaceCheck = true;
        })
      }
    }else if(this.splitScreenModelValue == 1 && !v){
      let device =  cloneDeep(this.currentMediaPlayers[0]);
      if(device){
        device['videoPathWithFrame'] = '';
        Vue.set(this.currentMediaPlayers,0,device);
      }
      this.lockFace = false;
    }
  }

  getLockLive(){
    if(this.lockLive) {
      EventBus.$emit( 'getLockLive', this.taskValue )
    }
    let _this = this  as any
    this.isShowlive = false
    getCSTaskDetail(this.taskValue).then((res:any)=>{
      if(res.runStatus == 0) {
        // this.isShowlive = false
        this.lockLive = false
        this.$message({
          showClose: true,
          message: _this.$tc('liveservice.videoOverlay'),
          type: 'error'
        })
      } else {
        this.isShowlive = true
      }
    })

  }

  //点击显示cavas
  warningLineChange() {
    let that = this as any;
    let deviceId = this.deviceId;

    if(!this.isLine) {
      this.clearCanvas()
      return
    }
    // console.log('111111' ,deviceId);
    // deviceId = '134'
    monitorFetchs.getDisplayWarnLimit(deviceId).then((data :any)=>{
      // 没有数据
      if(data.displayWarnLimitVoList && data.displayWarnLimitVoList.length == 0){
        this.isLine = false
        this.lockLive = false
        return this.$message({
          // showClose: true,
          message: that.$t('liveservice.noWarning'),
          type: 'error'
        });

      }

      data.displayWarnLimitVoList.forEach(item => {
        if(this.taskValue && item.taskId && this.taskValue == item.taskId) this.getCanvas(item)
      });
    })
  }

  //清除canvas
  clearCanvas() {
    this.isLine = false;
    if(this.splitScreenModelValue==4) return;
    const canvas = document.getElementById('canvas') as any;
    const ctx = canvas.getContext('2d') ;
    ctx.clearRect(0,0,canvas.width,canvas.height);
  }

  //绘制canvas
  getCanvas(item){
    if(this.splitScreenModelValue==4) return;
      /** @type {HTMLCanvasElement} */
      const canvas = document.getElementById('canvas') as any;
      // this.width = '300';
      // this.height=(this.$refs.mediaplayer as any).defaultHeight;
      // canvas.height = (this.$refs.mediaplayer as any).defaultHeight
      const ctx = canvas.getContext('2d')
      this.$nextTick(()=>{
        item.pointVoList.forEach(val => {
          if(val && val.length == 2){

            ctx.beginPath()
            val.forEach((e) => {
              ctx.lineTo(e.x * canvas.width, e.y * canvas.height)

            });
            ctx.strokeStyle = 'RGB(255,0, 0)'
            ctx.setLineDash([]) // 画实线
            ctx.stroke()
            ctx.closePath()

          }
          if(val && val.length > 2) {
            ctx.beginPath()
            val.forEach((e,index) => {
              ctx.lineTo(e.x * canvas.width, e.y * canvas.height)
              if(index== val.length-1){ //最后一个回到初始点位
                ctx.lineTo(val[0].x * canvas.width, val[0].y * canvas.height)
              }
            });
            ctx.strokeStyle = 'RGB(255, 0, 0)' //填充颜色
            ctx.setLineDash([2,2]) //画虚线
            ctx.fillStyle = 'RGBA(255, 0, 0, .5)' //线颜色
            ctx.fill()
            ctx.stroke()
            ctx.closePath()
          }
      });
      })


  }

  //获取视屏属性
  loadedmetadata(data) {
    // alert(data.path[0])
    this.width =data.target.clientWidth
    this.height =data.target.clientHeight
    this.isClick=false;
    this.showHotspotQuantity = true ;
  }

  screenModelChange(n){
    if(this.splitScreenModelValue == n) return;
    this.splitScreenModelValue = n;
    // if(n>1) this.lockFace = false;
    this.lockFace = false;
    this.isLine = false;
    this.lockLive = false
    this.taskValue = '';
    this.taskList = [];
    this.showHotspotQuantity = false;
    this.currentMediaPlayers = new Array(n);
  }
  //1、drop 2、click devicelist 3、click map device
  drop(e,model,cameraIndex){//1、drop
    if(e && e.dataTransfer){
      let data =JSON.parse(e.dataTransfer.getData("text")) ;
      e.dataTransfer.clearData();
      this.clearCanvas();
      this.lockLive = false
      if(data && data.id){
        (data.deviceType == 2 || data.deviceType == 4) && (data['keeperId'] = data.id);
        this.currentMediaPlayers[cameraIndex] = data;
        this.$set(this.currentMediaPlayers, cameraIndex, data);
        // this.setFrame(this.lockFace);
        this.lockFace = false;
        EventBus.$emit('monitor-alarm-filter',this.getDevicesIdsFromCurrentMediaPlayers());
        this.deviceId = data.id;
        this.showTaskList(data.id);
      }
    }
  }
  deviceTreeNodeClick(data){//2、click devicelist
    if(data && data.id){
      (data.deviceType == 2 || data.deviceType == 4) && (data['keeperId'] = data.id);
      let hasBlank =this.arrayHasBlank(this.currentMediaPlayers);
      if(hasBlank){
        for(let i=0;i<this.currentMediaPlayers.length;i++){
          if(!this.currentMediaPlayers[i]){
            this.currentMediaPlayers[i] = data;
            this.$set(this.currentMediaPlayers, i, data);
            break ;
          }
        }
      }else{
        this.currentMediaPlayers[this.treeNodeClickOrder] = data;
        this.$set(this.currentMediaPlayers, this.treeNodeClickOrder, data);
        this.treeNodeClickOrder = this.treeNodeClickOrder < (this.splitScreenModelValue-1)?this.treeNodeClickOrder+1:0;
      }
      // this.setFrame(this.lockFace);
      this.lockFace = false;
      EventBus.$emit('monitor-alarm-filter',this.getDevicesIdsFromCurrentMediaPlayers());
      this.showTaskList(data.id);
    }
  }
  mapDeviceClick(data){//3、click map device
    if(data && data.id){
      (data.deviceType == 2 || data.deviceType == 4) && (data['keeperId'] = data.id);
      this.currentMediaPlayers[0] = data;
      this.$set(this.currentMediaPlayers, 0, data);
      EventBus.$emit('monitor-alarm-filter',[data.id])
      this.showTaskList(data.id);
    }
  }
  arrayHasBlank(arr){
    for(let i=0;i<arr.length;i++){
      if(!arr[i]){
        return true;
      }
    }
  }
  filterCurrentMediaPlayersActive(n:any[]){
    this.currentMediaPlayersActive=[],this.currentPlayer=[];
    n.map(item=>{
      if(item){
        this.currentPlayer.push(item.id);
        this.currentMediaPlayersActive.push(item);
      }
    });
  }
  getserverTime(){
    let requestStartTime = new Date().getTime();
    monitorFetchs.getServerTime().then((res:any)=>{
      let nowTime = new Date().getTime();
      let diffTime = (nowTime - requestStartTime)/2 + (nowTime - res.millisecond);
      this.setIntervalLoopId = setInterval(()=>{
        this.getNowTime(diffTime)
      },300);
    })
  }
  getNowTime(difftime){
    let dt = new Date(new Date().getTime() - difftime),
    CurrentYear = dt.getFullYear(),
    CurrentMonth =  dt.getMonth() + 1,
    CurrentDay = dt.getDate(),
    CurrentHour = dt.getHours(),
    CurrentMinter = dt.getMinutes(),
    CurrentSeconds = dt.getSeconds(),
    dataArray:any = [CurrentYear, CurrentMonth, CurrentDay, CurrentHour, CurrentMinter, CurrentSeconds];
    for (let i = 0; i<dataArray.length; i++){
      if (dataArray[i] <= 9){dataArray[i] = "0" + dataArray[i]}
    }
    this.currentDateTime = `${dataArray[0]}/${dataArray[1]}/${dataArray[2]} ${dataArray[3]}:${dataArray[4]}:${dataArray[5]}`;
  }
  getDevicesIdsFromCurrentMediaPlayers(){
    let arr:any[]=[];
    this.currentMediaPlayers.map(item=>{
      item.id && arr.push(item.id);
    });
    return arr;
  }
  destroyed() {
    window.clearInterval(this.setIntervalLoopId);
    this.setIntervalLoopId = null;
  }
  handleLockFaceCheckChange(v){
    this.lockFace = false;
    if(v){
      this.mediaPlayerType = '2';
    }else{
      this.mediaPlayerType = '1';
    };
    this.setFrame(v);
  }
  fullScreen(){
    (this.$refs.mediaplayer as any).fullScreen();
  }

  taskHotMapMouseDown(e){
    let dv = this.$refs.taskHotMap as any;
    let wh = this.$refs.cameras as any;
    this.w =wh.clientWidth
    this.h = wh.clientHeight
    // console.log(wh.clientWidth);
    // console.log(wh.clientHeight);

    // console.log('mousedown' , dv);
    this.x = e.clientX;
    this.y = e.clientY;

    //获取左部和顶部的偏移量
    this.l = dv.offsetLeft;
    this.t = dv.offsetTop;
    //设置样式
    dv.style.cursor = 'move';
    this.isDown = true
  }
  taskHotMapMouseUp(e){
    // console.log(e,'mouseup');
    this.isDown = false
    let dv = this.$refs.taskHotMap as any;
    dv.style.cursor = 'default';
  }

  handleMouseMove(e) {
    // console.log(e,'clientWidth');
    if (!this.isDown) {
      return
    }
    let dv = this.$refs.taskHotMap as any;
    var nx = e.clientX;
    var ny = e.clientY;
    //计算移动后的左偏移量和顶部的偏移量
    var nl = nx - (this.x - this.l);
    var nt = ny - (this.y - this.t);

    nl = nl <= 0 ? 0 : (nl >= this.w-474 ? this.w-474:nl);
    nt = nt <= 0 ? 0 : (nt >= this.h-316 ? this.h-316:nt);
    dv.style.left = nl + 'px';
    dv.style.top = nt + 'px';
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .cameras-container{
    width: calc(100% - 270px);
    padding: 16px 0px;
    -webkit-user-select:none;

    .cameras-title{

    }
    .cameras-header{
      background-color: #011c50;
      color: #fff;
      display: flex;
      flex-wrap: nowrap;
      justify-content: space-between;
      padding-left: 10px;
      padding-right: 10px;
      line-height: 40px;
      .cameras-currenttime{
        line-height: 40px;
      }
      .cameras-modelicon{
        cursor: pointer;
        color: #a2b0c7;
        margin-left: 10px;
        i{
          font-size: 20px;
        }
      }
      .cameras-modelicon-active{
        color: $--color-white;
      }
    }
    .cameras-contents{
      padding: 10px;
      background-color: #011c50;
      padding-top: 0;
      position: relative;
      .cameras-items{
        width: 100%;
      }
      .cameras-dragenter-active{
        border: 2px solid red;
      }
      .cameras-items-titlebox{
        padding:16px 0;
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .mediaplayer-green-point{
          display: inline-block;
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background-color: #50cb04;
        }
      }

      .taskHotMap {
        width:474px;
        height:316px;
        position: absolute;
        right:30px;
        bottom: 10px;
        background:rgba(255,255,255,1);
        box-shadow:0px 3px 6px rgba(0,0,0,0.16);
        opacity:1;
        border-radius:4px;
        z-index: 99;
        padding: 0 10px;
        .taskHotMap-title {
          height: 50px;
          line-height: 50px;
          font-size: 16px;
          i {
            // line-height: 50px;
            float:right;
            margin-top: 15px;
            font-weight: 700;;
            cursor: pointer;
            transition: all .5s;

            &:hover {
              transform: rotate(90deg);
            }
          }
        }

      }
    }

  }

  ::v-deep .taskHotMap .canvasHotMap canvas {
    background: #011c50;
  }

  ::v-deep .el-checkbox__label{
    color: #28354d;

  }
  ::v-deep .el-checkbox.is-disabled .el-checkbox__label{
    color: #808896;
  }
  ::v-deep .el-checkbox__input.is-checked .el-checkbox__inner{
    background-color: rgb(25, 137, 250);
  }
  ::v-deep .el-checkbox__input.is-checked+.el-checkbox__label{
    color: rgb(25, 137, 250);
  }
  // ::v-deep .el-checkbox__input.is-checked .el-checkbox__inner{
  //   background-color: #fff;
  //   border-color: #011c50;
  // }
</style>
