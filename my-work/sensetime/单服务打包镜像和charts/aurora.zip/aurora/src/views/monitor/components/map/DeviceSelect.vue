<!-- 树状选择器 -->
<template>
  <div class="deviceSelect">
    <el-autocomplete
      v-model="keywords"
      ref="input"
      :fetch-suggestions="querySearchAsync"
      :placeholder="$t('form.texterrEnterDeviceName')"
      suffix-icon="el-icon-search"
      @select="handleSelect"
      clearable
    >

       <!--<span class="suffix-icon" slot="suffix">-->
         <!--<Icon-->
           <!--v-if="showClose"-->
           <!--type="ele"-->
           <!--size="15"-->
           <!--cursor="pointer"-->
           <!--name="circle-close"-->
           <!--@click="clickClearFilterText"-->
         <!--/>-->
            <!--<Icon-->
              <!--type="ele"-->
              <!--size="15"-->
              <!--cursor="pointer"-->
              <!--name="search"-->
            <!--/>-->
          <!--</span>-->
    </el-autocomplete>
  </div>
</template>

<script lang="js">
  import api_device from '@/api/device';
  import Icon from '@/components/icon-wrap/index.vue';
  export default {
    name: 'DeviceSelect',
    components:{
      Icon
    },
    computed:{
      showClose:function () {
        if (this.keywords.length>0){
          return true;
        } else{
          return false;
        }
      }
    },
    data() {
      return {
        keywords:'',
        copy:'',
        copyData:null,
        // showClose:false
      };
    },
    methods: {
      querySearchAsync(queryString, callback) {
        // debugger
        if (queryString.length == 0){
          // callback([{value:'请输入关键字检索'}])
          callback([])
          return;
        }
        // if (queryString === this.copy){
        //   callback(this.copyData);
        //   return;
        // }

        let params = {
          keyParam:queryString
        }
        api_device.queryDevice(params).then((data) => {
          //console.log(data)
          this.copy = queryString;
          if (data.length<1){
            // callback([{value:'暂无数据'}])
            callback([])
            return;
          }
          for(let i = 0;i < data.length;i++){
            data[i].value = data[i].deviceName;
          }
          this.copyData = data
          callback(data);
        }).catch((err) => {

        });
      },

      handleSelect(item) {
        // console.log(item);
        this.$emit('nodeData',item)
      },
      clickClearFilterText(){
        // this.keywords = '';
        // this.$refs.input.clear();
        console.log(this.$refs.input);
      }
    }
  };
</script>

<style lang="scss" scoped>
  .deviceSelect{
    // ::v-deep .el-input__suffix-inner{
    //   width: 30px;
    //   display: flex;
    //   align-items: center;
    // }
    ::v-deep .el-icon-circle-close{
      position: static!important;
      margin-left: -50px!important;
    }
  }

</style>
