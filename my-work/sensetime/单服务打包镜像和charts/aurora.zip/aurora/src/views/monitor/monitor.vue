<template>
  <el-container class="moitor-layer">
    <el-main class="main" style="padding-right:0;">
      <!-- <Navbar @modelchange="handleModelChange" :model="monitorModel" /> -->
      <transition name="component-fade" mode="out-in">
      <!-- <Media v-if="monitorModel == 'camera'" :treeData="treeData" @changeDeviceType="changeDeviceType" />
      <Map v-if="monitorModel == 'map'"/> -->
        <Media v-if="$route.path == '/monitor'" :treeData="treeData" @changeDeviceType="changeDeviceType" />
        <!-- <Map v-if="$route.path == '/monitor'"/> -->
      </transition>
    </el-main>
    <el-aside class="alarm-aside" width="374px" style="padding-left:0">
      <Alarm :treeData="treeData" />
    </el-aside>

  </el-container>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
// import {Media,Alarm,Navbar,Map} from './components';
import {Media,Alarm,Navbar} from './components';

import api from '@/api/monitor';

@Component({
  components: {
    Media,
    Alarm,
    Navbar,
    // Map
  },
})
export default class Monitor extends Vue {
  /* props */

  /* watch */

  /* data */
  monitorModel:string="map";
  treeData:any[] = [];
  /* methods */
  mounted() {
    this.getDevices();
  }
  handleModelChange(model:string){
    this.monitorModel = model;
  }
  getDevices(deviceType?:null){
    this.treeData=[];
    //所有设备
    api.getDevicesTreeData({filter:0,deviceType}).then(res=>{
      this.treeData = res.data;
    })
  }
  changeDeviceType(type){
    this.getDevices(type);
  }


}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .moitor-layer{
    // background: #fff;
  }
  .monitor-container{
    font-size: $--font-size-base;
    height: 100%;
    width: 100%;
    background-color: $--color-bg-1;
    .monitor-content{
      display: flex;
      flex-wrap: nowrap;
      //justify-content: center;
      height: calc(100% - 48px);
      padding:24px 16px;
      width: 100%;

      .component-fade-enter-active, .component-fade-leave-active {
        transition: opacity .3s ease;
      }
      .component-fade-enter, .component-fade-leave-to{
        opacity: 0;
      }
    }
  }
</style>
