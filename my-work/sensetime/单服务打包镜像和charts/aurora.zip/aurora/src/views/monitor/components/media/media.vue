<template>
  <div class="media-container">
    <Sidebar  :treedata="treeData" :deviceTypeList="deviceTypeList" @changeDeviceType="changeDeviceType" />
    <Cameras  />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import Sidebar from './sidebar.vue';
import Cameras from './cameras.vue';
import {deviceType as deviceTypeList }  from '@/utils/constants';

@Component({
  components: {
    Sidebar,
    Cameras
  },
})
export default class Media extends Vue {
  // deviceId = '';
  /* props */
  @Prop(Array) treeData!: any[];

  /* watch */

  /* data */

  // deviceTypeList:any[]=[{name:'none',id:'0'},{name:'Camera',id:'1'},{name:'Keeper',id:'2'},{name:'SenseDLC',id:'4'}];//1-Camera，2-SenseKeeper,3-SenseDLC
  deviceTypeList:any[] = [];

  /* methods */
  mounted() {
    let de = deviceTypeList.map(item=> {return {name:item.name,id:item.value.toString()}});
    de.unshift({name:this.$tc('liveservice.listNotifyTypeAll'),id:'0'})
    this.deviceTypeList = de;
    // this.deviceTypeList.unshift({name:this.$tc('liveservice.listNotifyTypeAll'),id:'0'})
    // this.deviceTypeList=[{name:this.$tc('liveservice.listNotifyTypeAll'),id:'0'},{name:this.$tc('liveservice.listDeviceTypeCamera'),id:'1'},{name:this.$tc('liveservice.listDeviceTypeKeeper'),id:'2'},{name:this.$tc('liveservice.listDeviceTypeDLC'),id:'4'}];//1-Camera，2-SenseKeeper
  }
  changeDeviceType(type){
    this.$emit('changeDeviceType',type)
  }
  // getDeviceId(data){
  //   // console.log(data);
  //   this.deviceId = data.id
  // }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .media-container{
    //background-color: $--color-bg-1;
    height: calc(100% - 48px);
    border-radius: 15px;
    display: flex;
    flex-wrap: nowrap;
    -webkit-user-select:none;
  }
</style>
