
//An extract of address points from the LINZ bulk extract: http://www.linz.govt.nz/survey-titles/landonline-data/landonline-bde
//Should be this data set: http://data.linz.govt.nz/#/layer/779-nz-street-address-electoral/
var addressPoints = [
  {
    "deviceId":671,
    "peopleNumber":5,
    "type":1,
    "point":[675,345]
  },
  {
    "deviceId":672,
    "peopleNumber":307,
    "type":1,
    "point":[568.7,220.3]
  },
  {
    "deviceId":673,
    "peopleNumber":37,
    "type":1,
    "point":[383.4,156.5]
  },
  {
    "deviceId":674,
    "peopleNumber":37,
    "type":1,
    "point":[741.6,430.1]
  },
  {
    "deviceId":675,
    "peopleNumber":137,
    "type":1,
    "point":[941.6,330.1]
  }
]
export default{
	addressPoints
};
