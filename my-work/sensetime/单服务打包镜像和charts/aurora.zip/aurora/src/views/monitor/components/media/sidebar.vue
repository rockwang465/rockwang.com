<template>
  <div class="sidebar-container">
    <div class="sidebar-header" >
      <el-input
        style="display:block"
        :clearable="true"
        :placeholder="$t('liveservice.validateDeviceName')"
        @keydown.native="keydown"
        @clear="clear"
        v-model="searchModel">
        <i
          class="el-input__icon el-icon-search"
          slot="suffix"
          @click="()=>inputKeywordChange(searchModel)">
        </i>
      </el-input>
      <div class="sidebar-sort">
        <div class="sidebar-sort-title">{{$t('liveservice.contDeviceType')}}</div>
        <el-select v-model="currentDeviceType" size="mini" class="sidebar-sort-type" :placeholder="$t('liveservice.listNotifyTypeAll')" @change="typeChange" >
          <el-option v-for="(deviceType,deviceTypeIndex) in deviceTypeList" :key="deviceTypeIndex" :value="deviceType.id" :label="deviceType.name"></el-option>
        </el-select>
      </div>
    </div>
    <div class="sidebar-contents" >
      <el-tree
        v-if="treedata.length>0"
        ref="deviceTree"
        :data="treedata"
        node-key="id"
        :props="{label:'name'}"
        :render-content='renderTreeContent'
        :filter-node-method="filterNode"
        :indent="0"
        >
      </el-tree>
      <div v-else style="text-align:center;padding-top:30px;">{{$t('liveservice.contNoData')}}</div>
    </div>
  </div>
</template>

<script lang="tsx">
import { Component, Vue ,Prop ,Watch} from 'vue-property-decorator';
import { spawn } from 'child_process';
import { parse } from 'path';
import api from '@/api/monitor';
import {EventBus} from "@/utils/eventbus";

@Component({
  components: {

  },
})
export default class Sidebar extends Vue {

  /* props */
  // @Prop({ default: [] }) treedata!: any[];
  @Prop({ type:Array,default: [] }) deviceTypeList!: any[];


  /* watch */

  /* data */
  $refs!: {
    deviceTree: HTMLFormElement
  };
  currentDeviceType='0';
  searchModel:string='';
  treedata:any[]=[];
  /* methods */
  mounted() {
    this.getDevices();

  }
  getLocationSearchDeviceId(){
    let url_string = location.search;
    let searchParams = new URLSearchParams(url_string);
    return searchParams.get('deviceid') || '';
  }
  dragstart(e,data,node){
    e.dataTransfer.clearData();
    let parentName:string = '';
    if(node.parent && node.parent.data){
      parentName = node.parent.data.name;
    }
    data['parentName'] = parentName;
    let json_str = JSON.stringify(data);
    e.dataTransfer.setData("text/plain", json_str);
  }
  clickTreeNode(data){
    // console.log(data);
    if(data.type == 1){//device
      EventBus.$emit('monitor-camera-treeclick',data)
      EventBus.$emit('getDeviceId',data)
    }
  }
  renderTreeContent(h, { node, data, store }){
    node.isLeaf = data.type == 1;
    let accessState:any = data.accessState;
    return <div draggable={data.type == 1} tabIndex="-2" on-click={(e)=>this.clickTreeNode(data)} on-dragstart={(e)=>this.dragstart(e,data,node)} title={data.name} class={["sidebar-tree-box",node.isLeaf?'sidebar-tree-box-leaf':'sidebar-tree-box-group']} >
            <i class={['sidebar-status-icons',accessState == 1?'sidebar-status-active':'',accessState == 0?'sidebar-status-inactive':'']} ></i>
            <span class="sidebar-tree-text-content">{data.name}</span>
            <i v-show={data.type == 0} class={['el-icon-caret-bottom','sidebar-icon-group']} ></i>
          </div>;
  }
  typeChange(type){
    let deviceType:any = null;
    type == 0 ?(deviceType=null):(deviceType = type);
    // this.$emit('changeDeviceType',deviceType);
    this.getDevices(deviceType);
  }
  inputKeywordChange(val){
    this.$refs.deviceTree.filter(val);
  }
  keydown(e){
    e.keyCode == '13' && this.inputKeywordChange(this.searchModel);
  }
  filterNode(value, data) {
    if (!value || !data.name) return true;
    return data.name.indexOf(value) !== -1;
  }
  clear(){
    this.inputKeywordChange('');
  }
  getDevices(deviceType?:null){
    this.treedata=[];
    //所有设备
    api.getDevicesTreeData({filter:0,deviceType}).then(res=>{
      this.treedata = res.data;
      !deviceType && setTimeout(()=>{
        let deviceId = this.getLocationSearchDeviceId();
        let mapClickDeviceData =  this.$refs.deviceTree && this.$refs.deviceTree.getNode(deviceId)?this.$refs.deviceTree.getNode(deviceId).data:null;
        mapClickDeviceData && EventBus.$emit('monitor-map-clickdevice',mapClickDeviceData);
      },10)

    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .sidebar-container{
    height: 100%;
    width: 246px;
    padding-right: 24px;
    padding-left: 10px;
    .sidebar-header{
      padding-top: 16px;
      padding-bottom: 16px;
    }
    .sidebar-sort{
      margin-top:8px;
      font-size: 14px;
      display:flex;
      justify-content: space-between;
      .sidebar-sort-title{
        display: inline-flex;
        align-items:center ;
      }
      .sidebar-sort-type{
        width: 150px;
      }
    }
    .sidebar-contents{
      // background-color: #fff;
      height: calc(100% - 153px);
      overflow: auto;
      border-radius: 4px;
      padding: 0 4px;
      margin: 0 -8px;
      // border: solid 1px $--border-color-base;
    }
    -webkit-user-select:none;
    //tree
    ::v-deep .el-tree{
      background-color:transparent;

    }
    ::v-deep .el-tree-node__content .el-tree-node__expand-icon{//隐藏自带的icon
      display: none;
    }
    ::v-deep .el-tree-node{
      span.el-tree-node__expand-icon.is-leaf{
        display: none;
      }
      & .sidebar-tree-box-group .el-icon-caret-bottom{
        transition: transform .4s;
      }
      &.is-expanded>.el-tree-node__content>.sidebar-tree-box-group>.el-icon-caret-bottom{
        transform: rotate(180deg);
      }

      // & >.el-tree-node__children[aria-expanded="true"]{
      //   .el-tree-node:first-child>.el-tree-node__content>.sidebar-tree-box-leaf{
      //     // margin-top: -8px;
      //   }
      // }
      .el-tree-node__children{
        margin: 0 4px;
      }
      .el-tree-node__content{

        height: auto;
        &:hover{
          background-color: transparent;
        }
        .sidebar-tree-box-group{
          // background-color:$--color-top;
          // color: $--color-white;
          margin: 0 4px 8px 4px;
          padding-right: 24px;
          position: relative;
          @include shadowBox;
          .sidebar-icon-group{
            position: absolute;
            right: 9px;
            top: 10px;
          }
        }
        .sidebar-tree-box-leaf{
          background-color:$--color-white;
          color: $--color-text-primary;
          border:1px solid rgba(223,223,224,1);
          border-bottom: none;
          border-top: none;
          box-shadow:0px 3px 6px rgba(0,0,0,0.16);
          .sidebar-status-icons{
            margin-right: 4px;
          }
        }
      }
    }
    ::v-deep .el-tree-node.is-expanded>.el-tree-node__children[role="group"]>.el-tree-node:last-child>.el-tree-node__content{
      &>.sidebar-tree-box.sidebar-tree-box-leaf{
        margin-bottom: 8px;
      }
    }
    ::v-deep .el-tree-node .sidebar-tree-box{
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
      width: 100%;
      height: 100%;
      padding: 8px ;

      .sidebar-status-active,.sidebar-status-inactive{
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #50cb04;
        margin-left: 10px;
      }
      .sidebar-status-inactive{
        background-color: #a2b0c7;
      }
      .icon-icon-round-drag{
        font-size:14px;
        color:#b3c1d2;
      }
    }
    // ::v-deep .el-tree-node .sidebar-tree-box-leaf:focus{
    //   background-color: #6d7c96;
    // }
    ::v-deep .el-tree-node.is-current>.el-tree-node__content{
      .sidebar-tree-box-leaf{
        background-color:rgba(242,242,242,1);
        color: $--color-text-primary;
      }

    }
    ::v-deep .el-tree-node.is-expanded.is-current{
      .el-tree-node__content .sidebar-tree-box-group{
        background-color:$--color-top;
        color: $--color-white;
      }

    }
    // ::v-deep .el-tree-node .sidebar-tree-box-leaf{
    //   background-color: #d2dbea;
    //   &:hover{
    //     background-color: #2a5af5;
    //     color: white;
    //   }
    // }
    // el-input
    // ::v-deep .el-input__suffix-inner{
    //   display: flex;
    //   flex-direction: row-reverse;
    //   align-items: center;
    //   .el-input__icon.el-input__clear{
    //     position: static;
    //   }
    // }
  }
</style>
