<template>
  <div class="navbar-container">
    <div :class="['navbar-btn',model == 'map' && 'navbar-btn-active']" @click="changeMonitorModel('map')"> <i class="iconfont icon-map" ></i> {{$t('liveservice.labelMapView')}}</div>
    <div :class="['navbar-btn',model == 'camera' && 'navbar-btn-active']" @click="changeMonitorModel('camera')" > <i class="iconfont icon-pes-view" ></i> {{$t('liveservice.labelLiveView')}}</div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop ,Watch } from 'vue-property-decorator';

@Component({
  components: {

  },
})
export default class Navbar extends Vue {
  /* props */
  @Prop({ default: 'map' }) model!: string;

  /* watch */
  @Watch('$route')
  onRouterChanged(val: any, oldVal: any) {
    if(val.query) {
      this.deviceId = val.query.deviceid;
      this.deviceId && this.changeMonitorModel('camera');
    }
  }
  /* data */
  deviceId:string='';

  /* methods */
  mounted() {
    this.deviceId = this.getLocationSearchDeviceId();
    this.deviceId && this.changeMonitorModel('camera');
  }
  changeMonitorModel(model:string){
    if(model === 'map'){
      this.$router.push('/monitor')
    }
    this.$emit('modelchange',model)
  }
  getLocationSearchDeviceId(){
    let url_string = location.search;
    let searchParams = new URLSearchParams(url_string);
    return searchParams.get('deviceid') || '';
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .navbar-container{
    width: 100%;
    padding-top: 16px;
    background-color:$--color-bg-1;
    display: flex;
    justify-content: flex-start;
    position: relative;
    // border-bottom: 1px solid #2a5af5;
    &::after{
      content: " ";
      width: 100%;
      height: 1px;
      background-image: linear-gradient(270deg, #e5e8ef 0%, $--color-primary 150%);
      position: absolute;
      left: 0;
      bottom: 0;
      z-index: 0;
    }

    .navbar-btn{
      margin-left: 16px;
      padding:0 16px;
      cursor: pointer;
      height: 32px;
      line-height: 32px;
    }
    .navbar-btn:first-child{
      margin-left: 0;
    }
    .navbar-btn-active{
      background-color: $--color-primary;
      color: $--color-white;
      border-radius: 5px 5px 0 0 ;
    }
    .navbar-btn:hover{
      background-color: $--color-primary;
      color: $--color-white;
      border-radius: 5px 5px 0 0 ;
    }
  }
</style>
