<template>
  <div class="alarm-container">
    <div class="alarm-header" >
      <el-popover
        placement="bottom-start"
        :width="language == 'en'?'355':'310'"
        v-model="popoverVisible">
        <div slot="reference" class="alarm-popover-btn" >
          <i class="iconfont icon-portrait-comparison"></i>
          <span>{{$t('liveservice.contAlarmFilter')}}</span>
          <i :class="['el-icon-arrow-down',popoverVisible?'alarm-header-icon-caret':'']" ></i>
        </div>
      <el-row>
        <el-form  :label-width="language == 'en'?'130px':'80px'">
            <el-form-item :label="$t('liveservice.contDeviceFilter')">
              <Select :data="treeData" @ensure="handleEnsureSelected" :checkedKeys="defaultChechedKeys" :placeholder="$tc('liveservice.listNotifyTypeAll')"  />
            </el-form-item>
            <el-form-item :label="$tc('liveservice.contTaskFilter')">
              <Select :data="taskList" @ensure="taskChange" :checkedKeys="ruleModel" :placeholder="$tc('liveservice.listNotifyTypeAll')" />
            </el-form-item>
            <el-form-item :label="$t('liveservice.contNotifyType')">
              <Select :data="compareTypeList" @ensure="compareTypeChange" :checkedKeys="compareType"  listType="list" :placeholder="$tc('liveservice.listNotifyTypeAll')" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="onReset" icon="el-icon-refresh">{{$t('liveservice.contReset')}}</el-button>
              <el-button type="primary" @click="onFilter" icon="el-icon-search">{{$t('liveservice.contSearch')}}</el-button>
            </el-form-item>
          </el-form>
      </el-row>
      </el-popover>
      <router-link tag="a" v-if="$modulePermission(roleModulesCode['retrival'])" to="/retrival" style="margin-left:8px;position: relative;top: 2px;" class="alarm-header-link" >
        <span style="font-size:14px;position: relative;top: -2px;"> <i class="iconfont icon-Journal" ></i> {{$t('liveservice.contMoreRecord')}}</span>
      </router-link>
    </div>
    <div class="alarm-contents" v-if="alarmsList.length>0">
      <transition-group v-if="documentVisibilityState && showAnimation " :name="documentVisibilityState ?'list-complete':''" class="alarm-contents-list" tag="ul">
        <li  v-for="(alarm) in alarmsList" :key="alarm.id" :class="[(!documentVisibilityState && alarm.replace) || !showAnimation?'':'list-complete-item','alarm-contents-items']">
          <!-- 行人/行人越线 -->
          <PedestrianImage
            v-if="alarm.alertType == 1 || alarm.alertType == 10 || alarm.alertType == 11"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
          <!-- 非机动车 -->
          <nonMotorCard
            v-else-if="alarm.alertType == 3"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
          <!-- 车辆违停 -->
          <vehicleImageCard
            v-else-if="alarm.alertType == 20 || alarm.alertType == 2"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
          <!-- 人群 -->
          <crowdRecordCard
            v-else-if="alarm.alertType == 23 || alarm.alertType == 24"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
            <!-- 人脸（ac、td） -->
          <TwoImage
            v-else
            @view-detail="viewAlarmDetail"
            :canOperate="false"
            :cardType="convertCardType(alarm.confirmationStatus)"
            :compareType="alarm.comparedType+''"
            :originImg="alarm.targetImg"
            :targetImg="alarm.showImage?alarm.captureImageUrl:''"
            :percentage="toPercentage(alarm.score)"
            :id="alarm.IDNumber"
            :name="alarm.name"
            :time="alarm.time"
            :item="alarm.recordDetail"
            :device="alarm.device"
            :location="alarm.location" />
        </li>
      </transition-group>
      <!--解决 推送过多 动画及transition修改class 导致页面卡顿 -->
      <ul v-else-if="documentVisibilityState && !showAnimation" class="alarm-contents-list" >
        <li  v-for="(alarm) in alarmsList" :key="alarm.id" :class="['alarm-contents-items']">
          <!-- 行人/行人越线 -->
          <PedestrianImage
            v-if="alarm.alertType == 1 || alarm.alertType == 10 || alarm.alertType == 11"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
          <!-- 非机动车 -->
          <nonMotorCard
            v-else-if="alarm.alertType == 3"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
          <!-- 车辆违停 -->
          <vehicleImageCard
            v-else-if="alarm.alertType == 20 || alarm.alertType == 2"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
          <!-- 人群 -->
          <crowdRecordCard
            v-else-if="alarm.alertType == 23 || alarm.alertType == 24"
            @view-detail="viewAlarmDetail"
            :items="{}"
            :item="alarm" />
            <!-- 人脸（ac、td） -->
          <TwoImage
            v-else
            @view-detail="viewAlarmDetail"
            :canOperate="false"
            :cardType="convertCardType(alarm.confirmationStatus)"
            :compareType="alarm.comparedType+''"
            :originImg="alarm.targetImg"
            :targetImg="alarm.showImage?alarm.captureImageUrl:''"
            :percentage="toPercentage(alarm.score)"
            :id="alarm.IDNumber"
            :name="alarm.name"
            :time="alarm.time"
            :item="alarm.recordDetail"
            :device="alarm.device"
            :location="alarm.location" />
        </li>
      </ul>

    </div>
    <el-dialog
      :title="$t('liveservice.labelDetail')"
      width="95%"
      custom-class="alarm-alarmdetail-dialog"
      :before-close="()=>dialogDetailVisible=false"
      :visible="dialogDetailVisible">
      <div style="width:100%;height:100%;" class="alarm-alarmdetail-content">
        <!-- 行人/行人越线 -->
        <CardDetail
          v-if="comparisonDetail.alertType == 1 || comparisonDetail.alertType ==10 || comparisonDetail.alertType ==11"
          :display="true"
          :data="comparisonDetail" />
        <!-- 非机动车 -->
        <cardParticulars
          v-else-if="comparisonDetail.alertType == 3"
          :display="true"
          :data="comparisonDetail" >
          <template slot="card" slot-scope='{currentCapture}'>
              <div style="">
                <div class="detail">
                  <div class="state" style="background:#1989FA;">{{$t('pedestrian.nonMotorRecords')}}</div>
                  <el-image
                    :src="processImgurl(currentCapture.imgUrl)"
                    fit="contain">
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"
                      style="color: aliceblue;
                      position: absolute;
                      left: 50%;
                      top: 50%;
                      transform: translate(-50%,-50%);"
                      ></i>
                    </div>
                  </el-image>
                <!-- {{currentCapture}} -->
                 <div class="detailText">
                    <ul class="">
                      <li>
                        <div><span>{{$t('pedestrian.title')}}:</span>{{currentCapture.deviceName}}</div>
                      </li>
                      <li>
                        <div><span>{{$t('pedestrian.site')}}:</span>{{currentCapture.placeName}}</div>
                      </li>
                      <li>
                        <div><span>{{$t('pedestrian.time')}}:</span>{{currentCapture.captureTime}}</div></li>
                      <li style="">
                        <div style="line-height: 25px;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            -ms-text-overflow: ellipsis;
            white-space: nowrap;
            display: flex;"><span>{{$t('pedestrian.carType2')}}:</span><p style="border-radius: 4px;min-width: 63px;text-align: center;" :class="currentCapture.color ?currentCapture.color.toLowerCase() : 'white'">{{ $t('pedestrian.'+(currentCapture.type ? currentCapture.type.toLowerCase() : 'no') )}}</p></div>
                      </li>
                    </ul>
                 </div>

                </div>
              </div>
            </template>
          </cardParticulars>
        <!-- 车辆违停 -->
        <cardParticulars
          v-else-if="comparisonDetail.alertType == 20 || comparisonDetail.alertType == 2"
          :display="true"
          :data="comparisonDetail" >
          <template slot="card" slot-scope="{currentCapture}">
            <div style>
              <!-- <img :src="processImgurl(currentCapture.imgUrl)" alt="" srcset=""> -->
              <!-- {{currentCapture}} -->
              <div class="detail">
                <div class="state" :style="bgcStyle">{{$t(i18nCompareType(currentCapture.alertType))}}</div>
                <el-image :src="processImgurl(currentCapture.imgUrl)" fit="contain">
                  <div slot="error" class="image-slot">
                    <i
                      class="el-icon-picture-outline"
                      style="color: aliceblue;
                      position: absolute;
                      left: 50%;
                      top: 50%;
                      transform: translate(-50%,-50%);"
                    ></i>
                  </div>
                </el-image>

                <div class="detailText">
                  <ul :class="['detail-left' ,language == 'en' ? 'isEn' : '' ]">
                    <li>
                      <div>
                        <span>{{$t('pedestrian.carType')}}:</span>
                        <p
                          style="border-radius: 4px;
                                font-size: 14px;
                                text-align: center;"
                          :class="currentCapture.color ?currentCapture.color.toLowerCase() : 'white'"
                        >{{ $t('pedestrian.'+(currentCapture.type ? currentCapture.type.toLowerCase() : 'no') )}}</p>
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.carModel')}}:</span>
                        <el-popover
                          placement="right-start"
                          width="150"
                          trigger="hover"
                          :content="currentCapture.model"
                          :disabled="!currentCapture.model"
                        >
                          <p slot="reference">{{currentCapture.model || $t('pedestrian.no')}}</p>
                        </el-popover>
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.carNum')}}:</span>
                        <p>{{currentCapture.carNum || $t('pedestrian.no')}}</p>
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.stayTimes')}}:</span>
                        <p>{{ toMin(currentCapture.stayTimes) || $t('pedestrian.no')}}</p>
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.carOwner')}}:</span>
                        <p>{{currentCapture.carOwner || $t('pedestrian.no')}}</p>
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.phoneNum')}}:</span>
                        <p>{{currentCapture.phoneNum || $t('pedestrian.no')}}</p>
                      </div>
                    </li>
                  </ul>
                  <ul class="detail-right">
                    <li>
                      <div>
                        <span>{{$t('pedestrian.title')}}:</span>
                        <el-popover
                          placement="right-start"
                          width="150"
                          trigger="hover"
                          :content="currentCapture.deviceName"
                        >
                          <p slot="reference">{{currentCapture.deviceName}}</p>
                        </el-popover>
                        <!-- <p>{{currentCapture.deviceName}}</p> -->
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.site')}}:</span>
                        <el-popover
                          placement="right-start"
                          width="150"
                          trigger="hover"
                          :content="currentCapture.placeName"
                        >
                          <p slot="reference">{{currentCapture.placeName}}</p>
                        </el-popover>
                        <!-- <p>{{currentCapture.placeName}}</p> -->
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.time')}}:</span>
                        <p>{{currentCapture.captureTime}}</p>
                      </div>
                    </li>
                    <li>
                      <div>
                        <span>{{$t('pedestrian.mission')}}:</span>
                        <el-popover
                          placement="right-start"
                          width="150"
                          trigger="hover"
                          :content="(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName ) ? currentCapture.taskInfo.task.taskName :$t('pedestrian.no')"
                          :disabled="!(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName )"
                        >
                          <p slot="reference">{{(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName ) ? currentCapture.taskInfo.task.taskName :$t('pedestrian.no')}}</p>
                        </el-popover>
                        <!-- <p>{{(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName ) ? currentCapture.taskInfo.task.taskName :$t('pedestrian.no')}}</p> -->
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </template>
          </cardParticulars>
         <!-- 人群 -->
        <crowdRetails
          v-else-if="comparisonDetail.alertType == 23 || comparisonDetail.alertType ==24"
          :display="true"
          :data="comparisonDetail">
        </crowdRetails>
        <RecordDetail
          v-else
          :display="dialogDetailVisible"
          :triggerEle="triggerEle"
          :data="comparisonDetail"
          :captureList="captureList"
          @cancel-success="cancelSuccess"
          @cancel-failed="cancelFailed"
          @success="handleSuccess"
          @failed="handleFailed"
          @sort="captureSort"
          @export="exportDetail"
          @slide="viewCaptureMore"
          :totalCapture="totalCapture"
        />
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import TwoImage from '@/components/two-image/index.vue';
import TreeSelect from "@/components/tree-select/index.vue";
import Select from "@/components/select/index.vue";
import { setInterval, setTimeout } from 'timers';
import { Stomp } from "stompjs/lib/stomp.min.js";
// import "@/utils/sockjs.min.js";
import SockJS from "sockjs-client";
import {Cache} from '@/utils/cache';
import { convertCardType,toPercentage } from '@/utils/small-tool';
import api from '@/api/monitor';
import { AppModule } from '@/store/modules/app';
import { MonitorModule } from '@/store/modules/monitor';
import {EventBus} from "@/utils/eventbus";
import {cloneDeep} from 'lodash';
import nonMotorCard from '@/views/retrival/component/image-card/non-motor-card.vue';
import vehicleImageCard from "@/views/retrival/component/image-card/vehicle-card.vue";
import crowdRecordCard from "@/views/retrival/component/image-card/crowdRecord-card.vue";
//detail
import  RecordDetail from '@/views/retrival/history-record/record-detail/index.vue';
import request from '@/api/history-record';
import PedestrianImage from '@/components/pedestrian-image/index.vue';
import CardDetail from '@/views/retrival/component/card-details.vue';
import cardParticulars from '@/views/retrival/component/image-card/cardParticulars.vue';
import crowdRetails from "@/views/retrival//component/allDetails/crowdRetails.vue";
import {taskType} from '@/utils/constants.ts';
//i18n
import i18n from '@/lang/index';
import {alarmCompareTypeList} from '@/utils/constants';
import { processImgurl } from "@/utils/image";
import { toMin } from '@/utils/small-tool';
import {roleModulesCode} from '@/router/moduleCode.ts';
import log from '../../../api/log';
// console.log(cloneDeep)

const tdwsHost = window.globalConfig.tdwsHost;
const wsAlarmListNum =window.globalConfig.wsAlarmListNum;
const alarmCheckFrequency = window.globalConfig.alarmCheckFrequency;
const isCheckPushFrequency = window.globalConfig.isCheckPushFrequency;
const sourceIds = [1,4,7]

interface reqParameterHD{
  sdSort:any,
  timeSort:any,
  targetId:number,
  from?:number,
  to?:number,
  pageSize?:number,
  pageNumber?:number,
}

@Component({
  components: {
    TwoImage,
    TreeSelect,
    RecordDetail,
    Select,
    PedestrianImage,
    CardDetail,
    nonMotorCard,
    vehicleImageCard,
    cardParticulars,
    crowdRecordCard,
    crowdRetails
  },
})
export default class Alarm extends Vue {
  /* props */
  @Prop(Array) treeData!: any[];

  /* watch */

  get language() {
    return AppModule.language;
  }

  toMin = toMin ;

  /* data */
  roleModulesCode:any=roleModulesCode;
  alarmsListSize = wsAlarmListNum;
  defaultChechedKeys:any[]=[];
  compareType:any[]=[];
  compareTypeList:any[]=[];
  ruleModel:any[]=[];
  taskList:any[]=[];
  alarmsList:any[]=[];
  score:number=1;

  socket:any=null;
  socketAC:any=null;
  socketStruct:any=null;
  socketWS:any=null;
  socketClient:any=null;
  socketClientAC:any=null;
  socketClientStruct:any=null;
  socketClientWS:any=null;
  sessionId:string='';
  sessionIdAC:string='';
  sessionIdStruct:string='';
  sessionIdWS:string='';

  sendLiveDeviceIds:any = null;
  sessionIdLive:any = null;
  socketLive:any = null;
  socketClientLive:any = null;



  convertCardType=convertCardType;
  toPercentage = toPercentage;
  get human() {
    return MonitorModule.human;
  }
  //detail
  dialogDetailVisible:boolean=false;
  triggerEle:any=null;
  comparisonDetail={};
  comparisonInfo:any=[];
  captureSize=16;
  captureIndex=1;
  reqParam:reqParameterHD={
    sdSort:null,
    timeSort:0,
    targetId:0,
    pageSize:this.captureSize,
    pageNumber:this.captureIndex,
  };
  maxIndex=1;
  totalCapture=0;
  captureList=[];
  loading=false;
  documentVisibilityState:boolean=true;
  popoverVisible:boolean=false;

  imageReauestArray:any[]=[];
  loopIntervalAlarmIds:any[]=[];
  checkFrequency:number = alarmCheckFrequency as number ;//time check once
  loopCheckIntervalId:any=null;
  timeNumList:any[]=[];
  frequencyNumShowAlert:number=8;
  limtAlertNum:number=1;
  alertNum:number=0;
  canAlert:boolean=true;


  showAnimation:boolean=true;


//cardParticulars  detail code ↓
  bgcStyle = {
    background: ""
  };
  processImgurl = processImgurl;
  i18nCompareType(val) {
    let compareType = "";
    switch (val) {
       case "0":
       compareType = 'pedestrian.unknown';
       this.bgcStyle.background = '#FF9800'
       break;
       case "1":
       compareType="pedestrian.pedestrianRecord"; //$t('pedestrian.search')
       this.bgcStyle.background = '#1989fa'
       break;
       case "2":
       compareType="pedestrian.vehicleRecord";
       this.bgcStyle.background = '#1989fa'
       break;
       case "3":
      //  compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
      //  compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
      //  compareType="records.listNotifyTypeBlacklist";
       break;
       case "10":
       compareType="pedestrian.pedestrianCrossingWarning";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "11":
       compareType="pedestrian.pedestriansInvasion";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "20":
       compareType="pedestrian.parkedVehicles";
       this.bgcStyle.background = '#ED3A33'
       break;
    }
    return compareType;
  }
  /* methods */
  mounted() {
    //init
    this.compareTypeList=alarmCompareTypeList;
    this.connect();
    this.connectWS();
    setTimeout(()=>{
      this.connectAC();
    },100);
    setTimeout(()=>{
      this.connectStruc();
    },200);
    setTimeout(()=>{
      this.connectLive();
    },300);


    api.getTasks([0,1,2,3,4,5]).then((res:any)=>{
      this.taskList = [];
      this.taskList = res && res.taskNameVOList?this.setTaskGroup(res.taskNameVOList):[];
    });

    EventBus.$on('monitor-alarm-filter',(deviceIds)=>{
      this.videoPlayerFilterAlarm(deviceIds)
      this.sendLiveDeviceIds = deviceIds
      // console.log(deviceIds);
      this.sendLive()
    })
    EventBus.$on('getLockLive',(ids)=>{
      // console.log(ids);
      // this.sendLive(data)
      this.sendLive(ids)
    })

    document.addEventListener('visibilitychange',(e)=>{
      this.documentVisibilityState = document.visibilityState == 'visible'?true:false;
    })
  }

  setTaskGroup(list){
    //0–门禁 1–布控 2–区域入侵 3–行人越线 4–车辆违停
    let arr:any[] = [];
    if(list &&  list.length>0){
      taskType.map(ty=>{
        arr.push({
          id:ty.id - ty.id*2,
          name:ty.label,
          children:list.filter(task=>task.type == ty.task_type)
        })
      })
    }
    return arr;
  }

  connect(){
    this.sessionId = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socket = new SockJS(`${tdwsHost}/senseguard-td-result-consume/stomp`,[], {
      sessionId: ()=>{
       return this.sessionId;
      }
    });
    this.socketClient = Stomp.over(this.socket);
    this.socketClient.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    this.socketClient.connect(
      {"userId":userInfo.userId},
      (frame)=> {
        this.socketClient.subscribe(`/queue/${this.sessionId}`,  (res) =>{
          res = JSON.parse(res.body) ;
          if(this.defaultChechedKeys.length == 0 || (this.defaultChechedKeys.length >0 && this.defaultChechedKeys.includes(res.record.deviceId+''))){
            let avatarInfo = {
              url:res.record.url,
              deviceId:res.record.deviceId,
              floorId:res.record.floorId,
              deviceName:res.record.deviceName
            }
            MonitorModule.SetHuman(avatarInfo)

            this.unshiftAlarm(res);
            this.loopCheckImageIsShow();
          }

        });
      },(error)=> {}
    );
  }
  connectAC(){
    this.sessionIdAC = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socketAC = new SockJS(`${tdwsHost}/senseguard-ac-result-consume/stomp`,[], {
      sessionId: ()=>{
       return this.sessionIdAC;
      }
    });
    this.socketClientAC = Stomp.over(this.socketAC);
    this.socketClientAC.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    this.socketClientAC.connect(
      {"userId":userInfo.userId},
      (frame)=> {
        this.socketClientAC.subscribe(`/queue/${this.sessionIdAC}`,  (res) =>{
          res = JSON.parse(res.body);
          if(this.defaultChechedKeys.length == 0 || (this.defaultChechedKeys.length >0 && this.defaultChechedKeys.includes(res.record.deviceId+''))){
            let avatarInfo = {
              url:res.record.url,
              deviceId:res.record.deviceId,
              floorId:res.record.floorId,
              deviceName:res.record.deviceName
            }
            MonitorModule.SetHuman(avatarInfo)

            this.unshiftAlarm(res);
            this.loopCheckImageIsShow();
          }
        });
      },(error)=> {}
    );
  }
  loopCheckImageIsShow(){
    if(!isCheckPushFrequency) return ;
    this.clearIntervalLoopId();
    this.loopCheckIntervalId = window.setInterval(()=>{
      this.alarmsList.map(ala=>{ ala['showImage'] = true;})
    },this.checkFrequency);
  }
  clearIntervalLoopId(){
    if(this.loopCheckIntervalId){
      window.clearInterval(this.loopCheckIntervalId);
      this.loopCheckIntervalId = null;
    };
  }
  handleLoopIntervalAlarmIds(alaId){
    if(this.loopIntervalAlarmIds.length>=this.alarmsListSize){
      this.loopIntervalAlarmIds.splice(this.alarmsListSize-1,1);
    }
    this.loopIntervalAlarmIds.unshift(alaId);
  }
  connectStruc(){//结构化推送
    this.sessionIdStruct = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socketStruct = new SockJS(`${tdwsHost}/senseguard-struct-process-service/websocket`,[], {
      sessionId: ()=>{
       return this.sessionIdStruct;
      }
    });
    this.socketClientStruct = Stomp.over(this.socketStruct);
    this.socketClientStruct.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    this.socketClientStruct.connect(
      {"userId":userInfo.userId},
      (frame)=> {
        this.socketClientStruct.subscribe(`/topic/${this.sessionIdStruct}`,  (res) =>{
          res = JSON.parse(res.body) ;
          this.unshiftAlarm(res)
        });
      },(error)=> {}
    );
  }
  connectLive(){//live推送
    this.sessionIdLive = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socketLive = new SockJS(`${tdwsHost}/senseguard-struct-process-service/live`,[], {
      sessionId: ()=>{
       return this.sessionIdLive;
      }
    });
    this.socketClientLive = Stomp.over(this.socketLive);
    this.socketClientLive.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    this.socketClientLive.connect(
      {"userId":userInfo.userId},
      (frame)=> {
        this.socketClientLive.subscribe(`/live/${this.sessionIdLive}`,  (res) =>{
          res = JSON.parse(res.body) ;
          // console.log(res);
          EventBus.$emit('getAlarm',res)
           });
      },(error)=> {}
    );
  }
  connectWS(){//link  推送
    this.sessionIdWS = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socketWS = new SockJS(`${tdwsHost}/senseguard-message-center/push_data`,[], {
      sessionId: ()=>{
       return this.sessionIdWS;
      }
    });
    this.socketClientWS = Stomp.over(this.socketWS);
    this.socketClientWS.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    this.socketClientWS.connect(
      {"userId":userInfo.userId ,sourceIds},
      (frame)=> {
        this.socketClientWS.subscribe(`/push_data_topic/${this.sessionIdWS}`,  (res) =>{
          res = JSON.parse(res.body) ;
          res = this.formatLinkData(res.data);
          this.unshiftAlarm(res);
          this.loopCheckImageIsShow();
        });
      },(error)=> {}
    );
  }

  sendLive(ids?) {
    this.canAlert = true;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    let data:any = {} ;
    data.userId = userId;
    data.sessionId = this.sessionIdLive;
    // data.taskIds = d ;
    ids ? data.taskIds = [ids] : null;
    this.sendLiveDeviceIds ? data.deviceIds = this.sendLiveDeviceIds : null ;
    // console.log(data.deviceIds);

    const requestBody = JSON.stringify(data);
    // console.log(requestBody);

    this.socketClientLive.send(`/app/filter_condition_struct_live`,{},requestBody);
  }

  videoPlayerFilterAlarm(deviceIds){
    this.defaultChechedKeys = [];
    deviceIds && deviceIds.length>0 && deviceIds.forEach(i=>{ i && !this.defaultChechedKeys.some(c=>c == i) && this.defaultChechedKeys.push(i)})
    this.sendmsg();
  }
  handleEnsureSelected(keys){
    this.defaultChechedKeys = [];
    keys && keys.length>0 && keys.map(i=>{ i && this.defaultChechedKeys.push(i)})
  }

  formatLinkData(res){
    let data:any={};
    // record
    data['record']={
    // 记录序列号
		"serialNumber": res.serialNumber,
		// 跟踪状态 0=ONGOING;1=END;2=START;-1=UNRECOGNIZED
		"eventNum": res.trackEvent?res.trackEvent.eventNum:'',
		// 跟踪描述
		"eventDescriptor": res.trackEvent?res.trackEvent.descriptor:'',
		// 记录确认状态
		"confirmationStatus": res.confirmationInfo.confirmationStatus,
		// 设备id
		"deviceId": res.deviceInfo.device.deviceId,
		// 设备名称
    "deviceName": res.deviceInfo.device.deviceName,
    // "deviceName":res.deviceInfo.device.subDevice &&  res.deviceInfo.device.subDevice.deviceName ? res.deviceInfo.device.subDevice.deviceName : res.deviceInfo.device.deviceName,
		// 抓拍小图
		"url": res.detectInfo.faceInfo.portraitImageInfo.url,
		// 楼层id
		"floorId": res.deviceInfo.device.floorId,
		// 识别分数
		"score": res.detectInfo.score,
		// 人像底库图
		"picUrl": res.targetInfo?res.targetInfo.targetImage.picUrl:'',
		// 识别比对类型 0=MATCH;1=STRANGER;2=NON_BODY_DETECT;3=PASSWD_ERROR;4=INACTIVE;5=TRACK_END;6=OUT_OF_TIMEZONE;7=ONLY_HAVE_BADGE;
		// 8=NO_DEVICE_PERMISSIONS;-1=UNRECOGNIZED
		"comparedType": res.comparedType,
		// 人员姓名
		"name": res.targetInfo?res.targetInfo.target.name:'',
		// 人员身份ID
		"identity": res.targetInfo?res.targetInfo.target.identity:'',
		// 抓拍大图
		"imageUrl": res.detectInfo.image?res.detectInfo.image.url:'',
		// 抓拍时间
		"captureDate": res.detectInfo.captureDate
    };
    data['recordDetail']={
      //体温检测
      "tempInfo":res.detectInfo.tempInfo,
      // 第一次抓拍时间
      "preCaptureDate": res.preCaptureDate,
      // 记录序列号
      "serialNumber": res.serialNumber||'',
      // 人员id
      "targetId": res.targetInfo?res.targetInfo.target.targetId:'',
      // 抓拍人脸属性
      "faceAttributeInfo": {
        // 疆藏
        "ethicCode": "",
        // 胡子
        "mustacheStyle": "",
        // 表情
        "expression": "",
        // 性别
        "gender": "",
        // 年龄
        "ageValue": "",
        // 肤色
        "skinColor": "",
        // 口罩颜色
        "respiratorColor": res.detectInfo.faceInfo && res.detectInfo.faceInfo.attribute?res.detectInfo.faceInfo.attribute.respirator_color:'',
        // 帽子
        "capStyle": "",
        // 年龄分类
        "age": "",
        // 眼镜
        "glassesStyle": ""
      },
      // 记录确认状态
      "confirmationStatus": res.confirmationInfo.confirmationStatus,
      // 跟踪id
      "trackId": res.detectInfo.faceInfo.trackId,
      // objectId
      "objectId": res.objectId||'',
      // 比对类型描述
      "description": res.description,
      // 人员姓名
      "userName": res.targetInfo?res.targetInfo.target.name:'',
      // 操作人姓名
      "operatorName": res.confirmationInfo.operatorInfo.name,
      // 抓拍背景图对象
      "bigPicture": {
        // 抓拍背景图(大图)
        "imgUrl": res.detectInfo.image.url,
        // 宽
        "width": res.detectInfo.image.width,
        // 人脸坐标
        "portraitImageCoordinateInfo": {
          // 终点Y坐标
          "endY": res.detectInfo.faceInfo.end.y,
          // 终点X坐标
          "endX": res.detectInfo.faceInfo.end.x,
          // 起点Y坐标
          "startY": res.detectInfo.faceInfo.start.y,
          // 起点X坐标
          "startX": res.detectInfo.faceInfo.start.x
        },
        // 高
        "height": res.detectInfo.image.height
      },
      // 抓拍小图
      "url": res.detectInfo.faceInfo.portraitImageInfo.url,
      // 人像底库图
      "picUrl": res.targetInfo?res.targetInfo.targetImage.picUrl:'',
      // 识别分数
      "score": res.detectInfo.score,
      // 识别比对类型 0=MATCH;1=STRANGER;2=NON_BODY_DETECT;3=PASSWD_ERROR;4=INACTIVE;5=TRACK_END;6=OUT_OF_TIMEZONE;7=ONLY_HAVE_BADGE;
      // 8=NO_DEVICE_PERMISSIONS;-1=UNRECOGNIZED
      "compareType": res.comparedType,
      // 规则名称
      "ruleName": res.taskInfo?res.taskInfo.taskName:'',
      // 任务id
      "taskId": res.taskInfo?res.taskInfo.taskId:'',
      // 任务名称
      "taskName":  res.taskInfo && res.taskInfo.task?res.taskInfo.task.taskName:'',
      // 人像库名称
      "targetLibraryName": res.targetInfo?res.targetInfo.library.name:'',
      // 抓拍时间
      "captureDate": res.detectInfo.captureDate,
      // 人员身份ID
      "id": res.targetInfo?res.targetInfo.target.identity:'',
      // 设备名称
      "place": res.deviceInfo.device.deviceName,
      // 设备信息
      "devicePlaceInfo": {
        // 楼层id
        "floorId": res.deviceInfo.device.floorId,
        // 设备名称
        "name": res.deviceInfo.device.deviceName,
        // 设备id
        "id": res.deviceInfo.device.deviceId,
        // 设备ID
        "deviceCode": res.deviceInfo.device.deviceCode,
        // 设备在楼层的位置
        "position": {
          // 经度
          "lng": parselocation(res.deviceInfo.device.point).lng,
          // 纬度
          "lat": parselocation(res.deviceInfo.device.point).lat
        },
        // 楼层地图url
        "url": res.deviceInfo.device.url
      },
      //子设备name
      'deviceInfo':{
        "device":{
          "subDevice" :res.deviceInfo.device.subDevice ?{
            "deviceName":res.deviceInfo.device.subDevice.deviceName ? res.deviceInfo.device.subDevice.deviceName :null
          } : null
        }
      }
    };
    function parselocation(point){
      let p = point?JSON.parse(point):'';
      if(p){
        return {lng:p[0],lat:p[1]};
      } else{
        return {lng:'',lat:''};
      }
    }

    return data;
  }

  unshiftAlarm(alarm:any){
    // EventBus.$emit('getAlarm',alarm)
    this.timeNumChangeList();//计数
    if(alarm.alertType){//struct  行人：1 ；非机动车：3；行人越线：10 ；行人区域入侵事件：11； 机动车违停事件：20；
      let ala = cloneDeep(alarm);
      ala['id'] =new Date().getTime() + '' + Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,5);
      ala.attributes =  ala.attributes ||[];
      if(this.alarmsList.length>=this.alarmsListSize){
        this.alarmsList.splice(this.alarmsListSize-1,1);
      }
      this.alarmsList.unshift(ala);

    }else{//ac、td push
      //replace same trackId
      // if(alarm && alarm.recordDetail && alarm.recordDetail.trackId){
      //   let isReplace = this.alarmsList.some(item=>
      //   (item.recordDetail
      //   && item.recordDetail.trackId
      //   && item.recordDetail.trackId == alarm.recordDetail.trackId
      //   && item.recordDetail.objectId == alarm.recordDetail.objectId
      //   && item.recordDetail.taskId == alarm.recordDetail.taskId));
      //   if(isReplace){
      //     this.replaceSameAlarm(alarm);
      //     return false;
      //   }
      // };
      // let ala_id = alarm.recordDetail.trackId+''+alarm.deviceId;
      let ala= {
        showImage:isCheckPushFrequency?false:true,
        captureImageUrl:alarm.record.url,
        targetImg:alarm.record.picUrl,
        score:alarm.record.score,
        id:alarm.record.serialNumber+Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,5),
        // id:alarm.recordDetail.trackId,
        replace:false,
        confirmationStatus:alarm.record.confirmationStatus,
        time:alarm.record.captureDate,
        location:alarm.record.deviceName||'',
        IDNumber:alarm.record.identity||'',
        name:alarm.record.name||'',
        comparedType:alarm.record.comparedType,
        recordDetail:alarm.recordDetail,
        device:alarm.recordDetail.devicePlaceInfo.name,
        deviceInfo:alarm.deviceInfo
        // deviceInfo:alarm.recordDetail.deviceInfo
      };
      this.handleLoopIntervalAlarmIds(ala.id);//handle loopIntervalAlarmIds
      if(this.alarmsList.length>=this.alarmsListSize){
        this.alarmsList.splice(this.alarmsListSize-1,1);
      }
      this.alarmsList.unshift(ala);
    }

  }
  replaceSameAlarm(currentAlarm){//replace same trackId capture
    currentAlarm.recordDetail
    && currentAlarm.recordDetail.trackId
    && currentAlarm.recordDetail.objectId
    && currentAlarm.recordDetail.taskId
    && this.alarmsList.map((item,itenIndex)=>{
      if(item.recordDetail
        && item.recordDetail.trackId
        && item.recordDetail.trackId == currentAlarm.recordDetail.trackId
        && item.recordDetail.objectId == currentAlarm.recordDetail.objectId
        && item.recordDetail.taskId == currentAlarm.recordDetail.taskId
      ){
        let alarm_ = {
          showImage:false,//替换直接显示
          captureImageUrl:currentAlarm.record.url,
          targetImg:currentAlarm.record.picUrl,
          score:currentAlarm.record.score,
          replace:true,
          id:item.id,
          // id:currentAlarm.record.serialNumber+Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,5),
          // id:item.recordDetail.trackId,
          confirmationStatus:currentAlarm.record.confirmationStatus,
          time:currentAlarm.record.captureDate,
          location:currentAlarm.record.deviceName||'',
          IDNumber:currentAlarm.record.identity||'',
          name:currentAlarm.record.name||'',
          comparedType:currentAlarm.record.comparedType,
          recordDetail:currentAlarm.recordDetail,
          device:currentAlarm.recordDetail.devicePlaceInfo.name
        };
        item = alarm_;
        this.loopIntervalAlarmIds[itenIndex] = alarm_.id;//handle loopIntervalAlarmIds
        this.$set(this.alarmsList,itenIndex,alarm_);
      }
    });
  }
  timeNumChangeList(){
    let now_time = new Date().getTime();
    this.timeNumList.push(now_time);
    let frequency = this.timeNumList,timeDiffSum=0;
    frequency.length > 2 && frequency.map((time,timeIndex)=>{
      if(frequency[timeIndex - 1]){
        timeDiffSum += (time - frequency[timeIndex - 1]);
      }
    });
    if(timeDiffSum >= 1000){//到一秒
      let frequencyNum = frequency.length;//每秒推送数量
      this.showAnimation = frequencyNum<15;
      if(frequencyNum > this.frequencyNumShowAlert ){
        // if(this.alertNum >= this.limtAlertNum && !this.canAlert) return ;
        // this.alertNum++;
        // this.$message({
        //   showClose: true,
        //   message: this.$tc('liveservice.alalmFastAlert'),
        //   type: 'warning'
        // });
        // if(this.alertNum >= this.limtAlertNum) this.canAlert = false;
        this.alertLimit()
      }
      this.timeNumList = [];//置空
    }

  }
  alertLimit(){
    if(this.alertNum >= this.limtAlertNum && !this.canAlert) return ;
    this.alertNum++;
    this.$message({
      showClose: true,
      message: this.$tc('liveservice.alalmFastAlert'),
      type: 'warning'
    });
    if(this.alertNum >= this.limtAlertNum) this.canAlert = false;
  }
  onReset(){
    this.defaultChechedKeys = [];
    this.ruleModel = [];
    this.compareType = [];
    this.sendmsg();
    this.popoverVisible = false;
  }
  onFilter(){
    this.sendmsg();
    this.popoverVisible = false;
  }
  sendmsg() {
    this.canAlert = true;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    const requestBody = JSON.stringify({
      sessionId:this.sessionId,
      deviceIds:this.defaultChechedKeys,
      compareTypes:this.filterCompareTypeForDifferrntTask('actd'),
      taskIds:this.ruleModel,
      userId
    });
    const requestBodyAC =JSON.stringify({
      sessionId:this.sessionIdAC,
      deviceIds:this.defaultChechedKeys,
      compareTypes:this.filterCompareTypeForDifferrntTask('actd'),
      taskIds:this.ruleModel,
      userId
    });
    const requestBodyStruct =JSON.stringify({
      sessionId:this.sessionIdStruct,
      deviceIds:this.defaultChechedKeys,
      taskIds:this.ruleModel,
      taskTypes:this.filterCompareTypeForDifferrntTask('struct'),
      userId
    });
    const requestBodyWS =JSON.stringify({
      sessionId:this.sessionIdWS,
      deviceIds:this.defaultChechedKeys,
      taskIds:this.ruleModel,
      taskTypes:this.filterCompareTypeForDifferrntTask('link'),
      userId,
      sourceIds
    });
    this.socketClient.send(`/app/filter_condition`,{},requestBody);
    this.socketClientAC.send(`/app/filter_condition_ac`,{},requestBodyAC);
    this.socketClientStruct.send(`/app/filter_condition_struct`,{},requestBodyStruct);
    this.socketClientWS.send(`/app/setting_push_filter`,{},requestBodyWS)
  }
  filterCompareTypeForDifferrntTask(type:string){
    let arr:any[] = [];
    this.compareType.length>0 && this.compareType.forEach((item:string)=>{
      // item && item.indexOf(type) >= 0 && arr.push(item.split('#')[1]);
      item && JSON.parse(item)[type] && arr.push(JSON.parse(item)[type]);
    });
    this.compareType.length>0 && this.compareType.every(i=>i.indexOf(type) < 0) && arr.push('9999999');//屏蔽选中类型以外的推送
    return arr;
  }
  getTypesId(typeStr){
    typeStr && (JSON.parse(typeStr))
  }
  taskChange(data){
    this.ruleModel = data;
  }
  compareTypeChange(data){
    this.compareType = data;
  }
  destroyed() {
    // this.socket.close();
    // this.socketAC.close();
    // this.socketStruct.close();
    this.socketLive && this.socketLive.close();
    this.socket && this.socket.close();
    this.socketAC && this.socketAC.close();
    this.socketStruct && this.socketStruct.close();
    this.clearIntervalLoopId();
    this.timeNumList = [];
  }
  //查看详情
  viewAlarmDetail(data,e){
    this.dialogDetailVisible = true;
    this.triggerEle=e;
    //当前展开
    data.items.showCompareDetail = true;
    data.item.isFocus = true;
    this.comparisonDetail = data.item
    this.reqParam["targetId"]=data.item.targetId || null;
    this.reqParam && this.fetchRecordDetail(this.reqParam) //获取抓拍
    if(data.item.confirmationStatus===0){ //如果未查看，修改为查看状态
      this.cancelSuccess(data.item)
    }
  }
  //获取详情抓拍列表
  fetchRecordDetail(param){
    this.maxIndex=1; //重置滑动参数
    this.reqParam.pageSize=this.captureSize; //重置滑动参数
    this.reqParam.pageNumber = this.captureIndex; //重置滑动参数
    request.fetchRecordDetail(param).then((data)=>{
      this.totalCapture = data.data.totalNumber || 0;
      this.captureList = data.data.baseVOList || [];
    }).catch(()=>{
        this.captureList=[]
    })
  }
  //取消比中状态
  cancelSuccess(param){
    this.comfirmCompareStatus(param,1)
  }
  //更新操作状态
  comfirmCompareStatus(item,status){
    //匹配列表中的serialnumber,更新相应的状态
    let serialNumber = item.serialNumber;
    this.loading=true
    let param = {id:item.serialNumber,confirmationStatus:status}
    request.checkCompareStatus(param).then(()=>{
      item.confirmationStatus = status;
      this.loading=false
    },(err)=>{
      this.loading=false
    })
  }
  //取消未比中状态
  cancelFailed(param){
    this.comfirmCompareStatus(param,1)
  }
  //点击比中
  handleSuccess(param){
    this.comfirmCompareStatus(param,2)
  }
  //点击未比中
  handleFailed(param){
    this.comfirmCompareStatus(param,3)
  }
  // 获取详情的抓拍
  captureSort(param){
    this.reqParam["sdSort"]= param.similaritySort
    this.reqParam["timeSort"]= param.timeSort
    this.fetchRecordDetail(this.reqParam)
  }
  exportDetail(start,end){
    var param:any={}
     param.from = start,
     param.to = end,
     param.sdSort = this.reqParam.sdSort,
     param.timeSort = this.reqParam.timeSort,
     param.targetId = this.reqParam.targetId,
     param.userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";
     request.exportHistoryDetail(param).then(()=>{
       this.$message({
         showClose: true,
          message: this.$t("log.exportSuccess") as string,
          type: 'success',
          duration: 3 * 1000,
       });
     })
  }
  //滑动加载更多
  viewCaptureMore(index){
    let pageNumber= index+1
    if(this.maxIndex<pageNumber){
      this.maxIndex=pageNumber
      this.reqParam.pageSize=(this.captureSize as number)/2;
      this.reqParam.pageNumber = this.maxIndex+1
      request.fetchRecordDetail(this.reqParam).then((data)=>{

          this.captureList = Array.prototype.concat.apply(this.captureList,data.data.baseVOList || []) as any;
      }).catch(()=>{
          // this.captureList=[]
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .alarm-container{
    width: 100%;
    // background-color:#F0F2F5;
    height: 100%;
    -webkit-user-select:none;
    padding: 8px 0 0px 0px;
    .alarm-header{
      padding: 8px 28px 12px 0px;
      font-size: 14px;
      //border-bottom: 1px solid #8e99aa;
      display: flex;
      justify-content: space-between;
      .alarm-header-link{
        line-height: 32px;
      }
      .side-title{
        padding-left: 0;
        padding-top: 60px;
        padding-bottom:16px;
        // font-size: 14px;
      }
      .alarm-title{
        padding-top: 20px;
        padding-bottom: 10px;
      }
      .alarm-records,.alarm-type{
        padding: 0px 0;
      }
      .alarm-select-type{
        width: 160px;
        top: 8px;
        ::v-deep .el-select__tags-text{
          color: #606266;
        }
      }
      .alarm-select-type.language-en{
        width: 140px;
      }

      .alarm-select-rules{
        width: 235px;
        top: 8px;
      }
      .alarm-select-rules.language-en{
        width: 195px;
      }
      .alarm-popover-btn{
        //display: inline-block;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 7px 8px;
        background-color: #fff;
        border:1px solid $--color-primary;
        border-radius:4px;
        box-sizing: border-box;
        cursor: pointer;
        .icon-portrait-comparison{
          margin-right: 4px;
          color: #A2B0C7;
        }
        span{
          color: #A2B0C7;
        }
        .el-icon-arrow-down{
          margin-left: 64px;
          transition: transform .4s;
        }
        .alarm-header-icon-caret{
          transform: rotate(180deg);
        }
      }
    }
    .alarm-contents{
      height: calc(100% - 64px);
      .alarm-contents-list{
        height: 100%;
        padding-top:4px;
        overflow-y: auto;
        overflow-x: hidden;
      }
      .alarm-contents-items{
        width: 362px;
        height: 202px;
        margin-bottom: 9px;
        padding-left:0px;
      }
      .list-complete-item {
        transition: transform .3s;
      }
      .list-complete-enter{
        opacity: 0;
        transform: translateX(-130px);
      }
      .list-complete-leave-to{
         opacity: 0;
        transform: translateX(130px);
      }
    }
  }
  .alarm-alarmdetail-dialog .alarm-alarmdetail-content .record-detail{
    background-color: $--color-white;
    color: $--color-text-primary;
    height: 640px;
    padding-bottom: 48px;
  }

  //detail start
::v-deep .alarm-alarmdetail-dialog{
    // max-width: 1440px;
  }
::v-deep .sort-container span.order{
      color: $--color-text-primary;
  }
::v-deep .sort-container .can-click.invert-order{
      color: $--color-text-primary;
  }
::v-deep .el-input__icon.close-tab.el-icon-close{
    display: none;
  }
::v-deep .big-img-fullscreen .el-input__icon.close-tab.el-icon-close{
    display: block;
    color: $--color-white;
  }
::v-deep .single-image-container.img-container .percentage{
    background-color: $--color-reserved-5;
  }
::v-deep  .alarm-alarmdetail-dialog .record-detail .detail-container .detail-list .record-detail-top .record-detail-title {
    & > span {
      color: $--color-text-primary;
      &>span{
        color: $--color-text-primary;
      }
    }

  }
::v-deep  .alarm-alarmdetail-dialog .detail-item p span{
  word-break: normal;
}
  //detail end

::v-deep .el-select__tags .el-tag{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    .el-select__tags-text{
      max-width: 60px;
      overflow: hidden;
      white-space:nowrap;
      text-overflow:ellipsis ;
    }
  }
::v-deep .alarm-select-rules.language-en .el-select__tags .el-tag .el-select__tags-text{
    max-width: 40px;
  }
::v-deep .alarm-select-type.language-en .el-select__tags .el-tag .el-select__tags-text{
    max-width: 40px;
  }
  .el-form-item{
    margin-bottom: 0;
    // .el-tag.el-tag--info {
    //   color: #28354d;
    // }

  }
  .treeselsect-container{
    height: 55px;
  }
  ::v-deep .el-select__tags .el-tag .el-select__tags-text{
    color: #28354d;
  }
  ::v-deep .detail-container .textCompare {
    color:#28354d;
  }

  ::v-deep .current-compare {
    // height: 92%;
  }




  //------------

  .list-img {
    min-height: 600px;
  }
  .block .el-pagination {
    margin: 0 auto;
    width: 50%;
    text-align: center;
  }

  .detail {
    display: inline-block;
    width: 408px;
    height: 528px;
    background-color: #fff;
    border-radius: 4px 0px 0px 4px;
    .state {
      width: 100%;
      height: 32px;
      border-radius: 4px 0px 0px 0px;
      text-align: center;
      line-height: 32px;
      color: #fff;
    }
    .el-image {
      width: 227.9px;
      height: 320px;
      // border:1px solid rgba(112,112,112,1);
      position: relative;
      left: 50%;
      transform: translateX(-50%);
      margin-top: 20px;
      // background-color: #011c50;
      border: 1px dashed #CDE1FD;
      background-color: #DFEAFC;
    }

    .detailText {
      margin-top: 5px;
      display: flex;
      line-height: 24px;

      .detail-left {
        width: 50%;
        // flex: 1;
        // display: block;
        padding-left: 20px;
        li {
          // width: 50%;
          div {
            width: 100%;
            display: flex;

            span {
              min-width: 35%;
              text-align: right;
              font-size: 14px;
              font-family: Source Han Sans CN;
              font-weight: bold;
              // line-height:14px;
              color: rgba(40, 53, 77, 1);
              margin-right: 10px;
            }

            p {
              // width: 100%;
              // border-radius: 4px;
              min-width: 63px;
              // text-align: center;
              overflow: hidden;
              text-overflow: ellipsis;
              -ms-text-overflow: ellipsis;
              white-space: nowrap;
              font-weight: 400;
              text-align: left;
            }
          }
        }

        &.isEn {
          padding-left: 0px;
          li div {
            span:first-child{
              min-width: 51%;
            }
          }
        }
      }
      .detail-right {
        width: 50%;
        // flex: 1;
        padding-left: 10px;

        li {
          div {
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            -ms-text-overflow: ellipsis;
            white-space: nowrap;
            display: flex;
            span {
              // min-width: 35%;
              text-align: right;
              font-size: 14px;
              font-family: Source Han Sans CN;
              font-weight: bold;
              // line-height:14px;
              color: rgba(40, 53, 77, 1);
              margin-right: 10px;
              display: grid;
            }
            p {
              // width: 100%;
              // border-radius: 4px;
              // min-width: 63px;
              // text-align: center;
              font-weight: 400;
              overflow: hidden;
              text-overflow: ellipsis;
              -ms-text-overflow: ellipsis;
              white-space: nowrap;
              // text-align: left;
            }
          }
        }
      }
    }
  }

  .batch-export {
    position: absolute;
    right: 35px;
    top: 11px;
  }

.condition-detail-all {
  display: flex;
  .condition-detail-item {
    display: flex;
    .label {
      padding-right: 3px;
      padding-left: 10px;
      // display: inline-block;
      line-height: 32px;
      white-space: nowrap;
    }

  }
}


  ::v-deep .el-dialog.alarm-alarmdetail-dialog .auroraUI .el-dialog .el-dialog__body{
    display: block;
  }
  ::v-deep .el-dialog.alarm-alarmdetail-dialog .el-dialog__body{
    max-height: 734px;
    .record-detail{
      border: none;
    }
  }

</style>
