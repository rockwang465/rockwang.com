export { default as Media } from './media/media.vue';
export { default as Alarm } from './alarm.vue';
export { default as Navbar } from './navbar.vue';
// export { default as Map } from './map/index.vue'; //模块内部有css没有scoped 易引起全局css变化导致其他模块受影响