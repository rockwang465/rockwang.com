<template>
<div class="detail-side">
  <el-card class="detail-side-info" shadow="never" v-if="staffInfo.staffInfoVo">
    <el-image class="image" :src="staffInfo.staffInfoVo.img" fit="cover">
      <div slot="placeholder" class="image-slot">
        <span class="dot">loading...</span>
      </div>
      <div slot="error" class="image-slot">
        <!-- <i class="el-icon-picture-outline"></i> -->
        <img src="/images/user-01.png" alt="">
      </div>
    </el-image>
    <div class="user-info">
      <dl>
        <dt>{{$t('attendance.name')}}</dt>
        <dd>{{staffInfo.staffInfoVo.name}}</dd>
      </dl>
      <dl>
        <dt>No.</dt>
        <dd>{{staffInfo.staffInfoVo.identity}}</dd>
      </dl>
      <dl>
        <dt>{{$t('attendance.department')}}</dt>
        <dd>{{staffInfo.staffInfoVo.dept}}</dd>
      </dl>
    </div>
  </el-card>
  <div v-else class="no-data">
    <p>{{$t('attendance.noData')}}</p>
  </div>
  <div class="statistics">
    <h3>{{$t('attendance.detail.attendanceStatistics')}}</h3>
    <el-tabs class="aurora-card-tabs" v-model="activeName" type="card" @tab-click="handleClick">
      <el-tab-pane :label="$t('attendance.thisMonth')" name="first">
        <div v-if="staffInfo.currentMonth" class="month-data">
          <dl>
            <dt>{{$t('attendance.detail.normalAttendance')}}</dt>
            <dd>{{staffInfo.currentMonth.normalNum}}{{$t('attendance.unitDay')}}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.attendanceRate')}}</dt>
            <dd class="w40">{{staffInfo.currentMonth.attendanceRatio}}%</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.lateTimes')}}</dt>
            <dd>{{staffInfo.currentMonth.lateNum}}{{$t('attendance.unitTimes')}}</dd>
          </dl>
          <dl>
            <dt :title="$t('attendance.detail.accumulativeLateTime')">{{$t('attendance.detail.accumulativeLateTime')}}</dt>
            <dd>{{staffInfo.currentMonth.totalLateMinutes | toFloor}}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.leaveDays')}}</dt>
            <dd>{{staffInfo.currentMonth.totalLeaveDays}}{{$t('attendance.unitDay')}}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.absenceDays')}}</dt>
            <dd>{{staffInfo.currentMonth.totalAbsenceDays}}{{$t('attendance.unitDay')}}</dd>
          </dl>
        </div>
      </el-tab-pane>
      <el-tab-pane :label="$t('attendance.lastMonth')" name="second">
        <div v-if="staffInfo.preMonth" class="month-data">
          <dl>
            <dt>{{$t('attendance.detail.normalAttendance')}}</dt>
            <dd>{{staffInfo.preMonth.normalNum}}{{$t('attendance.unitDay')}}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.attendanceRate')}}</dt>
            <dd>{{staffInfo.preMonth.attendanceRatio}}%</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.lateTimes')}}</dt>
            <dd>{{staffInfo.preMonth.lateNum}}{{$t('attendance.unitTimes')}}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.detail.accumulativeLateTime')}}</dt>
            <dd>{{ staffInfo.preMonth.totalLateMinutes | toFloor }}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.leaveDays')}}</dt>
            <dd>{{staffInfo.preMonth.totalLeaveDays}}{{$t('attendance.unitDay')}}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.absenceDays')}}</dt>
            <dd>{{staffInfo.preMonth.totalAbsenceDays}}{{$t('attendance.unitDay')}}</dd>
          </dl>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator'

import Api from '@/api/attendance';
import { processImgurl } from '@/utils/image';
import {EventBus} from '@/utils/eventbus';

@Component({
  components: {
    //,
  },
  filters: {
    toFloor: (value:string)=> {
      let totleTime = Math.floor(Number(value))
      if(totleTime > 60){
        return Math.floor(totleTime/60)+"h "+(totleTime%60)+"mins"
      }else{
        return totleTime+"mins"
      }
    }
  }
})
export default class AttendanceDetailSide extends Vue {
  activeName='first';
  routeQuery:any={};
  staffInfo:any={}

  mounted(){
    this.routeQuery = this.$route.query;
    this.getAttendanceStaffInfo();
  }
  handleClick(){

  }

  getAttendanceStaffInfo(){
    // let params = {
    //   targetId: this.routeQuery.targetId,
    //   identity: this.routeQuery.identity //'liqitian'
    // }
    Api.attendanceStaffInfo(this.routeQuery).then((resp:any)=>{
      //console.log("左侧：员工-月考勤统计",resp,resp.staffInfoVo.img);
      resp.staffInfoVo.img = processImgurl(resp.staffInfoVo.img)
      this.staffInfo = resp;
      EventBus.$emit('attendance-name',resp);
    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.detail-side{
  @include shadowBox();
  border-top: 2px solid #2A5AF5;
  background: #F5F7FC;
  padding: 8px;
  height: calc(100% - 24px);
  .el-card{border: none;}
  .statistics{
    h3{padding-left:8px; }
  }
  .no-data{min-height: 200px;}
  dt{
    font-weight: bold;
    word-break:keep-all;
    white-space:nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  dd{margin: 0;}
  .detail-side-info{
    background: #F5F7FC;
    .el-card__body{
      padding: 8px;
      display: flex;
      .user-info{
        align-self:flex-end;
        flex:1;
      }
      dl{

        padding-left: 8px;
        dt{
          width: 100px;
        }
        dd{
          flex: 1;
          word-wrap:break-word;
          word-break:break-all;
        }

      }
      .image{
        width: 168px;
        height: 224px;
      }
    }

  }
  .month-data{
    padding:0 8px;
    min-height: 300px;
    dl{
      display: flex;
      .w40{
        width: 150px;
      }
      dt,dd{display: inline-block;vertical-align: middle}
      dt{
        width: 140px;
      }
      dd{
        flex: 1;
      }
    }
  }
}

</style>

