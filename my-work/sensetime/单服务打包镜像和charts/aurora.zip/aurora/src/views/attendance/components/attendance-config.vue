<template>
  <div>
  <el-dialog
    :title="$t('attendance.titleHomePage')"
    :visible.sync="dialogShowVisible"
    :append-to-body="true"
    width="30%">
    <el-form ref="form" v-if="dialogShowVisible" label-position="right" :model="form" style="margin: 30px 0;width: 90%" :label-width="formLabelWidth">
      <!--时间条件-->
      <el-form-item :label="$t('attendance.timezone')" >
        <el-select v-model="form.timeChoose" style="width: 100%;" :placeholder="$t('visitor.visitorlist.tipsPSelect')">
          <el-option
            v-for="item in timezoneList"
            :key="item.timeZoneId"
            :label="item.timeZoneName"
            :value="item.timeZoneId">
          </el-option>
        </el-select>
        <div class="tips"><span @click="()=>{showTimezoneDialog = true}">{{$t('attendance.alert.configureTime')}}</span></div>
        <div style="position: absolute;top: 0;right: -20px;">
          <el-popover
            placement="bottom-start"
            width="271"
            trigger="hover">
            <div class="content">
              {{$t('attendance.alert.configTips1')}}
            </div>
            <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
          </el-popover>
        </div>
      </el-form-item>
      <!--考勤设备-->
      <el-form-item :label="$t('attendance.attendanceDevice')" >
        <DeviceTreeSelect style="width: 100%;" size="small" :data="deviceTreeData"
                    @selected="deviceHandleSelected"
                    show-checkbox
                    :dataObj="deviceDataUserIdsObj"/>
        <div style="position: absolute;top: 0;right: -20px;">
          <el-popover
            placement="bottom-start"
            width="271"
            trigger="hover">
            <div class="content">
              {{$t('attendance.alert.configTips2')}}
            </div>
            <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
          </el-popover>
        </div>
      </el-form-item>
      <!--人像库-->
      <el-form-item :label="$t('attendance.alert.portraitDatabase')" >
          <TreeSelect size="small" :data="treeData"
                      @selected="handleSelected"
                      show-checkbox
                      style="width: 100%;"
                      :libraryName="true"
                      :dataObj="dataUserIdsObj"/>
      </el-form-item>
      <!--生效时间-->
      <el-form-item :label="$t('attendance.implementedTime')" >
        <el-date-picker
          v-model="form.time"
          type="date"
          value-format="yyyy-MM-dd"
          :picker-options="pickerOptions"
          :placeholder="$t('visitor.visitorlist.tipsPSelect')">
        </el-date-picker>
        <div style="position: absolute;top: 0;right: -20px;">
          <el-popover
            placement="bottom-start"
            width="271"
            trigger="hover">
            <div class="content">
              {{$t('attendance.alert.configTips3')}}
            </div>
            <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
          </el-popover>
        </div>
      </el-form-item>
    </el-form>
    <!--配置时间条件-->
    <!--<div class="tips" v-if="step == 0">{{$t('attendance.alert.configTips1')}}<span @click="()=>{showTimezoneDialog = true}">{{$t('attendance.alert.configureTime')}}</span></div>-->
    <!--<div class="tips" v-if="step == 1">{{$t('attendance.alert.configTips2')}}</div>-->
    <!--<div class="tips" v-if="step == 2">{{$t('attendance.alert.configTips3')}}</div>-->
    <span slot="footer" class="dialog-footer">

      <!--上一步-->
      <!--<el-button type="info" @click="back()" v-show="step!=0">{{$t('attendance.alert.prev')}}</el-button>-->
      <!--下一步-->
      <!--<el-button type="primary" @click="next()" v-show="step!=2">{{$t('attendance.alert.btnNext')}}</el-button>-->
      <!--确定-->
      <el-button type="primary" @click="next()"  :loading="btnLoading">{{$t('attendance.alert.confirm')}}</el-button>
      <!--取 消-->
      <el-button type="info" @click="close()">{{$t('attendance.alert.btnCancel')}}</el-button>
    </span>
  </el-dialog>
    <el-dialog
      :title="$t('attendance.titleHomePage')"
      :visible.sync="showTimezoneDialog"
      :append-to-body="true"
      @close="()=>{this.getTimezoneList()}"
      width="95%"
    >
      <Timezone style="height:570px"></Timezone>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import DeviceTreeSelect from "@/components/userDeviceAdd/index.vue";
  import TreeSelect from "@/components/portraitDeviceAdd/index.vue";
  // import Timezone from '@/views/manage/rule/subview/dialog/timezone.vue';
  import Timezone from '@/views/manage/timezone/timezone.vue';
  import {getTimezone} from '@/api/rule';
  import {DeviceModule} from '@/store/modules/device';
  import {PortraitModule} from '@/store/modules/portrait';
  import {AppModule} from '@/store/modules/app';
  import Api from '@/api/attendance';
  import {EventBus} from '@/utils/eventbus';
  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    },
    components:{
      DeviceTreeSelect,
      TreeSelect,
      Timezone
    },
    computed:{
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '220px' : '80px';
      },
      titleList:function(){
        let that = this as any;
        let list1 = ['考勤配置 1/3 选择考勤时间','考勤配置 2/3 考勤设备&人像库','考勤配置 3/3 选择考勤时间']as any;
        let list2 = [(that.$t('attendance.titleHomePage') + ' 1/3 ' + that.$t('attendance.alert.titleAttendanceTime')),
          (that.$t('attendance.titleHomePage') + ' 2/3 ' + that.$t('attendance.alert.configDAndP')),
          (that.$t('attendance.titleHomePage') + ' 3/3 ' + that.$t('attendance.alert.selectAttendanceTime'))
        ];
        return that.language == 'en' ? list2 : list1;
      }
    }
  })
  export default class AttendanceConfig extends Vue {
    get language() {
      return AppModule.language;
    }
    pickerOptions= {
        disabledDate(time) {
        return time.getTime() < (Date.now()-24*60*60*1000);
      }
    }
    dialogShowVisible = false;
    showTimezoneDialog = false;
    btnLoading = false;
    step = 0;//步骤
    form = {
      timeChoose:'',
      deviceList:'',
      libraryList:'',
      time:''
    } as any;
    id=null;
    // titleList=['考勤配置 1/3 选择考勤时间','考勤配置 2/3 考勤设备&人像库','考勤配置 3/3 选择考勤时间']as any;
    timezoneList = [] as any;

    deviceTreeData = [] as any;//设备
    deviceDataUserIdsObj = {
      userIds: [],
      defaultIds: []
    } as any;//设备

    treeData = [{
      id: 1,
      libraryName: '白名单',
      children: []
    }] as any;//人像
    dataUserIdsObj = {
      userIds: [],
      defaultIds: []
    } as any;//人像


    @Prop(Object) data!:any;


    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeConfig")
        this.step = 0;
        this.close();
      }else{
        if (this.data){
          let val = this.data;
          this.id = val.id
          this.form.timeChoose = val.timeZoneId;
          this.form.deviceList=val.deviceIdArr;
          this.form.libraryList=val.targetLibIdArr;
          // this.form.time = val.activateTime;
          this.deviceDataUserIdsObj = {
            userIds: val.deviceIdArr,
            defaultIds: val.deviceIdArr
          } as any;//设备
          this.dataUserIdsObj = {
            userIds: val.targetLibIdArr,
            defaultIds: val.targetLibIdArr
          } as any;//人像
        }
      }
    }
    @Watch('language')
    onLanguageChange(val: any) {
      this.initGroupTree();
      this.searchPorpLibraries();
    }
    @Watch('step')
    onStepChange(val: any) {
      this.btnLoading = false;
    }
    @Watch('data')
    onDataChange(val: any) {
      if (val){
        this.id = val.id
        this.form.timeChoose = val.timeZoneId;
        this.form.deviceList=val.deviceIdArr;
        this.form.libraryList=val.targetLibIdArr;
        // this.form.time = val.activateTime;
        this.deviceDataUserIdsObj = {
          userIds: val.deviceIdArr,
          defaultIds: val.deviceIdArr
        } as any;//设备
        this.dataUserIdsObj = {
          userIds: val.targetLibIdArr,
          defaultIds: val.targetLibIdArr
        } as any;//人像
      }
    }

    created(){
      this.getTimezoneList();
      this.initGroupTree();
      this.searchPorpLibraries();
    }
    close(){
      this.dialogShowVisible = false;
      this.btnLoading = false;
      this.step = 0;
      this.id = null;
      this.form = {
        timeChoose:'',
        deviceList:'',
        libraryList:'',
        time:''
      } as any;
      this.deviceDataUserIdsObj = {
        userIds: [],
        defaultIds: []
      } as any;//设备
      this.dataUserIdsObj = {
        userIds: [],
        defaultIds: []
      } as any;//人像
    }
    back(){
      this.step--;
    }
    next(){
      let that = this as any;
      if (!this.form.timeChoose){
        this.$message.error({showClose: true,message:that.$tc('form.texterrSelectTimezone')});
        return;
      }

      if (this.form.deviceList.length==0){
        this.$message.error({showClose: true,message:that.$t('devicemanagement.chooseDevice')});
        return;
      }
      if (this.form.libraryList.length==0){
        this.$message.error({showClose: true,message:that.$t('form.texterrSelectImageLib')});
        return;
      }
      if (!this.form.time){
        this.$message.error({showClose: true,message:that.$tc('form.texterrSelectTimezone3')});
        return;
      }

        this.btnLoading = true;

        let params = {
          activateTime: this.form.time,
          deviceIdArr: this.form.deviceList,
          targetLibIdArr: this.form.libraryList,
          threshold: 0.95,
          timeZoneId: this.form.timeChoose,
          // id:this.id?this.id:null
          // timeZoneName: "考勤设置"
        };
        Api.attendanceConfig(params).then((res)=>{
          console.log(res);
          this.$message({
            showClose: true,
            message:that.$t('globaltip.tipAttendanceConfig'),
            type: 'success'
          })
          this.$emit('initList')
          EventBus.$emit('getModificationTime')
          this.close();
        }).catch(err=>{
          console.log(err);
          this.close();
        })


    }

    getTimezoneList(){//初始化时间选择选项
      getTimezone().then((res:any)=>{
        this.timezoneList = [];
        setTimeout(()=>{res.data && res.data.length>0 && (this.timezoneList = res.data)},50)
      });
    }

    //初始化设备树
    initGroupTree() {
      let that = this as any;
      //由于deviceType此处与后端约定，当deviceType参数为5时，请求所得的数据是除senseID以外的所有设备。
      DeviceModule.getDevicesTree({'deviceType':5,'filter':1 }).then((data: any) => {
        that.deviceTreeData = data.data;
      }).catch((err) => {
        console.log(err)
      });
    }

    //初始化人像库树
    searchPorpLibraries(){
      let that = this as any;
      let params = {} as any;
      PortraitModule.SearchLibraries(params).then((data: any) => {
        if(data != null && data.whitelists != null) {
          for (let i = 0; i < data.whitelists.length; i++) {
            data.whitelists[i].libraryType = 1
          }
        }

        //console.log('searchPorpLibraries',data)
        this.treeData[0].children = data.whitelists;
        this.treeData[0].libraryName = that.$t('imagemanagement.contWhiltelist');
      }).catch((err) => {
        //报错

      });
    }

    handleSelected(obj) {
      //console.log(obj);
      this.form.libraryList = obj.userIds;
      this.dataUserIdsObj = obj;
    }
    deviceHandleSelected(obj) {
      //console.log(obj);
      this.form.deviceList = obj.userIds;
      this.deviceDataUserIdsObj = obj;
    }

  }





</script>

<style scoped lang="scss">
.tips{
  /*display: flex;*/
  >span{
    display: block;
    /*float: right;*/
    color: #2A5AF5;
    text-decoration:underline;
    cursor: pointer;
  }
}
  .content{
    white-space: normal;
    word-break: break-all;
  }
</style>
