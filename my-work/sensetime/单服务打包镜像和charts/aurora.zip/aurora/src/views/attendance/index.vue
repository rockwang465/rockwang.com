<template>
<div class="attendance" v-loading="isLoad">
  <!--顶部统计-->
  <platform-overview></platform-overview>
  <!-- 子路由 -->
  <!-- <transition v-show="!isLoad" name="fade-transform" mode="out-in"></transition> -->
  <!-- TODO: 考勤路由列表缓存及详情清除缓存设置 -->
  <keep-alive include="AttendanceList" exclude="AttendanceDetail,e,a">
    <router-view></router-view>
  </keep-alive>

  <AttendanceConfig :dialogVisible="isConfigShow" @closeConfig="closeConfig"></AttendanceConfig>
  <AttendanceExport :dialogVisible="isExportShow" @closeExport="closeExport" :isCompany="true" :code="'123'" :title="title"></AttendanceExport>
  <!--（timeFlag：考勤时段标识,0:上午,1:下午）-->
  <AttendanceChangeState :dialogVisible="isChangeStateShow" :id="'1'" :timeFlag="0" @closeChangeState="closeChangeState"></AttendanceChangeState>
  <NowAttendanceConfig :dialogVisible="isNowConfig" @closeConfig="closeNowConfig"></NowAttendanceConfig>
</div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import { Route } from 'vue-router';
import Api from '@/api/attendance';
import PlatformOverview from './components/platform-overview.vue';
import AttendanceExport from './components/attendance-export.vue';
import AttendanceConfig from './components/attendance-config.vue';
import AttendanceChangeState from './components/attendance-changestate.vue';
import NowAttendanceConfig from "./components/now-attendance-config.vue";

var url = window.globalConfig.login;

@Component({
  components: {
    PlatformOverview,
    AttendanceExport,
    AttendanceConfig,
    AttendanceChangeState,
    NowAttendanceConfig,
  }
})
export default class Attendance extends Vue {
  redirect: string | undefined = undefined;
  keyId:any="";
  dialogVisible = false;
  isConfigShow = false;//考勤配置
  isChangeStateShow = false;//变更考勤状态
  isNowConfig = false;//目前考勤配置查看
  isExportShow = false;//导出
  form={
    carNumber:''
  };
  title='';
  listConfig = null as any;
  isLoad = false;
  // get cachedViews() {
  //   return TagsViewModule.cachedViews
  // }

  @Watch('$route', { immediate: true })
  OnRouteChange(route: Route) {
    //console.log(route)
    this.redirect = route.query && route.query.redirect as string;
    let str = this.$route.path;
    if (str === '/attendance/list'){
      this.getListConfig();
    }
  }
  created(){
    //console.log(this.$route)
    // let str = this.$route.path;
    // if (str === '/attendance/list'){
    //   this.getListConfig();
    // }
  }
  mounted(){
    //do
//console.log(this.cachedViews)
  }
activated(e) {
  console.log('激活')
}
deactivated(){
  console.log('去活')
}
  getListConfig(){

    this.isLoad = true;
    let params = {
      pageNum:1,
      pageSize:2
    };
    Api.attendanceListConfig(params).then(res=>{
      this.listConfig = (res as any).list;
      //console.log("路由----",this.listConfig)
      if (this.listConfig.length>1){//有两条配置，证明第一条配置为已生效
        // this.$router.push({ path:'/attendance/list'})
      }else if (this.listConfig.length == 1) {
        let config = this.listConfig[0];
        let activateTime = config.activateTime + ' ' + '00:00:00';
        var d = new Date(activateTime);
        var curDate = new Date();
        //console.log(curDate<d,d,curDate,this.$router)
        if (curDate<d){//第一条配置待生效
          this.$router.push({ path:'/attendance/homePage'})
        } else{//第一条配置已生效
          // this.$router.push({ path:'/attendance/list'})
        }
        // else{//第一条配置已生效
        //   this.$router.push({ name: 'list', path:'/attendance/list'})
        // }
      }else if (this.listConfig.length == 0){//还未配置考勤
        this.$router.push({ path:'/attendance/homePage'})
      }
      this.isLoad = false;
    }).catch(err=>{
      this.isLoad = false;
      console.log(err);
    })
  }

  showConfig(){
    this.isConfigShow = true;
  }
  closeConfig(){
    console.log('closeConfig')
    this.isConfigShow = false;
  }

  showExport(){
    this.isExportShow = true;
  }
  closeExport(){
    this.isExportShow = false;
  }

  showChangeState(){
    this.isChangeStateShow = true;
  }
  closeChangeState(){
    this.isChangeStateShow = false;
  }

  showNowConfig(){
    this.isNowConfig = true;
  }
  closeNowConfig(){
    console.log('closeConfig')
    this.isNowConfig = false;
  }

  doSomeThing(){

  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.attendance{padding: 16px;
height: 100%;
.el-container{
  padding: 24px 0;
  margin: 0 -8px;
}
}
</style>
