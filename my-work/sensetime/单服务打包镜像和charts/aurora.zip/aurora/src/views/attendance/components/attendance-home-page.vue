<template>
    <div class="home-page">
      <div class="content">
        <div class="pics">
          <img src="../../../assets/images/attendance-icon.png" alt="">
        </div>
        <div class="config" v-show="!isConfig">
          <!--还未配置考勤-->
          <div class="title">{{$t('attendance.notConfig')}}</div>
          <!--请联系管理员用户配置考勤-->
          <div class="text">{{$t('attendance.configTips')}}</div>
          <div class="between" v-show="$permission('022301')">
            <!--请点击完成-->
            <div>{{$t('attendance.clickOk')}}</div>
            <!--考勤配置-->
            <div class="btn"  @click="showConfig()">{{$t('attendance.titleHomePage')}}</div>
          </div>
        </div>
        <div class="configed" v-show="isConfig">
          <!--待生效的考勤配置-->
          <div class="title">{{$t('attendance.unimplemented')}}</div>
          <div class="outline"></div>
          <div class="content">
            <div class="line" v-if="listConfig[0]">
              <!--时间条件-->
              <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.timezone')}}</div>
              <div class="right">{{listConfig[0].timeZoneName?listConfig[0].timeZoneName:''}}</div>
            </div>
            <div class="line" v-if="listConfig[0]">
              <!--考勤设备-->
              <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.attendanceDevice')}}</div>
              <!--已选x个-->
              <div class="right">{{$t('attendance.selected',{number:listConfig[0].deviceIdArr?listConfig[0].deviceIdArr.length:'0'})}}</div>
            </div>
            <div class="line" v-if="listConfig[0]">
              <!--考勤人像库-->
              <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.imageLibrary')}}</div>
              <div class="right">{{$t('attendance.selected',{number:listConfig[0].targetLibIdArr?listConfig[0].targetLibIdArr.length:'0'})}}</div>
            </div>
            <div class="line" v-if="listConfig[0]">
              <!--生效时间-->
              <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.implementedTime')}}</div>
              <div class="right">{{listConfig[0].activateTime?listConfig[0].activateTime:''}}</div>
            </div>
          </div>
          <div class="bottom-btn">
            <!--编辑考勤配置-->
            <el-button type="primary" v-show="$permission('022301')"  @click="showConfig">{{$t('attendance.editConfig')}}</el-button>
          </div>
        </div>
      </div>

      <NowAttendanceConfig :dialogVisible="isNowConfigShow" @closeConfig="closeNowConfig"></NowAttendanceConfig>
      <AttendanceConfig :data="configData" :dialogVisible="isConfigShow" @initList="getListConfig" @closeConfig="closeConfig"></AttendanceConfig>
    </div>
</template>

<script>
  import { Component, Vue, Watch } from 'vue-property-decorator';
  import NowAttendanceConfig from "./now-attendance-config";
  import AttendanceConfig from './attendance-config.vue';
  import Api from '@/api/attendance';
  import {AppModule} from '@/store/modules/app';
  @Component({
    components:{
      NowAttendanceConfig,
      AttendanceConfig
    }
  })
  export default class AttendanceHomePage extends Vue {
    get language() {
      return AppModule.language;
    }
    isConfig = false;//控制显示哪种配置状态
    isConfigShow = false;
    isNowConfigShow = false;
    configData=null;
    listConfig = [];


    created(){
      this.getListConfig();
    }

    getListConfig(){
      let params = {
        pageNum:1,
        pageSize:2
      };
      Api.attendanceListConfig(params).then(res=>{
        this.listConfig = res.list
        if (this.listConfig.length>0){
          this.configData = this.listConfig[this.listConfig.length-1];
        }
        if (this.listConfig.length>1){//有两条配置，证明第一条配置为已生效
          this.$router.push({ path:'/attendance/list'});
          this.isConfig = true;
        }else if (this.listConfig.length == 1) {
          let config = this.listConfig[0];
          let activateTime = config.activateTime + ' ' + '00:00:00';
          var d = new Date(activateTime);
          var curDate = new Date();
          if (curDate<d){
            this.isConfig = true;//第一条配置待生效
          } else{//第一条配置已生效
            this.$router.push({ path:'/attendance/list'});
          }
        }else if (this.listConfig.length == 0){//还未配置考勤
          this.isConfig = false;
        }
      }).catch(err=>{
        console.log(err);
      })
    }

    showConfig(){
      this.isConfigShow = true;
    }
    closeConfig(){
      this.isConfigShow = false;
    }
    showNowConfig(){
      this.isNowConfigShow = true;
    }
    closeNowConfig(){
      this.isNowConfigShow = false;
    }

  }
</script>

<style lang="scss" scoped>
  .home-page{
    height: calc(100% - 32px);padding-top: 24px;
    background-image: url("../../../assets/images/attendance-bg.png");
    background-size: 100% 100%;
    position: relative;
    >.content{
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
      display: flex;
      align-items: center;
      .pics{
        height: 220px;
        width: 230px;
        margin-right: 30px;
        >img{
          width: 100%;
          height: 100%;
        }
      }
      .config{
        color: #C2CAD8;
        .title{
          font-size:24px;
          font-weight:bold;
          color:rgba(1,28,80,1);
          opacity:0.5;
        }
        .text{
          font-size: 16px;
          margin: 16px 0 24px;
        }
        .between{
          margin: 8px 0 0;
          display: flex;
          font-size: 16px;
          .btn{
            color:rgba(42,90,245,1);
            text-decoration:underline;
            margin-left: 10px;
            cursor: pointer;
          }
        }
      }
      .configed{
        .title{
          font-size:16px;
          font-weight:bold;
          color:rgba(40,53,77,1);
        }
        .outline{
          width:232px;
          height:1px;
          background:rgba(142,153,170,1);
          margin: 16px 0;
        }
        >.content{
          margin-bottom: 32px;
          .line{
            display: flex;
            margin: 8px 0;
            .left{
              width: 100px;
              font-size:14px;
              font-weight:bold;
              color:rgba(40,53,77,1);
            }
            .left2{
              width: 220px;
            }
            .right{
              /*width: 200px;*/
              font-size:14px;
              font-weight:400;
              color:rgba(40,53,77,1);
              opacity:0.5;
            }
          }
        }
        .bottom-btn{
          text-align: center;
        }
      }
    }
  }
</style>
