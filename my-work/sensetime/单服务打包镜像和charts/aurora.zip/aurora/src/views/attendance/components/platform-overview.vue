<template>
  <div class="platform-overview">
    <h2>
      <router-link to="/attendance/list">{{$t('attendance.title')}}</router-link>
    </h2>
    <!-- 本月考勤 -->
    <!-- <ul v-if="!statisData">
      <li>
        <strong>{{$t('attendance.thisMonth')}}:</strong>
        <span><em>{{$t('attendance.overview.lateRate')}}</em> {{attendanceGlobal.lateRatio}}%</span>
        <span><em>{{$t('attendance.overview.leaveEarlyRate')}}</em> {{attendanceGlobal.earlyRatio}}%</span>
        <span><em>{{$t('attendance.absenceDays')}}</em> {{attendanceGlobal.absenceTime}}{{$t('attendance.unitDay')}}</span>
        <span><em>{{$t('attendance.leaveDays')}}</em> {{attendanceGlobal.leaveTime}}{{$t('attendance.unitDay')}}</span>
      </li>
      <li>
        <strong>{{$t('attendance.lastMonth')}}:</strong>
        <span><em>{{$t('attendance.overview.lateRate')}}</em> {{attendanceGlobal.preLateRatio}}%</span>
        <span><em>{{$t('attendance.overview.leaveEarlyRate')}}</em> {{attendanceGlobal.preEarlyRatio}}%</span>
        <span><em>{{$t('attendance.absenceDays')}}</em> {{attendanceGlobal.preAbsenceTime}}{{$t('attendance.unitDay')}}</span>
        <span><em>{{$t('attendance.leaveDays')}}</em> {{attendanceGlobal.preLeaveTime}}{{$t('attendance.unitDay')}}</span>
      </li>
    </ul> -->
    <!-- 每日考勤 -->
    <ul>
      <li>
        <strong>{{$t('attendance.thisMonth')}}:</strong>
        <span><em>{{$t('attendance.attendanceRate')}}</em> {{statisData.currentMonthAttendanceRatio}}{{statisData.currentMonthAttendanceRatio? '%' : ''}}</span>
      </li>
      <li>
        <strong>{{$t('attendance.thatVeryDay')}}:</strong>
        <span><em>{{$t('attendance.attendanceNumber')}}</em> {{statisData.attendanceNum}}</span>
      </li>
      <li>
        <strong>{{$t('attendance.attendancePeriod')}}:</strong>
        <span><em></em> {{statisData.timeArr}}</span>
      </li>
    </ul>
    <div class="amount">
      <span><em>{{$t('attendance.overview.totalNumber')}}</em> {{attendanceGlobal.totalAttendanceNum}}{{$t('attendance.unitPeople')}}</span>
      <span class="update-time">{{$t('attendance.overview.dataUpdateTime')}}{{attendanceGlobal.updateDate}}</span>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator'
import Api from '@/api/attendance'
import { EventBus } from '@/utils/eventbus'
import dayjs from 'dayjs'

@Component({
  // computed:{
  //   nameStr:function () {
  //     let that = this as any;
  //     return '导出'+ that.nameStr?that.nameStr+'的':'-' + '考勤数据';
  //   }
  // }
})
export default class PlatformOverview extends Vue {
  dialogVisible = false
  form: any = {
    timeData: [] as any
  }
  attendanceGlobal: any = {}
  statisData = ''

  @Prop(String) name!: any

  // @Watch('name')
  // onNameChange(val:any){
  //   debugger
  //   if (val){
  //     this.nameStr ='导出'+ val + '的考勤数据'
  //   } else{
  //     this.nameStr ='导出 - 考勤数据'
  //   }
  // }
  mounted() {
    //do
    this.getAttendanceGlobal()
    this.getStatisData()

  }

  created() {
    // EventBus.$on('attendance-dayTime',data=>{
    //   console.log(data)
    //   // this.statisData = data
    //   let paramsDay ={
    //     keyWords: "",
    //     attendanceDay: "",
    //     attendanceStatus:[],
    //     pageNum: 1,
    //     pageSize: 1
    //   } as any;
    //   paramsDay.attendanceDay = data
    //   Api.queryAttendanceList(paramsDay).then((data: any) => {
    //      console.log('-------------------',data)
    //     this.statisData = data.statisData
    //   });
    // })
    EventBus.$on('getModificationTime',()=>{
        // this.getAttendanceGlobal()
        this.getStatisData()
    })
  }

  getStatisData() {
    let paramsDay = {
      keyWords: '',
      attendanceDay: '',
      attendanceStatus: [],
      pageNum: 1,
      pageSize: 1
    } as any
    // paramsDay.attendanceDay = data

    paramsDay.attendanceDay = dayjs().format('YYYY-MM-DD')

    Api.queryAttendanceList(paramsDay).then((data: any) => {
      // console.log('-------------------',data)
      this.statisData = data.statisData
    })
  }

  getAttendanceGlobal() {
    let params = {}
    Api.attendanceGlobal(params).then(data => {
      this.attendanceGlobal = data
      //console.log('................', data)
    })
  }

  exportBtn() {
    this.dialogVisible = true
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import '@/styles/variables.scss';
.platform-overview {
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  min-height: 32px;
  line-height: 32px;
  padding: 8px 0 8px 8px;
  flex-grow: 4;
  @include shadowBox();
  background-color: #f5f7fc;
  h2 {
    margin: 0;
    font-size: 16px;
  }
  em {
    font-style: normal;
    font-weight: bold;
    padding-left: 8px;
    padding-right: 4px;
  }
  ul {
    display: flex;
    li {
      background-color: #fff;
      line-height: 32px;
      margin-left: 24px;
      position: relative;
      padding-left: 24px;
      padding-right: 8px;
      border-radius: 4px;
      &::before {
        content: '';
        position: absolute;
        left: 13px;
        top: 13px;
        background-color: #011c50;
        width: 6px;
        height: 6px;
        border-radius: 5px;
      }
    }
  }
  .amount {
    flex: 1;
    text-align: right;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding-right: 24px;
    .update-time {
      padding: 0 8px;
    }
  }
}
</style>
