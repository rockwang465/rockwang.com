<template>
  <div class="attendance-main">
    <div class="aurora-tabs">
      <!-- <el-radio-group v-model="activeName" class="tab-button" @change.native="handleClick">
      <el-radio-button label="本月" name="0"></el-radio-button>
      <el-radio-button label="上月" name="1"></el-radio-button>
      </el-radio-group>-->
      <div :class="f ? '' : 'isok' " class="btnPer" @click="perDiem">{{$t('attendance.day')}}</div>
      <div :class="f ? 'isok' : '' " class="btnPer" @click="perMensem">{{$t('attendance.month')}}</div>

      <div class="select-date-picker" style="margin:0 auto">
        <el-date-picker
          v-if='f'
          v-model="params.selectValue"
          prefix-icon="el-icon-caret-bottom"
          size="small"
          :clearable="false"
          type="month"
          value-format="yyyy-MM"
          @change="selectMonth"
          placeholder
        ></el-date-picker>
        <el-date-picker
          v-else
          v-model="paramsDay.attendanceDay"
          prefix-icon="el-icon-caret-bottom"
          :clearable="false"
          size="small"
          type="date"
          value-format="yyyy-MM-dd"
          @change="selectDate"
          placeholder
        ></el-date-picker>
      </div>
      <div class="tab-action-bar">
        <el-input
          class="input-search"
          :placeholder="$t('attendance.searchKey')"
          @keyup.enter.native="handleSearch"
          v-model="keyWord"
        >
        <i slot="suffix" v-show="keyWord" @click="clearKeyWord" class="el-input__icon el-icon-circle-close"></i>
          <i slot="suffix" @click="handleSearch" class="el-input__icon el-icon-search"></i>
        </el-input>
        <el-button
          type="primary"
          icon="el-icon-setting"
          :disabled="!$permission('022302')"
          @click="showNowConfig"
        >{{$t('attendance.titleHomePage')}}</el-button>
        <el-button
          type="primary"
          icon="el-icon-upload2"
          :disabled="!$permission('022305')"
          @click="showExport"
        >{{$t('attendance.export')}}</el-button>
      </div>
    </div>
    <!-- 按月考勤 -->
    <div v-if="f" class="attendance-table">
      <el-table
        :data="tableData"
        ref="attendanceTable"
        style="width: 100% ;overflow: auto;"
        stripe
        @sort-change="sortRate"
      >
        <el-table-column prop="name" :label="$t('attendance.name')" width="250"></el-table-column>
        <el-table-column prop="identity" label="No." width="280"></el-table-column>
        <el-table-column prop="dept" :label="$t('attendance.department')" width="280"></el-table-column>
        <el-table-column
          prop="attendanceRatio"
          :label="$t('attendance.attendanceRate')"
          :formatter="formatterRatio"
          sortable
        >
          <template slot-scope="scope">
            <span >
              {{scope.row.attendanceRatio +'%'}}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="lateNum" :label="$t('attendance.lateTimes')"></el-table-column>
        <!-- <el-table-column prop="lateNum" :label="$t('attendance.lateTimes')"></el-table-column> -->
        <el-table-column prop="earlyNum" :label="$t('attendance.leaveEarlyTimes')"></el-table-column>
        <el-table-column prop="absenceNum" :label="$t('attendance.absenceDays')"></el-table-column>
        <el-table-column prop="leaveNum" :label="$t('attendance.leaveDays')"></el-table-column>
        <el-table-column
          prop="handle"
          :label="$t('attendance.viewAttendanceDetails')"
          align="center"
          width="180"
        >
          <template slot-scope="scope">
            <el-button @click="handleView(scope.row)" type="text" icon="el-icon-view"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        class="pagination align-center"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pagination.currentPage"
        :page-sizes="pagination.pageSizes"
        :page-size="pagination.pageSize"
        :total="pagination.totalPage"
        layout="total, sizes, prev, pager, next, jumper"
      ></el-pagination>
    </div>

    <!-- 按日考勤 -->
    <div v-else class="attendance-table">
      <el-table
        :data="tableDay"
        ref="attendanceTable"
        style="width: 100% ;overflow: auto;"
        stripe
        @sort-change="sortRate"
        >
        <el-table-column prop="name" :label="$t('attendance.name')" width="250"></el-table-column>
        <el-table-column prop="code" label="No." width="280"></el-table-column>
        <el-table-column prop="dept" :label="$t('attendance.department')" width="280"></el-table-column>
        <!-- <el-table-column
          label="考勤状态"
          :formatter="formatterRatio"
        ></el-table-column> -->
        <el-table-column
            prop="attendanceStatus"
            :render-header='renderHeader'
            >
            <template v-if="!f" slot-scope="scope">
              <span >
                {{$t(filterStatus(scope.row.attendanceStatus))}}
              </span>
            </template>
        </el-table-column>
        <el-table-column prop="firstCaptureTime" :label="$t('attendance.detail.goToWorkTime')"></el-table-column>
        <el-table-column prop="lastCaptureTime" :label="$t('attendance.detail.leaveWorkTime')"></el-table-column>
        <el-table-column prop="overTime" :label="$t('attendance.detail.overtimeHours')">
          <template v-if="!f" slot-scope="scope">
            <span >
              {{toMinute(scope.row.overTime) || 0}}
            </span>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('attendance.viewAttendanceDetails')"
          align="center"
          width="180"
        >
          <template v-if="!f" slot-scope="scope">
            <el-button @click="handleViewDay(scope.row)" type="text" icon="el-icon-view"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="!f"
        class="pagination align-center"
        @size-change="handleSizeChangeDay"
        @current-change="handleCurrentChangeDay"
        :current-page="pagination2.currentPage"
        :page-sizes="pagination2.pageSizes"
        :page-size="pagination2.pageSize"
        :total="pagination2.totalPage"
        layout="total, sizes, prev, pager, next, jumper"
      ></el-pagination>
    </div>
    <AttendanceExport :dialogVisible="isExportShow" @closeExport="closeExport" :isCompany="true" :time='f' :date='paramsDay.attendanceDay' :status="paramsDay.attendanceStatus" :sortType="params.sortType" :month='params.selectValue' :keywordM='params.keyWord' :keywordD='paramsDay.keyWords'></AttendanceExport>
    <NowAttendanceConfig :dialogVisible="isNowConfig" @closeConfig="closeNowConfig"></NowAttendanceConfig>
  </div>
</template>

<script lang="tsx" >
import { Component, Vue, Watch } from "vue-property-decorator";
import dayjs from "dayjs";

import AttendanceExport from "./attendance-export.vue";
import NowAttendanceConfig from "./now-attendance-config.vue";
import Api from "@/api/attendance";
import { divIcon } from "leaflet";
import {EventBus} from '@/utils/eventbus';

@Component({
  name: 'AttendanceList',
  components: {
    AttendanceExport,
    NowAttendanceConfig
  }
})
export default class AttendanceList extends Vue {
  activeName = "";
  f = false;
  isExportShow = false; //控制导出弹窗
  isNowConfig = false; //控制考勤配置弹窗
  params: any = {
    month: "0",
    keyWord: "",
    selectValue: ""
  };
  paramsDay: any = {
    keyWords: "",
    attendanceDay: "",
    attendanceStatus:[]
  };
  tableData: any = [];
  tableDay: any = [];
  pagination = {
    currentPage: 1,
    pageSize: 15,
    pageSizes: [15, 30, 45, 60, 75, 90],
    totalPage: 40
  };
  pagination2 = {
    currentPage: 1,
    pageSize: 15,
    pageSizes: [15, 30, 45, 60, 75, 90],
    totalPage: 40
  };
  tableHeight = "94.4%";
  orderType = "";
  cities=[
    { text: 'attendance.detail.normal', value: '11' },
    { text: 'attendance.detail.leave', value: '22' },
    { text: 'attendance.detail.absence', value: '33' },
    { text: 'attendance.detail.tardiness', value: '44' },
    { text: 'attendance.detail.leaveEarly', value: '14' },
    { text: 'attendance.detail.late', value: '41' },
    // { text: 'attendance.detail.workOvertime', value: '55' },
    ];
   checkedCities=[] as any;
   checkedShow=[] as any;
   checkAll = false;
   visible = false;
   keyWord = '';
   isSkyBlue = false ;

    filterStatus(val){
      switch (val) {
          case '11':
            return 'attendance.detail.normal'
          case '22':
            return 'attendance.detail.leave'
          case '33':
            return 'attendance.detail.absence'
          case '44':
            return 'attendance.detail.tardiness'
          case '14':
            return 'attendance.detail.leaveEarly'
          case '41':
            return 'attendance.detail.late'
          case '55':
            return 'attendance.detail.workOvertime'
      }
  }

  mounted() {
    console.log('考勤列表=>',this.$options.name);
    this.params.selectValue = dayjs()
      .startOf("month")
      .format("YYYY-MM");
    this.paramsDay.attendanceDay = dayjs()
      .format("YYYY-MM-DD");
    // this.params.startTime = dayjs().startOf('month').format('YYYY-MM-DD');
    // this.params.endTime = dayjs(new Date()).format('YYYY-MM-DD');
    this.getAttendanceList();
    // console.log(dayjs().get("day"));
    // EventBus.$emit('attendance-dayTime',this.paramsDay.attendanceDay );

    this.$nextTick(() => {
      // console.log((this.$refs.attendanceTable as Vue).$el.clientHeight);
      this.tableHeight =
        (this.$refs.attendanceTable as Vue).$el.clientHeight + "px";
    });

  }

  toMinute(val){
    if(!val) {
      return null
    }

    return (val/60).toFixed(1)
  }

  getAttendanceList(sortType?) {

    // if(sortType){
    //   this.params.sortType = sortType;
    // }
    // EventBus.$emit('attendance-dayTime121','----------fsfasf----------');
    if (this.f) {
      this.params.pageNum = this.pagination.currentPage;
      this.params.pageSize = this.pagination.pageSize;
      this.params.appointMonth = this.params.selectValue;
      this.params.sortType = this.orderType;
      //console.log("params=>", this.params);
      Api.attendanceList(this.params).then((data: any) => {
        this.tableData = data.list;
        this.pagination.totalPage = data.total;
        // console.log(data);
        //EventBus.$emit('attendance-dayTime',false );
      });
    } else {
      this.paramsDay.pageNum = this.pagination2.currentPage;
      this.paramsDay.pageSize = this.pagination2.pageSize;
      Api.queryAttendanceList(this.paramsDay).then((data: any) => {
        // console.log("本日数据");
        //console.log("本日数据" , data);
        // console.log(data.detailData.list);
        this.tableDay = data.detailData.list;
        this.pagination2.totalPage = data.detailData.total;
        let statisData = data.statisData
        // this.tableData = null;
        // this.pagination.totalPage = 1;
      });
    }
  }
  sort(prop, order) {
    console.log(prop, order);
  }
  handleView(item) {
    console.log(item);

    this.$router.push({
      path: "/attendance/detail",
      name:'AttendanceDetail',
      query: {
        //identity: item.identity,
        targetId: item.targetId,
        month: this.params.selectValue
      }
    });
  }
  handleViewDay(item) {
    console.log(item);
    let month = this.paramsDay.attendanceDay
    let reg = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
    month.match(reg);
    this.$router.push({
      path: "/attendance/detail",
      name:'AttendanceDetail',
      query: {
        //identity: item.code,
        targetId: item.targetId,
        month:`${RegExp.$1}-${RegExp.$2}`,
        attendanceDay: this.paramsDay.attendanceDay
      }
    });
  }
  sortRate(d) {
    console.log(d);
    this.orderType = "";
    if (d.order == "ascending") {
      this.orderType = "ASC";
    } else if (d.order == "descending") {
      this.orderType = "DESC";
    } else {
      this.orderType = "";
    }
    this.getAttendanceList(this.orderType);
  }
  selectDate(value) {
    this.paramsDay.attendanceDay = value
    // console.log(value);
    this.pagination2.currentPage =1;
    this.getAttendanceList();
  }
  selectMonth(value) {
    // console.log(value);
    this.pagination.currentPage =1;
    this.getAttendanceList();
  }

  handleSizeChange(val) {
    this.pagination.pageSize = val;
    this.getAttendanceList();
  }
  handleCurrentChange(val) {
    this.pagination.currentPage = val;
    this.getAttendanceList();
  }

  handleSearch(e) {
    console.log(this.keyWord);

    if(this.f) {
      this.pagination.currentPage = 1;
      this.params.keyWord = this.keyWord
    }else {
      this.pagination2.currentPage =1;
      this.paramsDay.keyWords = this.keyWord
    }
    this.getAttendanceList();
  }

  clearKeyWord(){
    this.keyWord =''
    if(this.f) {
      this.pagination.currentPage = 1;
      this.params.keyWord = this.keyWord
    }else {
      this.pagination2.currentPage =1;
      this.paramsDay.keyWords = this.keyWord
    }
    this.getAttendanceList();
  }

  formatterRatio(row, column) {
    if (row.attendanceRatio === undefined) {
      return "loading";
    } else {
      return row.attendanceRatio + "%";
    }
  }

  handleClick(ev) {
    this.params.month = ev.target.name;
    this.pagination.currentPage = 1;
    this.getAttendanceList();
  }

  showExport() {
    this.isExportShow = true;
  }
  closeExport() {
    this.isExportShow = false;
  }
  showNowConfig() {
    this.isNowConfig = true;
  }
  closeNowConfig() {
    this.isNowConfig = false;
  }

  perMensem() {
    this.f = true;
    this.keyWord = ''
    this.params.keyWord =''
    this.getAttendanceList();
  }
  perDiem() {
    this.f = false;
    this.keyWord = ''
    this.paramsDay.keyWords =''
    this.getAttendanceList();
  }

// 本日分页点击
  handleSizeChangeDay(val) {
    console.log('-------------',val);
    // this.pagination2.currentPage = val;
    this.pagination2.pageSize = val;
    this.getAttendanceList();
  }
  handleCurrentChangeDay(val) {
    console.log(val);
    this.pagination2.currentPage = val;
    this.getAttendanceList();
  }

  renderHeader(h, { column, $index }) {
    if(!this.f){
      return (

            <el-popover
            placement="bottom"
            v-model={this.visible}
            class='isShow'
            onHide={this.hide}
            onShow={this.show}
            >
              <el-checkbox
              label='null'
              onChange={this.handleCheckAllChange}
              v-model={this.checkAll}
              style="display:none"
              >
              {this.$t('rolemanagement.contSelectAll')}
              </el-checkbox>
            <el-checkbox-group v-model={this.checkedCities} onChange={this.handleCheckedCitiesChange}>
              {
                this.cities.map((v)=>{

                  return (
                    <el-checkbox  checkbox label={v.value} key={v.value}>{this.$t(v.text)}</el-checkbox>
                  )
                })
              }
            </el-checkbox-group>

            <div class='el-table-filter__bottom'>
            <el-button disabled={this.checkedCities != 0 ? false :true} onClick={this.screenOut}>{this.$t('records.contSearch')}</el-button>
            <el-button onClick={this.replacement}>{this.$t('records.contReset')}</el-button>
            </div>

              <div slot="reference" id='checking' class={this.isSkyBlue ? 'isSkyBlue' :''}>{this.$t('attendance.detail.attendanceStatus')}<i class="el-icon-caret-bottom"></i></div>
          </el-popover>
          )
    }else {
      return (<div slot="reference" id='checking'>{this.$t("attendance.attendanceRate")}</div>)
    }
  }
  // showFilter(){
  //   console.log(1313213)
  // }
  hide(){
     if(this.checkedShow) {
      this.checkedCities = this.checkedShow
      // console.log(this.checkedCities);

    }else {
      this.checkedCities =[]

    }
  }
  show(){
    this.checkedCities =[]
    if(this.checkedShow) {
      this.checkedCities = this.checkedShow
    }

     this.checkAll =  this.checkedCities.length == this.cities.length ? true :false
    // console.log(this.checkAll);

  }

  //全选
  handleCheckAllChange(){
    if(this.checkAll) {
      this.checkedCities = []
      this.cities.forEach(v=>{
        // console.log(this.checkedCities);
        let str = v.value
        this.checkedCities.push(str)
        // console.log(this.checkedCities);

      })
    }else {
      this.checkedCities = []
    }



  }

  //触发选择
  handleCheckedCitiesChange(val){

    this.checkedCities = val
    this.checkAll =  val.length == this.cities.length ? true :false

  }

  //筛选
  screenOut(){
    this.paramsDay.attendanceStatus = this.checkedCities.length == this.cities.length ? null :this.checkedCities
    this.visible = false
    this.checkedShow = this.checkedCities;
    this.pagination2.currentPage =1;
    this.getAttendanceList();
    this.isSkyBlue = true
    console.log(this.checkedCities);

  }
  //重置
  replacement() {
    this.checkAll = false
    this.checkedCities =[]
    this.checkedShow = this.checkedCities
    this.paramsDay.attendanceStatus = null
    this.pagination2.currentPage =1;
    this.isSkyBlue = false
    this.getAttendanceList();
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" >
@import "@/styles/variables.scss";
.aurora-tabs {
  min-height: 40px;
  .el-picker-panel{
    position: absolute;
    z-index: 99;
  }

  .btnPer {
    width: 80px;
    height: 32px;
    margin-top: 10px;
    text-align: center;
    line-height: 32px;
    cursor:pointer;
  }
  .isok {
    background: $--color-primary !important;
    color: #fff;
  }
}
.attendance-main {
  height: calc(100% - 32px);
  padding-top: 24px;
  .el-icon-search,
  .el-icon-circle-close{
    cursor: pointer;
  }
  .el-table th {
    padding: 14px 0;
    div {
      line-height: 40px;
    }
  }
  .el-table td {
    padding: 4px 0;
  }
  .el-pagination {
    padding: 8px;
    background-color: #f5f7fc;
  }

  .isSkyBlue {
    color:#2a5af5 ;
  }
}
.attendance-table {
  padding-top: 8px;
  height: calc(100% - 65px);
  @include shadowBox();
  .el-table {
    height: calc(100% - 40px);
    background-color: #f5f7fc;
    .el-button--text {
      color: #707070;
      padding: 8px;
    }
    .cell {
      white-space: nowrap;
      // height: 40px;
    }
  }
  border-radius: 0 0 4px 4px;
}

.tab-action-bar {
  .input-search {
    width: 280px;
    margin-right: 32px;
    display: inline-block;
    vertical-align: top;
  }
}


.select-date-picker{
  .el-date-editor{
    width: 145px;

  }
}

.el-table-filter__bottom button:hover {
  background-color: #fff;
}
.el-popover.el-popper {

  label {
    display: flex
  }
}

#checking {
  padding: 0px;
  display: inline ;
}

// .auroraUI .el-table__header .has-gutter .is-leaf .cell {
//   padding-left: 28px;
// }

.auroraUI .el-table tr td:first-child .cell, .auroraUI .el-table tr th:first-child .cell {
  padding-left: 28px;

}

</style>
