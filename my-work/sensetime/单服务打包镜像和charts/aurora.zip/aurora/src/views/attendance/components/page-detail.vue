<template>
  <el-container>
    <el-aside width="410px">
      <router-link class="backto-attendance" to="/attendance/list"> <i class="el-icon-arrow-left"></i>{{$t('attendance.overview.backToAttendance')}}</router-link>
      <attendance-detail-side></attendance-detail-side>
    </el-aside>
    <el-main class="main">
      <attendance-detail-main></attendance-detail-main>
    </el-main>
  </el-container>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator';
import AttendanceDetailSide from './attendance-detail-side.vue';
import AttendanceDetailMain from './attendance-detail-main.vue';

@Component({
  components: {
    AttendanceDetailSide,
    AttendanceDetailMain
  }
})
export default class AttendanceDetail extends Vue {
  mounted(){
    console.log('考勤详情=>',this.$options.name);
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.backto-attendance{
  position: absolute;
  display: inline-block;
  min-width: 100px;
  background: #F5F7FC;
  padding: 14px;
  padding-left: 8px;
  top: 18px;
  left: 18px;
  font-weight: bold;
  font-size: 16px;
}
</style>
