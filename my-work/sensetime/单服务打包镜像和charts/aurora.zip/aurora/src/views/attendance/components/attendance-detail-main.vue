<template>
  <div class="calendar-page">
    <div class="aurora-tabs">
      <!-- <el-radio-group v-model="activeName" class="tab-button" @change.native="handleClick">
      <el-radio-button label="day" name="day">{{$t('attendance.day')}}</el-radio-button>
      <el-radio-button label="month" name="month">{{$t('attendance.month')}}</el-radio-button>
    </el-radio-group> -->
      <div v-if="currentView === 'day'">
        <el-button
          icon="el-icon-date"
          type="text"
          @click="selectMonth"
        >{{params.selectValue}}</el-button>
        <i class="el-icon-arrow-right"></i>
        <el-button
          type="text"
          disabled
        >{{selectDayValue.substr(-2)}}</el-button>
      </div>
      <div class="select-date-picker">
        <!-- <el-select class="hide" v-model="params.selectValue" placeholder="请选择">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select> -->
        <!-- <el-date-picker
        v-if="activeName == '按月'"
        v-model="params.selectValue"
        prefix-icon="el-icon-caret-bottom"
        size="small"
        :clearable="false"
        type="month"
        value-format="yyyy-MM"
        @change="selectMonth"
        placeholder="选择月">
      </el-date-picker> -->
        <!-- <div v-if="currentView === 'day'">
        <el-date-picker
          v-if="selectDayValue"
          v-model="selectDayValue"
          prefix-icon="el-icon-caret-bottom"
          :clearable="false"
          type="date"
          @change="selectDay"
          value-format="yyyy-MM-dd"
          placeholder="">
        </el-date-picker>
      </div> -->
      </div>
      <div class="action-bar">
        <el-button
          type="primary"
          icon="el-icon-upload2"
          :disabled="!$permission('022307')"
          @click="showExport"
        >{{$t('attendance.export')}}</el-button>
      </div>
    </div>
    <div
      v-if="currentView === 'day'"
      class="day-view"
    >
      <div class="day-time">

        <div
          class="day-list"
          v-if="staffDayJson"
        >
          <div
            class="noData"
            v-if="noData"
          >
            <p>{{$t('attendance.noData')}}</p>
          </div>
          <el-scrollbar
            wrap-class="scrollbar-wrapper"
            v-else
          >
            <el-timeline>
              <el-timeline-item
                v-for="item in staffDayJson.list"
                :key="item.serialNumber"
                :timestamp="item.datTime"
                placement="top"
              >
                <el-card class="day-card-item">
                  <img
                    :src="item.url"
                    class="image"
                  >
                  <div class="day-card-item-info">
                    <p><i class="el-icon-alarm-clock"></i> {{ item.captureDate}}</p>
                    <p><i class="el-icon-location-outline"></i> {{ item.place}}</p>
                  </div>
                  <div class="day-card-item-right clearfix">
                    <el-button
                      v-if="item.bigPicture"
                      type="text"
                      class="button"
                      @click="viewBigPic(item.bigPicture.imgUrl)"
                      icon="el-icon-view"
                    >{{$t('attendance.detail.viewBigPic')}}</el-button>
                  </div>
                </el-card>
              </el-timeline-item>
            </el-timeline>
          </el-scrollbar>
        </div>

      </div>
      <div
        class="day-time-detail"
        v-if="staffDayJson"
      >
        <div class="day-detail-right">
          <h3>{{$t('attendance.detail.attendanceStatus')}}</h3>
          <el-divider></el-divider>
          <dl>
            <dt>{{$t('attendance.detail.attendanceRange')}}</dt>
            <dd>{{staffDayJson.workOnTime}} ~ {{staffDayJson.workOffTime}}</dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.detail.goToWork')}}</dt>
            <dd>
              {{attendanceStatus[0][Number(staffDayJson.attendanceStatusMorning)]}}
              <el-button
                v-if="staffDayJson.attendanceStatusMorning"
                type="text"
                class="button"
                icon="iconfont icon-edit"
                v-show="$permission('022308')"
                @click="editStatus(staffDayJson,0)"
              >{{$t('attendance.detail.editAttendanceStatus')}}</el-button>
            </dd>
          </dl>
          <dl>
            <dt>{{$t('attendance.detail.leaveWork')}}</dt>
            <dd>
              {{attendanceStatus[1][Number(staffDayJson.attendanceStatusAfternoon)]}}
              <el-button
                v-if="staffDayJson.attendanceStatusMorning"
                type="text"
                class="button"
                icon="iconfont icon-edit"
                v-show="$permission('022308')"
                @click="editStatus(staffDayJson,1)"
              >{{$t('attendance.detail.editAttendanceStatus')}}</el-button>
            </dd>
          </dl>
        </div>
        <el-divider></el-divider>
        <div class="attendance-edit-history">
          <template v-if="staffDayJson.attendanceStatusLogVos">
            <div
              v-for="item in staffDayJson.attendanceStatusLogVos"
              :key="item.id"
            >
              <h4>{{item.updateTime}}</h4>
              <div v-if="item.timeFlag =='0'">
                <dl>
                  <dt>{{$t('attendance.detail.goToWork')}}</dt>
                  <dd>{{attendanceStatus[0][Number(item.preAttendanceStatus)]}} <em v-if="item.preDuration">{{item.preDuration}} {{$t('attendance.unitMinute')}}</em> </dd>
                </dl>
                <dl>
                  <dt>{{$t('attendance.detail.changTo')}}</dt>
                  <dd>{{attendanceStatus[0][Number(item.dstAttendanceStatus)]}}</dd>
                </dl>
              </div>
              <div v-else>
                <dl>
                  <dt>{{$t('attendance.detail.leaveWork')}}</dt>
                  <dd>{{attendanceStatus[1][Number(item.preAttendanceStatus)]}} <em v-if="item.preDuration">{{item.preDuration}} {{$t('attendance.unitMinute')}}</em> </dd>
                </dl>
                <dl>
                  <dt>{{$t('attendance.detail.changTo')}}</dt>
                  <dd>{{attendanceStatus[1][Number(item.dstAttendanceStatus)]}}</dd>
                </dl>
              </div>
              <dl>
                <dt>{{$t('attendance.detail.editPeople')}}</dt>
                <dd>{{item.updatorName}}</dd>
              </dl>
              <dl>
                <dt>{{$t('attendance.detail.editTips')}}</dt>
                <dd>{{item.remark}}</dd>
              </dl>
            </div>
          </template>
        </div>
      </div>

    </div>

    <au-calendar
      v-if="currentView === 'month'"
      v-model="today"
      @clickVal="toMonth"
      :currMonth="params.selectValue"
      :value="params.selectValue"
    >
      <template
        slot="dateCell"
        slot-scope="{date, data}"
      >
        <strong class="day-num">
          {{ data.day.split('-').slice(2).join('-') }}
          <!-- {{ data.isSelected ? '✔️' : ''}} -->
        </strong>
        <template
          v-for="item in monthData"
          @click="daySelect"
        >
          <div
            class="day-event"
            v-if="item.attendanceDay == data.day"
            :key="item.id"
          >
            <i
              class="el-icon-warning icon-status danger"
              v-bind:class="{'success': (item.attendanceStatusMorning == 1 && item.attendanceStatusAfternoon == 1) || item.attendanceStatusMorning == 2}"
            ></i>
            <ul
              v-if="item.attendanceStatusMorning === item.attendanceStatusAfternoon && item.attendanceStatusMorning != 4  && item.attendanceStatusMorning != 1"
              class="case-list"
            >
              <li class="case-item">
                <strong
                  class="danger"
                  v-bind:class="{'success': item.attendanceStatusMorning == 1 || item.attendanceStatusMorning == 2}"
                >{{attendanceStatus[0][Number(item.attendanceStatusMorning)]}}</strong>
                <i
                  class="iconfont icon-edit"
                  v-show="$permission('022308')"
                  @click="editStatus(item,0)"
                ></i>
              </li>
            </ul>
            <ul
              v-else
              class="case-list"
            >
              <li class="case-item"><strong
                  class="danger"
                  v-bind:class="{'success': item.attendanceStatusMorning == 1}"
                >{{attendanceStatus[0][Number(item.attendanceStatusMorning)]}}</strong><i
                  class="iconfont icon-edit"
                  v-show="$permission('022308')"
                  @click="editStatus(item,0)"
                ></i></li>
              <li class="case-item"><strong
                  class="danger"
                  v-bind:class="{'success': item.attendanceStatusAfternoon == 1}"
                >{{attendanceStatus[1][Number(item.attendanceStatusAfternoon)]}}</strong><i
                  class="iconfont icon-edit"
                  v-show="$permission('022308')"
                  @click="editStatus(item,1)"
                ></i></li>
            </ul>
            <div class="hide">{{item}}</div>
            <div class="time">
              <p>
                <i
                  class="el-icon-warning danger"
                  v-bind:class="{'success': item.attendanceStatusMorning == 1}"
                ></i>
                {{$t('attendance.detail.goToWorkTime')}}: <span>{{item.arriveTime}}</span>
              </p>
              <p>
                <i
                  class="el-icon-warning danger"
                  v-bind:class="{'success': item.attendanceStatusAfternoon == 1}"
                ></i>
                {{$t('attendance.detail.leaveWorkTime')}}: <span>{{item.leaveTime}}</span>
              </p>
              <el-button
                class="btn-view-day"
                type="text"
                icon="el-icon-view"
                @click="loadDay(data.day)"
              ></el-button>
            </div>
          </div>
        </template>
      </template>
    </au-calendar>
    <el-dialog
      class="no-header"
      title=""
      width="58%"
      :visible.sync="dialogbigPicVisible"
      @closed="clearImg"
    >
      <!-- <i class="el-icon-close" @click="dialogbigPicVisible = false"></i> -->
      <el-image
        class="big-pic image"
        :src="bigPicSrc"
        fit="contain"
      >
        <div
          slot="placeholder"
          class="image-slot"
        >
          loading<span class="dot">...</span>
        </div>
      </el-image>
      <br>
    </el-dialog>
    <AttendanceExport
      :dialogVisible="isExportShow"
      @closeExport="closeExport"
      :isCompany="false"
      :targetId="targetId"
      :title="title"
    ></AttendanceExport>
    <AttendanceChangeState
      :dialogVisible="isChangeStateShow"
      :data="changeStateData"
      :timeFlag="timeFlag"
      @closeChangeState="closeChangeState"
    ></AttendanceChangeState>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import dayjs from 'dayjs';

import AuCalendar from '@/components/au-calendar/main.vue';
import AttendanceExport from './attendance-export.vue';
import AttendanceChangeState from './attendance-changestate.vue';
import i18n from '@/lang/index'
import Api from '@/api/attendance';
import { processImgurl } from '@/utils/image';
import {EventBus} from '@/utils/eventbus';

@Component({
  components: {
    AuCalendar,
    AttendanceExport,
    AttendanceChangeState
  }
})

export default class AttendanceUserDetail extends Vue {
  @Prop({ default: '' }) private staffDayData: any
  staffDayJson:any = {}
  dialogbigPicVisible=false;
  isExportShow=false; //导出弹窗
  isChangeStateShow=false; //修改考勤状态弹窗
  title:any=null; //导出员工姓名
  code:any=null;
  targetId:any = '';
  timeFlag:any=null; //修改员工状态时，选择的时间段;
  changeStateData:any=null;
  bigPicSrc:any = null;
  visitorObj:any={}
  exportParams:any={}
  today = new Date();
  params:any={
    keyWord:"",
    selectValue:'2019-07'
  }
  monthData:any = [];
  monthDataList:any = [];
  routeQuery:any={}
  selectDayValue = ''
  attendanceDay = ''
  currentView = "month"
  noData =false;
  activeName = 'month';
  fullPath = '';
  get attendanceStatus() {
     return [
      ['',this.$tc('attendance.detail.normal'),this.$tc('attendance.detail.leave'),this.$tc('attendance.detail.absence'),this.$tc('attendance.detail.late'),this.$tc('attendance.detail.workOvertime')],
      ['',this.$tc('attendance.detail.normal'),this.$tc('attendance.detail.leave'),this.$tc('attendance.detail.absence'),this.$tc('attendance.detail.leaveEarly'),this.$tc('attendance.detail.workOvertime')]
    ];
  }

  mounted(){
    //do something
    EventBus.$on('attendance-name',obj=>{
      //console.log(obj)
      this.title = obj.staffInfoVo.name;
      // this.targetId = obj.staffInfoVo.identity;
    })
    //console.log(this.$route)
    this.fullPath = this.$route.fullPath;
    this.routeQuery = this.$route.query;
    this.code = this.routeQuery.identity;
    this.targetId = this.routeQuery.targetId;
    this.params.selectValue = this.routeQuery.month;
    //console.log(this.routeQuery,this.currentView)
    if(this.routeQuery.attendanceDay){
      this.currentView = "day"
      this.selectDayValue = this.routeQuery.attendanceDay;
    }
    if(this.currentView === "month"){
      this.getMonthData()
    }else if(this.currentView === "day"){
      this.getAttendanceDetail();
    }
  }

  selectMonth(m){
    console.log("select-month",m,this.params.selectValue)
    this.getMonthData(this.params.selectValue);
    this.currentView = "month"
  }
  daySelect(ww){
    console.log(ww)
  }
  selectDay(day){
    console.log("select-day",day)
    this.getAttendanceDetail(day);
  }
  viewBigPic(url:string){
    this.dialogbigPicVisible = true;
    this.bigPicSrc = processImgurl(url);
  }
  clearImg() {
    this.bigPicSrc = null
  }
  loadDay(date){
    if(this.monthData && this.monthData.length >0 ){
      this.monthData.map((item)=>{
        if(date == item.attendanceDay){
          this.currentView = "day";
          this.activeName = this.currentView;
          this.selectDayValue = date;
          this.getAttendanceDetail(date)
        }
      })
    }
  }
  editStatus(item,num){
    this.timeFlag = num;
    this.changeStateData=item;
    this.showChangeState();
  }
  getAttendanceDetail(date?){
    this.staffDayJson = null;
    this.noData = true;
    if(!this.selectDayValue){
      this.selectDayValue = dayjs(this.today).format('YYYY-MM-DD');
    }

    let params = {
      attendanceDay:this.selectDayValue,
      targetId:this.routeQuery.targetId,
      identity:this.routeQuery.identity
    }
    if(date){
      params.attendanceDay = date;
      this.attendanceDay = date;
      this.selectDayValue = date;
    }

    Api.attendanceStaffDetail(params).then((resp:any)=>{
      //console.log("员工-某日-数据=>",resp);
      if(resp.list && resp.list.length>0){
        this.noData = false;
        resp.list.map((item)=>{
          //item.picUrl = processImgurl(item.picUrl);
          item.url = processImgurl(item.url);
          if(item.preCaptureDate){
            item.captureDate = item.preCaptureDate;
          }
          item.datTime = dayjs(item.captureDate).format('HH:mm:ss');
        })
      }
      this.staffDayJson = resp
    })
  }
  getMonthData(month?){
    let params:any={
      month: this.params.selectValue,
      targetId:this.routeQuery.targetId
    }
    if(month){
      params.month = this.params.selectValue
    }
    Api.attendanceStaffList(params).then((resp:any)=>{
      //console.log("某月-数据-列表=>",resp.singleStaffAttendanceInfoVoList)
      this.monthData = resp.singleStaffAttendanceInfoVoList;
    })
  }

  handleClick(ev){
    this.currentView = ev.target.name;
    console.log(ev)
    if(this.currentView === "month"){
      this.getMonthData()
    }else{
      this.getAttendanceDetail()
    }
  }

  showExport(){
    this.isExportShow = true;
  }
  closeExport(){
    this.isExportShow = false;
  }
  showChangeState(){
    this.isChangeStateShow = true;
  }
  closeChangeState(){
    this.isChangeStateShow = false;
    if(this.currentView === "month"){
      this.getMonthData()
    }else if(this.currentView === "day"){
      this.getAttendanceDetail();
    }
  }
  toMonth(month){
    this.params.selectValue = month;
    this.getMonthData()
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import '@/styles/variables.scss';
.calendar-page {
  height: 100%;
  .aurora-tabs {
    min-height: 40px;
    margin-bottom: 8px;
    .el-button--text {
      color: #011c50;
      font-weight: bold;
    }
    .el-button.is-disabled.el-button--text {
      font-weight: normal;
    }
  }
  .comp-full-calendar {
    width: 100%;
    margin: 0;
    max-width: 100%;
    .full-calendar-body {
      .weeks {
        border-left: none;

        border-top: none;
        border-bottom: 2px solid #d2dbea;
        .week {
          display: inline-block;
          border-right: none;
          margin: 0 4px;
          padding: 8px 0;
        }
      }
      .dates {
        .week-row {
          border-left: none;
          .day-cell {
            border-right: none;
            border-bottom: 2px solid #d2dbea;
            margin: 0 4px;
          }
        }
      }
    }
  }
  .attendance-edit-history {
    height: calc(100% - 200px);
    overflow-y: auto;
  }
  .select-date-picker {
    .el-date-editor {
      width: 150px;
    }
  }
  .time-line {
    position: absolute;
    left: 10px;
    font-weight: bold;
  }
  .el-timeline-item__timestamp {
    position: absolute;
    font-weight: bold;
    font-size: 16px;
  }
  .el-timeline-item__content {
    margin-left: 80px;
  }
  .el-timeline-item__node {
    background-color: #f5f7fc;
    border: 2px solid #2a5af5;
  }
  .noData {
    display: flex;
    height: 100%;
    justify-content: center;
    align-items: center;
  }
  .btn-view-day {
    position: absolute;
    right: 8px;
    bottom: 0px;
    font-size: 28px;
    color: #28354d;
    padding: 0;
    &:hover {
      color: #2a5af5;
    }
  }

  .no-header {
    ::after {
      border: none;
    }
  }
  .big-pic {
    width: 100%;
    height: 600px;
  }

  //考勤变更关闭按钮位置有问题,所以注释掉
  // .el-icon-close {
  //   position: absolute;
  //   right: -10px;
  //   top: -10px;
  // }

  .day-view {
    display: flex;
    // @include shadowBox();
    justify-content: space-between;
    height: calc(100% - 56px);
    .day-time {
      flex: 1;
      padding-right: 16px;
      padding-bottom: 16px;
      height: 100%;
      .day-list {
        padding: 16px;
        @include shadowBox();
        background-color: #f5f7fc;
        flex: 1;
        height: 100%;
        .el-scrollbar,
        .scrollbar-wrapper {
          height: 100%;
        }
        .scrollbar-wrapper {
          padding: 12px;
        }
        .el-timeline-item__wrapper {
          padding-left: 20px;
        }
      }

      .el-divider--horizontal {
        margin: 8px 0;
        width: calc(100% - 20px);
        background: none;
        //border-bottom: 1px dashed #FC3D1A;
        border-bottom: 1px dashed #f5f7fc;
        .el-divider__text.is-left {
          left: 0;
          padding-left: 0;
          padding-right: 4px;
          background-color: #f5f7fc;
          font-weight: bold;
          font-size: 18px;
        }
      }
    }
    .day-time-detail {
      width: 424px;
      padding: 16px;
      @include shadowBox();
      height: calc(100% - 16px);
      background-color: #f5f7fc;

      .day-time-detail-head {
        display: flex;
        justify-content: space-between;
        align-items: top;
        h3 {
          margin: 0;
        }
        .font-large {
          font-size: 22px;
          color: #0f9d58;
          padding: 8px;
        }
        .text-right {
          text-align: right;
        }
      }
      dl {
        display: flex;
        dt {
          width: 80px;
          text-align: right;
          font-weight: bold;
        }
        dd {
          padding-left: 8px;
          flex: 1;
          margin-left: 0;
          position: relative;
          .el-button--text {
            padding: 0;
            position: absolute;
            right: 0;
          }
        }
      }
    }
  }

  .day-layer {
    position: relative;
    padding-left: 60px;
    height: 187px;
    &::before {
      content: '';
      height: calc(100% - 24px);
      width: 16px;
      position: absolute;
      left: 0;
      top: 12px;
    }
    .el-scrollbar,
    .scrollbar-wrapper {
      height: 100%;
    }
    .scrollbar-wrapper {
      padding: 12px;
      padding-right: 20px;
      padding-bottom: 2px;
    }
  }
  .day-start {
    &::before {
      background-color: #fff9d6;
    }
  }
  .day-work {
    height: calc(100% - 374px);
    &::before {
      background-color: #eaf4ff;
    }
  }
  .day-end {
    &::before {
      background-color: #fff9d6;
    }
  }

  .day-card-item {
    margin-bottom: 8px;
    .el-card__body {
      padding: 8px;
      display: flex;
      align-items: center;
      img {
        width: 80px;
        height: 104px;
      }
      // .user-info{
      //   flex: 1;
      // }
      .day-card-item-info {
        padding: 16px;
        line-height: 1.6;
      }
      .day-card-item-right {
        flex: 1;
        padding: 16px;
        text-align: right;
      }
    }
  }
}

.attendance-main {
  height: calc(100% - 32px);
  padding-top: 24px;
}

.calendar-page {
  .el-calendar {
    background-color: #f5f7fc;
    height: calc(100% - 72px);
    position: relative;
    min-width: 990px;

    .el-calendar__header {
      display: flex;

      position: absolute;
      top: -54px;
      width: 40%;
      left: 30%;
      justify-content: center;
      .el-calendar__title {
        padding-right: 8px;
      }
    }
    .el-calendar__body {
      height: 100%;
      @include shadowBox();
      padding-bottom: 16px;
      .el-calendar-table {
        height: 100%;
        td {
          padding: 0 4px;
        }
      }
    }

    .el-calendar-day {
      position: relative;
      border-top: 2px solid #d2dbea;
      height: 100%;
      cursor: default;
      .day-num {
        position: absolute;
        right: 0;
        top: 0;
        font-size: 18px;
        padding: 4px;
      }
      .icon-status {
        position: absolute;
        right: 24px;
        top: 1px;
        font-size: 16px;
        margin: 4px;
        z-index: 0;
        opacity: 0.8;
      }

      .day-event {
        width: 80%;
        .icon-edit{
          font-size: large;
        }
      }
      .el-icon-warning {
        &::before {
          position: relative;
          z-index: 1;
        }
        &::after {
          content: '';
          width: 80%;
          height: 80%;

          border-radius: 30px;
          z-index: 0;
          position: absolute;
          left: 10%;
          top: 10%;
          border-radius: 30px;
        }
      }
      .danger {
        color: #fc3d1a;
        &::after {
          background-color: #fc3d1a;
        }
      }
      .success {
        color: #76ff03;
        &::after {
          background-color: #76ff03;
        }
      }
      .case-list {
        position: relative;
        z-index: 1;
        .case-item {
          font-size: 15px;
          line-height: 1.4;
          width: 155px;
          position: relative;
          i {
            display: none;
            margin-left: 4px;
            position: absolute;
            bottom: -2px;
          }
          i:hover {
            cursor: pointer;
          }
          &:hover {
            i {
              display: inline-block;
            }
          }
        }
      }
      .time {
        font-size: 12px;
        position: absolute;
        left: 0;
        bottom: 4px;
        width: 100%;
        line-height: 1.4;
        i {
          transform: scale(0.5);
        }
      }
    }
    .is-selected {
      .el-calendar-day {
        border-top: 2px solid #2a5af5;
        background-color: #eaf4ff;
      }
    }
    .el-calendar-table .el-calendar-day:hover {
      background-color: #eaf4ff;
    }
  }
}
</style>

