<template>
  <div class="attendance-export">
    <el-dialog
      :class="{hidden:isHide}"
      class="dialog-custom"
      :title="nameStr"
      :visible.sync="dialogShowVisible"
      width="30%"
      :append-to-body="true"
      :close-on-click-modal="false">

      <el-form ref="form" :model="form" label-width="80px">
        <!--按月-->
        <el-form-item v-if="isCompany&&time" :label="$t('attendance.alert.interval')">
          <el-date-picker
            v-model="form.timeData"
            type="daterange"
            size="small"
            prefix-icon	="el-icon-time"
            range-separator="~"
            value-format="yyyy-MM-dd"
            :start-placeholder="$t('visitor.visitorlist.labelStartTime')"
            :end-placeholder="$t('visitor.visitorlist.labelEndTime')">
          </el-date-picker>
        </el-form-item>

        <!--&lt;!&ndash;按日&ndash;&gt;-->
        <!--<el-form-item style="width: 400px;" v-if="isCompany&&!time" :label="$t('log.contQuantity')">-->
          <!--<div class="outNum">-->
            <!--<el-input-->
              <!--@input="inputStartNum"-->
              <!--maxlength="9"-->
              <!--v-model="starNum"></el-input>-->
            <!--<span class="xian"> ~ </span>-->
            <!--<el-input-->
              <!--@input="inputEndNum"-->
              <!--maxlength="9"-->
              <!--v-model="endNum"></el-input>-->
          <!--</div>-->
          <!--&lt;!&ndash;提示语&ndash;&gt;-->
          <!--<div style="height: 20px;line-height:20px;color: red;text-align: center;margin-top: 5px;">-->
            <!--{{tipsWords}}-->
          <!--</div>-->
        <!--</el-form-item>-->

        <!--个人-->
        <el-form-item v-if="!isCompany" :label="$t('attendance.alert.interval')">
          <el-date-picker
            v-model="form.dayData"
            type="daterange"
            size="small"
            prefix-icon	="el-icon-time"
            range-separator="~"
            value-format="yyyy-MM-dd"
            :start-placeholder="$t('visitor.visitorlist.labelStartTime')"
            :end-placeholder="$t('visitor.visitorlist.labelEndTime')">
          </el-date-picker>
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
          <el-button type="primary" :loading="btnLoading" :disabled="(starNum < 1 || endNum < 1)&&!time&&isCompany" @click="typeChoose()">{{$t('attendance.alert.confirm')}}</el-button>
          <el-button type="info" @click="dialogShowVisible = false">{{$t('attendance.alert.btnCancel')}}</el-button>
      </span>
    </el-dialog>

    <!--导出提示-->
    <el-dialog
      :title="$t('visitor.visitorlist.labelExport')"
      :visible.sync="dialogShowVisibleTips"
      width="30%">
      <div class="content">
        <!--确认导出筛选后的内容吗？-->
        {{$t('globaltip.tipExport')}}
      </div>
      <span slot="footer" class="dialog-footer">
        <!--从人像库中删除-->
        <el-button type="primary" :loading="btnLoading" @click="submit()">{{$t('visitor.visitorlist.btnOk')}}</el-button>
        <el-button class="cancel" type="info" @click="closeAll()">{{$t('visitor.visitorlist.btnCancel')}}</el-button>
     </span>
    </el-dialog>
  </div>

</template>

<script lang="ts">
  import { Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {Cache} from '@/utils/cache';
  import Api from '@/api/attendance';
  @Component({
    computed:{
      nameStr:function () {
        let that = this as any;
        let str = '';
        if (that.title){
          str = that.$t('attendance.alert.titleExport2',{name:that.title});
        } else{
          str = that.$t('attendance.alert.titleExport');
        }
        return str;
      },
      byData:function () {
        let that = this as any;
        return that.isCompany&&!that.time
      }
    },
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      }
    }
  })
  export default class AttendanceExport extends Vue {
    dialogShowVisible = false;
    dialogShowVisibleTips = false;
    isHide = false;
    form:any = {
      timeData:[] as any,
      dayData:[] as any,
    };
    starNum = null as any;
    endNum = null as any;
    tipsWords = '' as any;
    btnLoading = false;
    @Prop(String) title!: any;//员工姓名
    @Prop(Boolean) isCompany!: any;//整体导出还是个人导出
    @Prop(String) targetId!: any;//个人导出的targetId
    @Prop(Boolean) time!: any;//按月还是按日导出 false:日
    @Prop(String) date!: any;//按月还是按日导出 false:日
    @Prop() status!: any;//导出筛选条件
    @Prop(String) keywordM!: any;//导出筛选条件
    @Prop(String) keywordD!: any;//导出筛选条件
    @Prop(String) month!: any;//导出筛选条件
    @Prop(String) sortType!: any;//导出筛选条件


    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      let that = this as any;
      if (val&&that.byData){
        this.dialogShowVisible = !that.byData;
        this.dialogShowVisibleTips = that.byData;
        this.$emit("closeExport")
      }
    }


    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if(!val){
        this.starNum = null;
        this.endNum = null;
        this.form.timeData = [];
        this.form.dayData = [];
        this.$emit("closeExport")
      }else{
        this.isHide = false;
      }
    }

    exportBtn(){
      this.dialogShowVisible = true;
    }


    //输入验证
    inputStartNum(val){
      if(this.verifySize(val)){
        this.starNum = val
      }else{
        this.starNum = '';
      }
    }
    //输入验证
    inputEndNum(val){
      if(this.verifySize(val)){
        this.endNum = val
      }else{
        this.endNum = '';
      }

    }
    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([1-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        this.tipsWords="";
        return true;
      }else{
        this.tipsWords= this.$t("records.exportError");
        setTimeout(()=>{
          this.tipsWords=""
        },2000)
        return false;
      }
    }


    typeChoose(){
      if (!this.isCompany){
        this.submit();
      }else if(this.isCompany&&this.time){
        this.submit();
      } else{
        this.dialogShowVisibleTips  = true;
      }
    }


    submit(){
      let that = this as any;


      if (this.endNum-this.starNum<0){
        // this.tipsWords = '导出区间不能超过人像库总条数'
        this.tipsWords = that.$t('form.texterrExport2')
        setTimeout(()=>{
          this.tipsWords = '';
        },2000)
        return;
      }

      let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');







      if (!this.isCompany){//导出员工考勤数据
        if (this.form.dayData == null ||(this.form.dayData.length == 0&&this.form.timeData.length == 0)){
          this.$message.error({showClose: true,message:that.$tc('form.texterrSelectTimezone2')});
          return;
        }
        let params = {
          targetId:this.targetId,
          endTime:  this.form.dayData[1],
          startTime: this.form.dayData[0],
          userId:user.userId
        };
        this.btnLoading = true;
        Api.exportPersonalData(params).then((res)=>{
          this.dialogShowVisible = false;
          this.dialogShowVisibleTips = false;
          this.isHide = true;
          this.btnLoading = false;
          //console.log(res);
          let message;
          let type;
          if((res as any).count === 0){
            // message = '当前条件下，导出数据为0条，请重新筛选导出条件';
            message = that.$t('attendance.alert.exportTips');
            type = 'error';
          }else{
            message = that.$t('log.exportSuccess');
            type = 'success';
          }
          this.$message({
            showClose: true,
            // message: '导出成功',
            message:message,
            type: type
          });
        }).catch((err)=>{
          this.btnLoading = false;
        })
      } else if(this.isCompany&&this.time){//导出公司按月考勤数据
        if (this.form.timeData == null ||(this.form.timeData.length == 0&&this.form.timeData.length == 0)){
          this.$message.error({showClose: true,message:that.$tc('form.texterrSelectTimezone2')});
          return;
        }
        // let endDay = this.getDays(this.form.timeData[1])
        let params = {
          endTime: this.form.timeData[1],
          startTime: this.form.timeData[0],
          // appointMonth: this.month,
          // from: this.starNum,
          keyWord:this.keywordM,
          // sortType:this.sortType,
          // to: this.endNum,
          userId: user.userId
        };
        this.btnLoading = true;

        Api.exportCompany(params).then((res)=>{
          this.dialogShowVisible = false;
          this.dialogShowVisibleTips = false;
          this.btnLoading = false;
          this.isHide = true;
          //console.log(res);
          let message;
          let type;
          if((res as any).count === 0){
            // message = '当前条件下，导出数据为0条，请重新筛选导出条件';
            message = that.$t('attendance.alert.exportTips');
            type = 'error';
          }else{
            message = that.$t('log.exportSuccess');
            type = 'success';
          }
          this.$message({
            showClose: true,
            // message: '导出成功',
            message:message,
            type: type
          });
        }).catch((err)=>{
          this.btnLoading = false;
        })
      }else if (this.isCompany&&!this.time){//导出公司按日考勤数据
        let params = {
          date: this.date + ' 00:00:00',
          from: 1,
          to: 999999,
          userId: user.userId,
          status:this.status == null?[]:this.status,
          keyword:this.keywordD
          // endTime: endDay,
          // startTime: this.form.timeData[0],
          // userId:user.userId
        };
        this.btnLoading = true;

        Api.exportCompanyDataDay(params).then((res)=>{
          this.dialogShowVisible = false;
          this.dialogShowVisibleTips = false;
          this.btnLoading = false;
          this.isHide = true;
          //console.log(res);
          let message;
          let type;
          if((res as any).count === 0){
            // message = '当前条件下，导出数据为0条，请重新筛选导出条件';
            message = that.$t('attendance.alert.exportTips');
            type = 'error';
          }else{
            message = that.$t('log.exportSuccess');
            type = 'success';
          }
          this.$message({
            showClose: true,
            // message: '导出成功',
            message:message,
            type: type
          });
        }).catch((err)=>{
          this.btnLoading = false;
        })
      }
    }

    getDays(str){
      var date=new Date(str);
      //将当前月份加1，下移到下一个月
      date.setMonth(date.getMonth()+1);
      //将当前的日期置为0，
      date.setDate(0);
      //再获取天数即取上个月的最后一天的天数
      var days=date.getDate();
      return str.slice(0,8) + days;
    }

    closeAll(){
      this.dialogShowVisibleTips  = false
      this.dialogShowVisible = false
    }



    // getdaysinmonth (date){
    //   month = parseint(month,10)+1;
    //   var temp = new date(year+/+month+/0);
    //   return temp.getdate();
    // }
  }
</script>

<style scoped lang="scss">
  .dialog-custom{
  // display:block !important;
    width:100%;
    height:100%;
  }
  .hidden {
    display: block !important;
    position: fixed;
    top: -10%;
    bottom: 110%;
    right: 5%;
    left: 95%;
    width: 0;
    height: 0;
    overflow: hidden;
    transition: all 1s;
    ::v-deep .el-dialog {
      min-width: 30%;
      min-width: 30%;
      height: 30%;
      overflow: hidden;

    }
  }
  .outNum{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .outNum span{
    margin-right: 10px;
  }
  .outNum .xian{
    margin-left: 10px;
  }
  .content{
    font-weight: 600;
  }
  /*.outNum ::v-deep .el-input{*/
    /*width: 25%;*/
  /*}*/

</style>
