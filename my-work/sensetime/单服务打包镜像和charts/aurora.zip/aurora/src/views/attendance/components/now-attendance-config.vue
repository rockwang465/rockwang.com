<template>
  <div>
  <el-dialog
    :title="$t('attendance.titleHomePage')"
    :visible.sync="dialogShowVisible"
    width="30%">
    <div class="now-config">
      <div class="title">{{$t('attendance.alert.currentConfiguration')}}</div>
      <div class="content">
        <div class="line" v-if="listConfig[0]">
          <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.timezone')}}</div>
          <div class="right">{{listConfig[0].timeZoneName?listConfig[0].timeZoneName:''}}</div>
        </div>
        <div class="line" v-if="listConfig[0]">
          <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.attendanceDevice')}}</div>
          <div class="right">{{$t('attendance.selected',{number:listConfig[0].deviceIdArr?listConfig[0].deviceIdArr.length:'0'})}}</div>
        </div>
        <div class="line" v-if="listConfig[0]">
          <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.imageLibrary')}}</div>
          <div class="right">{{$t('attendance.selected',{number:listConfig[0].targetLibIdArr?listConfig[0].targetLibIdArr.length:'0'})}}</div>
        </div>
        <div class="line" v-if="listConfig[0]">
          <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.implementedTime')}}</div>
          <div class="right">{{listConfig[0].activateTime?listConfig[0].activateTime:''}}</div>
        </div>
      </div>
    </div>
    <div class="wait-config">
      <div>
        <div class="tips" v-show="listConfig.length == 1">{{$t('attendance.alert.configTips4')}}</div>
      </div>
      <div  v-if="listConfig.length == 2">
        <div class="mid-line"></div>
        <div class="title">{{$t('attendance.unimplemented')}}</div>
        <div class="content">
          <div class="line" v-if="listConfig[1]">
            <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.timezone')}}</div>
            <div class="right">{{listConfig[1].timeZoneName?listConfig[1].timeZoneName:''}}</div>
          </div>
          <div class="line" v-if="listConfig[1]">
            <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.attendanceDevice')}}</div>
            <div class="right">{{$t('attendance.selected',{number:listConfig[1].deviceIdArr?listConfig[1].deviceIdArr.length:'0'})}}</div>
          </div>
          <div class="line" v-if="listConfig[1]">
            <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.imageLibrary')}}</div>
            <div class="right">{{$t('attendance.selected',{number:listConfig[1].targetLibIdArr?listConfig[1].targetLibIdArr.length:'0'})}}</div>
          </div>
          <div class="line" v-if="listConfig[1]">
            <div class="left" :class="language === 'en'?'left2':''">{{$t('attendance.implementedTime')}}</div>
            <div class="right">{{listConfig[1].activateTime?listConfig[1].activateTime:''}}</div>
          </div>
        </div>
      </div>


    </div>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" v-show="$permission('022301')" @click="showConfig()">{{$t('attendance.editConfig')}}</el-button>
    </span>
  </el-dialog>
    <AttendanceConfig :data="configData" :dialogVisible="isConfigShow" @initList="getListConfig" @closeConfig="closeConfig"></AttendanceConfig>
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch, Prop} from 'vue-property-decorator'
  import TreeSelect from "@/components/portraitDeviceAdd/index.vue";
  import AttendanceConfig from './attendance-config.vue';
  import Api from '@/api/attendance';
  import {AppModule} from '@/store/modules/app';
  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    },
    components:{
      TreeSelect,
      AttendanceConfig
    }
  })
  export default class NowAttendanceConfig extends Vue {
    get language() {
      return AppModule.language;
    }
    dialogShowVisible = false;
    listConfig = [] as any;
    isConfigShow = false;
    configData = {} as any;

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeConfig")
      }
    }

    created(){
      this.getListConfig();
    }

    getListConfig(){
      let params = {
        pageNum:1,
        pageSize:2
      };
      Api.attendanceListConfig(params).then(res=>{
        this.listConfig = (res as any).list;

        if (this.listConfig.length>0){
          this.configData = this.listConfig[this.listConfig.length-1];
          if (this.listConfig.length == 1) {
            let config = this.listConfig[0];
            let activateTime = config.activateTime + ' ' + '00:00:00';
            var d = new Date(activateTime);
            var curDate = new Date();
            // if (curDate>d){//已生效
            //   this.configData = null;
            // }
          }
        }
      }).catch(err=>{
        console.log(err);
      })
    }

    editConfig(){

    }

    showConfig(){
      this.isConfigShow = true;
    }
    closeConfig(){
      this.isConfigShow = false;
    }

  }





</script>

<style scoped lang="scss">
  .now-config{
    width: 100%;
    /*height: 100%;*/
    margin-top: 16px;
    .title{
      font-size:14px;
      font-weight:bold;
      color:rgba(40,53,77,1);
      margin-bottom: 20px;
    }
    >.content{
      margin: 32px;
      .line{
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 12px 0;
        .left{
          width: 100px;
          font-size:14px;
          text-align: right;
          margin-right: 10px;
          font-weight:bold;
          color:rgba(40,53,77,1);
        }
        .left2{
          width: 220px;
          text-align: right;
          margin-right: 10px;
        }
        .right{
          width: 100px;
          font-size:14px;
          font-weight:400;
          color:rgba(40,53,77,1);
          opacity:0.5;
          white-space: nowrap;
        }
      }
    }
  }
  .wait-config{
    width: 100%;
    /*height: 100%;*/
    margin-top: 16px;
    .tips{
      text-align: center;
      margin: 60px 0 40px;
      font-size:14px;
      font-weight:400;
      color:rgba(40,53,77,1);
      opacity:0.5;
      word-break: break-all;
    }
    .mid-line{
      width: 100%;
      height: 2px;
      background: #8E99AA;
      margin-bottom: 16px;
      opacity: 0.5;
    }
    .title{
      font-size:14px;
      font-weight:bold;
      color:rgba(40,53,77,1);
      margin-bottom: 20px;
    }
    .content{
      margin: 32px;
      .line{
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 12px 0;
        .left{
          width: 100px;
          font-size:14px;
          font-weight:bold;
          color:rgba(40,53,77,1);
        }
        .left2{
          width: 220px;
        }
        .right{
          width: 100px;
          font-size:14px;
          font-weight:400;
          color:rgba(40,53,77,1);
          opacity:0.5;
          white-space: nowrap;
        }
      }
    }
  }
</style>
