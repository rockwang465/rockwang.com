<template>
    <el-dialog
      :title="$t('attendance.alert.statusChange')"
      :visible.sync="dialogShowVisible"
      width="30%"
      :close-on-click-modal="false">
      <el-form ref="form" :model="form" :label-width="formLabelWidth" label-position="right">
        <el-form-item :label="$t('attendance.alert.currentStatus')" style="margin-top: 22px;">
          <div class="state" v-if="data">
            <div class="color" :style="{color:(timeFlag == 0?data.attendanceStatusMorning:data.attendanceStatusAfternoon)>2?'#BE0000':'#0F9D58'}">{{timeFlag == 0?attendanceStatusMoring[data.attendanceStatusMorning]:attendanceStatusAfter[data.attendanceStatusAfternoon]}}</div>
            <div class="time"  v-show="(timeFlag == 0?data.attendanceStatusMorning:data.attendanceStatusAfternoon)==4">{{toHour(timeFlag == 0?data.lateDuration:data.earlyDuration)}}</div>
          </div>
        </el-form-item>
        <el-form-item :label="$t('attendance.alert.changeTo')">
          <el-select v-model="form.state" :placeholder="$t('visitor.visitorlist.tipsPSelect')">
            <el-option
              v-for="item in (timeFlag == 0 ? am.dataList:pm.dataList)"
              :key="item.label"
              :label="language == 'en'?(item.labelDescEn + (item.durationEn?item.durationEn:'')):(item.labelDesc + (item.duration?item.duration:''))"
              :value="item.label">
              <span :style="{float: 'left',color: item.label < 3?'#0F9D58':'#BE0000'}">{{ language == 'en'?item.labelDescEn:item.labelDesc }}</span>
              <span style="float: right; color: #000; font-size: 13px">{{  language == 'en'?item.durationEn:item.duration }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('attendance.alert.note')">
          <el-input
            type="textarea"
            :rows="5"
            resize="none"
            v-model="form.textarea">
          </el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="btnLoading" @click="subInfo()">{{$t('attendance.alert.confirm')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('attendance.alert.btnCancel')}}</el-button>
      </span>
    </el-dialog>
</template>

<script lang="ts">
  import { Component, Vue, Watch, Prop} from 'vue-property-decorator'
  import Api from '@/api/attendance';
  import {AppModule} from '@/store/modules/app';
  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    },
    computed:{
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '80px';
      },
    }
  })
  export default class AttendanceChangeState extends Vue {
    @Prop(Object) data!:any;
    @Prop(Number) timeFlag!:any;//判断上午下午
    get language() {
      return AppModule.language;
    };
    btnLoading=false;
    dialogShowVisible = false;
    // attendanceStatusMoring = ['','正常','请假','缺勤','迟到','加班'];
    get attendanceStatusMoring (){
      return ['',this.$tc('attendance.detail.normal'),this.$tc('attendance.detail.leave'),this.$tc('attendance.detail.absence'),this.$tc('attendance.detail.late'),this.$tc('attendance.detail.workOvertime')];
    }
    // attendanceStatusAfter = ['','正常','请假','缺勤','早退','加班'];
    get attendanceStatusAfter(){
      return ['',this.$tc('attendance.detail.normal'),this.$tc('attendance.detail.leave'),this.$tc('attendance.detail.absence'),this.$tc('attendance.detail.leaveEarly'),this.$tc('attendance.detail.workOvertime')];}
    form:any = {
      state:'1',
      textarea:''
    };
    am = [] as any;
    pm = [] as any;


    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.form.state = '1';
        this.btnLoading = false;
        this.$emit("closeChangeState");
      }
    }

    created(){
      this.getStateList(0);
      this.getStateList(1);

    }

    getStateList(num){
      let params = {
        timeFlag:num
      }
      Api.listAttendanceStatus(params).then(res=>{
        // console.log(res);
        if (num === 0){
          this.am = res;
        } else if (num === 1){
          this.pm = res;
        }
      }).catch(err=>{
        console.log(err);
      })
    }


    subInfo(){
      this.btnLoading = true;
      let params = {
        label:this.form.state,
        id:this.data.id,
        remark:this.form.textarea,
        timeFlag:this.timeFlag,//0上午，1下午
      };
      Api.modifyAttendanceInfoRequest(params).then(res=>{
        let that = this as any;
        this.$message({
          showClose: true,
          message:that.$t('globaltip.tipAttendanceStateChange'),
          type: 'success'
        })
        this.dialogShowVisible = false;
        //console.log(res);
      }).catch(err=>{
        this.dialogShowVisible = false;
        //console.log(err);
      })
    }

    toHour(minutes){
      if (this.language == 'en'){
        return ((Math.floor(minutes/60)>0?Math.floor(minutes/60) + "h":'') + ((minutes%60)>0?(minutes%60) + "m":'' ));
      } else{
        return ((Math.floor(minutes/60)>0?Math.floor(minutes/60) + "小时":'')  + ((minutes%60)>0?(minutes%60) + "分":'' ));
      }
    }

  }
</script>

<style scoped lang="scss">
.state{
  display: flex;
  justify-content: space-between;
  width: 100%;
  font-size: 14px;
  .color{
    color: #BE0000;
  }
  .time{
    color: #909191;
  }
}
</style>
