<template>
<div class="sn-login">
  <div class="login-container">
    <div class="app-info">
      <h1>{{systemName}} <small>{{systemVersion}}</small></h1>
      <h2>{{systemDescribe}}</h2>
      <div class="slogan"></div>
    </div>
    <div class="login-form">
      <el-form ref="loginForm" :model="loginForm" :rules="loginRules" auto-complete="on" label-position="left">
        <h2></h2>
        <el-form-item prop="username">
          <el-input
             v-model="loginForm.username"
             name="username"
             type="text"
             auto-complete="on"
             prefix-icon="iconfont icon-user1"
             :placeholder="$t('login.textboxEnterUsername')">
          </el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            :type="pwdType"
            v-model="loginForm.password"
            name="password"
            auto-complete="on"
            :placeholder="$t('login.textboxEnterPassword')"
             prefix-icon="iconfont icon-pwd"
            @keyup.enter.native="handleLogin">
            </el-input>
        </el-form-item>
        <div class="verify-code">
          <el-form-item class="code-input"  prop="verifyCode">
            <el-input
              v-model="loginForm.verifyCode"
              name="verifyCode"
              type="text"
              auto-complete="on"
              prefix-icon="iconfont icon-verify"
              :placeholder="$t('login.verifyCode')"
              @keyup.enter.native="handleLogin">
            </el-input>
          </el-form-item>
          <div class="code-pic">
          <img :src="codeUrl"/>
          </div>
          <div @click="refreshCodeManual" class="refresh">
            <Icon
              type="ele"
              name="refresh"
              size="24"
            />
          </div>
        </div>

        <div class="friend-remind">
          <div><el-checkbox v-model="isRememberPassword">{{$t("login.contRememberMe")}}</el-checkbox></div>
          <div>
            <el-popover
              placement="bottom-start"
              width="250"
              trigger="hover"
              >
                <div class="keyword-suggest">
                  {{this.forgetPassword}}
                </div>
              <span slot="reference" style="margin-left: 5px">
                {{$t("login.contForgotPassword")}}
              </span>
            </el-popover>
          </div>
        </div>
        <el-form-item class="submit-login">
          <el-button :loading="loading" type="primary" @click.native.prevent="handleLogin">
            {{ $t('login.buttonLogin') }}
          </el-button>
        </el-form-item>
      </el-form>

    </div>　
  </div>
  <div class="website-info">
    <!-- <p>
      <span> {{$t("login.contAboutUs")}} | </span>
      <span> {{$t("login.contBrowser")}} | </span>
      <span> {{$t("login.contContactUs")}} </span>
    </p>  -->
    <p>
      <span>{{"Powered by SenseTime. All rights reserved."}}</span>
    </p>
  </div>
  <lang-select @changeLang="changeLanguage" size="28px" class="set-language"/>
  <canvas ref="canvas"></canvas>
</div>
</template>

<script lang="ts">
import { isValidUsername,validPassword } from '@/utils/validate';
import { Component, Vue, Watch } from 'vue-property-decorator';
import { LoginModule } from '@/store/modules/login';
import {UserModule} from '@/store/modules/user';
import loginApi from '@/api/login';
import { Form as ElForm } from 'element-ui';
import LangSelect from '@/components/lang-select/index.vue';
import { Route } from 'vue-router';
import {Cache} from '@/utils/cache';
import Cookies from 'js-cookie';
import  Icon from '@/components/icon-wrap/index.vue';
import request from "@/api/system";
import {roleModulesCode} from '@/router/moduleCode';
import i18n from '@/lang/index' // Internationalization
var url = window.globalConfig.login;

const validateUsername = (rule: any, value: string, callback: any) => {
  if (!isValidUsername(value)) {
    callback(new Error(i18n.tc("login.errmsgBlankUsername")));
  } else {
    callback();
  }
};
const validatePass = (rule: any, value: string, callback: any) => {
  if (!validPassword(value)) {
    callback(new Error(i18n.tc("login.errmsgBlankPassword")));
  } else {
    callback();
  }
};

@Component({
  components: {
    LangSelect,
    Icon
  }
})
export default class Login extends Vue {
  keyId:any="";
  timer:any=null;
  codeUrl="";
  systemVersion = '';
  systemName="";
  systemDescribe:string=""
  forgetPassword=""
  loginForm = {
    username: '',
    password: '',
    verifyCode:'',
    timestamp:'',
    rememberMe:true
  };
  loginRules = {
    username: [{ required: true, trigger: 'blur', validator: validateUsername }],
    password: [{ required: true, trigger: 'blur', validator: validatePass }],
    verifyCode:[{ required: true, trigger: 'blur', min: 6 ,message:i18n.tc('login.errmsgWrongVerifyCode')}],
  };
  loading = false;
  pwdType = 'password';
  redirect: string | undefined = undefined;
  isRememberPassword:boolean=true;
  @Watch('$route', { immediate: true })
  OnRouteChange(route: Route) {
    // See https://github.com/vuejs/vue-router/pull/2050 for details
    this.redirect = route.query && route.query.redirect as string;
  }
  mounted(){
    this.changeLanguage()
    this.refreshCodeManual()//刷新验证码
    this.startInit()
  }
  startInit(){
    let canvas = this.$refs.canvas as any,
    ctx = canvas.getContext('2d'),
    w = canvas.width = window.innerWidth,
    h = canvas.height = window.innerHeight,
    hue = 180,
    stars:any = [],
    count = 0,
    maxStars = 560;
    //console.log(ctx)

    //星星绘制
    let canvas2 = document.createElement('canvas'),
      ctx2 = canvas2.getContext('2d') as any;
    canvas2.width = 50;
    canvas2.height = 36;
    let half = canvas2.width / 2,
    gradient2 = ctx2.createRadialGradient(half, half, 0, half, half, half)

    //渐变色
    gradient2.addColorStop(0.01, 'hsl(' + hue + ', 40%, 100%)')
    gradient2.addColorStop(0.04, 'hsl(' + hue + ', 50%, 85%)')
    gradient2.addColorStop(0.08, 'hsl(' + hue + ', 50%, 50%)')
    gradient2.addColorStop(0.11, 'rgba(255,255,255,.3)');
    gradient2.addColorStop(0.2, 'transparent');

    ctx2.fillStyle = gradient2
    ctx2.beginPath()
    ctx2.arc(half, half, half, 0, Math.PI * 2)
    ctx2.fill();

    function random (min, max?) {
      if (arguments.length < 2) {
        max = min
        min = 0
      }
      if (min > max) {
        var hold = max
        max = min
        min = hold
      }
      return Math.floor(Math.random() * (max - min + 1)) + min
    }

    function maxOrbit (x, y) {
      let max = Math.max(x, y),
        diameter = Math.round(Math.sqrt(max * max + max * max));
      return diameter / 2;// 星星移动范围，值越大范围越小
    }
    class Star {
      orbitRadius:number = random(maxOrbit(w, h))
      radius:number = random(60, this.orbitRadius) / 8
      orbitX:number = w / 2
      orbitY:number = h / 2
      timePassed:number = random(60, maxStars)
      speed:number = random(this.orbitRadius) / 3000000;
      alpha:number = random(2, 10) / 10
      constructor(){
        count++
        stars[count] = this;
      }
      draw(){
        let x = Math.sin(this.timePassed) * this.orbitRadius + this.orbitX,
            y = Math.cos(this.timePassed) * this.orbitRadius + this.orbitY,
            twinkle = random(10)

        if (twinkle === 1 && this.alpha > 0) {
          this.alpha -= 0.05
        } else if (twinkle === 2 && this.alpha < 1) {
          this.alpha += 0.05
        }

        ctx.globalAlpha = this.alpha
        ctx.drawImage(canvas2, x - this.radius / 2, y - this.radius / 2, this.radius, this.radius)
        this.timePassed += this.speed
      }

    }
    for (var i = 0; i < maxStars; i++) {
      new Star()
    }

    function animation () {
      ctx.clearRect(0, 0, w, h);//清理画布
      for (var i = 1, l = stars.length; i < l; i++) {
        stars[i].draw()
      };
      window.requestAnimationFrame(animation)
    }
    animation()

  }
  getStrangerPhoto(){
    request.getStrangerPhoto().then((resp:any)=>{
      Cache.localSet('strangerRatioSwitch',resp.strangerRatioSwitch)
    })
    request.getAllEventSwitchInfo().then((resp:any)=>{
      // console.log(resp);
      Cache.localSet('respiratorSwitch',resp.respiratorSwitch)
      Cache.localSet('helmetSwitch',resp.helmetSwitch)
    })
  }
  changeLanguage(){
    let language = Cookies.get('language') || 'zh';
    let num = language=="zh"?1:2
    loginApi.getSystemInfo(num).then((data:any)=>{
      this.systemName = data.systemName;
      this.systemVersion = data.version;
      this.forgetPassword = data.prompt;
      this.systemDescribe = data.systemDescribe;
    })
  }
  // showPwd() {
  //   if (this.pwdType === 'password') {
  //     this.pwdType = '';
  //   } else {
  //     this.pwdType = 'password';
  //   }
  // }

  refreshCodeManual(){
    clearInterval(this.timer)
    this.refreshCode()
    this.timer=setInterval(this.refreshCode,1000*60*4)
  }
  refreshCode(){
    var num = Math.random();
    this.keyId=String(num).split(".")[1]
    this.loginForm.timestamp = this.keyId;
    this.loginForm.rememberMe = this.isRememberPassword;
    this.codeUrl = url+"/kaptcha?timestamp="+this.keyId;
  }
  handleLogin() {
    //test permission
    // let is_permission = this.$permission('1100');
     this.loginForm.rememberMe = this.isRememberPassword;
    (this.$refs.loginForm as ElForm).validate((valid: boolean) => {
      if (valid) {
        this.loading = true;
        LoginModule.Login(this.loginForm).then((data:any) => {
          //去掉登录成功数据里的token
          if(data.accessToken){
            data.accessToken =null;
            delete(data.accessToken)
          }
          this.loading = false;
          let permissionCodes = data.modulePermissionCodes;
          if(this.isRememberPassword){
            Cache.localSet('modulecodes',data.modulePermissionCodes);
            Cache.localSet('isLogin',1);
            Cache.localSet('userInfo',data);
            // Cookies.set('accessToken', data.accessToken);//后端设置token  前端暂不设置
          }else{
            Cache.localClear();
            Cache.sessionSet('modulecodes',data.modulePermissionCodes);
            Cache.sessionSet('isLogin',1);
            Cache.sessionSet('userInfo',data);
          }
          this.getStrangerPhoto()//是否显示陌生人比对照片

          if(data.first==0){
            this.$router.push({ path: "/center/personInfo"});
          }else if(data.first==1){

            //判断是否有权限
            function hasPermission(code){
              let thisRouterCode = '';
              let userPermissionCodes:any = [];
              for(let key  in permissionCodes){
                userPermissionCodes.push(key);
              }
              for(let routerPermission  in roleModulesCode){
                if(routerPermission == code){
                  thisRouterCode = roleModulesCode[code]+''
                }
              }
              return userPermissionCodes.includes(thisRouterCode)
            }

            //登录成功跳转首页
            if(this.redirect){
              let pathArr = this.redirect.substr(1).split('/');
              let roleModule = '';
              if(pathArr.length>0 && (pathArr[0] == 'center' || pathArr[0] == 'manage')){
                roleModule= pathArr[pathArr.length-1]+'';
              }else{
                roleModule= pathArr[0]+'';
              }

              if(hasPermission(roleModule)){
                //this.$router.push({ path: this.redirect || '/' },() => {});

                //考勤详情页面，由于退出重新登录，用户信息需要清除，所以跳回考勤列表页
                if(this.redirect ==='/attendance/detail'){
                  this.$router.push({ path: '/attendance/list' || '/' });
                }else{
                  this.$router.push({ path: this.redirect || '/' });
                }

              }else{
                this.$router.push({ path: "/center/personInfo"});//如果用户没有redirect的路由权限
              }
            }else if(hasPermission('monitor')){
              console.log(2)
              this.$router.push({ path: "/"},() => {});
            }else{
              this.$router.push({ path: "/center/personInfo"});
            }
          }
          //license过期时间小于20天
          if(data.license==0){
             this.$message({
               showClose: true,
              message:this.$t("globaltip.tipmsgLicenseAlert",{number:data.expireDay}) as any,
              type: 'warning',
              duration: 3 * 1000,
            });
          }

          let language = Cookies.get('language') || 'zh';
          let num = language=="zh"?1:2
          let params = {
            userId:data.userId,
            language:num
          };
          UserModule.updateUserLanguage(params).then(res=>{
            //console.log(res);
          })
        }).catch((err) => {
          this.refreshCodeManual()//刷新验证码
          this.loginForm.verifyCode = '';//clear input
          this.loading = false;
        });
      }else{
        console.error('Login: error submit!!');
        return false;
      }
    });
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
$bg:#2d3a4b;
$dark_gray:#889aa4;
$light_gray:#eee;
 .keyword-suggest{
    word-break: normal;
    text-align: left;
  }
.sn-login{
  height: 100%;
  width:100%;
  background:#01061c url('/images/login_bg.jpg') no-repeat;
  //filter: blur(1px);
  background-size: 100% 100%;
  overflow: hidden;
  position: relative;
  &::after{
    content: '';
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    background: url('/images/login_bg.jpg') no-repeat;
    background-size: 100% 100%;
    z-index: 1;
    opacity: .4;
  }
  canvas{
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 0;
  }

  .login-container {
    position: relative;
    z-index: 2;
    display: flex;
    width:100%;
    height:95%;
    justify-content: center;
    align-items: center;
    padding:3% 0 0 12%;
    // background: url('/images/login.jpg') no-repeat 18% center;
    // background-size: 48%;
    color: #fff;
    .app-info{
      width: 660px;
      padding: 20px 0 40px;
      letter-spacing: .1em;
      h1,h2{
        text-shadow: 0 0 16px rgba(0,0,0,.4);
        font-style: normal;
      }
      h1{
        width: 10em;
        max-width: 100%;
        font-size: 65px;
        margin: 0;
        position: relative;
        padding-bottom: 10px;
        &::after{
          content: '';
          position: absolute;
          width: 4em;
          border-bottom: 1px solid rgba(255, 255, 255, .5);
          left: 0 ;
          bottom:0;
        }
        small{
          font-size: 40%;
        }
      }
      h2{
        font-size: 40px;
        margin: 16px 0 44px;
      }
      p{
        opacity: .6;
        font-size: 20px;
        line-height: 1.8;
        margin-bottom: 16px;
        .small{
          font-size: 15px;
          word-spacing: .3em;
        }
      }
      .line-bottom{
        font-style: normal;
        position: relative;
        &::after{
          content: '';
          width: 100%;
          height: 0;
          position: absolute;
          bottom: -14px;
          left: 0;
          border-bottom: 1px solid rgba(255, 255, 255, .5)
        }
      }
    }
    .login-decorate{
      width: 50%;
      margin-right:0px;
      .login-decorate-bg{
        img{
        width: 95%;
        }
      }
    }
    .login-form {
        width:450px;
        //height:400px;
        padding:$--base-gap*6 $--base-gap*4;
        background: rgba(255, 255, 255, 1);
        box-shadow: 0 0 10px rgba(0,0,0,.1);

        box-sizing: border-box;
        border-radius: 4px;
        .el-input{
          font-size: 16px;
        }
        .verify-code{
          display:flex;
          justify-content:space-between;
          margin-bottom:20px;
          .code-input{
            width:53%;
            margin-bottom:0;
          }
          .code-pic{
            width:37%;
            line-height: 0;
            img{
              width:100%;
              height: 52px;
              border: 1px solid #7E7E9A;
              border-radius: 4px;
            }
          }
          .refresh{
            line-height:52px;
            color:$--color-reserved-5;
            font-weight:600;
            cursor:pointer;
          }
        }
        .el-input__inner,
        button{
          height: 52px;
          border-radius: 4px;
        }
        .el-input__inner{
          padding-left: 40px;
          border: 1px solid #7E7E9A;
        }
        .el-input__inner:focus{
          border: 1px solid #7e7e9a;
        }
        .el-form-item{margin-bottom: 24px;}
        .el-form-item.is-success .el-input__inner:focus,
        .el-form-item.is-success .el-input__inner{
          border-color: #0f9d58;
        }
        .el-form-item.is-error .el-input__inner:focus,
        .el-form-item.is-error .el-input__inner{
          border-color: #db4436;
        }
        .el-input__prefix{
          left: 16px;
        }

        h2{
          color:#2185D0;
          font-weight: lighter;
          font-size: 24px;
        }
      .friend-remind {
        >:first-child{
          display: inline-block;
          width:50%;
          // color: $--color-white;
        };
        >:last-child{
          display: inline-block;
          width:50%;
          text-align: right;
          color:#777;
          cursor: pointer;
        }
      }
      .submit-login{
        margin-top:50px;
        button{width: 100%;font-size: 16px;}
      }
      .el-input__prefix{line-height: 50px;}
    }
  }
  @media screen and (max-width: 1400px) {
    .login-container{
      padding:3% 0 0 5%;
      .app-info{width: 550px;}
      .login-form{width: 420px;}
    }
  }
  .website-info{
    color: $--color-text-secondary;
    box-sizing: border-box;
    // padding-right:80px;
    text-align: center;
    p{
      padding: 5px;
    }
    .set-language{
      position: absolute;
      top: 24px;
      right: 24px;
      color: #99a5b9;
      .iconfont{color: #99a5b9;}
    }
  }
  .iconfont{font-size: 18px;}

}
.set-language{
  position: absolute;
  top: 24px;
  right: 24px;
  z-index: 3;
}
.sn-login{
  .international .icon-lang-set{
    color: #7E7E9A  !important;
    font-size: 22px !important;
  }
}
.slogan{
  width: 380px;
  height: 100px;
  background-size:auto 100%;
  background-repeat: no-repeat;
}
html:lang(en){
  .slogan{
    background-image: url(/images/e-slogan.svg);
  }
}
html:lang(zh){
  .slogan{
    background-image: url(/images/c-slogan.svg);
  }
}
</style>
