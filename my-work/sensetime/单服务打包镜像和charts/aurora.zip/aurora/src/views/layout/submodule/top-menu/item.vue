<template>
  <div class="link-inner">
    <i class="iconfont" v-bind:class="icon"></i>
    <em class="head_title" v-if="title" slot="title">{{title}}</em>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';

@Component
export default class MenuItem extends Vue {
  @Prop({ default: '' }) icon!: string;
  @Prop({ default: '' }) title!: string;
}
</script>
