<template>
  <el-menu
    ref="topMenu"
    :show-timeout="200"
    :default-active="$route.path"
    mode="horizontal"
    class="menu-wrap"
    :style="'width:'+topMenuWidth"
    @select="menuSelect"
  >
    <sidebar-item
      v-for="route in routes"
      :key="route.path"
      :item="route"
      :base-path="route.path"
    />
    <el-submenu index="tools" id="smallTools" v-if="showTools">
      <template slot="title"><i class="iconfont icon-tools"></i>{{$t('navbar.labelTools')}}</template>
      <el-menu-item index="tools/face-verification"> <i class="iconfont icon-face-id" ></i>{{$t('navbar.listToolsFaceVerify')}}</el-menu-item>
      <el-menu-item index="tools/score-detection"><i class="iconfont icon-face-id" ></i>{{$t('navbar.listToolsFaceQuality')}}</el-menu-item>
      <el-menu-item index="tools/test-detection"><i class="iconfont icon-face-id" ></i>{{$t('faceStyle.faceText')}}</el-menu-item>
    </el-submenu>
  </el-menu>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { AppModule } from '@/store/modules/app';
import SidebarItem from './top-menu-item.vue';
import {getUserRoutes} from '@/router/filterRouter';
import {Cache} from '@/utils/cache';
import {EventBus} from '@/utils/eventbus';
import {roleModulesCode} from '@/router/moduleCode';

@Component({
  components: {
    SidebarItem,
  },
})
export default class SideBar extends Vue {
  topMenuWidth = 'auto'

  get sidebar() {
    return AppModule.sidebar;
  }

  get routes() {
    let permissionCodes:any = Cache.localGet('modulecodes') || Cache.sessionGet('modulecodes');

    let modulesCodes:string[]=[];
    Object.keys(permissionCodes).forEach(item=>{
      modulesCodes.push(item);
    });
    this.showTools = modulesCodes.includes(roleModulesCode['tool']);
    //this.showTools = false;
    // return (this.$router as any).options.routes;
    return getUserRoutes(modulesCodes);
  }

  get isCollapse() {
    return !this.sidebar.opened;
  }
  mounted(){
    //console.log(this.routes)

    this.$nextTick(()=>{
      let totalWidth = 0;
      //console.log((this.$refs.topMenu as any).$vnode.child);
      // (this.$refs.topMenu as any).$el.children.map((item)=>{
      //   totalWidth += item.offsetWidth;
      // })

      //this.topMenuWidth = totalWidth+'px'
    })
  }

  menuSelect(index,path){
    if(index == 'tools/face-verification' || index == 'tools/score-detection' || index == 'tools/test-detection'){
      EventBus.$emit('layout-tools',index);
    }
  }
  //tool permission
  showTools:boolean=true;
}
</script>
