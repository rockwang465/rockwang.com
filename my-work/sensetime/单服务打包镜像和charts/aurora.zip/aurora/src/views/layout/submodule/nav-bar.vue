<template>
  <el-header height="64px">
    <el-row class="navbar">
      <el-col :span="3">
        <h1 class="logo">
          <img  :src="sysLogo" alt="" srcset="">
        </h1>
        <!-- <hamburger :toggle-click="toggleSideBar" :is-active="sidebar.opened" class="hamburger-container"/> -->
      </el-col>
      <el-col :span="17" class="sidebar-top">
        <top-menu class="sidebar-container"/>
      </el-col>
      <el-col :span="4" class="right_menu">
        <div class="avatar-container">
          <el-badge :max="99" class="msg-badge" :class="{msgShow:isMsgShow,msgHiden:!isMsgShow}" style="">
            <Icon @click="goAppCenter" style="color:#eee;cursor:pointer" type="icon" name="lujing" size="18"/>
          </el-badge>
          <el-badge ref="msgBadge" :value="newMessage" :max="99" class="msg-badge" :class="{msgShow:isMsgShow,msgHiden:!isMsgShow}" style="">
            <router-link to="/manage/message">
              <Icon style="color:#aaa;cursor:pointer" name="iconfont icon-news" size="18"/>
            </router-link>
          </el-badge>
          <template v-for="(item,key) in router">
            <el-dropdown v-if="item.meta && item.meta.center" :key="key" trigger="click">
              <div class="avatar-wrapper">
                <img :src="avatar + '/images/user-01.png'" class="user-avatar">
                <span class="avatar-name">{{userName}}</span>
                <i class="el-icon-caret-bottom"/>
              </div>
              <el-dropdown-menu slot="dropdown" class="user-dropdown">
                <!-- <router-link class="inlineBlock" to="/">
                  <el-dropdown-item>
                    Home
                  </el-dropdown-item>
                </router-link> -->
                <router-link v-for="(item,key) in item.children" :key="key" class="inlineBlock" :to="item.name">
                  <el-dropdown-item v-if="item.path == 'systemInfo'?$permission('003101'):true" :index="item.path">
                    {{$t('navbar.'+item.meta.title)}}
                  </el-dropdown-item>
                </router-link>
                <el-dropdown-item divided>
                  <span style="display:block;" @click="logout">{{$t("navbar.listLogout")}}</span>
                </el-dropdown-item>
              </el-dropdown-menu>
          </el-dropdown>
          </template>

        </div>
      </el-col>
    </el-row>
    <div class="waves-bg">
      <canvas ref="wavesBg"></canvas>
    </div>
  </el-header>
</template>

<script lang="ts">
import path from 'path';
import SineWaves from 'sine-waves';
import TopMenu from './top-menu/index.vue';
import Hamburger from '@/components/hamburger/index.vue';
import { Component, Vue,Watch } from 'vue-property-decorator';
import { AppModule } from '@/store/modules/app';
import { LoginModule } from '@/store/modules/login';
import { getSystem } from '@/store/modules/system';
import { logout } from '@/store/modules/login';
import {getUserRoutes} from '@/router/filterRouter';
import {Cache} from '@/utils/cache';
import Icon from '@/components/icon-wrap/index.vue';
import { messageCenter } from '@/store/modules/message-center';
import {processImgurl} from '@/utils/image.ts';

@Component({
  components: {
    Hamburger,
    TopMenu,

    Icon
  },
})

export default class Navbar extends Vue {
  isMsgShow=true;
  activeIndex= '1';
  activeIndex2= '1';
  host = window.globalConfig.host  as any;
  //token = null as any;
  processImgurl:any = processImgurl;
  msgCenterShow = false;
  systemInfo ={
    logo:''
  }
  msgBadgePos:any;
  @Watch("newMessage", { immediate: true,deep:true })
  msgChange(val,oldVal){
    if(val){
      this.isMsgShow=false;
    }else{
      this.isMsgShow=true;
    }
  }
  get userName(){
    return Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").realname:""; //产品要是显示这个名称
  }
  get sidebar() {
    return AppModule.sidebar;
  }

  get avatar() {
    return LoginModule.avatar;
  }
  get newMessage(){
    return messageCenter.newMessage;
  }
  get sysLogo(){
    // 判断后台接口前面是否有 '/'
    // let logo = getSystem.logo
    // if(logo.indexOf('/') == 0){

    //   logo = logo.slice(1)
    // }
    return getSystem.logo;
  }
  // get router(){
  //   return (this.$router as any).options.routes
  // }

  //临时解决权限不统一问题
  get router() {
    let permissionCodes:any = Cache.localGet('modulecodes') || Cache.sessionGet('modulecodes');

    let modulesCodes:string[]=[];
    Object.keys(permissionCodes).forEach(item=>{
      modulesCodes.push(item);
    });
    return getUserRoutes(modulesCodes);
  }
  mounted(){
    messageCenter.linkCenterMessage();
    //this.token = Cache.localGet('accessToken') || Cache.sessionGet('accessToken');

    //临时解决消息中心权限不被路由统一控制问题
    // this.router.map(item=>{
    //   if(item.name === 'manage'){
    //     item.children.find((value, index, arr) =>{
    //       if(value.name === 'message'){
    //         this.msgCenterShow = true;
    //         this.$nextTick(function () {
    //           this.msgBadgePos = (this.$refs.msgBadge as any).$el.getBoundingClientRect();
    //           let badgePos = {
    //             x : this.msgBadgePos.x,
    //             y : this.msgBadgePos.y,
    //             left : this.msgBadgePos.left,
    //             top : this.msgBadgePos.top,
    //           };
    //           AppModule.setBadgePos(badgePos)
    //         })
    //       }else{
    //         this.msgCenterShow = false;
    //       }
    //     })
    //   }
    // })

    getSystem.getSystemLogo().then((data:any)=>{
      this.systemInfo = data;
      if(this.systemInfo.logo){
         // 判断后台接口前面是否有 '/'
          let logo = this.systemInfo.logo;
          if (logo.indexOf("/") == 0) {
            logo = logo.slice(1);
          }
          this.systemInfo.logo = processImgurl(logo);
        // this.systemInfo.logo = this.host + this.systemInfo.logo;
      }else{
        this.systemInfo.logo = '/images/logo.png';
      }
      getSystem.SET_LOGO(this.systemInfo.logo);

    }).catch((err) => {

    });
    this.$nextTick(function () {
      this.msgBadgePos = (this.$refs.msgBadge as any).$el.getBoundingClientRect();
      let badgePos = {
        x : this.msgBadgePos.x,
        y : this.msgBadgePos.y,
        left : this.msgBadgePos.left,
        top : this.msgBadgePos.top,
      };
      AppModule.setBadgePos(badgePos)
    })

    this.wavesSet()
  }
  wavesSet(){
    var waves = new SineWaves({
      // Canvas Element
      el:this.$refs.wavesBg,

      // General speed of entire wave system
      speed: 1,

      // How many degress should we rotate all of the waves
      rotate: 0,

      // Ease function from left to right
      ease: 'Linear',

      // Specific how much the width of the canvas the waves should be
      // This can either be a number or a percent
      waveWidth: '95%',
      height:64,
      width:660,

      // An array of wave options
      waves: [
        {
          timeModifier: 1,   // This is multiplied againse `speed`
          lineWidth: 1,      // Stroke width
          amplitude: 20,    // How tall is the wave
          wavelength: 45,   // How long is the wave
          segmentLength: 20, // How smooth should the line be
          strokeStyle: 'rgba(255, 255, 255, 0.5)', // Stroke color and opacity
          type: 'sine'       // Wave type
        },
        {
          timeModifier: 0.5,
          lineWidth: 1,
          amplitude: 20,
          wavelength: 30,
          strokeStyle: 'rgba(255, 255, 255, 0.3)',
        }
      ],

      // Perform any additional initializations here
      initialize: function (){},

      // This function is called whenver the window is resized
      resizeEvent: function() {
        // Here is an example on how to create a gradient stroke
        var gradient = this.ctx.createLinearGradient(0, 0, this.width, 0);
        gradient.addColorStop(0,"rgba(21, 71, 206, 0)");
        gradient.addColorStop(0.5,"rgba(21, 71, 206, 0.5)");
        gradient.addColorStop(1,"rgba(21, 71, 206, 0)");

        var index = -1;
        var length = this.waves.length;
          while(++index < length){
          this.waves[index].strokeStyle = gradient;
        }
      }
    });
  }
  goMessageCenter(){
    this.$router.push({ path: '/manage/message' });
  }
  goAppCenter(){
    this.$emit('showApp')
  }
  toggleSideBar() {
    AppModule.ToggleSideBar(false);
  }
  handleSelect(key:string, keyPath:string) {
    console.log(key, keyPath);
  }
  logout() {
   logout();
  }
}
</script>
 <style rel="stylesheet/scss" lang="scss">
  .avatar-container{
    .msg-badge{
      margin-right:20px;
      margin-left:10px;
      line-height:30px;
    }
  }
  .navbar{
    z-index: 1;
    .sidebar-top{
      height: 64px;
    }
  }
  .waves-bg{
    position: absolute;
    height: 64px;
    width: 35%;
    z-index: 0;
    right: 200px;
    top: 0;
    canvas{
      transform: rotate(180deg);
      position: absolute;
      right: -24px;
    }
  }
 </style>
