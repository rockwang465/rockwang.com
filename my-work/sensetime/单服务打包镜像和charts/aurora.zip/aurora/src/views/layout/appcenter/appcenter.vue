<template>
  <el-dialog
    :title="$t('appCenter.appCenter')"
    :visible.sync="dialogShowVisible"
    class="isroll"
    width="60%">
    <div class="box">
      <div class="app">
        <div class="title"><span class="licon"></span><span>{{$t('appCenter.app')}}</span></div>
        <div class="list">
          <div class="btn-wrap" :style="{width: language == 'en'?'242px':'100px'}" v-for="(item,key) in useList"  @click="change('use',valueSplit(key))">
            <el-button size="medium" :disabled="!item" :class="item?'ac':'active'" :icon="'iconfont ' + appList.use[valueSplit(key)]" :key="key"></el-button>
            <div class="name">{{$t('appCenter.'+nameList.use[valueSplit(key)])}}</div>
          </div>
        </div>
      </div>
      <div class="set">
        <div class="title"><span class="licon"></span><span>{{$t('appCenter.set')}}</span></div>
        <div class="list">
          <div class="btn-wrap" :style="{width: language == 'en'?'242px':'100px'}" v-for="(item,key) in setList" @click="change('set',valueSplit(key))">
            <el-button size="medium" :disabled="!item" :class="item?'ac':'active'" :icon="'iconfont ' + appList.set[valueSplit(key)]" :key="key"></el-button>
            <div class="name">{{$t('appCenter.'+nameList.set[valueSplit(key)])}}</div>
          </div>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script lang="ts">
    import {Component, Vue, Watch } from 'vue-property-decorator';
    import {UserModule} from '@/store/modules/user';
    import {Cache} from '@/utils/cache';
    import appList from '@/.././public/appConfig';
    import {EventBus} from '@/utils/eventbus';
    import {AppModule} from '@/store/modules/app';
    // import nameList from '@/.././public/appConfig'

    @Component({
      props: {
        dialogVisible: {
          type: Boolean,
          default: false
        },
      },
    })
    export default class AppCenter extends Vue {
      dialogShowVisible = false;
      appList = appList['appList'] as any;
      nameList = appList['nameList'] as any;
      routerList = appList['routerList'] as any;
      moduleTypeVoList = {};
      useList = {};
      setList = {};
      // path = '';
      get language() {
        return AppModule.language;
      }

      created(){
        let userId = Cache.sessionGet('userInfo').userId;
        UserModule.queryModule(userId).then(res=>{
          //console.log(res);
          let obj = (res as any).moduleTypeVoList;
          // obj['a1']['a7'] = obj['a1']['a6'];
          // obj['a1']['a8'] = obj['a1']['a6'];
          this.moduleTypeVoList = obj;
          this.useList = obj['1'];
          this.setList = obj['2'];
        })
      }

      @Watch('dialogVisible')
      onDialogVisibleChange(val: any) {
        this.dialogShowVisible = val;
      }

      @Watch('dialogShowVisible')
      onDialogShowVisibleChange(val: any) {
        if (!val) {
          this.$emit("closeAppCenter")
        }
      }

      // @Watch('$route', { immediate: true })
      // onRouterChange(route: Route) {
      //   console.log(route)
      //   // this.path = route;
      // }

      close(){
        this.$emit('closeAppCenter')
      }

      valueSplit(val){
        return val.substr(1);
      }

      change(str,key){
        console.log(str,key);
        // console.log(this.$route.path);
        let path = this.$route.path;
        if (str === 'use'){
          if (!this.useList['a'+ key]){
            this.$message.error({showClose: true,message:this.$tc('appCenter.noPermission') as string});
            return;
          }
          if (key < 10 && key > 6){
            if(this.routerList['use'][key] == 'tools/face-verification' || this.routerList['use'][key] == 'tools/score-detection' || this.routerList['use'][key] == 'tools/test-detection'){
              EventBus.$emit('layout-tools',this.routerList['use'][key]);
            }
          } else{
            if (path.indexOf(this.routerList.use[key]) == -1){
              this.$router.push(this.routerList.use[key]);
            }
          }
        }
        if (str === 'set'){
          if (!this.setList['a'+key]){
            this.$message.error({showClose: true,message:this.$tc('appCenter.noPermission') as string});
            return;
          }
          if (path.indexOf(this.routerList.set[key]) == -1){
            this.$router.push(this.routerList.set[key]);
          }

        }
        this.close();
      }

    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.box{
  width: 100%;
  /*height: 500px;*/
  padding: 24px 0;
  .title{
    font-size: 18px;
    font-weight: 600;
    line-height: 20px;
    display: flex;
    align-items: flex-start;
    .licon{
      display: inline-block;
      width: 3px;
      height: 16px;
      margin-right: 5px;
      background: #000;
    }
  }
  .list{
    margin: 20px 0;
    display:flex;
    /*justify-content:space-around;*/
    flex-wrap: wrap;
    .btn-wrap{
      width: 100px;
      margin: 10px 10px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .name{
      text-align: center;
      /*margin:10px;*/
      box-sizing: content-box;
      font-size: 12px;
      font-weight: 600;
    }

    ::v-deep .active{
      border: 0px;
      width: 96px;
      height: 96px;
      text-align: center;
      line-height: 96px;
      background: linear-gradient(136deg,rgba(255,255,255,1) 0%,rgba(231,238,253,1) 100%);
      box-shadow: 0px 3px 6px rgba(0,0,0,0.16);
      opacity: 1;
      border-radius: 16px;
      padding: 0;
      margin: 10px 0;
      i{
        font-size: 48px;
        margin: 0;
        color:#D4D4D4;
      }
    }
    ::v-deep .ac{
      border: 0px;
      width: 96px;
      height: 96px;
      text-align: center;
      line-height: 96px;
      background: linear-gradient(136deg,rgba(255,255,255,1) 0%,rgba(231,238,253,1) 100%);
      box-shadow: 0px 3px 6px rgba(0,0,0,0.16);
      opacity: 1;
      border-radius: 16px;
      padding: 0;
      margin: 10px 0;
      i{
        font-size: 48px;
        margin: 0;
        color:rgba(34,76,241,1);
      }
    }
  }
}

</style>
