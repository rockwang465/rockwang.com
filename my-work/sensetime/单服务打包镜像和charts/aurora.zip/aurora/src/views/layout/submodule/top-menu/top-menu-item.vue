<template>
<li class="el-menu-item" v-if="item.children && hasOneShowingChild(item.children) && (!item.meta || !item.meta.hidden)">
  <el-menu-item
    :index="resolvePath(item.path)"
    :class="{'submenu-title-noDropdown': !isNest}"
  >
    <!-- {{ !onlyOneChild.children}} -->
    <app-link :to="resolvePath(onlyOneChild.path)">
      <item v-if="onlyOneChild.meta" :icon="onlyOneChild.meta.icon || item.meta.icon" :title="generateTitle(onlyOneChild.meta.title)"/>
    </app-link>
  </el-menu-item>
</li>
<li class="el-menu-item"  v-else-if="item.children && item.children.length>0 && (!item.meta || !item.meta.hidden)">
  <el-submenu :index="resolvePath(item.path)">
    <template slot="title">
      <item v-if="item.meta" :icon="item.meta.icon" :title="generateTitle(item.meta.title)" />
    </template>
    <template v-for="child in item.children" v-if="!child.meta || !child.meta.hidden">
      <item
        v-if="child.children && child.children.length > 0"
        :is-nest="true"
        :item="child"
        :key="child.path"
        :base-path="resolvePath(child.path)"
        class="nest-menu"/>
      <app-link v-else :to="resolvePath(child.path)" :key="child.name">
        <el-menu-item :index="resolvePath(child.path)">
          <item v-if="child.meta" :icon="child.meta.icon" :title="generateTitle(child.meta.title)" />
        </el-menu-item>
      </app-link>
    </template>
  </el-submenu>
</li>
</template>

<script lang="ts">
import path from 'path';
import { Route } from 'vue-router';
import { isExternal } from '@/utils/validate';
import { Component, Vue, Prop } from 'vue-property-decorator';
import Item from './item.vue';
import AppLink from './link.vue';

@Component({
  // Set 'name' here to prevent uglifyjs from causing recursive component not work
  // See https://medium.com/haiiro-io/element-component-name-with-vue-class-component-f3b435656561 for detail
  name: 'TopMenuItem',
  components: { Item, AppLink },
})
export default class TopMenuItem extends Vue {
  @Prop({ required: true }) item!: Route;
  @Prop({ default: false }) isNest!: boolean;
  @Prop({ default: '' }) basePath!: string;

  onlyOneChild: Route | null = null;

  hasOneShowingChild(children: Route[]) {
    if (!children) { return false; }
    const showingChildren = children.filter((item: Route) => {
      if (item.meta && item.meta.hidden) {
        return false;
      } else {
        this.onlyOneChild = item; // This will only be used if hasOneShowingChild return true
        return true;
      }
    });
    return showingChildren.length === 1;
  }

  resolvePath(routePath: string) {
    if (this.isExternalLink(routePath)) {
      return routePath;
    }

    return path.resolve(this.basePath, routePath);
  }

  isExternalLink(routePath: string) {
    return isExternal(routePath);
  }
  generateTitle(title:string) {
    const hasKey = this.$te('navbar.' + title)

    if (hasKey) {
      // $t :this method from vue-i18n, inject in @/lang/index.js
      const translatedTitle = this.$t('navbar.' + title)

      return translatedTitle
    }
    return title
  }

}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.el-menu--collapse > li > .el-submenu > .el-submenu__title span,
.el-menu--collapse > li > .el-submenu > .el-submenu__title  .el-submenu__icon-arrow {
  display: none;
}
</style>
