<template>
  <div class="app-wrapper" @mousemove="(e)=>handleMouseMove(e)">
    <navbar @showApp='appShow' />
    <!-- <el-row class="bread-wrapper">
      <breadcrumb/>
    </el-row> -->
    <div class="main-container" v-bind:style="heightObject">
      <app-main/>
    </div>
    <!-- tools -->
    <div class="app-tools tools-face-verification" ref="verification" v-if="showVerification"  :style="{zIndex:toolsZindexVerification}">
      <header class="app-tools-header" @mousedown="(e)=>handleMouseDown(e,'verification')" @mouseup="e=>handleMouseUp(e,'detection')">
        <i class="iconfont icon-drag" ></i>
        <i class="iconfont icon-face-id" ></i>
        <span> {{$t('tools.titleFaceVerify')}}</span>
        <i class="app-tools-header-close el-icon-close" @click="()=>showVerification=false" ></i>
      </header>
      <div class="app-tools-content" >
        <div class="app-tools-content-pics" >
          <ImageSelect @select="(base64)=>compareImagesSelect(base64,1)" />
          <transition name="fade" mode="out-in">
          <div
            v-if="compareScore<0"
            key="compareScore<0"
            @click="compare"
            :class="['app-tools-content-pics-vsbtn',compareStatus ==1?'':'app-tools-content-pics-vsbtn-active']" >
            <span v-if="compareScore === -1" >{{$t('tools.buttonVerify')}}</span>
            <div class="app-tools-content-pics-vsbtn-loading" @click.stop v-show="showCompareLoading" >
              <i class="el-icon-loading" ></i>
            </div>
          </div>
          <div v-else class="app-tools-content-center" key="compareScore>=0" >
            <span class="app-tools-content-pics-vsbtn-score" >
              <span class="app-tools-content-score-txt" >{{((compareScore*100).toFixed(1)).split('.')[0]}}</span> <span class="app-tools-content-score-txt" style="font-size:14px">.{{((compareScore*100).toFixed(1)+'%').split('.')[1]}}</span>
              <div class="app-tools-content-pics-vsbtn-popover"  @click.stop>
                <strong>{{$t('tools.contRatingTitle')}}</strong>
                <p>
                  0 ~ 60%: {{$t('tools.hovmsgRatingRefer.Unmatch')}}
                </p>
                <p>
                  60% ~ 85%: {{$t('tools.hovmsgRatingRefer.Maybe')}}
                </p>
                <p>
                  85% ~ 100%: {{$t('tools.hovmsgRatingRefer.LikelySame')}}
                </p>
              </div>
            </span>
          </div>
          </transition>
          <ImageSelect @select="(base64)=>compareImagesSelect(base64,2)" />
        </div>

        <p class="app-tools-content-pics-txt">
          <span v-if="compareScore === -1 && compareStatus == 1">{{$t('tools.contUploadImage')}}!</span>
          <span v-if="compareScore === -1 && compareStatus == 2">{{$t('tools.contClickCompareImage')}}!</span>
          <span v-else-if="compareScore>=0 && compareScore <= 0.60">{{$t('tools.contVerifyResultUnmatch')}}</span>
          <span v-else-if="compareScore>0.60 && compareScore <= 0.85">{{$t('tools.contVerifyResultLikely')}}</span>
          <span v-else-if="compareScore>0.85 && compareScore <= 1">{{$t('tools.contVerifyResultSame')}}</span>
          <span v-else></span>
        </p>
      </div>
    </div>
    <div class="app-tools app-tools-detection tools-score-detection"  ref="detection" v-if="showDetection" :style="{zIndex:toolsZindexDetection}">
      <header class="app-tools-header"  @mousedown="e=>handleMouseDown(e,'detection')" @mouseup="e=>handleMouseUp(e,'detection')" >
        <i class="iconfont icon-drag" ></i>
        <i class="iconfont icon-face-id" ></i>
        <span> {{$t('tools.titleFaceQuality')}}</span>
        <i class="app-tools-header-close el-icon-close" @click="()=>showDetection = false"></i>
      </header>
      <div class="app-tools-content" >
        <div class="app-tools-content-detection" >
          <ImageSelect @select="detectionSelect" />
          <div class="app-tools-content-detection-right" >
            <transition name="fade" mode="out-in">
            <div
              @click="detect"
              v-if="detectScore<0"
              key="detectScore<0"
              :class="classObjDetection" >
              <span v-if="(detectScore === -1 && detectStatus == 2 ) || detectStatus ==1 ">{{$t('tools.buttonEvaluate')}}</span>
              <span v-if="detectStatus == 3">{{$t('tools.buttonFail')}}</span>
              <div class="app-tools-content-detection-detectbtn-loading" @click.stop v-show="showDetectLoading" >
                <i class="el-icon-loading" ></i>
              </div>
            </div>
            <div v-else class="app-tools-content-center" key="detectScore>=0">
              <span>
                <span class="app-tools-content-score-txt" >{{((detectScore*100).toFixed(1)).split('.')[0]}}</span> <span class="app-tools-content-score-txt" style="font-size:14px">.{{((detectScore*100).toFixed(1)+'%').split('.')[1]}}</span>
              </span>
            </div>
            </transition>
            <div v-if="isSuccessStatus == 0 "></div>
            <div class="app-tools-content-detection-detectresult" v-if="isSuccessStatus == 1 ">
              <strong>{{$t('tools.contEvaluateResult')}}</strong>
              <p>
                <span v-if="detectScore>=0 && detectScore <= 0.30">{{$t('tools.contEvaluateResultLow')}}</span>
                <span v-else-if="detectScore>0.30 && detectScore <= 0.50">{{$t('tools.contEvaluateResultAve')}}</span>
                <span v-else-if="detectScore>0.50 && detectScore <= 1">{{$t('tools.contEvaluateResultHigh')}}</span>
              </p>
              <strong>{{$t('tools.contSuggestion')}}</strong>
              <p>
                <span v-if="detectScore>=0 && detectScore <= 0.30">{{$t('tools.contSuggestionLow')}}</span>
                <span v-else-if="detectScore>0.30 && detectScore <= 0.50">{{$t('tools.contSuggestionAve')}}</span>
                <span v-else-if="detectScore>0.50 && detectScore <= 1">{{$t('tools.contSuggestionHigh')}}</span>
              </p>
            </div>
            <div v-if="isSuccessStatus == 2" style="width: 100%;padding-left: 10px;">
              <strong>{{$t('tools.contEvaluateResult')}}</strong>
              <p>{{$t('tools.contEvaluateResultFail')}}</p>
              <strong>{{$t('tools.contFailReason')}}</strong>
              <p>{{detectErrorResult}}</p>
            </div>
          </div>

        </div>
      </div>
    </div>
    <!-- 人脸表情 -->
    <div class="app-tools app--detection tools-test-detection"  ref="faceVerification" v-if="showTestDetection" :style="{zIndex:toolsZindexFaceDetection}">
      <header class="app-tools-header"  @mousedown="(e)=>handleMouseDown(e,'faceVerification')" @mouseup="e=>handleMouseUp(e,'faceVerification')" >
        <i class="iconfont icon-drag" ></i>
        <i class="iconfont icon-face-id" ></i>
        <span>{{$t('faceStyle.faceText')}}</span>
        <i class="app-tools-header-close el-icon-close" @click="hideFaceDetection"></i>
      </header>
      <div class="app-tools-content" >
        <div class="app-tools-content-detection" >
          <ImageSelect @select="testDetectionImages" />
          <div class="app-tools-content-detection-right" >
            <div
              @click="testDetection"
              :class="classFaceDetection"
              v-if="showTestBtn">
              <span >{{$t('tools.buttonEvaluate')}}</span>
              <div class="app-tools-content-detection-detectbtn-loading" @click.stop v-show="showFaceLoading" >
                <i class="el-icon-loading" ></i>
              </div>
            </div>
            <div v-else>
<!--              小工具：人脸属性检测-->
              <ul>
                <li><span>{{$t('faceStyle.gender')}}:</span>{{$t(genderChange(faceData.gender))}}</li>
                <li><span>{{$t('faceStyle.age')}}:</span>{{$t(ageChange(faceData.age))}}</li>
                <!-- <li><span>{{$t('faceStyle.skinColor')}}:</span>{{$t(skinColorChange(faceData.skinColor))}}</li> -->
                <li><span>{{$t('faceStyle.expression')}}:</span>{{$t(expressionChange(faceData.expression))}}</li>
                <li><span>{{$t('faceStyle.mustacheStyle')}}:</span>{{$t(mustacheStyleChange(faceData.mustacheStyle))}}</li>
                <li><span>{{$t('faceStyle.glassesStyle')}}:</span>{{$t(glassesStyleChange(faceData.glassesStyle))}}</li>
                <!-- <li><span>{{$t('faceStyle.capStyle')}}:</span>{{$t(capStyleChange(faceData.capStyle))}}</li> -->
                <li><span>{{$t('faceStyle.respirator')}}:</span>{{$t(respiratorChange(faceData.respiratorColor))}}</li>
                <li><span>{{$t('faceStyle.Helmet')}}:</span>{{$t(helmetChange(faceData.helmetStyle))}}</li>
                <li><span>{{$t('faceStyle.Cap')}}:</span>{{$t(capChange(faceData.capStyle))}}</li>
              </ul>
            </div>
          </div>

        </div>
      </div>
    </div>
    <!-- tool-end -->

    <!-- global SenseID dialog -->
    <SenseIDDialog />
    <AppCenter :dialogVisible="showAppCenter" @closeAppCenter="closeAppCenter" />
  </div>
</template>

<script lang="ts">
import { Navbar, AppMain } from './submodule';
import ResizeMixin from './mixin/ResizeHandler';
import { Component, Vue ,Watch} from 'vue-property-decorator';
import { mixins } from 'vue-class-component';
import { DeviceType, AppModule } from '@/store/modules/app';
import Breadcrumb from '@/components/bread-crumb/index.vue';
import {EventBus} from '@/utils/eventbus';
import ImageSelect from '@/components/image-select/index.vue';
import {compareTwoFaces,detectQuality ,faceAttributeDetection} from '@/api/tools.ts';
import SenseIDDialog from "@/views/visitor/senseID-dialog/index.vue";
import  AppCenter  from "./appcenter/appcenter.vue";
import { TweenMax } from 'greensock';

@Component({
  components: {
    Navbar,
    AppMain,
    Breadcrumb,
    ImageSelect,
    SenseIDDialog,
    AppCenter
  },
})
export default class Layout extends mixins(ResizeMixin) {
  get classObj() {
    return {
      hideSidebar: !this.sidebar.opened,
      openSidebar: this.sidebar.opened,
      withoutAnimation: this.sidebar.withoutAnimation,
      mobile: this.device === DeviceType.Mobile,
    };
  }

  // handleClickOutside() {
  //   AppModule.CloseSideBar(false);
  // }
  //tools
  @Watch('showVerification', { immediate: true, deep: true })
  onVerificationChange(n,o){
    n && this.initVerificationData();
  }
  @Watch('showDetection', { immediate: true, deep: true })
  onDetectionChange(n,o){
    n && this.initDetectionData();
  }
  $refs!:{
    verification:HTMLFormElement
  };
  toolsZindexVerification:number=9999;
  toolsZindexDetection:number=9999;
  toolsZindexFaceDetection:number=9999;

  showVerification:boolean=false;
  showDetection:boolean=false;
  showTestDetection:boolean=false;
  showAppCenter:boolean=false;
  currentCard:string = '';
  isDown:boolean=false;
  x:number=0;
  y:number=0;
  l:number=0;
  t:number=0;
  compareImages:any[]=new Array(2);
  compareStatus:number=1;//1 不能比对  2可以比对
  compareScore:any=-1;
  showCompareLoading:boolean=false;

  detectionImages:string='';
  testImages:string='';
  showDetectLoading:boolean=false;
  detectStatus:number=1;//1 不能比对   2可检测 3失败且可检测
  detectScore:number=-1;

  showTestBtn :boolean = true;
  showFaceLoading:boolean=false;
  faceStatus:number = 1;
  heightObject ={}

  TweenMax=TweenMax;

  get classObjDetection() {
    return {
      'app-tools-content-detection-detectbtn':true,
      'app-tools-content-detection-detectbtn-active':this.detectStatus != 1 ,
    };
  };
  get classFaceDetection() {
    return {
      'app-tools-content-face-detectbtn':true,
      'app-tools-content-face-detectbtn-active':this.faceStatus != 1 ,
    };
  };
  get isFullScreen(){
    return AppModule.fullScreen
  }
  @Watch('isFullScreen', { immediate: true, deep: true })
  fullScreenChanged(now,old){
    this.mainHeight(now)
  }
  detectResult:any={};
  detectErrorResult:any='';
  isSuccessStatus:number=0;//0 空  1成功信息 2失败信息
  //methods
  // 人脸数据
  faceData :any = {};

  //性别
  genderChange(val) {
    return val == 'female' ? 'faceStyle.female' : 'faceStyle.male'
  }
  // 年龄
  ageChange(val) {
    switch (val) {
      case 'adult':
        return 'faceStyle.adult'
      case 'child':
        return 'faceStyle.child'
      case 'old':
        return 'faceStyle.old'
    }
  }
    //肤色
  skinColorChange(val){
    switch (val) {
      case 'yellow':
        return 'faceStyle.yellow'
      case 'black':
        return 'faceStyle.black'
      case 'white':
        return 'faceStyle.white'
    }
  }
  // 表情
  expressionChange(val) {
    switch (val) {
      case 'st_angry':
        return 'faceStyle.angr'
      case 'st_happy':
        return 'faceStyle.happy'
      case 'st_sorrow':
        return 'faceStyle.sorrow'
      case 'st_calm':
        return 'faceStyle.calm'
      case 'st_surprised':
        return 'faceStyle.surprised'
      case 'st_scared':
        return 'faceStyle.scared'
      case 'st_disgust':
        return 'faceStyle.disgust'
      case 'st_yawn':
        return 'faceStyle.yawn'
      default:
        return 'faceStyle.no'
    }
  }
  //胡子
  mustacheStyleChange(val){
    return val =='whiskers' ? 'faceStyle.yes' : 'faceStyle.no'
  }
  //眼镜
  glassesStyleChange(val) {
    switch (val) {
      case 'glasses_style_type_none':
        return 'faceStyle.no'
      case 'transparent_glasses':
        return 'faceStyle.transparentGlasses'
      case 'sunglasses':
        return 'faceStyle.sunglasses'
    }
  }
  //帽子
  capStyleChange(val){
    // if(val) {
    //   //style-type-none和cap
    //   return val == 'cap' ?  'faceStyle.yes':'faceStyle.no'
    // }else {
    //   return 'faceStyle.no'
    // }
    return val == 'cap' ?  'faceStyle.yes':'faceStyle.no'
  }
  //口罩
  respiratorChange(val) {
    return val == 'color_type_none' ? 'faceStyle.no' : 'faceStyle.yes'
  }

  //安全帽
  helmetChange(val){
    return val == 'st_helmet_style_type_none' ? 'faceStyle.no' : 'faceStyle.yes'
  }
  // 帽子
  capChange(val){
    return val == 'hat_style_type_none' ? 'faceStyle.no' : 'faceStyle.yes'
  }


  mounted(){
    EventBus.$on('layout-tools',this.handleShowTools);
  }
  initVerificationData(){
    this.currentCard = '';
    this.isDown = false;
    this.x=0;
    this.y=0;
    this.l=0;
    this.t=0;
    this.compareImages=new Array(2);
    this.compareStatus=1;
    this.compareScore=-1;
    this.showCompareLoading=false;
  }
  initDetectionData(){
    this.detectStatus = 1;
    this.detectionImages = '';
    this.detectScore=-1;
    this.currentCard = '';
    this.isDown = false;
    this.x=0;
    this.y=0;
    this.l=0;
    this.t=0;
    this.detectResult={};
    this.detectErrorResult='';
    this.isSuccessStatus=0;
    this.detectResult={};
    this.detectErrorResult='';
    this.isSuccessStatus=0;
  }
  handleShowTools(indexType){
    if(indexType == 'tools/face-verification'){
      this.showVerification = true;
      // this.toolsZindexVerification = this.toolsZindexDetection+1;
      this.toolsZindexVerification = this.toolsZindexFaceDetection > this.toolsZindexDetection ?  this.toolsZindexFaceDetection+1 :this.toolsZindexDetection+1;
    }
    if(indexType == 'tools/score-detection'){
      this.showDetection = true;
      // this.toolsZindexDetection=this.toolsZindexVerification+1;
      this.toolsZindexDetection = this.toolsZindexFaceDetection > this.toolsZindexVerification ?  this.toolsZindexFaceDetection+1 :this.toolsZindexVerification+1;
    }
    if(indexType == 'tools/test-detection'){
      this.showTestDetection = true
      this.toolsZindexFaceDetection = this.toolsZindexDetection > this.toolsZindexVerification ?  this.toolsZindexDetection+1 :this.toolsZindexVerification+1;
    }
  }
  handleMouseDown(e,type){
    this.currentCard = type;
    let dv = this.$refs[type];
    this.x = e.clientX;
    this.y = e.clientY;
    this.l = dv?dv.offsetLeft:0;
    this.t = dv?dv.offsetTop:0;
    this.isDown = true;
  }
  handleMouseMove(e){
    if (this.isDown == false) {
        return;
    }
    let dv= this.$refs[this.currentCard];
    let nx = e.clientX;
    let ny = e.clientY;
    let nl = nx - (this.x - this.l);
    let nt = ny - (this.y - this.t);
    dv && (dv.style.left = nl + 'px');
    dv && (dv.style.top = nt + 'px');
  }
  handleMouseUp(e,type){
    this.isDown = false;
    this.$refs[type] && (this.$refs[type].style.cursor = 'default');
  }
  compareImagesSelect(base64,type){
    this.compareScore = -1;
    this.compareImages[type-1] = base64;
    this.validateImagesStatus();
  }
  validateImagesStatus(){
    let images = this.compareImages;
    if(!!images[0] && !!images[1] ){
      this.compareStatus = 2;
    }else{
      this.compareStatus = 1;
    }
  }
  compare(){
    let images = this.compareImages;
    if(!!images[0] && !!images[1] ){
      this.showCompareLoading=true;
      compareTwoFaces(images[0],images[1]).then((res:any)=>{
        this.showCompareLoading=false;
        this.compareScore = res.score;
      }).catch(err=>{
        this.showCompareLoading=false;
        this.compareScore = -1;
      })
    }
  }
  detectionSelect(base64){
    this.detectionImages = base64;
    if(base64){
      this.detectStatus = 2;
    }else{
      this.detectStatus = 1;
    };
    this.detectScore =-1;
    this.isSuccessStatus = 0;
  }
  // 人脸
  testDetectionImages(base64){
    this.testImages = base64;
    // console.log(this.testImages);
    this.showTestBtn = true;

    if(base64){
      this.faceStatus = 2;
    }else{
      this.faceStatus = 1;
    };
  }
  detect(){
    if(this.detectionImages){
      this.showDetectLoading = true;
      detectQuality(this.detectionImages).then((res:any)=>{
        this.isSuccessStatus = 1;
        this.detectScore = res.score;
        this.showDetectLoading = false;
        // if(res.score<0.3){
        //   this.isSuccessStatus=2;
        //   this.detectErrorResult = '图片质量过低或检测不到人脸或图片含有多张人脸';
        // }
      }).catch(error=>{
        this.isSuccessStatus=2;
        this.showDetectLoading = false;
        this.detectScore = -1;
        this.detectStatus = 3;
        let data = error.response.data;
        let code = data.code;
        if(code && code == '418004'){
          this.detectErrorResult = this.$tc('tools.contFailReasonLowerQuality');
        }
        if(code && code == '418005'){
          this.detectErrorResult = this.$tc('tools.contFailReasonNoFace');
        }
        if(code && code == '418006'){
          this.detectErrorResult = this.$tc('tools.contFailReasonLowersize');
        }
        if(code && code == '418007'){
          this.detectErrorResult = this.$tc('tools.contFailReasonOversize');
        }
        if(code && code == '418009'){
          this.detectErrorResult = this.$tc('tools.contFailReasonFaces');
        }
      });
    }
  }

  testDetection(){
    if(this.testImages){
      this.showFaceLoading = true;
      faceAttributeDetection(this.testImages).then(data=>{
        console.log(data);
        this.faceData = data
        this.showTestBtn = false;
        this.showFaceLoading = false;
      }).catch(()=>{
        this.showFaceLoading = false;
        // this.faceStatus = 1;
      }).finally(()=>{
        this.showFaceLoading = false;
      })

    }
  }

  hideFaceDetection() {
    this.showTestDetection = false;
    this.isDown = false;
    this.x=0;
    this.y=0;
    this.l=0;
    this.t=0;
    this.showTestBtn  = true;
    this.faceStatus = 1;
    this.faceData = '';
    this.testImages = '';
  }

  appShow() {
    this.showAppCenter = true;
  }
  closeAppCenter(){
    this.showAppCenter = false;
  }
  mainHeight(hasNav){
    if(hasNav){
      this.heightObject = {
        height:'100%'
      }
    }else{
      this.heightObject = {}
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
  //@import "@/styles/index.scss";
  @import "@/styles/variables.scss";
  .clearfix {
    &:after {
      visibility: hidden;
      display: block;
      font-size: 0;
      content: " ";
      clear: both;
      height: 0;
    }
  }
  .app-wrapper {
    @include clearfix;
    position: relative;
    height: 100%;
    width: 100%;
  }
  .bread-wrapper{
    padding: 16px 24px 0;
  }
  .navbar {
    height: 64px;
    line-height: 64px;
    border-radius: 0px !important;
    .logo{
      padding: 0 10px;
      margin: 0;
      img{
        height: 28px;
        vertical-align: middle
      }
    }
    .hamburger-container {
      line-height: 58px;
      height: 50px;
      float: left;
      padding: 0 10px;
      fill: #fff;
    }
    .screenfull {
      position: absolute;
      right: 90px;
      top: 16px;
      color: red;
    }
    .avatar-container {
      height: 100%;
      display: inline-block;
      position: absolute;
      right: 35px;
      display: flex;
      align-items:center;
      .avatar-wrapper {
        cursor: pointer;
        position: relative;
        line-height: initial;
        display: flex;
        align-items:center;
        font-size:16px;
        color: $--color-white;
        .user-avatar {
          width: 40px;
          height: 40px;
          border-radius: 30px;
        }
        .avatar-name{padding-left: 5px;}
        .el-icon-caret-bottom {
          position: absolute;
          right: -20px;
          top: 15px;
          font-size: 12px;
        }
      }
    }
  }
  .app-main {
    /* 50 = navbar */
    height:100%;
    //min-height: 100%;
    position: relative;
    overflow: hidden;
    background-color: #e5e8ef;
    background: url('/images/bg.svg') no-repeat left top;
    background-size: cover;
  }
  .head_title{
    font-style:normal;
    font-size: 18px;
    -webkit-user-select:none;
    -moz-user-select:none;
    -o-user-select:none;
  }
  .el-menu--horizontal{
    .head_title{font-size: 16px;}
    i.iconfont{margin-right: 8px;}
    // .is-active{
    //   i.iconfont{color: $--color-reserved-1;}
    // }

  }

  .el-menu--horizontal .el-menu .el-submenu{opacity: 0.8;}
  .el-menu--horizontal .el-menu .el-menu-item.is-active i.iconfont,
  .el-menu--horizontal .el-menu .el-submenu.is-active > .el-submenu__title i.iconfont,
  .el-menu--horizontal > .el-submenu.is-active .el-submenu__title i.iconfont{margin-right: 8px;}



  //tools
  .app-tools{
    position: absolute;
    z-index: 9999;
    width: 320px;
    height: 240px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    background-color: $--color-white;
    top: 180px;
    left: calc(50% - 150px);
    .app-tools-content-score-txt{
      font-size:36px;
      color:#9099B7;
      font-weight:300;
    }
    .app-tools-header{
      width: 100%;
      background-color: $--color-top;
      padding:7px 5px;
      position: relative;
      color: white;
      cursor: move;
      .icon-drag{
        font-size: 12px;
        margin-right: 10px;
        color: #9da8b6;
      }
      .app-tools-header-close{
        position: absolute;
        right: 5px;
        top:5px;
        color: white;
        font-size: 18px;
        cursor: pointer;
      }
    };
    .app-tools-content{
      p{
        // text-indent: 16px;
        padding-left: 16px;
      }
      .app-tools-content-pics-txt{
          word-break: break-word;
      }
      .app-tools-content-pics{
        display: flex;
        flex-wrap: nowrap;
        position: relative;
        justify-content: space-between;
        padding:16px;
        .app-tools-content-pics-vsbtn{
          position: absolute;
          z-index: 1;
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background-color: rgb(84, 86, 88);
          border:4px solid rgba(221, 227, 233, .9);
          left: calc(50% - 32px);
          top: calc(50% - 32px);
          color: white;
          text-align: center;
          line-height: 57px;
          transition: all .5s;
          .app-tools-content-pics-vsbtn-loading{
            position: absolute;
            left: -4px;
            top: -4px;
            border-radius: 50%;
            width: 64px;
            height: 64px;
            background-color: rgba(218, 229, 240, 0.4);
            text-align: center;
            line-height: 58px;
            color: black;
          }
        }
        .app-tools-content-pics-vsbtn-popover{
          box-shadow: $--box-shadow-base;
          border-radius: $--border-radius-base;
          width: 345px;
          background-color: $--color-white;
          display: none;
          position: absolute;
          top: 105px;
          left: 130px;
          z-index: 1;
          color: #28354d;
          padding: 5px 5px 10px 5px;
          text-align: left;
          line-height: 24px;
        }
        .app-tools-content-pics-vsbtn-score:hover .app-tools-content-pics-vsbtn-popover{
          display: block;
        }
        .app-tools-content-pics-vsbtn-active{
          background-color: $--color-primary;
          &:hover{
            background-color: rgba(9, 126, 236,1);
          }
          border:4px solid rgba(221, 227, 233, .9);
          cursor: pointer;
          &:active{
            transform: scale(1.1);
          }
        }
      }
      .app-tools-content-center{
        display: inline-flex;
        justify-content: center;
        align-items: center;
        padding: 0px;
        width: 92px;
      }
      .app-tools-content-detection{
        padding: 16px;
        display: flex;
        justify-content: flex-start;
        .app-tools-content-detection-detectbtn{
          position: relative;
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background-color: rgb(84, 86, 88);
          border:4px solid rgba(221, 227, 233, .9);
          color: white;
          text-align: center;
          line-height: 57px;
          transition: all .5s;
          // margin: 10px auto;
          .app-tools-content-detection-detectbtn-loading{
            position: absolute;
            left: -4px;
            top: -4px;
            border-radius: 50%;
            width: 64px;
            height: 64px;
            background-color: rgba(218, 229, 240, 0.4);
            text-align: center;
            line-height: 58px;
            color: black;
          }
        }
        .app-tools-content-detection-detectbtn-active{
          background-color: $--color-primary;
          border:4px solid rgba(221, 227, 233, .9);
          cursor: pointer;
          &:hover{
            background-color: rgba(9, 126, 236,1);
          }
          &:active{
            transform: scale(1.1);
          }
        }
        .app-tools-content-face-detectbtn{
          position: relative;
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background-color: rgb(84, 86, 88);
          border:4px solid rgba(221, 227, 233, .9);
          color: white;
          text-align: center;
          line-height: 57px;
          transition: all .5s;
          // margin: 10px auto;
          .app-tools-content-detection-detectbtn-loading{
            position: absolute;
            left: -4px;
            top: -4px;
            border-radius: 50%;
            width: 64px;
            height: 64px;
            background-color: rgba(218, 229, 240, 0.4);
            text-align: center;
            line-height: 58px;
            color: black;
          }
        }
        .app-tools-content-face-detectbtn-active{
          background-color: $--color-primary;
          &:hover{
            background-color: rgba(9, 126, 236,1);
          }
          border:4px solid rgba(221, 227, 233, .9);
          cursor: pointer;
          &:active{
            transform: scale(1.1);
          }
        }
        .app-tools-content-detection-detectresult{
          width: 100%;
          padding-left: 84px;
          line-height: 18px;
          word-break: break-word;
        }
        .app-tools-content-detection-right{
          display: flex;
          width: 240px;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
      }
    }

  }
  .tools-face-verification{
    width: 350px;
  }
  .app-tools-detection{
    top: 200px;
    left: calc(50% - 120px);
    width: 380px;
    height: 218px;
  }
  .tools-test-detection{
    top: 220px;
    left: calc(50% - 90px);
    width: 380px;
    // height: 218px;
    height: auto;
    ul {
      li {
        // line-height: 20px;
        margin-bottom: 4px;
        display: flex;;
        span {
          // width: 40px;
          margin-right:10px;
        }
      }
    }
  }



  .fade-enter-active, .fade-leave-active {
  transition: opacity .5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

</style>
