<template>
  <div :class="['visitor-image',showImageEle?'':'visitor-image-empty']">
    <img :src="formatSrc" ref="img" v-show="showImageEle" />
    <i class="iconfont icon-people" v-show="!showImageEle" ></i>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {processImgurlForVisitor} from '@/utils/image.ts';

@Component({
  components: {
    
  }
})

export default class VisitorImage extends Vue {
  /* props */
  @Prop({default:''}) src!: string;

  /* watch */
  @Watch('src',{immediate:true})
  onSrcChange(n,o){
    this.formatSrc = '';
    this.showImageEle = false;
    n && this.loadImg(n);
  }

  /* data */
  refs!:{
    img:HTMLFormElement
  };
  formatSrc:string='';
  processImgurlForVisitor:any=processImgurlForVisitor;
  showImageEle:boolean=false;
  /* methods */
  loadImg(src){
    src = processImgurlForVisitor(src);
    let img_ele:any = new Image();
    img_ele.onload = ()=>{
      this.formatSrc = src;
      this.showImageEle = true;
    }
    img_ele.onerror = ()=>{
      this.showImageEle = false;
    }
    img_ele.src = src;
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.visitor-image{
  width: 100%;
  height: 100%;
  background-color: #B3C1D2;
  display: flex;
  justify-content:center;
  align-items:center;
  &>img{
    max-width: 100%;
    max-height: 100%;
    width: 100%;
    margin: 0;
    padding: 0;
    border: 0;
    display: block;
  };
}
.visitor-image-empty{
  background-color: #B3C1D2;  
  border:1px dashed #ccc;
  box-sizing: border-box;
  position: relative;
  .icon-people{
    position: absolute;
    top: 16px;
    left: -14px;
    font-size: 170px;
    color: #6D7C96;
  }
}
</style>