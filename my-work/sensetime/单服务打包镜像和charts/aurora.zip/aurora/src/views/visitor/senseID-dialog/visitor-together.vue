<template>
  <div class="visitor-together">
    <el-dialog
    center
    :show-close="false"
    :visible.sync="visible"
    width="50%"
    :close-on-click-modal="false"
    :before-close="handleClose">
    <span slot="title" style="font-size:24px;font-weight:bold;">{{$t('visitor.senseid.titleTogetherBrush')}}</span>
      
      <div class="visitor-together-content">
        <div>
          <div class="visitor-together-img">
            <VisitorImage :src="reservationDataFormat.idImageUrl" />
          </div>
          <div class="visitor-together-text">
            <el-form :label-width="language == 'en'?'135px':'90px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelName')+':'">
                <div class="visitor-together-formtext" >{{reservationDataFormat.name}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelIdnumber')+':'">
                <div class="visitor-together-formtext" >{{reservationDataFormat.idNumber}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelNation')+':'">
                <div class="visitor-together-formtext" >{{reservationDataFormat.nation}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelAdress')+':'">
                <div class="visitor-together-formtext" >{{reservationDataFormat.address}}</div>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <div style="position:relative;">
          <span style="position:absolute;top:-20px;">{{$t('visitor.senseid.constTogether')}}</span>
          <div class="visitor-together-img">
            <VisitorImage :src="togetherData.guestLog.idImageUrl" />
          </div>
          <div class="visitor-together-text">
            <el-form :label-width="language == 'en'?'135px':'90px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelName')+':'">
                <div class="visitor-together-formtext" >{{togetherData.guestLog.name}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelIdnumber')+':'">
                <div class="visitor-together-formtext" >{{togetherData.guestLog.idNumber}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelNation')+':'">
                <div class="visitor-together-formtext" >{{togetherData.guestLog.nation}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelAdress')+':'">
                <div class="visitor-together-formtext" >{{togetherData.guestLog.address}}</div>
              </el-form-item>
            </el-form>
          </div>
          <i class="iconfont icon-renzhengbufu" v-show="togetherData.guestLog && (togetherData.guestLog.verifyResult == 1 || togetherData.guestLog.verifyResult == 2)" style="font-size:80px;color:#BE0000;position:absolute;right:0;bottom:-25px;" ></i>
        </div>
      </div>

      <span slot="footer">
        <el-button @click="handleRebrush" type="primary" v-if="togetherData.guestLog && (togetherData.guestLog.verifyResult == 1 || togetherData.guestLog.verifyResult == 2)">{{$t('visitor.senseid.btnRebrush')}}</el-button>
        <el-button v-else @click="agree" :loading="loading" :disabled="!data" v-show="$permission('021303')" type="success">{{$t('visitor.senseid.btnApproveVisit')}}</el-button>
        <el-button @click="cancel" type="info" >{{$t('visitor.senseid.btnCancel')}}</el-button>  
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import VisitorImage from './components/visitor-image.vue';
import api from '@/api/visitor.ts';
import {Cache} from '@/utils/cache';
import {EventBus} from '@/utils/eventbus';
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    VisitorImage
  }
})
export default class VisitorTogether extends Vue {//同行
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:false}) data!: any;
  @Prop({default:false}) reservationData!: any;
  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.initData();
  }
  @Watch('data',{immediate:true,deep:true})
  onDataChange(n,o){
    n == null && this.formatDataEmpty('together');
    n && (this.togetherData = n);
  }
  @Watch('reservationData',{immediate:true,deep:true})
  onReservationDataChange(n,o){
    n == null && this.formatDataEmpty('reservation');
    n && (this.reservationDataFormat = n);
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  togetherData:any={
    guestLog:{
      idImageUrl:'',
      name:'',
      idNumber:'',
      nation:'',
      address:''
    }
  };
  reservationDataFormat:any={
    idImageUrl:'',
    name:'',
    idNumber:'',
    nation:'',
    address:'',
    libraryId:'',
    activationTime:'',
    expirationTime:'',
    visitPurpose:'',
    phone:'',
    unawaresName:'',
  };
  loading:boolean=false;
  /* methods */
  initData(){
    this.loading = false;
    if(!this.reservationData){
      this.reservationDataFormat = {
        idImageUrl:'',
        name:'',
        idNumber:'',
        nation:'',
        address:''
      }
    };
    this.togetherData={
      guestLog:{
        idImageUrl:'',
        name:'',
        idNumber:'',
        nation:'',
        address:''
      }
    };
  }
  formatDataEmpty(v){
    v == 'together' && (this.togetherData = {
      guestLog:{
        idImageUrl:'',
        name:'',
        idNumber:'',
        sex:0,
        address:''
      }
    });
    v == 'reservation' && (this.reservationDataFormat = {
      idImageUrl:'',
      name:'',
      idNumber:'',
      sex:0,
      address:'',
      libraryId:'',
      activationTime:'',
      expirationTime:'',
      visitPurpose:'',
      phone:'',
      unawaresName:'',
    });
  }
  handleClose(){
    this.$emit('close')
  }
  handleRebrush(){
    this.$emit('rebrush')
  }
  cancel(){
    this.handleClose();
  }
  agree(){
    this.loading = true;
    this.agreeVisitor(1).then(e=>{
      this.handleClose();
      EventBus.$emit('visitor-seneid-dialog-closetogether')
    }).catch(e=>{
      this.loading = false;
      e.response.data.code == '421013' && this.handleClose();//others already operate close the dialog
    }).finally(()=>{
      this.loading = false;
    });
  }
  agreeVisitor(pass){//pass --> 1允许 2不允许; type --> 1 预约访客 2临时访客 3同行访客;
    const user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
    return api.addVisitorRecord({
      pass,
      type:3,
      libraryId:this.reservationData.libraryId||'',
      activationTime:this.reservationData.activationTime||'',
      expirationTime:this.reservationData.expirationTime||'',
      visitPurpose:this.reservationData.visitPurpose||'',
      phone:this.reservationData.phone||'',
      unawaresName:this.reservationData.unawaresName||'',
      guestId:this.reservationData.guestId||'',
      guestCode:this.reservationData.guestCode||'',
      //ws info
      idNumber:this.data.guestLog.idNumber,
      guestLogId:this.data.guestLog.guestLogId,
      name:this.data.guestLog.name,
      floorId:this.data.floorId,
      deviceId:this.data.deviceId,
      deviceGroupId:this.data.deviceGroupId,
      updateBy:user.userId || ''
    });
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.visitor-together-content{
  display: flex;
  justify-content:space-between;
  width: 100%;
  padding-top: 24px;
  &>div{
    width: 50%;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    .visitor-together-img{
      width: 144px;
      height: 192px;
    }
    .visitor-together-text{
      padding-left: 16px;
      position: relative;
      .visitor-together-formtext{
        max-width: 200px;
        // overflow: hidden;
        // text-overflow:ellipsis;
        // white-space: nowrap;
        word-wrap:break-word;
      }
      .el-form-item{
        margin-bottom: 0;
        
        .el-form-item__label,.el-form-item__content{
          line-height: 22px;
        }
      }
      .icon-renzhengbufu{
        position: absolute;
        right: 0;
      }
    }
  }
}
</style>