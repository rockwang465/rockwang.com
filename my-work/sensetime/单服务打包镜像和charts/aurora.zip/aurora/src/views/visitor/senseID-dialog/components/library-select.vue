<template>
  <div class="library-select">
    <el-popover
      ref="library-select-popover"
      placement="bottom"
      trigger="click">
      <div slot="reference"  class="library-select-selected" >
        <el-input type="text" :placeholder="$t('rule.contPleaseSelect')" readonly v-model="inputText" />
      </div>
      <div class="library-select-content">
        <div >
          <el-tree
            :data="data"
            node-key="id"
            ref="tree"
            class="library-select-tree"
            default-expand-all
            :render-content="renderContent"
            >
          </el-tree>  
        </div>
      </div>
    </el-popover>
  </div>
</template>

<script lang="tsx">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import i18n from '@/lang/index';
import api from '@/api/visitor.ts';

@Component({
  components: {
    
  }
})

export default class LibrarySelect extends Vue {
  /* props */

  /* watch */
  @Watch('radioModel', { immediate: false, deep: false }) 
  onradioModelChanged(val: any, oldVal: any) {
    this.radioChange(val);
  }
  /* data */
  data:any=[];
  radioModel:any={};
  inputText:string="";
  /* methods */ 
  mounted() {
    this.initData();
    api.getLibsList().then(res=>{
      this.formatListToTree(res)
    }) 
  }
  initData(){
    this.data = [];
    this.data.push({
      id:-1,
      label:i18n.t('rule.contWhitelist'),
      children:[]
    });
    // this.data.push({
    //   id:-2,
    //   label:'黑名单',
    //   children:[]
    // });
  }
  renderContent(h,{node,data,store}){ 
    node.isLeaf = data.id> 0;
    return  data.id > 0?<el-radio v-model={this.radioModel} label={data} ><span title={data.label}>{data.label}</span></el-radio>
                          :<span title={data.label}>{data.label}</span>
  }
  radioChange(currentLabel){
    if(currentLabel && currentLabel.id){
      this.$emit('check',currentLabel);
      this.inputText = currentLabel.label;
    }else{
      this.inputText = this.$tc('rule.contPleaseSelect');
    }
  }
  formatListToTree(res){
    res.whitelists && res.whitelists.map(lib_white=>{
      this.data[0].children.push({
        id:lib_white.libraryId,
        label:lib_white.libraryName
      })
    });
    // res.blacklists && res.blacklists.map(lib_black=>{
    //   this.data[1].children.push({
    //     id:lib_black.libraryId,
    //     label:lib_black.libraryName
    //   })
    // });
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.library-select-content{
  max-height: 200px;
  overflow: auto;
}
</style>