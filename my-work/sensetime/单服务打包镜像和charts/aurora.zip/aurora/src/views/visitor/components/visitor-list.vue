<template>
    <div class="visitor-list-container">
        <div class="top-switch">
          <el-button v-show="batchHandle" @click="batchHandle = false" class="add-visitor-btn" icon="iconfont icon-fanhui visitor-list-icon-back" type="text"></el-button>
          <el-button
            v-if="$permission('021301') && !batchHandle"
            class="add-visitor-btn"
            @click="addNewVisitor"
            size="medium"
            type="primary">
            <Icon
              size="12"
              name="plus-square"
            />
            <!--预约访客-->
            {{$t('visitor.visitorlist.labelAddReserve')}}
          </el-button>
          <el-button
            v-show="!batchHandle && $permission('021410')"
            @click="batchHandle = true"
            class="add-visitor-btn"
            size="medium"
            icon="iconfont icon-batch-handle"
            type="primary">
            {{$t('visitor.visitorlist.buttonBatch')}}
            <!-- iconfont icon-fanhui rule-list-td-back -->
          </el-button>
          <el-button
            v-if="$permission('021410') && batchHandle"
            class="add-visitor-btn"
            icon="el-icon-delete"
            size="medium"
            @click="deleteB"
            :disabled="checkedGuestIds.length <= 0"
            :loading="deleteLoading"
            type="danger">
            <!-- v-if="$permission('021410')" 批量删除权限码 -->
            {{$t('visitor.visitorlist.buttonBatchDelete')}}
          </el-button>
          <VisitorExport
            :count="count"
            :visitType="visitType"
            :visitState="visitState"
            :startTime="visitorReqParams.startTime"
            :endTime="visitorReqParams.endTime"
            :keywords="keywordParams.keywords"
            v-show="!batchHandle">

          </VisitorExport>
          <el-popover
            placement="bottom-start"
            width="371"
            trigger="click">
            <div style="font-size: 14px;">
              <div style="font-weight: bolder;">
                {{$t('visitor.explain.explain1')}}
              </div>
              <br>
              <div>
                <i class="iconfont icon-jiantou"></i>
                {{$t('visitor.explain.explain2')}}
              </div>
              <div>
                <i class="iconfont icon-jiantou"></i>
                {{$t('visitor.explain.explain3')}}
              </div>
            </div>
            <div slot="reference" class="explain-btn"> {{$t('visitor.explain.btn')}}</div>
          </el-popover>



        </div>
        <div class="visitor-list" style="height: calc(100% - 66px);">
            <div class="condition-filter">
            <el-checkbox v-if="batchHandle" :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">{{''}}</el-checkbox>
                <div v-if="onVisitHistory" class="condition-filter-item">
                  <!--访客类型-->
                    <span class="filter-title">{{$t('visitor.visitorlist.titleVisitorType')}}</span>
                    <el-select @change="onVisitTypechange" v-model="visitType" placeholder="">
                        <el-option
                        v-for="item in visitTypes"
                        :key="item.value"
                        :label="$t(item.label)"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div class="condition-filter-item">
                  <!--访客状态-->
                  <span class="filter-title">{{$t('visitor.visitorlist.VisitorStatus')}}</span>
                  <el-select @change="onVisitStatechange" v-model="visitState" placeholder="">
                    <el-option
                      v-for="item in visitStates"
                      :key="item.value"
                      :label="$t(item.label)"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </div>
                <div class="condition-filter-item">
                  <!--访问时间-->
                    <span class="filter-title">{{$t('visitor.visitorlist.titleVisitTime')}}</span>
                    <el-date-picker
                      style="width: 350px"
                        v-model="visitTime"
                        size="small"
                        type="datetimerange"
                        :start-placeholder="$t('visitor.visitorlist.labelStartTime')"
                        :end-placeholder="$t('visitor.visitorlist.labelEndTime')"
                        @change="onVisitTimechange"

                    >
                    </el-date-picker>
                </div>
              <div class="condition-filter-item input-box" style="margin-left: auto;margin-right: 0;">
                <!--支持访客姓名/访客身份证号/用户名-->
                <!--<span class="filter-title"> &nbsp; </span>-->
                <el-input style="width: 270px;" :placeholder="$t('visitor.visitorlist.titleSearchTips')"
                          @focus="inputFocus"
                          @blur="inputBlur"
                          v-model="visitorReqParams.keyWord">
                  <i slot="suffix" v-show="showSearchClose" @click="handleClearSearch" class="el-input__icon el-icon-circle-close"></i>
                  <i slot="suffix" @click="handleSearch" class="el-input__icon iconfont icon-search" style="color: #000"></i>
                </el-input>
              </div>
            </div>
            <div class="visitor-list-content" v-loading="loading">
              <el-checkbox-group v-model="checkedGuestIds" @change="handleCheckedGuestChange">
                <el-checkbox v-for="item in visitList" :class="!batchHandle?'visitor-list-content-checkbox-box':''" :label ="item.guestId" :key="item.guestId" >
                <div  @click="handleListClick(item)" class="list-item-container" v-bind:class="[{isCurrent:currentVisitId==item.guestId} , item.statusClass]" >
                    <div class="picture list-item">

                        <img :src="processImgurl(item.idImageUrl) ||'images/user-01.png'"/>
                    </div>
                    <div class="list-item">

                        <p>
                            <b>{{$t('visitor.senseid.labelName')}}：</b>
                            <span>{{item.name}}</span>
                        </p>
                        <p>
                            <b>{{$t('visitor.senseid.labelIdnumber')}}：</b>
                            <span>{{item.idNumber}}</span>
                        </p>
                        <p>
                            <b>{{$t('visitor.senseid.labelContact')}}：</b>
                            <span>{{item.phone}}</span>
                        </p>
                        <p>
                            <b>{{$t('visitor.visitorlist.labelCarNumber')}}：</b>
                            <span>{{item.vehicleNumber}}</span>
                        </p>
                    </div>
                    <div class="list-item">
                        <p>{{item.type==1?$t('visitor.senseid.titleReservation'):$t('visitor.senseid.titleTemporary')}}</p>
                    </div>
                    <div class="list-item">
                        <p>
                          <b>{{$t('visitor.senseid.labelPurpose')}}：</b>
                          <span>{{visitPurpose[item.visitPurpose]}}</span>
                        </p>
                        <p v-if="item.createByName">
                          <b>{{$t('visitor.senseid.labelAdd')}}：</b>
                          <span>{{item.createByName}}</span>
                        </p>
                        <!--<p v-if="item.unawaresName">-->
                          <!--<b>{{$t('visitor.senseid.labelRecepter')}}：</b>-->
                          <!--<span>{{item.unawaresName}}</span>-->
                        <!--</p>-->
                    </div>
                    <div class="list-item">
                        <p v-if="item.entryName">
                          <!--到访入口-->
                        <b >{{$t('visitor.visitorlist.labelVisitorEntrance')}}：</b>
                        <span>{{item.entryName}}</span>
                        </p>
                        <p v-if="onVisitHistory">
                            <b>{{$t('visitor.visitorlist.labelVisitorTime')}}：</b>
                            <span>{{item.visitTime}}</span>
                        </p>
                        <p v-else>
                            <b>{{$t('visitor.visitorlist.labelVisitorTime')}}：</b>
                            <span>{{item.activationTime}}</span>
                        </p>
                        <p v-if="item.peerVisitorNum">
                          <!--同行访客-->
                        <b>{{$t('visitor.senseid.constTogether')}}：</b>
                        <span>{{item.peerVisitorNum}}</span>
                        </p>
                    </div>

                    <div class="visitorType list-item">

                      <!--等待到访-->
                      <div v-if="item.status==1">{{$t('visitor.visitorlist.Reserved')}}</div>
                      <!--已到访-->
                      <div v-else-if="item.status==2">{{$t('visitor.visitorlist.Visiting')}}</div>
                      <!--预约失效-->
                      <div v-else-if="item.status==3">{{$t('visitor.visitorlist.Expired')}}</div>

                    </div>
                </div>
                </el-checkbox>
              </el-checkbox-group>
            </div>
            <!-- </el-checkbox-group> -->
            <el-pagination
                class="pagination"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageNumber"
                :page-sizes="[10, 20, 30 , 50,100]"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage">
            </el-pagination>
          <VisitorAdd @onFreshList="fetchVisitList" @closeVisitorAdd="closeVisitorAdd" :dialogVisible="isVisitorAdd"></VisitorAdd>

        </div>
    <!-- messageBox delete -->
    <el-dialog
      :visible="showDeleteDialog"
      :before-close="()=>this.showDeleteDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{$t('visitor.visitorlist.popmsgRulesetDelete')}}</p>
      <div slot="title" >
        <span>{{$t('rule.listDelete')}}</span>
      </div>
      <span slot="footer">
        <el-button type="danger" :loading="ensureLoading" @click="()=>ensureDelete()">{{$t('visitor.visitorlist.buttonOperationDelete')}}</el-button>
        <el-button @click="showDeleteDialog = false" type="info">{{$t('visitor.visitorlist.btnCancel')}}</el-button>
      </span>
    </el-dialog>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import  Icon from '@/components/icon-wrap/index.vue';
import visitorApi from '@/api/visitor';
import dayjs from "dayjs"
import EditAddGroup from "@/components/deviceUserAdd/editAddGroup.vue";
import {DeviceModule} from '@/store/modules/device';
import TreeInput from '@/components/tree-input/index.vue';
import historyApi from '@/api/history-record';
import { processImgurl } from '@/utils/image.ts';
import {visitorSelectData} from '@/utils/constants';
import VisitorExport from './visitor-export.vue';
import VisitorAdd from './visitor-add.vue';
import {isEmpty} from '@/utils/validate';
import {EventBus} from '@/utils/eventbus';


import i18n from '@/lang/index';

// let unselected = i18n.t('visitor.senseid.titleUnselected')
// let reservation = i18n.t('visitor.senseid.titleReservation')
// let temporary = i18n.t('visitor.senseid.titleTemporary')

//访客状态  预约信息 到访记录
enum ListType {
    bespeak=1,
    visit=2,
}
// enum visitPurpose {
//     "面试"=1,
//     "会议",
//     "活动",
//     "家长",
//     "其他",
// }
//请求参数
interface visitorReqParams {
    endTime?:string|null;
    floorId?:number[]|null;
    pageNum:number;
    pageSize:number;
    startTime?:string|null;
    state:number;
    type?:number|null;
    keyWord?:string;
}

@Component({
  components: {
    Icon,
    TreeInput,
    VisitorExport,
    VisitorAdd
  }
})
export default class VisitorListContainer extends Vue {
  //visitPurpose=visitorSelectData;
  get visitPurpose(){
    //console.log(visitorSelectData)
    return visitorSelectData
  }
    // visitPurpose=visitPurpose;
    count = null;
    loading = false;
    totalPage=0;
    locationList=[];
    currentVisitId:number | null = null;
    statusClass= '';
    visitList:any=[];
    pageNumber=1;
    pageSize=10;
    processImgurl:any  = processImgurl;
    onVisitHistory:boolean=true;//表示是否在访客记录页面
    visit:ListType=ListType.visit; //visit表示访客记录
    bespeak:ListType=ListType.bespeak; //表示预约访客
    //过滤条件 类型 区域 时间
    visitType:null| number=null;
    visitState:null| number=null;
    visitArea:string="";
    visitTime:string[]=[];
    //访客类型
    visitTypes=[
        {value:null,label:'visitor.senseid.titleUnselected'},
        {value:1,label:'visitor.senseid.titleReservation'},
        {value:2,label:'visitor.senseid.titleTemporary'},
    ]
  //访客状态
    visitStates=[
      {value:null,label:'visitor.senseid.titleUnselected'},
      {value:1,label:'visitor.visitorlist.Reserved'},
      {value:2,label:'visitor.visitorlist.Visiting'},
      {value:3,label:'visitor.visitorlist.Expired'},
    ]
    // visitTypes=[
    //     {value:null,label:unselected},
    //     {value:1,label:reservation},
    //     {value:2,label:temporary},
    // ]
    //获取访客列表初始参数
    visitorReqParams:visitorReqParams={
        pageNum:this.pageNumber,
        pageSize:this.pageSize,
        // state:this.visit, //状态默认访客记录 visit  ,bespeak为预约信息
        state:null, //状态默认访客记录 visit  ,bespeak为预约信息
        endTime:null,
        startTime:null,
        floorId:null,
        type:null,
        keyWord:"",
    } as any;
    keywordParams = {
      keywords:''
    } as any;
    isVisitorAdd = false;
    focusEnter = false;//控制搜索
    showSearchClose = false//控制搜索

    @Watch('visitorReqParams.keyWord')
    onKwordChange(val: any) {
      if (val) {
        this.showSearchClose = true;
      }
      if (val == ''){
        this.showSearchClose = false;
        this.fetchVisitList();
      }
    }

    mounted(){
        this.fetchVisitList();
        EventBus.$on('new-visitor',()=>{
          this.fetchVisitList();
        });
    }


    //获取位置列表
    fetchLocation(val){
        if(!this.locationList.length){
        historyApi.fetchLocation().then((data)=>{
            this.locationList = data.data
        })
        }
    }
      // //选择访客区域
    checkoutLocation(ids){
        this.visitorReqParams.floorId=ids
        this.fetchVisitList()
    }
    //关键字检索
    handleSearch(){
        this.fetchVisitList()
    }
    handleClearSearch(){
      this.visitorReqParams.keyWord = '';
      this.keywordParams.keywords = '';
      this.fetchVisitList()
    }
    //列表点击的处理函数
    handleListClick(obj){
        this.$emit("onDatachange",obj)
        this.currentVisitId = obj.guestId;
    }


     fetchVisitList(){
         //初始化页码
        this.pageNumber=1;
        this.visitorReqParams.pageNum=this.pageNumber
        this.fetchVisitListRequest()
     }
    //请求访客列表
    fetchVisitListRequest(){
        this.isIndeterminate = false;
        this.loading = true;
        this.checkAll = false;
        this.checkedGuestIds = [];
        this.keywordParams.keywords = this.visitorReqParams.keyWord;


        visitorApi.getVisitorList(this.visitorReqParams).then((obj)=>{


          this.visitList=(obj as any).list;
          if (this.visitorReqParams.state === null&&this.visitorReqParams.startTime === null&&this.visitorReqParams.type === null&&this.visitorReqParams.keyWord === ''){
            this.count = this.visitList.length;
          }
          this.visitList.map((item)=>{
              item.statusClass = "status"+item.status;
            })

            this.totalPage=(obj as any).total;

            if(this.visitList[0]){
                this.currentVisitId = (this.visitList[0] as any).guestId;
            }
            this.$emit("onDatachange",this.visitList[0]);
        }).finally(()=>{
          this.loading = false;
        })
        this.$emit("filterParams",this.visitorReqParams);
    }


    //选择访客类型
    onVisitTypechange(val){
        this.visitorReqParams.type=val;
        this.fetchVisitList()
    }

    //选择访客状态
  onVisitStatechange(val){
    this.visitorReqParams.state=val;
    this.fetchVisitList()
  }



    //选择访问时间
    onVisitTimechange(val){
        if(val){
            this.visitorReqParams.startTime=dayjs(val[0]).format('YYYY-MM-DD HH:mm:ss')
            this.visitorReqParams.endTime=dayjs(val[1]).format('YYYY-MM-DD HH:mm:ss')
        }else{
            this.visitorReqParams.startTime=null;
            this.visitorReqParams.endTime=null;
        }
        this.fetchVisitList()
    }

    inputFocus(){
      this.focusEnter = true;
      let that = this as any;
      window.document.onkeydown = function(event){
        if (that.focusEnter) {
          if (event.keyCode == 13){
            that.fetchVisitList();
          }
        }
      }
    }

    inputBlur(){
      this.focusEnter = false;
    }

    //切换面板
    // switchVisitorList(type){
    //     if(type==this.visit){
    //         this.onVisitHistory=true;
    //         this.visitorReqParams.state=this.visit
    //     }else{
    //         this.onVisitHistory=false;
    //         this.visitorReqParams.state=this.bespeak;
    //         //访客类型
    //         this.visitorReqParams.type=null;
    //         this.visitType=null;
    //     }
    //
    //     this.fetchVisitList()
    // }

    handleSizeChange(val){
        this.pageSize=val
        this.visitorReqParams.pageSize=val
        this.fetchVisitList()
    }
    handleCurrentChange(val){
        this.pageNumber=val
        this.visitorReqParams.pageNum=val
        this.fetchVisitListRequest()
    }

    //新建预约
    closeVisitorAdd(){
      this.isVisitorAdd = false;
    }
    fetchVisitListInit(){
      this.$emit("onFreshList")
    }
    addNewVisitor() {
      this.isVisitorAdd = true
    }

    //批量删除
    disabledDelete:boolean=false;
    checkedGuestIds:any[]=[];
    isIndeterminate:boolean=false;
    checkAll: boolean= false;
    deleteLoading:boolean=false;
    showDeleteDialog:boolean=false;
    ensureLoading:boolean=false;
    batchHandle:boolean=false;
    @Watch('batchHandle')
    onBatchHandleChange(val){
      this.isIndeterminate = false;
      this.checkAll = false;
      this.checkedGuestIds = [];
    }
    deleteB(){
      this.checkedGuestIds.length > 0 && (this.showDeleteDialog = true);
    }
    ensureDelete(){
      this.ensureLoading = true;
      this.deleteReservationBatch();
    }
    deleteReservationBatch(){
      this.deleteLoading = true;
      let guestIds = this.checkedGuestIds;
      visitorApi.deleteGuestBatch({guestIds}).then((e)=>{
        this.$message({
          showClose: true,
          message: this.$tc('visitor.visitorlist.tipsDeleteRecordSuccess'),
          type: 'success'
        });
        this.fetchVisitList()
      }).finally(()=>{
        this.ensureLoading = false;
        this.showDeleteDialog=false;
        this.deleteLoading = false;
      });
    }
    handleCheckedGuestChange(val){
      let checkedCount = val.length;
      this.checkAll = checkedCount === this.visitList.length;
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.visitList.length;
    }
    handleCheckAllChange(val){
      this.checkedGuestIds = val ? this.visitList.map(item=>item.guestId) : [];
      this.isIndeterminate = false;
    }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
    .visitor-list-container{
      height: 100%;
        .top-switch{
          border-bottom:2px solid $--color-primary;
          display:flex;
          margin:0 4px;
          justify-content:flex-start;
          align-items:flex-end;
          box-sizing: border-box;
          .switch-btns{
              .switch-btn{
                  display:inline-block;
                  padding:7px 16px;
                  border-radius:2px 2px 0 0 ;
                  cursor:pointer;
              }
              .onfocus{
                  background: $--color-primary;
                  color:#fff;
              }
          };
          .input-box{
              padding:4px;
            width: 300px;
              i:hover{
                  cursor:pointer;
              }
          };
          .add-visitor-btn{
            margin: 0 8px 8px 0;
          }
          .explain-btn{
            height: 36px;
            line-height: 36px;
            margin: 0 0 8px 30px;
            cursor: pointer;
            font-size:14px;
            font-family:Source Han Sans CN;
            font-weight:bold;
            color:rgba(1,28,80,1);
            text-decoration:underline;
          }
          .content{
            width: 100px;
            font-size: 16px;
            font-weight: 500;
          }
        }
        .visitor-list{
            .condition-filter{
                display:flex;
                padding:8px;
                .el-checkbox{
                  margin-right: 0;
                  line-height: 32px;
                }
                .condition-filter-item{
                    margin-right:8px;
                  display: flex;
                  align-items: center;
                    .filter-title{
                        padding-right:4px;
                      /*width: 100px;*/
                      min-width: 60px;
                    }
                  >div{
                    width: 130px;
                  }
                }
            }
            .visitor-list-content{
                height: calc(100% - 91px);
                overflow-y:scroll;
                .el-checkbox{
                  margin-right: 0;
                  position: relative;
                  display: flex;
                  .el-checkbox__input{
                    /*position: absolute;*/
                    /*top: calc(50% - 8px);*/
                    /*left: 6px;*/
                    margin-top: 49px;
                    margin-left: 8px;
                  }
                  .el-checkbox__label{
                    display: block;
                    width: 100%;
                    /*padding: 6px;*/
                  }
                }
                .list-item-container{
                  color: #011C50;
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                    background:#fff;
                    margin-bottom:16px;
                    cursor:pointer;
                    transition:all .5s;
                    position: relative;
                    background:rgba(255,255,255,1);
                    box-shadow:0px 3px 6px rgba(0,0,0,0.16);
                    opacity:1;
                    border-radius:4px;
                    overflow: hidden;
                    .list-item{
                        overflow:hidden;
                    };
                    .list-item:nth-child(1){
                        // flex-grow:1;
                        width:14%;
                    };
                     .list-item:nth-child(2){
                        // flex-grow:1;
                        width:25%;
                    };
                    .list-item:nth-child(3){
                        // flex-grow:1;
                        width:10%;
                    };
                    .list-item:nth-child(4){
                        // flex-grow:1;
                        width:15%;
                    };
                    .list-item:nth-child(5){
                        // flex-grow:1;
                        width:25%;
                    };
                    .list-item:nth-child(6){
                        // flex-grow:1;
                        width:6%;
                    };
                    &:hover{
                        background:#fff;
                        margin-left:5px;
                    }
                    &::before{
                      content: "";
                      position: absolute;
                      left: 0;
                      top: 0;
                      width: 4px;height: 100%;
                      background-color: #0F9D58;
                    }
                    p{
                        padding:4px;
                      /*display: flex;*/
                      /*b{*/
                        /*display: block;*/
                        /*width: 55%;*/
                        /*text-align: right;*/
                      /*}*/
                    }
                    .visitorType{
                        margin-right:16px;
                        // .bespeak{
                        //     color:#0F9D58;
                        // }
                    }
                    .picture{
                        height:112px;
                        padding:8px 16px;
                        padding-left: 32px;
                        img{
                          height:100%;
                        }
                    }
                }
                .status4{
                  &::before{
                    background-color: #BE0000;
                  }
                }
                .status3{
                  color: #909191;
                  .picture img{
                    opacity: 0.6;
                  }
                  &::before{
                    background-color: #909191;
                  }
                }

                .isCurrent{
                    /*background:#EAF4FF;*/
                    background:#fff;
                }
                .visitor-list-content-checkbox-box{
                  .el-checkbox__input{
                    display: none;
                  }
                }
            }
            .pagination{
                text-align: center;
                padding-top:8px;
            }
        }

    }
    .visitor-list-icon-back{
      color:#000;
      font-weight: 600;
    }
    ::v-deep .visitor-list-content .checkbox-group .el-checkbox{
      display: block;
      margin-right: 0;
    }
// ::v-deep .el-input__suffix-inner{
//   width: 30px;
//   display: flex;
//   align-items: center;
// }图标偏上
::v-deep .el-icon-circle-close{
  position: relative!important;
  margin-left: -50px!important;
}
</style>
