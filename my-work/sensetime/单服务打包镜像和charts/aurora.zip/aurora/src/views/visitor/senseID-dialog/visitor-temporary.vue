<template>
  <div class="visitor-temporary">
    <el-dialog
    center
    :show-close="false"
    :visible.sync="visible"
    width="65%"
    :close-on-click-modal="false"
    :before-close="handleClose">
    <span slot="title" style="font-size:16px;font-weight:bold;">{{$t('visitor.senseid.titleTemporary')}}</span>

      <div class="visitor-temporary-content">
        <div>
          <div class="visitor-temporary-img">
            <VisitorImage :src="temporaryData.guestLog.idImageUrl" />
          </div>
          <div class="visitor-temporary-text">
            <el-form :label-width="language == 'en'?'135px':'90px'" label-position="left" style="width:300px;" class="visitor-form" >
              <el-form-item :label="$t('visitor.senseid.labelName')+':'">
                <span :title="temporaryData.guestLog.name" >{{temporaryData.guestLog.name}}</span>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelIdnumber')+':'">
                <span :title="temporaryData.guestLog.idNumber">{{temporaryData.guestLog.idNumber}}</span>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelNation')+':'">
                <span :title="temporaryData.guestLog.nation">{{temporaryData.guestLog.nation}}</span>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelAdress')+':'">
                <span :title="temporaryData.guestLog.address">{{temporaryData.guestLog.address}}</span>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <div>
          <div class="visitor-temporary-form">
            <el-form :label-width="language == 'en'?'130px':'90px'" label-position="left" style="width:300px;" class="visitor-form">
              <el-form-item :label="$t('visitor.senseid.labelActiveTime')+':'">
                <span :title="temporaryData.guest?temporaryData.guest.activationTime:''">{{temporaryData.guest?temporaryData.guest.activationTime:''}}</span>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelInvalidTime')+':'">
                <span :title="temporaryData.guest?temporaryData.guest.expirationTime:''">{{temporaryData.guest?temporaryData.guest.expirationTime:''}}</span>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelLibrary')+':'">
                <div v-if="temporaryData.guest && temporaryData.libraryNames" class="visitor-temporary-form-libraryNames">
                  <p v-for="(libraryName,libraryNameIndex) in temporaryData.libraryNames" :title="libraryName|| ''" :key="libraryNameIndex">{{libraryName||''}}</p>
                </div>
                <!-- <span :title="temporaryData.guest?temporaryData.libraryName:''">{{temporaryData.guest?temporaryData.libraryName:''}}</span>  -->
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelContact')+':'">
                <span :title="temporaryData.guest?temporaryData.guest.phone:''">{{temporaryData.guest?temporaryData.guest.phone:''}}</span>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelPurpose')+':'">
                <span :title="visitorSelectData[temporaryData.guest?temporaryData.guest.visitPurpose:'']">{{visitorSelectData[temporaryData.guest?temporaryData.guest.visitPurpose:'']}}</span>
              </el-form-item>
            </el-form>
          </div>
        </div>

      </div>

      <span slot="footer">
        <el-button @click="agree" type="primary">{{$t('visitor.senseid.btnSure')}}({{countdown}})</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import LibrarySelect from './components/library-select.vue';
import VisitorImage from './components/visitor-image.vue';
import api from '@/api/visitor.ts';
import {Cache} from '@/utils/cache';
import {EventBus} from '@/utils/eventbus';
import {visitorSelectData} from "@/utils/constants";
import i18n from '@/lang/index';
import dayjs from "dayjs";
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    LibrarySelect,
    VisitorImage
  }
})
export default class VisitorTemporary extends Vue {//临时
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:false}) data!: any;

  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.initData();
  }
  @Watch('data',{immediate:true,deep:true})
  onDataChange(n,o){
    n == null && this.formatDataEmpty();
    n && (this.temporaryData = n);
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  $refs!:{
    form1:HTMLFormElement
    form2:HTMLFormElement
  }
  visitorSelectData:any=visitorSelectData;
  countdown:number=10;
  timer:any=null;
  temporaryData:any={
    idImage:'',
    guestLog:{
      idImageUrl:'',
      name:'',
      idNumber:'',
      nation:'',
      address:''
    }
  };
  loading:boolean=false;
  //form1
  form1:{
    activeTime:any
    recepter:string
    purpose:string
  }={
    activeTime:'',
    recepter:'',
    purpose:'',
  };
  form1Rule:{
    activeTime:any[]
    recepter:any[]
    purpose:any[]
  }={
    activeTime:[
      {required: true, message: i18n.t('form.texterrAvtivetime'), trigger: 'blur' }
    ],
    recepter:[
      {required: false}
    ],
    purpose:[
      {required: false}
    ],
  };
  //form2
  form2:{
    invalidTime:string
    library:string
    contact:string
  }={
    invalidTime:'',
    library:'',
    contact:'',
  };
  form2Rule:{
    invalidTime:any[]
    library:any[]
    contact:any[]
  }={
    invalidTime:[
      {required: true, message: i18n.t('form.texterrInvalitime'), trigger: 'blur' }
    ],
    library:[
      {required: true,message: i18n.t('form.texterrSelectImageLib'), trigger: 'change'}
    ],
    contact:[
      {required: false}
    ],
  };

  /* methods */
  initData(){
    this.loading = false;
    this.form1 = {
      activeTime:dayjs().format('YYYY-MM-DD HH:mm:ss'),
      recepter:'',
      purpose:'',
    };
    this.form2 = {
      invalidTime:'',
      library:'',
      contact:'',
    };
    this.countdownTime();
  }
  countdownTime(){
    this.countdown = 10;
    this.timer = setInterval(()=>{
      if(this.countdown>0){
        this.countdown--;
      }else{
        this.agree();
        // clearInterval(this.timer);
      }
    },1000);
  }
  formatDataEmpty(){
    this.temporaryData = {
      idImage:'',
      guestLog:{
        idImageUrl:'',
        name:'',
        idNumber:'',
        nation:'',
        address:''
      }
    };
  }
  agree(){//
    this.handleClose();
    clearInterval(this.timer);
    // this.handleRequest(1) //访客逻辑修改
    // EventBus.$emit('visitor-seneid-dialog-close')
  }
  agreeOrRefuseVisitor(pass){//pass --> 1允许 2不允许; type --> 1 预约访客 2临时访客 3同行访客;
    const user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
    return api.addVisitorRecord({
      pass,
      type:2,
      libraryId:this.form2.library,
      activationTime:this.form1.activeTime,
      expirationTime:this.form2.invalidTime,
      visitPurpose:this.form1.purpose,
      phone:this.form2.contact,
      unawaresName:this.form1.recepter,
      //ws info
      idNumber:this.data.guestLog.idNumber,
      guestLogId:this.data.guestLog.guestLogId,
      name:this.data.guestLog.name,
      guestId:this.data.guest?this.data.guest.guestId:'',
      guestCode:this.data.guest?this.data.guest.guestCode:'',
      floorId:this.data.floorId,
      deviceId:this.data.deviceId,
      deviceGroupId:this.data.deviceGroupId,
      updateBy:user.userId || ''
    });
  }
  refuseVisit(){
    this.handleRequest(2)
  }
  handleRequest(pass){
    if(!this.data) return;
    if(pass == 1){
      this.$refs.form1.validate(vali1=>{
        this.$refs.form2.validate(vali2=>{
          if(vali1 && vali2){
            this.loading = true;
            this.agreeOrRefuseVisitor(pass).then(e=>{
              this.handleClose();
              EventBus.$emit('visitor-seneid-dialog-close')
            }).catch(e=>{
              this.loading = false;
               e.response.data.code == '421013' && this.handleClose();//others already operate close the dialog
            }).finally(()=>{
              this.loading = false;
            });
          }
        })
      })
    }
    if(pass == 2){
      this.loading = true;
      this.agreeOrRefuseVisitor(pass).then(e=>{
        this.handleClose();
        EventBus.$emit('visitor-seneid-dialog-close')
      }).catch(e=>{
        this.loading = false;
         e.response.data.code == '421013' && this.handleClose();//others already operate close the dialog
      }).finally(()=>{
        this.loading = false;
      });
    }


  }
  handleClose(){
    this.$emit('close')
  }
  libraryCheck(v){
    let chekced_libId = v.id;
    this.form2.library=chekced_libId;
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.visitor-temporary-content{
  display: flex;
  justify-content:center;
  width: 100%;
  padding-top: 24px;
  &>div{
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    .visitor-temporary-img{
      width: 144px;
      height: 192px;
    }
    .visitor-temporary-text{
      padding-left: 24px;
      position: relative;
      max-width: 300px;
    }
    .visitor-temporary-form{
      max-width: 300px;
      margin-left: 30px;
      margin-right: 20px;
    }
    .visitor-temporary-form-libraryNames{
      max-height: 90px;
      overflow-y: auto;
    }
  }
  ::v-deep .visitor-form{
    max-width: 300px;
    .el-form-item {
     .el-form-item__content{
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
      }
    }
  }
}
</style>
