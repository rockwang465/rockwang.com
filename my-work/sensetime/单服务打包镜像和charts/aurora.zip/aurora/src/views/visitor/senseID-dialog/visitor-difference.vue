<template>
  <div class="visitor-difference">
    <el-dialog
    center
    :show-close="false"
    :visible.sync="visible"
    width="50%"
    :close-on-click-modal="false"
    :before-close="handleClose">
    <span slot="title" style="font-size:16px;color:#BE0000;font-weight:bold;">{{$t('visitor.senseid.titleRebrush')}}</span>

      <div class="visitor-difference-content">
        <div>
          <div class="visitor-difference-img">
            <VisitorImage :src="formatData.guestLog.idImageUrl"  />
          </div>
          <div class="visitor-difference-text">
            <el-form :label-width="language == 'en'?'140px':'90px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelName')+':'">
                <div class="visitor-difference-formtext" >{{formatData.guestLog.name}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelIdnumber')+':'">
                <div class="visitor-difference-formtext" >{{formatData.guestLog.idNumber}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelNation')+':'">
                <div class="visitor-difference-formtext" >{{formatData.guestLog.nation}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelAdress')+':'">
                <div class="visitor-difference-formtext" >{{formatData.guestLog.address}}</div>
              </el-form-item>
            </el-form>
            <i class="iconfont icon-renzhengbufu" style="font-size:80px;color:#BE0000" ></i>
          </div>
        </div>
      </div>

      <span slot="footer">
        <el-button @click="handleClose" type="primary" v-show="$permission('021303')" :loading="loading">{{$t('visitor.senseid.btnRebrush')}}</el-button>
        <el-button @click="ignore" type="info" v-show="$permission('021303')" :loading="loading">{{$t('visitor.senseid.btnIgnoreAlarm')}}</el-button>
        <el-button @click="refuseVisit" type="danger" v-show="$permission('021303')" :loading="loading">{{$t('visitor.senseid.btnRefuseVisit')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import api from '@/api/visitor.ts';
import VisitorImage from './components/visitor-image.vue';
import {Cache} from '@/utils/cache';
import {EventBus} from '@/utils/eventbus';
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    VisitorImage
  }
})
export default class VisitorDifference extends Vue {//人证不一
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:false}) data!: any;

  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.initData();
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  formatData:any={
    guest:null,
    guestLog:{
      idImageUrl:'',
      name:'',
      idNumber:'',
      nation:'',
      address:''
    }
  };
  loading:boolean=false;
  /* methods */
  initData(){
    this.loading = false;
    if(this.data){
      this.formatData = this.data;
    }else{
      this.formatData = {
        guest:null,
        guestLog:{
          idImageUrl:'',
          name:'',
          idNumber:'',
          nation:'',
          address:''
        }
      };
    }
  }
  handleClose(){
    this.$emit('close')
  }
  refuseVisit(){
    if(!this.data) return;
    this.loading = true;
    this.refuseVisitor().then(e=>{
      this.handleClose();
      EventBus.$emit('visitor-seneid-dialog-close')
    }).catch(e=>{
      this.loading = false;
       e.response.data.code == '421013' && this.handleClose();//others already operate close the dialog
    }).finally(()=>{
      this.loading = false;
    });
  }
  ignore(){
    this.data && this.$emit('close',this.data);
  }
  refuseVisitor(){//pass --> 1允许 2不允许; type --> 1 预约访客 2临时访客 3同行访客;
    const user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
    return api.addVisitorRecord({
      pass:2,
      type:this.data.reservation == 0?2:1,
      libraryId:this.data.guest?this.data.guest.libraryId:'',
      activationTime:this.data.guest?this.data.guest.activationTime:'',
      expirationTime:this.data.guest?this.data.guest.expirationTime:'',
      visitPurpose:this.data.guest?this.data.guest.visitPurpose:'',
      phone:this.data.guest?this.data.guest.phone:'',
      unawaresName:this.data.guest?this.data.guest.unawaresName:'',
      idNumber:this.data.guestLog.idNumber,
      // idImage :this.data.idImage,
      guestLogId:this.data.guestLog.guestLogId,
      name:this.data.guestLog.name,
      guestId:this.data.guest?this.data.guest.guestId:'',
      guestCode:this.data.guest?this.data.guest.guestCode:'',
      floorId:this.data.floorId,
      deviceId:this.data.deviceId,
      deviceGroupId:this.data.deviceGroupId,
      updateBy:user.userId||''
    });
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.visitor-difference-content{
  display: flex;
  justify-content:center;
  width: 100%;
  padding-top: 24px;
  &>div{
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    .visitor-difference-img{
      width: 144px;
      height: 192px;
    }
    .visitor-difference-text{
      padding-left: 16px;
      position: relative;
      width: 300px;
      .visitor-difference-formtext{
        max-width: 200px;
        // overflow: hidden;
        // text-overflow:ellipsis;
        // white-space: nowrap;
        word-wrap:break-word;
      }
      .el-form-item{
        margin-bottom: 0;

        .el-form-item__label,.el-form-item__content{
          line-height: 22px;
        }
      }
      .icon-renzhengbufu{
        position: absolute;
        right: 0;
        right: 57px;
        bottom: -17px;
      }
    }
  }
}
</style>
