<template>
    <div class="visitor-add" v-if="dialogVisible">
      <!--:title="isEdit?'编辑预约':'新建预约'"-->
      <el-dialog
        :title="isEdit?$t('visitor.visitorlist.labelEditReserve'):$t('visitor.visitorlist.labelAddReserve')"
        :visible.sync="dialogShowVisible"
        :width="enDialog">

          <el-form v-if="dialogShowVisible" :model="form" label-position="right" :rules="form.vehicleNumber?rules1:rules2" ref="ruleForm" :label-width="enWidth" class="add-visitorForm">
            <div class="new-visitor">
            <div class="left">
              <div class="visitor-line">
                <!--姓名-->
                <el-form-item :label="$t('visitor.senseid.labelName')" prop="name">
                  <el-input :disabled="isDisabled" size="small" v-model="form.name" maxlength="40"></el-input>
                </el-form-item>
              </div>
              <div class="visitor-line">
                <el-form-item :label="$t('visitor.senseid.labelActiveTime')" prop="activationTime">
                  <el-date-picker class="starTime"
                                  v-model="form.activationTime"
                                  type="datetime"
                                  value-format="yyyy-MM-dd HH:mm:ss"
                                  :disabled="isDisabled"
                                  :placeholder="$t('imagemanagement.contTimeSet')">
                  </el-date-picker>
                  <!--:picker-options="startDatePicker"-->
                </el-form-item>
              </div>
              <div class="visitor-line">
                <!--人像库-->
                <el-form-item :label="$t('visitor.visitorlist.labelLibrary')" prop="libraryIds">
                  <!-- <el-select v-model="form.libraryId" style="width: 100%;" @change="selectState" size="small" class="el-list">
                    <el-option
                      v-for="item in libraryList"
                      :key="item.libraryId"
                      :label="item.libraryName"
                      :value="item.libraryId">
                    </el-option>
                  </el-select> -->
                  <Select size1="small" :data="formatLibraryList(libraryList)" :checkedKeys="form.libraryIds" @ensure="libraryIdsChecked" />
                </el-form-item>
              </div>
              <div class="visitor-line">
                <!--接待人-->
                <el-form-item :label="$t('visitor.senseid.labelRecepter')">
                  <el-popover
                    placement="bottom-start"
                    width="500"
                    v-model="popoverVisible"
                    @hide="popoverHide"
                    trigger="click">
                    <!--<el-input v-model="form.unawaresName"></el-input>-->
                    <el-input :placeholder="$t('imagemanagement.textboxKeywordSearch')"
                              @focus="inputFocus"
                              @blur="inputBlur"
                              v-model="keywords">
                      <i slot="suffix" v-show="showSearchClose" @click="handleClearSearch" class="el-input__icon el-icon-circle-close"></i>
                      <i slot="suffix" @click="handleSearch" class="el-input__icon el-icon-search"></i>
                    </el-input>
                    <el-table stripe
                              v-loading="loading"
                              @row-click="chooseRecepter"
                              class="fetch-img"
                              :data="tableData">
                      <el-table-column  :label="$t('imagemanagement.labelImage')">
                        <template slot-scope="scope">
                          <img height="80px" width="60px" :src="processImgurl(scope.row.imageUrl)" alt="">
                        </template>
                      </el-table-column>
                      <el-table-column  property="name" :label="$t('imagemanagement.labelName')"></el-table-column>
                      <el-table-column  property="ID" :label="$t('imagemanagement.labelID')"></el-table-column>
                      <el-table-column  property="dept" :label="$t('imagemanagement.labelDepartment')"></el-table-column>
                      <!--<el-table-column width="300" property="address" label="地址"></el-table-column>-->
                    </el-table>
                    <el-input slot="reference" size="small" v-model="form.unawaresName"
                              @focus="inputFocus"
                              @blur="inputBlur"
                              maxlength="40"></el-input>
                  </el-popover>
                  <!--<el-input size="small" v-model="form.unawaresName" maxlength="40"></el-input>-->
                </el-form-item>
              </div>
              <div class="visitor-line">
                <!--车牌号-->
                <el-form-item :label="$t('visitor.visitorlist.labelCarNumber')" prop="vehicleNumber">
                  <el-input v-model="form.vehicleNumber" maxlength="40"></el-input>
                <!-- 2846新增需求修改 -->
                <!-- <plate-number
                  v-if="dialogShowVisible"
                  size="small"
                  v-model="form.vehicleNumber"
                  :oldCarNumber="form.vehicleNumber"
                  @getCarNumber="getVehicleNumber">
                </plate-number> -->
              </el-form-item>
              </div>
            </div>
            <div class="right">
              <div class="visitor-line">
                <!--身份证号-->
                <el-form-item :label="$t('visitor.senseid.labelIdnumber')" prop="idNumber">
                  <el-input :disabled="isDisabled" size="small" v-model="form.idNumber" @focus="idFocus" @blur="idBlur" maxlength="18"></el-input>
                </el-form-item>
              </div>
              <div class="visitor-line">
                <!--失效时间-->
                <el-form-item :label="$t('visitor.senseid.labelInvalidTime')" prop="expirationTime">
                  <el-date-picker class="starTime"
                                  v-model="form.expirationTime"
                                  type="datetime"
                                  value-format="yyyy-MM-dd HH:mm:ss"
                                  :placeholder="$t('imagemanagement.contTimeSet')">
                  </el-date-picker>
                  <!--:picker-options="startDatePicker"-->
                </el-form-item>
              </div>
              <div class="visitor-line">
                <!--来访目的-->
                <el-form-item :label="$t('visitor.senseid.labelPurpose')">
                  <el-select v-model="form.visitPurpose" style="width: 100%;" @change="selectState" size="small" class="el-list">
                    <el-option
                      v-for="(item,index) in selectData"
                      :key="index"
                      :label="$t(item)"
                      :value="index">
                    </el-option>
                  </el-select>
                </el-form-item>
              </div>
              <div class="visitor-line">
                <!--接待人联系方式-->
                <!--<el-form-item :label="$t('visitor.senseid.labelContact')">-->
                <el-form-item :label="$t('visitor.visitorlist.contact')">
                  <el-input size="small" v-model="form.unawaresPhone" maxlength="40"></el-input>
                </el-form-item>
              </div>
              <div class="visitor-line">
                <!--联系方式-->
                <el-form-item :label="$t('visitor.senseid.labelContact')">
                  <el-input size="small" v-model="form.phone" maxlength="30"></el-input>
                </el-form-item>
              </div>
            </div>
            </div>
          </el-form>


        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="subInfo">{{$t('visitor.visitorlist.btnOk')}}</el-button>
          <el-button type="info" @click="dialogShowVisible = false">{{$t('visitor.visitorlist.btnCancel')}}</el-button>
        </span>
      </el-dialog>

      <!--    输入密码显示id弹窗-->
      <el-dialog
        :title="$t('imagemanagement.importPassWord')"
        :visible.sync="isShowIdVisible"
      >
        <el-form :model="pwd" :rules="ruleList" ref="pwdForm" label-width="150px" @submit.native.prevent>
          <el-form-item :label="$t('imagemanagement.userPassWord')" prop="password">
            <el-input type="password" v-model="pwd.password"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" class="deleteBtn" @click="showIdFn">{{$t('imagemanagement.buttonOK')}}</el-button>
            <el-button @click="isShowIdVisible = false" type="info" class="cancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
        </span>
      </el-dialog>
    </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import visitorAppi from '@/api/visitor';
  import {Cache} from '@/utils/cache';
  import {PortraitModule} from '@/store/modules/portrait';
  import PlateNumber from '@/components/plate-number/plate-number.vue';
  import {visitorSelectData} from '@/utils/constants';
  import {AppModule} from '@/store/modules/app';
  import Select from "@/components/select/index.vue";
  import {processImgurl} from '@/utils/image.ts';
  import el from "element-ui/src/locale/lang/el";
  import id from "element-ui/src/locale/lang/id";
  import {UserModule} from '@/store/modules/user';
  import i18n from "@/lang";

  let vm = null as any;
  let idNoChange:boolean = false;
  const nameTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrEnterName')))
    }else{
      callback()
    }
  }
  const requiredTip = (rule, value = '', callback) => {
    // debugger
    if (value === ''|| value === null) {
      // debugger
      callback(new Error(vm.$t('visitor.visitorlist.tipsNoNull')))
      // callback(new Error("请输入非空内容"))
    } else {
      callback()
    }
  }
  const timeTip = (rule, value = '', callback) => {
    if (value === ''|| value === null){
      callback(new Error(vm.$t('form.texterrSelectTime')))//请选择时间
    }else{
      callback()
    }
  }
  const librariesRule = (rule, value = '', callback) => {
    if (value === ''|| value === null || value.length == 0) {
      // debugger
      callback(new Error(vm.$t('visitor.visitorlist.tipsNoNull')))
      // callback(new Error("请输入非空内容"))
    } else {
      callback()
    }
  }
  const idTip = (rule, value = '', callback) => {
    if (value === ''|| value === null) {
      callback(new Error(vm.$t('visitor.visitorlist.tipsNoIdNumber')))
      // callback(new Error("请输入身份证号"))//
    }

    if (idNoChange){
      callback();
    }
    // let re = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{1,40}$/ as any
    let re =/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/
    if (re.test(value) && value.length === 18) {
      callback()
    }else{
      callback(new Error(vm.$t('visitor.visitorlist.tipsIdNumberErr')))
    }
  }
  const vehicleNumberTip = (rule, value, callback) => {
    console.log(value.carNumber,value)
    if(value.carNumber||value){
      let pattPlateNumber = /^(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z](([0-9]{5}[DF])|([DF]([A-HJ-NP-Z0-9])[0-9]{4})))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳使领]))$/;
      //console.log(rule, value,pattPlateNumber.test(value.carNumber))
      if (pattPlateNumber.test(value.carNumber)||pattPlateNumber.test(value)) {
        callback()
      }else{
        // callback(new Error("请输入正确的车牌号"))
        callback(new Error(vm.$t('visitor.visitorlist.tipsCarNumberErr')))
      }
    }

  }
  @Component({
    components: {
      PlateNumber,
      // HeadPreview,
      // VisitorContainer,
      Select
    },
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    },
    computed:{
      enWidth:function () {
        let that = this as any;
        return that.language === 'en' ? "150px" : "110px";
      },
      enDialog:function(){
        let that = this as any;
        return that.language === 'en' ? "60%" : "50%";
      }
    }
  })
  export default class visitorAdd extends Vue{
    get language() {
      return AppModule.language;
    }
    tableData= []
    @Prop(Object) visitorObj!:any;
    dialogShowVisible = false;
    libraryList = [] as any;
    focusEnter = false;
    keywords = '' as string;
    loading = false as boolean;
    showSearchClose = false as boolean;
    processImgurl:any = processImgurl;
    popoverVisible = false;
    form = {
      name:'',
      activationTime:'',
      expirationTime:'',
      visitPurpose:null,
      unawaresName:'',
      idNumber:'',
      isNewEnergy:false,
      // libraryName:1,
      libraryIds:[],
      phone:'',
      unawaresPhone:'',
      vehicleNumber:'',
    } as any;
    vehicleBool = true;
    vehicleTips = '';
    isEdit = false;
    isDisabled = false;
    // selectData = visitorSelectData;
    selectData = {
      1:'visitor.senseid.optionInterview',
      2:'visitor.senseid.optionMeeting',
      3:'visitor.senseid.optionActivity',
      4:'visitor.senseid.optionParent',
      5:'visitor.senseid.optionOther'
    };

    rules1 = {
      name: [{required: true, trigger: 'blur',  validator: nameTip}],//'请输入姓名'
      libraryIds: [{required: true, trigger: 'blur',  validator: librariesRule}],
      vehicleNumber:[
        {required: false,max: 40, trigger: ['blur', 'change']}
      ],
      idNumber: [{required: true, trigger: 'blur', validator: idTip}],
      activationTime: [{required: true, trigger: 'blur', validator: timeTip}],//'请选择时间'
      expirationTime: [{required: true, trigger: 'blur', validator: timeTip}],
    };
    rules2 = {
      name: [{required: true, trigger: 'blur',  validator: nameTip}],//'请输入姓名'
      libraryIds: [{required: true, trigger: 'blur',  validator: librariesRule}],
      idNumber: [{required: true, trigger: 'blur', validator: idTip}],
      activationTime: [{required: true, trigger: 'blur', validator: timeTip}],//'请选择时间'
      expirationTime: [{required: true, trigger: 'blur', validator: timeTip}],
    };

    isNunberChange = ''
    isShowId = false
    isShowIdVisible = false;
    pwd = {
      password: ''
    };
    ruleList = {
      password:[
        { required: true, message: i18n.t('imagemanagement.passWordImport')+"", trigger: 'blur' }
      ]
    };

    @Watch('visitorObj')
    onVisitorObjChange(val:any){
      console.log(val)
        if (val){
          //console.log(val)
          if (val.state == 2){
            this.isDisabled = true;
          }else{
            this.isDisabled = false;
          }
          this.isEdit = true;
          idNoChange = true;

          //form共10条属性
          this.form.name=val.name;
          this.form.activationTime=val.activationTime;
          this.form.expirationTime=val.expirationTime;
          this.form.visitPurpose=val.visitPurpose;
          this.form.unawaresName=val.unawaresName;
          this.form.idNumber=val.idNumber;
          // this.form.libraryName=val.libraryName;
          this.form.libraryIds=val.libraryId?val.libraryId.split(','):[];
          this.form.phone=val.phone;
          this.form.unawaresPhone=val.unawaresPhone;
          this.form.vehicleNumber=val.vehicleNumber;

          this.isNunberChange = val.idNumber
          // this.isShowId = false
        }
    }
    // @Watch('libraryList')
    // onLibraryListChange(val:any){
    //   if (val.length>0){
    //     this.form.libraryId = val[0].libraryId
    //   }
    // }
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      if(!val) {
        this.isShowId = false
      }
      
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      let that = this as any;
      if (!val) {
        // that.$refs['ruleForm'].resetFields()
        // that.form.libraryId = that.libraryList[0].libraryId
        that.clertData();//初始化表单
        this.$emit("closeVisitorAdd")
      }else{
        if (this.visitorObj){
          idNoChange = true;

          //form共10条属性
          this.form.visitPurpose=this.visitorObj.visitPurpose;
          this.form.vehicleNumber=this.visitorObj.vehicleNumber;
          this.form.phone=this.visitorObj.phone;
          this.form.unawaresName=this.visitorObj.unawaresName;
          this.form.name=this.visitorObj.name;
          this.form.activationTime=this.visitorObj.activationTime;
          this.form.expirationTime=this.visitorObj.expirationTime;
          this.form.idNumber=this.visitorObj.idNumber;
          this.form.unawaresPhone=this.visitorObj.unawaresPhone;
          this.form.libraryIds=this.visitorObj.libraryId?this.visitorObj.libraryId.split(','):[];
        }else{

          // this.form.libraryId=null;
        }
      }
    }

    @Watch('form.vehicleNumber')
    onVehicleNumberChange(val:any){
      let that = this as any;
      if (!val||val.length == 0){
        this.vehicleBool = true;
      }
    }

    @Watch('form.unawaresName')
    onUnawaresNameChange(val: any) {
      this.keywords = val;
    }

    @Watch('keywords')
    onKwordChange(val: any) {
      this.form.unawaresName = val;
      if (val) {
        this.showSearchClose = true;
      }
      if (val == ''){
        this.showSearchClose = false;
        // this.fetchImgList();
        this.tableData = [];
      }
    }


    created(){
      vm = this as any;
      vm.getLibsList();

    }

    selectState(){

    }

    inputFocus(){
      this.focusEnter = true;
      let that = this as any;
      window.document.onkeydown = function(event){
        if (that.focusEnter && that.popoverVisible) {
          if (event.keyCode == 13){
            that.fetchImgList();
          }
        }
      }
    }
    inputBlur(){
      this.focusEnter = false;
    }
    handleClearSearch(){
      this.keywords = '';
      this.tableData = [];
    }
    handleSearch(){
      this.fetchImgList()
    }
    popoverHide(){
      this.tableData = [];
    }

    //id加密后的修改逻辑
    idFocus(){
      
      if (this.isEdit){
        // this.form.idNumber = '';
        if(!this.isShowId)
        this.isShowIdVisible = true;
      } 
      // idNoChange = false;

      console.log(idNoChange)
    }
    idBlur(){
      if(this.isNunberChange != this.form.idNumber){
        idNoChange = false;
      }else {
        idNoChange = true;
      }
    }

    showIdFn(){

      (this.$refs.pwdForm as any).validate((valid) => {
        if (valid) {
          let params = {
            password:'',
            secret:''
          };
          params.password = this.pwd.password;
          params.secret = this.visitorObj.cipherText;
          UserModule.getPortraitId(params).then((res)=>{
            this.form.idNumber = (res as any).decryptStr;
            this.isShowId = true;
          }).finally(()=>{
            this.isShowIdVisible = false;
            this.pwd.password = '';
          })
        }else {
          return false;
        }
      });
    }


    chooseRecepter(data){
      console.log(data);
      let that = this;
      let portraitData = {}as any;
      PortraitModule.PortraitDetails(data.targetId).then((data: any) => {
        console.log("查询人像详情",data);
        portraitData = data;
        this.form.unawaresName = portraitData.name;
        this.form.unawaresPhone = portraitData.phone;
      }).catch((err) => {

      });

      this.popoverVisible = false;
      this.keywords = '';
      this.tableData = [];
    }
    fetchImgList(){
      let that = this as any;
      this.loading = true
      let params = {
        page:1,
        size:99,
        sort:'ASC',
        activeState:1,
        keywords:this.keywords,
      } as any;
      PortraitModule.GetPortraitList(params).then((data: any) => {
        this.loading = false

        if (data.data){
          this.tableData = data.data;
        }else{
          this.tableData = [];
        }
      }).catch((err) => {
        this.loading = false
      });
    }

    getVehicleNumber(data,error){
      console.log("getVehicleNumber →",data)
      this.form.vehicleNumber = data;//.carNumber;

      let that = this as any;
      (that.$refs.ruleForm as any).validateField('vehicleNumber',(valid)=>{
        console.log(valid);
      })

      //this.form.isNewEnergy = data.isNewEnergy;
      // if(error){
      //   console.log(error)
      //   this.vehicleTips = error;
      //   this.vehicleBool = false;
      // }else{
      //   this.form.vehicleNumber = data;
      //   this.vehicleBool = true;
      //   console.log(this.form)
      // }

    }

    subInfo(){
      let that = this as any;

      if (this.form.expirationTime && new Date(this.form.expirationTime).getTime() < new Date(this.form.activationTime).getTime()){
        // this.form.activationTime = '';
        // this.form.expirationTime = '';
        this.$message({
          showClose: true,
          message:that.$t('imagemanagement.timeTips'),
          // message:'激活时间需早于失效时间',
          type: 'error'
        })
        return;
      }

      if (new Date().getTime() > new Date(this.form.expirationTime).getTime()){
        // this.form.activationTime = '';
        // this.form.expirationTime = '';
        this.$message({
          showClose: true,
          message:that.$t('visitor.visitorlist.timeTips'),
          // message:'失效时间需晚于当前时间',
          type: 'error'
        })
        return;
      }

      console.log(this.form);

      (that.$refs.ruleForm as any).validate((valid) => {

        if (valid){

          let params = {} as any;
          for (let key in this.form) {
            params[key] = this.form[key]
          }
          console.log(params);
          // params.vehicleNumber = this.form.vehicleNumber.carNumber?this.form.vehicleNumber.carNumber:this.form.vehicleNumber;
          let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
          params.createBy = user.userId;
          this.dialogShowVisible = false;
          if (this.isEdit){
            if (idNoChange){
              params.idNumber = this.visitorObj.cipherText;
            }
            params.guestId = this.visitorObj.guestId;
            console.log(params)
            if (this.visitorObj.status == 2){
              visitorAppi.updateVisitInfo(params).then((res)=>{
                console.log(res);
                that.$emit('edited')
              }).catch(err=>{
                console.log(err);
              })
            }else if(this.visitorObj.status == 1){
              visitorAppi.updateReservation(params).then((res)=>{
                console.log(res);
                that.$emit('edited')
              }).catch(err=>{
                console.log(err);
              })
            }


          } else{
            visitorAppi.addReservation(params).then((res)=>{
              console.log(res);
              that.$emit('onFreshList')
              this.$message({
                // message: "添加访客成功",
                showClose: true,
                message:that.$t('visitor.visitorlist.tipAddVisitorSuccess'),
                type: 'success'
              })
            }).catch(err=>{
              console.log(err);
            })
          }
        }
      })
    }

    getLibsList(){
      let that = this as any;
      PortraitModule.SearchLibraries({}).then((data: any) => {
        //console.log('111111111111',data);
        that.libraryList = data.whitelists
      }).catch(err=>{
        console.log(err);
      })
    }

    clertData(){
      // this.form.unawaresName='';
      // this.form.phone='';
      // this.form.vehicleNumber='';
      // this.form.visitPurpose=null;
      this.form = {
        name:'',
        activationTime:'',
        expirationTime:'',
        visitPurpose:null,
        unawaresName:'',
        idNumber:'',
        isNewEnergy:false,
        // libraryName:1,
        libraryIds:[],
        phone:'',
        unawaresPhone:'',
        vehicleNumber:'',
      } as any;
      idNoChange = false;
    }


    //人像库多选
    formatLibraryList(arr){
      if(arr && arr.length>0){
        return arr.map(item => {return {'id':item.libraryId,'name':item.libraryName}});
      }else{
        return [];
      }
    }
    libraryIdsChecked(ids){
      this.form.libraryIds = ids ;
      (this.$refs.ruleForm as any ).validateField('libraryIds');
    }
  }
</script>

<style lang="scss" scoped>
  .new-visitor {
    display: flex;
    margin-top: 10px;
    .left{
      margin-right: 20px;
      width: 50%;
    }
    .right{
      width: 50%;
    }
  }
  .fetch-img{
    height: 300px;
    overflow: auto;
  }
  .add-visitorForm{
    width: 100%;
  }

  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }
  /*::v-deep  input::-webkit-outer-spin-button,*/
  /*::v-deep  input::-webkit-inner-spin-button {*/
    /*-webkit-appearance: none;*/
  /*}*/
  /*::v-deep  input[type="number"]{*/
    /*-moz-appearance: textfield;*/
  /*}*/
  .visitor-add{
    ::v-deep .el-dialog__body{
      overflow: initial;
    }
    ::v-deep .el-dialog{
      overflow: initial;
    }
  }

</style>
