<template>
<el-container class="visitor-main">
  <el-main class="main">
    <VisitorListContainer
      @onDatachange="visitorListChange"
      ref="visitList"
    />
  </el-main>
  <el-aside :width="asideWidth">
    <VisitorDetailContainer
      :visitorObj="visitorObj"
      @onFreshList="fetchVisitList"
    />
  </el-aside>
</el-container>

</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator'
import  Icon from '@/components/icon-wrap/index.vue'
import VisitorListContainer from './visitor-list.vue'
import VisitorDetailContainer from './visitor-detail.vue'
import {AppModule} from '@/store/modules/app';

@Component({
  components: {
    Icon,
    VisitorListContainer,
    VisitorDetailContainer,
  },
  computed:{
    asideWidth:function () {
      let that = this as any;
      return that.language === 'en' ? "640px" : "540px";
    }
  }
})
export default class VisitorContainer extends Vue {
  visitorObj:any={}
  exportParams:any={}
  get language() {
    return AppModule.language;
  }

  mounted(){
    //do something
  }

  visitorListChange(obj:any){//获取访客列表
    this.visitorObj=obj||{};
  }
  fetchVisitList(){
    (this.$refs.visitList as any).fetchVisitList()
  }

}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.visitor-main{height: calc(100% - 98px);}
.visitor-container{
  margin:16px 24px;
  display:flex;
}
</style>

