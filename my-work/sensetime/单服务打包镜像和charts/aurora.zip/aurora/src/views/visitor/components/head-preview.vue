<template>
<div class="head-HeadPreview">
  <!--<el-button-->
    <!--v-if="$permission('021301')"-->
    <!--class="add-visitor-btn"-->
    <!--@click="addNewVisitor"-->
    <!--type="primary">-->
    <!--<Icon-->
      <!--size="12"-->
      <!--name="plus-square"-->
    <!--/>-->
      <!--&lt;!&ndash;预约访客&ndash;&gt;-->
    <!--{{$t('visitor.senseid.titleReservation')}}-->
  <!--</el-button>-->
  <div class="hide">{{visitStatistics}}</div>
   <div v-if="visitStatistics.dayGuestCount" class="preview-item">
      <i></i>
     <!--今日访客-->
      <b>{{$t('visitor.visitorlist.titleTodayVisitor')}}</b>
     <!--xx人-->
      <span>{{$t('visitor.visitorlist.labelPersonNum',{number:visitStatistics.dayGuestCount.dayGuestCount})}}</span>
   </div>
   <div v-if="visitStatistics.dayGuestCount" class="preview-item">
     <!--预约访客-->
      <b>{{$t('visitor.senseid.titleReservation')}}</b>
      <span>{{$t('visitor.visitorlist.labelPersonNum',{number:visitStatistics.dayGuestCount.reservationGuestCount})}}</span>
   </div>
   <div v-if="visitStatistics.dayGuestCount" class="preview-item">
     <!--临时访客-->
      <b>{{$t('visitor.senseid.titleTemporary')}}</b>
      <span>{{$t('visitor.visitorlist.labelPersonNum',{number:visitStatistics.dayGuestCount.tempGuestCount})}}</span>
   </div>
   <div v-if="visitStatistics.deviceGuestCounts" v-for="(v,i) in 3" class="preview-item">
      <b v-if="visitStatistics.deviceGuestCounts[i]">{{visitStatistics.deviceGuestCounts[i].deviceName}}</b>
      <span v-if="visitStatistics.deviceGuestCounts[i]">{{$t('visitor.visitorlist.labelPersonNum',{number:visitStatistics.deviceGuestCounts[i].guestCount})}}</span>
   </div>
   <el-link class="more-right" @click="showMore = true" type="primary">{{$t('visitor.visitorlist.titleMore')}}>></el-link>
  <!--<VisitorAdd @onFreshList="fetchVisitList" @closeVisitorAdd="closeVisitorAdd" :dialogVisible="isVisitorAdd"></VisitorAdd>-->

  <el-dialog
    :title="$t('visitor.visitorlist.labelOverView')"
    :visible.sync="showMore"
    v-if="showMore"
    width="30%"
    max-height="500"
    :close-on-click-modal="false">

    <el-table :data="visitStatistics.deviceGuestCounts">
      <el-table-column property="floorName" :label="$t('visitor.visitorlist.titleVisitorArea')" width="150"></el-table-column>
      <el-table-column property="deviceName" :label="$t('visitor.visitorlist.labelVisitorEntrance')" width="200"></el-table-column>
      <el-table-column property="guestCount" :label="$t('visitor.visitorlist.labelVisitorNumber')"></el-table-column>
    </el-table>
    <br>

  </el-dialog>

</div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import  Icon from '@/components/icon-wrap/index.vue';
import VisitorAdd from './visitor-add.vue'
import visitorApi from '@/api/visitor';
import  { VisitorModule } from '@/store/modules/visitor';
VisitorModule.getVisitorStatistics();
@Component({
  components: {
    Icon,
    VisitorAdd
  }
})
export default class HeadPreview extends Vue {
  // visitStatistics={};
  isVisitorAdd = false;
  showMore = false;
  gridData=[];
  isGetData = false;

  get visitStatistics(){
    console.log("数据",VisitorModule.visitStatistics);
    return  VisitorModule.visitStatistics
  }

  created(){
    this.fetchVisitStatistics()
  }

  mounted(){
    //请求访客统计
    setTimeout(()=>{
      console.log("===>>",this.visitStatistics)
    },1000)
  }

  addNewVisitor() {
   this.isVisitorAdd = true
  }

  closeVisitorAdd(){
    this.isVisitorAdd = false;
  }
  fetchVisitList(){
    this.$emit("onFreshList")
  }
  //请求访客列表
  fetchVisitStatistics(){
      VisitorModule.getVisitorStatistics();
      // visitorApi.getVisitorStatistics().then((obj)=>{
      //     this.visitStatistics=obj
      // })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
    .head-HeadPreview{
        margin:16px 8px 24px;
        background:#fff;
        padding:16px 8px;
        display:flex;
        align-items:center;
        position: relative;
        @include shadowBox();
        .add-visitor-btn{

        }
        .more-right{
          position: absolute;
          right: 8px;

        }
        .preview-item{
          margin:0 16px;
          b{
            padding-right:10px
          }
          i{
            display:inline-block;
            height:4px;
            width:4px;
            border-radius:100%;
            background:#000;
            margin:4px;
          }
        }
    }
</style>

