<template>
  <div class="visitor-already">
    <el-dialog
    center
    :show-close="false"
    :visible.sync="visible"
    width="60%"
    :close-on-click-modal="false"
    :before-close="handleClose">
    <span slot="title" style="font-size:16px;font-weight:bold;">{{$t('visitor.senseid.titleAlready')}}</span>

      <div class="visitor-already-content">
        <div>
          <div class="visitor-already-img">
            <VisitorImage :src="formatData.guestLog.idImageUrl" />
          </div>
          <div class="visitor-already-text">
            <el-form :label-width="language == 'en'?'155px':'110px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelName')+':'">
                <div class="visitor-already-formtext" :title="formatData.guestLog.name">{{formatData.guestLog.name}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelIdnumber')+':'">
                <div class="visitor-already-formtext" :title="formatData.guestLog.idNumber||''">{{formatData.guestLog.idNumber}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelNation')+':'">
                <div class="visitor-already-formtext" :title="formatData.guestLog.nation||''">{{formatData.guestLog.nation}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelAdress')+':'">
                <div class="visitor-already-formtext" :title="formatData.guestLog.address||''">{{formatData.guestLog.address}}</div>
              </el-form-item>
              <!--接待人-->
              <el-form-item :label="$t('visitor.senseid.labelRecepter')+':'">
                <div class="visitor-already-formtext" :title="formatData.guest?formatData.guest.unawaresName:''">{{formatData.guest?formatData.guest.unawaresName:''}}</div>
              </el-form-item>
              <!--接待人联系方式-->
              <el-form-item :label="$t('visitor.visitorlist.contact')+':'">
                <div class="visitor-already-formtext" :title="formatData.guest?formatData.guest.unawaresPhone:''">{{formatData.guest?formatData.guest.unawaresPhone:''}}</div>
              </el-form-item>
            </el-form>
          </div>
          <div class="visitor-already-text">
            <el-form :label-width="language == 'en'?'135px':'90px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelActiveTime')+':'">
                <div class="visitor-already-formtext" :title="formatData.guest?formatData.guest.activationTime:''">{{formatData.guest?formatData.guest.activationTime:''}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelInvalidTime')+':'">
                <div class="visitor-already-formtext" :title="formatData.guest?formatData.guest.expirationTime:''">{{formatData.guest?formatData.guest.expirationTime:''}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelLibrary')+':'">
                <!-- <div class="visitor-already-formtext" :title="formatData.guest?formatData.libraryName:''">{{formatData.guest?formatData.libraryName:''}}</div> -->
                <div v-if="formatData.guest && formatData.libraryNames" class="visitor-already-formtext visitor-already-formtext-libraryNames">
                  <p v-for="(libraryName,libraryNameIndex) in formatData.libraryNames" :title="libraryName|| ''" :key="libraryNameIndex">{{libraryName||''}}</p>
                </div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelContact')+':'">
                <div class="visitor-already-formtext" :title="formatData.guest?formatData.guest.phone:''">{{formatData.guest?formatData.guest.phone:''}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelPurpose')+':'">
                <div class="visitor-already-formtext" :title="visitorSelectData[formatData.guest?formatData.guest.visitPurpose:'']" >{{visitorSelectData[formatData.guest?formatData.guest.visitPurpose:'']}}</div>
              </el-form-item>
              <!--车牌号-->
              <el-form-item :label="$t('visitor.visitorlist.labelCarNumber')+':'">
                <div class="visitor-already-formtext" :title="formatData.guest?formatData.guest.vehicleNumber:''">{{formatData.guest?formatData.guest.vehicleNumber:''}}</div>
              </el-form-item>

            </el-form>
          </div>
        </div>
      </div>

      <span slot="footer">
        <el-button @click="agree" type="primary">{{$t('visitor.senseid.btnSure')}}({{countdown}})</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import VisitorImage from './components/visitor-image.vue';
import {visitorSelectData} from "@/utils/constants";
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    VisitorImage
  }
})
export default class VisitorAlready extends Vue {//已刷脸
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:false}) data!: any;
  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    clearInterval(this.timer);
    n && this.initData();
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  visitorSelectData:any=visitorSelectData;
  countdown:number=10;
  timer:any=null;
  formatData:any={
    guest:null,
    guestLog:{
      idImageUrl:'',
      name:'',
      idNumber:'',
      nation:'',
      address:''
    }
  };
  /* methods */
  initData(){
    if(this.data){
      this.formatData = this.data
    }else{
      this.formatData={
        guest:null,
        guestLog:{
          idImageUrl:'',
          name:'',
          idNumber:'',
          nation:'',
          address:''
        }
      };
    }
    this.countdown = 10;
    this.countdownTime();
  }
  countdownTime(){
    this.timer = setInterval(()=>{
      if(this.countdown>0){
        this.countdown--;
      }else{
        this.agree();
      }
    },1000);
  }
  destroyed() {
    clearInterval(this.timer);
  }
  handleClose(){
    this.$emit('close')
  }
  agree(){
    this.handleClose();
    clearInterval(this.timer);

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.visitor-already-content{
  display: flex;
  width: 100%;
  padding-top: 24px;
  &>div{
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    width: 100%;
    justify-content: center;
    .visitor-already-img{
      width: 144px;
      height: 192px;
    }
    .visitor-already-text{
      padding-left: 24px;
      position: relative;
      width: 300px;
      .visitor-already-formtext{
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
      }
      .el-form-item{
        margin-bottom: 0;

        .el-form-item__label,.el-form-item__content{
          line-height: 22px;
        }
      }
      .icon-renzhengbufu{
        position: absolute;
        right: 0;
      }
      .visitor-already-formtext-libraryNames{
        max-height: 90px;
        overflow-y: auto;
      }
    }
  }
}
</style>
