<template>
  <div class="visitor-reservation">
    <el-dialog
    center
    :show-close="false"
    :visible.sync="visible"
    width="60%"
    :close-on-click-modal="false"
    :before-close="handleClose">
    <span slot="title" style="font-size:16px;font-weight:bold;">{{$t('visitor.senseid.titleReservation')}}</span>

      <div class="visitor-reservation-content">
        <div>
          <div class="visitor-reservation-img">
            <VisitorImage :src="formatData.guestLog.idImageUrl" />
          </div>
          <div class="visitor-reservation-text">
            <el-form :label-width="language == 'en'?'155px':'110px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelName')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guestLog.name" >{{formatData.guestLog.name}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelIdnumber')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guestLog.idNumber" >{{formatData.guestLog.idNumber}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelNation')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guestLog.nation" >{{formatData.guestLog.nation}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelAdress')+':'">
                <div class="visitor-reservation-formtext" > <span :title="formatData.guestLog.address">{{formatData.guestLog.address}}</span> </div>
              </el-form-item>
              <!--接待人-->
              <el-form-item :label="$t('visitor.senseid.labelRecepter')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guest?formatData.guest.unawaresName:''">{{formatData.guest?formatData.guest.unawaresName:''}}</div>
              </el-form-item>
              <!--接待人联系方式-->
              <el-form-item :label="$t('visitor.visitorlist.contact')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guest?formatData.guest.unawaresPhone:''">{{formatData.guest?formatData.guest.unawaresPhone:''}}</div>
              </el-form-item>
            </el-form>
          </div>
          <div class="visitor-reservation-text" >
            <el-form :label-width="language == 'en'?'130px':'90px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelActiveTime')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guest?formatData.guest.activationTime:''">{{formatData.guest?formatData.guest.activationTime:''}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelInvalidTime')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guest?formatData.guest.expirationTime:''" >{{formatData.guest?formatData.guest.expirationTime:''}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelLibrary')+':'">
                <!-- <div class="visitor-reservation-formtext" :title="formatData.guest?formatData.libraryName:''" >{{formatData.guest?formatData.libraryName:''}}</div> -->
                <div v-if="formatData.guest && formatData.libraryNames" class="visitor-reservation-formtext visitor-reservation-formtext-libraryNames">
                  <p v-for="(libraryName,libraryNameIndex) in formatData.libraryNames" :title="libraryName|| ''" :key="libraryNameIndex">{{libraryName||''}}</p>
                </div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelContact')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guest?formatData.guest.phone:''" >{{formatData.guest?formatData.guest.phone:''}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelPurpose')+':'">
                <div class="visitor-reservation-formtext" :title="visitorSelectData[formatData.guest?formatData.guest.visitPurpose:'']" >{{visitorSelectData[formatData.guest?formatData.guest.visitPurpose:'']}}</div>
              </el-form-item>
              <!--车牌号-->
              <el-form-item :label="$t('visitor.visitorlist.labelCarNumber')+':'">
                <div class="visitor-reservation-formtext" :title="formatData.guest?formatData.guest.vehicleNumber:''">{{formatData.guest?formatData.guest.vehicleNumber:''}}</div>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>

      <span slot="footer">
        <el-button @click="agree" type="primary" >{{$t('visitor.senseid.btnSure')}}({{countdown}})</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import VisitorImage from './components/visitor-image.vue';
import api from '@/api/visitor.ts';
import {Cache} from '@/utils/cache';
import {EventBus} from '@/utils/eventbus';
import {visitorSelectData} from "@/utils/constants";
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    VisitorImage
  }
})
export default class VisitorReservation extends Vue {//预约
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:false}) data!: any;
  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    clearInterval(this.timer);
    n && this.initData();
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  visitorSelectData:any=visitorSelectData;
  countdown:number=10;
  timer:any=null;
  formatData:any={
    guest:null,
    guestLog:{
      idImageUrl:'',
      name:'',
      idNumber:'',
      nation:'',
      address:''
    }
  };
  loading:boolean=false;
  /* methods */
  initData(){
    if(this.data){
      this.formatData = this.data
    }else{
      this.formatData={
        guest:null,
        guestLog:{
          idImageUrl:'',
          name:'',
          idNumber:'',
          nation:'',
          address:''
        }
      };
    }
    this.loading = false;
    this.countdown = 10;
    this.countdownTime();
  }
  countdownTime(){
    this.timer = setInterval(()=>{
      if(this.countdown>0){
        this.countdown--;
      }else{
        this.agree();
      }
    },1000);
  }
  destroyed() {
    clearInterval(this.timer);
  }
  handleClose(){
    this.$emit('close')
  }
  agree(){
    this.handleClose();//访客修改逻辑
    clearInterval(this.timer);

  }
  agreeOrRefuseVisitor(pass){//pass --> 1允许 2不允许; type --> 1 预约访客 2临时访客 3同行访客;
    const user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
    return api.addVisitorRecord({
      pass,
      type:1,
      libraryId:this.data.guest?this.data.guest.libraryId:'',
      activationTime:this.data.guest?this.data.guest.activationTime:'',
      expirationTime:this.data.guest?this.data.guest.expirationTime:'',
      visitPurpose:this.data.guest?this.data.guest.visitPurpose:'',
      phone:this.data.guest?this.data.guest.phone:'',
      unawaresName:this.data.guest?this.data.guest.unawaresName:'',
      idNumber:this.data.guestLog.idNumber,
      guestLogId:this.data.guestLog.guestLogId,
      name:this.data.guestLog.name,
      guestId:this.data.guest?this.data.guest.guestId:'',
      guestCode:this.data.guest?this.data.guest.guestCode:'',
      floorId:this.data.floorId,
      deviceId:this.data.deviceId,
      deviceGroupId:this.data.deviceGroupId,
      updateBy:user.userId || ''
    });
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.visitor-reservation-content{
  display: flex;
  width: 100%;
  padding-top: 24px;
  &>div{
    width:100%;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: center;
    .visitor-reservation-img{
      width: 144px;
      height: 192px;
    }
    .visitor-reservation-text{
      padding-left: 24px;
      position: relative;
       width: 300px;
      .visitor-reservation-formtext{
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
      }
      .icon-renzhengbufu{
        position: absolute;
        right: 0;
      }
    }
    .visitor-reservation-formtext-libraryNames{
      max-height: 90px;
      overflow-y: auto;
    }
  }
}
</style>
