<template>
  <div class="visitor-senseID">
    <VisitorDifference :visible="showDifferenceDialog" @close="handleCloseDifferenceDialog" :data="differenceVisitorData"/>
    <VisitorAlarm :visible="showAlarmDialog" @close="showAlarmDialog = false" :data="alarmVisitorData" />
    <VisitorReservation :visible="showReservationDialog" @close="showReservationDialog = false" :data="reservationVisitorData"/>
    <VisitorTemporary :visible="showTemporaryDialog" @close="showTemporaryDialog = false" :data="temporaryVisitorData"/>
    <VisitorTogether :visible="showTogetherDialog" @close="showTogetherDialog = false" :data="togetherVisitorData" :reservationData="togetherReservationData" @rebrush="rebrushTogether"/>
    <VisitorAlready :visible="showAlreadyDialog" @close="showAlreadyDialog = false" :data="alreadyVisitorData"/>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import VisitorDifference from './visitor-difference.vue';
import VisitorAlarm from './visitor-alarm.vue';
import VisitorReservation from './visitor-reservation.vue';
import VisitorTemporary from './visitor-temporary.vue';
import VisitorTogether from './visitor-together.vue';
import VisitorAlready from './visitor-already.vue';
import { Stomp } from "stompjs/lib/stomp.min.js";
import SockJS from "sockjs-client";
import {Cache} from '@/utils/cache';
import {EventBus} from '@/utils/eventbus';
import Visitor from '@/views/visitor/index.vue';


const visitorWSHost = window.globalConfig.visitorWS;

@Component({
  components: {
    VisitorDifference,
    VisitorAlarm,
    VisitorReservation,
    VisitorTemporary,
    VisitorTogether,
    VisitorAlready
  }
})
export default class VisitorSenseID extends Vue {
  /* props */

  /* watch */

  /* data */
  showDifferenceDialog:boolean=false;
  showAlarmDialog:boolean=false;
  showReservationDialog:boolean=false;
  showTemporaryDialog:boolean=false;
  showTogetherDialog:boolean=false;
  showAlreadyDialog:boolean=false;

  socket:any=null;
  socketClient:any=null;

  differenceVisitorData:any=null;
  alarmVisitorData:any=null;
  reservationVisitorData:any=null;
  temporaryVisitorData:any=null;
  togetherVisitorData:any=null;
  togetherReservationData:any=null;
  alreadyVisitorData:any=null;

  countDown:number=0;
  cacheTogetherReservationData:any=null;
  /* methods */
  mounted() {
    this.countDown = 0;
    // EventBus.$on('visitor-senseID-dialog-together',(data)=>{this.addTogetherVisitor(data)});
    this.$permission('021308') && this.connectSenseIDWS();
    // setTimeout(()=>{//test------------
    //   let data = {
    //     "deviceGroupId":"112",
    //     "deviceId":"313",
    //     "floorId":"20",
    //     "guest":{
    //       "activationTime":"2019-09-09 13:38:24",
    //       "createBy":1,
    //       "createTime":"2019-09-09 13:38:24",
    //       "deviceId":"313",
    //       "expirationTime":"2019-09-09 23:59:59",
    //       "floorId":"20",
    //       "groupId":"112",
    //       "guestCode":"20190909133824067381",
    //       "guestId":405,
    //       "guestLogId":14482,
    //       "idNumber":"411326199604142122",
    //       "libraryId":"258",
    //       "name":"狂龙",
    //       "pass":"1",
    //       "phone":"111111111111111111111111111111111111111111111111111111111111111111",
    //       "state":"2",
    //       "targetId":null,
    //       "type":"2",
    //       "unawaresName":'张三1111111111111111111111111111111111111111111111111111111111111111111',
    //       "unawaresPhone":'1122211212111111111111111111111111111111111111111111111111111111111111111111',
    //       "updateBy":null,
    //       "updateTime":null,
    //       "vehicleNumber":"1233211231232111111111111111111111111111111111111111111111111",
    //       "visitPurpose":null,
    //       "visitTime":"2019-09-09 13:38:24"
    //     },
    //     "guestLog":{
    //       "address":"上海市徐汇区希望村幸福街平安巷666号",
    //       "authority":"彩虹市公安局",
    //       "birthday":"19950506",
    //       "cardType":" ",
    //       "createTime":"2019-09-09 13:42:10",
    //       "deviceId":"313",
    //       "faceImageUrl":"senseguard-oauth2/api/v1/osg/images/GUEST/20190909-054210a37-72a5559c5829b3-00000000-00019308",
    //       "guestLogId":14510,
    //       "idImageUrl":"senseguard-oauth2/api/v1/osg/images/GUEST/20190909-054210a38-72a554af4ff7dc-00000000-00019308",
    //       "idNumber":"411326199604142122",
    //       "name":"狂龙",
    //       "nation":"汉",
    //       "sex":"1",
    //       "validity":"20170310-20370310",
    //       "verifyResult":"0",
    //       "verifyScore":null
    //     },
    //     "libraryNames":["临时访客库","临时访客库2","临时访客库3","临时访客库4"],
    //     "reservation":"2"
    //   };
    //   this.handleWSData(data)
    // },5000)
  }
  addTogetherVisitor(data){
    this.showTogetherDialog = true;
    this.togetherVisitorData = null;
    this.togetherReservationData = data;
    this.cacheTogetherReservationData = data;
  }
  rebrushTogether(){
    this.showTogetherDialog = false;
    let cacheData = this.cacheTogetherReservationData;
    setTimeout(()=>{
      this.addTogetherVisitor(cacheData)
    },200)
  }
  connectSenseIDWS(){
    const user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
    this.socket = new SockJS(`${visitorWSHost}/websocket`);
    this.socketClient = Stomp.over(this.socket);
    this.socketClient.connect({},
      (frame)=> {
        this.socketClient.subscribe(`/topic/msg/subscribe/${user.userId}`,  (res) =>{
          res = JSON.parse(res.body) ;
          console.log(res);
          this.handleWSData(res);
        });
      },(error)=> {
      }
    );
    // this.socket.onclose = (e) =>{
    //   // this.countDown == 0 && this.$message.error('Guest Websocket close:'+e.reason);
    //   this.countDown=1;
    //   setTimeout(()=>{
    //    this.connectSenseIDWS();
    //   },2000);
    // };
  }
  handleWSData(res){
    EventBus.$emit('new-visitor');
    if(res.reservation == 0){//临时
      this.temporaryVisitorData = res;
      this.showTemporaryDialog = true;
    }
    if(res.reservation == 1 ||res.reservation == 3){//预约 (|| 提前)
      this.reservationVisitorData = res;
      this.showReservationDialog = true;
    }
    if(res.reservation == 2){//预约二次刷脸认证
      this.alreadyVisitorData = res;
      this.showAlreadyDialog = true;
    }
  }
  setAllFalse(){
    this.showDifferenceDialog = false;
    this.showAlarmDialog = false;
    this.showReservationDialog = false;
    this.showTemporaryDialog = false;
    this.showTogetherDialog = false;
  }
  hasDialog(){
    return this.showDifferenceDialog || this.showAlarmDialog || this.showReservationDialog || this.showTemporaryDialog || this.showReservationDialog ||this.showAlreadyDialog;
  }
  handleCloseDifferenceDialog(data?){
    this.showDifferenceDialog = false;
    if(data){
      this.alarmVisitorData = data;
      this.showAlarmDialog = true;
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";

</style>
