<template>
  <div class="visitor-export">
    <div class="text-right">
      <el-button
        v-if="$permission('021307')"
        type="primary"
        size="medium"
        icon="el-icon-upload2"
        @click="dialogVisible = true"
        :disabled="count == 0"
        style="margin-bottom: 4px;"
      >{{$t('visitor.visitorlist.labelExport')}}</el-button>
    </div>
    <!--<el-dialog-->
      <!--:title="$t('visitor.visitorlist.labelExport')"-->
      <!--width="30%"-->
      <!--:visible.sync="dialogVisible"-->
      <!--v-if="dialogVisible"-->
    <!--&gt;-->
      <!--<br />-->
      <!--<el-form-->
        <!--ref="exportForm"-->
        <!--:model="form"-->
        <!--label-width="80px"-->
        <!--label-position="left"-->
        <!--size="small"-->
      <!--&gt;-->
        <!--<el-form-item style="width: 400px;" :label="$t('log.contQuantity')" prop="visitorDate">-->
          <!--<div class="outNum" style="display: flex;">-->
            <!--<el-input-->
              <!--@input="inputStartNum"-->
              <!--maxlength="9"-->
              <!--v-model="starNum"></el-input>-->
            <!--<span class="xian"> ~ </span>-->
            <!--<el-input-->
              <!--@input="inputEndNum"-->
              <!--maxlength="9"-->
              <!--v-model="endNum"></el-input>-->
          <!--</div>-->
          <!--&lt;!&ndash;提示语&ndash;&gt;-->
          <!--<div style="height: 20px;line-height:20px;color: red;text-align: center;margin-top: 5px;">-->
            <!--{{tipsWords}}-->
          <!--</div>-->
        <!--</el-form-item>-->
      <!--</el-form>-->

      <!--<span slot="footer" class="dialog-footer">-->
        <!--<el-button type="primary" @click="dialogShowVisible  = true">{{$t('visitor.visitorlist.btnOk')}}</el-button>-->
        <!--<el-button-->
          <!--type="info"-->
          <!--@click="dialogVisible = false"-->
        <!--&gt;{{$t('visitor.visitorlist.btnCancel')}}</el-button>-->
      <!--</span>-->
    <!--</el-dialog>-->

    <!--导出提示-->
    <el-dialog
      :title="$t('visitor.visitorlist.labelExport')"
      :visible.sync="dialogVisible"
      width="30%">
      <div class="export-content">
        <!--确认导出筛选后的内容吗？-->
        {{$t('globaltip.tipExport')}}
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="loading" @click="exportVisitor">{{$t('visitor.visitorlist.btnOk')}}</el-button>
        <el-button class="cancel" type="info" @click="dialogVisible  = false">{{$t('visitor.visitorlist.btnCancel')}}</el-button>
     </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch,Prop } from "vue-property-decorator";
import { Form as ElForm } from "element-ui";
import Icon from "@/components/icon-wrap/index.vue";
import { Cache } from "@/utils/cache";
import visitorApi from "@/api/visitor";

let vm = null as any;

@Component({
  components: {
    Icon
  }
})
export default class VisitorExport extends Vue {
  visitStatistics = {};
  isVisitorAdd = false;
  exportForm: any = {};
  form: any = {};
  exportParams: any = {};
  visitorCount = "";
  isExceed = false;
  dialogVisible = false;
  starNum = null as any;
  endNum = null as any;
  tipsWords = '' as any;
  dialogShowVisible:boolean = false;
  loading:boolean = false;

  @Prop(Number) count!: any;
  @Prop(Number) visitType!: any;
  @Prop(Number) visitState!: any;
  @Prop(String) startTime!: any;
  @Prop(String) endTime!: any;
  @Prop(String) keywords!: any;

  @Watch('dialogVisible')
  onBoolChange(val:any){
    if (!val){
      this.starNum = null;
      this.endNum = null;
    }
  }

  created() {
    vm = this as any;
  }
  mounted() {}

  //输入验证
  inputStartNum(val){
    if(this.verifySize(val)){
      this.starNum = val
    }else{
      this.starNum = '';
    }
  }
  //输入验证
  inputEndNum(val){
    if(this.verifySize(val)){
      this.endNum = val
    }else{
      this.endNum = '';
    }

  }
  //输入验证
  verifySize(val){
    // let reg = /^\d*$/
    let reg = /^([1-9]{1})\d*$/
    if(reg.test(val)|| val==""){
      this.tipsWords="";
      return true;
    }else{
      this.tipsWords= this.$t("records.exportError");
      setTimeout(()=>{
        this.tipsWords=""
      },2000)
      return false;
    }
  }

  exportVisitor() {
    let that = this as any ;
    that.loading = true;


    // if (this.endNum-this.starNum<0){
    //   // this.tipsWords = '导出区间不能超过人像库总条数'
    //   this.tipsWords = that.$t('form.texterrExport2')
    //   setTimeout(()=>{
    //     this.tipsWords = '';
    //   },2000)
    //   return;
    // }
    //
    // if(this.endNum-this.starNum>=1000){
    //   // this.tipsWords = '请输入规范的数字，每次支持导出1000条'
    //   this.tipsWords = that.$t('form.texterrExport1')
    //   setTimeout(()=>{
    //     this.tipsWords = '';
    //   },2000)
    //   return;
    // }


    let params = {
      type: this.visitType,
      state: this.visitState,
      startTime: this.startTime,
      endTime: this.endTime,
      from: 1,
      keyWord:this.keywords,
      to: 999999,
      userId: Cache.sessionGet("userInfo").userId
    };
    console.log(params);
    visitorApi
      .exportVisitorData(params)
      .then((res: any) => {
        //console.log("导出成功",res);
        this.isExceed = false;
        //大于1000条
        // if (res.count > 1000) {
        //   this.visitorCount = res.count;
        //   this.isExceed = true;
        //   return;
        // }
        if (res.count < 1) {
          this.$message({
            showClose: true,
            // message: "期间无访客信息", //No visitor information during this period
            message: that.$t('visitor.visitorlist.tipmsgNoPeople'),
            type: "warning"
          });
        }else if (!res.code) {
          this.$message({
            showClose: true,
            message: that.$t('log.exportSuccess'),
            type: "success"
          });
        }
        this.dialogVisible = false;
        this.dialogShowVisible  = false;
        that.loading = false;
      })
      .catch(err => {
        that.loading = false;
        console.log(err);
      });
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.visitor-export {
  /*padding-bottom: 8px;*/
  /*border-bottom: 2px solid #2a5af5;*/
  margin-bottom: 4px;
  .text-right {
    text-align: right;
  }
  .outNum .xian{
    margin:0 10px;
  }
  .export-content{
    font-weight: 600;
    width:100%;
    /*font-size: 16px;*/
    text-align: center;
  }
}
</style>

