<template>
<div class="visitor">

  <head-preview @onFreshList="fetchVisitList"/>
  <VisitorContainer ref="visitCotainer"/>

  <!-- <div class="fixed-tools">
    <ul>
      <li><el-button type="primary" size="mini" @click="dialogVisible = true">车牌输入</el-button></li>
      <li><el-button type="primary" size="mini" icon="el-icon-upload2">导出</el-button></li>
    </ul>
  </div>

  <el-dialog
    title="提示"
    :visible.sync="dialogVisible"
    width="30%"
    :close-on-click-modal="false">
    <el-form ref="form" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="车牌号" prop="carNumber">
        <plate-number v-model="form.carNumber" :oldCarNumber="form.carNumber" :length="6" @getCarNumber="getCarNumber"></plate-number>
      </el-form-item>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      <el-button type="info" @click="dialogVisible = false">取 消</el-button>
    </span>
  </el-dialog> -->

</div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import { Route } from 'vue-router';
import HeadPreview from './components/head-preview.vue';
import VisitorContainer from './components/main.vue';
import PlateNumber from '@/components/plate-number/plate-number.vue';
import {EventBus} from '@/utils/eventbus';
import  { VisitorModule } from '@/store/modules/visitor';

var url = window.globalConfig.login;

@Component({
  components: {
    PlateNumber,
    HeadPreview,
    VisitorContainer,
  }
})
export default class Visitor extends Vue {
  keyId:any="";
  dialogVisible = false;
  form={
    carNumber:''
  };
  redirect: string | undefined = undefined;
  rules = {
    carNumber: [
      { required: true, message: '请输入车牌号', trigger: 'blur' },
      { min: 6, max: 8, message: '输入不正确', trigger: 'blur' }
    ],
  }

  @Watch('$route', { immediate: true })
  OnRouteChange(route: Route) {
    this.redirect = route.query && route.query.redirect as string;
  }
  mounted(){
    //do something
    // EventBus.$on('visitor-seneid-dialog-close',()=>{
    //   this.fetchVisitList();
    //   VisitorModule.getVisitorStatistics();
    // })
  }
  getCarNumber(data,error){
    if(error){
      console.log(error)
    }else{
      this.form.carNumber = data;
      console.log(this.form)
    }

  }
  fetchVisitList(){
    (this.$refs.visitCotainer as any).fetchVisitList()
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
.visitor{
  height:100%;
  padding:0 8px;
}
</style>
