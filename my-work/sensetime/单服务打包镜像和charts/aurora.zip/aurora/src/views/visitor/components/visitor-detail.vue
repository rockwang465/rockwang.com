<template>
<div class="visitor-detail-container">
  <div class="id-card-detail">
    <!--<div class="visitorType">-->
      <!--<Icon-->
        <!--size="72"-->
        <!--name="yuyuefangke"-->
        <!--class="bespeak"-->
      <!--/>-->
    <!--</div>-->
    <div class="showId" v-if="visitorObj&&visitorObj.guestId">
      <div v-if="!isShowId" @click="idShowOrHid('show')"><i class="iconfont icon-eye" style="font-size:12px;color:#2A5AF5"></i></div>
      <div v-else @click="idShowOrHid('hide')"><i class="iconfont icon-eye" style="font-size: 12px;"></i></div>
    </div>
    <div class="avatar">
      <img :src="visitorObj.idImageUrl?processImgurl(visitorObj.idImageUrl):'/images/user-01.png'">
    </div>
    <div class="card-detail">
      <div class="line">
        <!--姓名-->
        <span class="left" :class="enClass">{{$t('visitor.senseid.labelName')}}：</span>
        <span class="right">{{myDetailObj.name}}</span>
      </div>
      <div class="line">
        <!--身份证号-->
        <span class="left" :class="enClass">{{$t('visitor.senseid.labelIdnumber')}}：</span>
        <span class="right">{{myDetailObj.idNumber}}</span>
      </div>
      <div class="line">
        <!--民族-->
        <span class="left" :class="enClass">{{$t('visitor.senseid.labelNation')}}：</span>
        <span class="right">{{myDetailObj.nation}}</span>
      </div>
      <div class="line">
        <!--户籍地址-->
        <span class="left" :class="enClass">{{$t('visitor.senseid.labelAdress')}}：</span>
        <span class="right">{{myDetailObj.address}}</span>
      </div>
    </div>
  </div>
  <div class="parting-line"></div>
  <div class="visitor-detail">
    <div class="title">
      <!--访客详情-->
      <div>{{$t('visitor.visitorlist.titleVisitorDetail')}}</div>
      <!--<el-button size="mini" v-show="myDetailObj.status == 1" v-if="$permission('021302')" @click="isVisitorAdd = true" type="primary" icon="el-icon-edit">{{$t('visitor.visitorlist.labelReserve')}}</el-button>-->
      <el-button size="mini" v-show="myDetailObj.status <= 2" v-if="$permission('021302')" @click="isVisitorAdd = true" type="primary" icon="el-icon-edit">{{$t('visitor.visitorlist.labelReserve')}}</el-button>
    </div>
    <div class="content">
      <div class="content-left">
        <div class="line">
          <!--访客类型-->
          <div class="left" :class="enClass">{{$t('visitor.visitorlist.titleVisitorType2')}}：</div>
          <!--<div class="right">{{myDetailObj.type == 1?'预约访客':myDetailObj.type == 2?'临时访客':''}}</div>-->
          <div class="right">{{myDetailObj.type == 1?$t('visitor.senseid.titleReservation'):myDetailObj.type == 2?$t('visitor.senseid.titleTemporary'):''}}</div>
        </div>
        <div class="line">
          <!--联系方式-->
          <div class="left" :class="enClass">{{$t('visitor.senseid.labelContact')}}：</div>
          <el-tooltip v-if="myDetailObj.phone&&myDetailObj.phone.length>10" class="item" effect="dark" :content="myDetailObj.phone" placement="top">
            <div class="right">{{myDetailObj.phone}}</div>
          </el-tooltip>
          <div class="right" v-else>{{myDetailObj.phone}}</div>
        </div>

        <div class="line">
          <!--激活时间-->
          <div class="left" :class="enClass">{{$t('visitor.senseid.labelActiveTime')}}：</div>
          <div class="right">{{myDetailObj.activationTime}}</div>
        </div>

        <div class="line">
          <!--失效时间-->
          <div class="left" :class="enClass">{{$t('visitor.senseid.labelInvalidTime')}}：</div>
          <div class="right">{{myDetailObj.expirationTime}}</div>
        </div>

      </div>
      <div class="content-right">
        <div class="line">
          <!--接待人-->
          <div class="left" :class="enClass">{{$t('visitor.senseid.labelRecepter2')}}：</div>
          <!--<div class="right">{{myDetailObj.unawaresName}}</div>-->
          <el-tooltip v-if="myDetailObj.unawaresName&&myDetailObj.unawaresName.length>10" class="item" effect="dark" :content="myDetailObj.unawaresName" placement="top">
            <div class="right portrait-manage">{{myDetailObj.unawaresName}}</div>
          </el-tooltip>
          <div class="right" v-else>{{myDetailObj.unawaresName}}</div>
        </div>

        <div class="line">
          <!--车牌号-->
          <!--<div class="left" :class="enClass">{{$t('visitor.visitorlist.labelCarNumber')}}：</div>-->
          <!--//接待人联系方式-->
          <div class="left" :class="enClass">{{$t('visitor.visitorlist.contact')}}：</div>
          <!--<div class="right">{{myDetailObj.unawaresPhone}}</div>-->
          <el-tooltip v-if="myDetailObj.unawaresPhone&&myDetailObj.unawaresPhone.length>10" class="item" effect="dark" :content="myDetailObj.unawaresPhone" placement="top">
            <div class="right portrait-manage">{{myDetailObj.unawaresPhone}}</div>
          </el-tooltip>
          <div class="right" v-else>{{myDetailObj.unawaresPhone}}</div>
        </div>

        <div class="line">
          <!--来访目的-->
          <div class="left" :class="enClass">{{$t('visitor.senseid.labelPurpose2')}}：</div>
          <div class="right">{{selectData[myDetailObj.visitPurpose]}}</div>
        </div>

        <div class="line">
          <!--车牌号-->
          <div class="left" :class="enClass">{{$t('visitor.visitorlist.labelCarNumber')}}：</div>
          <!--<div class="right">{{myDetailObj.vehicleNumber}}</div>-->
          <el-tooltip v-if="myDetailObj.vehicleNumber&&myDetailObj.vehicleNumber.length>10" class="item" effect="dark" :content="myDetailObj.vehicleNumber" placement="top">
            <div class="right portrait-manage">{{myDetailObj.vehicleNumber}}</div>
          </el-tooltip>
          <div class="right" v-else>{{myDetailObj.vehicleNumber}}</div>
        </div>

        <div class="line">
          <!--添加人-->
          <div class="left" :class="enClass">{{$t('visitor.visitorlist.labelAdd2')}}：</div>
          <!--<div class="right">{{myDetailObj.createByName}}</div>-->
          <el-tooltip v-if="myDetailObj.createByName&&myDetailObj.createByName.length>10" class="item" effect="dark" :content="myDetailObj.createByName" placement="top">
            <div class="right portrait-manage">{{myDetailObj.createByName}}</div>
          </el-tooltip>
          <div class="right" v-else>{{myDetailObj.createByName}}</div>

        </div>


        <div class="line">
          <!--人像库-->
          <div class="left" :class="enClass">{{$t('visitor.visitorlist.labelLibrary2')}}：</div>
          <div class="wrap" v-if="myDetailObj.libraryId && libraryList && libraryList.length>0" >
            <div v-for="(library,libraryIndex) in getLibraryName(libraryList,myDetailObj.libraryId)" :key="libraryIndex" >
              <el-tooltip v-if="library.length>10" class="item" effect="dark" :content="library" placement="top">
                <div class="portrait-manage">{{library}}</div>
              </el-tooltip>
              <div v-else>{{library}}</div>
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>
  <!--1.2.1删除同行访客功能-->
  <!--<div class="visitor-together" v-loading="loading" v-show="visitorObj.status == 2">-->
    <!--<div class="title">-->
      <!--&lt;!&ndash;同行访客&ndash;&gt;-->
      <!--<div class="name">{{$t('visitor.senseid.constTogether')}}</div>-->
      <!--<div v-if="$permission('021404')" v-show="togetherList.length>0" class="btn" @click="showTogetherDel">-->
        <!--<Icon size="16"-->
        <!--name="user"-->
        <!--class="user"></Icon>-->
        <!--<span>{{togetherFields === 1?$t('visitor.visitorlist.titleManagement'):$t('visitor.visitorlist.btnCancel')}}</span>-->
      <!--</div>-->
    <!--</div>-->
    <!--<div class="together-list">-->
      <!--<div class="together-person" v-for="(item,index) in togetherList">-->
        <!--<el-popover-->
          <!--placement="right"-->

          <!--trigger="hover"><div class="card-detail">-->
          <!--<div class="line">-->
            <!--&lt;!&ndash;姓名&ndash;&gt;-->
            <!--<span class="left">{{$t('visitor.senseid.labelName')}}：</span>-->
            <!--<span class="right">{{item.name}}</span>-->
          <!--</div>-->
          <!--<div class="line">-->
            <!--&lt;!&ndash;身份证号&ndash;&gt;-->
            <!--<span class="left">{{$t('visitor.senseid.labelIdnumber')}}：</span>-->
            <!--<span class="right">{{item.idNumber}}</span>-->
          <!--</div>-->
          <!--<div class="line">-->
            <!--&lt;!&ndash;民族&ndash;&gt;-->
            <!--<span class="left">{{$t('visitor.senseid.labelIdnumber')}}：</span>-->
            <!--<span class="right">{{item.labelNation}}</span>-->
          <!--</div>-->
          <!--<div class="line">-->
            <!--&lt;!&ndash;户籍地址&ndash;&gt;-->
            <!--<span class="left">{{$t('visitor.senseid.labelAdress')}}：</span>-->
            <!--<span class="right">{{item.address}}</span>-->
          <!--</div>-->
        <!--</div>-->

          <!--&lt;!&ndash;<el-button slot="reference">hover 激活</el-button>&ndash;&gt;-->
          <!--<img slot="reference" :src="item.idImageUrl?processImgurl(item.idImageUrl):''">-->
        <!--</el-popover>-->

        <!--<div class="del" @click="getTogetherId(item.guestId)" v-show="isTogetherDel">-->
          <!--<Icon-->
            <!--size="16"-->
            <!--name="jian"-->
            <!--class="jian"-->
          <!--/>-->
        <!--</div>-->
        <!--<div style="text-align: center;margin-top: 2px;">{{item.name}}</div>-->
      <!--</div>-->
      <!--<div v-if="$permission('021303')" class="person-add" @click="showEventBus">-->
        <!--<div  class="upload">-->
          <!--&lt;!&ndash;for="img-upload-btn"&ndash;&gt;-->
          <!--<span><i class="iconfont el-icon-plus"></i></span>-->
          <!--&lt;!&ndash;<img v-show="!showIcon" id="selectedImg">&ndash;&gt;-->
        <!--</div>-->
        <!--&lt;!&ndash;<input style="display: none;" type="file" id="img-upload-btn" accept="image/*" @change="upImage($event)"/>&ndash;&gt;-->
      <!--</div>-->
    <!--</div>-->
  <!--</div>-->
  <el-dialog
    :title="$t('usermanagement.titleReminder')"
    :visible.sync="isTogetherDelDialog"
    width="30%">
    <!--确定删除该同行人员？-->
    <span>{{$t('visitor.visitorlist.tipsDeleteTogether')}}</span>
    <span slot="footer" class="dialog-footer">
    <el-button type="primary" @click="togetherDel">{{$t('visitor.visitorlist.btnOk')}}</el-button>
    <el-button @click="isTogetherDelDialog = false">{{$t('visitor.visitorlist.btnCancel')}}</el-button>
  </span>
  </el-dialog>

  <!--    输入密码显示id弹窗-->
  <el-dialog
    :title="$t('imagemanagement.importPassWord')"
    :visible.sync="isShowIdVisible"
  >
    <el-form :model="pwd" :rules="ruleList" ref="pwdForm" label-width="150px" @submit.native.prevent>
      <el-form-item :label="$t('imagemanagement.userPassWord')" prop="password">
        <el-input type="password" v-model="pwd.password"></el-input>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="deleteBtn" @click="showIdFn">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button @click="isShowIdVisible = false" type="info" class="cancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
  </el-dialog>


  <VisitorAdd @closeVisitorAdd="closeVisitorAdd"  :visitorObj="visitorObj" @edited="doing" :dialogVisible="isVisitorAdd"></VisitorAdd>
</div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import  Icon from '@/components/icon-wrap/index.vue';
import {fileValidate} from '@/utils/validate';
import {EventBus} from '@/utils/eventbus';
import VisitorAdd from './visitor-add.vue'
import visitorApi from '@/api/visitor';
import {PortraitModule} from '@/store/modules/portrait';
import {processImgurl} from '@/utils/image.ts';
import {visitorSelectData} from '@/utils/constants';
import {AppModule} from '@/store/modules/app';
import {Form as ElForm} from "element-ui/types/element-ui";
import {UserModule} from "@/store/modules/user";
import i18n from "@/lang";


@Component({
  components: {
    Icon,
    VisitorAdd
  },
  computed:{
    enClass:function () {
      let that = this as any;
      return that.language === 'en' ? "left2" : "";
    }
  }
})
export default class VisitorDetailContainer extends Vue {
  get language() {
    return AppModule.language;
  }
  showIcon = true;
  isVisitorAdd = false;
  isTogetherDelDialog = false;//显示删除同行人弹窗；
  togetherList=[] as any;
  conditions = {file: null}; //添加同行
  libraryList :any[]=[];
  libraryName = '';
  visitPurpose = '';
  isTogetherDel = false;
  togetherGuestId = null as any;
  togetherFields = 1;
  loading = false;
  myDetailObj = {} as any;
  // selectData = [{id:1,label:'面试'},{id:2,label:'会议'},{id:3,label:'活动'},{id:4,label:'家长'},{id:5,label:'其它'}]
  selectData=visitorSelectData;
  processImgurl:any=processImgurl;
  isShowId:boolean = false;
  isShowIdVisible:boolean = false;
  pwd = {
    password: ''
  };
  idStr:string = '';
  ruleList = {
    password:[
      { required: true, message: i18n.t('imagemanagement.passWordImport')+"", trigger: 'blur' }
    ]
  };
  @Prop(Object) visitorObj!:any

  @Watch('visitorObj')
  onLibraryListChange(val:any){
    let that = this as any;
    that.isTogetherDel = false;//初始化
    that.togetherFields = 1;//初始化
    if (val.guestId){//如果左边列表有内容
      this.queryGuestInfoByGuestId(val.guestId)
    }else{
      //如果左边列表没有内容
      // debugger
      that.myDetailObj = {} as any;
    }
  }


  created(){
    this.getLibsList();
  }
  mounted(){
    //do something
    let that = this as any;
    EventBus.$on('visitor-seneid-dialog-closetogether',()=>{
      if (that.visitorObj){
        that.queryGuestInfoByGuestId(that.visitorObj.guestId)
      }
    });
  }
  closeVisitorAdd(){
    this.isVisitorAdd = false;
  }
  showEventBus(){
    // let data = {} as any;
    // data.idImageUrl = this.visitorObj.idImageUrl;
    // data.name = this.visitorObj.name;
    // data.idNumber = this.visitorObj.idNumber;
    // data.nation = this.visitorObj.nation;
    // data.address = this.visitorObj.address;
    // data.libraryId=this.visitorObj.libraryId
    // data.activationTime=this.visitorObj.activationTime
    // data.expirationTime=this.visitorObj.expirationTime
    // data.visitPurpose=this.visitorObj.visitPurpose
    // data.phone=this.visitorObj.phone
    // data.unawaresName=this.visitorObj.unawaresName
    // data.guestId = this.visitorObj.guestId;
    // data.guestCode = this.visitorObj.guestCode;
    EventBus.$emit('visitor-senseID-dialog-together',this.visitorObj);
  }

  doing(){
    this.$emit('onFreshList')
    // this.queryGuestInfoByGuestId(this.visitorObj.guestId)
  }

  getLibsList(){
    let that = this as any;
    PortraitModule.SearchLibraries({}).then((data: any) => {
      let val = data.whitelists;

      that.libraryList = val;
      // for (let i = 0;i < val.length;i++){
      //   that.$set(that.libraryList,i,{libraryId:val[i].libraryId,libraryName:val[i].libraryName});
      // }
    }).catch(err=>{
      console.log(err);
    })
    // visitorApi.getLibsList().then((res)=>{
    //   console.log(res.whitelists);
    //   res.whitelists.map((item:any)=> {
    //     this.libraryList.push({
    //       id: item.libraryId,
    //       label: item.libraryName
    //     })
    //   })
    // }).catch(err=>{
    //   console.log(err);
    // })
  }

  showTogetherDel(){
    this.isTogetherDel = !this.isTogetherDel
    if (this.isTogetherDel){
      this.togetherFields = 2
    }else{
      this.togetherFields = 1
    }
  }

  getTogetherId(guestId){
    this.togetherGuestId = guestId;
    this.isTogetherDelDialog = true;
  }

  togetherDel(){
    this.isTogetherDelDialog = false;
    this.loading = true;
    let that = this as any;
    visitorApi.delGuest(this.togetherGuestId ).then((res)=>{
      this.$message({
        showClose: true,
        message:that.$t('globaltip.tipDeleteTogether'),
        type: 'success'
      })
      this.loading = false;
      this.queryGuestInfoByGuestId(this.visitorObj.guestId)
    }).catch(err=>{
      this.loading = false;
    })
  }

  addFollowVisitor(){
    console.log("添加同行访客")
  }

  //id的展示加密与隐藏加密
  idShowOrHid(str:string){
    if (str === 'show'){
      // this.isShowId = true;
      this.isShowIdVisible = true;
    }else if(str === 'hide'){
      this.isShowId = false;
      this.myDetailObj.idNumber = this.idStr;
    }
  }

  @Watch('isShowIdVisible')
  onIsShowIdVisibleChange(val: any) {
    this.$nextTick(()=>{
      (this.$refs.pwdForm as ElForm).clearValidate();
    })
  }

  showIdFn(){
    (this.$refs.pwdForm as ElForm).validate((valid) => {
      if (valid) {
        let params = {
          password:'',
          secret:''
        };
        params.password = this.pwd.password;
        params.secret = this.myDetailObj.cipherText;
        UserModule.getPortraitId(params).then((res)=>{
          this.myDetailObj.idNumber = (res as any).decryptStr;
          this.isShowId = true;
        }).finally(()=>{
          this.isShowIdVisible = false;
          this.pwd.password = '';
        })
      }else {
        return false;
      }
    });
  }

  queryGuestInfoByGuestId(guestId){
    let that = this as any;
    visitorApi.queryGuestInfoByGuestId(guestId).then((res:any)=>{
      this.myDetailObj = res;
      this.idStr = res.idNumber;
      this.myDetailObj['libraryId'] = res.libraryId?res.libraryId.split(','):[];
      that.togetherList = (res as any).peerVisitorList
      if (this.myDetailObj.status > 2){
        this.closeVisitorAdd();
      }
    }).catch(err=>{
      console.log(err);
    })
  }
  getLibraryName(allLibraries,libraryIds){
    if(allLibraries && allLibraries.length>0){
      if(libraryIds && libraryIds.length>0){
        let ids = libraryIds.map(id=>{
          let libObj = allLibraries.find(lib=>{return lib.libraryId == id});
          return libObj?libObj.libraryName:'';
        })
        return ids ||[];
      }else{
        return [];
      }

    }else{
      return [];
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "@/styles/variables.scss";
    .visitor-detail-container{
        background:#fff;
        padding: 14px 32px;
        box-sizing: content-box;
        overflow: auto;
        height: calc(100% - 66px);
        @include shadowBox();
      .portrait-manage{
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      /*.id-card-detail:lang(en){*/
        /*background-color: red;*/
      /*}*/
      .id-card-detail{
        height: 200px;
        width: 100%;
        display: flex;
        color: #011C50;
        position: relative;
        .showId{
          width:80px;
          position: absolute;
          right: -5px;
          top: 38px;
          z-index: 10;
          div{
            cursor: pointer;
            user-select: none;
          }
        }
        .visitorType{
          position: absolute;
          right: 0;
          top: 0;
          .bespeak{
            color:#0F9D58;
          }
        }
        .avatar{
          width: 25%;
          margin-right: 12px;
          >img{
            width: 100%;
            max-height: 100%;
            /*height: 100%;*/
          }
        }
        .card-detail{
          height: 160px;
          flex: 1;
          margin: auto;
          display: flex;
          flex-direction: column;
          justify-content: center;
          .line{
            height: 20px;
            padding: 6px 0;
            box-sizing: content-box;
            display: flex;
            position: relative;
            font-size: 14px;
            .left{
              font-weight: 800;
              display: block;
              text-align: right;
              width: 100px;
              height: 100%;
              word-break:break-word;
            }
            .left2{
              width: 170px;
            }
            .right{
              flex: 1;
              display: block;
              opacity: 0.8;
              position: relative;
              height: 100%;
            }
          }
        }
      }
      .parting-line{
        width:100%;
        height:2px;
        background-color: #8E99AA;
        margin: 16px 0;
      }
      .visitor-detail{
        .title{
          font-size: 16px;
          font-weight:800;
          /*margin-top: 8px;*/
          margin-bottom: 12px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .content{
          /*display: flex;*/
          /*justify-content: space-between;*/
          .content-left{
            /*display: flex;*/
            /*width: 70%;*/
          }
          .content-right{
            /*display: flex;*/
            /*width: 70%;*/
          }
          .line {
            height: 20px;
            padding: 6px 0;
            box-sizing: content-box;
            display: flex;
            position: relative;
            font-size: 14px;
            .left {
              font-weight: 800;
              text-align: right;
              display: block;
              width: 120px;
              height: 100%;
              word-break:break-word;
            }
            .left2{
              width: 288px;
              text-align: right;
              word-break:break-word;
            }
            .right {
              /*flex: 1;*/
              width: 158px;
              display: block;
              opacity: 0.8;
              height: 100%;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
            }
            .wrap{
              width: 158px;
              display: block;
              opacity: 0.8;
            }
          }
        }
      }
      .visitor-together{
        .title{
          margin-top: 8px;
          margin-bottom: 12px;
          display: flex;
          justify-content: space-between;
          .name{
            font-size: 16px;
            font-weight:800;
          }
          .btn{
            height:12px;
            font-size:12px;
            font-weight:400;
            line-height:16px;
            cursor: pointer;
            user-select: none;
            >span{
              color:rgba(42,90,245,1);
              text-decoration:underline;
            }
            .user{
              margin-right: 2px;
              color: gray;
            }
          }
        }
        .together-list{
          height: 306px;
          overflow: auto;
          display: flex;
          flex-wrap: wrap;
          >div{
            margin: 2% 2%;
          }
          .person-add{
            width: 100px;
            height: 140px;
          }
          .upload{
            width: 100px;
            height: 140px;
            border: 1px dashed #707070;
            border-radius: 3px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            user-select: none;
            .el-icon-plus{
              font-size:30px;
            }
            >span{
              width: 68px;
              height: 68px;
              border:1px dashed #707070;
              border-radius: 50%;
              display: flex;
              justify-content: center;
              align-items: center;
            }
          }
          .together-person{
            width: 100px;
            height: 140px;
            position: relative;
            display: flex;
            flex-direction: column;
            img{
              width: 100px;
              height: 120px;
            }
            .del{
              position: absolute;
              top: -8px;
              right: -8px;
              width: 16px;
              height: 16px;
              .jian{
                color: red;
              }
            }
          }
        }
      }
    }
</style>
