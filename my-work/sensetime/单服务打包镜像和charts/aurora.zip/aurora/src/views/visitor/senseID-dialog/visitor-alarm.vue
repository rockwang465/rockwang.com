<template>
  <div class="visitor-alarm">
    <el-dialog
    center
    :show-close="false"
    :visible.sync="visible"
    width="60%"
    :close-on-click-modal="false"
    :before-close="handleClose">
    <span slot="title" style="font-size:16px;color:#BE0000;font-weight:bold;">{{$t('visitor.senseid.titleAlarm')}}</span>

      <div class="visitor-alarm-content">
        <div>
          <div class="visitor-alarm-img">
            <VisitorImage :src="formatData.guestLog.idImageUrl" />
          </div>
          <div class="visitor-alarm-text">
            <el-form :label-width="language == 'en'?'140px':'90px'" label-position="left" >
              <el-form-item :label="$t('visitor.senseid.labelName')+':'">
                <div class="visitor-alarm-formtext" >{{formatData.guestLog.name}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelIdnumber')+':'">
                <div class="visitor-alarm-formtext" >{{formatData.guestLog.idNumber}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelNation')+':'">
                <div class="visitor-alarm-formtext" >{{formatData.guestLog.nation}}</div>
              </el-form-item>
              <el-form-item :label="$t('visitor.senseid.labelAdress')+':'">
                <div class="visitor-alarm-formtext" >{{formatData.guestLog.address}}</div>
              </el-form-item>
            </el-form>
            <i class="iconfont icon-renzhengbufu" style="font-size:80px;color:#BE0000" ></i>
          </div>
        </div>
        <div>
          <div style="margin-right:20px;" class="visitor-alarm-form">
            <el-form :model="form1" :rules="form1Rule" ref="form1" :label-width="language == 'en'?'130px':'85px'" label-position="left">
              <el-form-item :label="$t('visitor.senseid.labelActiveTime')+':'" prop="activeTime">
                <el-date-picker
                  :disabled="true"
                  format="yyyy-MM-dd HH:mm:ss"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  v-model="form1.activeTime"
                  type="datetime">
                </el-date-picker>
              </el-form-item>

              <el-form-item :label="$t('visitor.senseid.labelRecepter')+':'" prop="recepter">
                <el-input v-model="form1.recepter" placeholder=""></el-input>
              </el-form-item>

              <el-form-item :label="$t('visitor.senseid.labelPurpose')+':'" prop="purpose">
                <el-select v-model="form1.purpose" placeholder="">
                  <el-option :value="purposeTextIndex" :label="purposeText" v-for="(purposeText,purposeTextIndex) in visitorSelectData" :key="purposeTextIndex" ></el-option>
                </el-select>
              </el-form-item>

            </el-form>
          </div>
          <div class="visitor-alarm-form">
            <el-form :model="form2" :rules="form2Rule" ref="form2" :label-width="language == 'en'?'130px':'85px'" label-position="left">

              <el-form-item :label="$t('visitor.senseid.labelInvalidTime')+':'" prop="invalidTime">
                <el-date-picker
                  format="yyyy-MM-dd HH:mm:ss"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  v-model="form2.invalidTime"
                  type="datetime">
                </el-date-picker>
              </el-form-item>

              <el-form-item :label="$t('visitor.senseid.labelLibrary')+':'" prop="library">
                <LibrarySelect @check="libraryCheck" v-if="visible" />
              </el-form-item>

              <el-form-item :label="$t('visitor.senseid.labelContact')+':'" prop="contact">
                <el-input v-model="form2.contact" placeholder=""></el-input>
              </el-form-item>
            </el-form>
          </div>
        </div>

      </div>

      <span slot="footer">
        <el-button @click="agree" v-show="$permission('021303')" type="success">{{$t('visitor.senseid.btnApproveVisit')}}</el-button>
        <el-button @click="refuseVisit" type="danger" v-show="$permission('021303')" >{{$t('visitor.senseid.btnRefuseVisit')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import LibrarySelect from './components/library-select.vue';
import VisitorImage from './components/visitor-image.vue';
import api from '@/api/visitor';
import {Cache} from '@/utils/cache';
import {EventBus} from '@/utils/eventbus';
import {visitorSelectData} from "@/utils/constants";
import i18n from '@/lang/index';
import dayjs from "dayjs";
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    LibrarySelect,
    VisitorImage
  }
})
export default class VisitorAlarm extends Vue {//告警
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:false}) data!: any;

  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.initData();
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  $refs!:{
    form1:HTMLFormElement
    form2:HTMLFormElement
  }
  visitorSelectData:any=visitorSelectData;
  //form1
  form1:{
    activeTime:string
    recepter:string
    purpose:string
  }={
    activeTime:'',
    recepter:'',
    purpose:'',
  };
  form1Rule:{
    activeTime:any[]
    recepter:any[]
    purpose:any[]
  }={
    activeTime:[
      {required: true, message: i18n.t('form.texterrAvtivetime'), trigger: 'blur' }
    ],
    recepter:[
      {required: false}
    ],
    purpose:[
      {required: false}
    ],
  };
  //form2
  form2:{
    invalidTime:string
    library:string
    contact:string
  }={
    invalidTime:'',
    library:'',
    contact:'',
  };
  form2Rule:{
    invalidTime:any[]
    library:any[]
    contact:any[]
  }={
    invalidTime:[
      {required: true, message: i18n.t('form.texterrInvalitime'), trigger: 'blur' }
    ],
    library:[
      {required: true,message: i18n.t('form.texterrSelectImageLib'), trigger: 'change'}
    ],
    contact:[
      {required: false}
    ],
  };
  loading:boolean=false;
  formatData:any = {
    guest:null,
    guestLog:{
      idImageUrl:'',
      name:'',
      idNumber:'',
      nation:'',
      address:''
    }
  };
  /* methods */
  initData(){
    this.loading = false;
    this.form1 = {
      activeTime:dayjs().format('YYYY-MM-DD HH:mm:ss'),
      recepter:'',
      purpose:'',
    };
    this.form2 = {
      invalidTime:'',
      library:'',
      contact:'',
    };
    if(this.data ){
      this.formatData = this.data;
    }else{
      this.formatData = {
        guest:null,
        guestLog:{
          idImageUrl:'',
          name:'',
          idNumber:'',
          nation:'',
          address:''
        }
      };
    }
    setTimeout(()=>{
      this.$refs.form1.clearValidate();
      this.$refs.form2.clearValidate();
    },100);
  }
  agree(){
    if(!this.data) return;
    this.$refs.form1.validate(vali1=>{
      this.$refs.form2.validate(vali2=>{
        if(vali1 && vali2){
          this.loading = true;
          this.agreeOrRefuseVisitor(1).then(e=>{
            this.handleClose();
            EventBus.$emit('visitor-seneid-dialog-close')
          }).catch(e=>{
            this.loading = false;
             e.response.data.code == '421013' && this.handleClose();//others already operate close the dialog
          }).finally(()=>{
            this.loading = false;
          });
        }
      })
    })
  }
  refuseVisit(){
    if(!this.data) return;
    // this.$refs.form1.validate(vali1=>{
    //   this.$refs.form2.validate(vali2=>{
    //     if(vali1 && vali2){
          this.loading = true;
          this.agreeOrRefuseVisitor(2).then(e=>{
            this.handleClose();
            EventBus.$emit('visitor-seneid-dialog-close')
          }).catch(e=>{
            this.loading = false;
            e.response.data.code == '421013' && this.handleClose();//others already operate close the dialog
          }).finally(()=>{
            this.loading = false;
          });
    //     }
    //   })
    // })
  }
  agreeOrRefuseVisitor(pass){//pass --> 1允许 2不允许; type --> 1 预约访客 2临时访客 3同行访客;
  const user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
    return api.addVisitorRecord({
      pass,
      type:this.data.reservation == 0?2:1,
      libraryId:this.form2.library,
      activationTime:this.form1.activeTime,
      expirationTime:this.form2.invalidTime,
      visitPurpose:this.form1.purpose,
      phone:this.form2.contact,
      unawaresName:this.form1.recepter,
      //ws info
      idNumber:this.data.guestLog.idNumber,
      // idImage :this.data.idImage,
      guestLogId:this.data.guestLog.guestLogId,
      name:this.data.guestLog.name,
      guestId:this.data.guest?this.data.guest.guestId:'',
      guestCode:this.data.guest?this.data.guest.guestCode:'',
      floorId:this.data.floorId,
      deviceId:this.data.deviceId,
      deviceGroupId:this.data.deviceGroupId,
      updateBy:user.userId||''
    });
  }
  handleClose(){
    this.$emit('close')
  }
  libraryCheck(v){
    let chekced_libId = v.id;
    this.form2.library=chekced_libId;
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.visitor-alarm-content{
  display: flex;
  justify-content:space-between;
  width: 100%;
  padding-top: 24px;
  &>div{
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    .visitor-alarm-img{
      width: 144px;
      height: 192px;
    }
    .visitor-alarm-text{
      padding-left: 16px;
      position: relative;
      padding-right: 10px;
      width: 200px;
      .visitor-alarm-formtext{
        max-width:200px;
        word-wrap:break-word;
        // overflow: hidden;
        // text-overflow:ellipsis;
        // white-space: nowrap;
      }
      .el-form-item{
        margin-bottom: 0;

        .el-form-item__label,.el-form-item__content{
          line-height: 22px;
        }
      }
      .icon-renzhengbufu{
        position: absolute;
        right: 10px;
      }
    }
    .visitor-alarm-form{
      max-width: 297px;
    }
  }
}
</style>
