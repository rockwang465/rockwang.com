<template>
  <el-dialog :visible="dialogVisible" class="doalogbox" @close="closeDialog" width="65%">
    <div slot="title">
      <span>{{$t('heatMap.contLiveTitle')}}</span>&nbsp;&nbsp;&nbsp;
      <span> {{currentDateTime ? currentDateTime : ''}} </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
    <div class="hotMap-nav">
      <el-select
        v-model="taskValue"
        :placeholder="$tc('liveservice.contPleaseSelect')"
        @clear="taskClear"
        @change="taskValueChange"
      >
        <el-option
          v-for="itemTask in taskList"
          :key="itemTask.taskId"
          :label="itemTask.taskName"
          :value="itemTask.taskId"
        ></el-option>
      </el-select>
      <el-checkbox
        style="margin-left:20px"
        v-model="isLine"
        :disabled="!taskValue"
        @change="warningLineChange"
      >
        <span>
          <i class="iconfont icon-gaojing_xiantiao"></i>
          <span>{{$t('heatMap.zoneCheck')}}</span>
        </span>
      </el-checkbox>
      <span style="margin-left:50px">{{$t('heatMap.zoneCrowdRealTime')}}:{{hotspotQuantity ?  hotspotQuantity : '0'}}</span>
    </div>
    <div class="hotMap-body">
      <div style="position: relative;">
        <mediaplayer ref="mediaplayer" :url="data.videoPath" @loadedmetadata="loadedmetadata" />
        <canvas
          id="canvas"
          :height="cHeight"
          :width="cWidth"
          style="position: absolute;top:0px;left:0px ;"
        ></canvas>
        <!-- <el-button v-if="videoHeight" @click="()=>{this.$refs.mediaplayer.fullScreen()}"><i class="iconfont icon-fullscreen"></i>放大画面</el-button> -->
      </div>
      <div :style="{'background':'#011c50','height':videoHeight}">
        <div class style="background:#011c50;width: 100%;">
          <!-- {{id}} -->
          <detailHotMap :hotMapList="socketHotMap[0].hotspotHeadPosition" />
        </div>
      </div>
    </div>
    <!-- <div >{{data.deviceName}}</div>&nbsp;&nbsp;&nbsp; -->
      <div class="cameras-items-titlebox" >
        <div style="text-overflow: ellipsis;overflow: hidden;white-space: nowrap;">
          <span class="mediaplayer-green-point"></span>
          {{data.deviceName}}
        </div>
        <el-button
          type="primary"
          v-if="videoHeight"
          @click="()=>{this.$refs.mediaplayer.fullScreen()}"
          icon="iconfont icon-fullscreen"
          style="background-color:rgba(25, 137, 250, 1);margin-left: 30px;">{{$tc('liveservice.contEnlargeScreen')}}</el-button>
      </div>
  </el-dialog>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit, Prop } from "vue-property-decorator";
import { Stomp } from "stompjs/lib/stomp.min.js";
import SockJS from "sockjs-client";
const tdwsHost = window.globalConfig.tdwsHost;
import { Cache } from "@/utils/cache";
import detailHotMap from "@/components/detailHotMap/index.vue";
import monitorFetchs from "@/api/monitor";
import mediaplayer from "@/components/media-player/index.vue";

@Component({
  components: {
    detailHotMap,
    mediaplayer
  }
})
export default class mediaHeatMap extends Vue {
  @Prop({ default: "" }) id!: string;
  @Prop({ default: false }) dialogVisible!: boolean;
  @Prop({ default: {} }) data!: object;
  @Prop({ default: "" }) deviceId!: string;
  sessionIdLive: any;
  socketLive: any;
  socketClientLive: any;
  socketHotMap: any = [{ hotspotHeadPosition: [] }];
  hotspotQuantity: any = "";
  setIntervalLoopId: any;
  currentDateTime: any = '';
  videoHeight: any = "";
  isLine: boolean = false;
  cHeight: any = "1";
  cWidth: any = "1";
  taskList: any = [];
  taskValue: any = "";
  //  dialogVisible = false;

 async mounted() {
    await this.getDisplayWarnLimit();
  // console.log('---------------------' , 222222222);
    this.connectLive();
    this.getserverTime();
    // console.log(222222222222);
}

  @Emit("slot")
  slot() {
    return this.socketHotMap[0];
  }

  //获取当前设备任务
  getDisplayWarnLimit() {
    return monitorFetchs.getDisplayWarnLimit(this.deviceId).then((res: any) => {
        this.taskList = res.displayWarnLimitVoList.filter(
          item => item.taskType == 5
        );
        this.taskValue =  this.taskList[0].taskId
        // console.log('----------------------------------', this.taskValue);
        // this.connectLive()
    });
  }

  getserverTime() {
    let requestStartTime = new Date().getTime();
    monitorFetchs.getServerTime().then((res: any) => {
      let nowTime = new Date().getTime();
      let diffTime =
        (nowTime - requestStartTime) / 2 + (nowTime - res.millisecond);
      this.setIntervalLoopId = setInterval(() => {
        this.getNowTime(diffTime);
      }, 300);
    });
  }

  getNowTime(difftime) {
    let dt = new Date(new Date().getTime() - difftime),
      CurrentYear = dt.getFullYear(),
      CurrentMonth = dt.getMonth() + 1,
      CurrentDay = dt.getDate(),
      CurrentHour = dt.getHours(),
      CurrentMinter = dt.getMinutes(),
      CurrentSeconds = dt.getSeconds(),
      dataArray: any = [
        CurrentYear,
        CurrentMonth,
        CurrentDay,
        CurrentHour,
        CurrentMinter,
        CurrentSeconds
      ];
    for (let i = 0; i < dataArray.length; i++) {
      if (dataArray[i] <= 9) {
        dataArray[i] = "0" + dataArray[i];
      }
    }
    this.currentDateTime = `${dataArray[0]}/${dataArray[1]}/${dataArray[2]} ${dataArray[3]}:${dataArray[4]}:${dataArray[5]}`;
  }

  @Emit("close")
  closeDialog() {
    window.clearInterval(this.setIntervalLoopId);
    this.setIntervalLoopId = null;
    // this.$props.dialogVisible = false
    return false;
  }

  taskClear() {
    // console.log(this.taskValue)
    // this.isLine = false
    this.clearCanvas();
  }
  taskValueChange(v) {
    // console.log(v);
    this.hotspotQuantity = 0
    this.socketHotMap = [{ hotspotHeadPosition: [] }]
    this.clearCanvas()
    this.sendLive(v);
  }

  loadedmetadata(e) {
    // console.log(e);
    this.videoHeight = e.target.clientHeight + "px";
    this.cHeight = e.target.clientHeight;
    this.cWidth = e.target.clientWidth;
  }

  //点击显示cavas
  warningLineChange() {
    let that = this as any;
    let deviceId = this.deviceId;
    // (this.$refs.mediaplayer as any).fullScreen()
    if (!this.isLine) {
      this.clearCanvas();
      return;
    }

    this.taskList.forEach(item => {
      if (this.taskValue && item.taskId && this.taskValue == item.taskId)
        this.getCanvas(item);
    });
  }

  //清除canvas
  clearCanvas() {
    this.isLine = false;
    // if(this.splitScreenModelValue==4) return;
    const canvas = document.getElementById("canvas") as any;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  //绘制canvas
  getCanvas(item) {
    const canvas = document.getElementById("canvas") as any;
    const ctx = canvas.getContext("2d");
    this.$nextTick(() => {
      item.pointVoList.forEach(val => {
        if (val && val.length == 2) {
          ctx.beginPath();
          val.forEach(e => {
            ctx.lineTo(e.x * canvas.width, e.y * canvas.height);
          });
          ctx.strokeStyle = "RGB(255,0, 0)";
          ctx.setLineDash([]); // 画实线
          ctx.stroke();
          ctx.closePath();
        }
        if (val && val.length > 2) {
          ctx.beginPath();
          val.forEach((e, index) => {
            ctx.lineTo(e.x * canvas.width, e.y * canvas.height);
            if (index == val.length - 1) {
              //最后一个回到初始点位
              ctx.lineTo(val[0].x * canvas.width, val[0].y * canvas.height);
            }
          });
          ctx.strokeStyle = "RGB(255, 0, 0)"; //填充颜色
          ctx.setLineDash([2, 2]); //画虚线
          ctx.fillStyle = "RGBA(255, 0, 0, .5)"; //线颜色
          ctx.fill();
          ctx.stroke();
          ctx.closePath();
        }
      });
    });
  }

  // connectStruc(){//结构化推送
  //   this.sessionIdStruct = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
  //   this.socketStruct = new SockJS(`${tdwsHost}/senseguard-struct-process-service/websocket`,[], {
  //     sessionId: ()=>{
  //     return this.sessionIdStruct;
  //     }
  //   });
  //   this.socketClientStruct = Stomp.over(this.socketStruct);
  //   this.socketClientStruct.debug = null;
  //   const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
  //   const userId = userInfo.userId;
  //   this.socketClientStruct.connect(
  //     {"userId":userInfo.userId},
  //     (frame)=> {
  //       this.socketClientStruct.subscribe(`/topic/${this.sessionIdStruct}`,  (res) =>{
  //         res = JSON.parse(res.body) ;
  //         // console.log(res);

  //         // this.unshiftAlarm(res)
  //         if(this.socketHotMap.length >=2) {
  //           // this.socketHotMap.
  //           this.socketHotMap.pop()
  //         }
  //         this.socketHotMap.unshift(res);
  //         // console.log(this.socketHotMap);
  //         this.slot()

  //       });
  //       const requestBodyStruct =JSON.stringify({
  //           sessionId:this.sessionIdStruct,
  //           deviceIds:[this.id],
  //           taskTypes:[23,24],
  //           userId
  //       });
  //       this.socketClientStruct.send(`/app/filter_condition_struct`,{},requestBodyStruct);
  //     },(error)=> {}
  //   );
  // }

  connectLive() {
    //live推送
    this.sessionIdLive = Math.random()
      .toString(36)
      .replace(/[^a-z]+/g, "")
      .substr(0, 7);
    this.socketLive = new SockJS(
      `${tdwsHost}/senseguard-struct-process-service/live`,
      [],
      {
        sessionId: () => {
          return this.sessionIdLive;
        }
      }
    );
    this.socketClientLive = Stomp.over(this.socketLive);
    this.socketClientLive.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    this.socketClientLive.connect(
      { userId: userInfo.userId },
      frame => {
        this.socketClientLive.subscribe(`/live/${this.sessionIdLive}`, res => {
          res = JSON.parse(res.body);
          // console.log(res);
          this.hotspotQuantity = res.hotspotQuantity;
          if(this.socketHotMap.length >=2) {
            this.socketHotMap.pop()
          }
          this.socketHotMap.unshift(res);
        });
        this.sendLive(this.taskValue);

        // this.sendLive('')
      },
      error => {}
    );
  }

  sendLive(ids?) {
    // this.canAlert = true;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    let data: any = {};
    data.userId = userId;
    data.sessionId = this.sessionIdLive;
    data.deviceIds = [this.deviceId];
    // data.taskIds = d ;
    ids ? (data.taskIds = [ids]) : null;
    // this.sendLiveDeviceIds ? data.deviceIds = this.sendLiveDeviceIds : null ;
    // console.log(data.deviceIds);

    const requestBody = JSON.stringify(data);
    // console.log(requestBody);

    this.socketClientLive.send(
      `/app/filter_condition_struct_live`,
      {},
      requestBody
    );
  }

  beforeDestroy() {
    this.socketLive.close();
    window.clearInterval(this.setIntervalLoopId);
    this.setIntervalLoopId = null;
  }
}
</script>

<style lang="scss" scoped>
.doalogbox .el-dialog {
  width: 66%;
  min-height: 350px;
}
.doalogbox .el-dialog .el-dialog__body {

  .hotMap-body {
    display: flex;
    // flex-direction: inherit;
    align-items: center;
    background: #000;
    margin: 16px 24px;
    padding: 0;
    // width: calc(100% - 24px * 2);
    width: 100%;
    height: 450px;
    > div {
      width: 50% !important;
    }

    .el-button {
      position: absolute;
      bottom: 5px;
      right: 5px;
    }
  }

  .cameras-items-titlebox{
    padding:16px 0;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    // flex-direction:row ;
    justify-content:flex-start;
    width: 100%;
    color: #000;
    font-size: 16px;
    font-weight: 700;
    min-height: 64px;
    .mediaplayer-green-point{
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: #50cb04;
    }
  }
}

.hotMap-body {
  display: flex;
  // height: 100%;
  margin-bottom: 25px;
  > div {
    width: 50%;
  }
}

.hotMap-nav {
  width: 100%;
  display: flex;
  align-items: baseline;
}
</style>
