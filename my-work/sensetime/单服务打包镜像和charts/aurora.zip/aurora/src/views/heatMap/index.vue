<template>
  <div style="width: 100%; height:100%">
    <div v-if="!isShowHap" class="noTaskShow">
      <div>
        <img src="/images/task-nodata.png" alt="">
        <p>
          {{$t('heatMap.hint1')}}
          <span @click="()=>{this.$router.push({ path:'/manage/task'})}">{{$t('appCenter.task')}}</span>
          {{$t('heatMap.hint2')}}
        </p>
      </div>
      <!-- <h1 @click="()=>{this.$router.push({ path:'/manage/task'})}">无数据</h1> -->
    </div>
    <div class="HotMap" style="width: 100%; height:100%" v-if="isShowHap">
      <div class="hotMap-sou">
        <el-dropdown trigger="click" placement="bottom-start" ref="messageDrop" @visible-change='visibleChange'>
          <el-input suffix-icon='el-icon-arrow-down' :class="{conditionBoxVisible}" :value="inputText" :placeholder="$t('rule.contPleaseSelect')"></el-input>
          <el-dropdown-menu slot="dropdown">
            <el-tree
            node-key="id"
            ref="tree"
            :data="infoFloors"
            :props="defaultProps"
            :highlight-current='true'
            @node-click='getNodeKey'
            class="hotTree"
            ></el-tree>
          </el-dropdown-menu>
        </el-dropdown>
          <el-select v-model="deviceNameMapSet" @change="deviceNameMapSetChange" filterable :placeholder="$t('devicemanagement.validateDeviceName')">
          <el-option
            v-for="item in deviceList"
            :key="item.deviceId"
            :label="item.deviceName"
            :value="item.position"
            >
            <!-- {{item}} -->
          </el-option>
    </el-select>
      </div>

      <div class="hotMap-now">
        <div class="hotMap-now1">
          <p>{{totalAll.totalCurrentMap}} <i class="iconfont icon-shijingku-renshu"></i></p>
          <p>{{$t('heatMap.zoneCrowdNow')}}</p>
          <p style="font-weight: 700;">{{totalAll.totalAllMap}}</p>
          <p style="line-height:14px">{{$t('heatMap.zoneCrowdMap')}}</p>
        </div>
        <div class="hotMap-now2">
          <p>{{totalAll.alarmNumber}} <i class="iconfont icon-gaojingzhongxin"></i></p>
          <p>{{$t('heatMap.zoneCrowdToday')}}</p>
          <p v-if="this.$permission('012307')" style="color:#2A5AF5;cursor: pointer;" @click="goRetrivalCrowdRecord">{{$t('heatMap.warningMore')}} > </p>
        </div>
        <div class="hotMap-now3">
          <p>{{totalAll.deviceNumber}} <i class="iconfont icon-shexiang"></i></p>
          <p>{{$t('heatMap.accessDevices')}}</p>
        </div>
      </div>

      <div class="color-ratio">

        <div>
          <span>{{$t('records.contThreshold')}}</span>
          <div class="color-title"></div>
        </div>
        <div class="ratio-title">
          <span>0</span>
          <span>40%</span>
          <span>60%</span>
          <span>80%</span>
          <span>100%</span>
        </div>
      </div>

      <l-map ref="elMap" style="width: 100%; height: 100%;"
        :min-zoom="mapSet.minZoom"
        :max-zoom="mapSet.maxZoom"
        :zoom="mapSet.zoom"
        :center="mapSet.center"
        :options="mapOptions"
        :crs='crs'>
        <l-image-overlay :url="mapSet.url" className="mapStyle" style="width:100% ; height:100%"  :bounds="mapSet.bounds"></l-image-overlay>
        <l-marker
        v-for="item in deviceList"
        :key="item.deviceId"
        :lat-lng="item.position"
        :icon="icon">
          <l-popup >
            <div>{{$t('heatMap.zoneCrowd')}}: {{item.crowdNumber}}</div>
            <div>{{$t('heatMap.tableDevice')}}: {{item.deviceName}} </div>
            <div :ref="'shebei'+item.deviceName" style="color:#2A5AF5;cursor: pointer;margin-top:5px;" @click="setTitleMap(item)">{{$t('heatMap.setLive')}} </div>
          </l-popup>
        </l-marker>

      </l-map>

      <!-- <el-dialog
      :visible.sync="dialogVisible" v-if="dialogVisible"
      class="doalogbox"
      @close='closeDialog'>
      <div slot='title'>
        <span>设备实况画面 </span>&nbsp;&nbsp;&nbsp;
        <span> {{currentDateTime}} </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <span> 热区实时人数:{{hotspotQuantity}}</span>
      </div>
        <mediaplayer
        ref="mediaplayer"
        :url='rtspVideo'
        @loadedmetadata='loadedmetadata' />
        <div :style="{'background':'#011c50','height':videoHeight}">
          <mediaHeatMap
          :id='videoID'
          @slot='slot' />
        </div>
      </el-dialog> -->

      <mediaHeatMap
        v-if="dialogVisible"
          :dialogVisible="dialogVisible"
          :deviceId='deviceId'
          :data='propData'
          @close='closeDialog'/>

    </div>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import api from '@/api/crowdHotMap'
import mediaplayer from '@/components/media-player/index.vue';
import mediaHeatMap from './media-heatMap/index.vue'
import L from "leaflet";
var _ = require('lodash/lang');
import monitorFetchs from '@/api/monitor';
import { Stomp } from "stompjs/lib/stomp.min.js";
import SockJS from "sockjs-client";
const tdwsHost = window.globalConfig.tdwsHost;
import {Cache} from '@/utils/cache';
// delete (L.Icon.Default.prototype as any)._getIconUrl;
// L.Icon.Default.mergeOptions({
//   iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
//   iconUrl: require('leaflet/dist/images/marker-icon.png'),
//   shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
// });

//热区
import 'leaflet.heat'

// import api from '@/api/map';
// import api_device from '@/api/device';
// import { MapModule } from '@/store/modules/map';
import '@/assets/js/plugins/L.Control.Zoomslider.js';

var heatLayer = L.heatLayer([],{
  radius: 35,
  blur:30,
  minOpacity :0.5,
  max: 1.0,
  // maxZoom :10,
  // radius: 10,
  // maxZoom: .5,
  // minOpacity: 0,
  // blur: .75,
  // gradient: {0: 'green', 0.3: 'lime', 0.5: 'red'},
  // gradient: {0: "#0ff",0.3: 'lime',0.4: "#0f0",0.7: 'lime',0.8: "#ff0",0.9: 'lime',1: "#f00"}
  gradient: {
    "0.95": "rgba(255,0,0,1)",
    "0.62": "rgba(251,255,0,1)",
    "0.43": "rgba(94,255,6,1)",
    "0.26": "rgba(0,0,182,1)",
    "0": "rgba(18,22,245,1)"
  },
});

import {
  LMap,
  LTileLayer,
  LImageOverlay,
  LMarker,
  LPopup,
  LPolyline,
  LGeoJson,
  LControl,
  LControlLayers,
  LControlScale,
  LControlZoom,
  LLayerGroup
} from "vue2-leaflet";
import log from "../../api/log";

@Component({
  components: {
    LMap,
    LTileLayer,
    LMarker,
    LPopup,
    LImageOverlay,
    mediaplayer,
    mediaHeatMap
  }
})
export default class HotMap extends Vue {
  map='';
  crs= L.CRS.Simple;
  deviceList:any   = [];
  deviceLi:any   = [];
  deviceListId:any=[];
  heatLayer:any = null;
  heatmapSet:any=[]
  heatmapLayer:any = null
  icon = L.icon({
    iconUrl: '/images/camera.png',
    iconSize: [35, 35],
    iconAnchor: [19, 24],
    popupAnchor: [-2, -28]
  })
  dialogVisible =false
  rtspVideo = ''
  infoFloors :any =[];
  inputText ='';
  totalAll :any ={
    alarmNumber: 0,
    deviceNumber: 0,
    totalAllMap: 0,
    totalCurrentMap: 0,
  };
  loading = false;
  floorId = ''
  setIntervalId:any;
  deviceId =''
  currentDateTime =''
  setIntervalLoopId :any;
  hotspotQuantity:any = 0;
  deviceNameMapSet = '';
  conditionBoxVisible = false;
  videoHeight='';
  isShowHap = true;

  //ws
  sessionIdLive:any;
  socketLive:any;
  socketClientLive:any;
  propData:any;

  // @Watch('deviceNameMapSet')
  deviceNameMapSetChange(value) {
    this.mapSet.center = value
    // this.setTitleMap(value)
    // this.deviceNameMapSet = value.deviceName
    // console.log(value ,this.mapSet.center);
  }

  get defaultProps(){
      return {
        children: 'children',
        label: 'name',
        id:'floorId',
      }
  }

//时间
  getserverTime(){
    let requestStartTime = new Date().getTime();
    monitorFetchs.getServerTime().then((res:any)=>{
      let nowTime = new Date().getTime();
      let diffTime = (nowTime - requestStartTime)/2 + (nowTime - res.millisecond);
      this.setIntervalLoopId = setInterval(()=>{
        this.getNowTime(diffTime)
      },300);
    })
  }
  getNowTime(difftime){
    let dt = new Date(new Date().getTime() - difftime),
    CurrentYear = dt.getFullYear(),
    CurrentMonth =  dt.getMonth() + 1,
    CurrentDay = dt.getDate(),
    CurrentHour = dt.getHours(),
    CurrentMinter = dt.getMinutes(),
    CurrentSeconds = dt.getSeconds(),
    dataArray:any = [CurrentYear, CurrentMonth, CurrentDay, CurrentHour, CurrentMinter, CurrentSeconds];
    for (let i = 0; i<dataArray.length; i++){
      if (dataArray[i] <= 9){dataArray[i] = "0" + dataArray[i]}
    }
    this.currentDateTime = `${dataArray[0]}/${dataArray[1]}/${dataArray[2]} ${dataArray[3]}:${dataArray[4]}:${dataArray[5]}`;
  }

  closeDialog(res:boolean) {
    // window.clearInterval(this.setIntervalLoopId);
    // this.setIntervalLoopId = null;
    this.dialogVisible = false
  }

  // slot(data) {
  //   console.log(data);
  //   this.hotspotQuantity = data.hotspotQuantity
  // }

  setTitleMap(item){
    this.dialogVisible = true
    this.rtspVideo = item.videoPath
    this.deviceId =item.deviceId
    this.propData = item
    this.getserverTime()
  }


  //点击切换地图
  getNodeKey(data,datas) {

    if(!data.group) {
      // console.log(data);
      // let name = ''
      // datas.parent.forEach(item => {
      //    name = item
      // });
      // console.log(data);
      this.inputText = data.name
      ;(this.$refs.messageDrop as any).hide();
      this.mapSet.url = data.url
      this.floorId = data.floorId
      clearInterval(this.setIntervalId);
      this.deviceNameMapSet = ''
      this.deviceList = []
      this.mapSet.center = [540,960];
      this.getCrowdHeatMapInfo()
    }
  }

  //地图选择框显示隐藏
  visibleChange(e:boolean) {
    // console.log(e);
    this.conditionBoxVisible = e
  }

  mapSet = {
    url: "/images/floor03.png1"+'?timestamp='+ +new Date(),
    //  url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png',
    marker: [540,960],  // [y,x]
    // text: "this is a marker",
    bounds  : [[0,0], [1080, 1920]],
    minZoom : -2,
    maxZoom : 2,
    center  : [540,960],
    zoom    : -.2,
    // bgUrl   : '/images/floor00.png',
    // mapSetUrl : '/mock/floor0.json',
    reset   : true
  };
  mapOptions= {
    attributionControl: false,
    zoomSnap: false,
    drawControl: false,
    zoomControl: false,
    zoomsliderControl: true,
  };
  // $refs !:{
  //   devicePanel:HTMLFormElement,
  //   elMap:any
  // }



  async mounted() {
      // this.loadHeatMap()
      // (this.map as any).zoomControl.setPosition('bottomright');
      await this.getHotMap();
      if(this.isShowHap){
        this.map = (this.$refs.elMap as any).mapObject;
        (this.map as any).addLayer(heatLayer);
      }
      // this.connectLive();
  }

  goRetrivalCrowdRecord() {
    this.$router.push({ path:'/retrival/crowdRecord'});
  }

  getHotMap() {
    // let _this = this as any;
    this.loading = true
    return  api.getHotMap().then((res:any)=>{
      // console.log(res);
      // this.mapSet.url = res.infoFloors[0].url
      // this.inputText = res.infoFloors[0].name
      let obj = _.cloneDeep(res.infoFloors)
      // let obj = null
      if(!obj || obj.length == 0)  return this.isShowHap = false ;
      let ons = getFirstData(res.infoFloors[0])
      this.mapSet.url = ons.url
      this.inputText = ons.name
      this.infoFloors = obj
      this.floorId =this.floorId?this.floorId : ons.floorId
      this.getCrowdHeatMapInfo()

      function getFirstData(obj) {
        // console.log(obj);
        let newArr = []
        if(!obj.group) {
          return obj
        }
        return obj.children.map((item,index)=>{
          return  index == 0 ? getFirstData(item) :''
        })[0]
      }

    })
  }

  getCrowdHeatMapInfo() {
    this.loading = true
    api.getCrowdHeatMapInfo(this.floorId).then((res:any)=>{
      // console.log(res);
      this.deviceList = res.deviceVos.map(item=>{
        return {
            id:item.ID,
            deviceId:item.deviceId,
            deviceName:item.deviceName,
            crowdNumber:item.crowdNumber,
            // name : this.$tc('map.deviceName')+item.deviceName+"<br>"+this.$tc('map.deviceId')+item.deviceId,
            // isShow:false,
            // icon:this.deviceIcon,
            videoPath:item.rtspAddress,
            position :[
              item.point[1],
              item.point[0],
            ]
         }
      })
    // console.log(this.deviceList);
      this.loadHeatMap(res.deviceVos)
      clearInterval(this.setIntervalId)
      this.setIntervalId = setInterval(()=>{
        this.getCrowdHeatMapInfo()
      },30000)
    }).finally(()=>{

      this.loading = false
    })

    api.getStatistics(this.floorId).then(res=>{
      this.totalAll = {...res}
      // console.log( '----------------',this.totalAll ,{...res});
    }).finally(()=>{
      this.loading = false
    })
  }

  loadHeatMap(deviceVos){
    let _this = this;


    this.deviceLi = JSON.parse(JSON.stringify(_this.deviceList));
    // console.log(deviceVos[0].point)

      //模拟数据
      // let deviceInfo = [
      //   {"deviceId":331,"deviceName":"深圳模拟视频","hotRate":.2,"type":1,"point":[837, 489.88]},
      //   {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":.4,"type":1,"point":[650,610]},
      //   {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":.6,"type":1,"point":[888, 848.38]},
      //   // {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":4,"type":1,"point":[832, 596]},
      //   {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":.8,"type":1,"point":[1424, 844]},
      //   {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":.9,"type":1,"point":[300, 844]},
      //   // {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":50,"type":1,"point":[870,610]},
      //   // {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":10,"type":1,"point":[690,610]},
      //   // {"deviceId":340,"deviceName":"深圳模拟视频","hotRate":10,"type":1,"point":[610,600]},
      // ]
      let deviceInfo =JSON.parse(JSON.stringify(deviceVos)) ;
      this.heatmapSet = [];
      if(deviceInfo){
        for(let i=0;i<deviceInfo.length;i++){
          let newPoint = deviceInfo[i].point;
          [newPoint[0],newPoint[1]] = [newPoint[1],newPoint[0]]
          let nowNum:any = (deviceInfo[i].hotRate*5);
          newPoint.push(nowNum);
          if(deviceInfo[i].hotRate > .8){
            for(let n=0;n<deviceInfo[i].hotRate*15;n++){
              this.heatmapSet.push(newPoint)
            }
          } else if (deviceInfo[i].hotRate > .6){
            for(let n=0;n<deviceInfo[i].hotRate*10;n++){
              this.heatmapSet.push(newPoint)
            }
          } else if (deviceInfo[i].hotRate > .4){
            for(let n=0;n<deviceInfo[i].hotRate*6;n++){
              this.heatmapSet.push(newPoint)
            }
          } else if(deviceInfo[i].hotRate > .2){
            for(let n=0;n<deviceInfo[i].hotRate*3;n++){
              this.heatmapSet.push(newPoint)
            }

          } else {
              this.heatmapSet.push(newPoint)
          }
            // console.log(newPoint);

          // console.log(this.heatmapSet);

          // _this.deviceLi.map((item,index)=>{
          //   if(item.deviceId == deviceInfo[i].deviceId){
          //     item.heatCount = deviceInfo[i].hotRate*1000;
          //     Vue.set(_this.deviceLi,index,item);
          //   }
          // })
        }
        // console.log(this.deviceLi);

          // this.heatmapLayer.setmapSet(this.heatmapSet);
      }
    heatLayer.setLatLngs(this.heatmapSet);
    // console.log(this.heatmapSet);

  }

  //获取视屏属性
  loadedmetadata(e) {
    // console.log(e);
    this.videoHeight =e.target.clientHeight +'px';
  }

  beforeDestroy() {
   clearInterval(this.setIntervalId);
   this.setIntervalId = null;
  }


   connectLive(){//live推送
    this.sessionIdLive = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socketLive = new SockJS(`${tdwsHost}/senseguard-struct-process-service/live`,[], {
      sessionId: ()=>{
       return this.sessionIdLive;
      }
    });
    this.socketClientLive = Stomp.over(this.socketLive);
    this.socketClientLive.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    this.socketClientLive.connect(
      {"userId":userInfo.userId},
      (frame)=> {
        this.socketClientLive.subscribe(`/live/${this.sessionIdLive}`,  (res) =>{
          res = JSON.parse(res.body) ;
          // console.log(res);
          // EventBus.$emit('getAlarm',res)
        });
      },(error)=> {}
    );
  }

  sendLive(ids?) {
    // this.canAlert = true;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    let data:any = {} ;
    data.userId = userId;
    data.sessionId = this.sessionIdLive;
    // data.taskIds = d ;
    ids ? data.taskIds = [ids] : null;
    // this.sendLiveDeviceIds ? data.deviceIds = this.sendLiveDeviceIds : null ;
    // console.log(data.deviceIds);

    const requestBody = JSON.stringify(data);
    // console.log(requestBody);

    this.socketClientLive.send(`/app/filter_condition_struct_live`,{},requestBody);
  }
}


</script>

<style lang="scss">
@import "@/styles/variables.scss";
@import "src/assets/style/leaflet.scss";
.leaflet-image-layer {
    background: rgba(250, 250, 250, 0.2);
    border: 1px dashed #ddd;
}

.noTaskShow {
  display: flex;
  width: 100%;
  height: 100%;
  justify-content: center;
  align-items: center;
  >div {
    text-align: center;
    >p {
      font-size:20px ;
      // line-height: 50px;
      margin-top: 35px;
      >span {
        // margin: 0 5px;
        border-bottom: 1px solid #409eff;
        cursor: pointer;
        color: #409eff;
      }
    }
  }
}

.HotMap {
  background: #fff;
  position: relative;

  .hotMap-sou {
    position: absolute;
    z-index: 1000;
    top: 20px;
    left: 20px;
    >div {
      margin-right: 10px;
    }
  }
  .hotMap-now {
    position: absolute;
    z-index: 1000;
    top: 20px;
    right: 20px;
    width: 168px;
    >div {
      background: #fafafa;
      padding:10px ;
      p {
        &:nth-child(1) {
          font-size: 20px;
          font-weight: 700;
        }
        line-height: 24px;
        font-size:12px;
      }
      i {
        float: right;
        font-size: 16px;
        margin-right: 4px;
      }
    }
    .hotMap-now1{
      border-top: 2px solid #28354d;
      border-radius: 4px 4px 0 0;
      p {

        &:nth-child(2){
          position: relative;
          &::after  {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            border-bottom: 2px solid;
            width: 10px;
          }
        }
      }
    }
    .hotMap-now2 {
      border-top: 1px solid #28354d;

    }
    .hotMap-now3 {
      margin-top: 5px;
      border-top: 2px solid #28354d;
      border-radius: 4px;
      i {
        // float: right;
        font-size: 14px;
        margin-right: 0;
      }
    }
  }

  .color-ratio {
    position: absolute;
    z-index: 1000;
    bottom: 20px;
    right: 100px;
    width:691px;
    height:53px;
    background:rgba(255,255,255,1);
    box-shadow:0px 3px 6px rgba(0,0,0,0.16);
    opacity:0.7;
    border-radius:4px;
    padding-top: 10px;
    font-size:14px;
    >div {
      display: flex;
      height: 18px;
      align-items: center;
      justify-content:center;
      >span {
        margin-right: 10px;
        font-family:Source Han Sans CN;
        font-weight:700;
      }
      .color-title {
        display: table-cell;
        width:600px;
        height:8px;
        background:linear-gradient(90deg,rgba(18,22,245,1) 0%,rgba(0,122,182,1) 26%,rgba(94,255,6,1) 43%,rgba(251,255,0,1) 62%,rgba(255,0,0,1) 100%);
        box-shadow:0px 3px 6px rgba(0,0,0,0.16);
        opacity:1;
        border-radius:10px;
        // float: right;
      }

    }

    .ratio-title {
      margin-left: 65px;
      >span {
        display: inline-block;
        width: 20%;
        font-weight: 400;
      }
    }
  }

  .leaflet-pane .leaflet-marker-pane {
    // img {
    //   margin-left: -19px !important;
    //   margin-top: -24px !important;
    //   width: 35px !important;
    //   height: 35px !important;
    // }
  }

  // .doalogbox .el-dialog {
  //   width: 66%;
  //   min-height: 350px;
  // }
  // .doalogbox .el-dialog .el-dialog__body {
  //   display: flex;
  //   flex-direction: inherit;
  //   background: #000;
  //   margin: 16px 24px;
  //   padding: 0;
  //   width: calc(100% - 24px * 2 );
  //   height: 450px;
  //   >div  {
  //     width: 50% !important;
  //   }
  // }

  .mediaplayer {

  }

  .el-dropdown {
    .el-input i {
        transform: rotate(0deg);
        transition: all .3s ;
    }

    .conditionBoxVisible i {
      transform: rotate(-180deg);
    }
  }
}

.el-popper .hotTree {
  // padding: 0px;
  min-width: 215px;
}
</style>
