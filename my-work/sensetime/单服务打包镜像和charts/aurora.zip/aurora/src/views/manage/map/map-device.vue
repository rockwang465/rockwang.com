<template>
  <div class="device-wrapper">
    <div class="map_device_edit_tip" v-if="handleType ==='edit'">
      <el-alert
        :title="$t('map.coordEditTips')"
        show-icon
        :closable="false"
        type="success">
      </el-alert>
    </div>

    <div class="side-tree device-select" v-if="handleType != 'view'">
      <el-form :inline="true" @submit.native.prevent>
        <el-input
        size="small"
        class="search-input"
        :placeholder="$t('map.textboxEnterMapName')"
        :clearable="true"
        suffix-icon="el-icon-search"
        v-model="filterText"/>
      </el-form>
      <el-tree
        ref="sideTree"
        class="filter-tree"
        node-key="id"
       :data="treeData"
       :current-node-key="currentNodeKey"
       :props="defaultProps"
       :filter-node-method="filterNode"
       @node-click="clickVal"></el-tree>
    </div>
    <div class="device-view">
      <l-map ref="deviceView"
        :min-zoom="mapSet.minZoom"
        :max-zoom="mapSet.maxZoom"
        :zoom="mapSet.zoom"
        :center="mapSet.center"
        :key="mapSet.key"
        :options="mapOptions"
        :class="'map_'+handleType"
        :crs="crs"
      >
        <l-image-overlay
          :url="mapSet.bgUrl"
          :bounds="mapSet.bounds"/>

        <l-layer-group
          layer-type="overlay"
          name="Layer polyline"
        >
          <l-marker v-for="item in deviceList"
            :lat-lng.sync="item.position"
            @update:latLng="dragendPosition"
            :icon="item.icon"
            attribution="selected"
            :draggable="item.draggable"
            :key="item.id">
            <l-tooltip :options="showOption" v-if="handleType =='edit'">
              <div class="edit-tips">{{$t('map.deviceDragTips')}}</div>
            </l-tooltip>
            <l-popup>
              {{$tc('map.deviceName')}}
              {{item.deviceName}}
              <br/>
              {{$tc('map.deviceId')}}
              {{item.deviceId}}
            </l-popup>
          </l-marker>
        </l-layer-group>
        <div v-if="noMapbg" class="no-map-bg">
          <div>{{$tc('map.mapChangedTips')}}</div>
        </div>
      </l-map>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue,Watch,Prop } from 'vue-property-decorator';
import {Tree as ElTree} from 'element-ui';
import L from 'leaflet';
import { LMap, LImageOverlay, LMarker, LPopup,LPolyline,LGeoJson,LLayerGroup,LTooltip  } from 'vue2-leaflet';
import PopupContent from './geo-json-popup.vue';
//import LMovingMarker from './moving-maker.vue';
import LeftTree from '@/components/leftTree/index.vue';
import api from '@/api/map';
import api_device from '@/api/device';
import { MapModule } from '@/store/modules/map';
import {transport} from '@/utils/image';

import 'leaflet-toolbar';
import 'leaflet-draw';
import '@/assets/js/plugins/leaflet.draw-toolbar.js';
import '@/assets/js/plugins/L.Control.Zoomslider.js';

//地图基础配置
import {drawSetting,markerIcon,localDeviceList} from '@/views/manage/map/mapConfig';

@Component({
  components: {
    LMap, LImageOverlay, LMarker, LPopup,LPolyline,LLayerGroup,LTooltip,
    LGeoJson,
    LeftTree
  }
})
export default class MapDevice extends Vue {
  @Prop({ default: '' }) deviceInfo!: any;//人像所在设备点位数据
  @Prop({ default: '' }) handleType!: any;//操作类型
  @Prop({ default: '' }) isEdit!: any;//是否设备添加
  @Prop({ default: '' }) outHeight!: any;//窗口高度
  markerLatLng= [470.313220, 200.319482]
  map:any = "";
  crs     = L.CRS.Simple;
  mapOptions= {
    attributionControl: false,
    zoomSnap: true ,
    zoomControl: false,
    //drawControl: true,
    //editable:true,
    zoomsliderControl: true,
  };
  showOption = {
    permanent: true,
    interactive: false,
    direction:"right",
    opacity:"0.6"
  };
  filterText = '';
  currentNodeKey:any='';
  heightStyle:any = '';
  treeData:any = [];
  deviceList:any = [];
  defaultProps= {
    children: 'children',
    label: 'name'
  }
  fillOpacityVal=0;
  mapSet:any = {
    //key : +new Date(),
    bgUrl     : '/images/floor00.png',
    bounds  : [[0,0], [1080, 1920]],
    minZoom : -2,
    maxZoom : 1,
    center  : [540,800],
    zoom    : -1,
    dataUrl : '/mock/floor01.json'
  };
  stars:any   = [];
  noData = false;
  noMapbg = false;
  floorInfo:any = {}
  icon:any ="";
  isMapTrack=false;
  drawnItems:any=null;
  devicePlace:any=null;
  floorId ='';
  deviceIcon = markerIcon.default;
  expandedKeys:any=[]
  selected='leaflet-edit-marker-selected';
  //监听搜索框的值,检索
  @Watch('filterText')
  onFilterTextChange(val: string) {
    (this.$refs.sideTree as ElTree).filter(val);
  }

  @Watch('currentNodeKey')
  onCurrentNodeKeyChange(val: any) {
    //console.log("当前楼层id：",val)
    this.currentNodeKey = val;
    this.$nextTick(function () {
      (this.$refs.sideTree as ElTree).setCurrentKey(val);
    })
  }

  mounted(){
    let _this = this;
    this.map = (this.$refs.deviceView as any).mapObject;
    //console.log(this.deviceInfo);

    if(this.handleType == 'add'){
      console.log("添加")
      this.treeInit();
      this.drawnItems = new window.L.FeatureGroup();
      this.map.addLayer(this.drawnItems);
      let options = {
        position: "topleft",
        draw: {
          polyline: undefined,
          polygon: undefined,
          circle: undefined, // Turns off this drawing tool
          rectangle: undefined,
          circlemarker:undefined,
          marker: {
            icon: markerIcon.editing
          }
        },
        edit: {
          featureGroup: this.drawnItems, //REQUIRED!!
          //remove: true
        }
      };
      var drawControl = new window.L.Control.Draw(options as any);
      this.map.addControl(drawControl);

      this.map.on('draw:edited', function (e) {
        let layers = e.layers;

        layers.eachLayer(function (layer) {
          let deviceInfo = _this.setDeviceInfo(layer.getLatLng());
          _this.$emit("deviceVal", deviceInfo);
        });
      });
      this.map.on('draw:deleted', function (e) {
        e.layers.eachLayer(function (layer) {
          let deviceInfo = {
            coords:[],
            pathName:"",
            floorId:""
          }
          _this.$emit("deviceVal", deviceInfo);
        })
      });

      this.map.on("draw:created", function (ev,el) {
        _this.drawnItems.clearLayers();
        api.getisLeaf(_this.floorInfo).then((resp:any)=>{
          let layer = ev.layer;
          _this.drawnItems.addLayer(layer);
          let deviceInfo = _this.setDeviceInfo(layer.getLatLng());
          _this.$emit("deviceVal", deviceInfo);
        })

      });
    }else if(this.handleType =='edit'){
      this.treeInit();
      if(this.deviceInfo.length > 0){
        if(this.deviceInfo[0].deviceId){
          console.log("编辑坐标")
          this.floorInfo.id = this.deviceInfo[0].floorId;
          this.getFloorDeviceList();
          setTimeout(()=>{
            //console.log(this.deviceInfo[0])
            _this.filterText = this.deviceInfo[0].floorName
          },1500)
        }
      }
    }else{
      this.mapOptions.zoomsliderControl = false;
      //this.mapSet.center =  [this.deviceInfo[0].position.lat,this.deviceInfo[0].position.lng];
      this.mapSet.zoom = -2.4;
      this.mapSet.minZoom = -2.4;

      if(this.deviceInfo[0].url){
        this.mapSet.bgUrl = transport(this.deviceInfo[0].url);
        this.noMapbg = false;
      }else{
        this.mapSet.bgUrl = '/images/floor00.png'
        this.noMapbg = true;
      }
      //console.log(this.mapSet.bgUrl)
      this.deviceInfo[0].icon = this.deviceIcon
      this.deviceList = this.deviceInfo;
      this.deviceList.map((item,i)=>{
        //console.log(item)
        item.deviceName = item.deviceName || item.name;
        item.deviceId = item.deviceCode || item.deviceId || item.id;
      })
      //console.log(this.deviceList)
    }

  }
  setDeviceInfo(latLng) {
    latLng.lng = latLng.lng.toFixed(2);
    latLng.lat = latLng.lat.toFixed(2);
    let coords = L.GeoJSON.latLngToCoords(latLng);

    let pathName = "";
    if(this.floorInfo.parentId){
      pathName = this.floorInfo.parentId+"-"+this.floorInfo.name;
    }else{
      pathName = this.floorInfo.name;
    }

    console.log(this.floorInfo.id,pathName,coords);
    return {
      coords:coords,
      pathName:pathName,
      floorId:this.floorInfo.id
    }
  }
  dragendPosition(e){
    let coords=[Math.round((e.lng*100)/100) , Math.round((e.lat*100)/100)];
    let deviceInfo = {
      coords:coords,
      floorId:this.floorInfo.id,
      pathName:this.floorInfo.name
    }
    //console.log(e,deviceInfo)
    this.$emit("deviceVal", deviceInfo);
  }
  getFloorDeviceList(){
    this.deviceList = [];

    api_device.floorDeviceList({id:this.floorInfo.id}).then((resp)=>{
      resp.data.map((item,i)=>{
        //console.log(item,i)
        let pointStr = item.point.substring(1,item.point.length-1);
        let pointArr = pointStr.split(',');
        this.deviceIcon = markerIcon.default;
        if(item.accessState =='0'){
          this.deviceIcon = markerIcon.offLine;
        }

        //console.log(item.deviceId , this.deviceInfo[0].id)
        if(item.deviceId == this.deviceInfo[0].deviceId){
          let newJson = {
            id:item.ID,
            deviceName:item.deviceName,
            deviceId:item.deviceId,
            deviceCode:item.deviceCode || item.deviceId || item.ID,
            isShow:false,
            icon:this.deviceIcon,
            draggable:true,
            position :{
              lng:pointArr[0],
              lat:pointArr[1],
            }
          }
          this.deviceList.push(newJson)
        }
      })
    }).then(()=>{
      //console.log(this.deviceList)
    })
  }

  //根据值过滤掉不匹配的分支
  filterNode(value: string, data: any,node) {
    //console.log(value,data.name,node)
    if (!value) {
      return true;
    }
    if(value == data.name){
      (this.$refs.sideTree as ElTree).setCurrentKey(data.id);
      this.$nextTick(() => {
        this.filterText = ''
      });

      this.clickVal(data)
    }

    return data.name.indexOf(value) !== -1;
  }
  clickVal(localData: any){
    // console.log(localData)
    if(localData.id){
      this.currentNodeKey = localData.id
    }

    if(localData.children+'' == 'null'){
      //console.log(localData)
      this.floorInfo = localData;
      this.floorId = localData.floorId;
      this.mapSet = {
        bgUrl : transport(localData.url),
        bounds  : [[0,0], [1080, 1920]],
        minZoom : -1,
        maxZoom : 2,
        center  : [540,960],
        zoom    : -1,
        iconUrl : '/images/icon-camera.png',
        dataUrl : api.getMapData(localData.id)
      }
    }
    //this.getFloorDeviceList()
  }
  treeInit(){
    MapModule.TreeList().then((resp:any) => {
      if(resp.data){
        this.treeData = resp.data;
        if(this.handleType == 'add'){
          this.clickVal(this.treeData[0])
        }

        //console.log(this.deviceInfo)
        if(this.deviceInfo.length>0){
          this.treeData.map((item)=>{
            if(item.id == this.deviceInfo[0].floorId){
              this.floorInfo= item;
              this.mapSet.bgUrl = transport(item.url);
              this.mapSet.dataUrl = api.getMapData(item.id);
            }else if(item.children){
              item.children.forEach((value)=>{
                if(value.id == this.deviceInfo[0].floorId){
                  //console.log(value.id,this.deviceInfo[0].floorId)
                  this.floorInfo= value;
                  this.mapSet.bgUrl = transport(value.url);
                  this.mapSet.dataUrl = api.getMapData(value.id);
                  if(value.children){
                    item.children.forEach((value)=>{

                    })
                  }
                }
              })
            }
          })
        }else{
          if(this.treeData[0].id){
            if(this.treeData[0].children){
              this.floorInfo= this.treeData[0].children[0];
              this.mapSet.bgUrl = transport(this.treeData[0].children[0].url);
              this.mapSet.dataUrl = api.getMapData(this.treeData[0].children[0].id);
            }else{
              this.floorInfo= this.treeData[0];
              this.mapSet.bgUrl = transport(this.treeData[0].url);
              this.mapSet.dataUrl = api.getMapData(this.treeData[0].id);
            }

          }else{
            this.noData = true;
          }
        }
      }
    });
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
@import "src/assets/style/leaflet.scss";
@import "src/assets/style/leaflet.draw.scss";
.device-wrapper{
  display: flex;
  height: 100%;
  box-sizing: border-box;
  flex-wrap:wrap;
  padding:8px;
  background: #f5f7fc;
  .map_device_edit_tip{
    flex-basis: 100%;
    padding-bottom: 8px;
    .el-alert--warning.is-light{
      background-color: #fdf6ec;
      color: #e6a23c;
    }
  }
  .device-select{
    width: 240px;
    padding-right:8px;
    right: 0;
    top:0;
    box-sizing: content-box;
    height: calc(100% - 96px) !important;
    .filter-tree{
      max-height: 480px;
      overflow-y: auto;
      background: transparent;
    }
    position: relative;
    z-index: 1;
  }
  .device-view{
    position: relative;
    z-index: 0;
    width: 100%;
    min-height: 200px;
    flex:1;
    box-sizing: border-box;
    border:1px dashed #c2cad8;
  }
  .ferrari img{display: block;height: 35px;}
  .no-map-bg{
    position: absolute;width: 100%;height: 100%;
    background: rgba(255,255,255,.5);
    display: flex;
    align-items: center;
    text-align: center;
    justify-content: center;
    color: #666;
    z-index: 404;
  }
  .map_edit{
    .leaflet-marker-draggable{
      background-color: rgba(254,87,161,.1);
      border: 3px dotted rgba(254,87,161,.6);
      border-radius: 4px;
      box-sizing: content-box;
    }
    .leaflet-tooltip-right{
      margin-left: 22px;
      margin-top: -12px;
      background-color: rgba(0,0,0,.3);
      &::before{
        border-right-color: rgba(0,0,0,.3);
      }
      .edit-tips{
        padding: 8px 10px;
      }
    }
  }

}
</style>
