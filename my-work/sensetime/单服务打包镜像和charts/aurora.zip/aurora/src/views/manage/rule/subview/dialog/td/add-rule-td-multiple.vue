<template>
  <el-dialog
  :title="$t('rolemanagement.titleReminder')"
  :visible.sync="visible"
  width="30%"
  :center="true"
  :before-close="handleClose">
    <!-- title -->
    <p slot="title" style="text-align:left" >{{$t('rule.titleMultipleCreate')}}</p>
    <!-- content -->
    <div class="add-rule-td-multiple-form1" >
      <br/>
      <el-form ref="form" :model="form" :rules="rules" label-position="left">
        <br/>
        <el-form-item :label-width="labelWidth" prop="ruleGroupName" :label="$t('rule.titleRulesetName')">
          <span v-if="!!groupId" >{{groupName}}</span>
          <el-input v-else v-model="form.ruleGroupName" :disabled="!!groupId"></el-input>
        </el-form-item>
        <el-form-item :label-width="labelWidth" prop="checkedCamerasIds" :label="$t('rule.labelDevice')">
          <TreeSelect
            :defaultChechedKeys="form.checkedCamerasIds"
            @selected="selectedCamera"
            type="border"
            inputWidth="100%"
            :data="treeData"
            show-checkbox  />
        </el-form-item>
      </el-form>
    </div>
    <div class="sapce-border" ></div>
    <div class="add-rule-td-multiple-libs" >
      <header class="add-rule-td-multiple-libsheader"> <b>{{$t('rule.labelOnlistLibrary')}}:</b> </header>
      <div  class="add-rule-td-multiple-libs-scrollbox">
        <el-tree :data="libsList" ref="library" node-key="id" show-checkbox ></el-tree>
      </div>
    </div>
    <el-form ref="form2" :model="form2" label-position="left" :rules="rules2">
        <el-form-item :label-width="labelWidth" :label="$t('rule.contThreshold')" prop="threshold">
          <el-select
            class="add-rule-td-multiple-threshold"
            v-model="form2.threshold"
            filterable
            allow-create
            default-first-option
            :placeholder="$t('rule.texterrEnterThreshold')">
            <el-option
              v-for="(item,itemIndex) in thresholdOptions"
              :key="itemIndex"
              :label="Number(item*100).toFixed(1)"
              :value="item">
            </el-option>
          </el-select> %
        </el-form-item>
      </el-form>



    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="ensure">{{$t('rule.buttonOK')}}</el-button>
      <el-button @click="hide" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>
</template>

<script lang="ts">
import { Component, Vue , Watch, Prop} from 'vue-property-decorator';
import TreeSelect from '@/components/tree-select/index.vue';
import {addTDRulesMultiple,getLibsList,getDevicesTreeData} from "@/api/rule";
import {EventBus} from '@/utils/eventbus';
const defaultAcThreshold = window.globalConfig.acThreshold;
import {ruleThresholdOptions} from '@/utils/constants';
import {trim} from 'lodash';
import i18n from '@/lang/index';
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    TreeSelect
  },
})
export default class AddRuleTDMultiple extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;
  // @Prop({default:''}) groupId!: string;
  @Prop({default:''}) ruleId!: string;

  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.initData();
    //初始化groupId
    !n && (this.groupId = '');
    !n && (this.groupName = '');
  }
  get language() {
    return AppModule.language;
  }
  /* data */
  $refs!:{
    library:HTMLFormElement,
    form:HTMLFormElement
  };
  groupId:string="";
  groupName:string="";
  labelWidth:string='117px';
  form:{
    ruleGroupName:string;
    checkedCamerasIds:any[];
  }={
    ruleGroupName:"",
    checkedCamerasIds:[]
  };
  validateGroupName=(rule, value, callback) => {
    let str = value;
    if (str === '') {
      callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
    } else {
      //去除两头空格:
      let regx = /^\s+|\s+$/g;
      while (regx.test(str)) {
        str   =  trim(str);
      };
      str   =  trim(str);
      if(str){
        callback();
      }else{
        callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
      }

    }
  };
  rules={
    ruleGroupName:[
      { required: true, validator: this.validateGroupName, trigger: 'blur' },
      // { min: 1, max: 40, message: '长度在 1 到 40 个字符', trigger: 'blur' }
    ],
    checkedCamerasIds:[
      { required: true, message: i18n.t('form.texterrSelectDevice')+""},
    ],
  };
  rules2={
    threshold:[
      { required: true, message: i18n.t('form.texterrEnterThreshold')+""},
    ],
  };
  form2:any={
    threshold:defaultAcThreshold
  };
  timeCheckListModel:any[]=[];
  libsList:any[]=[{id:-1,label:"",children:[]},{id:0,label:"",children:[]}];
  timezoneList:any[]=[];
  treeData:any[] = [];
  props:any=this.$props;
  thresholdOptions = ruleThresholdOptions;
  /* methods */
  getParamsValueFromURL(key){
    let url_string = location.href.split('?')[1];
    let searchParams = new URLSearchParams(url_string);
    return searchParams.get(key) || '';
  }
  initData(){
    this.$refs.form && this.$refs.form.clearValidate();
    //groupId
    this.groupId = this.getParamsValueFromURL('groupId');
    this.groupName = this.getParamsValueFromURL('groupName');

    if(this.groupId){
      this.rules.ruleGroupName=[];
    }else{
      this.rules.ruleGroupName=[
        { required: true, validator: this.validateGroupName, trigger: 'blur' },
        // { min: 1, max: 40, message: '长度在 1 到 40 个字符', trigger: 'blur' }
      ];
    };

    this.form.checkedCamerasIds=[];
    this.form2.threshold=defaultAcThreshold;
    this.getDevices();
    this.getLibsList();
  }
  hide(){
    this.$emit('hideAddRuletdMultipleDialog')
  }
  handleClose(){
    this.hide();
  }
  getDevices(){
    getDevicesTreeData({deviceType:14}).then((res:any)=>{
      this.treeData = res.data;
    })
  }
  selectedCamera(camera){
    if(camera && camera.length>0){
      this.form.checkedCamerasIds = this.getOnlyKeeperIds(camera);
    }else{
      this.form.checkedCamerasIds = [];
    }
    this.$refs.form.validate();
  }
  getOnlyKeeperIds(list){
    let arr:any = [];
    list.map((item)=>{
      arr.push(item.id)
    })
    return arr;
  }
  //libslist
  getLibsList(keywords?){
    getLibsList(keywords).then(res=>{
      this.libsList=[];
      res && this.formatLibs(res);
    })
  }
  formatLibs(res){
    this.libsList = [{id:-1,label:this.$tc('rule.contWhitelist'),children:[]},{id:0,label:this.$tc('rule.contBlacklist'),children:[]}];
    res.whitelists && res.whitelists.map((item:any)=>{
       this.libsList[0].children.push({
        id:item.libraryId,
        label:item.libraryName
      })
    });
    res.blacklists && res.blacklists.map((item:any)=>{
      this.libsList[1].children.push({
        id:item.libraryId,
        label:item.libraryName
      })
    });
  }
  getOnlyLeafTreeLibs(){
    let list = this.$refs.library.getCheckedKeys(true);
    let lis:any[]=[];
    list.map(item=>{
      item > 0 && lis.push(item);
    });
    return lis;
  }
  formatSubmitData(){
    let data  = {
      "deviceIds": this.form.checkedCamerasIds,
      "libraryIds": this.getOnlyLeafTreeLibs(),
      "taskGroup": {
        // "taskGroupId": 1,
        "taskGroupName": this.form.ruleGroupName
      },
      "taskType": 1,//0->ac 1->td
      "threshold": this.form2.threshold
    };
    if(data.threshold>0 && data.threshold<100 && !this.thresholdOptions.some((item)=> data.threshold == item)){
      data.threshold = (data.threshold*1000)/100000 ;
    };
    if(this.groupId){
      data.taskGroup['taskGroupId'] = this.groupId;
    }else{
      data.taskGroup['taskGroupName'] = this.form.ruleGroupName;
    };
    return data;
  }
  ensure(){
    let data  = this.formatSubmitData();
    //name min:1 max:40 get40
    if(trim(data.taskGroup.taskGroupName).length>40){
      data.taskGroup.taskGroupName = trim(data.taskGroup.taskGroupName).substr(0,40);
    };
    this.$refs.form.validate(valid=>{
      if(valid){
        if(data.libraryIds && data.libraryIds.length>0){
          addTDRulesMultiple(data).then(res=>{
            // this.$message({
            //   message: '添加成功',
            //   type: 'success'
            // });
            if(data.taskGroup['taskGroupId']){
              EventBus.$emit('rule-refresh-ruleslistTD')
            }else{
              EventBus.$emit('rule-refresh-grouptd');
            };
            this.hide();
          })
        }else{
          this.$message.error(this.$tc('form.texterrSelectImageLib') as string);
        }
      }
    })
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .add-rule-td-multiple-threshold{
    width: 120px;
  }
  // .add-rule-td-multiple-form1{
  //   border-bottom: 1px solid $--border-color-form;
  // }
  .add-rule-td-multiple-libs{
    padding-top: 10px;
    width: 62%;
    margin: 0 auto;
    margin-bottom: 20px;
    .add-rule-td-multiple-libsheader{
      height: 24px;
      line-height: 24px;
      color: $--color-black;
      text-indent: 8px;
    }
    .add-rule-td-multiple-libsheader-time{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;
    }
    .add-rule-td-multiple-libs-scrollbox{
      width: 100%;
      max-height: 225px;
      overflow: auto;
    }

  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
  // ::v-deep .el-form{
  //     max-width: 330px;
  //     margin: 0 auto;
  //   }
  .add-rule-td-multiple-keepertreeinput{
    width: 100%;
  }

::v-deep .add-rule-td-multiple-libs-scrollbox .el-tree .el-tree-node .el-tree-node__children .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .add-rule-td-multiple-libs-scrollbox .el-tree>.el-tree-node.is-current>.el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .add-rule-td-multiple-libs-scrollbox .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }

// ::v-deep .el-form-item.is-required:not(.is-no-asterisk)>.el-form-item__label{
//     position: relative;
//     &:before {
//       position: absolute;
//       left: -8px;
//     }
//   }
</style>
