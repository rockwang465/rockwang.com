<template>
  <div class="group-ac-container">

    <div class="group-ac-contents" >
      <GroupCard
        :title="group.name"
        :devices="group.devicesNum"
        :times="group.times"
        :libs="group.libs"
        :groupId="group.groupId"
        v-for="(group,groupIndex) in groupListData"
        :key="groupIndex"
        type="ac"
        @view="handleView" @edit="(groupId)=>handleEdit(groupId,group.name)" @delete="handleDelete" />
    </div>
    <div class="group-ac-footer" >
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
    <el-dialog
      class="group-ac-dialog"
      :visible="showRenameDialog"
      :before-close="()=>this.showRenameDialog = false"
      width="400px">
      <el-form ref="formname" :model="form" :rules="rules" label-width="120px">
        <el-form-item :label="$t('rule.contRulesetName')" prop="groupName">
          <el-input v-model="form.groupName"></el-input>
        </el-form-item>
      </el-form>
      <div slot="title" class="group-ac-dialog-header" >
        <span>{{$t('rule.titleEdit')}}</span>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="ensureEdit">{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="showRenameDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>

    <!-- delete dialog -->
    <el-dialog
      :visible="showDeleteDialog"
      :before-close="()=>this.showDeleteDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{this.$t('rule.popmsgRulesetDelete')}}</p>
      <div slot="title" class="group-ac-dialog-header" >
        <span>{{this.$t('rule.titleDelete')}}</span>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="danger" @click="ensureDelete">{{$t('rule.buttonOperationDelete')}}</el-button>
        <el-button @click="showDeleteDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import GroupCard from './group-card.vue';
import {getACRule,editGroupName,deleteRulesGroup} from '@/api/rule';
import { RuleModule } from '@/store/modules/rule';
import {EventBus} from '@/utils/eventbus';
import {trim} from 'lodash';
import i18n from '@/lang/index';
import {paginationPageSizes} from '@/utils/constants';

@Component({
  components: {
    GroupCard,
  },
})
export default class GroupAC extends Vue {
  // 计算属性
  // get keyword (){
  //   return RuleModule.keyword;
  // }

  /* props */
  @Prop({default:false}) addRuleSuccess!: boolean;

  /* watch */
  @Watch('currentPage')
  onCurrentPageChange(n,o){
    this.getGroupList()
  }
  @Watch('pageSize')
  onPageSizeChange(n,o){
    this.getGroupList()
  }
  // @Watch('keyword')
  // onkeywordChange(n,o){
  //   this.getGroupList({keyword:n});
  // }
  @Watch('addRuleSuccess', { immediate: true, deep: true })
  onAddRuleSuccessChange(n,o){
    n && this.initDroupData();
  }
  @Watch('showRenameDialog', { immediate: false, deep: true })
  onShowRenameDialogChange(n,o){
    if(n){
      // this.form.groupName = '';
      this.$refs.formname && this.$refs.formname.clearValidate();
    }
  }
  /* data */
  $refs !:{
    formname:HTMLFormElement
  };
  showRenameDialog:boolean=false;
  form:{groupName:string;}={groupName:''};
  validateGroupName=(rule, value, callback) => {
    let str = value;
    if (str === '') {
      callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
    } else {
      //去除两头空格:
      let regx = /^\s+|\s+$/g;
      while (regx.test(str)) {
        str   =  trim(str);
      };
      str   =  trim(str);
      if(str){
        callback();
      }else{
        callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
      }

    }
  };
  rules={
    groupName:[
      { required:true,validator: this.validateGroupName, trigger: 'blur' },
      // { min: 1, max: 40, message: '长度在 1 到 40 个字符', trigger: 'blur' }
    ],
  };

  currentPage:number=1;
  totalPage:number=1;
  total:number=0;
  // pageSizes=[10,20,30,40,50];
  pageSizes=paginationPageSizes;
  pageSize:number=this.pageSizes[0];
  acRulesListCondition:any;
  groupListData:any[] = [];

  currentGroupId:any='';

  keyword:string='';

  //delete
  showDeleteDialog:boolean=false;
  currentDeleteId:any='';
  /* methods */
  mounted() {
    this.initDroupData();
    EventBus.$on('rule-refresh-group-ac',()=>{this.getGroupList()});
    EventBus.$on('rule-search-group-ac',(n)=>{this.keyword = n;this.getGroupList({keyword:n});})
  }
  initDroupData(){
    //获取group列表
    this.getGroupList()
  }
  handleView(group){
    this.$emit('viewrules',group)
  }
  handleEdit(groupId,groupName){
    this.form.groupName = groupName;
    this.currentGroupId = groupId;
    this.showRenameDialog = true;
  }
  ensureEdit(){
    this.$refs.formname.validate((valid)=>{
      if(valid){
        let name = this.form.groupName;
        //name min:1 max:40 get40
        if(trim(name).length>40){
          name = trim(name).substr(0,40);
        };
        this.editGroupName(this.currentGroupId,this.form.groupName);
        this.showRenameDialog = false;
      }
    });
  }
  handleDelete(groupId){
    this.deleteGroup(groupId)
  }
  handleSizeChange(val){
    this.pageSize = val;
    this.getGroupList({keyword:this.keyword})
  }
  handleCurrentChange(val){
    this.currentPage  = val;
    this.getGroupList({keyword:this.keyword})
  }
  getGroupList(params?){
    let para = {...params,page:this.currentPage,num:this.pageSize};
    getACRule({...para}).then((res:any)=>{
      this.formatGroupData(res.list);
      this.totalPage = res.totalPage;
      this.total = res.total;
    })
  }
  editGroupName(groupId,groupName){
    editGroupName({"taskGroupId": groupId,"taskGroupName": groupName}).then(res=>{
      // this.$message({
      //   message: '修改成功',
      //   type: 'success'
      // });
      this.getGroupList();
    }).catch(err=>{

    })
  }
  ensureDelete(){
    let groupId = this.currentDeleteId;
    groupId && deleteRulesGroup(groupId).then(res=>{
      // this.$message({
      //   message: '删除成功',
      //   type: 'success'
      // });
      this.showDeleteDialog = false;
      this.getGroupList();
    }).catch(err=>{
      this.showDeleteDialog = false;
    })
  }
  deleteGroup(groupId){
    this.currentDeleteId = groupId;
    this.showDeleteDialog = true;

    // this.$confirm(this.$tc('rule.popmsgRulesetDelete') as string, this.$tc('rule.titleDelete') as string, {
    //   confirmButtonText: this.$tc('rule.buttonDelete') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    //   center: true
    // }).then(() => {
    //   deleteRulesGroup(groupId).then(res=>{
    //     // this.$message({
    //     //   message: '删除成功',
    //     //   type: 'success'
    //     // });
    //     this.getGroupList();
    //   })
    // }).catch(() => {

    // });

  }
  formatGroupData(list){
    this.groupListData = [];
    list.map(item=>{
      this.groupListData.push({
        name:item.taskGroupName,
        devicesNum:item.deviceNum,
        times:item.timeZoneNum,
        libs:item.libraryNum,
        groupId:item.taskGroupId
      })
    })
  }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .group-ac-container{
    padding-top:10px;
    height: 100%;
    .group-ac-contents{
      height: calc(100% - 32px);
      padding: 10px 0;
      overflow-y: auto;
      display: grid;
      grid-gap: 8px;
      // grid-template-columns: repeat(auto-fit, minmax(325px, 1fr));
      grid-template-rows: repeat(auto-fill, 220px);
      grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
    }
    .group-ac-footer{
      text-align: center;
    }
  }
  // ::v-deep .group-ac-dialog .group-ac-dialog-header{
  //   padding: 10px 2px;
  //   border-bottom:1px solid $--border-color-form;
  // }
</style>
