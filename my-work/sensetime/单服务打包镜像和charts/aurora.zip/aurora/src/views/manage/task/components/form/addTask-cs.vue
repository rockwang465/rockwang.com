<template>
  <div v-if="visible" style="display:flex;flex-direction: column;align-items: center;">
    <el-form ref="form" :model="form" :rules="rules" label-position="right" :label-width="labelWidth">
      <el-form-item :label="$t('task.contTaskName')" prop="taskName">
        <el-input v-model="form.taskName" placeholder=""></el-input>
      </el-form-item>
      <el-form-item prop="defaultDevices" :label="$t('rule.labelDevice')">
        <TreeSelectRadio
          :data="treeData"
          @check="deviceSlected"
          @clear="clearTreeSelectRadio"
          :defaultChechedKeys="form.defaultDevices"
        />
      </el-form-item>
      <el-form-item prop="" :label="$t('task.contTimezone')">
        <el-select v-model="form.timeZoneId" clearable>
          <el-option
            v-for="(timezone,timezoneIndex) in timezoneList"
            :key="timezoneIndex"
            :label="timezone.label"
            :value="timezone.id">
          </el-option>
        </el-select>
      </el-form-item>

      <el-col :span="24" >
        <strong>{{$t('task.alarmSet')}}</strong>
      </el-col>
      <el-col :span="24" style="padding-top:20px;">
        <div class="sapce-border" ></div>
      </el-col>

      <!--告警阈值-->

      <el-form-item prop="threshold" :label="$t('task.alarmThreshold')">
        <el-row>
          <el-col :span="8">
            <el-input v-model="form.threshold" @input="inputAgeNum" :maxlength="form.thresholdUnit == 2 ? 2 : 3" style="width:60px"></el-input>
          </el-col>
          <el-col :span="14">
            <el-select v-model="form.thresholdUnit" @change='onformThresholdUnitChange' style="width: 130px">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>

      </el-form-item>

      <!--持续时间-->
      <!-- <el-form-item prop="duration" label="持续时间">
        <el-row>
          <el-col :span="8">
            <el-input v-model="form.duration" :maxlength="3" @input="()=>{form.duration =/^[1-9][0-9]*$/.test(form.duration) ?form.duration : ''}"   style="width:60px"></el-input>
          </el-col>
          <el-col :span="14">
            <el-select v-model="form.durationUnit" style="width: 130px">
              <el-option
                v-for="item in durationOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>

      </el-form-item> -->
      <!--宽高设置-->
      <!--宽高设置-->
      <!--宽高设置-->

      <el-col :span="24" >
        <strong>{{$t('task.pushSettings')}}</strong>
      </el-col>
      <el-col :span="24" style="padding-top:20px;">
        <div class="sapce-border" ></div>
      </el-col>

      <!--推送设置-->
      <el-form-item prop='pushInterval' :label="$t('task.normalPushInterval')">
        <el-row>
          <el-col :span="8">
            <el-input v-model="form.pushInterval" :maxlength="3" @input="()=>{form.pushInterval =/^[1-9][0-9]*$/.test(form.pushInterval) ?form.pushInterval : ''}"  style="width:60px"></el-input>
          </el-col>
          <el-col :span="14">
            <el-select v-model="form.pushIntervalUnit" style="width: 130px">
              <el-option
                v-for="item in pushIntervalOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item prop='alarmInterval' :label="$t('task.alertPushInterval')">
        <el-row>
          <el-col :span="8">
            <el-input v-model="form.alarmInterval" :maxlength="3" @input="()=>{form.alarmInterval =/^[1-9][0-9]*$/.test(form.alarmInterval) ?form.alarmInterval : ''}"  style="width:60px"></el-input>
          </el-col>
          <el-col :span="14">
            <el-select v-model="form.alarmIntervalUnit" style="width: 130px">
              <el-option
                v-for="item in alarmIntervalOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </el-form-item>

      <el-form-item prop='humanBodyArray' :label="$t('task.drawBodyPos')">
        <el-button @click.once="humanBodyScale" @click="previewHumanBody(true)" type="text" :disabled="!isVideo">{{$t("task.contPreviewDraw")}}</el-button>
        <el-button @click="previewHumanBody(false)" type="text" :disabled="!isVideo">{{$t("task.contNoPreviewDraw")}}</el-button>
      </el-form-item>
      <el-form-item>
        <p class="draw-tips">
          {{$t("task.drawBodyTips")}}
          <!-- <el-popover
            placement="top-start"
            width="400"
            trigger="click"
            >
            <div class="moudle-tips">素材图准备中</div>
            <a slot="reference" href="javascript:">{{$t("task.viewDemo")}}</a>
          </el-popover> -->
        </p>
      </el-form-item>


      <el-form-item v-if="isPolygons" prop="polygons" :label="$tc('task.contSetZone')">
        <span style="color:#ccc;">{{polygonsList.length>0?$tc('task.contAlreadyZone'):$tc('task.contYetZone')}}</span>
        <div style="font-size:12px;color:#ccc;width:220px;over-flow:hidden;line-height:16px;">（{{$tc('task.contSetZoneWarn')}}）</div>
      </el-form-item>
      <el-form-item v-else prop="polygons" :label="$tc('task.contSetZone')">
        <span style="color:#ccc;">{{polygonsList.length>0?$tc('task.contAlreadyZone'):$tc('task.contYetZone')}}</span>
        <div style="font-size:12px;color:#ccc;width:220px;over-flow:hidden;line-height:16px;">（{{$tc('task.contSetZoneWarn')}}）</div>
      </el-form-item>
    </el-form>
    <div class="btn-human-bodys" v-if="isHumanBodyBtns">
      <div class="btns">
        <el-button size="mini"
        v-for="(item,index) in humanBodys"
        :key="index"
        @click="handleBodyBtn(index)"
        v-bind:class="{ 'el-button--primary': item.isActive,'is-clear':item.isClear}"
        :disabled="item.isDisabled">
          {{item.name}}
          <i v-on:click.stop="clearHumanBody(index)" class="el-icon-refresh-left"></i>
          <!-- <i v-else v-on:click.stop="drawHumanBody(index)" class="el-icon-edit"></i> -->
        </el-button>
      </div>
      <el-button type="text" class="right" @click="resetBodySegment"><i class="iconfont icon-restore" ></i>{{$tc('task.contResetDefault')}}</el-button>
    </div>
    <div class="addTaskPC-btns" v-if="form.defaultDevices && form.defaultDevices[0]" >
      <div class="addTaskPC-btns-polygons">
        <div v-show="visible1" class="area-popover-content">
          <h5>{{$t('task.areaDrawn')}}</h5>
          <div style="margin: 20px 0;">
            <el-input style="width: 80%;"
              v-model="drawArea"
              @input="drawArea = /^[1-9][0-9]*$/.test(drawArea) ? drawArea : ''"
              ></el-input> m²</div>
          <div class="timezone-timezone-footer">
            <el-button type="primary" @click="confirmArea()">{{$t('imagemanagement.buttonOK')}}</el-button>
            <el-button class="cancel" @click="visible1 = false;drawArea = null">{{$t('imagemanagement.buttonCancel')}}</el-button>
          </div>
        </div>

        <div  v-for="(polygon,polygonIndex) in polygonsList" :key="polygonIndex" class="addTaskPC-btns-btn"
              @click="(e)=>clickBtns(polygonIndex)"
              @mouseenter="(e)=>enterBtns(polygonIndex)" @mouseleave="(e)=>leaveBtns(polygonIndex)">
          {{`${$tc('task.contZoneNum')}${polygonIndex+1}`}}
          <div class="addTaskPC-btns-btn-delete" @click.stop="(e)=>deletePolygon(polygonIndex)">
            <div style="width:8px;height:2px;background-color:#fff;"></div>
          </div>
        </div>

        <div @click="beginDrawLine" v-show="polygonsList.length < 1" >
          <i class="iconfont icon-edit1" ></i>{{$tc('task.contClickSetZone')}}
        </div>
      </div>
      <div class="addTaskPC-btns-polygons">
        <el-button type="text" @click="restoreLine" v-show="polygonsList.length > 0">
          <i class="iconfont icon-restore" ></i>{{$tc('task.contAreaClean')}}
        </el-button>
      </div>

    </div>
    <div v-if="form.defaultDevices && form.defaultDevices[0]" class="addTaskPC-video" style="position:relative;width:532px;"  >
      <MediaPlayer v-if="form.defaultDevices && form.defaultDevices[0]" :showControl="false" type="1" name="test" :url="form.defaultDevices[0].videoPath" @loadedmetadata="initDrawer" />
      <DrawPolygons ref="drawLines"
        :style="{position:'absolute',left:0,top:0,'z-index':drawLineIndex}"
        :width="sketchpadWidth"
        :height="sketchpadHeight"
        v-bind:class="{'drawing':isDrawing}"
        @drawEnd="drawEndFn"
        :scale="{w:scaleW,h:scaleH}"
        :segmentList="segmentList"
        @hidedrawLine="()=>{this.drawLine = false}"
        :drawLine="drawLine" />

      <DrawPolygons ref="drawPolygons"
                    @end="handleDrwaEnd"
                    :style="{position:'absolute',left:0,top:0}"
                    :width="sketchpadWidth"
                    :height="sketchpadHeight"
                    @hidedrawmodel="()=>{this.drawModel = false}"
                    :drawModel="drawModel" style="z-index:99"  />

    </div>

  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
  import {getTimezoneWithIntervals,getDevicesTreeData,getSpecialAttrs} from '@/api/rule';
  import {addCSTasks} from '@/api/task';
  import TreeSelectRadio from "../treeSelectRadio.vue";
  import i18n from '@/lang/index';
  import MediaPlayer from '@/components/media-player/index.vue';
  import DrawPolygons from '../drawPolygons.vue';
  import {cloneDeep,trim} from 'lodash';
  import {calculateClockDirection} from '@/utils/polygons.ts';
  import { AppModule } from '@/store/modules/app';
  import { defaultBodySegments } from '@/utils/constants';
  const defaultMiniMax = {//default value
    miniNumber:{width:30,height:30},
    maxNumber:{width:500,height:500}
  };

  interface PointObj {
    x:number
    y:number
  }
  const polygonLimitNum = 1;

  @Component({
    components: {
      TreeSelectRadio,
      MediaPlayer,
      DrawPolygons
    },
  })
  export default class AddTaskCs extends Vue {
    /* props */
    @Prop({default:false}) visible!: boolean;
    @Prop({required:true}) labelWidth!: string;

    /* watch */
    @Watch('visible',{ immediate: true})
    onVisibleChange(n,o){
      n && this.initData();
    }
    @Watch('polygonsList')
    onpolygonsListChange(n){
      if (n.length == 0){
        this.visible1 = false;
      }
    }

    isVideo:boolean = false
    isActive:boolean = false
    isDrawing:boolean = false
    drawLineIndex = 1;
    inDrawingIndex = 0

    // @Watch('form.thresholdUnit')
    onformThresholdUnitChange(){
      this.form.threshold = ''
    }

    get language() {
      return AppModule.language;
    }

    //输入验证
    inputAgeNum(val){

      if(this.verifySize(val)){
        this.form.threshold = val
      }else{
        this.form.threshold = '';
      }

    }
    inputAgeNum2(val){

      if(/^[1-9][0-9]*$/.test(val)){
        this.form.threshold = val
      }else{
        this.form.threshold = '';
      }

    }

    verifySize(val){//数字
      let reg = /^([1-9]|20|1[0-9])$/;
      if(this.form.thresholdUnit != 2) {
        reg = /^[1-9][0-9]*$/;
      }

      if(reg.test(val)|| val==""){

        return true;
      }else{
        return false;
      }
    }

    get subLabelWidth(){
      return AppModule.language === 'en'?'48px':'20px';
    }

    get isPolygons(){
      return this.form.thresholdUnit == 2?true:false
    }
    /* data */
    $refs !:{
      drawPolygons,
      drawLines,
      form:HTMLFormElement
    }
    form:{
      taskName:string;
      defaultDevices:any[],
      timeZoneId:any,
      specialAttribute:any[],
      polygons:any[],
      // duration:any,//持续时间
      // durationUnit:any,
      threshold:any,//告警阈值
      alarmInterval:any,//告警时间间隔
      alarmIntervalUnit:any,//告警时间间隔单位
      pushInterval:any,//推送时间间隔
      pushIntervalUnit:any,//推送时间间隔单位
      thresholdUnit:any,//告警阈值单位
      strandAnalyzeVertices:Object
    }={
      taskName:'',
      defaultDevices:[],
      timeZoneId:'',
      specialAttribute:[],
      polygons:[],
      // duration: null,//持续时间
      // durationUnit:1,
      threshold : null,//告警阈值
      alarmInterval:1,//告警时间间隔
      alarmIntervalUnit:2,//告警时间间隔单位
      pushInterval:2,//推送时间间隔
      pushIntervalUnit:2,//推送时间间隔单位
      thresholdUnit:1,//告警阈值单位
      strandAnalyzeVertices:{
        labeledPersonVertices:[]
      }
    };
    humanBodys:any = []
    isHumanBodyBtns = false
    rules={
      taskName:[
        { required: true,validator:this.validateTaskName, trigger: 'blur' },
      ],
      defaultDevices:[
        { required: true, message: i18n.tc('form.texterrSelectDevice')},
      ],
      threshold:[{
         required: true, message: i18n.tc('form.cannotBeEmpty'),trigger:'blur'}
      ],
      // duration:[{required: true,message: '持续时间不能为空', trigger: 'blur' }],
      pushInterval:[{required: true,message: i18n.tc('form.cannotBeEmpty2'), trigger: 'blur' }],
      alarmInterval:[{required: true,message: i18n.tc('form.cannotBeEmpty3'), trigger: 'blur' }],
      area:[{required: true,message: i18n.tc('form.cannotBeEmpty4'), trigger: 'blur' }],
      timeZoneId:[
        { required: true, message: i18n.tc('form.texterrSelectTimezone')},
      ],
      polygons:[
        { required: true,message: i18n.tc('task.formSetZone')},
      ],
    };
    value='1';
    options=[{
      value: 1,
      label: i18n.tc('pedestrian.crowdUnit1')
    },{
      value: 2,
      label: i18n.tc('pedestrian.crowdUnit2')
    }]
    alarmIntervalOptions=[{
      value: 1,
      label: 's'
    },{
      value: 2,
      label: 'min'
    },{
      value: 3,
      label: 'hour'
    }]
    pushIntervalOptions=[{
      value: 1,
      label: 's'
    },{
      value: 2,
      label: 'min'
    },{
      value: 3,
      label: 'hour'
    }]
    durationOptions=[{
      value: 1,
      label: 's'
    },{
      value: 2,
      label: 'min'
    },{
      value: 3,
      label: 'hour'
    }]
    visible1 = false;
    polygonIndex = '';
    drawArea:any = null;

    treeData:any[]=[];
    timezoneList:any[]=[];
    specialAttributeOptions:any[]=[];
    miniNumber:any={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
    maxNumber:any={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
    videoUrl:string='';
    sketchpadWidth:number=0;
    sketchpadHeight:number=this.sketchpadWidth*1080/1920;
    scale:any={x:1,y:1};
    drawModel:boolean=false;
    drawLine:boolean=false;
    polygonsList:any[]=[];

    minwidthError:boolean=false;
    maxwidthError:boolean=false;
    minheightError:boolean=false;
    maxheightError:boolean=false;
    scaleW = 1;
    scaleH = 1;
    segmentList:any = []
    /* methods */
    mounted(){

    }
    //validate
    validateTaskName(rule, value, callback){
      let str = value;
      if (str === '') {
        callback(new Error(i18n.tc('task.texterrEnterTaskName')));
      } else {
        //去除两头空格:
        let regx = /^\s+|\s+$/g;
        while (regx.test(str)) {
          str   =  trim(str);
        };
        str   =  trim(str);
        if(str && str.length<=40){
          callback();
        }else{
          callback(new Error(i18n.tc('task.texterrEnterTaskName')));
        }
      }
    }
    initDefaultMiniMax(){
      this.miniNumber={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
      this.maxNumber={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
    }
    initData(){
      this.treeData=[];
      this.timezoneList=[];
      this.specialAttributeOptions=[];
      this.initDefaultMiniMax();
      this.videoUrl='';
      this.sketchpadWidth=0;
      this.sketchpadHeight=this.sketchpadWidth*1080/1920;
      this.scale={x:1,y:1};
      this.drawModel = false;
      this.isVideo = false
      //init form
      this.form={
        taskName:'',
        defaultDevices:[],
        timeZoneId:'',
        specialAttribute:[],
        polygons:[],
        // duration: null,//持续时间
        // durationUnit:1,
        threshold : null,//告警阈值
        alarmInterval:1,//告警时间间隔
        alarmIntervalUnit:2,//告警时间间隔单位
        pushInterval:2,//推送时间间隔
        pushIntervalUnit:2,//推送时间间隔单位
        thresholdUnit:1,//告警阈值单位
        strandAnalyzeVertices:{
          labeledPersonVertices:[]
        }
      };
      this.polygonsList = [];
      this.polygonIndex = '';
      this.drawArea = null;
      this.drawLineIndex = 1;
      this.inDrawingIndex = 0;
      this.isDrawing = false
      this.isHumanBodyBtns = false;
      //get data
      this.getDevices();
      this.getTimezoneList();
      this.getSpecialAttrs();
      setTimeout(()=>{
        this.$refs.form && this.$refs.form.clearValidate();
        this.resetBodySegmentData()
      },60)
    }
    deviceSlected(v){
      this.isVideo = false;
      v && (this.form.defaultDevices = v);


    }
    clearTreeSelectRadio(){
      this.form.defaultDevices =  [];
      this.isVideo = false;
    }
    getDevices(){
      let deviceType = 14;
      let filter = 0;
      getDevicesTreeData({deviceType,filter}).then(res=>{
        res && res.data && (this.treeData = res.data);
      })
    }
    getTimezoneList(){
      this.timezoneList = [];
      getTimezoneWithIntervals().then((res:any)=>{
        res && this.formatTimezoneList(res.data);
      })
    }
    formatTimezoneList(timezoneList){
      timezoneList && timezoneList.map((item,itemIndex)=>{
        this.timezoneList.push({
          id:item.timeZoneId,
          label:item.timeZoneName
        })
      })
    }
    getSpecialAttrs(){
      getSpecialAttrs(5).then((res:any)=>{
        res && res.list.map(item=>{
          this.specialAttributeOptions.push({
            id:item.taskAttributeId,
            name:this.$tc(`rule.${item.taskAttributeName}`),
            disabled:false
          })
        })
      })
    }
    humanBodyScale(){
      let scaleW = this.sketchpadWidth / 1920;
      let scaleH = this.sketchpadHeight / 1080;
      this.scaleW = scaleW;
      this.scaleH = scaleH;
      this.humanBodys = cloneDeep(defaultBodySegments)
      this.$refs.drawLines.scaleValue(scaleW,scaleH)
    }
    clearHumanBody(currentId){
      this.inDrawingIndex = currentId;
      this.isDrawing = false
      this.$refs.drawLines.clearCanvas(1920,1080)
      this.humanBodys.map((item,index)=>{
        item.isClear = false;
        item.isDisabled = false;
        if(index !== currentId){
          item.isDisabled = true;
        }else{
          item.isDisabled = true;
          item.isClear = true;
        }
      })
      this.$refs.drawLines.insertLines(this.humanBodys,currentId);
      this.segmentList = this.humanBodys;
      this.drawHumanBody(currentId)
    }
    drawHumanBody(index){
      console.log('人体',index)
      this.isDrawing = true;
      this.drawLine = true;
      this.drawLineIndex = 100;
      //this.$refs.drawLines.drawSegment()
    }
    drawEndFn(drawdata:Array<PointObj>){
      //console.log(drawdata)
      this.resetBodySegmentData(true)
      let endPoints:Array<object> = []

      this.humanBodys.map((item,index)=>{
        if(index === this.inDrawingIndex){
          item.points.start = drawdata[0]
          item.points.end   = drawdata[1]
        }
        let iPoint = {
          "leftTop"    : {"x": item.points.start.x,"y": item.points.start.y},
          "rightBottom": {"x": item.points.end.x,"y": item.points.end.y}
        }
        endPoints.push(iPoint)

      })
      this.form.strandAnalyzeVertices = {
        labeledPersonVertices:endPoints
      }

      this.$refs.drawLines.insertLines(this.humanBodys,this.inDrawingIndex);

    }
    resetBodySegmentData(clearActive?){
      this.isDrawing = false
      this.drawLineIndex = 1;

      this.humanBodys.map((item)=>{
        item.isClear = false;
        item.isDisabled = false;
        if(!clearActive){
          item.isActive = false;
        }
      })
    }

    resetBodySegment(){
      this.$refs.drawLines.clearCanvas(1920,1080)
      this.humanBodys = cloneDeep(defaultBodySegments);
      this.resetBodySegmentData();
      this.$refs.drawLines.insertLines(this.humanBodys);
    }

    handleBodyBtn(currentId){
      //console.log('handleBodyBtn')
      this.isDrawing = false
      this.drawLineIndex = 1;
      this.$refs.drawLines.clearCanvas(1920,1080)

      this.humanBodys.map((item,index)=>{
        item.isActive = false;
        let color = "#0083f7"
        if(index === currentId){
          item.isActive = true
          color = "#cc0000"
        }
      })
      this.$refs.drawLines.insertLines(this.humanBodys,currentId);
    }

    previewHumanBody(show){
      this.isDrawing = false
      this.drawLineIndex = 1;
      this.$refs.drawLines.clearCanvas(1920,1080)
      this.isHumanBodyBtns = false;

      if(show){
        //console.log("绘制人",this.$refs.drawPolygons)
        this.isHumanBodyBtns = true;
        this.$refs.drawLines.insertLines(this.humanBodys);
      }else{
        //this.$refs.drawLines.clearCanvas()
      }
    }

    initDrawer(video){
      //console.log(video)
      this.isVideo = true
      let origin_w = video.target.videoWidth,origin_h = video.target.videoHeight;
      let client_w = video.target.clientWidth,client_h = video.target.clientHeight;
      //set canvas
      this.sketchpadWidth  = client_w;
      this.sketchpadHeight = client_h;
      //set scale
      this.scale.x = client_w/origin_w;
      this.scale.y = client_h/origin_h;

      //设备切换后，绘制数据初始化
      this.resetBodySegment()
      this.previewHumanBody(false)
    }
    showOnVideo(type){
      this.$refs.drawPolygons.clearCanvas();
      this.drawModel = false;
      type == 'mini' && this.$refs.drawPolygons.drawRectangle(this.centerCoordinate(this.miniNumber));
      type == 'max' && this.$refs.drawPolygons.drawRectangle(this.centerCoordinate(this.maxNumber));
    }
    setDefault(type){
      type == 'mini' && (this.miniNumber={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height});
      type == 'max' && (this.maxNumber={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height});
      this.showOnVideo(type);
    }
    centerCoordinate(size){
      let size_copy = cloneDeep(size);
      size_copy.width  = size_copy.width*this.scale.x;
      size_copy.height = size_copy.height*this.scale.y;
      let centerCoordinate = {x:this.sketchpadWidth/2,y:this.sketchpadHeight/2};
      let start = {x:centerCoordinate.x-(size_copy.width/2),y:centerCoordinate.y-(size_copy.height/2)};
      let end   = {x:centerCoordinate.x+(size_copy.width/2),y:centerCoordinate.y+(size_copy.height/2)};
      return [start,end];
    }
    beginDrawLine(){
      if(this.$refs.drawPolygons){
        this.$refs.drawPolygons.clearCanvas();
        this.$refs.drawPolygons.drawAllPolygons();
      }
      if(this.polygonsList.length <  polygonLimitNum) this.drawModel = true;
    }
    restoreLine(){
      this.$refs.drawPolygons.clearAll();
      this.polygonsList = [];
      this.form.polygons = [];
      this.drawModel = false;
      this.$refs.form.validateField('polygons')
    }
    handleDrwaEnd(data){
      console.log(data);
      this.drawModel = false
      let arr:any[] = [];
      data && data.length>0 && data.map(poly=>{
        arr.push(this.setScaleForCoordinate(poly.points));
      });
      this.polygonsList = arr;
      this.form.polygons = arr;
      this.$refs.form.validateField('polygons')
      this.visible1 = true
    }
    setScaleForCoordinate(list){
      let arr = [], _w = this.sketchpadWidth, _h = this.sketchpadHeight;
      if(_w > 0 && _h > 0 && list && list.length > 0){
        arr = list.map(item =>{
          let x = item.x/_w , y = item.y/_h,area=item.area;
          return {x,y,area}
        })
      }
      return arr.length>0?arr:list;
    }
    getOriginScaleForCoordinate(list){
      let arr = [], _w = this.sketchpadWidth, _h = this.sketchpadHeight;
      if(_w > 0 && _h > 0 && list && list.length > 0){
        arr = list.map(item =>{
          let x = item.x*_w , y = item.y*_h;
          return {x,y}
        })
      }
      return arr.length>0?arr:list;
    }
    confirmArea(){
      // console.log('------创建生成区域大小',this.polygonIndex);
      this.$refs.drawPolygons.showAreaPolygon(this.polygonIndex,this.drawArea);
      this.visible1 = false
    }
    clickBtns(polygonIndex){
      this.polygonIndex = polygonIndex;
      this.visible1 = true
    }
    enterBtns(polygonIndex){
      // this.$refs.drawPolygons.showCurrentPolygon(polygonIndex)
      if(this.$refs.drawPolygons && this.$refs.drawPolygons.polygons
        && this.$refs.drawPolygons.polygons[polygonIndex]
        && this.$refs.drawPolygons.polygons[polygonIndex].points
        && this.$refs.drawPolygons.polygons[polygonIndex].points.length>0){
        this.$refs.drawPolygons.showCurrentPolygon(polygonIndex)
      }else if(this.$refs.drawPolygons){
        this.$refs.drawPolygons.clearAll();
        //set default
        if(this.polygonsList.length>0){
          let arr:any[]=[];
          arr = this.polygonsList.map(polygon=>{
            return this.getOriginScaleForCoordinate(polygon);
          });
          this.$nextTick(()=>{
            arr && arr.length>0 && this.$refs.drawPolygons.drawPolygonsMethod(arr);
          })

        }
      }
    }
    leaveBtns(polygonIndex){
      this.$refs.drawPolygons.hideCurrentPolygon(polygonIndex)
    }
    deletePolygon(polygonIndex){
      this.polygonsList.splice(polygonIndex,1);
      this.form.polygons = this.polygonsList;
      this.$refs.drawPolygons.deletePolygon(polygonIndex);
      this.$refs.form.validateField('polygons')
    }
    submitData(startcal,successcal,errorcal){
      let _this = this as any;
      if(!this.polygonsList[0] ) {
        this.$message.error({showClose: true,message:_this.$t('task.contYetZone')})
        // return
      }
      if (this.form.thresholdUnit == 2 && this.polygonsList[0] && !this.drawArea){
        this.$message.error({showClose: true,message:_this.$t('task.noneSetZone')})
        return
      }
      let data = {
        "deviceId": this.form.defaultDevices.length>0?this.form.defaultDevices[0].id:'',
        "taskName": this.form.taskName,
        "taskConfigId": 5,//人群
        "timeZoneId": this.form.timeZoneId,
        "vertices": {
          "rois": [
            {
              "area": this.drawArea,
              "hotSpotName": "m",
              "pointVos": this.polygonsList[0],
            }
          ],
          // "area":this.drawArea,
          // "pointVoList": this.polygonsList,
        },
        "alarmInterval":this.form.alarmInterval,//告警时间间隔
        "pushInterval":this.form.pushInterval,//推送时间间隔
        // "duration":this.form.duration,//持续时间
        // "durationUnit":this.form.durationUnit,//
        "threshold":this.form.threshold,//告警阈值
        "thresholdUnit":this.form.thresholdUnit,//告警阈值单位
        "alarmIntervalUnit":this.form.alarmIntervalUnit,//
        "pushIntervalUnit":this.form.pushIntervalUnit,//
        "strandAnalyzeVertices":this.form.strandAnalyzeVertices
      } as any;
      console.log(data)
      if(data.vertices.rois[0].pointVos&&data.vertices.rois[0].pointVos.length>0){
        data.vertices.rois[0].pointVos.map(arr=>{
          if(!calculateClockDirection(arr)) arr.reverse();
        })
      }
      (!this.minwidthError && !this.minheightError && !this.maxwidthError && !this.maxheightError) && this.$refs.form.validate((isvalidate)=>{
        isvalidate && startcal && startcal();
        isvalidate && addCSTasks(data).then(res=>{
          successcal && successcal(res);
        }).catch(err=>{
          errorcal && errorcal(err)
        })
      })

    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .tables-container{
    .task-list-operation-item{
      cursor: pointer;
      margin-right: 8px;
      i.iconfont{
        font-size:19px;
      }
    }
  }
  ::v-deep .el-select__tags .el-tag--info {
    color: #28354d;
  }

  .el-input{
    ::v-deep input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
  }
  .addTaskPC-linkbtn{
    display: inline-block;
    color: #2A5AF5;
    cursor: pointer;
    text-decoration: underline ;
  }
  .addTaskPC-video{
    position: relative;
    width: 532px;
  }
  .addTaskPC-btns{
    display: flex;
    justify-content: space-between;
    width: 532px;
    padding-bottom: 8px;
    &>div{
      cursor: pointer;
      &:active{
        color: #2A5AF5;
      }
    }
  }
  .addTaskPC-btns-btn{
    padding: 8px 16px;
    border:1px solid #7E7E9A;
    border-radius: 4px;
    margin-right: 16px;
    position: relative;
    display: inline-block;
    &:hover{
      background-color: #1989FA;
      color: white;
      .addTaskPC-btns-btn-delete{
        display: flex;
      }
    }
    .addTaskPC-btns-btn-delete{
      display: none;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background-color: #ED3A33;
      cursor: pointer;
      position: absolute;
      top: -8px;
      right: -8px;
      justify-content: center;
      align-items: center;
    }
  }
  .addTaskPC-btns-polygons{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    position: relative;
  }
  ::v-deep .el-select{
    width: 100%;
  }
  ::v-deep .el-input.form-number-error .el-input__inner{
    border-color: red;
  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
  .warning-inp{
    display: flex;
  }
  .area-popover-content{
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 400px;
    position: absolute;
    top: 40px;
    transform-origin: center top;
    z-index: 111;
    border: 1px solid #000;
    padding: 10px;
    border-radius: 4px;
    background: #FFFFFF;
  }
  .btn-human-bodys{
    width: 100%;
    margin-bottom: 8px;
    position: relative;
    .right{
      position: absolute;
      right: 0;
      top: 0;
    }
    .btns{
      .el-button{
        position: relative;
      }
      .el-button--primary,
      .el-button--primary{
        // &:hover,
        // &:focus{}
          i{
            display: block;
            color: #28354d;
          }

      }
      .el-button--primary:hover i,
      .el-button--primary:focus i{
        color: #28354d;
        &:hover{
          color: #fff;
        }
      }
      .is-clear{
        border-style: dashed;
        color: #28354d;
        opacity: 0.7;
        background: transparent;
        &:focus,
        &:active,
        &:hover{
          background: transparent;
          color: #28354d;
        }
      }
      i{
        position: absolute;
        display: none;
        right: -7px;
        top: -7px;
        cursor: pointer;
        background: #fff;
        border:1px solid #ccc;
        border-radius: 10px;
        padding: 1px;
        transform:scale(0.9,0.9);
        // &::before{
        //   transform:scale(0.8)
        // }
        &:hover{
          background: #1989FA;
          color: #fff;
          border-color: #1989FA;
        }
      }
    }
  }
  .draw-tips{
    font-size: 12px;
    color: #939abc;
    width: 400px;
    left: -96px;
    top: -20px;
    line-height: 1.6;
    position: absolute;
    a{
      color: #4a00ff;
      text-decoration: underline;
    }
  }
</style>
