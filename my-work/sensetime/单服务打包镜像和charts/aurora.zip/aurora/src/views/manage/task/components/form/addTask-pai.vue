<template>
    <div v-if="visible" style="display:flex;flex-direction: column;align-items: center;">
        <el-form ref="form" :model="form" :rules="rules" label-position="right" :label-width="labelWidth">
            <el-form-item :label="$t('task.contTaskName')" prop="taskName">
                <el-input v-model="form.taskName" placeholder=""></el-input>
            </el-form-item>
            <el-form-item prop="defaultDevices" :label="$t('rule.labelDevice')">
                <TreeSelectRadio
                :data="treeData"
                @check="deviceSlected"
                @clear="clearTreeSelectRadio"
                :defaultChechedKeys="form.defaultDevices"
                />
            </el-form-item>

            <!--添加抓拍模式--start-->
            <el-form-item prop="snapStrategy" :label="$t('task.labelSnapStrategy')">
                <el-select
                @change="snapStrategyChange"
                v-model="form.snapStrategy"
                default-first-option>
                  <el-option :label="'定时模式'" :value="1"></el-option>
                  <el-option :label="'实时模式'" :value="0"></el-option>
                  <el-option :label="'精准模式'" :value="-1"></el-option>
                </el-select>
                <el-popover
                 class="right-tips"
                  placement="bottom-start"
                  width="400"
                  trigger="hover"
                  >
                  <div class="moudle-tips" v-html="$t('task.moudleTips')"></div>
                  <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
                </el-popover>
            </el-form-item>
            <el-form-item prop="quickresponsetime" v-if="form.snapStrategy>0" :label="$t('task.labelQuickresponsetime')">
              <el-input-number style="width:217px" v-model="form.quickresponsetime" :min="1" step-strictly :step="1" ></el-input-number>
              <span class="right-tips">{{$t("pedestrian.sec")}}</span>
            </el-form-item>
            <!--添加抓拍模式--end-->

            <el-form-item prop="time" :label="$t('task.contTimezone')">
                <el-select v-model="form.time" clearable>
                  <el-option
                    v-for="(timezone,timezoneIndex) in timezoneList"
                    :key="timezoneIndex"
                    :label="timezone.label"
                    :value="timezone.id">
                  </el-option>
                </el-select>
            </el-form-item>
            <el-form-item prop="specialAttribute" :label="$t('rule.contAttribute')">
                <el-select
                multiple
                collapse-tags
                v-model="form.specialAttribute"
                :placeholder="$t('rule.listAttributeNone')">
                <el-option
                    v-for="(item,itemIndex) in specialAttributeOptions"
                    :key="itemIndex"
                    :label="item.name"
                    :value="item.id">
                </el-option>
                </el-select>
            </el-form-item>
            <el-form-item prop="" :label="$t('task.contMinPersionSize')">
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneWidth')" :label-width="subLabelWidth">
                        <el-input @keydown.native="inputLimit" :disabled="!isLoadedVideo" v-model="miniNumber.width" :class="minwidthError?'form-number-error':''"  @input="(v)=>handleInputWidthSize(v,'min')" type="number" style="width:65px"></el-input>
                    </el-form-item>
                    <span class="tips-gray">{{$t('rule.contmini')}}({{miniLimit.width}})</span><br>
                    <el-button type="text" :disabled="!isLoadedVideo || minwidthError || minheightError" @click="showOnVideo('mini')">{{$t('task.contPreviewDraw')}}</el-button>
                </el-col>
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneHeight')" :label-width="subLabelWidth">
                        <el-input @keydown.native="inputLimit" :disabled="!isLoadedVideo" v-model="miniNumber.height" :class="minheightError?'form-number-error':''" @input="(v)=>handleInputHeightSize(v,'min')" type="number"  style="width:65px"></el-input>
                    </el-form-item>
                    <span class="tips-gray">{{$t('rule.contmini')}}({{miniLimit.height}})</span><br>
                    <el-button type="text" :disabled="!isLoadedVideo" @click="setDefault('mini')" :style="{'margin-left':language =='en'?'32px':'8px'}" >{{$tc('task.contResetDefault')}}</el-button>
                </el-col>
            </el-form-item>
            <el-form-item prop="" :label="$t('task.contMaxPersionSize')">
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneWidth')" :label-width="subLabelWidth">
                        <el-input @keydown.native="inputLimit" :disabled="!isLoadedVideo" v-model="maxNumber.width" :class="maxwidthError?'form-number-error':''" @input="(v)=>handleInputWidthSize(v,'max')" type="number" style="width:65px"></el-input>
                    </el-form-item>
                    <span class="tips-gray">{{$t('rule.contLimit')}}({{maxLimit.width}})</span><br>
                    <el-button type="text" :disabled="!isLoadedVideo || maxwidthError || maxheightError" @click="showOnVideo('max')">{{$t('task.contPreviewDraw')}}</el-button>
                </el-col>
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneHeight')" :label-width="subLabelWidth">
                        <el-input @keydown.native="inputLimit" :disabled="!isLoadedVideo" v-model="maxNumber.height" :class="maxheightError?'form-number-error':''" @input="(v)=>handleInputHeightSize(v,'max')" type="number"  style="width:65px"></el-input>
                    </el-form-item>
                    <span class="tips-gray">{{$t('rule.contLimit')}}({{maxLimit.height}})</span><br>
                    <el-button type="text" :disabled="!isLoadedVideo" @click="setDefault('max')" :style="{'margin-left':language =='en'?'32px':'8px'}" >{{$tc('task.contResetDefault')}}</el-button>
                </el-col>
            </el-form-item>
            <el-form-item prop="polygons" :label="$tc('task.contSetZone')">
                <span style="color:#ccc;">{{polygonsList.length>0?$tc('task.contAlreadyZone'):$tc('task.contYetZone')}}</span>
                <div style="font-size:12px;color:#ccc;width:220px;over-flow:hidden;line-height:16px;">（{{$tc('task.contSetZoneWarn')}}）</div>
            </el-form-item>
        </el-form>
        <div class="addTaskPC-btns" v-if="form.defaultDevices && form.defaultDevices[0]" >
            <div class="addTaskPC-btns-polygons">
                <div v-for="(polygon,polygonIndex) in polygonsList" :key="polygonIndex" class="addTaskPC-btns-btn"
                @mouseenter="(e)=>enterBtns(polygonIndex)" @mouseleave="(e)=>leaveBtns(polygonIndex)">
                    {{`${$tc('task.contZoneNum')}${polygonIndex+1}`}}
                    <div class="addTaskPC-btns-btn-delete" @click="(e)=>deletePolygon(polygonIndex)">
                        <div style="width:8px;height:2px;background-color:#fff;"></div>
                    </div>
                </div>
                <div @click="beginDrawLine" v-show="polygonsList.length < 4" >
                    <i class="iconfont icon-edit1" ></i>{{$tc('task.contClickSetZone')}}
                </div>
            </div>
            <div class="addTaskPC-btns-polygons">
                <div @click="restoreLine" v-show="polygonsList.length > 0">
                    <i class="iconfont icon-restore" ></i>{{$tc('task.contResetDefault')}}
                </div>
            </div>

        </div>
        <div class="addTaskPC-video" style="position:relative;width:532px;"  >
            <MediaPlayer v-if="form.defaultDevices && form.defaultDevices[0]" :showControl="false" type="1" name="test" :url="form.defaultDevices[0].videoPath" @loadedmetadata="initDrawer" />
            <DrawPolygons ref="drawPolygons"
                @end="handleDrwaEnd"
                :style="{position:'absolute',left:0,top:0}"
                :width="sketchpadWidth"
                :height="sketchpadHeight"
                @hidedrawmodel="()=>{this.drawModel = false}"
                :drawModel="drawModel"  />
        </div>

    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {getTimezoneWithIntervals,getDevicesTreeData,getSpecialAttrs} from '@/api/rule';
import {addPAITasks} from '@/api/task';
import TreeSelectRadio from "../treeSelectRadio.vue";
import i18n from '@/lang/index';
import MediaPlayer from '@/components/media-player/index.vue';
import DrawPolygons from '../drawPolygons.vue';
import {cloneDeep,trim} from 'lodash';
import {calculateClockDirection} from '@/utils/polygons.ts';
import { AppModule } from '@/store/modules/app';

const defaultMiniMax = {//default value
    miniLimit:{width:30,height:30},
    miniNumber:{width:30,height:30},
    maxNumber :{width:500,height:500},
    maxLimit  :{width:1920,height:1080}
};

const polygonLimitNum = 4;

@Component({
    components: {
        TreeSelectRadio,
        MediaPlayer,
        DrawPolygons
    },
})
export default class AddTaskPAI extends Vue {
    /* props */
    @Prop({default:false}) visible!: boolean;
    @Prop({required:true}) labelWidth!: string;

    /* watch */
    @Watch('visible',{ immediate: true})
    onVisibleChange(n,o){
        n && this.initData();
    }
    get language() {
        return AppModule.language;
    }

    get subLabelWidth(){
        return AppModule.language === 'en'?'48px':'20px';
    }
    /* data */
    $refs !:{
        drawPolygons,
        form:HTMLFormElement
    }
    form:{
        taskName:string;
        defaultDevices:any[],
        time:any,
        specialAttribute:any[],
        polygons:any[],
        quickresponsetime:number,
        snapStrategy:number,
    }={
        taskName:'',
        defaultDevices:[],
        time:'',
        specialAttribute:[],
        polygons:[],
        quickresponsetime:4,
        snapStrategy:1
    };
    rules={
        taskName:[
            { required: true,validator:this.validateTaskName, trigger: 'blur' },
        ],
        defaultDevices:[
            { required: true, message: i18n.tc('form.texterrSelectDevice')},
        ],
        time:[
            { required: false},
        ],
        specialAttribute:[
            { required: false},
        ],
        polygons:[
            { required: true,message: i18n.tc('task.formSetZone')},
        ],
        quickresponsetime:[
            { required: true,message: i18n.t('form.texterrQuickresponsetime') },
        ],
        snapStrategy:[
            { required: true,message: '' },
        ],
    };
    treeData:any[]=[];
    timezoneList:any[]=[];
    specialAttributeOptions:any[]=[];
    miniLimit:any={width:defaultMiniMax.miniLimit.width,height:defaultMiniMax.miniLimit.height};
    miniNumber:any={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
    maxNumber:any={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
    maxLimit:any={width:defaultMiniMax.maxLimit.width,height:defaultMiniMax.maxLimit.height};
    videoUrl:string='';
    sketchpadWidth:number=0;
    sketchpadHeight:number=this.sketchpadWidth*1080/1920;
    scale:any={x:1,y:1};
    drawModel:boolean=false;
    polygonsList:any[]=[];

    minwidthError:boolean=false;
    maxwidthError:boolean=false;
    minheightError:boolean=false;
    maxheightError:boolean=false;
    isLoadedVideo:boolean=false;
    /* methods */
    mounted(){

    }
    //validate
    validateTaskName(rule, value, callback){
        let str = value;
        if (str === '') {
        callback(new Error(i18n.tc('task.texterrEnterTaskName')));
        } else {
            //去除两头空格:
            let regx = /^\s+|\s+$/g;
            while (regx.test(str)) {
                str   =  trim(str);
            };
            str   =  trim(str);
            if(str && str.length<=40){
                callback();
            }else{
                callback(new Error(i18n.tc('task.texterrEnterTaskName')));
            }
        }
    }
    initDefaultMiniMax(){
      this.miniLimit={width:defaultMiniMax.miniLimit.width,height:defaultMiniMax.miniLimit.height};
      this.miniNumber={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
      this.maxNumber={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
      this.maxLimit={width:defaultMiniMax.maxLimit.width,height:defaultMiniMax.maxLimit.height};
    }
    initData(){
        this.treeData=[];
        this.timezoneList=[];
        this.specialAttributeOptions=[];
        this.initDefaultMiniMax();
        this.videoUrl='';
        this.sketchpadWidth=0;
        this.sketchpadHeight=this.sketchpadWidth*1080/1920;
        this.scale={x:1,y:1};
        this.drawModel = false;
        //init form
        this.form={
            taskName:'',
            defaultDevices:[],
            time:'',
            specialAttribute:[],
            polygons:[],
            quickresponsetime:4,
            snapStrategy:1
        };
        this.polygonsList = [];
        this.isLoadedVideo = false;
        //get data
        this.getDevices();
        this.getTimezoneList();
        this.getSpecialAttrs();
        setTimeout(()=>{
            this.$refs.form && this.$refs.form.clearValidate();
        },60);
        this.minwidthError=false;
        this.maxwidthError=false;
        this.minheightError=false;
        this.maxheightError=false;

    }
    snapStrategyChange(v){
        v <= 0 && (this.form.quickresponsetime = v);
    }
    deviceSlected(v){
      this.isLoadedVideo = false;
        v && (this.form.defaultDevices = v);
    }
    clearTreeSelectRadio(){
        this.form.defaultDevices =  [];
    }
    getDevices(){
        let deviceType = 14;
        let filter = 0;
        getDevicesTreeData({deviceType,filter}).then(res=>{
            res && res.data && (this.treeData = res.data);
        })
    }
    getTimezoneList(){
        this.timezoneList = [];
        getTimezoneWithIntervals().then((res:any)=>{
            res && this.formatTimezoneList(res.data);
        })
    }
    formatTimezoneList(timezoneList){
        timezoneList && timezoneList.map((item,itemIndex)=>{
            this.timezoneList.push({
                id:item.timeZoneId,
                label:item.timeZoneName
            })
        })
    }
    getSpecialAttrs(){
        getSpecialAttrs(3).then((res:any)=>{
        res && res.list.map(item=>{
            this.specialAttributeOptions.push({
            id:item.taskAttributeId,
            name:this.$tc(`rule.${item.taskAttributeName}`),
            disabled:false
            })
        })
        })
    }
    inputLimit(e){
      let key = e.key;
      if (key === 'e' || key === '.') {
        e.returnValue = false
        return false
      }
      return true
    }
    handleInputWidthSize(v,type){
        let val = parseInt(v);
        if(type === 'min'){
          this.miniNumber.width = val
            if(val >= defaultMiniMax.miniLimit.width && val <= this.maxNumber.width && val<=defaultMiniMax.maxLimit.width){
                this.minwidthError = false;
                //this.maxwidthError = false;
            }else{
                this.minwidthError = true;
            }
            if(this.maxNumber.width >= defaultMiniMax.miniLimit.width && this.maxNumber.width >= val && this.maxNumber.width<=defaultMiniMax.maxLimit.width){
                //this.minwidthError = false;
                this.maxwidthError = false;
            }else{
                this.maxwidthError = true;
            }
        }
        if(type === 'max'){
          this.maxNumber.width = val
            if(val >= defaultMiniMax.miniLimit.width && val >= this.miniNumber.width && val<=defaultMiniMax.maxLimit.width){
                this.maxwidthError = false;
            }else{
                this.maxwidthError = true;
            }

            if(this.miniNumber.width >= defaultMiniMax.miniLimit.width && val >= this.miniNumber.width && this.miniNumber.width<=defaultMiniMax.maxLimit.width){
                this.minwidthError = false;
            }else{
                this.minwidthError = true;
            }
        }
    }
    handleInputHeightSize(v,type){
        let val = parseInt(v);
        if(type === 'min'){
          this.miniNumber.height = val
            if(val >= defaultMiniMax.miniLimit.height && val <= this.maxNumber.height && val<=defaultMiniMax.maxLimit.height){
                this.minheightError = false;
                //this.maxheightError = false;
            }else{
                this.minheightError = true;
            }
            if(this.maxNumber.height >= defaultMiniMax.miniLimit.height && this.maxNumber.height >= val && this.maxNumber.height<=defaultMiniMax.maxLimit.height){
                //this.minwidthError = false;
                this.maxheightError = false;
            }else{
                this.maxheightError = true;
            }
        }
        if(type === 'max'){
          this.maxNumber.height = val
            if(val >= defaultMiniMax.miniLimit.height && val >= this.miniNumber.height && val<=defaultMiniMax.maxLimit.height){
                //this.minheightError = false;
                this.maxheightError = false;
            }else{
                this.maxheightError = true;
            }

            if(this.miniNumber.height >= defaultMiniMax.miniLimit.height && val >= this.miniNumber.height && this.miniNumber.height<=defaultMiniMax.maxLimit.height){
                //this.minwidthError = false;
                this.minheightError = false;
            }else{
                this.minheightError = true;
            }
        }
    }
    initDrawer(video){
        let origin_w = video.target.videoWidth,origin_h = video.target.videoHeight;
        let client_w = video.target.clientWidth,client_h = video.target.clientHeight;
        //set canvas
        this.sketchpadWidth  = client_w;
        this.sketchpadHeight = client_h;
        //set scale
        this.scale.x = client_w/origin_w;
        this.scale.y = client_h/origin_h;
        this.isLoadedVideo = true;
    }
    showOnVideo(type){
        this.$refs.drawPolygons.clearCanvas();
        this.drawModel = false;
        type == 'mini' && this.$refs.drawPolygons.drawRectangle(this.centerCoordinate(this.miniNumber));
        type == 'max' && this.$refs.drawPolygons.drawRectangle(this.centerCoordinate(this.maxNumber));
    }
    setDefault(type){
      if(type == 'mini'){
        this.minwidthError=false;
        this.minheightError=false;
        this.miniNumber={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height}
      }
      if(type == 'max'){
        this.maxwidthError=false;
        this.maxheightError=false;
        this.maxNumber={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height}
      }
      this.showOnVideo(type);
    }
    centerCoordinate(size){
        let size_copy = cloneDeep(size);
        size_copy.width  = size_copy.width*this.scale.x;
        size_copy.height = size_copy.height*this.scale.y;
        let centerCoordinate = {x:this.sketchpadWidth/2,y:this.sketchpadHeight/2};
        let start = {x:centerCoordinate.x-(size_copy.width/2),y:centerCoordinate.y-(size_copy.height/2)};
        let end   = {x:centerCoordinate.x+(size_copy.width/2),y:centerCoordinate.y+(size_copy.height/2)};
        return [start,end];
    }
    beginDrawLine(){
        if(this.$refs.drawPolygons){
            this.$refs.drawPolygons.clearCanvas();
            this.$refs.drawPolygons.drawAllPolygons();
        }
        if(this.polygonsList.length <  polygonLimitNum) this.drawModel = true;
    }
    restoreLine(){
        this.$refs.drawPolygons.clearAll();
        this.polygonsList = [];
        this.form.polygons = [];
        this.drawModel = false;
        this.$refs.form.validateField('polygons')
    }
    handleDrwaEnd(data){
        this.drawModel = false;
        let arr:any[] = [];
        data && data.length>0 && data.map(poly=>{
            arr.push(this.setScaleForCoordinate(poly.points));
        });
        this.polygonsList = arr;
        this.form.polygons = arr;
        this.$refs.form.validateField('polygons')
    }
    setScaleForCoordinate(list){
        let arr = [], _w = this.sketchpadWidth, _h = this.sketchpadHeight;
        if(_w > 0 && _h > 0 && list && list.length > 0){
            arr = list.map(item =>{
                let x = item.x/_w , y = item.y/_h;
                return {x,y}
            })
        }
        return arr.length>0?arr:list;
    }
    getOriginScaleForCoordinate(list){
        let arr = [], _w = this.sketchpadWidth, _h = this.sketchpadHeight;
        if(_w > 0 && _h > 0 && list && list.length > 0){
            arr = list.map(item =>{
                let x = item.x*_w , y = item.y*_h;
                return {x,y}
            })
        }
        return arr.length>0?arr:list;
    }
    enterBtns(polygonIndex){
        // this.$refs.drawPolygons.showCurrentPolygon(polygonIndex)
        if(this.$refs.drawPolygons && this.$refs.drawPolygons.polygons
        && this.$refs.drawPolygons.polygons[polygonIndex]
        && this.$refs.drawPolygons.polygons[polygonIndex].points
        && this.$refs.drawPolygons.polygons[polygonIndex].points.length>0){
            this.$refs.drawPolygons.showCurrentPolygon(polygonIndex)
        }else if(this.$refs.drawPolygons){
            this.$refs.drawPolygons.clearAll();
            //set default
            if(this.polygonsList.length>0){
                let arr:any[]=[];
                arr = this.polygonsList.map(polygon=>{
                    return this.getOriginScaleForCoordinate(polygon);
                });
                this.$nextTick(()=>{
                    arr && arr.length>0 && this.$refs.drawPolygons.drawPolygonsMethod(arr);
                })

            }
        }
    }
    leaveBtns(polygonIndex){
        this.$refs.drawPolygons.hideCurrentPolygon(polygonIndex)
    }
    deletePolygon(polygonIndex){
        this.polygonsList.splice(polygonIndex,1);
        this.form.polygons = this.polygonsList;
        this.$refs.drawPolygons.deletePolygon(polygonIndex);
        this.$refs.form.validateField('polygons')
    }
    submitData(startcal,successcal,errorcal){
        let data = {
            "deviceId": this.form.defaultDevices.length>0?this.form.defaultDevices[0].id:'',
            "direction": {
                "x": 0,
                "y": 0
            },
            "taskAttributeIds": this.form.specialAttribute,
            "taskName": this.form.taskName,
            "taskType": 2,//行人区域入侵
            "timeZoneId": this.form.time,
            "vertices": {
                "maxTarget": {
                    "height": this.maxNumber.height,
                    "width": this.maxNumber.width
                },
                "minTarget": {
                    "height": this.miniNumber.height,
                    "width": this.miniNumber.width
                },
                "pointVoList": this.polygonsList,
            },
            "quickResponseTime":this.form.quickresponsetime
        };
        if(data.vertices.pointVoList.length>0){
            data.vertices.pointVoList.map(arr=>{
                if(!calculateClockDirection(arr)) arr.reverse();
            })
        }
        this.$refs.form.validate((isvalidate)=>{
          if(!this.minwidthError && !this.minheightError && !this.maxwidthError && !this.maxheightError){
            isvalidate && startcal && startcal();
            isvalidate && addPAITasks(data).then(res=>{
                successcal && successcal(res);
            }).catch(err=>{
                errorcal && errorcal(err)
            })
          }

        })

    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.tables-container{
    .task-list-operation-item{
        cursor: pointer;
        margin-right: 8px;
        i.iconfont{
            font-size:19px;
        }
    }
}
::v-deep .el-select__tags .el-tag--info {
    color: #28354d;
}

.el-input{
    ::v-deep input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }
}
.addTaskPC-linkbtn{
    display: inline-block;
    color: #2A5AF5;
    cursor: pointer;
    text-decoration: underline ;
}
.addTaskPC-video{
    position: relative;
    width: 532px;
}
.addTaskPC-btns{
    display: flex;
    justify-content: space-between;
    width: 532px;
    padding-bottom: 8px;
    &>div{
        cursor: pointer;
        &:active{
            color: #2A5AF5;
        }
    }
}
.addTaskPC-btns-btn{
    padding: 8px 16px;
    border:1px solid #7E7E9A;
    border-radius: 4px;
    margin-right: 16px;
    position: relative;
    &:hover{
        background-color: #1989FA;
        color: white;
        .addTaskPC-btns-btn-delete{
            display: flex;
        }
    }
    .addTaskPC-btns-btn-delete{
        display: none;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background-color: #ED3A33;
        cursor: pointer;
        position: absolute;
        top: -8px;
        right: -8px;
        justify-content: center;
        align-items: center;
    }
}
.addTaskPC-btns-polygons{
    display: flex;
    justify-content: flex-start;
    align-items: center;
}
::v-deep .el-select{
  width: 100%;
}
::v-deep .el-input.form-number-error .el-input__inner{
    border-color: #db4436;
}
</style>
