<template>
  <el-dialog
  :title="$t('rolemanagement.titleReminder')"
  :visible.sync="visible"
  width="30%"
  :center="true"
  :before-close="handleClose">
  <!-- title -->
  <p slot="title" style="text-align:left" >{{$t('rule.titleAcRulesetCreate')}}</p>
  <!-- content -->
    <el-form ref="form" :model="form" :rules="rules" label-position="left" :label-width="language == 'en'?'125px':'115px'">
      <br />
      <el-form-item prop="ruleGroupName" :label="$t('rule.contRulesetName')">
        <el-input v-model="form.ruleGroupName" ></el-input>
      </el-form-item>
      <el-form-item prop="defaultChechedKeys" :label="$t('rule.labelDevice')">
        <!-- <TreeSelect
          :defaultChechedKeys="form.defaultChechedKeys"
          type="border"
          @selected="deviceSlected"
          :multiple="false"
          inputWidth="100%"
          :data="treeData"
          show-checkbox  /> -->
        <TreeSelectRadio
          :data="treeData"
          @check="deviceSlected"
          :defaultChechedKeys="form.defaultChechedKeys"
          />
      </el-form-item>
      <el-form-item prop="specialAttribute" :label="$t('rule.contAttribute')">
        <el-select
          v-model="form.specialAttribute"
          default-first-option
          multiple
          collapse-tags
          :placeholder="$t('rule.listAttributeNone')">
          <el-option
            v-for="item in specialAttributeOptions"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="threshold" :label="$t('rule.contThreshold')">
        <el-select
          class="add-rule-ac-threshold"
          v-model="form.threshold"
          filterable
          allow-create
          default-first-option
          :placeholder="$t('form.texterrEnterThreshold')">
          <el-option
            v-for="(item,itemIndex) in thresholdOptions"
            :key="itemIndex"
            :label="Number(item*100).toFixed(1)"
            :value="item">
          </el-option>
        </el-select> %
      </el-form-item>
    </el-form>
    <div class="sapce-border" ></div>
    <div class="add-rule-ac-timeAndLibs" style="width:100%;" v-if="selectedKeeper">
      <div v-if="selectedKeeper && selectedKeeper.deviceType != 6">
        <header class="add-rule-ac-libsheader-time">{{$t('rule.labelTimezoneList')}}</header>
        <div class="add-rule-ac-timeAndLibs-scrollbox add-rule-ac-timeAndLibs-scrollbox-times" >
          <el-tree
            :data="timezoneList"
            ref="timezoneList"
            node-key="id"
            show-checkbox
            @check-change="handleTimezoneListCheckChange"
            @node-click="timezoneListNodeClick" ></el-tree>
        </div>
      </div>
      <div :class="selectedKeeper && selectedKeeper.deviceType == 6 ?'':'add-rule-ac-box-right'" >
        <header class="add-rule-ac-libsheader">{{$t('rule.labelImageLibraryList')}}</header>
        <div  class="add-rule-ac-timeAndLibs-scrollbox add-rule-ac-timeAndLibs-scrollbox-libs">
          <el-tree :data="libsList"
            ref="libsList"
            node-key="id"
            :props="{disabled:setLiblistDisabled}"
            show-checkbox
            default-expand-all
            @check-change="handleLibsListCheckChange" ></el-tree>
        </div>

      </div>
    </div>

    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="submitData" :loading="loading">{{$t('rule.buttonOK')}}</el-button>
      <el-button @click="hide" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>
</template>

<script lang="ts">
import { Component, Vue , Watch, Prop} from 'vue-property-decorator';
import TreeSelect from '@/components/tree-select/index.vue';
import {getTimezone,getTimezoneWithIntervals,addACRule,getSpecialAttrs,getDevices,getDevicesTreeData,getLibsList} from '@/api/rule';
const defaultAcThreshold = window.globalConfig.acThreshold;
import {ruleThresholdOptions} from '@/utils/constants';
import {EventBus} from '@/utils/eventbus';
import {trim} from 'lodash';
import i18n from '@/lang/index';
import TreeSelectRadio from "../../components/treeSelectRadio.vue";
import {deviceType} from '@/utils/constants';
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    TreeSelect,
    TreeSelectRadio
  },
})
export default class AddRuleAC extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;


  /* watch */
  @Watch('visible', { immediate: true, deep: true })
  onVisibleChange(n,o){
    n && this.initRuleData();
  }
  // @Watch('defaultChechedKeys', { immediate: false, deep: true })
  // onDefaultChechedKeysChange(n,o){
  //   this.form.device = n;
  //   this.$refs.form && this.$refs.form.validateField('device');
  // }
  get language() {
    return AppModule.language;
  }
  /* data */
  loading:boolean=false;
  $refs!:{
    timezoneList:HTMLFormElement,
    libsList:HTMLFormElement,
    form:HTMLFormElement
  }
  labelWidth:string='115px';
  selectedKeeper:any=null;
  // defaultChechedKeys:any[]=[];
  form:{
    ruleGroupName:string;
    defaultChechedKeys:any[],
    specialAttribute:any[],
    threshold:any;
  }={
    ruleGroupName:"",
    defaultChechedKeys:[],
    specialAttribute:[],
    threshold:defaultAcThreshold
  };
  validateGroupName=(rule, value, callback) => {
    let str = value;
    if (str === '') {
      callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
    } else {
      //去除两头空格:
      let regx = /^\s+|\s+$/g;
      while (regx.test(str)) {
        str   =  trim(str);
      };
      str   =  trim(str);
      if(str){
        callback();
      }else{
        callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
      }
    }
  };
  rules={
    ruleGroupName:[
      { required: true, validator: this.validateGroupName, trigger: 'blur' },
      // { min: 1, max: 40, message: '长度在 1 到 40 个字符', trigger: 'blur' }
    ],
    specialAttribute:[
      { required: false },
    ],
    defaultChechedKeys:[
      { required: true, message: i18n.t('form.texterrSelectDevice')+""},
    ],
    threshold:[
      { required: true, message: i18n.t('form.texterrEnterThreshold')+"", trigger: 'change' },
    ],
  };
  timezoneLibraryRelation:any[]=[];
  timeCheckListModel:any[]=[];
  libsCheckListModel:any[]=[];
  timezoneList:any[]=[];
  currentTimezoneIndex:number=0;
  treeData:any[] = [];
  libsList:any[]=[{id:0,label:"",children:[]}];
  props:any=this.$props;
  thresholdOptions = ruleThresholdOptions;
  specialAttributeOptions:any[]=[];



  /* methods */
  initRuleData(){
    // this.$refs.form && this.$refs.form.clearValidate();
    this.form.ruleGroupName = '';
    this.form.specialAttribute = [];
    this.selectedKeeper = null;
    // this.form.device = [];
    this.form.defaultChechedKeys = [];
    this.form.threshold =defaultAcThreshold;
    this.timezoneLibraryRelation=[];
    this.timeCheckListModel=[];
    this.libsCheckListModel=[];
    this.timezoneList=[];
    this.currentTimezoneIndex = 0;
    this.specialAttributeOptions = [];
    this.libsList=[{id:0,label:this.$tc('rule.contWhitelist'),children:[]}];
    this.$refs.libsList && this.$refs.libsList.setCheckedKeys([]);
    this.getTimezoneList();
    this.getLibsList();
    this.getAttrs();
    this.getDevicesKeeperWithoutRule();
    setTimeout(()=>{
      this.$refs.form && this.$refs.form.clearValidate();
    },60)
  }
  getAttrs(){
    getSpecialAttrs(0).then((res:any)=>{
      res && res.list.map(item=>{
        this.specialAttributeOptions.push({
          id:item.taskAttributeId,
          name:this.$tc(`rule.${item.taskAttributeName}`)
        })
      })
    })
  }
  getTimezoneList(){
    this.timezoneList = [];
    getTimezoneWithIntervals().then((res:any)=>{
      res && this.formatTimezoneList(res.data);
    })
  }
  //libslist
  getLibsList(keywords?){
    getLibsList(keywords).then(res=>{
      this.libsList=[];
      res && this.formatLibs(res);
    })
  }
  formatLibs(res){
    this.libsList = [{id:-1,label:this.$tc('rule.contWhitelist'),children:[]}];
    res.whitelists && res.whitelists.map((item:any)=>{
      if(this.selectedKeeper){
        if(this.selectedKeeper.deviceType == 6){//前端比对设备对应人像库
          this.libsList[0].children.push({
            id:item.libraryId,
            label:item.libraryName
          });
        }else if(this.selectedKeeper.deviceType != 6){//非前端比对设备对应人像库
          this.libsList[0].children.push({
            id:item.libraryId,
            label:item.libraryName
          });
        }
        // this.libsList[0].children.push({
        //   id:item.libraryId,
        //   label:item.libraryName
        // });
      }
    });
  }
  setLiblistDisabled(data, node){
    return data.id == -1 && data.children.length == 0 ;
  }
  getDevicesKeeperWithoutRule(){
    //get keeper not used
    getDevicesTreeData({deviceType:20,filter:1}).then(res=>{
      this.treeData = [];
      this.formatTreeData(res.data);
    })
  }
  formatTreeData(data){
    this.treeData = data;
  }
  formatTimezoneList(timezoneList){
    timezoneList && timezoneList.map((item,itemIndex)=>{
      this.timezoneList.push({
        id:item.timeZoneId,
        label:item.timeZoneName
      })
    })
  }
  hide(){
    this.$emit('hideAddRuleacDialog')
  }
  handleClose(){
    this.hide();
  }
  handleLibsListCheckChange(data, checked, indeterminate){
    if(this.timezoneLibraryRelation[this.currentTimezoneIndex]){
      let currentLibsIds = this.timezoneLibraryRelation[this.currentTimezoneIndex]['libraryIds'];
      let index = currentLibsIds.findIndex(item=>item == data.id);
      if(checked && index<0 && data.id>0){
        currentLibsIds.push(data.id)
      }
      if(!checked && index>=0){
        currentLibsIds.splice(index,1);
      }
    }
  }
  handleTimezoneListCheckChange(data, checked, indeterminate){
    this.$refs.timezoneList.setCurrentKey(data.id)
    let currentIndex = this.timezoneLibraryRelation.findIndex(item => item.timezoneId == data.id );
    if(checked && currentIndex < 0 ){
      this.timezoneLibraryRelation.push({
        timezoneId:data.id,
        libraryIds:[]
      });
      this.timezoneListNodeClick(data);
    }
    if(!checked && currentIndex>=0){
      this.timezoneLibraryRelation.splice(currentIndex,1);
      this.timezoneListNodeClick(data);
    }

  }
  timezoneListNodeClick(data){
    let currentIndex = this.timezoneLibraryRelation.findIndex(item => item.timezoneId == data.id );
    this.currentTimezoneIndex = currentIndex;
    if(currentIndex >= 0){
      let libraryIds = this.timezoneLibraryRelation[currentIndex].libraryIds;
      this.$refs.libsList.setCheckedKeys(libraryIds);
    }else{
      this.$refs.libsList.setCheckedKeys([]);
    }
  }
  deviceSlected(data){
    if(data.length>0){
      this.selectedKeeper = data[0];
      this.form.defaultChechedKeys[0] && this.form.defaultChechedKeys.shift();
      this.form.defaultChechedKeys.push(data[0]['id']);
      this.selectedKeeper.id && this.getLibsList();////暂时屏蔽前端比对
    }
  }
  formatSubmitData(){
    let data = {
      "deviceId": this.selectedKeeper ?this.selectedKeeper.id:null,
      "taskAttributeIds": this.form.specialAttribute,
      "taskGroup": {"taskGroupName":  this.form.ruleGroupName},
      "taskType": 0,//ac->0  td->1
      "threshold": this.form.threshold,
      "timezoneLibraryRelation":this.timezoneLibraryRelation || [],
      "passLibraryIds":this.$refs.libsList.getCheckedKeys(true)
    };
    if(data.threshold>0 && data.threshold<100 && !this.thresholdOptions.some((item)=> data.threshold == item)){
      data.threshold = (data.threshold*1000)/100000 ;
    }
    return data;
  }
  submitData(){
    let data = this.formatSubmitData();
    //name min:1 max:40 get40
    if(trim(data.taskGroup.taskGroupName).length>40){
      data.taskGroup.taskGroupName = trim(data.taskGroup.taskGroupName).substr(0,40);
    };
    this.$refs.form.validate(valid=>{
      if(valid  ){
        if(this.selectedKeeper.deviceType == 6){
          if(data.passLibraryIds && data.passLibraryIds.length>0){
            this.loading = true;
            addACRule(data).then(res=>{
              EventBus.$emit('rule-refresh-group-ac');
              this.$emit('addsuccess',true)
              this.hide();
            }).finally( ()=>{
              this.loading = false;
            })
          }else{
            this.$message.error(this.$tc('form.texterrSelectImageLib'));
          }
        }else if(this.validateTimezoneLibraryRelation(data.timezoneLibraryRelation) ){
          this.loading = true;
          addACRule(data).then(res=>{
            // this.$message({
            //   message: '创建规则成功',
            //   type: 'success'
            // });
            EventBus.$emit('rule-refresh-group-ac');
            this.$emit('addsuccess',true)
            this.hide();
          }).finally( ()=>{
            this.loading = false;
          })
        }else{
          this.$message.error(this.$tc('rule.errmsgSelectTimeLib') as string);
        }

      }else{
        return false;
      }
    })
  }
  validateTimezoneLibraryRelation(timezoneLibraryRelation){
    if(timezoneLibraryRelation.length == 0){
      return false;
    }else{
      let isLibIds = timezoneLibraryRelation.some((item:any)=>{
        return item.libraryIds && item.libraryIds.length >0;
      });
      return isLibIds?true:false;
    }
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .add-rule-ac-threshold{
    width: 120px;
  }
  .add-rule-ac-timeAndLibs{
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    &>div{
      width: 50%;
    }
    .add-rule-ac-libsheader{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;
    }
    .add-rule-ac-libsheader-time{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;
    }
    .add-rule-ac-timeAndLibs-scrollbox{
      width: 100%;
      max-height: 225px;
      overflow: auto;
    }

  }
  .add-rule-ac-box-right{
    border-left:1px solid $--border-color-base;
  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
  // ::v-deep .el-form{
  //     max-width: 330px;
  //     margin: 0 auto;
  //   }
  .add-rule-ac-keepertreeinput{
    width: 100%;
  }
::v-deep .add-rule-ac-timeAndLibs-scrollbox-times .el-tree .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .add-rule-ac-timeAndLibs-scrollbox-times .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .add-rule-ac-timeAndLibs-scrollbox-libs .el-tree .el-tree-node .el-tree-node__children .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .add-rule-ac-timeAndLibs-scrollbox-libs .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }

// ::v-deep .el-form-item.is-required:not(.is-no-asterisk)>.el-form-item__label{
//     position: relative;
//     &:before {
//       position: absolute;
//       left: -8px;
//     }
//   }
  ::v-deep .el-form-item__content .el-select .el-select__tags .el-select__tags-text{
    color:#28354d;
  }
</style>
