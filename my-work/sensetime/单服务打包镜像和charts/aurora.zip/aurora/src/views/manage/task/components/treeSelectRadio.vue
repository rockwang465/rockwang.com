<template>
  <div class="treeselsectradio-container">
    <el-popover
      ref="treeselsectradio-popover"
      placement="bottom"
      trigger="click"
      v-model="visible">
        <div slot="reference"  class="treeselsectradio-selected" >
          <el-input type="text" :placeholder="$t('rule.contPleaseSelect')" 
            ref="input"  
            v-model="inputText" 
            @clear="inputClear"
            @focus="inputFocus" :clearable="isClearable"/>
        </div>
        <div class="treeselsectradio-content">
          <el-input
            :placeholder="$t('liveservice.contDeviceSearch')"
            v-model="filterText">
          </el-input>
          <div >
            <el-tree
              :data="data"
              node-key="id"
              ref="tree"
              class="treeselsectradio-tree"
              :filter-node-method="filterNode"
              default-expand-all
              :render-content="renderContent"
              >
            </el-tree>
          </div>
        </div>
    </el-popover>
  </div>
</template>

<script lang="tsx">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import { setTimeout } from 'timers';

@Component({
  components: {

  },
})
export default class TreeSelectRadio extends Vue {

  /* props */
  @Prop(Array) data!: any[];
  @Prop({default: [] }) defaultChechedKeys!: any[];//默认选中

  /* watch */
  @Watch('visible', { immediate: false, deep: false })
  onVisibleChanged(val: boolean, oldVal: boolean) {

  }
  @Watch('filterText', { immediate: false, deep: false })
  onfilterTextChanged(val: string, oldVal: string) {
    this.$refs.tree.filter(val);
  }
  @Watch('radioModel', { immediate: false, deep: false })
  onradioModelChanged(val: any, oldVal: any) {
    this.isClearable = Object.keys(val).length>0;
    this.radioChange(val);
  }
  @Watch('defaultChechedKeys', { immediate: false, deep: false })
  ondefaultChechedKeysChanged(val: any[], oldVal: any[]) {
    if(val.length>0 && val[0]){
      let id = val[0];
      let data = this.$refs.tree.getNode(id).data;
      this.radioModel = data;
    }else{
      this.radioModel = {};
    }
  }
  /* data */
  $refs!: {
    tree: HTMLFormElement,
    input:HTMLFormElement
  };
  visible:boolean=false;
  inputText:string="";
  filterText:string="";
  clearTimer:any=null;
  isClearable:boolean=false;

  radioModel:any={};
  /* methods */
  mounted() {
    this.radioModel={};
  }
  filterNode(value, data) {
    if (!value) return true;
    return data.name.indexOf(value) !== -1;
  }
  renderContent(h,{node,data,store}){
    node.isLeaf = data.type == 1;
    return  data.type == 1?<el-radio v-model={this.radioModel} label={data} ><span title={data.name}>{data.name}</span></el-radio>
                          :<span title={data.name}>{data.name}</span>
  }
  radioChange(currentLabel){
    if(currentLabel && currentLabel.id){
      this.$emit('check',[currentLabel]);
      this.inputText = currentLabel.name;
      this.visible=false;
    }else{
      this.inputText = this.$tc('rule.contPleaseSelect');
    }
  }
  inputFocus(){
    this.$refs.input.blur();
  }
  inputClear(){
    this.$emit('clear')
    this.radioModel = {};
    if(this.clearTimer) window.clearTimeout(this.clearTimer);
    this.clearTimer = null;
    this.clearTimer = setTimeout(()=>{
      this.visible=false;
    },50)
    
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .treeselsectradio-container{
    display: inline-block;
    position: relative;
    background-color: #fff;
    width: 100%;
  }
  .treeselsectradio-selected{
    // padding: 5px 0;
    position: relative;

    // .treeselsectradio-selected-icon{
    //   background-color: rgba(162, 176, 199, 0.48);
    //   cursor: pointer;
    //   color: #28354d;
    //   padding: 5px 0 6px;
    // }

    // .treeselsectradio-selected-icon-border{
    //   background-color: rgba(162, 176, 199, 0.48);
    //   cursor: pointer;
    //   color: #28354d;
    //   padding: 12px 0 13px;
    //   position: relative;
    //   left: -15px;
    // }
    // .treeselsectradio-selected-text{
    //   border:1px solid #c2cad8;
    //   padding: 5px 0;
    // }
    // .treeselsectradio-selected-text:focus{
    //   border-color:#2a5af5;
    // }
  }
  .treeselsectradio-content{
    .treeselsectradio-btns{
      width: 100%;
      text-align: right;
    }
    .treeselsectradio-tree{
      max-width:300px;
      min-height: 200px;
      max-height: 300px;
      overflow: auto;
    }

  }
  // ::v-deep .el-tree.treeselsectradio-tree{
  //   overflow:auto;
  // }

</style>
