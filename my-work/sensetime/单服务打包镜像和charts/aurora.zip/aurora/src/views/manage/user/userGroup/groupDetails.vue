<template>
  <div>
    <el-dialog class="details"
               :title="$t('usermanagement.titleDetail')"
               :visible.sync="dialogShowVisible"
               width="30%">
      <div class="content">
        <div class="left">
          <!--分组名称-->
          <span>{{$t('usermanagement.contGroupName')}}</span>
          <!--创建时间-->
          <span>{{$t('usermanagement.contTimeCreation')}}</span>
          <!--创建者-->
          <span>{{$t('usermanagement.contCreator')}}</span>
        </div>
        <div class="right">
          <el-tooltip v-if="dataObj.name&&dataObj.name.length>10" class="item" effect="dark" :content="dataObj.name" placement="top">
            <span class="type-name">{{dataObj.name}}</span>
          </el-tooltip>
          <span v-else>{{dataObj.name}}</span>
          <span>{{dataObj.createTime}}</span>
          <span>{{dataObj.createUserName}}</span>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogShowVisible = false">{{$t('usermanagement.buttonOK')}}</el-button>
      <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';

  @Component({

  })
  export default class GroupDetails extends Vue {
    @Prop(Object) dataObj!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    dialogShowVisible = false;

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }
    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeGroupDetails")
      }
    }


  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .content{
    width: 80%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  .content .left span{
    padding-left: 40%;
    font-weight: 600;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  .content .right>span{
    display: block;
    width: 80%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
