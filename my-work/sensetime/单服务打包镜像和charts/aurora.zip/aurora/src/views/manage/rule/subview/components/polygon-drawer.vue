<template>
  <div 
    :class="['draw-polygon-container',drawingRect || drawingPolygon ? 'is-drawing' : '']"
    ref="container"
    :style="{
      width: string=this.width?`${this.width}px`:'100%',
      height: this.height?`${this.height}px`:'100%'
    }">
    <MediaPlayer v-if="videoUrl" :showControl="false" type="1" name="test" :url="videoUrl" @loadedmetadata="initDrawer" />
    <canvas
      ref="canvas"
      class="draw-polygon-container__canvas"
      :style="{
        top: `${canvasStyle.top}px`,
        left: `${canvasStyle.left}px`
      }"
      :width="canvasStyle.width"
      :height="canvasStyle.height"
      @click="handleCanvasClick"
      @mousedown="handleCanvasMouseDown"
      @mousemove="(e)=>myDebounce(e)"
      @mouseup="handleCanvasMouseUp"
    />
    <div
      v-if="$slots.buttons && showButtons"
      class="draw-polygon-container__buttons"
      :style="{
        right: `${buttonsPosition.right}px`,
        top: `${buttonsPosition.top}px`
      }"
    >
      <slot name="buttons" ></slot>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue ,Watch ,Prop} from 'vue-property-decorator';
import MediaPlayer from '@/components/media-player/index.vue';
import {debounce} from "lodash";
import PolygonDrawer, {
  DEFAULT_POLYGON_LINE_COLOR,
  DEFAULT_POLYGON_LINE_WEIGHT,
  DEFAULT_POLYGON_LINE_OPACITY,
  DEFAULT_POLYGON_LINE_CONNECT_POINT_RADIUS,
  DEFAULT_POLYGON_MASK_OPACITY
} from "./drawer";
import { getImageSize } from "@/utils/image";
import { hex2rgba } from "@/utils/format";
import { on, off } from "@/utils/dom";

const BUTTON_HEIGHT = 34;

interface IPoint {
  x: number;
  y: number;
}

interface IPolygon {
  points: IPoint[];
}

interface IRect {
  leftTop: IPoint;
  rightBottom: IPoint;
}

@Component({
  components: {
    MediaPlayer,
  }
})
export default class drawPolygon extends PolygonDrawer {
  
  /* props */
  @Prop({default:''}) videoUrl!: string;
  @Prop(Number) width!: number;
  @Prop(Number) height!: number;
  @Prop({default:false}) drawingRect!: boolean;
  @Prop({default:true}) drawingPolygon!: boolean;
  @Prop({default:[],type:Array}) polygons!: IPolygon[];
  @Prop({default:[],type:Array}) rects!: IRect[];

  /* watch */
  @Watch('videoUrl')
  onVideoUrlChange(n,o){
    this.calculateCanvas(() => {
      this.$nextTick(() => {
        this.drawPolygons();
        this.drawRects();
      });
    });
  }
  @Watch('drawingPolygon',{ immediate: true})
  onDrawingPolygonChange(n,o){
    this.isDrawingPolygon = n;
  }
  @Watch('isDrawingPolygon')
  onIsDrawingPolygonChange(n,o){
    if (n) {
      this.clearPolygon();
      on(document.body, "keyup", this.handleKeyUp);
      this.showButtons = false;
    } else {
      off(document.body, "keyup", this.handleKeyUp);
    }
  }
  @Watch('drawingRect',{ immediate: true})
  onDrawingRectChange(n,o){
    this.isDrawingRect = n;
  }
  @Watch('isDrawingRect')
  onIsDrawingRectChange(n,o){
    if (n) {
      this.clearPolygon();
      on(document.body, "keyup", this.handleKeyUp);
      this.showButtons = false;
    } else {
      off(document.body, "keyup", this.handleKeyUp);
    }
  }
  @Watch('polygons',{ immediate: false, deep: true })
  onPolygonsChange(n,o){
    this.$nextTick(() => {
      this.clearCanvas();
      this.drawPolygons();
    });
  }
  @Watch('rects',{ immediate: false, deep: true })
  onRectsChange(n,o){
    this.$nextTick(() => {
      this.clearCanvas();
      this.drawRects();
    });
  }
  

  /* data */
  $refs!:{
    container:HTMLFormElement,
    canvas:HTMLFormElement
  };
  
  containerWidth: number=0; // 组件宽度
  containerHeight: number=0; // 组件高度
  originWidth: number=0; // 图片实际宽度
  originHeight: number=0; // 图片实际高度
  ratio: number=0; // 图片尺寸和组件尺寸的比例

  canvasStyle = {
    width: 0,
    height: 0,
    left: 0,
    top: 0
  };

  canvasContext:any = null;
  isDrawingRect = false;
  drawRectMoving = false;
  rectStart: IPoint={x:0,y:0};
  rectEnd: IPoint={x:0,y:0};

  // 画完多边形后出现的按钮位置
  buttonsPosition = {
    top: 0,
    right: 0
  };
  showButtons = false;

  myDebounce:any = debounce((e)=>{ this.handleCanvasMove(e) }, 30, {maxWait: 30});

  /* methods */
  mounted() {
    
  }

  initDrawer(video){
    let w = video.target.videoWidth,h = video.target.videoHeight;
    this.canvasStyle.width = w;
    this.canvasStyle.height = h;
    this.containerWidth = this.width || this.$refs.container.offsetWidth;
    this.containerHeight = this.height || this.$refs.container.offsetHeight;
    this.canvasContext = this.$refs.canvas.getContext("2d");
    this.calculateCanvas(() => {
      this.$nextTick(() => {
        this.drawPolygons();
        this.drawRects();
      });
    },{width:w,height:h});
    this.$emit('loadedmetadata',{w,h,isLoaded:true})
  }

  calculateCanvas(cb,videoWH?) {
    this.clearCanvas();
    // 没有图片路径,返回
    if (!this.videoUrl || !this.videoUrl.length) {
      return;
    }
    // 计算 canvas 尺寸和位置
    const { width, height } = videoWH;
    this.originWidth = width;
    this.originHeight = height;
    let cWidth, cHeight, cTop, cLeft;

    // 先得到显示比例和原始比例
    const showRatio = this.containerWidth / this.containerHeight;
    const originRatio = width / height;

    if (originRatio > showRatio) {
      // 如果原始长宽比例比显示的要大，则以显示宽度为 canvas 宽度
      cWidth = this.containerWidth;
      cHeight = cWidth * (1 / originRatio);
      cLeft = 0;
      cTop = (this.containerHeight - cHeight) / 2;
      this.ratio = width / this.containerWidth;
    } else if (originRatio < showRatio) {
      // 如果原始长宽比例比显示的要小，则以显示高度为 canvas 高度
      cHeight = this.containerHeight;
      cWidth = cHeight * originRatio;
      cTop = 0;
      cLeft = (this.containerWidth - cWidth) / 2;
      this.ratio = height / this.containerHeight;
    } else {
      cWidth = this.containerWidth;
      cHeight = this.containerHeight;
      cTop = 0;
      cLeft = 0;
      this.ratio = 1;
    }

    this.canvasStyle.width = cWidth;
    this.canvasStyle.height = cHeight;
    this.canvasStyle.top = cTop;
    this.canvasStyle.left = cLeft;

    cb && cb();
    
  }

  handleCanvasClick(e) {
    this.handleClick({
      x: e.offsetX,
      y: e.offsetY
    });
  }

  handleCanvasMove(e) {
    const point = {
      x: e.offsetX,
      y: e.offsetY
    };
    if (this.drawRectMoving) {
      this.clearCanvas();
      this.drawRect(
        this.rectStart,
        point,
        DEFAULT_POLYGON_LINE_COLOR,
        DEFAULT_POLYGON_LINE_WEIGHT,
        DEFAULT_POLYGON_MASK_OPACITY
      );
    } else {
      this.handleMove(point);
    }
  }

  handleCanvasMouseDown(e) {
    if (this.isDrawingRect) {
      this.drawRectMoving = true;
      this.rectStart = {
        x: e.offsetX,
        y: e.offsetY
      };
    }
  }

  handleCanvasMouseUp(e) {
    if (this.isDrawingRect) {
      this.drawRectMoving = false;
      this.rectEnd = {
        x: e.offsetX,
        y: e.offsetY
      };
      if (
        this.rectStart.x === this.rectEnd.x ||
        this.rectStart.y === this.rectEnd.y
      ) {
        this.clearCanvas();
        return;
      }
      this.showFinishButtons("rect", [this.rectStart, this.rectEnd]);
      this.$emit("finish", {
        leftTop: {
          x: Math.min(this.rectStart.x, this.rectEnd.x) * this.ratio,
          y: Math.min(this.rectStart.y, this.rectEnd.y) * this.ratio
        },
        rightBottom: {
          x: Math.max(this.rectStart.x, this.rectEnd.x) * this.ratio,
          y: Math.max(this.rectStart.y, this.rectEnd.y) * this.ratio
        }
      });
    }
  }

  drawLine(start, end, color, weight, opacity) {
    const ctx = this.canvasContext;
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.strokeStyle = hex2rgba(color, opacity);
    ctx.lineWidth = weight;
    ctx.stroke();
    return {
      start,
      end
    };
  }

  drawCircle(point, radius, color, weight, opacity) {
    const ctx = this.canvasContext;
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius, 0, 2 * Math.PI, false);
    ctx.fillStyle = hex2rgba(color, opacity);
    ctx.fill();
    ctx.lineWidth = weight;
    ctx.strokeStyle = color;
    ctx.stroke();
  }

  drawRect(start, end, color, weight, opacity) {
    const leftTop: any = {
      x: Math.min(start.x, end.x),
      y: Math.min(start.y, end.y)
    };
    const width = Math.abs(start.x - end.x);
    const height = Math.abs(start.y - end.y);
    const ctx = this.canvasContext;
    ctx.beginPath();
    ctx.rect(leftTop.x, leftTop.y, width, height);
    ctx.fillStyle = hex2rgba(color, opacity);
    ctx.fill();
    ctx.lineWidth = weight;
    ctx.strokeStyle = color;
    ctx.stroke();
  }

  removeMovingLine() {
    // 先清空然后将除了 movingLine 以外的线画回去
    this.clearCanvas();
    this.lines.forEach(line => {
      if (!this.isSameLine(line, this.movingLine)) {
        this.drawLine(
          line.start,
          line.end,
          DEFAULT_POLYGON_LINE_COLOR,
          DEFAULT_POLYGON_LINE_WEIGHT,
          DEFAULT_POLYGON_LINE_OPACITY
        );
      }
    });
    if (this.finishHint) {
      this.showCloseHint();
    }
    this.movingLine = null;
  }

  saveMovingLine(data) {
    this.movingLine = data;
  }

  calculateDistance(first: IPoint, second: IPoint) {
    return Math.sqrt(
      Math.pow(first.x - second.x, 2) + Math.pow(first.y - second.y, 2)
    );
  }

  showCloseHint() {
    const point = this.points[0];
    this.drawCircle(
      point,
      10,
      DEFAULT_POLYGON_LINE_COLOR,
      DEFAULT_POLYGON_LINE_WEIGHT,
      DEFAULT_POLYGON_MASK_OPACITY
    );
    this.finishHint = point;
  }

  hideCloseHint() {
    this.finishHint = null;
    this.clearCanvas();
  }

  drawMask(pointArray?) {
    const points = pointArray || this.points;
    const ctx = this.canvasContext;
    ctx.fillStyle = hex2rgba(
      DEFAULT_POLYGON_LINE_COLOR,
      DEFAULT_POLYGON_MASK_OPACITY
    );
    ctx.lineWidth = DEFAULT_POLYGON_LINE_WEIGHT;
    ctx.strokeStyle = hex2rgba(
      DEFAULT_POLYGON_LINE_COLOR,
      DEFAULT_POLYGON_LINE_OPACITY
    );
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      const { x, y } = points[i];
      ctx.lineTo(x, y);
    }
    ctx.lineTo(points[0].x, points[0].y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  emitPolygon(points: IPoint[]) {
    this.showFinishButtons("polygon", points);
    this.$emit(
      "finish",
      points.map(p => ({
        x: p.x * this.ratio,
        y: p.y * this.ratio
      }))
    );
  }

  clearPolygon() {
    this.lines = [];
    this.points = [];
    this.removeMovingLine();
    this.hideCloseHint();
  }

  clearCanvas() {
    this.canvasContext && this.canvasContext.clearRect(
      0,
      0,
      this.canvasStyle.width,
      this.canvasStyle.height
    );
  }

  isSameLine(first, second) {
    return (
      this.calculateDistance(first.start, second.start) === 0 &&
      this.calculateDistance(first.end, second.end) === 0
    );
  }

  handleKeyUp(e) {
    const code = e.keyCode || e.which;
    if (code === 27) {
      this.isDrawingPolygon = false;
    }
  }

  drawPolygons() {
    this.polygons.forEach(p => {
      this.drawMask(
        p.points.map(point => ({
          x: point.x / this.ratio,
          y: point.y / this.ratio
        }))
      );
      
    });
  }

  drawRects() {
    this.rects.forEach(r => {
      const { leftTop, rightBottom } = r;
      this.drawRect(
        {
          x: leftTop.x / this.ratio,
          y: leftTop.y / this.ratio
        },
        {
          x: rightBottom.x / this.ratio,
          y: rightBottom.y / this.ratio
        },
        DEFAULT_POLYGON_LINE_COLOR,
        DEFAULT_POLYGON_LINE_WEIGHT,
        DEFAULT_POLYGON_MASK_OPACITY
      );
    });
  }

  showFinishButtons(type, points) {
    this.calculateButtonPosition(type, points);
    this.$nextTick(() => (this.showButtons = true));
  }

  // 计算按钮显示的位置，临近多边形
  calculateButtonPosition(type, points) {
    if (this.$slots.buttons) {
      const right = Math.max(...points.map(p => p.x));
      const top = Math.min(...points.map(p => p.y));
      const bottom = Math.max(...points.map(p => p.y));

      this.buttonsPosition.right =
        this.canvasStyle.width - right + this.canvasStyle.left;
      // 根据多边形上下的空隙对比，决定按钮显示在上面还是下面(位置需要加上偏移)
      if (top < this.canvasStyle.height - bottom) {
        this.buttonsPosition.top = bottom + 10 + this.canvasStyle.top;
      } else {
        this.buttonsPosition.top =
          top - (BUTTON_HEIGHT + 10) + this.canvasStyle.top;
      }
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .draw-polygon-container{
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #000;
    .draw-polygon-container__canvas{
      position: absolute;
      background-color: transparent;
    }
    .draw-polygon-container__buttons{
      position: absolute;
    }
  }
  .is-drawing{
    canvas {
      cursor: url("/images/drawer-edit.svg"), default !important;
    }
  }
  
</style>
