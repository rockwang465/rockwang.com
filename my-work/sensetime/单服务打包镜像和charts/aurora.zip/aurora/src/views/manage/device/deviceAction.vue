<template>
  <div>
    <el-dialog
      :title="dataObj.title"
      :visible.sync="dialogShowVisible"
      width="584px">

      <div class="content">
        <div class="div-class-edit">
          <div>{{dataObj.confirm}}</div>
          <div v-show="dataObj.deviceObj&&dataObj.deviceObj.deviceType == 3" style="height: 10px;"></div>
          <!--<div v-show="dataObj.deviceObj&&dataObj.deviceObj.deviceType == 3">{{dataObj.confirm2}}</div>-->
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button v-if="dataObj.type == 'deleteDevice' || dataObj.type == 'deleteDeviceBatch'" type="danger"
                   @click="handleAction" :loading="loading">{{$t('devicemanagement.buttonDelete')}}</el-button>
        <el-button v-if="dataObj.type != 'deleteDevice' && dataObj.type != 'deleteDeviceBatch'" type="primary"
                   @click="handleAction" :loading="loading">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {DeviceModule} from '@/store/modules/device';
  import {isEmpty} from '@/utils/validate';

  @Component({

  })
  export default class groupAction extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    valueData = "";
    loading:boolean = false;
    @Prop(Object) dataObj!: any[];
    @Prop({required: true, default: false}) dialogVisible!: boolean;

    handleAction() {
      this.loading = true;
      let that = this as any;
      let deviceData = that.dataObj as any;
      this.loading = true;
      //修改设备状态
      switch (deviceData.type) {
        case "deleteDevice":
          DeviceModule.DeleteDevice(deviceData.deviceObj.deviceId).then((data: any) => {
            that.dialogShowVisible = false;
            that.$emit("resetDeviceList")
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.deviceDeleteSuccess'),
              type: 'success'
            });
            this.loading = false;
          }).catch((err) => {
            console.log(err)
          }).finally(()=>{
            that.loading = false;
          });
          break;
        case "deleteDeviceBatch":
          let multipleSelectionArray = deviceData.multipleSelection;
          //如果没有选择设备,提示请选择设备
          if (isEmpty(multipleSelectionArray) || multipleSelectionArray.size == 0) {
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.chooseDevice'),
              type: 'error'
            });
            that.dialogShowVisible = false;
            return
          }
          let deviceIds = [] as any;
          for (let i = 0; i < multipleSelectionArray.length; i++) {
            deviceIds.push(multipleSelectionArray[i].deviceId);
          }
          DeviceModule.DeleteDeviceBatch(deviceIds).then((data: any) => {
            that.dialogShowVisible = false
            that.$emit("resetDeviceList")
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.devicesDeleteSuccess'),
              type: 'success'
            });
            this.loading = false;
          }).catch((err) => {
            console.log(err)
          }).finally(()=>{
            that.loading = false;
          });
          break;
      }
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.loading = false;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeDeviceAction")
      }
    }

  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  ::v-deep .el-dialog__body {
    padding: 0px 0px
  }

  ::v-deep .el-input {
    width: 224px;
    height: 32px;
  }

  ::v-deep .el-dialog__footer {
    text-align: center;
  }

  .content {
    height: 120px;
  }

  .div-class-edit {
    text-align: center;
    padding-top: 50px;
  }

  .div-class-delete {
    text-align: center;
    padding-top: 100px;
  }

  .div-class-detail {
  }

  .div-class-detail > div {
    padding: 50px 20px 0 50px;
  }

  .div-class-detail > div > span {
    margin-right: 30px;
    width: 56px;
    height: 14px;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: bold;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
  }
</style>
