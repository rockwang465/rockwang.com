<template>
  <div>
    <el-dialog :title="$t('devicemanagement.titleDetail')" :visible.sync="dialogShowVisible"  v-if="dialogShowVisible" width="584px">
      <el-form :model="form" label-position="right" style="max-height: 580px" @submit.native.prevent>
        <div>
          <el-form-item :label="$t('devicemanagement.contDeviceType')" :label-width="formLabelWidth"><!--设备类型-->
            {{deviceTypeObj && deviceTypeObj[detailObj.deviceType]}}
          </el-form-item>
          <el-form-item v-show="detailObj.deviceType==3" :label="$t('devicemanagement.version')" :label-width="formLabelWidth"><!--版本-->
            {{mDeviceTypeObj && mDeviceTypeObj[detailObj.nebulaVersion]}}
          </el-form-item>
          <el-form-item v-show="detailObj.subordinateToNodeVo" :label="$t('devicemanagement.fpoint')" :label-width="formLabelWidth"><!--所属节点-->
            {{detailObj.subordinateToNodeVo && detailObj.subordinateToNodeVo.subordinateToNodeName}}
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceName')" :label-width="formLabelWidth"><!--名称-->
            {{detailObj.deviceName}}
          </el-form-item>
          <el-form-item v-show="detailObj.deviceType==2" :label="$t('devicemanagement.contDeviceID')"
                        :label-width="formLabelWidth">
            {{detailObj.deviceCode}}
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceGroup')" :label-width="formLabelWidth"><!--分组-->
            {{detailObj.groupName}}
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contLocation')" :label-width="formLabelWidth"><!--地点-->
            <div class="address-class" @click="addDevice">{{detailObj.floorName + ',' + detailObj.point}}</div>
          </el-form-item>
          <el-form-item v-if="detailObj.latitudeLongitude" :label="$t('devicemanagement.trapeze')" :label-width="formLabelWidth"><!--经纬度-->
            <div>{{detailObj.latitudeLongitude}}</div>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contAssignedUser')" :label-width="formLabelWidth"><!--添加用户-->
            {{$t('devicemanagement.contSelected',{number:detailObj.userIds ? detailObj.userIds.length : 0})}}
          </el-form-item>
        </div>
        <div v-if="showVideo" class="rtsp-video">
          <br>
          <div class="rtsp-video-see-cancel">
            <el-button type="danger" size="mini" @click="showVideo = !showVideo">
              {{$t('devicemanagement.buttonCancel')}}
            </el-button>
          </div>
          <br>
          <div class="rtsp-video-see">
            <MediaPlayer type="1" :name="detailObj.name" :url="detailObj.rtspAddress"/>
          </div>
        </div>
        <hr v-if=" (detailObj.deviceType==1 || detailObj.deviceType==4 || detailObj.deviceType==6 || detailObj.deviceType==3)">
        <!-- <br> -->
        <!--<el-form-item :label="$t('devicemanagement.contOtherInfo')" :label-width="formLabelWidth">&lt;!&ndash;属性&ndash;&gt;-->
        <!--</el-form-item>-->
        <!--类型-->
        <el-form-item v-if="(detailObj.deviceType==1&&!detailObj.subordinateToNodeVo) || (detailObj.streamType && detailObj.subordinateToNodeVo)" :label="$t('devicemanagement.contCameraType')"
                      :label-width="formLabelWidth">
          {{detailObj.streamType}}
        </el-form-item>
        <!-- <el-form-item v-if="detailObj.streamType && detailObj.subordinateToNodeVo"
          :label="$t('devicemanagement.contCameraType')"  :label-width="formLabelWidth">
          {{detailObj.streamType}}
        </el-form-item> -->
        <!-- 抓拍策略 -->
        <el-form-item v-if="detailObj.streamType && detailObj.subordinateToNodeVo" :label="$t('devicemanagement.capturingstrategies')"
                      :label-width="formLabelWidth">
          {{getStrategyType}}
        </el-form-item>

        <el-form-item v-if="detailObj.deviceType==1 && detailObj.streamType=='RTSP' && !detailObj.subordinateToNodeVo"
          :label="$t('devicemanagement.contRTSP2')"
          :label-width="formLabelWidth">
          <el-popover
            placement="top-start"
            :title="$t('devicemanagement.rtspDetail')"
            width="300"
            trigger="hover"
          >
            <div style="width: 250px;word-wrap: break-word">{{detailObj.rtspAddress}}</div>
            <span slot="reference">{{detailObj.rtspAddress.length < 20 ? detailObj.rtspAddress : detailObj.rtspAddress.substring(0,20) + '......'}}</span>
          </el-popover>
          &nbsp;&nbsp;&nbsp;&nbsp;<i v-if="$permission('007118')" style="cursor: pointer"
                                     @click="showVideo = !showVideo"
                                     class="iconfont icon-view"></i>
        </el-form-item>
        <el-form-item v-if="detailObj.deviceType==1 && detailObj.streamType=='RTSP'&&!detailObj.subordinateToNodeVo"
                      :label="$t('devicemanagement.contEncodeType')"
                      :label-width="formLabelWidth"><!--编码类型-->
          {{codeTypeObj[detailObj.codeType]}}
        </el-form-item>
        <el-form-item v-if="detailObj.deviceType==1 && detailObj.streamType=='RTSP'&&!detailObj.subordinateToNodeVo"
                      :label="$t('devicemanagement.contProtocol')"
                      :label-width="formLabelWidth"><!--传输协议-->
          {{detailObj.protocolType}}
        </el-form-item>
        <el-form-item v-if="detailObj.deviceType==4&&!detailObj.subordinateToNodeVo"
                      :label="$t('devicemanagement.manufacturer')"
                      :label-width="formLabelWidth">
          {{detailObj.firmName}}
        </el-form-item>
        <el-form-item v-if="(detailObj.deviceType==1 && detailObj.streamType=='ONVIF'||detailObj.deviceType==4)&&!detailObj.subordinateToNodeVo"
                      :label="$t('devicemanagement.contIP')"
                      :label-width="formLabelWidth">
          {{detailObj.ip}}
        </el-form-item>
        <el-form-item v-if="(detailObj.deviceType==1 && detailObj.streamType=='ONVIF'||detailObj.deviceType==4)&&!detailObj.subordinateToNodeVo"
                      :label="$t('devicemanagement.contPort')"
                      :label-width="formLabelWidth">
          {{detailObj.port}}
        </el-form-item>
        <el-form-item v-if="(detailObj.deviceType==1 && detailObj.streamType=='ONVIF'||detailObj.deviceType==4)&&!detailObj.subordinateToNodeVo"
                      :label="$t('devicemanagement.contUsername')"
                      :label-width="formLabelWidth">
          {{detailObj.username}}
        </el-form-item>
        <el-form-item v-if="(detailObj.deviceType==1 && detailObj.streamType=='ONVIF'||detailObj.deviceType==4)&&!detailObj.subordinateToNodeVo"
                      :label="$t('devicemanagement.contPassword')"
                      :label-width="formLabelWidth">
          {{detailObj.password}}
        </el-form-item>
        <el-form-item v-if="detailObj.noSenseSwitch == 1"
                      :label="$t('devicemanagement.noSenseIp')"
                      :label-width="formLabelWidth">
          {{detailObj.noSenseIp}}
        </el-form-item>
        <el-form-item v-if="detailObj.noSenseSwitch == 1"
                      :label="$t('devicemanagement.noSensePort')"
                      :label-width="formLabelWidth">
          {{detailObj.noSensePort}}
        </el-form-item>
        <el-form-item v-if="detailObj.deviceType == 6 &&  !detailObj.subordinateToNodeVo"
                      :label="$t('rule.contThreshold')"
                      :label-width="formLabelWidth">
          {{Number(detailObj.verifyThreshold*100).toFixed(1)}}%
        </el-form-item>

        <!-- <el-form-item v-if="detailObj.libraryVos" :label="$t('rule.labelImageLibraryList')" :label-width="formLabelWidth">
          {{$t('devicemanagement.contSelected',{number:detailObj.libraryVos ? detailObj.libraryVos.length : 0})}}
        </el-form-item> -->
        <!-- <el-form-item v-if="detailObj.threshold" :label="$t('rule.contThreshold')" :label-width="formLabelWidth">
          {{detailObj.threshold}}%
        </el-form-item> -->

        <!-- 前端比对设备上传 -->
        <el-form-item v-if="false&&detailObj.deviceType == 6" :label="$t('devicemanagement.contOtherInfo')" :label-width="formLabelWidth">
          <!-- apkneme -->
          {{apkName}}
        </el-form-item>
        <el-form-item v-if="false&&detailObj.deviceType == 6" v-show="$permission('007210')" :label="$t('devicemanagement.contFirmware')" :label-width="formLabelWidth">
          <el-upload
          :action="frontendCompareHost+'/upload_app?deviceId='+detailObj.deviceId+'&deviceType=6'"
          :before-upload="beforeAvatarUpload"
          :on-progress="handleProcess"
          :on-exceed="handleExceed"
          :on-success="handleSuccess"
          :auto-upload="true"
          :on-error="handleError"
          :file-list="fileList"
          :show-file-list="true"
          :limit="2"
          name="apkFile"
          :multiple="false">
              <el-button slot="trigger" type="text">{{$t('devicemanagement.deviceUpdateSelectFile')}}</el-button>
              <el-tooltip class="item" effect="dark" :content="$t('devicemanagement.deviceUpdateTip')" placement="right">
                  <i class="el-icon-question"></i>
              </el-tooltip>
          </el-upload>
          <!-- <el-button type="primary" @click="updateFiles" :disabled="updateLoading" style="margin-top:16px">{{$t('devicemanagement.deviceUpdateCont')}}</el-button> -->
          <el-button type="primary" @click="showUpdateDialog = true" :disabled="updateLoading || !(fileList[0] && fileList[0].name)" style="margin-top:16px">{{$t('devicemanagement.deviceUpdateCont')}}</el-button>

        </el-form-item>

                <!--厂商-->
        <el-form-item v-if="detailObj.deviceType==4 && !detailObj.streamType  && detailObj.subordinateToNodeVo "  :label="$t('devicemanagement.manufacturer')"
                      :label-width="formLabelWidth">
                      {{detailObj.firmName}}
        </el-form-item>
        <!--非人脸过滤-->
        <el-form-item v-if="detailObj.deviceType==4 && !detailObj.streamType  && detailObj.subordinateToNodeVo && detailObj.nebulaVersion == 2"  :label="$t('devicemanagement.noFace')"
                      :label-width="formLabelWidth">
                      <!-- {{detailObj.disableAnalysis}} -->
                      {{getDisableAnalysis}}
        </el-form-item>


        <el-form-item v-if="detailObj.deviceType == 3 || ( detailObj.streamType != 'RTSP' && detailObj.subordinateToNodeVo )"
          :label="detailObj.streamType=='GB28181' ? $t('imagemanagement.spiServersId') :$t('devicemanagement.contIP')" :label-width="formLabelWidth">
          {{detailObj.ip}}
        </el-form-item>
        <el-form-item v-if="detailObj.deviceType == 3 || ( detailObj.streamType != 'RTSP' && detailObj.subordinateToNodeVo )"
          :label="detailObj.streamType=='GB28181' ? $t('devicemanagement.spiCameraPort'):$t('devicemanagement.contPort')" :label-width="formLabelWidth">
          {{detailObj.port}}
        </el-form-item>
        <el-form-item v-if="detailObj.deviceType == 3 || ( detailObj.streamType != 'RTSP' && detailObj.streamType != 'GB28181' && detailObj.subordinateToNodeVo )"
          :label="$t('devicemanagement.contUsername')"  :label-width="formLabelWidth">
          {{detailObj.username}}
        </el-form-item>
        <el-form-item v-if="detailObj.deviceType == 3 || ( detailObj.streamType != 'RTSP' && detailObj.streamType != 'GB28181' && detailObj.subordinateToNodeVo )"
          :label="$t('devicemanagement.contPassword')"  :label-width="formLabelWidth">
          {{detailObj.password}}
        </el-form-item>

        <el-form-item v-if="detailObj.streamType == 'GB28181' && detailObj.subordinateToNodeVo "
        :label="$t('imagemanagement.spiServersId')" prop="serverSipId" :label-width="formLabelWidth">
          {{detailObj.serverSipId}}
        </el-form-item>

        <el-form-item v-if="detailObj.streamType == 'GB28181' && detailObj.subordinateToNodeVo "
          :label="$t('imagemanagement.spiCameraID')" prop="cameraSipId" :label-width="formLabelWidth">
          {{detailObj.cameraSipId}}
        </el-form-item>


        <el-form-item
          v-if="(detailObj.deviceType == 3&&detailObj.libraryVos) || detailObj.subordinateToNodeVo"
          :label="$t('imagemanagement.contImageLibrary')"
          :label-width="formLabelWidth">
          {{$t('records.contSelected',{number: detailObj.libraryVos&&detailObj.libraryVos.length ? detailObj.libraryVos.length : 0 })}}
            <!-- {{ `已选${detailObj.libraryVos&&detailObj.libraryVos.length ? detailObj.libraryVos.length : 0}个`}} -->
        </el-form-item>

         <el-form-item v-if="detailObj.subordinateToNodeVo && detailObj.libraryVos && detailObj.libraryVos.length"
                      :label="$t('rule.contThreshold')"
                      :label-width="formLabelWidth">
          {{(detailObj.threshold)}}%
        </el-form-item>

        <el-form-item v-if="detailObj.subordinateToNodeVo && detailObj.streamType=='GB28181'"
          :label="$t('devicemanagement.authentication')"  :label-width="formLabelWidth">
          <el-switch
            :value="!!detailObj.password"
            active-color="#13ce66"
            inactive-color="#ff4949"
            >
          </el-switch>
        </el-form-item>
        <el-form-item v-if="detailObj.subordinateToNodeVo && detailObj.streamType=='GB28181' && detailObj.password"
          :label="$t('devicemanagement.contPassword')"  :label-width="formLabelWidth">
            {{detailObj.password}}
        </el-form-item>

        <el-form-item v-if="detailObj.deviceType == 3&&detailObj.libraryVos&&detailObj.libraryVos.length > 0" :label-width="formLabelWidth">
          <div @click="openProtraitList" class="show-pro-btn">{{$t('devicemanagement.contViewAsync')}}</div>
        </el-form-item>
      </el-form>
      <div v-if="detailObj.deviceType==6" style="">
          <!-- <el-form-item v-if="form.deviceType==6" > -->
            <LibraryToTimezone ref="librarytotimezone" :viewModel="true" :data="detailObj.configVos" />
          <!-- </el-form-item> -->
        </div>
        <div v-if="detailObj.deviceType==6" style="padding:16px 0;">
          <el-link type="primary" @click="showImagesSyncDialog=true" v-if="$permission('007125')">{{$tc('devicemanagement.contViewAsync')}}</el-link>
        </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" v-if="$permission('007210')" @click="toEditDevice">{{$t('devicemanagement.titleEdit')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </span>
      <el-dialog
      :title="$t('devicemanagement.deviceUpdateLabel')"
      :visible="deviceUpdateVisible"
      append-to-body>
        {{$t('devicemanagement.deviceUpdateLabel')}}
      </el-dialog>
    </el-dialog>
    <el-dialog
      :title="$t('devicemanagement.titleDetail')"
      :visible.sync="isMapDevice"
      v-if="isMapDevice"
      width="600px"
      class="dialog-track"
    >
      <el-form style="width:100%;min-height:500px">
        <map-device class="device-view" handleType="view" :deviceInfo="deviceInfo" :key="deviceInfo.length != 0 ? deviceInfo[0].id : ''"/>
      </el-form>

      <div slot="footer" class="dialog-footer" style="padding-top:16px">
        <el-button @click="isMapDevice = false" type="primary">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button @click="isMapDevice = false" type="info">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>

    <!-- update dialog -->
    <el-dialog
      :visible="showUpdateDialog"
      :before-close="()=>this.showUpdateDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{$t('devicemanagement.ensureUpdate')}} {{fileList[0]?fileList[0].name:''}}</p>
      <div slot="title" class="group-td-dialog-header" >
        <span>{{this.$t('rule.titleReminder')}}</span>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="updateFiles">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button @click="showUpdateDialog = false" type="info">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!-- images sync -->
    <ImagesSync :visible="showImagesSyncDialog" @close="()=>{this.showImagesSyncDialog=false}" :deviceId="detailObj.deviceId" />
    <PortraitList :dialogVisible="showPortraitList" :deviceObj="detailObj" @closeProtraitList="closeProtraitList"></PortraitList>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {AppModule} from '@/store/modules/app';
  import MapDevice from '../map/map-device.vue';
  import MediaPlayer from '@/components/media-player/index.vue';
  import {deviceType} from '@/utils/constants';
  import {mDeviceType} from '@/utils/constants';
  const frontendCompareHost = window.globalConfig.frontendCompare;
  import api from "@/api/device";
  import {Cache} from '@/utils/cache';
   import LibraryToTimezone from './components/libraryToTimezone.vue';
   import ImagesSync from './components/imageSync.vue';
  import PortraitList from './portraitList.vue'
  import {noFaceType as noFaceTypeList }  from '@/utils/constants';

  @Component({
    components: {
      MapDevice,
      MediaPlayer,
      LibraryToTimezone,
      ImagesSync,
      PortraitList,
    },
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    },
    computed: {
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '170px' : '100px';
      }
    }
  })
  export default class DetailDevice extends Vue {
    get language() {
      return AppModule.language;
    }

    get getStrategyType(){

      switch (this.detailObj.captureStrategy) {
        case 1:
          return this.$t('captureStrategyType.accurate')
          break;
        case 2:
          return this.$t('captureStrategyType.timing')
          break;
        case 3:
          return this.$t('captureStrategyType.realTime')
          break;

        default:
          return ''
          break;
      }
    }
    get getDisableAnalysis(){
      //console.log(this.detailObj.filterNoface,noFaceTypeList)
      if(this.detailObj.filterNoface == 0 || this.detailObj.filterNoface == 1){
        return noFaceTypeList[this.detailObj.filterNoface].name
      }else{
        return ''
      }

      // switch (this.detailObj.filterNoface) {
      //   case 1:
      //     return this.$t('noFaceType.yes')
      //     break;
      //   case 0:
      //     return this.$t('noFaceType.no')
      //     break;

      //   default:
      //     return ''
      //     break;
      // }
    }


    frontendCompareHost:string=frontendCompareHost;
    showVideo = false as any;
    deviceInfo = [] as any;
    // deviceTypeObj = {1: 'Camera', 2: 'SenseKeeper',4:'SenseDLC',5:'SenseID'};/*, 'SenseNebula-M', 'SenseDLC'*/
    deviceTypeObj:any = null;
    mDeviceTypeObj:any = null;
    codeTypeObj = {1: 'contDirectConnection', 2: 'contTranscode'};
    transportProtocolArray = ['TCP', 'UDP'];
    dialogShowVisible = false;
    uploadFilesList:any[]=[];
    showImagesSyncDialog:boolean=false;
    showPortraitList:boolean = false;

    @Prop(Object) detailObj!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    isMapDevice = false;

    //编辑的表单里的值
    form = {};

    apkName:string=''
    deviceUpdateVisible:boolean=false;


    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      let that = this as any;
      if (val) {
        that.deviceInfo = [{
          deviceId: that.detailObj.deviceId,
          floorId: that.detailObj.floorId,
          name: that.detailObj.floorName,
          deviceName: that.detailObj.deviceName,
          position: {
            lat: that.detailObj.point?JSON.parse(that.detailObj.point)[1]:'',
            lng: that.detailObj.point?JSON.parse(that.detailObj.point)[0]:'',
          },
          url: that.detailObj.floorUrl
        }]
      }
      that.dialogShowVisible = val;
      if(val){
        this.codeTypeObj = {1: this.$tc('devicemanagement.contDirectConnection'), 2: this.$tc('devicemanagement.contTranscode')};
      }
      if(val) this.translateArrayToObj();
      this.deviceUpdateVisible=false;
    }

    translateArrayToObj(){
      deviceType && (this.deviceTypeObj = {});
      deviceType && deviceType.map(item=>{
        item && (this.deviceTypeObj[item.value] = item.name);
      })
      mDeviceType && (this.mDeviceTypeObj = {});
      mDeviceType && mDeviceType.map(item=>{
        item && (this.mDeviceTypeObj[item.value] = item.name);
      })
    }

    toEditDevice() {
      let that = this as any;
      if(that.detailObj.subordinateToNodeVo != null){
        //如果是子设备
        this.$emit("detailShowEdit", that.detailObj,{deviceName:that.detailObj.subordinateToNodeVo.subordinateToNodeName,deviceId:that.detailObj.subordinateToNodeVo.subordinateToNodeId})
      }else{
        this.$emit("detailShowEdit", that.detailObj,null)
      }
      that.dialogShowVisible = false;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      this.showVideo = false
      if (!val) {
        this.$emit("closeDetail")
        this.destoryData()
      }
      val && this.initData()
    }

    addDevice(e) {
      if (e) {
        this.isMapDevice = true;
      } else {
        this.isMapDevice = false;
      }
    }

    closeProtraitList(){
      this.showPortraitList = false;
    }
    openProtraitList(){
      this.showPortraitList = true;
    }





    //upload
    fileList:any[]=[]
    // accessToken:string=Cache.localGet('accessToken') || Cache.sessionGet("accessToken");
    updateLoading:boolean=false;
    showUpdateDialog:boolean=false;
    // methods
    beforeAvatarUpload(file) {
        const isApk = file.type === 'application/vnd.android.package-archive';
        const isLt100M = file.size / 1024 / 1024 < 100;
        if (!isApk) {
          this.$message.error({showClose: true,message:this.$tc('devicemanagement.deviceUpdateApkTypeError')});
        }
        if (!isLt100M) {
          this.$message.error({showClose: true,message:this.$tc('devicemanagement.deviceUpdateApkSizeError')});
        }
        return isApk && isLt100M;
    }
    handleExceed(){
        this.$message.warning({showClose: true,message:this.$tc('devicemanagement.deviceUpdateApkNumberError')});
    }
    handleProcess(e,file){
        // console.log(e)
    }
    handleSuccess(res, file, fileList){
        fileList.length >= 2 && fileList.shift();
        // this.fileList = fileList;
        this.initData()
        this.$message({
          showClose: true,
          message: this.$tc('devicemanagement.deviceUpdateApkSuccess'),
          type: 'success'
        });
    }
    handleError(error){
      let data = error.message?JSON.parse(error.message):null;
      data && this.$message.error({showClose: true,message:this.$te(data.code)?this.$t(data.code):data.message});
    }
    updateFiles(){
      let detailObj:any = this.detailObj;
      let deviceId = detailObj.deviceId;
      this.updateLoading = true;
      let deviceType = 6;
      (api as any).updateDeviceFirmware({deviceId,deviceType}).then(()=>{
        this.$message({
          showClose: true,
          message: this.$tc('devicemanagement.deviceUpdateStartSuccess'),
          type: 'success'
        });
      }).finally(()=>{
        this.updateLoading = false;
        this.showUpdateDialog = false;
      })
    }
    destoryData(){
      this.fileList = [];
    }
    initData(){
      let detailObj:any = this.detailObj;
      if(detailObj && detailObj.deviceType == 6){
        let deviceId = detailObj.deviceId;
        this.getVersionInfo(deviceId);
      }
    }
    getVersionInfo(deviceId){
      (api as any).getDeviceFirmwareInfo({deviceId}).then((res:any)=>{
        this.fileList = [];
        this.apkName = res.currentApkVersion || '';
        res.lastApkVersion && this.fileList.push({id:res.lastId,name:res.lastApkVersion})
      })
    }

  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.dialog-track{
  .device-wrapper{
    min-height: 500px;
    .device-view{
      min-height: 500px;
    }
  }
}
  .el-input {
    width: 224px
  }
  .adddeviceonmap{min-height: 500px;}

  .address-class {
    cursor: pointer;
    width: 224px;
    height: 32px;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #2a5af5;
    overflow: hidden; /*超出部分隐藏*/
    text-overflow: ellipsis; /* 超出部分显示省略号 */
    white-space: nowrap; /*规定段落中的文本不进行换行 */
  }

  ::v-deep .el-dialog__footer {
    text-align: center;
  }

  .rtsp-video {
    position: absolute;
    left: 0px;
    top: 0px;
    z-index: 1;
  }

  .rtsp-video-see-cancel {
    text-align: right;
    position: relative;
    top: 44px;
    z-index: 10;
  }

  .rtsp-video-see {
    width: 570px;
    margin-left: 7px
  }
  .el-upload-list__item.is-success {
    .el-icon-close{
      display: none;
    }

  }
  ::v-deep .el-upload-list__item:hover .el-icon-close{
    display: none;
  }
  ::v-deep .el-upload-list.el-upload-list--text{
    max-width: 275px;
  }
  ::v-deep .el-link .el-link--inner{
    color: #2a5af5;
    text-decoration: underline;
  }
  .show-pro-btn{
    font-weight:bold;
    color:rgba(42,90,245,1);
    text-decoration:underline;
    cursor: pointer;
  }

</style>
