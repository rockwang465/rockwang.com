<template>
  <div class="track-wrapper">
    <div class="track-select">
      <div class="track-tree">
        <!-- <el-checkbox v-model="selectAll" @change="showAll">显示所有轨迹</el-checkbox> -->
        <el-tree
          ref="trackTree"
          :data="trackData"
          :props="defaultProps"
          node-key="id"
          highlight-current
          current-node-key="0"
          defaultKey="0"
          @node-click="selectDate"
          @current-change="resetPopover">
        </el-tree>
      </div>
    </div>
    <div class="track-pic">
      <ul>
        <li class="track-pic-item"
          v-bind:class="{select:i == current}"
          @click="selectDevice(item,i)"
          v-for="(item,i) in trackPic" :key="i"
          :data-device="item.deviceId">
          <i class="list-style">{{i+1}}</i>
          <i class="button hide">x</i>
          <h6>{{item.deviceName}}</h6>
          <div class="image-wrap">
            <img class='image' :src='processImgurl(item.imageUrl)'>
          </div>
          <el-popover
            placement="right"
            width="580"
            popper-class="carousel-popover"
            :close-delay=10
            :ref="'popover' + i"
            trigger="click">
            <i class="iconfont el-icon-close" @click="hidePopover(i+1)"></i>
            <p>{{ currentDateTime }} </p>
            <div class="carousel-big-img-warp">
              <el-image class="carousel-big-img" :src="processImgurl(bigImageUrl)" fit="contain">
                <div slot="placeholder" class="image-slot">
                  <i class="el-icon-loading"></i>
                </div>
                <div slot="error" class="image-slot">
                  <i class="el-icon-picture-outline"></i>
                </div>
              </el-image>
            </div>
            <carousel
              :perPage="6"
              :navigationEnabled="true"
              :paginationEnabled="false"
              navigationPrevLabel=""
              navigationNextLabel=""
            >
              <slide v-for="(li,i) in item.list" :key="i" @click.native="postBigPic(li,i)" v-bind:class="{select:i == curr}">
                <img class="carousel-small-img" :src="processImgurl(li.smallImageUrl)" alt="">
              </slide>
            </carousel>
            <a href="javascript:;" slot="reference" @click="viewBigPic(item.list[0],i)">
              {{$t('records.viewDevicePics',{num:item.peopleNumber})}}
            </a>
          </el-popover>
        </li>
      </ul>
    </div>
    <div class="track-view" id="trackCanvas" v-loading="loading">

      <l-map ref="trackView"
        :min-zoom="mapSet.minZoom"
        :max-zoom="mapSet.maxZoom"
        :zoom="mapSet.zoom"
        :center="mapSet.center"
        :crs="mapSet.crs"
        :key="mapSet.key"
        :options="mapOptions"
      >
        <div v-if="noMapbg" class="no-map-bg">
          <div class="no-map-bg-tips">
            <img src="/images/map-changed.png" height="130" alt="">
            <span v-html="$t('map.mapChangedTips')"></span>
          </div>
        </div>
        <l-image-overlay
          :url="mapSet.bgUrl"
          :bounds="mapSet.bounds"/>
        <l-layer-group
          layer-type="overlay"
          name="Layer polyline"
        >
          <l-polyline
            v-for="item in trackLine"
            :key="item.floorId"
            :fillOpacity=fillOpacityVal
            :lat-lngs="item.devicePoints"
            :visible="item.visible"
            @click="alert(item)" />
          <!-- <l-polyline :lat-lngs="trackLine[0].devicePoints" :fillOpacity=fillOpacityVal /> -->
        </l-layer-group>
        <l-layer-group
          layer-type="overlay"
          name="Layer polyline"
          v-if="!noMapbg"
        >
          <l-marker v-for="item in deviceList"
            :lat-lng.sync="item.position"
            :icon="item.icon"
            :key="item.id">
            <l-popup>
              {{$tc('map.deviceName')}}
              {{item.deviceName}}
              <br/>
              {{$tc('map.deviceId')}}
              {{item.deviceId}}
            </l-popup>
          </l-marker>
        </l-layer-group>

        <!-- <l-control position="bottomleft" >
          <el-button size="mini" icon="el-icon-download" @click="exportTrack" round>导出</el-button>
        </l-control> -->
      </l-map>
      <div class="bottom-center">
        <el-button v-if="playShow" size="mini" :icon="playIcon" @click="playTrack" type="primary">{{playTips}}</el-button>
      </div>
      <div class="hide">
        <img src="/images/marker-icon-warning.png" alt="">
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue,Prop } from 'vue-property-decorator';
import {Tree as ElTree} from 'element-ui';
import L from 'leaflet';
import { LMap, LImageOverlay, LMarker, LPopup,LPolyline,LGeoJson,LLayerGroup,LControl } from 'vue2-leaflet';
import PopupContent from './geo-json-popup.vue';
import { Carousel, Slide } from 'vue-carousel';
import {transport} from '@/utils/image';
//import LMovingMarker from './moving-maker.vue';
import './MovingMarker.ts';

import api from '@/api/map';
import api_device from '@/api/device';
import api_history from '@/api/history-record';
import { MapModule } from '@/store/modules/map';
import '@/assets/js/plugins/L.Control.Zoomslider.js';

import domtoimage from 'dom-to-image';

//地图基础配置
import {drawSetting,markerIcon,localDeviceList,mapBase} from '@/views/manage/map/mapConfig';

import {Cache} from '@/utils/cache';
import i18n from '../../../lang';
const host = window.globalConfig.host;
// const token = Cache.localGet("accessToken") || Cache.sessionGet("accessToken");

import {processImgurl} from '@/utils/image.ts';

@Component({
  components: {
    LMap, LImageOverlay, LMarker, LPopup,LPolyline,LLayerGroup,LControl,
    LGeoJson,
    Carousel,
    Slide,
  }
})
export default class MapTrack extends Vue {
  @Prop({ default: '' }) uuidSerial!: any;
  @Prop({ default: '' }) trackData!: any;//轨迹数据
  map:any = "";
  mapOptions= {attributionControl: false, zoomSnap: true,zoomControl: false ,zoomsliderControl: true,};
  mapSet:any = Object.assign(mapBase,{
    //key     : +new Date(),
    bgUrl   : '/images/floor00.png',
    dataUrl : '/mock/floor0.json',
    reset   : true,
    zoom    : -1.8
  });
  loading:boolean = false;
  deviceList:any=[]
  treeData:any=[]
  floorId:any =''
  trackPic:any=[]
  trackLine:any=[];
  fillOpacityVal=0;
  defaultProps= {
    children: 'children',
    label: 'label'
  }
  host= host;
  selectAll=true;
  icon:any ="";
  isMapTrack=false;
  polylineData:any=[]
  selectDayTime="";
  current:any = '';
  curr:any = '';
  selectStyle=false
  noMapbg=false;
  locations = [
    {
      "recorded_at_ms": 1481571875000,
      "bearing": 0
    },
    {
      "recorded_at_ms": 1481571876000,
      "bearing": 3
    }
  ]
  makerM:any;
  printer:any;
  playShow = false;
  playIcon = 'el-icon-caret-right';
  playTips = "";
  showPopover = true;
  timeKey = "";
  bigImageUrl = ''
  currentDateTime = ''
  currentPopover = 0
  processImgurl:any=processImgurl;


  mounted(){
    let _this = this;
    this.$nextTick(function(){
      (this.$refs.trackTree as ElTree).setCurrentKey(0);
    });
    console.log(this.trackData)
    if(this.trackData.length>0){
      //this.selectDayTime = this.trackData[0].date;
      // this.trackPic =this.trackData[0].trajectorHeatMap.deviceImageNumber;
      // this.trackPic.map((item,i)=>{
      //   item.imageUrl = `${host}/${item.list[0].smallImageUrl}`;
      // });
      // this.floorId = this.trackPic[0].floorId;
      this.selectDate(this.trackData[0]);
    }

    this.map = (this.$refs.trackView as any).mapObject;
    // this.printer = (L as any).easyPrint({
    //   title: 'My awesome print button',
    //   position: 'bottomright',
    //   sizeModes: ['Current', 'A4Landscape', 'A4Portrait'],
    // }).addTo(this.map);

    // this.printer = (L as any).easyPrint({
    //   exportOnly: true,
    //   currentMapNum: 1,
    //   hideControlContainer:true,
		// }).addTo(this.map);

  }
  exportTrack(){
    //this.manualPrint()
    let _this = this;
    console.log(this.mapSet)
    this.mapSet.zoom = -2;
    this.mapSet.center = [540,800];

    console.log(this.mapSet)
    _this.loading = true;
    var controlContainer = document.getElementsByClassName("leaflet-control-container")[1];//多个map的bug

    var printContainer = document.getElementsByClassName("leaflet-map-pane")[1];//多个map的bug
    //if (show) return controlContainer.style.display = 'block';
    //controlContainer.style.display = 'none';
    setTimeout(()=>{
      let mapContainer = _this.map.getContainer();
      domtoimage.toJpeg(mapContainer).then((dataUrl) => {
        //console.log(dataUrl);
        let param = {
          "timeKey": _this.timeKey,
          "trajectoryImg": dataUrl,
          "userId": Cache.sessionGet('userInfo').userId
        }
        api.exportTrack(param).then((resp:any)=>{
          _this.loading = false;
          //console.log(resp)
          if(resp.count){
            _this.$message({
              showClose:true,
              message: _this.$tc('log.exportSuccess'),
              type: "success"
            });
          }
        })
      }).catch(function (error) {
        console.error('oops, something went wrong!', error);
      });
    },800)

  }

  // manualPrint () {
  //   //console.log(this.printer)
	// 	this.printer.printMap('CurrentSize', 'userTrack').then((result)=>{
  //     console.log(result)
  //   })
  // }
  hidePopover(ref) {
    //console.log(ref);
    if(ref>0){
      ref = ref - 1;
      console.log(ref)
      console.log(this.$refs)
      console.log(this.$refs['popover' + ref]);
      this.$refs['popover' + ref][0].doClose();
    }
  }
  // closeCarousel(e){
  //   //e.path[1].style.display="none"
  //   this.showPopover = !this.showPopover;
  // }

  viewBigPic(e,i){
    this.showPopover = true;
    this.currentPopover = i+1;
    console.log('大图展示',this.currentPopover,e)
    this.postBigPic(e,0)
  }
  postBigPic(item,i){
    console.log(item,i);
    //
    this.currentDateTime = item.dateTime;
    this.curr=i;
    this.bigImageUrl = `${item.bigImageUrl}`;
  }
  resetPopover(){
    //console.log("刷新")
    this.showPopover = false
    setTimeout(()=>{
      this.showPopover = true
    },100)
  }
  playTrack(){
    console.log('播放',this.makerM.isPaused,this.makerM)
    if (this.makerM.isPaused) {
      this.makerM.start();
      this.playIcon = 'iconfont icon-pause1';
      this.playTips = this.$tc("records.pauseFootfall");
    } else {
      this.playIcon = 'el-icon-caret-right';
      this.makerM.pause();
      this.playTips = this.$tc("records.playFootfall");
    }
  }
  selectDevice(data,i){
    //console.log(data);
    this.current=i;

    this.deviceList.map((item)=>{

      if(item.deviceId == data.deviceId){
        item.icon = markerIcon.warning
      }else{
        item.icon = markerIcon.default
      }
    })
  }

  selectFloor(isShowTrack){
    let _this =this;
    //this.current=i;
    //this.treeInit(this.floorId);
    let param = {
      // dayTime:this.selectDayTime,
      // uuidSerial:this.uuidSerial,
      // floorId:this.floorId

    }
    this.playShow = false;
    console.log('轨迹数据',_this.trackLine[0])
    // api_history.getTrackDayFloor(param).then((resp:any)=>{

    // }).then(()=>{})

      if(this.map.hasLayer(this.makerM)){
        this.map.removeLayer(this.makerM)
      }
      if(_this.trackLine && _this.trackLine[0].devicePoints && isShowTrack){
        this.playShow = true;
        var icon = L.divIcon({
          className: 'my-div-icon',
          //html:'<img src="/images/man.png" />'
          html:'<div class="round"><div class="circle"></div><div class="circle_bottom animation "></div><div class="circle_bottom2 animation2 "></div></div>'
        });


        this.makerM = (L as any).movingMarker(_this.trackLine[0].devicePoints[0], {
          destinations: _this.trackLine[0].devicePoints.map((item, index, array)=>{
            return {
              //latLng: item.step,
              latLng: item,
              duration: 1200,//duration
              //bearing: item.bearing,
            };
          }),
          // destinations: _this.locations.map(function(item, index, array) {
          //   var trackPoints = _this.trackLine[0].devicePoints;
          //   console.log(item.recorded_at_ms - array[index - 1].recorded_at_ms)
          //   //var duration = index === 0 ? 1000 : item.recorded_at_ms - array[index - 1].recorded_at_ms;
          //   return {
          //     //latLng: item.step,
          //     latLng: trackPoints[index],
          //     duration: 500,//duration
          //     //bearing: item.bearing,
          //   };
          // }),
          icon: icon,
          zIndexOffset:600
        });
        this.makerM.addTo(this.map);
        this.makerM.pause();
        this.playIcon = 'el-icon-caret-right';
        this.playTips = this.$tc("records.playFootfall");

        //this.makerM.on('start', function() {
          //icon.rotate(_this.locations[0].bearing);
        //});
        this.makerM.on('destination', function(destination) {
          // if (destination.bearing !== undefined) {
          //   icon.rotate(destination.bearing);
          // }
        });
        //this.makerM.start();
        this.makerM.on('destinationsdrained', function(e) {
          console.log('done');
          _this.selectFloor(true);
          _this.makerM.isPaused = true;
          _this.playIcon = 'el-icon-caret-right';
          _this.playTips = _this.$tc("records.playFootfall");
        });
      }

  }

  selectDate(data:any) {
    console.log(data);
    let _this = this;
    _this.noMapbg = false;
    let imgObj = new Image();

    if(!data.mapUrl){
      _this.noMapbg = true;
      _this.mapSet.bgUrl ='/images/floor00.png';
    }else{
      _this.mapSet.bgUrl = data.mapUrl;
      imgObj.onerror = (v) => {
        _this.noMapbg = true;
        _this.mapSet.bgUrl ='/images/floor00.png';
      }

    }


    imgObj.src = data.mapUrl;
    this.hidePopover(this.currentPopover);

    this.floorId = data.floorId;
    // if(this.showPopover){
    //   this.showPopover = false;
    // }
    this.current=null;
    let param = {
      // dayTime:data.date,
      // uuidSerial:this.uuidSerial
      timeKey:data.timeKey
    }
    this.timeKey = data.timeKey;
    this.trackLine =[];
    //this.selectDayTime = data.date;
    api_history.getTrackDay(param).then((resp:any)=>{
      //this.trackPic = resp.floorImageNumberList;
      this.trackPic = resp.trajectorHeatMap.deviceImageNumber;
      this.trackPic.map((item,i)=>{
        //item.imageUrl = `${host}/${item.imageUrl}`;
        item.imageUrl = `${item.viewImageUrl}`;
      })

      //轨迹点位去重

      function removeRepetition(list){
        let x = list[0][0],y= list[0][1];
        let result:string[][] = [];
        result.push(list[0]);
        for(let i = 1;i<list.length;i++){
          let tx = list[i][0],ty=list[i][1];
          if(tx !=x || ty!=y){
            result.push(list[i]);
            x = tx;
            y = ty;
          }
        }
        return result
      }
      let trackPoints = removeRepetition(resp.trajectorHeatMap.doubleList);

      let trackObj = {
        id:1,
        devicePoints:trackPoints,
        visible:true
      }
      //this.trackLine.devicePoints = resp.trajectorHeatMap.doubleList;


      //console.log(this.trackLine)
      this.trackLine =[trackObj];
      console.log(this.trackLine)

      // this.trackLine.map((item,i)=>{
      //   item.id = i;
      //   if(i =='0'){
      //     item.visible = true;
      //   }else{
      //     item.visible = false;
      //   }
      // })

      this.deviceList = [];
      let deviceIcon = markerIcon.default;

      this.trackLine[0].visible =true;
      resp.trajectorHeatMap.deviceBasisInfoList.map((item,i)=>{
        // let pointStr = item.points.substring(1,item.points.length-1);
        // let pointArr = pointStr.split(',');
        let newJson = {
          id:i,
          deviceName:item.deviceName,
          deviceId:item.deviceId,
          isShow:false,
          icon:deviceIcon,
          position :{
            lng:item.points[1],
            lat:item.points[0],
          }
        }
        this.deviceList.push(newJson)
      })
    }).then(()=>{
      //console.log(this.deviceList);
      this.currentPopover = 0;
      if(this.deviceList.length > 1){
        this.selectFloor(true);
      }else{
        this.selectFloor(false);
      }
    })

    this.trackData.map((item)=>{
      if(item.id == data.id){
        item.visible=true
      }else{
        item.visible=false
      }
    });
  }
  // getFloorDeviceList(){
  //   this.deviceList = [];
  //   api_device.floorDeviceList({id:this.floorId}).then((resp)=>{
  //     resp.data.map((item,i)=>{
  //       //console.log(item,i)
  //       let pointStr = item.point.substring(1,item.point.length-1);
  //       let pointArr = pointStr.split(',');
  //       let deviceIcon = markerIcon.default;
  //       if(item.accessState =='0'){
  //         deviceIcon = markerIcon.offLine
  //       }
  //       let newJson = {
  //         id:item.deviceId,
  //         deviceId:item.deviceId,
  //         name : "名称："+item.deviceName+"<br>设备id："+item.deviceId,
  //         isShow:false,
  //         icon:deviceIcon,
  //         position :{
  //           lng:pointArr[1],
  //           lat:pointArr[0],
  //         }
  //       }
  //       this.deviceList.push(newJson)
  //     })
  //   })
  //   //console.log(this.deviceList)
  // }

  showAll(e){
    if(!this.selectAll){
      this.trackData.map((item)=>{
        item.visible=false
      });
    }else{
      this.trackData.map((item)=>{
        item.visible=true
      });
    }
  }
  trackInit(){
    function rand(n) {
      let max = n + 0.01
      let min = n - 0.01
      return Math.random() * (max - min) + min;
    }

    //轨迹图
    //var antLatlngs:any = [[290,572],[442,714],[620,756],[814,752],[1004,542],[1314,510]]

    // var marker5 = new L.Marker.MovingMarker(antLatlngs,10000, {autostart: true}).addTo(this.map);
    // console.log(marker5)

    // marker5.addStation(1, 2000);
    // marker5.addStation(2, 2000);
    // marker5.addStation(3, 2000);
    // marker5.addStation(4, 2000);

    //L.polyline(antLatlngs,{color: 'green'}).addTo(this.map);
  }

  onSubmit() {
    this.$message('submit!');
  }
  alert(e){
    console.log(e)
  }

  onCancel() {
    this.$message({
      showClose:true,
      message: 'cancel!',
      type: 'warning',
    });
  }
}
</script>
<style rel="stylesheet/scss" lang="scss" >
@import "src/assets/style/leaflet.scss";
.track-wrapper{
  display: flex;
  background: #f5f7fc;
  width: 100%;
  position: relative;
  top: -16px;
  .track-select{
    width: 280px;
    padding: 8px;
    display: flex;
    max-height: 562px;
    .track-tree{width: 100%}
    .el-tree{
      border: 1px solid #c2cad8;
      height: 100%;
      overflow-y: auto;
      .el-tree-node__content{
        background-color: #eaf4ff;
        border-bottom: solid 1px #c2cad8;
        height: 32px;
        line-height: 32px;
        position: relative;
        padding-right: 32px;
        -webkit-user-select:none;
        -moz-user-select:none;
        -ms-user-select:none;
        user-select:none;
        &:hover{
          background-color: #d2dbea;
          .el-tree-node__label::before{color: #f00}
        }
        .el-tree-node__label{padding-left: 4px;}
        .el-tree-node__label::before{
          content: " · ";
          font-family: "SimSun";
          color:#2a5af5;
        }

      }
      .is-current{
        .el-tree-node__content{
          background-color: #d2dbea;
          .el-checkbox{
            .el-checkbox__inner::before{
              content: "\e65b";
            }
          }

        }
      }
      .el-tree-node__expand-icon.is-leaf{
        display: none;
      }
      .el-checkbox{
        position: absolute;
        right: 0;
        top: 0;
        .el-checkbox__input{
          .el-checkbox__inner{background: none;border:none;width: 20px;height: 20px;}
          .el-checkbox__inner::after{
            content: none;
          }
          .el-checkbox__inner::before{
            font-family: "iconfont" !important;
            font-size: 20px;
            font-style: normal;
            color: #28354d;
            -webkit-font-smoothing: antialiased;
            content: "\e625";
          }

        }
        .is-checked{
          .el-checkbox__inner::before{
            content: "\e65b";
          }
        }
      }

    }
  }
  .track-pic{
    width: 160px;
    background: #d2dbea;
    padding: 16px;
    overflow-y: auto;
    // padding-left: 12px;
  }
  .track-pic ul{
    padding-left: 15px;
    width: 104%;
    li{
      position: relative;
      margin-bottom: 16px;
      color: #28354D;
      background: #EAF4FF;
      // margin-left: 10px;
      z-index: 1;
      width: 100%;
      padding:3px 8px;
      text-align: center;
      font-size: 12px;
      &::before{
        content: " ";
        height: 110%;
        position: absolute;
        opacity: 0.22;
        left: -16px;
        top: 0;
        width: 1px;
        border:1px solid #28354d;
        z-index: 0;
      }
      &:last-child{
        &::before{
          content: "";
          opacity: 0;
          z-index: 0;
        }
      }
      .list-style{
        background:#EAF4FF;
        display: inline-block;
        position: absolute;
        width: 17px;
        height: 17px;
        left: -24px;
        top: 0;
        border: 1px solid #fff;
        border-radius: 20px;
        font-size: 12px;
        font-style: normal;
        line-height: 17px;
        text-align: center;
        color: #28354D;
      }
      .button{
        position: absolute;right: 5px;top: 0;color: #fff;
        display: inline-block;font-style: normal;padding: 4px;
        display: none
      }
      .image-wrap{line-height: 0;}
      .image{width: 100%;max-height: 120px; background: #eee;min-height: 100px;}
      h6{margin: 0;text-align: left;padding: 5px 0 4px;font-weight: normal;overflow: hidden;text-overflow: ellipsis;}
      a{
        display: inline-block;
        width: 100%;
        line-height: 22px;
        text-decoration: underline;
        color: #2A5AF5;
      }
    }
    li.select{
      background: #28354d;
      color: #fff;
      .list-style{
        background:#28354d;
        color: #fff;
      }
      a{color: #23A5F7}
    }
  }

  .track-view{
    flex:1;
    position: relative;
  }
  .track-view,
  .track-pic{height: 100%;min-height: 500px;height: 562px;}
  .no-map-bg{
    position: absolute;width: 20%;height: 20%;
    top: 40%;
    left: 40%;
    // background: rgba(255,255,255,.5);
    display: flex;
    align-items: center;
    text-align: center;
    justify-content: center;
    z-index: 400;
    .no-map-bg-tips{
      position: relative;
      z-index: 401;
      opacity: 0.7;
    }
  }
  .my-div-icon{
    img{
      display: block;
      width: 30px;
      height: 30px;
      margin-left:-9px;
      margin-top: -23px;
    }
  }
  .leaflet-control-easyPrint{
    display: none;
  }
}
.round{position: relative;z-index: 1;margin-left: -6px;margin-top: -6px;}
.circle {
	background:#fff;
	border-radius:100%;
	width:13px;
	height:13px;
	z-index:999;
	text-align:center;
	top:5px;
	left:5px;
  position:absolute;
  border:2px solid #3a96e1;
  box-shadow: 0 0 3px rgba(251, 255, 213, 0.3)
}
.circle_bottom {

  background:rgba(58,150,225,0.8);
	border-radius:100%;
	width:19px;
	height:19px;
	filter:alpha(opacity=80);
	z-index:-100;
	position:absolute;
	top:2px;
	left:2px;
}
.circle_bottom2 {
	background:rgba(59, 129, 187, 0.3);
	border-radius:100%;
	width:23px;
	height:23px;
	filter:alpha(opacity=30);
	z-index:-110;
	position:relative;
}
.animation {
	-webkit-animation:twinkling 2.1s infinite ease-in-out;
	animation:twinkling 2.1s infinite ease-in-out;
	-webkit-animation-fill-mode:both;
	animation-fill-mode:both;
}
.animation2 {
	-webkit-animation:twinkling 2.1s infinite ease-in-out;
	animation:twinkling 2.1s infinite ease-in-out;
	-webkit-animation-fill-mode:both;
	animation-fill-mode:both;
}
@-webkit-keyframes twinkling {
	0% {
    opacity:0.2;
    filter:alpha(opacity=20);
    -webkit-transform:scale(1);
  }
  50% {
    opacity:0.5;
    filter:alpha(opacity=50);
    -webkit-transform:scale(1.12);
  }
  100% {
    opacity:0.2;
    filter:alpha(opacity=20);
    -webkit-transform:scale(1);
  }
}
@keyframes twinkling {
	0% {
    opacity:0.2;
    filter:alpha(opacity=20);
    -webkit-transform:scale(1);
  }
  50% {
    opacity:0.5;
    filter:alpha(opacity=50);
    -webkit-transform:scale(1.12);
  }
  100% {
    opacity:0.2;
    filter:alpha(opacity=20);
    -webkit-transform:scale(1);
  }
}
.carousel-popover{
  background: #28354D;
  border: 1px solid #28354D;
  color: #fff;
  border-radius: 2px;
  .el-icon-close{top:10px;right: 10px;position: absolute;}
  .VueCarousel{margin: 0 16px;}
  .VueCarousel-navigation-button{
    font-family: element-icons!important;
    speak: none;
    font-style: normal;
    font-weight: 400;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    vertical-align: baseline;
    display: inline-block;
    -webkit-font-smoothing: antialiased;
    color: #fff;
  }
  .VueCarousel-navigation-prev::before{
    content: "\e6de";
  }
  .VueCarousel-navigation-next::before{
    content: "\e6e0";
  }
}
.carousel-popover[x-placement^="right"]{
  margin-left: 16px;
  .popper__arrow::after,
  .popper__arrow{
    border-right-color:#28354D;
    margin-top: -100px;
  }
}
.carousel-big-img-warp{
  height: 322px;

}
.carousel-big-img{
  width: 100%;min-height: 310px;max-height: 320px;overflow: hidden;height: 310px;
  .image-slot{
    display: flex;align-items: center;justify-content: center;height: 320px;
    i{
      font-size: 18px;
      color: #c2cad8;
    }
  }
}

.carousel-small-img{width: 78px;height: 100px;border: 1px solid #28354D}
.select .carousel-small-img{border: 2px solid #2A5AF5}

.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 150px;
  margin: 0;
}
// .el-icon-close{position: absolute;cursor: pointer;right:10px;top:0;z-index: 10;}
.bottom-center{position: absolute;width: 100%;text-align: center;z-index: 400;bottom: 16px;}
</style>
