<template>
  <div class="container" style="height: 100%">
    <!--<div class="title">-->
      <!---->
    <!--</div>-->
    <el-row>
      <!--人像分组-->
      <!--<router-link target="_blank" to="/manage/rule" ><i class="el-icon-arrow-left" ></i> {{$t('rule.contRulesetBack')}}</router-link>-->
      <el-col :span="4" style="width: 304px" class="el-breadcrumb-top">
        <h2 class="side-title" style="font-size: 16px;margin: 10px 0;padding: 0;">
          <i class="iconfont icon-portrait-group"></i><span>{{$t('imagemanagement.labelLibraryGroup')}}</span>
        </h2>
      </el-col>
      <el-col :span="20" style="width: calc(100% - 304px);" class="el-breadcrumb">
        <!--操作按钮-->
        <el-col :span="12">
          <el-col v-show="showBtn" style="height: 32px;">
            <!--添加人像-->
            <el-button v-if="$permission('008308')" type="primary" icon="iconfont icon-add-user" @click="addPerson">{{$t('imagemanagement.buttonAddImage')}}</el-button>
            <!--批量操作-->
            <el-button v-if="$permission('008411') || $permission('008312')" type="primary" icon="iconfont icon-batch-handle" @click="showHandle">{{$t('imagemanagement.buttonBatch')}}</el-button>
            <!--导出人像-->
            <!--v-show="btnShow"-->
            <el-button v-if="$permission('016301')"  type="primary" icon="el-icon-upload2" @click="outPerson">{{$t('imagemanagement.buttonExport')}}</el-button>
            <!--批量上传-->
            <el-button v-if="$permission('018301') && $permission('018302')" type="primary" icon="iconfont icon-upload-copy" @click="updataInfo">{{$t('imagemanagement.buttonBulkUpload')}}</el-button>
            &nbsp;
          </el-col>
          <el-col v-show="!showBtn" style="height: 32px;">
            <i @click="comeHome" class="iconfont icon-fanhui"></i>
            <!--添加到分组-->
            <el-button v-if="$permission('008312')" type="primary" icon="iconfont icon-add-group" @click="showAddGroup">{{$t('imagemanagement.buttonAddtoGroup')}}</el-button>
            <!--删除-->
            <el-button v-if="$permission('008411')" type="danger" icon="iconfont icon-delete" @click="showportaDelete(arr,2)">{{$t('imagemanagement.buttonDelete')}}</el-button>
          </el-col>
        </el-col>
        <!--操作按钮-->
        <!--文字提示-->
        <el-col :span="7" class="center" style="height: 32px;">
          <!--人像数量-->
            <span>{{$t('imagemanagement.contTotalImage',{number:total})}}</span><i class="iconfont icon-separator"></i>
          <!--批量上传失败数量-->
            <span class="error" @click="openPortraitFail">{{$t('imagemanagement.contUploadFail',{number:failCount})}}</span>
          <!--人像库同布-->
            <span style="text-decoration:underline;cursor:pointer;margin-left:16px;" class="error" v-if="$permission('008120')" @click="showPortraitAsyncDialog=true" > {{$t('imagemanagement.contAsyncFailNumber',{number:asyncFilterNumber})}}</span>
        </el-col>
        <!--文字提示-->
        <!--搜索按钮-->
        <el-col :span="4">
          <el-input class="inp-search"
                    @focus="inputFocus"
                    @blur="inputBlur"
            :placeholder="$t('imagemanagement.labelName')+'/'+$t('imagemanagement.labelID')+'/'+$t('imagemanagement.labelDepartment')"
            v-model="keywords">
            <span class="suffix-icon" slot="suffix">
              <Icon
                v-if="showSearchClose"
                type="ele"
                size="15"
                cursor="pointer"
                name="circle-close"
                @click="clickClearKeywords"
              />
            <Icon
              size="15"
              cursor="pointer"
              name="search"
              style="color: #000"
              @click="onKeywordsChange"
            />
          </span>
          </el-input>
        </el-col>
        <!--搜索按钮-->
        <el-col :span="1">
             <i @click="changeList(1)" class="iconfont icon-view-list" :style="!showList ? 'color: #2a5af5' : 'color:#b3c1d2'"></i>
             <i @click="changeList(2)" class="iconfont icon-preview-img" :style="showList ? 'color: #2a5af5' : 'color:#b3c1d2'"></i>
        </el-col>
      </el-col>
    </el-row>
    <el-row v-loading="loading" style="height: calc(100% - 58px)">
      <!--左边树的组件-->
      <el-col :span="4" style="height: 100%;width:304px">
        <LeftTree :treeData="treeData" @clickVal="clickVal"
                  :leftTreeData="leftTreeData"
                  :topKeyWords="clearLeftKeywords"
                  @filterNode="filterNode"
                  @inpFocus="searchLibraries"
                  @showDetail="showDetail"
                  @addData="addData"
                  @updateData="updateData"
                  @deleteData="deleteData">
        </LeftTree>
      </el-col>
      <!--左边树的组件-->
      <!--右边数据列表-->
      <el-col class="imgList" :span="20" style="height: calc(100% - 40px);width: calc(100% - 304px);">
          <el-row  v-show="showList" style="width: 100%;height:  calc(100% - 54px);background-color: #fff;overflow: auto;">
            <el-row class="search-top" v-show="!showSelect">
              <el-col :span="6" class="createTime" style="text-align: center">{{$t('imagemanagement.contTimeCreation')}}: </el-col>
              <el-col :span="18">
                <!--<el-input class="search-time" placeholder="点击设置时间段"></el-input>-->
                <el-date-picker
                  v-model="time"
                  @change="timeChange"
                  size="mini"
                  type="datetimerange"
                  range-separator="-"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :start-placeholder="$t('visitor.visitorlist.labelStartTime')"
                  :end-placeholder="$t('visitor.visitorlist.labelEndTime')">
                </el-date-picker>
              </el-col>
            </el-row>
            <el-row class="selectAll" v-show="showSelect">
              <!--全选-->
              <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">{{$t('rule.listDeviceAll')}}</el-checkbox>
            </el-row>
             <el-col class="item" @click.native="showInfo(item.targetId,$event)" v-if="tableData.length > 0" v-for="(item,index) in tableData" :key="index">
               <el-checkbox-group v-model="portraitOption" @change="handleCheckedChange">
                <el-col>
                </el-col>
                <el-col class="people pic" :style="{'backgroundImage': 'url(' + processImgurl(item.imageUrl) + ')'}"></el-col>
                <el-col class="people info">
                  <el-col style="overflow: hidden;white-space:nowrap;text-overflow: ellipsis;">{{$t('imagemanagement.labelName')}}:{{item.name}}</el-col>
                  <el-col style="overflow: hidden;white-space:nowrap;text-overflow: ellipsis;">{{item.ID}}</el-col>
                  <el-col v-show="showSelect" class="check"><el-checkbox class="chess" :label="item.targetId" :key="item.targetId"></el-checkbox></el-col>
                </el-col>
               </el-checkbox-group>
             </el-col>
        </el-row>
        <el-row  v-show="!showList" style="width: 100%;height:  calc(100% - 54px);">
          <el-table v-show="!showList"
                    stripe
                    :data="tableData"
                    style="height: 100%;width:100%;"
                    @filter-change="tableFilterChange"
                    @selection-change="handleSelectionChange"
                    :row-style="rowClass"
                    ref="tables"
                    @sort-change="dateSort">
            <el-table-column v-if="showSelect"
                             type="selection"
                             width="55">
            </el-table-column>
            <el-table-column
              prop=""
              label=" "
              width="30">
            </el-table-column>
            <el-table-column
              prop=""
              :label="$t('imagemanagement.labelImage')"
              width="70">
              <template slot-scope="scope">
                <img height="80px" width="60px" :src="processImgurl(scope.row.imageUrl)" alt="">
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              prop="name"
              :label="$t('imagemanagement.labelName')"
              width="120">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              prop="ID"
              :label="$t('imagemanagement.labelID')"
              width="120">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--部门-->
            <el-table-column
              prop="dept"
              :label="$t('imagemanagement.labelDepartment')"
              width="100">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
           <!--添加时间-->
            <el-table-column
              prop="createTime"
              :label="$t('imagemanagement.labelTimeAddition')"
              sortable="custom"
              width="154">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--激活状态-->
            <el-table-column
              v-if="libraryType == 1"
              prop="activeState"
              column-key="activeState"
              :filter-multiple="false"
              :filters="[{text:$t('imagemanagement.contActiveStatusActivated') , value:1}, {text: $t('imagemanagement.contActiveStatusExpired'), value: 2},{text: $t('imagemanagement.contActiveStatusInvalid'), value: 3}]"
              :label="$t('imagemanagement.contActiveStatus')"
              width="150">
              <template slot-scope="scope" v-if="libraryType == 1">
                <span
                  :style="{color:scope.row.enableState === 2?'#6D7C96':scope.row.activeState === 1?'#31D500':scope.row.activeState === 2?'#6D7C96':'#FC3D1A'}"
                  close-transition>{{scope.row.activeState === 1?$t('imagemanagement.contActiveStatusActivated'):scope.row.activeState === 2?$t('imagemanagement.contActiveStatusExpired'):$t('imagemanagement.contActiveStatusInvalid')}}</span>
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--激活时间-->
            <el-table-column
              v-if="libraryType == 1"
              prop="activationTime"
              :label="$t('imagemanagement.contTimeActivation')"
              width="154">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--失效时间-->
            <el-table-column
              v-if="libraryType == 1"
              prop="expirationTime"
              :label="$t('imagemanagement.contTimeExpiration')"
              width="154">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--启用状态-->
            <el-table-column
              v-if="libraryType == 1"
              prop="enableState"
              column-key="enableState"
              :filter-multiple="false"
              :filters="[{text: $t('usermanagement.buttonEnable'), value: '1'}, {text: $t('usermanagement.listStatusDisabled'), value: '2'}]"
              :label="$t('imagemanagement.EnabledAndDisabled')"
              width="150">
              <template slot-scope="scope">
                <el-switch
                  :disabled="!$permission('008318')"
                  @change="updateStates(scope.row)"
                  v-model="scope.row.enableState === 1"
                  active-color="#13ce66"
                  inactive-color="#ff4949">
                </el-switch>
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              width="112"
              :label="$t('imagemanagement.labelOperation')">
              <template slot-scope="scope">
                <!--查看-->
                <span v-if="$permission('008107')" class="rule-list-operation-item"  @click="showInfo(scope.row.targetId,$event)">
                  <i class="iconfont icon-view"  ></i>
                </span>
                <!--编辑-->
                <span v-if="$permission('008209')" class="rule-list-operation-item"  @click="showportaEdit(scope.row.targetId)">
                  <i class="iconfont icon-edit"  ></i>
                </span>
                <!--删除-->
                <span v-if="$permission('008410')" class="rule-list-operation-item"  @click="showportaDelete(scope.row,1)">
                  <i class="iconfont icon-delete"></i>
                </span>
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              min-width="30">
            </el-table-column>
          </el-table>
          <!--<el-pagination-->
            <!--class="page"-->
            <!--@size-change="handleSizeChange"-->
            <!--@current-change="handleCurrentChange"-->
            <!--:current-page="page"-->
            <!--:page-sizes="[10, 20, 30, 50,100]"-->
            <!--:page-size="size"-->
            <!--layout="total, sizes, prev, pager, next, jumper"-->
            <!--:total="total">-->
          <!--</el-pagination>-->
        </el-row>
        <el-pagination
          class="page"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="page"
          :page-sizes="[10, 20, 30, 50,100]"
          :page-size="size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
        </el-pagination>
      </el-col>
      <!--右边数据列表-->
    </el-row>
    <!--分组详情组件-->
    <groupDetails :dataObj="groupDetailsObj" :dialogVisible="data.dialogVisible1" @closeDetails = "closeDetails"></groupDetails>
    <!--分组详情组件-->
    <!--编辑组件-->
    <groupEdit :dataObj="groupActionObj" :groupInfo="groupDetailsObj" :dialogVisible="data.dialogVisible2" @handleGroupAction="handleGroupAction" @closeEdit="closeEdit"></groupEdit>
    <!--编辑组件-->
    <!--删除分组组件-->
    <groupDelete :dataObj="groupActionObj" :dialogVisible="data.dialogVisible3" @handleGroupAction="handleGroupAction" @closeDelete="closeDelete"></groupDelete>
    <!--删除分组组件-->
    <!--添加分组组件-->
    <groupAdd :dataObj="groupActionObj" :treeData="propTreeData" :dialogVisible="data.dialogVisible4" @handleGroupAction="handleGroupAction" @closeAdd="closeAdd"></groupAdd>
    <!--添加分组组件-->
    <!--添加人像组件-->
    <PortraitAdd :libraryId="libraryId" :dialogVisible="data.showPortrait" :treeData="propTreeData" @inIt="showPortraitList" @closePortraitAdd="closePortraitAdd"></PortraitAdd>
    <!--添加人像组件-->
    <!--导出人像组件-->
    <PortraitOut :dialogVisible="data.showOut" :libraryType="libraryType" :sort="sort" :keywords="keywords" :total="total" :libraryId="libraryId" @closePortraitOut="closePortraitOut"></PortraitOut>
    <!--导出人像组件-->
    <!--批量上传组件-->
    <PortraitUpData :leftTreeData="propTreeData" :dialogVisible="data.showUpdata" @closePortraitUpData="closePortraitUpData"></PortraitUpData>
    <!--批量上传组件-->
    <!--人像详情页-->
    <portraitDetails :libraryType="libraryType" :treeData="addGroupObj" :portraitInfo="portraitData" :targetId="targetId" :libraryId="libraryId" :dialogVisible="data.showDetails" :treeList="propTreeData" @getPortraitDetails="getPortraitDetails" @inIt="showPortraitList" @closePortraitDetails="closePortraitDetails"></portraitDetails>
    <!--人像详情页-->
    <!--人像编辑-->
    <portraitEdit :dataObj="portraitData" :treeData="propTreeData" :libraryType="libraryType" :libraryId="libraryId" :dialogVisible="data.showPortraitEdit" @closePortraitEdit="closePortraitEdit" @showPortraitList="showPortraitList"></portraitEdit>
    <!--人像编辑-->
    <!--人像删除-->
    <portraitDelete :dialogVisible="data.showPortraitDelete" :libraryId="libraryId" :dataObj="deleteObj" @handleDeletePortrait="handleDeletePortrait" @closePortraitDelete="closePortraitDelete"></portraitDelete>
    <!--添加到分组-->
    <AddPersonGroup :type="libraryType" :propTreeData="propTreeData" :dialogVisible="data.showPortraitAddGroup" :dataObj="addGroupObj" :idArr="addGroupIdArr" @closeEdit="closeAddGroup" @handleActive="handleAddGroup"
    ></AddPersonGroup>
    <!--添加到分组-->
    <!--上传入库失败-->
    <portraitFail :failCount="failCount" @init="findProtraitUpFailCount" :dialogVisible="data.showPortraitFail" :btnShow="btnShow" :libraryType="libraryType" :libraryId="libraryId" @closePortraitFail="closePortraitFail"></portraitFail>
    <!--上传入库失败-->
    <!-- 人像库同步情况 -->
    <PortraitAsync :dialogVisible="showPortraitAsyncDialog" @close="showPortraitAsyncDialog=false" />
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch } from 'vue-property-decorator';

  import LeftTree from '@/components/leftTree/personLeftTree.vue';

  import groupDetails from './portraitGroup/groupDetails.vue';
  import groupEdit from './portraitGroup/groupEdit.vue';

  import groupDelete from './portraitGroup/groupDelete.vue';

  import groupAdd from './portraitGroup/groupAdd.vue';

  import PortraitAdd from './portraitHandle/portraitAdd.vue';

  import PortraitOut from './portraitHandle/portraitOut.vue';

  import PortraitUpData from './portraitHandle/portraitUpdata.vue';
  import {Tree as ElTree} from 'element-ui';
  // import PortraitUpData from './portraitHandle/testUpdata.vue';
  import {EventBus} from '@/utils/eventbus';
  import portraitDetails from './portraitHandle/portraitDetails.vue';

  import portraitEdit from './portraitHandle/portraitEdit.vue';

  import portraitDelete from './portraitHandle/portraitDelete.vue';

  import AddPersonGroup from '@/components/addPersonGroup/index.vue';

  import portraitFail from './portraitHandle/portraitUpFail.vue';

  import {PortraitModule} from '@/store/modules/portrait';

  import {isEmpty} from '@/utils/validate';

  import Icon from '@/components/icon-wrap/index.vue';

  import {AppModule} from '@/store/modules/app';

  import {processImgurl} from '@/utils/image.ts';

  import PortraitAsync from './portraitHandle/portraitAsync.vue';
  import api from '@/api/portrait';
  @Component({
    components: {
      LeftTree,      //树状图
      groupDetails,//详情页
      groupEdit,   //编辑页
      groupDelete,  //删除页
      groupAdd,     //添加分组页
      PortraitAdd,  //添加人像
      PortraitOut,  //导出人像
      PortraitUpData, // 批量上传
      portraitDetails, //人像详情
      portraitEdit,     //人像编辑
      portraitDelete,    //人像删除
      AddPersonGroup,    //人像添加
      portraitFail,   //上传入库失败
      Icon,  //搜索按钮
      PortraitAsync
    }
  })
  export default class Portrait extends Vue {
    get language() {
      return AppModule.language;
    }
    //data-start
    focusEnter = false;
    loading = false;
    showSearchClose = false
    btnShow = false;//黑白名单不支持导出
    page = 1;
    size = 10;
    sort = 'DESC';
    state = null;
    enableState = null;
    keywords= "";
    clearLeftKeywords= '';
    time = null as any;
    total = 0;
    showList = false;
    showBtn = true;
    showSelect = false;
    isIndeterminate = false;
    checkAll = false;
    processImgurl:any = processImgurl;
    data = {
        dialogVisible1:false, //详情页
        dialogVisible2:false, //编辑页
        dialogVisible3:false, //删除页
        dialogVisible4:false, //添加分组页
        showPortrait:false,   //添加人像页
        showOut:false,        //导出弹框
        showUpdata:false,     //批量上传弹框
        showDetails:false,    //展示人像详情
        showPortraitDelete:false, //展示人像详情删除
        showPortraitGroup:false,  //展示人像详情分组
        showPortraitEdit:false,  //展示人像编辑
        showPortraitAddGroup:false, //展示添加分组
        showPortraitFail:false   //展示人像上传入库失败
      };
    tableData = [] as any;//人像库列表数据
    addGroupObj = {} as any;
    addGroupIdArr = [] as any;
    treeData = [
      {
      id: 1,
      libraryName: '白名单',
      children: []
      },
      {
      id: 2,
      libraryName: '黑名单',
      children: []
    }];
    propTreeData = [
      {
        id: 1,
        libraryName: '白名单',
        children: []
      },
      {
        id: 2,
        libraryName: '黑名单',
        children: []
      }];
    leftTreeData={
      label:'libraryName',
      actionArray: [1, 1, 1, 1, 1] //设备树的按钮显示影藏 创建同级 创建下一级 详情 重命名 分组
    } as any;
    // token = "";
    groupActionObj = {
      title: '',
      type: ''
    } as any;
    groupDetailsObj = {} as any;
    targetId = 0;
    portraitData = {} as any;
    libraryId = null as any;
    storeLibraryId = null as any;
    treeList = {} as any;
    deleteObj = {
       title:"",
       type: ""
    } as any;
    type = 1;
    multipleSelection = [] as any;
    libraryType = 1 as any;
    portraitOption = [] as any;
    arr = [] as any;
    detailsData = [] as any;//上传失败信息
    failCount = 0 as any;//上传失败条数
    // host = 'http://aurora.com/' as any;
    host = window.globalConfig.host  + '/' as any;

    $refs !:{
      tables:HTMLFormElement
    };
    showPortraitAsyncDialog:boolean=false;

    @Watch('language')
    onLanguageChange(val: any) {
      this.searchLibraries();
      this.searchPorpLibraries();
    }
    @Watch('libraryType')
    onLibraryTypeChange(val: any) {
      if (val == 2){
        this.state = null;
        this.enableState = null;
      }
    }
    @Watch('keywords')
    onKwordChange(val: any) {
      if (!isEmpty(val)) {
        this.showSearchClose = true
      }
      if (val == ''){
        this.clickClearKeywords();
      }
    }

    inputFocus(){
      this.focusEnter = true;
      let that = this as any;
      window.document.onkeydown = function(event){
        if (that.focusEnter) {
          if (event.keyCode == 13){
            that.onKeywordsChange();
          }
        }
      }
    }

    inputBlur(){
      this.focusEnter = false;
    }


    // @Watch("keywords")
    onKeywordsChange() {
      this.page = 1;
      this.libraryId = null;
      this.libraryType = 1;
      if (this.keywords == ''){
        this.clearLeftKeywords = '';
      } else{
        this.clearLeftKeywords = this.keywords;
      }

      EventBus.$emit('search-person');

      //搜索时，再次请求左边树列表
      this.searchLibraries();
      this.showPortraitList();
    }
    asyncFilterNumber:number=0;
    //挂载时期
    mounted(){
      let that = this as any;
      that.leftTreeData.actionArray = [that.$permission('008303'), that.$permission('008303'), that.$permission('008102'), that.$permission('008204'), that.$permission('008405')];
      this.searchLibraries();
      this.searchPorpLibraries();
      this.showPortraitList();
      this.findProtraitUpFailCount();
      this.$permission('008120') && this.getAsyncFailNumber();
    }
    getAsyncFailNumber(){
      api.getPortraitAsyncImages({page:1,size:1}).then((res:any)=>{
        res && (this.asyncFilterNumber = res.total);
      }).catch(err=>{
        this.asyncFilterNumber=0;
      })
    }
    //时间排序
    dateSort(val){
      console.log(val);
      // if (val.prop == 'activationTime') {
        if(val.order == 'ascending'){
           this.sort = "ASC";
        }else if(val.order == 'descending'){
            this.sort = 'DESC';
        }else{
          this.sort = 'DESC';
        }
      // }
      this.page = 1;
      this.showPortraitList();
    }
    //激活状态
    tableFilterChange(filter){
      console.log(filter)
      let condition = Object.keys(filter)[0];
      let num = '' as any;
      if(condition == 'activeState'){
        num = filter['activeState'][0];
        this.state = num;
      }
      if(condition == 'enableState'){
        this.enableState =  filter['enableState'][0];
      }
      this.showPortraitList();
    }
    //删除人像方法
    handleDeletePortrait(deleteObj : any){
      let that = this as any;
      let dataObj = {} as any;
      if(deleteObj.title == "分组删除"){
        this.type = 1;
      }
      if(deleteObj.title == "人像库删除"){
        this.type = 2;
      }
      if(deleteObj.type == "单个删除"){
        dataObj.params = {
          libraryId: this.libraryId,
          type: this.type
        };
        dataObj.id = this.targetId;
        // this.multipleSelection.forEach((item)=>{
        //   dataObj.id.push(item.targetId);
        // })

        PortraitModule.ProtraitDelete(dataObj).then((data: any) => {
          console.log("列表数据",data);
          this.showPortraitList();
          this.$message({
            showClose: true,
            // message: "删除人像成功",
            message: that.$t('globaltip.tipmsgDeleteImage'),
            type: 'success'
          })
        }).catch((err) => {

        });
      }else if(deleteObj.type == "批量删除"){
        let arr = [] as any;
        dataObj.params = {
          libraryId: this.libraryId,
          type: this.type
        };
        if(this.multipleSelection === this.arr){
          this.deleteObj.data.forEach((item:any)=>{
            arr.push(item.targetId);
            dataObj.params.targetIds = arr;
          })
        }else{
          dataObj.params.targetIds = this.arr;
        }
        PortraitModule.ProtraitDeleteAll(dataObj).then((data: any) => {
          console.log("列表数据",data);
          this.isIndeterminate = false;
          this.showPortraitList();
          this.$message({
            showClose: true,
            // message: "所选人像删除成功",
            message: that.$t('globaltip.tipmsgBatchImageDelete'),
            type: 'success'
          })
        }).catch((err) => {

        });
      }
    }
    //全选操作
    handleCheckAllChange(val) {
      let targetIds = [] as any;
      this.tableData.forEach((item)=>{
         targetIds.push(item.targetId);
      })
      console.log(targetIds)
      this.portraitOption = val ? targetIds : [];
      this.isIndeterminate = false;
      this.arr = this.portraitOption;
      this.addGroupIdArr = this.portraitOption
    }
    //单选操作
    handleCheckedChange(value) {
      let checkedCount = value.length;
      this.checkAll = checkedCount === this.tableData.length;
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.tableData.length;
      this.arr = this.portraitOption;
      this.addGroupIdArr = this.portraitOption
    }
    handleSelectionChange(val) {
      this.addGroupIdArr = [];
      this.multipleSelection = val;
      this.arr = this.multipleSelection;
      for(let i = 0;i <val.length;i++){
        this.addGroupIdArr.push(this.arr[i].targetId - 0)
      }
      console.log(this.addGroupIdArr,'选中的人像ID')
    }
    comeHome(){
      this.addGroupIdArr = [];
      this.arr = [];
      this.portraitOption = [];
      this.checkAll = false;
      this.$refs.tables && this.$refs.tables.clearSelection();
      this.showBtn = true;
      this.showSelect = false;
    }
    //点击左边树操作
    clickVal(localData: any){
      console.log(localData);
      // this.keywords = '';
      this.libraryId = localData.libraryId;
      if (localData.children || localData.children == null){
        this.libraryType = localData.id;
        this.btnShow = false;
      }
      if (localData.libraryType == 1){
        this.libraryType = 1;
        this.btnShow = true;
      }
      if (localData.libraryType == 2){
        this.libraryType = 2;
        this.btnShow = true;
      }
      console.log(this.libraryType)
      this.page = 1;
      this.showPortraitList();//展示人像库列表
      this.findProtraitUpFailCount();//查询上传失败数量
    }
    //展示左边树列表
    searchLibraries(){
      let that = this as any;
      // this.loading = true;
      let params = {} as any;
      if (this.keywords != ''){
        params.searchType = 2
        params.keywords = this.keywords;
      }
      PortraitModule.SearchLibraries(params).then((data: any) => {
        console.log('debugger',data)
        // this.loading = false;
        this.treeList = data;
        if(!data){
          return;
        }
        if(data != null && data.whitelists != null) {
          for (let i = 0; i < data.whitelists.length; i++) {
            data.whitelists[i].libraryType = 1
          }
        }
        if(data != null && data.blacklists != null){
          for(let i = 0;i < data.blacklists.length;i++){
            data.blacklists[i].libraryType = 2
          }
        }
        this.treeData[0].children = data.whitelists;
        this.treeData[0].libraryName = that.$t('imagemanagement.contWhiltelist');
        this.treeData[1].children = data.blacklists;
        this.treeData[1].libraryName = that.$t('imagemanagement.contBlacklist');
        console.log(data.whitelists)
        if(!isEmpty(data.whitelists) && data.whitelists.length != 0){
          // this.libraryId = data.whitelists[0].libraryId;
          this.storeLibraryId = data.whitelists[0].libraryId;
        }
        this.addGroupObj.data = this.treeData;
        console.log('addGroupObj',this.addGroupObj)
      }).catch((err) => {
        //报错
        // this.loading = false;
      });
    }
    //获取默认左边树列表
    searchPorpLibraries(){
      let that = this as any;
      let params = {} as any;
      PortraitModule.SearchLibraries(params).then((data: any) => {
        //console.log('searchPorpLibraries',data)
        this.treeList = data;
        if(!data){
          return;
        }
        if(data != null && data.whitelists != null) {
          for (let i = 0; i < data.whitelists.length; i++) {
            data.whitelists[i].libraryType = 1
          }
        }
        if(data != null && data.blacklists != null){
          for(let i = 0;i < data.blacklists.length;i++){
            data.blacklists[i].libraryType = 2
          }
        }
        this.propTreeData[0].children = data.whitelists;
        this.propTreeData[0].libraryName = that.$t('imagemanagement.contWhiltelist');
        this.propTreeData[1].children = data.blacklists;
        this.propTreeData[1].libraryName = that.$t('imagemanagement.contBlacklist');
      }).catch((err) => {
        //报错

      });
    }

    //展示人像库列表
    showPortraitList(){
      let that = this as any;
      this.loading = true
      let params = {
          libraryId:this.libraryId,
          page:this.page,
          size:this.size,
          sort:this.sort,
          enableState:this.libraryType == 1?this.enableState:null,
          activeState:this.libraryType == 1?this.state:null,
          libraryType:this.libraryType,
          keywords:this.keywords,
      } as any;
      if(this.time){
        params.startTime = this.time[0];
        params.endTime = this.time[1];
      }
      PortraitModule.GetPortraitList(params).then((data: any) => {
        this.loading = false

        if (data.data){
          this.tableData = data.data;
          this.tableData.forEach((item)=>{
            // item.imageUrl = this.host + item.imageUrl;
            // console.log(item.imageUrl)
            item.state = item.activeState == 1?that.$t('usermanagement.listStatusEnabled')//'激活'
             :that.$t('usermanagement.listStatusDisabled')//'禁用';
            // if (item.expirationTime == "3019-02-13 00:00:00") {
            //  item. expirationTime = '';
            // }
          })
        }else{
          this.tableData = [];
        }
        console.log("列表数据",this.tableData);
        this.total = data.total;
        // this.token = JSON.parse((localStorage as any).getItem("accessToken")).value;
        if(!this.tableData){
          return;
        }
        for(let i=0;i<this.tableData.length;i++){
          this.tableData[i].imageUrl = this.tableData[i].imageUrl;
        }
      }).catch((err) => {
        this.loading = false
      });
    }

    //添加人像库分组接口
    handleGroupAction(obj, valueData,type,front){
      let that = this as any;
      let params = {} as any;
      switch (obj.type){
        //同级添加分组
        case "addLevel":
          params.name = valueData;
          params.type = type;
          // params.extractFeature = front;//暂时屏蔽前端比对
          PortraitModule.AddPortraitNode(params).then((data: any) => {
            console.log("返回数据",data);
            if (data.code == "408003") {
              // that.$message.error('已存在相同名字的分组,请重新命名添加!');
              that.$message.error({showClose: true,message:that.$t('imagemanagement.NameRepetition')});
              return;
            }
            that.$message({
              showClose: true,
              // message: "添加同级分组成功",
              message: that.$t('devicemanagement.groupAddSuccess'),
              type: 'success'
            })
            this.searchLibraries();
            this.searchPorpLibraries();
          }).catch((err) => {

          });
          break;
        // 添加下一级分组
        case "addNext":
          params.name = valueData;
          params.type = type;
          // params.extractFeature = front;//暂时屏蔽前端比对
          PortraitModule.AddPortraitNode(params).then((data: any) => {
            if (data.code == "408003") {
              // that.$message.error('已存在相同名字的分组,请重新命名添加!');
              that.$message.error({showClose: true,message:that.$t('imagemanagement.NameRepetition')});
              return;
            }
            that.$message({
              showClose: true,
              // message: "添加下级分组成功",
              message: that.$t('devicemanagement.groupNextAddSuccess'),
              type: 'success'
            })
            this.searchLibraries();
            this.searchPorpLibraries();
          }).catch((err) => {

          });
          break;
        //修改分组
        case "edit":
          let objData = {} as any;
          objData.params = {name: valueData};
          objData.id = obj.localData.libraryId;
          PortraitModule.ReviseGroup(objData).then((data: any) => {
            if (data.code == "407003") {
              // that.$message.error('已存在相同名字的分组,请重新命名修改!');
              that.$message.error({showClose: true,message:that.$t('imagemanagement.NameRepetition')});
              return;
            }
            // that.$message({
            //   message: '修改分组成功',
            //   type: 'success'
            // })
            this.searchLibraries();
            this.searchPorpLibraries();
          }).catch((err) => {

            console.log(err)
          });
          break;
        //删除分组
        case "delete":
          // debugger
          that.loading = true
          if(obj.localData.id === 1 || obj.localData.id == 2){
            that.$message.error({showClose: true,message:that.$t('devicemanagement.defaultGroupDeleteFail')});//"默认分组,无法删除"
            return;
          }
          PortraitModule.DeleteGroups(obj.localData.libraryId).then((data: any) => {
            that.loading = false;
            that.$message({
              showClose: true,
              // message: "删除分组成功",
              message: that.$t('devicemanagement.groupDeleteSuccess'),
              type: 'success'
            })
            this.searchLibraries();
            this.searchPorpLibraries();
            this.libraryId = null;
            this.showPortraitList();
          }).catch((err) => {
            that.loading = false;
          });
          break;
      }
    }
    //搜索部门
    filterNode(){
      this.keywords = '';//清空右边关键字
    }
    //查看详情
    showDetail(localData: any) {
      console.log(localData);
      this.groupActionObj.title = "详情";
      this.groupActionObj.type = "detail";
      this.groupActionObj.localData = localData;
      this.showGroupDetails();
    }
    //查看详情接口
    showGroupDetails(){
      let that = this;
      PortraitModule.GroupDetails(this.groupActionObj.localData.libraryId).then((data: any) => {
        that.groupDetailsObj = data;
        this.data.dialogVisible1 = true;
        console.log('分组详情数据',data);
      }).catch((err) => {

      });
    }
    //关闭详情的回调
    closeDetails() {
      this.data.dialogVisible1 = false
    }
    //修改数据
    updateData(localData: any) {
      console.log(localData)
      this.data.dialogVisible2 = true;
      this.groupActionObj.title = "编辑";
      this.groupActionObj.type = "edit";
      this.groupActionObj.localData = localData;
      console.log(this.groupActionObj);
      // this.showGroupDetails();
    }
    //关闭编辑弹框
    closeEdit(){
      this.data.dialogVisible2 = false;
    }
    //关闭添加分组
    closeAddGroup() {
      this.data.showPortraitAddGroup = false
    }
    //操作分组
    handleAddGroup(data) {
      console.log(data)
    }
    //点击添加到分组
    showAddGroup(){
      let that = this as any;
      if (this.addGroupIdArr.length>0){
        this.data.showPortraitAddGroup = true;
      }else{
        this.$message({
          showClose: true,
          // message: "请先选择人像",
          message: that.$t('form.texterrSelectImage'),
          type: 'error'
        })
      }
    }
    //添加数据
    addData(flag: any,localData: any) {
      console.log(localData);
      this.data.dialogVisible4 = true;
      this.groupActionObj.title = flag == 'level' ? "添加同级分组" : "添加下级分组";
      this.groupActionObj.type = flag == 'level' ? "addLevel" : "addNext";
      this.groupActionObj.localData = localData;
      console.log(this.groupActionObj);
    }
    //关闭添加分组组件
    closeAdd(){
       this.data.dialogVisible4 = false;
    }
    //删除数据
    deleteData(localData: any) {
      console.log(localData)
      this.data.dialogVisible3 = true;
      this.groupActionObj.title = "删除"
      this.groupActionObj.type = "delete"
      this.groupActionObj.localData = localData;
      console.log(this.groupActionObj);
    }
    //关闭删除
    closeDelete(){
      this.data.dialogVisible3 = false;
    }

    //切换列表显示
    changeList(num:any){
      this.time = null;
      if(num===1){
        this.showList = false;
        this.arr = [];
        this.multipleSelection = [];
      }else{
        this.showList = true;
        this.arr = [];
        this.portraitOption = [];
      }
      this.showPortraitList();
      this.checkAll = false;
    }
    //按时间筛选人像列表展示
    timeChange(){
      this.page = 1;
      this.showPortraitList();
    }
    //添加人像弹出框
    addPerson(){
        this.data.showPortrait = true;
    }
    //关闭添加人脸
    closePortraitAdd(){
      this.data.showPortrait = false;
    }
    //点击弹出导出人像弹框
    outPerson(){
       this.data.showOut = true;
    }
    //关闭导出
    closePortraitOut(){
      this.data.showOut = false;
    }
    //点击弹出批量上传弹框
    updataInfo(){
      // this.$router.push({ path:'/manage/rule'})
      // window.open('/updata')
      let that = this as any;
      PortraitModule.protraitCheckUploadState().then((data:any)=>{
        console.log(data)
        if (data){
          this.data.showUpdata = true;
          // this.$router.push({ path:'/manage/rule'})
        } else{
          this.$message({
            showClose: true,
            message: that.$t('imagemanagement.updateTips'),
            // message: '当前已有批量上传任务进行中，请稍后重试',
            type: 'error'
          });
        }

      }).catch((err)=>{

      })
    }
    //关闭人脸上传弹框
    closePortraitUpData(){
      this.data.showUpdata = false;
    }
    //点击展示人像详情
    showInfo(targetId,event){
      if(event.target.className !== "el-checkbox__original" && event.target.className !== "el-checkbox__inner"){
        this.data.showDetails = true;
        this.targetId = targetId;
        this.getPortraitDetails();
      }else{
        this.data.showDetails = false;
      }
    }
    //查询人像详情
    getPortraitDetails(){
      let that = this;
      PortraitModule.PortraitDetails(this.targetId).then((data: any) => {
        console.log("查询人像详情",data);
        this.portraitData = data;
        // this.portraitData.imageUrl = this.host + this.portraitData.imageUrl;
      }).catch((err) => {

      });
    }
    //关闭人像详情页
    closePortraitDetails(){
      this.data.showDetails = false;
    }
    //展示编辑
    showportaEdit(targetId){
      this.data.showPortraitEdit = true;
      this.targetId = targetId;
      console.log(targetId);
      this.getPortraitDetails();
      // this.searchLibraries();
    }
    //关闭编辑
    closePortraitEdit(){
      this.data.showPortraitEdit = false;
    }
    //打开删除弹框
    showportaDelete(data,type){
      let that = this as any;
      console.log(type);
      if(type === 1){
         this.deleteObj.type = "单个删除";
        this.targetId = data.targetId;
        this.data.showPortraitDelete = true;
      }else if(type === 2){
        this.deleteObj.type = "批量删除";
        if(data.length > 0){
          this.deleteObj.data = data;
          this.data.showPortraitDelete = true;
        }else{
          this.$message({
            showClose: true,
            // message: '请选择要删除的人像',
            message: that.$t('form.texterrSelectImage'),
            type: 'error'
          });
        }
      }

    }
    //关闭删除按钮
    closePortraitDelete(){
      this.data.showPortraitDelete = false;
    }
    //分码大小处理
    handleSizeChange(val){
      this.page = 1;
      this.size = val;
      this.showPortraitList();
    }
    //当前页变动处理
    handleCurrentChange(val){
      this.page = val;
      this.showPortraitList();
    }
    //展示分组和删除按钮
    showHandle(){
       this.showBtn = false;
       this.showSelect = true;
    }
    //打开上传失败页面
    openPortraitFail(){
      //页面显示上传失败图片数量
      // let params = {} as any;
      // params.taskId = PortraitModule.taskId
      // params.pageNum = 1;
      // params.pageSize = 10;
      // PortraitModule.protraitQueryTaskList(params).then((data : any)=>{
      //   console.log(data)
      //   this.detailsData = data.dataList;
      // })
      this.data.showPortraitFail = true;
    }
    //关闭上传失败页面
    closePortraitFail(){
       this.data.showPortraitFail = false;
    }
    //查询上传失败数量
    findProtraitUpFailCount(){
      let params = {
        libraryId:this.libraryId?this.libraryId:null,
        libraryType :this.libraryType,
      } as any;
      PortraitModule.protraitUpFailCount(params).then((data:any)=>{
        console.log(data);
        this.failCount = data.failTargetCount
      })
    }

    clickClearKeywords() {
      this.keywords = '';
      this.clearLeftKeywords = '';
      this.showSearchClose = false
      this.page = 1
      this.showPortraitList();
      this.searchLibraries();
    }
    rowClass (row, index) {
      // if (row.row.enableState == 2){
      //   // return { "opacity": "0.6" }
      //   return {
      //     "color":'#6D7C96!important',
      //     "opacity": "0.3",
      //   }
      // }
    }

    //改变人像状态
    updateStates(obj) {
      console.log(obj);
      let params = {
        enableState: obj.enableState == 1?2:1,
        targetId: obj.targetId
      }
      console.log(params)
      PortraitModule.updateEnableStateByTargetId(params).then((data:any)=>{
        console.log(data);
        this.showPortraitList();
      })
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  $bg: #2d3a4b;
  $light_gray: #eee;
  .container{
    padding: 16px 24px 0;
  }
  /*.container .imgList ::v-deep .el-table__body-wrapper{*/
    /*max-height: 600px;*/
  /*}*/
  .container ::v-deep .el-col-4{
    padding-right: 16px;
  }
  .chess ::v-deep .el-checkbox__label{
     display: none;
  }
  .el-input__icon{
    margin-top: -7px;
  }
  .el-breadcrumb-top {
    padding: 20px 0px 0px 0px;
    line-height: 30px;
    font-size: 14px;
  }
  .el-breadcrumb {
    padding: 16px 0px 16px 0px;
    line-height: 30px;
    font-size: 14px;
  }
  ::v-deep .inp-search{
    padding-left: 5px;
  }
  .inp-search ::v-deep .el-input__inner{
    margin-bottom: 10px;
    padding-left: 20px;
  }
  .inp-search ::v-deep .el-input__prefix{
    left: 170px;
    width: 24px;
    top: -4px;
  }

  .inp-search ::v-deep .el-input__inner{
    margin: 0;
    height: 32px;
  }
  .map_layer {
    border: 1px dashed rgba(6, 77, 41, .5);
    height: 600px;
  }
   .center{
     text-align: left;
   }
   .error{
     color: #e72427;
     cursor: pointer;
     font-weight: 600;
     user-select: none;
     text-decoration: underline;
   }
  .leaflet-div-icon {
    border-radius: 10px;
    transform: scale(0.3);
    background: rgba(255, 204, 0, .6);
    border: 1px dotted rgba(255, 204, 0, .8);
  }
  .icon-view-list{
    font-size: 22px;
  }
  .icon-preview-img{
    font-size: 22px;
    margin-left: 10px;
  }
  .listTable{
     display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .imgList{
     display: flex;
     flex-wrap: wrap;
     position: relative;
    @include shadowBox();
  }
  .item{
    width: 120px;
    height: 238px;
    margin-left: 24px;
    position: relative;
  }
  .check{
    position: absolute;
    right: -105px;
    top: 0;
  }
  .item .people{
    width: 100%;
    font-size: 12px;
    font-family: "Helvetica";
    line-height: 20px;
  }
  .item .pic{
    height: 160px;
    background-size:cover;
    background-repeat: no-repeat;
    background-position:center;
  }
  .selectAll{
    padding:10px 25px;
  }

  ::v-deep .delete{
     /*margin: 0 36px !important;*/
  }
  ::v-deep .cancel{
    background-color:rgba(162,176,199,0.3) !important;
  }
  .content .tree ::v-deep .filter-tree{
    border: none !important;
    height: 155px;
  }
  .search-time ::v-deep .el-input__inner{
    height: 32px;
    width: 134px;
  }
  .createTime{
    line-height: 32px;
  }
  .search-top{
    padding: 10px 0;
    width: 500px;
  }
  .icon-fanhui{
    font-weight:600;
    font-size: 20px;
    margin-right: 20px;
    cursor: pointer;
  }
  ::v-deep .el-table th, .el-table td{
    padding: 10px 0 !important;
    /*text-align: center;*/
  }

  ::v-deep .el-table__body-wrapper{
    /*width: 100%;*/
    height: calc(100% - 65px);
    overflow-y: auto;
  }

  .rule-list-operation-item {
    cursor: pointer;
    margin-right: 10px;
    i.iconfont {
      font-size: 19px;
    }
  }
  ::v-deep .el-table__column-filter-trigger {
    margin-left: 10px;
    i {
      color: black;
      font-size: 16px;
    }
  }
  .container .page{
    width: 100%;
    background-color: #fff;
  }
</style>
