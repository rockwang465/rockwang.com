<template>
  <div>
    <!--导出人像弹框-->
    <el-dialog
      :class="{hidden:isHide}"
      class="dialog-custom"
      :title="$t('usermanagement.titleExport')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <div class="outNum">
        <!--导出数量-->
        <span class="num">{{$t('usermanagement.contQuantity')}}</span>
        <el-input
          @input="inputStartNum"
          v-model="startNum"></el-input>
        <span class="xian"> ~ </span>
        <el-input
          @input="inputEndNum"
          v-model="endNum"></el-input>
      </div>
      <!--提示语-->
      <div style="height: 20px;color: red;text-align: center">
        {{tipsWords}}
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="isLoading" :disabled="!startNum || !endNum" @click="exportUser">{{$t('usermanagement.buttonOK')}}</el-button>
      <el-button type="info" class="cancel" @click="dialogShowVisible = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--导出人像弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {UserModule} from '@/store/modules/user';
  @Component({

  })
  export default class userOut extends Vue {
    dialogShowVisible = false;
    startNum = "" as any;
    endNum = "" as any;
    tipsWords = '' as any;
    isHide = false;
    isLoading = false;
    @Prop(String) keywords!: any;
    @Prop(Number) orgId!: any;
    @Prop(Number) total!: any;
    @Prop(Number) state!: any;
    @Prop(String) sort!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.startNum = '';
      this.endNum = '';
      if (val){
        this.isHide = false;
      }
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeUserOut")
      }
    }

    //输入验证
    inputStartNum(val){
      if(this.verifySize(val)){
        this.startNum = val
      }else{
        this.startNum = '';
      }
    }
    //输入验证
    inputEndNum(val){
      if(this.verifySize(val)){
        this.endNum = val
      }else{
        this.endNum = '';
      }

    }
    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([1-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        this.tipsWords="";
        return true;
      }else{
        this.tipsWords= this.$t("records.exportError");
        setTimeout(()=>{
          this.tipsWords=""
        },2000)
        return false;
      }
    }

    exportUser(){
      let that = this as any;
      this.isLoading = true;
      // setTimeout(()=>{
      //   this.isLoading=false;
      // },1100)
      if (this.endNum > this.total||this.startNum > this.total){
        // this.tipsWords = '导出区间不能超过用户总条数'
        this.tipsWords = that.$t('form.texterrExport3',{number:this.total})
        setTimeout(()=>{
          this.tipsWords = '';
          this.isLoading=false;
        },2000)
        return;
      }
      //判断开始和结束的数字规范
      if(this.endNum-this.startNum>=10000){
        // this.tipsWords = '请输入规范的数字，每次支持导出10000条'
        this.tipsWords = that.$t('form.userTexterrExport1')
        setTimeout(()=>{
          this.tipsWords = '';
          this.isLoading=false;
        },2000)
        return;
      }
      if (this.endNum-this.startNum<0){
        // this.tipsWords = '导出区间不能超过人像库总条数'
        this.tipsWords = that.$t('form.texterrExport2')
        setTimeout(()=>{
          this.tipsWords = '';
          this.isLoading=false;
        },2000)
        return;
      }



      this.tipsWords = '';
      let params = {
        keywords:this.keywords,
        orgId:this.orgId,
        state:this.state,
        sort:this.sort,
        from: this.startNum,
        to: this.endNum,
        page:1,
        size:10
      }
      UserModule.ExportUserList(params).then((data: any) => {
           console.log("导出",data);
        this.$message({
          showClose: true,
          // message: "用户导出成功",
          message:that.$t('log.exportSuccess'),
          type: 'success'
        });
        this.dialogShowVisible = false;
        this.isHide = true;
        setTimeout(()=>{
          this.isHide=false;
        },1100)
        this.isLoading = false;
        this.startNum = "";
        this.endNum = "";
      }).catch((err) => {
        console.log(err)
      }).finally(() =>{
        that.isLoading = false;
      })
    }

  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .dialog-custom{
    // display:block !important;
    width:100%;
    height:100%;
  }
  .hidden {
    display: block !important;
    position: fixed;
    top: -10%;
    bottom: 110%;
    right: 5%;
    left: 95%;
    width: 0;
    height: 0;
    overflow: hidden;
    transition: all 1s;
    ::v-deep .el-dialog {
      min-width: 30%;
      min-width: 30%;
      height: 30%;
      overflow: hidden;

    }
  }

  $bg: #2d3a4b;
  $light_gray: #eee;
  .outNum{
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
  }
  .outNum span{
    margin-right: 10px;
  }
  .outNum .xian{
    margin-left: 10px;
  }
  .outNum ::v-deep .el-input{
    width: 25%;
  }
  .el-list ::v-deep .el-input__suffix{
    right: 10px !important;
    top: 3px !important;
  }
  .right-name ::v-deep .el-input{
    width: 75%;
  }
  .upFile{
    color: #2a5af5;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  ::v-deep .el-input__inner{
    height: 32px !important;
  }

  //批量的number样式
  .outNum ::v-deep  input::-webkit-outer-spin-button,
  .outNum ::v-deep  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }
  .outNum ::v-deep  input[type="number"]{
    -moz-appearance: textfield;
  }
</style>
