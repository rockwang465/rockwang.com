<template>
  <div class="rule-list-ac-container">
    <header>
      <span>  <router-link to="/manage/rule" ><i class="el-icon-arrow-left" ></i> {{$t('rule.contRulesetBack')}}</router-link> </span>
      <span> {{$t('rule.contTotal')}} <span>{{tableData.length}}</span> {{$t('rule.contRecords')}}</span>
    </header>
    <div class="rule-list-ac-table" >
      <el-table
        :data="tableData"
        :stripe="true"
        style="width: 100%">
        <el-table-column prop="ruleName" :label="$t('rule.labelRuleName')" ></el-table-column>
        <el-table-column prop="deviceName" :label="$t('rule.contDevice')" ></el-table-column>
        <el-table-column prop="deviceGroup" :label="$t('rule.labelDeviceGroup')" >
          <template slot-scope="scope">
            <el-tooltip effect="dark" :content="scope.row.deviceGroup.groupNames" placement="bottom">
              <span>
                {{scope.row.deviceGroup.groupName}}
              </span>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column prop="deviceSpecialAttribute" :label="$t('rule.labelAttribute')" ></el-table-column>
        <el-table-column prop="timezones" :label="$t('rule.labelTimezone')" ></el-table-column>
        <el-table-column prop="library" :label="$t('rule.labelImageLibrary')" ></el-table-column>
        <el-table-column prop="threshold" :label="$t('rule.labelThreshold')" >
          <template slot-scope="scope">
            <span>{{Number(scope.row.threshold*100).toFixed(1)}}%</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" :label="$t('rule.labelRuleStaus')" >
          <template slot-scope="scope">
            <el-switch
              :disabled="!$permission('006308')"
              @change="(v)=>changeRuleStatus(v,scope.row)"
              v-model="scope.row.status"
              :active-value="1"
              :inactive-value="0"
              active-color="#13ce66"
              inactive-color="#ff4949">
            </el-switch>
          </template>
        </el-table-column>
        <el-table-column prop="operation" :label="$t('rule.labelOperation')" fixed="right"  >
          <template slot-scope="scope">
            <span class="rule-list-operation-item" @click="handleView(scope.$index, scope.row)" v-if="$permission('006102')">
              <i class="iconfont icon-view"  ></i>
            </span>
            <span class="rule-list-operation-item" @click="handleEdit(scope.$index, scope.row)" v-if="$permission('006203')">
              <i class="iconfont icon-edit" ></i>
            </span>
            <span class="rule-list-operation-item" @click="handleDelete(scope.$index, scope.row)" v-if="$permission('006404')">
              <i class="iconfont icon-delete" ></i>
            </span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- edit rule ac dialog -->
    <EditRuleAC :visible="showEditRuleACDialog" @editsuccess="handleEditSuccess" @hideEditRuleacDialog="()=>{showEditRuleACDialog = false}" :ruleId="currentRuleId" :groupId="groupId"/>
    <!-- view rule ac dialog -->
    <ViewRuleAC :visible="showViewRuleACDialog" @hideViewRuleacDialog="(isEdit)=>{showViewRuleACDialog = false;isEdit?showEditRuleACDialog = true:''}" :ruleId="currentRuleId"  />
    <!-- messageBox delete -->
    <el-dialog
      :append-to-body="true"
      :visible="showDeleteDialog"
      :before-close="()=>this.showDeleteDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{$t('rule.popmsgRulesetDelete')}}</p>
      <div slot="title" >
        <span>{{$t('rule.listDelete')}}</span>
      </div>
      <span slot="footer">
        <el-button type="danger" @click="()=>ensureDelete()">{{$t('rule.buttonOperationDelete')}}</el-button>
        <el-button @click="showDeleteDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!-- messageBox change status -->
    <el-dialog
      :append-to-body="true"
      :visible="showStatusDialog"
      :before-close="()=>this.showStatusDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{statusText}}</p>
      <div slot="title" >
        <span>{{$t('rule.titleReminder')}}</span>
      </div>
      <span slot="footer">
        <el-button type="primary" @click="()=>ensureChangeStatus()">{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="showStatusDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import EditRuleAC from '../dialog/ac/edit-rule-ac.vue';
import ViewRuleAC from '../dialog/ac/view-rule-ac.vue';
import {deleteRuleAc,getRulesACList,startRuleAC,stopRuleAC} from '@/api/rule';
import { RuleModule } from '@/store/modules/rule';
import {EventBus} from '@/utils/eventbus';

@Component({
  components: {
    EditRuleAC,
    ViewRuleAC
  },
})
export default class RuleListAC extends Vue {
  // 计算属性
  // get keyword (){
  //   return RuleModule.keyword;
  // }
  /* props */

  /* watch */
  // @Watch('keyword')
  // onkeywordChange(n,o){
  //   this.getRuleList({keyword:n});
  // }
  /* data */
  tableData:any[]= [];
  showEditRuleACDialog:boolean =false;
  showViewRuleACDialog:boolean = false;
  // groupId:string=location.hash.split('?')[1].split('=')[1];
  groupId:string=this.getParamsValueFromURL('groupId');
  currentRuleId:string='';
  //delete
  showDeleteDialog:boolean=false;
  //change status
  showStatusDialog:boolean=false;
  statusModel:string='';
  statusText:string='';
  keyword:string='';
  /* methods */
  getParamsValueFromURL(key){
    let url_string = location.href.split('?')[1];
    let searchParams = new URLSearchParams(url_string);
    return searchParams.get(key) || '';
  }
  mounted() {
    this.getRuleList();
    EventBus.$on('rule-search-list-ac',(n)=>{this.keyword=n;this.getRuleList({keyword:n});})
  }
  getRuleList(params?){
    let condition = {...params,page:1,num:1};
    getRulesACList(condition,this.groupId).then((res:any)=>{
      res.list && this.formatListData(res.list);
      res.list && res.list.length == 0 && (this.tableData = []);
    })
  }
  formatListData(list){
    this.tableData = [];
    list.length>0 && list.map((item:any)=>{
      this.tableData.push({
        ruleId:item.taskId,
        ruleName: item.taskName,
        deviceName: item.deviceVo.deviceName,
        deviceGroup: this.formatGroupName(item.deviceVo.deviceGroupList),
        deviceSpecialAttribute:this.formatDeviceSpecialAttribute(item.taskAttributeVos),
        timezones:item.timeZoneNum,
        library:item.libraryNum,
        threshold:item.threshold,
        status:item.taskStatus
      });
    })
  }
  formatDeviceSpecialAttribute(deviceSpecialAttribute){
    let str = '';
    deviceSpecialAttribute && deviceSpecialAttribute.map(item=>{
      str= str+' '+this.$tc(`rule.${item.taskAttributeName}`);
    });
    return str;
  }
  formatGroupName(deviceGroupList){
    let groupName:string='',groupNames:string='',len = deviceGroupList.length;
    groupName = deviceGroupList[len-1].name;
    deviceGroupList.map((item,itemIndex)=>{
      groupNames+=item.name+(itemIndex == (len -1)?'':'>');
    });
    return {groupName,groupNames};
  }
  handleView(index,row){
    this.currentRuleId = row.ruleId;
    this.showViewRuleACDialog = true;
  }
  handleEdit(index,row){
    this.currentRuleId = row.ruleId;
    this.showEditRuleACDialog = true;
  }
  ensureDelete(){
    deleteRuleAc(this.currentRuleId).then(res=>{
      // this.$message({
      //   type: 'success',
      //   message: '删除成功!'
      // });
      this.showDeleteDialog = false;
      this.getRuleList();
    }).catch(err=>{
      this.showDeleteDialog = false;
    })
  }
  handleDelete(index,row){
    this.currentRuleId = row.ruleId;
    this.showDeleteDialog = true;
    // this.$confirm(this.$tc('rule.popmsgRulesetDelete') as string, this.$tc('rule.buttonDelete') as string, {
    //   confirmButtonText: this.$tc('rule.buttonOK') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    //   center:true
    // }).then(() => {
    //   let ruleId = '1';
    //   deleteRuleAc(row.ruleId).then(res=>{
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '删除成功!'
    //     // });
    //     this.getRuleList();
    //   })
    // }).catch(() => {
    //   // this.$message({
    //   //   type: 'info',
    //   //   message: '已取消删除'
    //   // });
    // });

  }
  handleEditSuccess(){
    this.getRuleList();
  }
  changeRuleStatus(v,row){
    row.status = v==0?1:0;
    v ==1 && this.startRule(row.ruleId);
    v ==0 && this.stopRule(row.ruleId);
  }
  startRule(ruleId){
    this.statusModel = 'start';
    this.currentRuleId = ruleId;
    this.statusText = this.$tc('rule.popmsgBatchEnable');
    this.showStatusDialog = true;

    // this.$confirm(this.$tc('rule.popmsgBatchEnable') as string, this.$tc('rolemanagement.titleReminder') as string, {
    //   confirmButtonText: this.$tc('rule.buttonOK') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    // }).then(() => {
    //   startRuleAC(ruleId).then(res=>{
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '开启成功!'
    //     // });
    //   }).finally(()=>{
    //     this.getRuleList({keyword:this.keyword});
    //   })
    // }).catch(()=>{});
  }
  stopRule(ruleId){
    this.statusModel = 'stop';
    this.currentRuleId = ruleId;
    this.statusText = this.$tc('rule.popmsgBatchDisable');
    this.showStatusDialog = true;

    // this.$confirm(this.$tc('rule.popmsgBatchDisable') as string, this.$tc('rolemanagement.titleReminder') as string, {
    //   confirmButtonText: this.$tc('rule.buttonOK') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    // }).then(() => {
    //     stopRuleAC(ruleId).then(res=>{
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '关闭成功!'
    //     // });
    //   }).finally(()=>{
    //     this.getRuleList({keyword:this.keyword});
    //   });
    // }).catch(()=>{});
  }
  ensureChangeStatus(){
    if(this.statusModel == 'start'){
      startRuleAC(this.currentRuleId).then(res=>{
        // this.$message({
        //   type: 'success',
        //   message: '开启成功!'
        // });
        this.getRuleList({keyword:this.keyword});
      }).finally(()=>{
        this.showStatusDialog = false;
      })
    }
    if(this.statusModel == 'stop'){
      stopRuleAC(this.currentRuleId).then(res=>{
        // this.$message({
        //   type: 'success',
        //   message: '关闭成功!'
        // });
        this.getRuleList({keyword:this.keyword});
      }).finally(()=>{
        this.showStatusDialog = false;
      });
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .rule-list-ac-container{
    header{
      display: flex;
      justify-content: space-between;
      color: $--color-black;
      padding: 25px 0;
      padding-bottom: 16px;
      border-bottom:1px solid $--border-color-base;
    }
     .rule-list-operation-item{
      cursor: pointer;
      margin-right: 10px;
      i.iconfont{
        font-size:19px;
      }
    }
  }
</style>
