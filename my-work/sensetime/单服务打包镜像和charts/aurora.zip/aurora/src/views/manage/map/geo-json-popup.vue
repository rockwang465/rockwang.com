<template>
  <div>
    <!-- <p>
      I started out as a GeoJSON {{ type }}, but now I'm a Leaflet vector!
    </p> -->
    {{ text }}
    <!-- <button @click="editRegion">修改</button>
    <button @click="delectRegion">删除</button> -->
  </div>
</template>

<script>
export default {
  name: 'GeoJsonPopup',
  props: {
    type: {
      type: String,
      default: ''
    },
    text: {
      type: String,
      default: ''
    }
  },
  data(){
    return {
      editing:"1"
    }
  },
  mounted () {

  },
  methods: {
    editRegion(e){
      console.log("编辑",e)
      this.$emit("editing", this.editing);
    },
    delectRegion(e){
      console.log("删除",e)
    }
  }
};
</script>
