<template>

    <!--导出日志弹框-->
    <el-dialog
      :title="$t('rolemanagement.contExport')"
      :visible.sync="dialogShowVisible"
      :class="{hidden:isHidden}"
      class="dialog-custom"
      width="580px">

      <div class="outNum">
        <span class="num">{{$t('rolemanagement.contQuantity')}}</span>
        <el-input v-model="startNum"  @input="inputStartNum"></el-input>
        <!-- <el-input v-model="startNum" onkeyup="this.value=this.value.replace(/\D/g,'')"
                  onafterpaste="this.value=this.value.replace(/\D/g,'')"></el-input> -->
        <span class="xian">~</span>
        <el-input v-model="endNum" @input="inputEndNum"></el-input>
        <!-- <el-input v-model="endNum" onkeyup="this.value=this.value.replace(/^(0+)|[^\d]+/g,'')"></el-input> -->
      </div>
      <br>
      <div v-if="errorConfirmFlag">
        <br>
        <span class="error-confirm">{{errorConfirm}}</span>
      </div>
      <!--提示语-->
      <div style="height: 20px;color: red;text-align: center">
        {{tipsWords}}
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleData"
                   :disabled="!startNum || !endNum" :loading="isLoading">{{$t('rolemanagement.buttonOK')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('rolemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--导出人像弹框-->
</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {RoleModule} from '@/store/modules/role';
  import {isEmpty} from '@/utils/validate';

  @Component({

  })
  export default class RoleExport extends Vue {
    isHidden=false;
    isLoading = false;
    confirmButtonFlag = true;
    errorConfirmFlag = false;
    errorConfirm = "";
    dialogShowVisible = false;
    startNum = "" as any;
    endNum = "" as any;
    tipsWords = '' as any;
    @Prop(Object) query!: any[];
    @Prop(Number) total!: any[];
    @Prop({required: true, default: false}) dialogVisible!: boolean;

     //输入验证
    inputStartNum(val){
      if(this.verifySize(val)){
        this.startNum = val
      }else{
        this.startNum = '';
      }
    }
    //输入验证
    inputEndNum(val){
      if(this.verifySize(val)){
        this.endNum = val
      }else{
        this.endNum = '';
      }

    }
    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([1-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        this.tipsWords="";
        return true;
      }else{
        this.tipsWords= this.$t("records.exportError");
        setTimeout(()=>{
          this.tipsWords=""
        },2000)
        return false;
      }
    }


    handleData() {
      let that = this as any;
      that.isLoading = true;
      // setTimeout(()=>{
      //   this.isLoading=false;
      // },1100)
      let params = that.query as any;
      that.startNum = Number(that.startNum);
      that.startNum = Number(that.startNum);
      that.total = Number(that.total);
      if (isEmpty(that.startNum) || isEmpty(that.startNum)) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('rolemanagement.exportError1');
        that.clearError();
        that.isLoading = false;
        return
      }
      if (that.startNum <= 0 || that.endNum <= 0 || that.startNum > that.endNum) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('rolemanagement.exportError2');
        that.clearError();
        that.isLoading = false;
        return
      }
      if (that.endNum > that.total) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('rolemanagement.exportError3', {number: that.total});
        that.clearError();
        that.isLoading = false;
        return
      }
      if ((that.endNum - that.startNum) >= 10000) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('rolemanagement.exportError4');
        that.clearError();
        that.isLoading = false;
        return
      }
      params.from = that.startNum;
      params.to = that.endNum;
      //导出
      RoleModule.ExportRoleList(params).then((data: any) => {
        that.$message({
          showClose: true,
          message: that.$t('rolemanagement.exportSuccess'),
          type: 'success'
        })
        that.dialogShowVisible = false
        that.isHidden=true;
        setTimeout(()=>{
          that.isHidden=false;
        },1100)
        this.$emit('closeRoleExport')
      }).catch((err) => {
        console.log(err)
      }).finally(() =>{
        that.isLoading = false;
      })
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.errorConfirmFlag = true;
      this.dialogShowVisible = val;
    }

    @Watch('startNum')
    onDialogStartNumChange(val: any) {
      if (val < 1) {
        this.startNum = '';
      }
      if (!isEmpty(this.startNum) && !isEmpty(this.endNum)) {
        this.confirmButtonFlag = false;
      } else {
        this.confirmButtonFlag = true;
      }
    }

    @Watch('endNum')
    onDialogEndNumChange(val: any) {
      if (val < 1) {
        this.endNum = '';
      }
      if (!isEmpty(this.startNum) && !isEmpty(this.endNum)) {
        this.confirmButtonFlag = false;
      } else {
        this.confirmButtonFlag = true;
      }
    }


    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      this.startNum = '';
      this.endNum = '';
      if (!val) {
        this.$emit("closeRoleExport")
      }
    }

    clearError() {
      setTimeout(() => {
        this.errorConfirmFlag = false;
        this.errorConfirm = "";
        this.isLoading = false;
      }, 2000)
    }


  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  .dialog-custom{
    // display:block !important;
    width:100%;
    height:100%;
  }
  .hidden {
    display:block !important;
    position:flex;
    top:-10%;
    bottom:110%;
    right:5%;
    left:95%;
    width:0;
    height:0;
    overflow:hidden;
    transition:all 1s;
    ::v-deep.el-dialog{
      min-width:20%;
      height:30%;
      overflow:hidden;
    }
  }
  .content {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }

  .content > div {
    width: 45%;
  }

  .content > div span {
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }

  .outNum {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .outNum span {
    margin-right: 10px;
  }

  .outNum .xian {
    margin-left: 10px;
  }

  .outNum ::v-deep .el-input {
    width: 25%;
  }

  .el-list ::v-deep .el-input__suffix {
    right: 10px !important;
    top: 3px !important;
  }

  .right-name ::v-deep .el-input {
    width: 75%;
  }

  .upFile {
    color: #2a5af5;
  }

  ::v-deep .el-dialog__footer {
    text-align: center !important;
  }

  ::v-deep .el-input__inner {
    height: 32px !important;
  }

  .error-confirm {
    color: red;
  }
</style>
