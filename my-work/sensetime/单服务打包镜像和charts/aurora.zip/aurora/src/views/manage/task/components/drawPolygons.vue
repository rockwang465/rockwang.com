<template>
    <div>
        <canvas :class="['draw-line',drawModel && 'draw-line-draw']"
            @mousedown="handleMousedown"
            @mousemove="e=>{myDebounce(e);}"
            @mouseenter="handleMouseenter"
            @mouseleave="handleMouseleave" ref="cvs" :width="width" :height="height"></canvas>
        <div v-show="(drawModel || drawLine) && showPromt" class="draw-line-text" :style="{top:promptTop - 10 +'px',left:promptLeft+20+'px'}" >{{promtText}}</div>
    </div>
</template>

<script lang="tsx">
import { Component, Vue,Watch ,Prop} from 'vue-property-decorator';
import {debounce,cloneDeep} from "lodash";
import i18n from '@/lang/index';
const POINTER_R = 7;
const POINTER_COLOR_BEGIN = '#FAA51E';
const POINTER_COLOR_END = '#DA5A34';
const PROMT_START_TEXT = i18n.tc('task.drawStart');
const PROMT_END_TEXT =i18n.tc('task.drawEnd');
const PROMT_MARK_DISTANCE = 16;

  interface PointObj {
    x:number
    y:number
  }
  interface scaleObj {
    w:number
    h:number
  }


const
    POINT_R = 2,
    lineWidth = 1,
    lineColor = 'rgb(234,20,20)',
    lineColorWaring = 'rgb(245,190,24)',
    fillStyle = 'rgba(234,20,20,.3)',
    minPointsStance = 5,
    close_r = 25,
    keepStickingOut = false,
    allowLineIntersect = false,
    allowLineIntersectOtherPolygons = false;

@Component({
    components: {

    },
    directives:{

    }
})

export default class DrawPolygons extends Vue {
    /* props */
    @Prop({required:true}) width !: number;
    @Prop({required:true}) height !: number;
    @Prop({required:false}) drawModel !: number;
    @Prop({required:false}) drawLine !: number;
    @Prop({required:false}) segmentList !: Array<Object>;
    @Prop({required:false,default:()=>{}}) scale !:scaleObj;

    /* watch */

    /* data */
    $refs !:{
        cvs:HTMLCanvasElement
    };
    ctx:any=null;
    promptTop:number=0;
    promptLeft:number=0;
    promtText:string=i18n.tc('task.drawStart');
    showPromt:boolean=false;
    myDebounce:any = debounce((e)=>{ this.handleMouseMove(e) }, 30, {maxWait: 30});
    coordinateList:any[]=[];

    polygons:any[]=[];
    currentPolygonIndex:number=0;
    currentPolygon:any=null;
    currentPoints:any=null;
    watchMouseMove = false;
    segmentData:Array<PointObj> =[]
    currentIndex:any = undefined
    /* methods */
    mounted(){
        this.ctx = this.$refs.cvs.getContext('2d');
        this.initPolygonsData(0);
    }
    clearCanvas(width?,height?){
      if(width && height){
        this.ctx.clearRect(0, 0, width, height);
      }
      this.ctx.clearRect(0, 0, this.width, this.height);
    }
    clearAll(){
        this.coordinateList = [];
        this.polygons = [];
        this.initPolygonsData(0);
        this.ctx.clearRect(0, 0, this.width, this.height);
    }
    drawRectangle(rectangle:[{x:number,y:number},{x:number,y:number}]){
        rectangle && rectangle.length>0 && this.canvasRectangle(rectangle)
    }
    canvasRectangle(rectangle){
        let start = rectangle[0],
            end   = rectangle[1];
        this.ctx.beginPath(start.x,start.y);
        this.ctx.moveTo(start.x,end.y);
        this.ctx.lineTo(end.x,end.y);
        this.ctx.lineTo(end.x,start.y);
        this.ctx.lineTo(start.x,start.y);
        this.ctx.closePath();
        //style
        this.ctx.strokeStyle='#fff';
        this.ctx.stroke();
        this.ctx.fillStyle = 'rgba(255,255,255,.3)';
        this.ctx.fill();
    }
    handleMouseenter(){
        this.showPromt = true;
        if(this.coordinateList.length == 0) this.promtText = PROMT_START_TEXT;
    }

    handleMouseMove(e){
      //console.log(!this.drawModel,!this.drawLine)
        if(!this.drawModel && !this.drawLine) return ;
        let x = e.offsetX,y = e.offsetY;
        this.promptTop  = y;
        this.promptLeft = x;

        if(this.drawLine && this.watchMouseMove){
          x = x/this.scale.w
          y = y/this.scale.h
          this.handleMouseMoveLine(x,y)
        }

        if(this.drawModel){
          this.handleMouseMovePolygons(x,y);
        }

    }
    handleMouseleave(e){
        this.showPromt = false;
        let x = e.offsetX,y = e.offsetY;
        if(this.drawModel
        &&!(x>0 && y>0
        && x<this.width
        && y<this.height)
        && this.currentPolygon
        && this.currentPolygon.isClose === false
        && this.currentPolygon.points.length>0){
            this.$emit('hidedrawmodel');
            this.currentPolygon.points = [];
            this.currentPoints = [];
            this.polygons.length>1 && this.polygons.splice(this.currentPolygonIndex,1);
            this.ctx.clearRect(0, 0, this.width, this.height);
            this.drawAllPolygons();
        };
    }
    handleMousedown(e){
      let x = e.offsetX,y = e.offsetY;
      //console.log("drawModel:"+this.drawModel,"drawLine:"+this.drawLine)
      if(this.drawLine){
        this.watchMouseMove = true;
        x = x/this.scale.w
        y = y/this.scale.h
        this.drawSegment(x,y)
      }else{
        this.handleMouseDownPolygons(x,y);
      }
    }
    handleMouseMoveLine(x,y){
      //let currentSegmentData = cloneDeep(this.segmentData);

      //console.log('线段',x,y,this.segmentData)
      if(this.segmentData.length === 2){
        this.segmentData.pop()
      }
      //this.segmentData.push({x:x,y:y})

      // this.segmentData.forEach(item=>{
      //   item.x = item.x/this.scale.w
      //   item.y = item.x/this.scale.h
      // })




      //当前编辑线段
      this.currentPoints = cloneDeep(this.segmentData)
      this.draw(x,y,this.currentPoints);

      //绘制不需要编辑的线段
      this.insertLines(this.segmentList,this.currentIndex)
    }
    inDrawing(){
      this.showPromt = true;
      this.promtText = i18n.tc('task.drawStart');
    }
    endDrawing(){
      this.showPromt = false;
      this.promtText = i18n.tc('task.drawStart');
      this.watchMouseMove = false;
    }
    drawSegment(x,y){
      console.log('绘制')
      let _self = this;
      if(this.segmentData.length <2){
        let segmentPoint = {
          x:x,
          y:y
        }
        this.segmentData.push(segmentPoint)
      }
      setTimeout(()=>{
        this.promtText = i18n.tc('task.drawEnd');
      },400)

      if(this.segmentData.length == 2){
        this.endDrawing()

        this.$emit("drawEnd",this.segmentData)
        console.log(this.segmentData)
        setTimeout(()=>{
          _self.segmentData = []
        },400)
      }
      //console.log("开始绘制线段",x,y)
    }
    initPolygonsData(index){
        this.currentPolygonIndex = index;
        this.initCurrentPolygonData();
        this.currentPolygon = this.polygons[this.currentPolygonIndex];
        this.currentPoints = this.currentPolygon.points;
    }
    initCurrentPolygonData(){
        this.polygons[this.currentPolygonIndex] = {
            points:[],
            isClose:false,
            limitDown:false,
            area:'',
        };
        this.currentPoints = [];
    }
    handleMouseDownPolygons(x,y){
      //console.log('down')
        if(!this.drawModel) return ;
        //init data
        var p_len = this.polygons.length;
        if(p_len > 0){
            for(let i = 0;i < p_len;i++){
                if(this.polygons[i].isClose === true && !this.polygons[i+1]){
                    this.currentPolygonIndex = i+1;
                    this.initCurrentPolygonData();
                    break ;
                }
            }
        }
        this.currentPolygon = this.polygons[this.currentPolygonIndex];
        this.currentPoints = this.currentPolygon.points;
        //console.log(this.currentPoints)

        if(this.currentPolygon.isClose || this.currentPolygon.limitDown){
            return ;
        }
        if(this.polygons.length>1 && !allowLineIntersectOtherPolygons && this.isInPolygons({x,y},cloneDeep(this.polygons))){
            this.showPromt = true;
            this.promtText = i18n.tc('task.propNotDrawSameZone');
            return ;
        }
        var points = this.currentPoints;
        if(points.length > 0 && this.getTwoPointsStance({x,y},points[points.length - 1]) <= minPointsStance ){
            return ;
        }
        this.showPromt = false;
        if(points.length >=3 && this.getTwoPointsStance({x,y},points[0]) < close_r){
            x = points[0].x;
            y = points[0].y;
            this.currentPolygon.isClose = true;
            points.push({x,y})
            this.ctx.clearRect(0, 0, this.width, this.height);
            this.showAreaPolygon();
            //redraw before polygons
            if(this.polygons.length > 1) this.reDrawBeforePolygons();
            if(this.polygons.length == 1){
                points.map((point,pointIndex)=>{
                    points[pointIndex+1] && this.drawLines(point,points[pointIndex+1],lineColor);
                });
            };
            let data = cloneDeep(this.polygons);
            this.$emit('end',data)
            return ;
        }
        points.push({x,y});
    }
    getTwoPointsStance(pointA,pointB){
        let a = pointA.x - pointB.x;
        let b = pointA.y - pointB.y;
        let stance = Math.sqrt( a*a + b*b );
        return stance;
    }
    reDrawBeforePolygons(){
        let len = this.polygons.length;
        if(len > 0){
            for(let i = 0;i<len;i++){
                let polygon = this.polygons[i];
                if(!polygon.isClose) continue  ;
                this.ctx.beginPath();
                this.ctx.moveTo(polygon.points[0].x,polygon.points[0].y)
                polygon.points && polygon.points.length>=3 && polygon.points.map((point,pointIndex)=>{
                    this.ctx.lineTo(point.x,point.y);
                });
                this.ctx.strokeStyle=lineColor;
                this.ctx.stroke();
                this.ctx.fillStyle = fillStyle;
                this.ctx.fill();
                this.ctx.closePath();
            }
        }
    }
    drawAllPolygons(){
        let len = this.polygons.length;
        if(len > 0){
            this.showAreaPolygon();
            for(let i = 0;i<len;i++){
                let polygon = this.polygons[i];
                if(!polygon.isClose) continue  ;
                this.ctx.beginPath();
                this.ctx.moveTo(polygon.points[0].x,polygon.points[0].y)
                polygon.points && polygon.points.length>=3 && polygon.points.map((point,pointIndex)=>{
                    this.ctx.lineTo(point.x,point.y);
                });
                this.ctx.strokeStyle=lineColor;
                this.ctx.stroke();
                this.ctx.fillStyle = fillStyle;
                this.ctx.fill();
                this.ctx.closePath();
            }
        }
    }

    drawArc(x,y,color){
        this.ctx.beginPath();
        this.ctx.arc(x,y,POINT_R,0,2*Math.PI);
        this.ctx.fillStyle = color;
        this.ctx.fill();
        this.ctx.stroke();
        this.ctx.closePath();
    }
    reDrawLines(startPoint,endPoint,color){
        this.ctx.lineTo(endPoint.x, endPoint.y);
        this.ctx.strokeStyle = color;
    }
    drawLines(startPoint,endPoint,color){
        let is_start = startPoint.x === this.currentPoints[0].x && startPoint.y === this.currentPoints[0].y;
        let is_last  = endPoint.x === this.currentPoints[this.currentPoints.length-1].x && endPoint.y === this.currentPoints[this.currentPoints.length-1].y;
        let is_close = this.currentPolygon.isClose;
        //line style
        this.ctx.strokeStyle = color;
        //draw line
        is_start && this.ctx.beginPath();
        is_start && this.ctx.moveTo(startPoint.x, startPoint.y);
        this.ctx.lineTo(endPoint.x, endPoint.y);
        this.ctx.stroke();
        is_last && is_close && this.ctx.closePath();
        is_last && is_close && (this.ctx.fillStyle = fillStyle);
        is_last && is_close && this.ctx.fill();
    }
    insertLines(originSegmentList,currentIndex?){
      this.currentIndex = currentIndex
      if(currentIndex == "undefined"){
        originSegmentList.forEach((item,index) => {
          this.insertLine(item.points.start,item.points.end,"#0083f7");
        })
      }
      originSegmentList.forEach((item,index) => {
        if(index === currentIndex){
          if(item.isClear){
            return
          }
          if(this.watchMouseMove){
            return
          }
          this.insertLine(item.points.start,item.points.end,"#cc0000");
        }else{
          //console.log('绘制非当前线段')
          this.insertLine(item.points.start,item.points.end,"#0083f7");
        }
      });
    }

    insertLine(startPoint,endPoint,color){
      //console.log(startPoint.y,endPoint.y,color)
      this.ctx.beginPath();

      this.ctx.arc(startPoint.x, startPoint.y,POINT_R*4,0,2*Math.PI);
      this.ctx.moveTo(startPoint.x, startPoint.y);
      this.ctx.lineTo(endPoint.x, endPoint.y);
      this.ctx.arc(endPoint.x, endPoint.y,POINT_R*4,0,2*Math.PI);
      this.ctx.strokeStyle = color;
      this.ctx.lineWidth = 8;
      this.ctx.lineCap="round";
      this.ctx.stroke();
    }
    scaleValue(scaleW,scaleH){
      this.ctx.scale(scaleW,scaleH);
    }
    handleMouseMovePolygons(x,y){
      console.log(x,y)
        if(this.currentPolygon && this.currentPolygon.isClose){
            return ;
        }

        if(this.currentPolygon && this.currentPolygon.points && this.currentPolygon.points.length == 0){
            this.showPromt = true;
            this.promtText = i18n.tc('task.drawStart');
        }else{
            this.showPromt = false;
        }
        this.draw(x,y,this.currentPoints);
    }
    cloneCanvas(oldCanvas) {
      //create a new canvas
      let newCanvas = document.createElement('canvas');
      let context = newCanvas.getContext('2d');

      //set dimensions
      newCanvas.width = oldCanvas.width;
      newCanvas.height = oldCanvas.height;

      //apply the old canvas to the new one
      if(context){
        context.drawImage(oldCanvas, 0, 0);

        //return the new canvas
        return newCanvas;
      }
    }
    draw(x,y,points){
      //console.log(x,y,points)
        if(points.length > 0){
          //console.log('clearRect',this.width, this.height)
          //this.ctx.save()
            //clear canvas
            if(this.scale){
              this.ctx.clearRect(0, 0,  this.width/this.scale.w, this.height/this.scale.h);
            }else{
              this.ctx.clearRect(0, 0, this.width, this.height);
            }

            this.showAreaPolygon();
            //redraw before polygons
            this.reDrawBeforePolygons();
            //redraw points
            points.map((point,pointIndex)=>{
                // this.drawArc(point.x,point.y,lineColor);
                points[pointIndex+1] && this.drawLines(point,points[pointIndex+1],lineColor);
            })
            //draw line
            let startPoint = cloneDeep(points[points.length-1]);
            //intersect other polygons
            if(this.polygons.length>1 && !this.currentPoints.isClose && !allowLineIntersectOtherPolygons){
                let start = {x:startPoint.x,y:startPoint.y},end={x,y};
                let isWarn = this.isIntersectOtherPolygon({start,end});
                this.drawLines(startPoint,{x,y},isWarn?lineColorWaring : lineColor);
                this.currentPolygon.limitDown = isWarn;
                if(isWarn) {
                    this.showPromt = true;
                    this.promtText = i18n.tc('task.propNotDrawSameZone');
                }
                if(isWarn) return ;
            }
            if(keepStickingOut && allowLineIntersect){//convex
                let isWarn = this.isInPolygon({x,y},points) || !this.isPointsSameSide({x,y},points);
                this.drawLines(startPoint,{x,y},isWarn?lineColorWaring : lineColor);
                this.currentPolygon.limitDown = isWarn;
                if(isWarn) {
                    this.showPromt = true;
                    this.promtText = i18n.tc('task.propNotDrawSameZone');
                }
            }else if(keepStickingOut && !allowLineIntersect){//convex && not allow intersect
                let isWarn = this.isIntersect({x,y},points) || this.isInPolygon({x,y},points) || !this.isPointsSameSide({x,y},points);
                !allowLineIntersect && this.drawLines(startPoint,{x,y},isWarn?lineColorWaring : lineColor);
                this.currentPolygon.limitDown = isWarn;
                if(isWarn) {
                    this.showPromt = true;
                    this.promtText = i18n.tc('task.propNotDrawSameZone');
                }
            }else if(!keepStickingOut && !allowLineIntersect){//not allow intersect
                let isWarn = this.isIntersect({x,y},points);
                !allowLineIntersect && this.drawLines(startPoint,{x,y},isWarn?lineColorWaring : lineColor);
                this.currentPolygon.limitDown = isWarn;
                if(isWarn) {
                    this.showPromt = true;
                    this.promtText = i18n.tc('task.propNotDrawSameZone');
                }
            }else{//free
                this.drawLines(startPoint,{x,y},lineColor)
            }
        }
    }
    isIntersectOtherPolygon(checkLine){
        if(this.polygons.length>1){
            for(let j = 0; j < (this.polygons.length-1);j++){//not check intersect self
                let polygonPoints = this.polygons[j].points;
                let len = polygonPoints.length;
                if(polygonPoints && len>0 ){
                    for (let i = 0; i<len ; i++){
                        if(polygonPoints[i+1]){
                            let p1 = {x:polygonPoints[i].x,y:polygonPoints[i].y},
                                p2 = {x:polygonPoints[i+1].x,y:polygonPoints[i+1].y};
                            let line1 = {p1,p2};
                            if(this.isTwoShortLineIntersect(line1,{p1:{x:checkLine.start.x,y:checkLine.start.y},p2:{x:checkLine.end.x,y:checkLine.end.y}})){
                                return true;
                            }
                        }
                    }
                }

            }
            return false;
        }
        return false;

    }
    isInPolygon(checkPoint, polygonPoints) {
        var counter = 0;
        var i;
        var xinters;
        var p1, p2;
        var pointCount = polygonPoints.length;
        p1 = polygonPoints[0];

        for (i = 1; i <= pointCount; i++) {
            p2 = polygonPoints[i % pointCount];
            if (
                checkPoint.x > Math.min(p1.x, p2.x) &&
                checkPoint.x <= Math.max(p1.x, p2.x)
            ) {
                if (checkPoint.y <= Math.max(p1.y, p2.y)) {
                    if (p1.x != p2.x) {
                        xinters =
                            (checkPoint.x - p1.x) *
                                (p2.y - p1.y) /
                                (p2.x - p1.x) +
                            p1.y;
                        if (p1.y == p2.y || checkPoint.y <= xinters) {
                            counter++;
                        }
                    }
                }
            }
            p1 = p2;
        }
        if (counter % 2 == 0) {
            return false;
        } else {
            return true;
        }
    }
    getPolygonCentroid(pts) {
      //获取重心
      var first = pts[0], last = pts[pts.length-1];
      if (first.x != last.x || first.y != last.y) pts.push(first);
      var twicearea=0,
        x=0, y=0,
        nPts = pts.length,
        p1, p2, f;
      for ( var i=0, j=nPts-1 ; i<nPts ; j=i++ ) {
        p1 = pts[i]; p2 = pts[j];
        f = p1.x*p2.y - p2.x*p1.y;
        twicearea += f;
        x += ( p1.x + p2.x ) * f;
        y += ( p1.y + p2.y ) * f;
      }
      f = twicearea * 3;
      return { x:x/f, y:y/f };
    }
    isInPolygons(checkPoint,polygons){
        if(polygons && polygons.length>1){
            for(let i = 0;i<polygons.length;i++){
               let polygon = polygons[i];
               if(polygon.isClose && polygon.points.length>0 && this.isInPolygon(checkPoint,polygon.points)) return true;
            }
        }
        return false;
    }
    isPointsSameSide(checkPoint,polygonPoints){
        let len = polygonPoints.length;
        if(len<3){
            return true;
        }
        let short = {p1:checkPoint,p2:polygonPoints[0]},
            long = {p1:polygonPoints[len-1],p2:polygonPoints[len-2]};
        return !this.isTwoShortAndLongLineIntersect(short,long);

    }
    isIntersect(checkPoint,polygonPoints){
        let len = polygonPoints.length;
        if(len<3){
            return false;
        }
        for (let i = 0; i<len ; i++){
            if(polygonPoints[i+2]){
                let p1 = {x:polygonPoints[i].x,y:polygonPoints[i].y},
                    p2 = {x:polygonPoints[i+1].x,y:polygonPoints[i+1].y};
                let p3 = {x:polygonPoints[len-1].x,y:polygonPoints[len-1].y},
                    p4 = {x:checkPoint.x,y:checkPoint.y};
                let line1 = {p1,p2},line2 = {p1:p3,p2:p4};
                if(this.isTwoShortLineIntersect(line1,line2)){
                    return true;
                }
            }
        }
        return false;
    }
    isTwoShortLineIntersect(line1,line2){
        let k1 = (line1.p1.y - line1.p2.y)/(line1.p1.x - line1.p2.x),
            k2 = (line2.p1.y - line2.p2.y)/(line2.p1.x - line2.p2.x);
        if(k1 == k2){
            return false;
        }
        let x = (k1*line1.p1.x - k2*line2.p1.x - line1.p1.y + line2.p1.y)/(k1 - k2);
        let y = (k1*k2*line1.p1.x - k1*k2*line2.p1.x - k2*line1.p1.y + k1*line2.p1.y)/(k1 - k2);
        if( x > Math.max(Math.min(line1.p1.x,line1.p2.x),Math.min(line2.p1.x,line2.p2.x))
        &&  x < Math.min(Math.max(line1.p1.x,line1.p2.x),Math.max(line2.p1.x,line2.p2.x))
        &&  y > Math.max(Math.min(line1.p1.y,line1.p2.y),Math.min(line2.p1.y,line2.p2.y))
        &&  y < Math.min(Math.max(line1.p1.y,line1.p2.y),Math.max(line2.p1.y,line2.p2.y))){
            return true;
        }else{
            return false;
        }
    }
    isTwoShortAndLongLineIntersect(line1,line2){//line1--> short ; line2 --> long
        let k1 = (line1.p1.y - line1.p2.y)/(line1.p1.x - line1.p2.x),
            k2 = (line2.p1.y - line2.p2.y)/(line2.p1.x - line2.p2.x);
        if(k1 == k2){
            return false;
        }
        let x = (k1*line1.p1.x - k2*line2.p1.x - line1.p1.y + line2.p1.y)/(k1 - k2);
        let y = (k1*k2*line1.p1.x - k1*k2*line2.p1.x - k2*line1.p1.y + k1*line2.p1.y)/(k1 - k2);
        if( x > Math.min(line1.p1.x,line1.p2.x)
        &&  x < Math.max(line1.p1.x,line1.p2.x)
        &&  y > Math.min(line1.p1.y,line1.p2.y)
        &&  y < Math.max(line1.p1.y,line1.p2.y)){
            return true;
        }else{
            return false;
        }
    }
    deletePolygon(index){
        this.polygons.splice(index,1);
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.drawAllPolygons();
        if(this.polygons.length == 0){
            this.polygons.push({
                points:[],
                isClose:false,
                limitDown:false
            });
            this.currentPolygonIndex = 0;
        }

    }
    showCurrentPolygon(index){
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.showAreaPolygon(index,null,'#1989FA');
        if(this.polygons.length>0){
            for(let i=0;i<this.polygons.length;i++){
                let polygon = this.polygons[i];
                if(!polygon.isClose) continue ;
                this.ctx.beginPath();
                this.ctx.moveTo(polygon.points[0].x,polygon.points[0].y)
                polygon.points && polygon.points.length>=3 && polygon.points.map((point,pointIndex)=>{
                    this.ctx.lineTo(point.x,point.y);
                });
                this.ctx.lineTo(polygon.points[0].x,polygon.points[0].y);
                this.ctx.strokeStyle = i == index ?'#1989FA':lineColor;
                this.ctx.fillStyle = i == index ?'rgba(255,255,255,.3)':fillStyle;
                this.ctx.stroke();
                this.ctx.fill();
                this.ctx.closePath();
            }
        }
    }
  showAreaPolygon(index?,area?,color?){

    this.ctx.clearRect(0, 0, this.width, this.height);
    if (area){
      if(!index) {
        index = 0
      }
      this.polygons[index].area = area;
    }
    if(this.polygons.length>0){
      for(let i=0;i<this.polygons.length;i++){
        if (this.polygons[i].area){
          let polygon = this.polygons[i];
          let point = polygon.points;
          let p = this.getPolygonCentroid(point)
          let font = 70;
          let x = p.x;
          let y = p.y;
          let arrx:any = [];
          let arry:any = [];
          for (let j = 0;j < point.length;j++){
            arrx.push(point[j].x);
            arry.push(point[j].y);
          }
          arrx.sort(function(a,b){ return a-b; })
          arry.sort(function(a,b){ return a-b; })
          let x1 = arrx[0] + (arrx[arrx.length-1] - arrx[0]) / 2
          let y1 = arry[0] + (arry[arrx.length-1] - arry[0]) / 2
          let xbool = x - x1;//正+负-
          let ybool = y - y1;
          this.ctx.font='30px sans-serif'
          this.ctx.fillStyle="#f40";
          if(color&&(index == i)){
            this.ctx.fillStyle = color;
          }else{
            this.ctx.fillStyle="#f40";
          }
          // this.ctx.beginPath();
          // this.ctx.arc(x, y, 5, 0, 2*Math.PI, false);
          // this.ctx.fill();
          this.ctx.fillText(this.polygons[i].area + 'm²', x, y)
          // this.ctx.fillText(this.polygons[i].area + 'm²', xbool?(x+font/2):(x-font/2), ybool?(y+font/2):(y-font/2))

        }
      }
      for(let i = 0;i<this.polygons.length;i++){
        let polygon = this.polygons[i];
        if(!polygon.isClose) continue  ;
        this.ctx.beginPath();
        this.ctx.moveTo(polygon.points[0].x,polygon.points[0].y)
        polygon.points && polygon.points.length>=3 && polygon.points.map((point,pointIndex)=>{
          this.ctx.lineTo(point.x,point.y);
        });
        this.ctx.strokeStyle=lineColor;
        this.ctx.stroke();
        this.ctx.fillStyle = fillStyle;
        this.ctx.fill();
        this.ctx.closePath();
      }
    }
    // let polygon = this.polygons[index];
    // let point = polygon.points;
    // let font = 30;
    // console.log(polygon);
    // let arrx:any = [];
    // let arry:any = [];
    // for (let i = 0;i < point.length;i++){
    //   arrx.push(point[i].x);
    //   arry.push(point[i].y);
    // }
    // arrx.sort(function(a,b){ return a-b; })
    // arry.sort(function(a,b){ return a-b; })
    // console.log(arrx,arry)
    // let x = arrx[0] + (arrx[arrx.length-1] - arrx[0]) / 2
    // let y = arry[0] + (arry[arrx.length-1] - arry[0]) / 2
    // // this.ctx.font = font + 'px #fff'
    // this.ctx.font='30px sans-serif'
    // if (color){
    //   this.ctx.fillStyle=color;
    // } else{
    //   this.ctx.fillStyle="#000";
    // }
    // this.ctx.fillText(area, (x-font/2), y)


    // this.ctx.clearRect(0, 0, this.width, this.height);
    // if(this.polygons.length>0){
    //   for(let i=0;i<this.polygons.length;i++){
    //     let polygon = this.polygons[index];
    //     if(!polygon.isClose) continue ;
    //     this.ctx.beginPath();
    //     this.ctx.moveTo(polygon.points[0].x,polygon.points[0].y)
    //     polygon.points && polygon.points.length>=3 && polygon.points.map((point,pointIndex)=>{
    //       this.ctx.lineTo(point.x,point.y);
    //     });
    //     this.ctx.lineTo(polygon.points[0].x,polygon.points[0].y);
    //     this.ctx.strokeStyle = i == index ?'#1989FA':lineColor;
    //     this.ctx.fillStyle = i == index ?'rgba(255,255,255,.3)':fillStyle;
    //     this.ctx.stroke();
    //     this.ctx.fill();
    //     this.ctx.closePath();
    //   }
    // }
  }
    hideCurrentPolygon(index){
        this.ctx.clearRect(0, 0, this.width, this.height);
        if(this.polygons.length>0){
            this.showAreaPolygon();
            for(let i=0;i<this.polygons.length;i++){
                let polygon = this.polygons[i];
                if(!polygon.isClose) continue ;
                this.ctx.beginPath();
                this.ctx.moveTo(polygon.points[0].x,polygon.points[0].y)
                polygon.points && polygon.points.length>=3 && polygon.points.map((point,pointIndex)=>{
                    this.ctx.lineTo(point.x,point.y);
                });
                this.ctx.lineTo(polygon.points[0].x,polygon.points[0].y);
                this.ctx.strokeStyle = lineColor;
                this.ctx.fillStyle = fillStyle;
                this.ctx.stroke();
                this.ctx.fill();
                this.ctx.closePath();
            }
        }
    }
    drawPolygonsMethod(polygons,area?){
      // debugger
        this.formatPolygonsMethodData(polygons,area);
        this.drawAllPolygons();
    }
    formatPolygonsMethodData(polygons,area?){
        let arr :any[]=[];
        polygons.length > 0 && polygons.map(polygon=>{
            arr.push({points:polygon,isClose:true,limitDown:false,area:area?area:''})
        });
        this.polygons = arr;
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.draw-line-draw,.draw-line-text{
    cursor: url("/images/positting.svg") 16 16, default ;
}
.draw-line-text{
    position: absolute;
    background-color: rgba($color: #000000, $alpha: .5);
    padding: 4px;
    color: white;
    border-radius: 2px;
}
</style>
