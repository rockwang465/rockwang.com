<template>
  <el-container style="height: 100%;padding:0 8px;">
    <el-aside width="312px">
      <h2 class="side-title"><i class="iconfont icon-device-manage" ></i><span>{{$t('devicemanagement.labelDeviceGroup')}}</span>
      </h2><!--设备分组-->
      <LeftTree ref="lefttree"
        :treeData="treeData"
        :leftTreeData="leftTreeData"
        :currentNodeKey="currentNodeKey"
        @clickVal="clickVal"
        @actionMethod="leftTreeAction"
        @showDetail="showDetail"
        @addData="addData"
        @updateData="updateData"
        @deleteData="deleteData"
        style="height: calc(100% - 95px);">
      </LeftTree>
    </el-aside>
    <el-container style="padding: 0 8px;">
      <el-main class="main" style="height: 100%;padding: 0;overflow: hidden">
        <div class="main_head" style="padding: 32px 0 16px 0;height: 80px;">
          <el-col :span="12" v-show="showBtn" style="height: 32px;">
            <el-button type="primary" size="small" icon="iconfont icon-add-device" v-if="$permission('007309')"
                       @click="showDeviceEdit('')">{{$t('devicemanagement.buttonAddDevice')}}
            </el-button><!--添加设备-->
            <el-button type="primary" v-if="$permission('007316')||$permission('007215')||$permission('007412')" size="small" icon="iconfont icon-batch-handle" @click="disBtn">
              {{$t('devicemanagement.buttonBatch')}}
            </el-button>&nbsp;<!--批量操作-->
            <el-button type="primary" size="small" icon="iconfont icon-batch-export"  v-if="$permission('007324')" @click="isShowExport = true">
              {{$t('rolemanagement.buttonExport')}}
            </el-button>&nbsp;<!--导出-->
          </el-col>
          <el-col :span="12" v-show="!showBtn" style="height: 32px;">
            <i @click="comeHome" class="iconfont icon-fanhui"></i>
            <el-button type="primary" size="small" icon="iconfont icon-add-user" v-if="$permission('007316')"
                       @click="addGroupData('user')">{{$t('devicemanagement.buttonAssignUser')}}
            </el-button><!--添加到用户-->
            <el-button type="primary" size="small" icon="iconfont icon-add-group" v-if="$permission('007215')"
                       @click="addGroupData('group')">{{$t('devicemanagement.buttonMoveGroup')}}
            </el-button><!--添加到分组-->
            <el-button type="danger" size="small" v-if="$permission('007412')" icon="iconfont icon-delete"
                       @click="deviceDeleteBatch">
              {{$t('devicemanagement.buttonDelete')}}
            </el-button>&nbsp;<!--删除-->
          </el-col>
          <el-col :span="8" class="center">
            <span v-if="$permission('007119')">
              <span>{{$t('devicemanagement.contTotalDevice',{number:total})}}</span>
              <i class="iconfont icon icon-separator"></i>
              <span class="active">{{$t('devicemanagement.contOnlineDevice',{number:onlineCount})}}</span>
            </span>
            &nbsp;
          </el-col><!--设备数量  在线-->
          <el-col :span="4">
            <el-input
              :placeholder="$t('devicemanagement.contDeviceSearch')"
              size="medium" class="search-input-device"
              @blur="blurInput"
              @focus="blurFocus"
              v-model="query.keywords">
          <span class="suffix-icon" slot="suffix">
            <Icon
              v-if="showSearchClose"
              type="ele"
              size="15"
              cursor="pointer"
              name="circle-close"
              @click="clickClearKeywords"
            />
            <Icon
              type="ele"
              size="15"
              cursor="pointer"
              name="search"
              @click="onKeywordsChange"
            />
          </span>
            </el-input>
          </el-col>
        </div>
        <div class="main_con">
          <el-table
            stripe
            v-loading="loading"
            @filter-change="tableFilterChange"
            :data="tableData"
            style="width: 100%;height:calc(100% - 54px)"
            ref="tables"
            @select="handleSelect"
            @select-all="handleSelection"
            @selection-change="handleSelectionChange"
            row-key="deviceId"
            :row-class-name="tableRowClassName"
            :expand-change="expandChange"
            :tree-props="{children: 'childDeviceList', hasChildren: 'hasChildren'}"
          >
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="30">
            </el-table-column>
            <el-table-column
              v-if="showTableSelect"
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              align="left"
              prop="deviceName"
              :label="$t('devicemanagement.labelDeviceName')"
              width="200"><!--名称-->
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              :label="$t('devicemanagement.labelDeviceType')"
              align="left"
              width="200"
              prop="deviceType"
              column-key="deviceType"
              :filter-multiple="false"
              :filters="deviceTypeList"
            >
              <template slot-scope="scope">
                {{deviceTypeList.find(i=>i.value == scope.row.deviceType).text}}
                <!-- {{scope.row.deviceType == 1 ? "Camera" : scope.row.deviceType == 2 ? "SenseKeeper" : scope.row.deviceType == 4 ? "SenseDLC" : scope.row.deviceType == 5 ?'SenseID':"未知" }} -->
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              align="left"
              prop="ID"
              :label="$t('devicemanagement.labelDeviceID')"
              width="230"><!--设备ID-->
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              align="left"
              prop="ip"
              :label="$t('devicemanagement.labelIP')"
              width="230">
            </el-table-column><!--IP/网络地址-->
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              :label="$t('devicemanagement.labelConnectStatus')"
              align="left"
              width="180"
              prop="connectStatus"
              column-key="connectStatus"
              :filter-multiple="false"
              :filters="[{text: $t('devicemanagement.listConnectStatusOnline'), value: 1},{text: $t('devicemanagement.listConnectStatusOffline'), value: 0}]"
            >
              <template slot-scope="scope">
                <span v-if="scope.row.accessState == 1" style="color: #8e99aa">{{$t('devicemanagement.listConnectStatusOnline')}}</span>
                <span v-if="scope.row.accessState == 0" style="color: #8e99aa">{{$t('devicemanagement.listConnectStatusOffline')}}</span>
              </template><!--在线,离线-->
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              align="left"
              :label="$t('devicemanagement.labelActiveStatus')"
              width="150"
              prop="useStatus"
              column-key="useStatus"
              :filter-multiple="false"
              :filters="[{text: $t('usermanagement.buttonEnable'), value: 1},{text: $t('devicemanagement.listActiveStatusDisabled'), value: 0}]"
            ><!--启用状态-->
              <template slot-scope="scope">
                <el-popover v-if="scope.row.state == 1 && $permission('007120')"
                            placement="top-start"
                            :title="$t('devicemanagement.deviceRuleGroup')"
                            width="300"
                            trigger="hover"
                            @show="showDeviceTask(scope.row)"
                ><!--启动任务-->
                  <div style="width: 250px;word-wrap: break-word">
                    <div v-for="item in deviceTaskList" :key="item.id">{{item}}</div>
                  </div>
                  <span slot="reference" style="color: #0f9d58;cursor: pointer">{{$t('devicemanagement.listActiveStatusEnabled')}}</span>
                </el-popover>
                <span v-if="scope.row.state == 0" style="color: #8e99aa">{{$t('devicemanagement.listActiveStatusDisabled')}}</span>
              </template><!--激活,禁用-->
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              align="left"
              :label="$t('devicemanagement.labelOperation')"
              width="132">
              <template slot-scope="scope">
                <span class="device-list-operation-item" v-if="$permission('007108')"
                      @click="showDeviceDetail(scope.row)">
                      <i class="iconfont icon-view"></i>
                    </span>
                <!--打开编辑-->
                <span class="device-list-operation-item" v-if="$permission('007210')"
                      @click="showDeviceEdit(scope.row)">
                      <i class="iconfont icon-edit"></i>
                    </span>
                <!--删除-->
                <span class="device-list-operation-item" v-if="$permission('007411')" @click="deviceDelete(scope.row)">
                      <i class="iconfont icon-delete"></i>
                    </span>
                <!--子设备-->
                <span class="device-list-operation-item" v-if="$permission('007210')&&scope.row.deviceType == 3"
                      @click="showAddSubset('',scope.row)">
                      <i class="iconfont icon-tianjia"></i>
                    </span>
              </template><!--操作-->
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              min-width="30">
            </el-table-column>
          </el-table>
          <el-pagination class="page" @size-change="handleSizeChange" @current-change="handleCurrentChange"
                      :current-page="query.page"
                      :page-sizes="[10, 20, 30, 50,100]" :page-size="query.size"
                      layout="total, sizes, prev, pager, next, jumper" :total="total">
          </el-pagination>
        </div>

      </el-main>

    </el-container>
    <el-dialog
      :title="$t('rolemanagement.buttonExport')"
      :visible.sync="isShowExport"
      width="30%">
      <span>{{$t('devicemanagement.deviceExportTips')}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="exportLoading" @click="deviceExport">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button type="info" @click="isShowExport = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <GroupAction
      ref='groupactionref'
      :dialogVisible="dialogGroupActionVisible"
      :dataObj="groupActionObj"
      @closeEdit="closeGroupAction"
      @handleDeviceGroupAction="handleGroupAction"
    ></GroupAction>
    <AddGroup
      :dialogVisible="dialogAddGroupVisible"
      :dataObj="addGroupObj"
      @closeEdit="closeAddGroup"
    ></AddGroup>
    <AddUser
      :dialogVisible="dialogAddUserVisible"
      :dataObj="addGroupObj"
      @closeEdit="closeAddUser"
    ></AddUser>
    <DeviceEdit
      :dialogVisible="dialogDeviceEditVisible"
      :dataObj="editObj"
      @closeEdit="closeEdit"
      @resetDeviceList="searchDeviceList"
    ></DeviceEdit>
    <AddSubset
      :dialogVisible="dialogAddSubsettVisible"
      :dataObj="editObj"
      :deviceObj="deviceObj"
      :handleType="handleType"
      @closeEdit="closeEdit"
      @resetDeviceList="searchDeviceList"
    ></AddSubset>
    <DeviceDetail
      :dialogVisible="dialogDeviceDetailVisible"
      :detailObj="detailObj"
      @closeDetail="closeDetail"
      @detailShowEdit="detailShowEdit"
    ></DeviceDetail>
    <DeviceAction
      :dialogVisible="dialogDeviceActionVisible"
      :dataObj="deviceActionObj"
      @closeDeviceAction="closeDeviceAction"
      @resetDeviceList="resetDeviceList"
    ></DeviceAction>
  </el-container>
</template>

<script lang="ts">
  import {Component, Vue, Watch} from 'vue-property-decorator';
  import LeftTree from '@/components/leftTree/index.vue';
  import DeviceEdit from '@/views/manage/device/editDialog.vue';
  import DeviceDetail from '@/views/manage/device/detailDialog.vue';
  import AddSubset from '@/views/manage/device/addSubset.vue';
  import AddGroup from '@/components/addGroup/index.vue'
  import AddUser from '@/components/addUser/index.vue'
  import GroupAction from '@/views/manage/device/groupAction.vue';
  import DeviceAction from '@/views/manage/device/deviceAction.vue';
  import {DeviceModule} from '@/store/modules/device';
  import {UserModule} from '@/store/modules/user';
  import {isEmpty,isEmptyNotZero} from '@/utils/validate';
  import Icon from '@/components/icon-wrap/index.vue';
  import {deviceType as deviceTypeList }  from '@/utils/constants';
  import {Cache} from "@/utils/cache";

  @Component({
    components: {
      LeftTree,
      DeviceEdit,
      DeviceDetail,
      AddGroup,
      GroupAction,
      DeviceAction,
      AddUser,
      Icon,
      AddSubset
    }
  })
  export default class Device extends Vue {
    deviceTypeList:any[]=deviceTypeList.map(item=> {return {text:item.name,value:item.value}});
    loading = false;
    checkInputEnter = false as Boolean;//判断回车是否可以触发搜索时间
    showSearchClose = false;
    dialogDeviceEditVisible = false;//显示设备编辑弹出框
    dialogAddSubsettVisible = false;//显示子设备弹出框
    dialogDeviceDetailVisible = false;//显示设备详情弹出框
    dialogAddGroupVisible = false;//显示添加分组弹出框
    dialogAddUserVisible = false;
    dialogGroupActionVisible = false;//显示分组操作的弹出框
    dialogDeviceActionVisible = false;//显示设备操作的弹出框
    showTableSelect = false;
    showBtn = true;
    isShowExport:boolean = false;
    localClickGroup = {} as any;//当前选中的组
    leftTreeData = {
      label: 'name',
      actionArray: [],
      expandArr: []
    } as any;
    addGroupObj = {
      title: '添加',
      treeData: [],
      treeUserData: [],
    } as any;
    groupActionObj = {
      title: '',
      type: ''
    } as any;//分组操作组件之间交互的对象值
    deviceActionObj = {
      title: "",
      confirm: "",
      confirm2: "",
    } as any;
    detailObj = {} as any;
    editObj = {} as any;
    deviceObj = {} as any;
    tableData = [];//设备列表数据
    treeData = [];//分组树treeData
    currentNodeKey = 0;
    query = {
      page: 1,
      size: 10,
      deviceType: "",//设备类型，1-Camera，2-SenseKeeper
      groupId: "",
      state: "",
      keywords: "",
      sort: "DESC"
    } as any;//设备检索条件
    total = 0;
    onlineCount = 0;
    multipleSelection = [];//表头多选框的选择项
    deviceTaskList = [];
    exportLoading:boolean = false;
    selectAll = false;//判断点击全选选中还是点击全选取消全部选择
    selectNow = {} as any;//此次点击到的设备
    handleType = 'add'

    $refs !:{
      tables:HTMLFormElement,
      lefttree:HTMLFormElement,
      trees:HTMLFormElement
    };
    mounted() {
      let that = this as any;
      that.leftTreeData.actionArray = [that.$permission('007303'), that.$permission('007303'), that.$permission('007102'), that.$permission('007204'), that.$permission('007405')];
      that.initGroupTree();//获取分组树
      that.searchOrgUserTree();
    }

    blurInput() {
      this.checkInputEnter = false;
    }

    blurFocus() {
      let that = this as any;
      that.checkInputEnter = true;
      document.onkeydown = function (event) {
        let e = event || window.event || arguments.callee.caller.arguments[0];
        //回车键检索
        if (e && e.key == 'Enter') {
          if (that.checkInputEnter) {
            that.onKeywordsChange()
          }
        }
      };
    }

    showDeviceTask(obj) {
      let that = this as any;
      this.deviceTaskList = [];
      DeviceModule.GetDeviceTaskById(obj.deviceId).then((data: any) => {
        this.deviceTaskList = data.taskNames;
      }).catch((err) => {
        console.log(err)
      });
    }

    //获取设备列表
    searchDeviceList() {
      let that = this as any;
      that.loading = true;
      // that.query.groupId = this.localClickGroup.id;
      DeviceModule.GetDeviceList(that.query).then((data: any) => {
        that.loading = false;
        that.tableData = data.data;
        that.total = data.total;
        that.onlineCount = data.onlineCount;
      }).catch((err) => {
        that.loading = false;
        console.log(err)
      });
    }

    //初始化设备树
    initGroupTree() {
      let that = this as any;
      DeviceModule.GetGroupList({keyword: ""}).then((data: any) => {
        that.treeData = data.data;
        that.addGroupObj.treeData = data.data;
        (that.$refs.lefttree as any).showInitData(data.data);
      }).catch((err) => {
        console.log(err)
      });
    }

    //获取设备树
    searchGroupTree() {
      let that = this as any;
      DeviceModule.GetGroupList({keyword: ""}).then((data: any) => {
        that.treeData = data.data;
        that.addGroupObj.treeData = data.data;
      }).catch((err) => {
        console.log(err)
      });
    }

    //获取用户数
    searchOrgUserTree() {
      let that = this as any;
      UserModule.GetOrgUserTree().then((data: any) => {
        that.addGroupObj.treeUserData = data.data;
      }).catch((err) => {
        console.log(err)
      });
    }

    //删除设备
    deviceDelete(obj) {
      console.log(obj)
      let that = this as any;
      this.deviceActionObj.deviceObj = obj;
      this.deviceActionObj.type = 'deleteDevice';
      this.deviceActionObj.confirm = that.$t('devicemanagement.popmsgDeviceDelete')
      this.deviceActionObj.confirm2 = that.$t('devicemanagement.popmsgDeviceDelete2')
      this.deviceActionObj.title = that.$t('devicemanagement.titleDelete')
      this.dialogDeviceActionVisible = true;
    }

    //批量删除设备
    deviceDeleteBatch() {
      let that = this as any;
      if (isEmpty(that.multipleSelection) || that.multipleSelection.size == 0) {
        that.$message({
          showClose: true,
          message: that.$t('devicemanagement.chooseDevice'),
          type: 'error'
        });
        return
      }
      this.deviceActionObj.multipleSelection = this.multipleSelection;
      this.deviceActionObj.type = 'deleteDeviceBatch';
      //"设备删除后,将不能恢复"
      this.deviceActionObj.confirm = that.$t('devicemanagement.popmsgDeviceDelete')
      this.deviceActionObj.title = that.$t('devicemanagement.titleDelete')
      this.dialogDeviceActionVisible = true;
    }

    //关闭设备操作弹窗
    closeDeviceAction() {
      this.dialogDeviceActionVisible = false;
    }

    clickVal(localData: any) {
      console.log(localData)
      this.currentNodeKey = localData.id
      this.query.page = 1;
      this.localClickGroup = localData;
      this.query.groupId = localData.id;
      this.searchDeviceList();
    }

    //处理分组弹窗操作
    handleGroupAction(obj, valueData) {
      let that = this as any;
      let params = {} as any;
      switch (obj.type) {
        //同级添加分组
        case "addLevel":
          params.name = valueData;
          params.parentId = obj.localData.parentId;
          DeviceModule.AddDeviceGroup(params).then((data: any) => {
            that.$refs.groupactionref.dialogShowVisible = false
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.groupAddSuccess'),
              type: 'success'
            })
            that.searchGroupTree();
          }).catch((err) => {
            console.log(err)
          });
          break;
        //添加下一级分组
        case "addNext":
          params.name = valueData;
          params.parentId = obj.localData.id
          DeviceModule.AddDeviceGroup(params).then((data: any) => {
            that.$refs.groupactionref.dialogShowVisible = false
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.groupNextAddSuccess'),
              type: 'success'
            })
            that.searchGroupTree();
          }).catch((err) => {
            console.log(err)
          });
          break;
        //修改分组
        case "edit":
          let objData = {} as any;
          objData.params = {name: valueData}
          objData.id = obj.localData.id
          DeviceModule.UpdateDeviceGroup(objData).then((data: any) => {
            that.$refs.groupactionref.dialogShowVisible = false
            that.searchGroupTree();
          }).catch((err) => {
            console.log(err)
          });
          break;
        //删除分组
        case "delete":
          that.$refs.groupactionref.dialogShowVisible = false
          if (obj.localData.defaultGroup == 1) {
            that.$message.error({showClose: true,message:that.$t('devicemanagement.defaultGroupDeleteFail'),});
            return
          }
          DeviceModule.DeleteDeviceGroup(obj.localData.id).then((data: any) => {
            that.$message({
              showClose: true,
              message: that.$t('devicemanagement.groupDeleteSuccess'),
              type: 'success'
            })
            //设备列表重置成默认组的列表
            if (!isEmpty(that.treeData) && that.treeData.length != 0) {
              that.clickVal(that.treeData[0]);
            }
            that.searchGroupTree();
          }).catch((err) => {
            console.log(err)
          });
          break;
      }
    }

    //分组添加数据
    addData(flag: any, localData: any) {
      let that = this as any;
      this.dialogGroupActionVisible = true;
      //添加同级分组,添加下级分组
      this.groupActionObj.title = flag == 'level' ? that.$t('devicemanagement.listPeerGroupCreate') : that.$t('devicemanagement.listSubGroupCreate')
      this.groupActionObj.type = flag == 'level' ? "addLevel" : "addNext"
      this.groupActionObj.localData = localData;
    }

    //分组修改数据
    updateData(localData: any) {
      let that = this as any;
      this.dialogGroupActionVisible = true;
      this.groupActionObj.title = that.$t('devicemanagement.titleEdit')
      this.groupActionObj.type = "edit"
      this.groupActionObj.localData = localData;
    }

    //分组删除数据
    deleteData(localData: any) {
      let that = this as any;
      this.dialogGroupActionVisible = true;
      this.groupActionObj.title = that.$t('devicemanagement.titleDelete')
      this.groupActionObj.type = "delete"
      this.groupActionObj.localData = localData;
    }

    //分组查看详情
    showDetail(localData: any) {
      let that = this as any;
      DeviceModule.DeviceGroupDetailById(localData.id).then((data: any) => {
        this.dialogGroupActionVisible = true;
        this.groupActionObj.title = that.$t('devicemanagement.titleDetail')
        this.groupActionObj.type = "detail";
        this.groupActionObj.localData = data;
      }).catch((err) => {
        console.log(err)
      });

    }

    showDeviceEdit(obj) {
      console.log(obj)
      let that = this as any;
      if (isEmpty(obj)) {

        that.editObj = {};
        that.editObj.localClickGroup = that.localClickGroup;
        that.dialogDeviceEditVisible = true;
        that.editObj.showNoSenseSwitch = true;
      } else {

        //如果是编辑子设备的话
        if (obj && obj.childDeviceList == undefined){
          // that.showAddSubset(obj,{deviceName:obj.subordinateToNodeVo.subordinateToNodeName,deviceId:obj.subordinateToNodeVo.subordinateToNodeId});
          that.showAddSubset(obj,{});
        }else{
          DeviceModule.GetDeviceDetail(obj.deviceId).then((data: any) => {
            that.editObj = data;
            that.editObj.showNoSenseSwitch = false;
            //console.log("编辑属性",that.editObj);
            this.dialogDeviceEditVisible = true
          }).catch((err) => {
            console.log(err)
          });
        }

      }
    }
    @Watch('handleType')
    onhandleTypeChange(val: any) {
      this.handleType = val
    }
    // 展示子设备弹窗
    showAddSubset(obj,deviceData) {
      let that = this as any;
      this.deviceObj = deviceData//获取所属父节点的数据,编辑子设备时，此数据在接口回调中获取
      if (isEmpty(obj)) {
        console.log('添加子设备')
        that.handleType = 'add'
        that.editObj = {};
        that.editObj.localClickGroup = that.localClickGroup;
        that.dialogAddSubsettVisible = true;
        that.editObj.showNoSenseSwitch = true;
      } else {
        console.log('编辑子设备')
        that.handleType = 'edit'
        DeviceModule.GetDeviceDetail(obj.deviceId).then((data: any) => {
          that.editObj = data;
          that.deviceObj = {
            deviceName:data.subordinateToNodeVo.subordinateToNodeName,deviceId:data.subordinateToNodeVo.subordinateToNodeId
          }

          that.editObj.showNoSenseSwitch = false;
          //console.log("编辑属性",that.editObj);
          this.dialogAddSubsettVisible = true
        }).catch((err) => {
          console.log(err)
        });
      }
    }

    detailShowEdit(obj,deviceObj) {
      let that = this as any;
      that.editObj = obj;
      if (deviceObj){
        that.deviceObj = deviceObj;
        this.dialogAddSubsettVisible = true;
      }else{
        this.dialogDeviceEditVisible = true;
      }
    }



    //关闭设备编辑弹窗
    closeEdit() {
      this.dialogDeviceEditVisible = false;
      this.dialogAddSubsettVisible = false;
    }

    //显示详情弹框
    showDeviceDetail(obj) {
      let that = this as any;
      DeviceModule.GetDeviceDetail(obj.deviceId).then((data: any) => {
        this.detailObj = data;
        console.log(this.detailObj)
        this.dialogDeviceDetailVisible = true
      }).catch((err) => {
        console.log(err)
      });
    }

    //关闭设备详情弹窗
    closeDetail() {
      this.dialogDeviceDetailVisible = false
    }

    //关闭组操作弹窗
    closeAddGroup() {
      this.searchDeviceList();
      this.dialogAddGroupVisible = false
      this.searchDeviceList();
    }

    closeAddUser() {
      this.dialogAddUserVisible = false
    }

    addGroupData(flag) {
      let that = this as any;
      that.addGroupObj.multipleSelection = this.multipleSelection;
      if (isEmpty(that.multipleSelection) || that.multipleSelection.size == 0) {
        that.$message({
          showClose: true,
          message: that.$t('devicemanagement.chooseDevice'),
          type: 'error'
        });
        return
      }
      if (flag == 'user') {
        that.addGroupObj.type = "addUser"
        //"添加到用户"
        that.addGroupObj.title = that.$t('devicemanagement.titleAssignUser')
        this.dialogAddUserVisible = true
      } else if (flag == 'group') {
        that.addGroupObj.type = "addGroup"
        //"添加到分组"
        that.addGroupObj.title = that.$t('devicemanagement.titleMoveGroup')
        this.dialogAddGroupVisible = true
      }
    }

    closeGroupAction() {
      this.dialogGroupActionVisible = false;
    }

    //点击更多操作
    disBtn() {
      this.showBtn = false;
      this.showTableSelect = true;
    }



    //返回
    comeHome() {
      this.$refs.tables && this.$refs.tables.clearSelection();
      this.showBtn = true;
      this.showTableSelect = false;
    }

    handleSizeChange(val) {
      this.query.page = 1
      this.query.size = val;
      this.searchDeviceList();
    }

    handleCurrentChange(val) {
      this.query.page = val;
      this.searchDeviceList();
    }

    resetDeviceList() {
      this.query.page == 1;
      this.searchDeviceList();
    }

    handleSelectionChange(val) {
      // console.log('单点',val);
      this.multipleSelection = val;
      const obj = this.selectNow;
      if (val.indexOf(obj) == -1){
        //取消选中
        for (let i = 0;i < val.length;i++){
          if (val[i].deviceType == 3){
            // console.log(val[i].childDeviceList,obj);
            if (val[i].childDeviceList.indexOf(obj) != -1){
              // console.log('进验证')
              this.$refs.tables.toggleRowSelection(val[i],false);//全选父设备后，某个子设备取消选中，父设备也取消选中
            }
          }
        }

      } else{
        //选中
        if (obj.deviceType == 3){
          for(let j = 0;j < obj.childDeviceList.length;j++){
            this.$refs.tables.toggleRowSelection(obj.childDeviceList[j],true);//批量删除点击父设备选中子设备
          }
        }
      }
    }
    handleSelection(val){
      console.log('全选',val);
      let count = 0;
      val.forEach(item=>{
        if (item.childDeviceList){
          count++;
        }
      })
      // let bool = count === this.query.size?true:count === 0?false:true
      let bool = count === 0 ? false : true;
      console.log(count,bool);
      if (bool){
        for (let i = 0;i < val.length;i++){
          if (val[i].deviceType == 3){
            for(let j = 0;j < val[i].childDeviceList.length;j++){
                this.$refs.tables.toggleRowSelection(val[i].childDeviceList[j],bool);//批量删除点击父设备选中子设备
            }
          }
        }
      }else if(bool === false){
        let value = this.tableData as any;
        for (let i = 0;i < value.length;i++){
          if (value[i].deviceType == 3){
            for(let j = 0;j < value[i].childDeviceList.length;j++){
              // debugger
                this.$refs.tables.toggleRowSelection(value[i].childDeviceList[j],bool);//批量删除点击父设备选中子设备
            }
          }
        }
      }
    }
    handleSelect(section,row){
      this.selectNow = row;//储存此次点击的设备信息
    }

    leftTreeAction(type) {
      let that = this;
      switch (type) {
        case 1:
          if (!isEmpty(that.query.keywords)) {
            that.query.keywords = '';
          }
          break;
      }
    }

    onKeywordsChange() {
      let that = this;
      (that.$refs.lefttree as any).filterText = '';
      (that.$refs.lefttree as any).onFilterAllChange();
      //清空输的检索条件
      that.query.page = 1;
      //that.query.groupId = '';
      that.searchDeviceList();
    }

    @Watch('query.keywords')
    onQueryKeywordsChange(val: any) {
      if (!isEmpty(val)) {
        this.showSearchClose = true
      } else {
        this.showSearchClose = false
        this.query.page = 1
        this.searchDeviceList()
      }
    }

    clickClearKeywords() {
      this.query.keywords = '';
      this.showSearchClose = false
    }

    tableFilterChange(filter) {
      let that = this as any;
      that.query.page = 1;
      if (filter.deviceType) {
        that.query.deviceType = !isEmptyNotZero(filter.deviceType[0]) ? filter.deviceType[0] : '';
      }
      if (filter.connectStatus) {
        that.query.accessState = !isEmptyNotZero(filter.connectStatus[0]) ? filter.connectStatus[0] : '';
      }
      if (filter.useStatus) {
        that.query.state = !isEmptyNotZero(filter.useStatus[0]) ? filter.useStatus[0] : '';
      }
      that.searchDeviceList();
    }

    // 设备导出
    deviceExport(){
      let that = this as any;
      this.exportLoading = true;
      let userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";
      let params = {
        userId:userId
      }
      DeviceModule.deviceExport(params).then((res)=>{
        console.log(res);
        that.$message({
          showClose: true,
          message: that.$t('devicemanagement.deviceExport'),
          type: 'success'
        });
      }).finally(()=>{
        this.exportLoading = false;
        this.isShowExport = false;
      })
    }

    tableRowClassName({row, rowIndex}) {
      if (row.childDeviceList == undefined) {
        return 'subset-row';
      }
      return 'test';
    }

    expandChange(row,expandRow){
      console.log(row,expandRow)

    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";

  .el-breadcrumb {
    padding: 10px;
  }

  ::v-deep .subset-row {
    >td{
      background: #d2dbea!important;
    }
  }


  .wrap {
    padding: 0 15px;
  }

  .row-bg {
    padding-bottom: 15px;
  }

  .role-permission .el-form-item {
    margin-bottom: 0;
  }

  .wrap .row-bg {
    padding: 10px 0;
  }

  .title {
    line-height: 52px;
    padding-left: 20px;
  }

  .tree-title-class {
    margin-top: 10px
  }

  .active {
    color: #BE0000;
    text-align: left;
    font-weight: 600;
    cursor: pointer;
  }

  .center {
    line-height: 32px;
    height: 32px;
    display: flex;
  }

  .icon-fanhui {
    font-weight: 600;
    font-size: 20px;
    margin-right: 20px;
    cursor: pointer;
  }

  .el-main .main_head {
    padding: 20px 0 16px;
    height: 70px;
  }

  /*.side-title {*/
    /*height: 70px;*/
    /*padding: 25px 0 0 0;*/
    /*margin: 0;*/
  /*}*/

  ::v-deep .el-table__body-wrapper {
    max-height: calc(100% - 65px);
    overflow-y: auto;
  }

  .device-list-operation-item {
    cursor: pointer;
    margin-right: 10px;

    i.iconfont {
      font-size: 19px;
    }
  }
  .main_con{
    height: calc(100% - 104px);
    @include shadowBox();
  }

  ::v-deep .el-table__column-filter-trigger {
    margin-left: 10px;

    i {
      color: black;
      font-size: 16px;
    }
  }

  ::v-deep .el-table tr td:first-child .cell,
   .el-table tr th:first-child .cell{
    padding-left: 16px;
  }

</style>
