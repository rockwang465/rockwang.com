<template>
  <el-container class="container wrap manage-table" style="height: 100%">
      <el-aside width="312px">
        <h2 class="side-title">
          <!--部门分组-->
          <i class="iconfont icon-group"></i>
          <span>{{$t('usermanagement.labelUserGroup')}}</span>
        </h2>
        <LeftTree ref="lefttree" class="tree"
          :treeData="treeData"
          :leftTreeData="leftTreeData"
          :currentNodeKey="currentNodeKey"
          @clickVal="clickVal"
          @showDetail="showDetail"
          @addData="addData"
          @updateData="updateData"
          @deleteData="deleteData">
        </LeftTree>
      </el-aside>
      <el-main class="main" style="height: 100%;">
        <el-row class="main_head">
          <el-col :span="11" v-show="showBtn" style="height: 32px;">
            <el-button @click="showUserAdd = true" v-if="$permission('002319')" type="primary" size="small" icon="iconfont icon-add-user">{{$t('usermanagement.buttonAddUser')}}
              <!--添加用户-->
            </el-button>
            <el-button v-if="$permission('002232') || $permission('002233') || $permission('002234') ||$permission('002235') || $permission('002422')"  @click="disBtn" type="primary" size="small" icon="iconfont icon-batch-handle">
              <!--批量操作-->
              {{$t('usermanagement.buttonBatch')}}
            </el-button>
            <!--导出-->
            <el-button v-if="$permission('002329')" type="primary" size="small" icon="iconfont icon-batch-export" @click="userExport">{{$t('usermanagement.buttonExport')}}</el-button>
            &nbsp;
          </el-col>
          <el-col :span="11" v-show="!showBtn" style="height: 32px;">
            <i @click="comeHome" class="iconfont icon-fanhui"></i>
            <el-button v-if="$permission('002232')" type="primary" size="small" icon="iconfont icon-add-group" @click="UserGroup">
              <!--移动到分组-->
              {{$t('usermanagement.buttonMoveGroup')}}
            </el-button>
            <el-button v-if="$permission('002233')" type="primary" size="small" icon="iconfont icon-add-user" @click="openUserAuthority">
              <!--修改角色-->
              {{$t('usermanagement.buttonEditRole')}}
            </el-button>
            <!--启用-->
            <el-button v-if="$permission('002234')" type="primary" size="small" icon="iconfont icon-on-off" @click="opendStart(2)">{{$t('usermanagement.buttonEnable')}}</el-button>
            <!--停用-->
            <el-button v-if="$permission('002235')" type="primary" size="small" icon="iconfont icon-disable" @click="opendStop(1)">{{$t('usermanagement.buttonDisable')}}</el-button>
            <!--删除-->
            <el-button v-if="$permission('002422')" type="danger" size="small" icon="iconfont icon-delete" @click="deleteCheck">{{$t('usermanagement.buttonDelete')}}</el-button>
          </el-col>
          <el-col :span="5" class="center" style="height: 32px;">
            <!--用户数量-->
            <el-col><span>{{$t('usermanagement.contTotalUser',{number:total})}}</span> <i class="iconfont icon icon-separator"></i>
              <!--激活-->
              <span class="active">{{$t('usermanagement.contEnabledUser')}} {{activationCount}}</span></el-col>
          </el-col>
          <el-col :span="4" :push="4">
            <el-input class="userInp"
                      @focus="inputFocus"
                      @blur="inputBlur"
              :placeholder="$t('usermanagement.labelUsername')+'/'+$t('usermanagement.labelRealname')+'/'+$t('usermanagement.labelID')"
              size="small"
              v-model="input">
              <span class="suffix-icon" slot="suffix">
                <Icon
                  v-if="showSearchClose"
                  type="ele"
                  size="15"
                  cursor="pointer"
                  name="circle-close"
                  @click="clickClearKeywords"
                />
                <Icon
                  type="ele"
                  size="15"
                  cursor="pointer"
                  name="search"
                  @click="onKeywordsChange"
                />
              </span>
            </el-input>
          </el-col>
        </el-row>
        <!--减去头部按钮和下部分页的高度-->
        <el-row style="width: 100%;height:calc(100% - 106px)">
          <!--<el-col :span="24" style="height: 100%;background-color: #fff;overflow: auto">-->
          <el-col class="addShadow" :span="24" style="height:100%;width: 100%;">
            <el-table
                stripe
                v-loading="loading"
                :data="tableData"
                style="width: 100%;height: calc(100% - 54px);"
                ref="tables"
                @filter-change="tableFilterChange"
                @selection-change="handleSelectionChange" @sort-change="dateSort">
                <el-table-column v-if="showSelect"
                                 type="selection"
                                 width="55">
                </el-table-column>
              <el-table-column
                prop=""
                label=" "
                width="30">
              </el-table-column>
                <!--用户名-->
                <el-table-column
                  prop="username"
                  :label="$t('usermanagement.labelUsername')"
                  width="200">
                </el-table-column>

                <!--间隔-->
                <el-table-column
                  prop=""
                  label=" "
                  width="20">
                </el-table-column>
                <!--姓名-->
                <el-table-column
                  prop="realname"
                  :label="$t('usermanagement.labelRealname')"
                  width="150">
                </el-table-column>
              <!--间隔-->
              <el-table-column
                prop=""
                label=" "
                width="20">
              </el-table-column>
                <!--ID-->
                <el-table-column
                  prop="ID"
                  :label="$t('usermanagement.labelID')"
                  width="180"
                >
                </el-table-column>
              <!--间隔-->
              <el-table-column
                prop=""
                label=" "
                width="20">
              </el-table-column>
                <!--部门-->
                <el-table-column
                  prop="orgName"
                  :label="$t('usermanagement.labelDepartment')"
                  width="150">
                </el-table-column>
              <!--间隔-->
              <el-table-column
                prop=""
                label=" "
                width="20">
              </el-table-column>
                <!--角色-->
                <el-table-column
                  prop="roleName"
                  :label="$t('usermanagement.labelRole')"
                  width="200">
                </el-table-column>
              <!--间隔-->
              <el-table-column
                prop=""
                label=" "
                width="20">
              </el-table-column>
                <!--添加时间-->
                <el-table-column
                  prop="createTime"
                  :label="$t('usermanagement.labelTimeCreation')"
                  sortable="custom"
                  width="224"
                >
                </el-table-column>
              <!--间隔-->
              <el-table-column
                prop=""
                label=" "
                width="20">
              </el-table-column>
                <!--状态-->
                <el-table-column
                  prop="state"
                  column-key="runStatus"
                  :filter-multiple="false"
                  :filters="[{text: $t('rule.buttonRuleStausEnabled'), value: 1}, {text: $t('rule.buttonRuleStausDisabled'), value: 0}]"
                  :label="$t('usermanagement.labelStatus')"
                  width="140"
                >
                  <!--:render-header="renderUseStatus"-->
                  <template slot-scope="scope">
                    <el-switch
                      :disabled="!$permission('002225')"
                      @change="showUpdateStates(scope.row)"
                      v-model="scope.row.state === 1"
                      active-color="#13ce66"
                      inactive-color="#ff4949">
                    </el-switch>
                  </template>
                </el-table-column>
              <!--间隔-->
              <el-table-column
                prop=""
                label=" "
                width="20">
              </el-table-column>
                <!--操作-->
                <el-table-column
                  width="112"
                  :label="$t('usermanagement.labelOperation')">
                  <template slot-scope="scope">
                    <!--打开详情-->
                    <span class="rule-list-operation-item" v-if="$permission('002118')"  @click="openDetails(scope.$index,tableData)">
                      <i class="iconfont icon-view"  ></i>
                    </span>
                    <!--打开编辑-->
                    <span class="rule-list-operation-item" v-if="$permission('002220')" @click="openEdit(scope.$index,tableData)">
                      <i class="iconfont icon-edit"  ></i>
                    </span>
                    <!--删除-->
                    <span class="rule-list-operation-item" v-if="$permission('002421')"  @click="deleteUser(scope.$index,tableData)">
                      <i class="iconfont icon-delete"></i>
                    </span>
                  </template>
                </el-table-column>
              <!--间隔-->
              <el-table-column
                prop=""
                label=" "
                min-width="30">
              </el-table-column>
              </el-table>
            <el-pagination class="page"
                           @size-change="handleSizeChange"
                           @current-change="handleCurrentChange"
                           :current-page="1"
                           :page-sizes="[10, 20, 30, 50,100]"
                           :page-size="size"
                           layout="total, sizes, prev, pager, next, jumper"
                           :total="total">
            </el-pagination>
          </el-col>
        </el-row>
      </el-main>

    <!--用户分组详情组件-->
    <groupDetails :dataObj="groupDetailsObj" :dialogVisible="showGroupDetails" @closeGroupDetails="closeGroupDetails"></groupDetails>
    <!--用户分组详情组件-->

    <!--用户分组添加组件-->
    <groupAdd :dataObj="groupActionObj" :dialogVisible="showGroupAdd" @handleGroupAction="handleGroupAction" @closeGroupAdd="closeGroupAdd"></groupAdd>
    <!--用户分组添加组件-->

    <!--分组编辑组件-->
    <groupEdit :dataObj="groupActionObj" :dialogVisible="showGroupEdit" @handleGroupAction="handleGroupAction" @closeGroupEdit="closeGroupEdit"></groupEdit>
    <!--分组编辑组件-->
    <!--分组删除组件-->
    <groupDelete :dataObj="groupActionObj" :dialogVisible="showGroupDelete" @handleGroupAction="handleGroupAction" @closeGroupDelete="closeGroupDelete"></groupDelete>
    <!--分组删除组件-->
    <!--用户添加组件-->
    <userAdd :dialogVisible="showUserAdd" :dataObj="clickTreeData" :roleList="roleObj.roleList" :id="orgId" @inIt="searchUserList" @closeUserAdd="closeUserAdd"></userAdd>
    <!--用户添加组件-->
    <!--用户删除组件-->
    <userDelete :usId="uId" :dialogVisible="showUserDelete" @closeUserDelete="closeUserDelete" @searchUserList="searchUserList"></userDelete>
    <!--用户删除组件-->
    <!--用户详情组件-->
    <userDetails :userInfo="tableInfo" :roleName="roleName" :roleObj="roleObj.roleList" :dialogVisible="showUserDetails" @closeUserDetails="closeUserDetails"></userDetails>
    <!--用户详情组件-->
    <!--用户编辑组件-->
    <userEdit :userInfo="tableInfo" :roleName="roleName" :dataObj="clickTreeData" :roleObj="roleObj.roleList" :dialogVisible="showUserEdit" @inIt="searchUserList" @closeUserEdit="closeUserEdit"></userEdit>
    <!--用户编辑组件-->
    <!--用户导出-->
    <userOut :dialogVisible="showUserOut" :total="total" :keywords="input" :orgId="orgId" :sort="sort" :state="state" @closeUserOut="closeUserOut"></userOut>
    <!--用户导出-->
    <!--添加到分组-->
    <userAddGroup :dialogVisible="showUserAddGroup" :dataObj="addGroupObj" @inIt="searchUserList" @closeEdit="closeAddGroup"></userAddGroup>
    <!--添加到分组-->
    <!--修改角色-->
    <userAuthority :dataObj="roleObj" @inIt="searchUserList" :dialogVisible="showUserAuthority" @closeUserAuthority="closeUserAuthority"></userAuthority>
    <!--修改角色-->
    <!--修改密码-->
    <userPassword :dialogVisible="showUserPassword" @closeUserPassword="closeUserPassword"></userPassword>
    <!--修改密码-->
    <!--启用状态弹框-->
    <!--提示-->
    <el-dialog
      :title="$t('usermanagement.titleReminder')"
      :visible.sync="showStart"
      width="30%">
      <!--启用后，该用户将能登录系统，可以使用已经分配的功能权限-->
      <p class="tips">{{$tc('usermanagement.popmsgUserEnable')}}</p>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="startUsing">{{$t('usermanagement.buttonOK')}}</el-button>
        <el-button type="info" class="cancel" @click="showStart = false">{{$t('usermanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!--启用状态弹框-->
    <!--禁用弹框-->
    <!--提示-->
    <el-dialog
      :title="$t('usermanagement.titleReminder')"
      :visible.sync="showDisplay"
      width="30%">
      <!--禁用后，该用户将不能再登录系统，但可以查询到相关的历史信息-->
      <p class="tips">{{$t('usermanagement.popmsgUserDisable')}}</p>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="disUsing">{{$t('usermanagement.buttonOK')}}</el-button>
        <el-button type="info" class="cancel" @click="showDisplay = false">{{$t('usermanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!--禁用弹框-->
    <!--批量删除弹框-->
    <el-dialog
      :title="$t('usermanagement.listDelete')"
      :visible.sync="showAllDelete"
      width="30%">
      <div class="content">
        <!--删除后，已选用户将不再支持使用！-->
        {{$t('usermanagement.popmsgUserDelete')}}
      </div>
      <span slot="footer" class="dialog-footer">
        <!--删除-->
        <el-button type="danger" @click="deleteAll">{{$t('usermanagement.buttonDelete')}}</el-button>
        <el-button type="info" class="cancel" @click="showAllDelete = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--批量删除弹框-->
  </el-container>

</template>
<script lang="ts">

import { Component, Vue, Watch } from 'vue-property-decorator';

import { Route } from 'vue-router';

import LeftTree from '@/components/leftTree/index.vue';

import groupDetails from './userGroup/groupDetails.vue';

import groupAdd from './userGroup/groupAdd.vue'

import groupEdit from './userGroup/groupEdit.vue'

import groupDelete from './userGroup/groupDelete.vue'

import userAdd from './userHandle/userAdd.vue';

import userDelete from './userHandle/userDelete.vue';

import userDetails from './userHandle/userDetails.vue';

import userEdit from './userHandle/userEdit.vue';

import userOut from './userHandle/userOut.vue';

import userAddGroup from '@/components/userAddGroup/index.vue'

import userAuthority from './userHandle/userAuthority.vue';

import userPassword from './userHandle/userPassword.vue';

import {UserModule} from '@/store/modules/user';

import {RoleModule} from '@/store/modules/role';

import Icon from '@/components/icon-wrap/index.vue';
import {isEmpty} from '@/utils/validate';

const permissionOptions = [
  {
    id:"1",
    name:"监控",
    permissions:[
      {id:"1",text:'查看',disabled:false},
      {id:"2",text:'添加',disabled:true},
      {id:"3",text:'删除',disabled:false},
      {id:"4",text:'修改',disabled:false},
      {id:"5",text:'导出',disabled:false}
    ]
  },
  {
    id:"2",
    name:"检索",
    permissions:[
      {id:"1",text:'查看',disabled:false},
      {id:"2",text:'添加',disabled:false},
      {id:"3",text:'删除',disabled:false},
      {id:"4",text:'修改',disabled:false},
      {id:"5",text:'导出',disabled:false}
    ]
  }
];

@Component({
  components: {
    LeftTree,
    groupDetails, //分组详情
    groupAdd,     //分组添加
    groupEdit,    //分组编辑
    groupDelete,   //分组删除
    userAdd,       //添加用户
    userDelete,     //用户删除
    userDetails,    //用户详情
    userEdit,       //用户编辑
    userOut,        //用户导出
    userAddGroup,       //添加分组
    userAuthority,  //修改权限
    userPassword,    //修改密码
    Icon
  },
})
export default class User extends Vue {
  loading=false
  showSearchClose = false
  //data-begin
  clickTree = false as any;
  tableInfo = {} as any;
  orgId = 1;
  page = 1;
  size = 10;
  total = 0;
  activationCount = 0;//激活数量
  uId = 1;
  parentId = 0;
  redirect: string | undefined = undefined;
  dialogFormVisible= false;
  showGroupDetails = false;
  showGroupAdd = false;
  showGroupEdit = false;
  showGroupDelete = false;
  showUserAdd = false;
  showUserDelete = false;
  showUserDetails = false;
  showUserEdit = false;
  showUserOut = false;
  showBtn = true;
  showUserAddGroup = false;
  showUserAuthority = false;
  showUserPassword = false;
  showStart = false;
  showDisplay = false;
  showSelect = false;
  showAllDelete = false;
  multipleSelection = [];
  defaultProps = {
    children: 'children',
    label: 'label'
  };
  treeData = [] as any;
  checkAll= false;
  checkedCities= [];
  state = null;
  checkedPermissions:any = [];
  cities= permissionOptions;
  isIndeterminate= true;
  formLabelWidth= '120px';
  subLabelWidth="80px";
  input : string = '';
  tableData = [];
  focusEnter = false
  leftTreeData={
    label:'name',
    actionArray: [1, 1, 1, 1, 1] //设备树的按钮显示影藏 创建同级 创建下一级 详情 重命名 分组
  } as any;
  addGroupObj = {
    title: '',
    type:'',
    checkList: [],
    treeUserData: [],
  } as any;
  groupActionObj = {
    title: '',
    type: ''
  } as any;//分组操作组件之间交互的对象值
  groupDetailsObj = {} as any;
  userInfo = {} as any;
  userIdArr:any = [];
  sort = "DESC";
  roleObj = {
    roleList:[],
    title:''
  } as any;
  disStyle = 0;
  roleName = "";
  deviceList = [] as any;
  clickTreeData = {} as any;
  currentNodeKey = 0
  //data-end

  @Watch('$route', { immediate: true })
  OnRouteChange(route: Route) {
    // See https://github.com/vuejs/vue-router/pull/2050 for details
    this.redirect = route.query && route.query.redirect as string;
  }
  onKeywordsChange() {
    let that = this as any;
    (that.$refs.lefttree as any).filterText = '';
    (that.$refs.lefttree as any).onFilterAllChange();
    this.page = 1;
    this.search()
  }
  clickClearKeywords() {
    this.input = '';
    this.showSearchClose = false
    this.page = 1
    this.searchUserList();
  }

  inputFocus(){
    this.focusEnter = true;
    let that = this as any;
    window.document.onkeydown = function(event){
      if (that.focusEnter) {
        if (event.keyCode == 13){
          that.onKeywordsChange();
        }
      }
    }
  }

  inputBlur(){
    this.focusEnter = false;
  }

  @Watch('input')
  onInputChange(val: any) {
    if (!isEmpty(val)) {
      this.showSearchClose = true
    }
    if (val == ''){
      this.clickClearKeywords();
    }
  }

  //搜索框失焦，清除绑定值
  // inputBlur(){
  //   this.input = '';
  // }
  //获取初始化列表
  searchUserList(){
    this.loading = true;
    let params = {
      orgId: this.orgId,
      page: this.page,
      size: this.size,
      sort: this.sort,
      state:this.state
    };
    // console.log('this.orgId',this.orgId)
    // this.currentNodeKey = this.orgId;
    UserModule.GetUserList(params).then((data: any) => {
      this.loading = false;
      this.activationCount = data.activationCount;
      this.total = data.total;
      this.tableData = data.data;
      console.log('用户列表数据',this.tableData);
    }).catch((err) => {
      this.loading = false;
    });
  }
  //获取角色list
  searchData() {
    let that = this as any;
    let params = {
      page: that.page,
      size: 10000,
      sort: that.sort,
      state: that.state,
      keywords: that.keywords
    };
    RoleModule.GetRoleList(params).then((data: any) => {
      console.log('角色列表',data.data)
      this.roleObj.roleList = data.data;
      //this.roleObj.roleList.children = [] as any;
    }).catch((err) => {
      console.log(err)
    });
  }
  //显示改变设备状态
  showUpdateStates(obj) {
    this.disStyle = 0;
    console.log(obj);
    this.userInfo = obj;
    if(obj.state){
       this.showDisplay = true;
    }else {
      this.showStart = true;
    }
  }
  tableFilterChange(filter){
    console.log(filter)
    let condition = Object.keys(filter)[0];
    let num = '' as any;
    if(condition == 'runStatus'){
      num = filter['runStatus'][0];
    }
    this.state = num;
    this.searchUserList();
  }
  //启用
  startUsing(){
    let that = this as any;
    if(this.disStyle === 2){
      this.multipleSelection.forEach((item:any)=>{
        this.userIdArr.push(item.userId);
      })
      this.showStart = false;
      UserModule.BatchStartUser(this.userIdArr).then((data: any) => {
        console.log('禁用用户',data);
        this.$message({
          showClose: true,
          // message: "启用用户成功",
          message: that.$t('globaltip.tipmsgBatchEnableUser'),
          type: 'success'
        });
        this.showDisplay = false;
        this.userIdArr = [];
        this.searchUserList();
      }).catch((err) => {
        this.showStart = false;
        this.userIdArr = [];
      });
    }else{
      let dataObj : any = {};
      dataObj.params = {
        state : 1
      };
      this.showStart = false;
      dataObj.id = this.userInfo.userId;
      let that = this as any;
      UserModule.UpDataState(dataObj).then((data: any) => {
        console.log(data);
        this.showStart = false;
        this.searchUserList();
        this.$message({
          showClose: true,
          // message: "用户启用成功",
          message: that.$t('globaltip.tipmsgBatchEnableUser'),
          type: 'success'
        })
      }).catch((err) => {
        this.showStart = false;
      });
    }
  }
  //禁用
  disUsing(){
    //批量禁用
    if(this.disStyle === 1){
      this.multipleSelection.forEach((item:any)=>{
        this.userIdArr.push(item.userId);
      })
      this.showDisplay = false;
      let that = this as any;
      UserModule.BatchStopUser(this.userIdArr).then((data: any) => {
        console.log('禁用用户',data);
        this.$message({
          showClose: true,
          // message: "禁用用户成功",
          message: that.$t('globaltip.tipmsgBatchDisableUser'),
          type: 'success'
        });
        this.showDisplay = false;
        this.userIdArr = [];
        this.searchUserList();
      }).catch((err) => {
        this.showDisplay = false;
        this.userIdArr = [];
      });
    }else{
      //单个禁用
      let dataObj : any = {};
      dataObj.params = {
        state: 0
      };
      this.showDisplay = false;
      dataObj.id = this.userInfo.userId;
      let that = this as any;
      UserModule.UpDataState(dataObj).then((data: any) => {
        console.log(data);
        this.showDisplay = false;
        this.searchUserList();
        this.$message({
          showClose: true,
          // message: "用户禁用成功",
          message: that.$t('globaltip.tipmsgBatchDisableUser'),
          type: 'success'
        })
      }).catch((err) => {
        this.showDisplay = false;
      });
    }
  }
  //关键字检索用户
  search(){
    this.loading = true;
    let params = {
      orgId: this.clickTree?this.orgId:null,
      keywords : this.input,
      page: this.page,
      size: this.size,
      sort: this.sort
    }
    //this.currentNodeKey = params.orgId
    UserModule.SearchUseList(params).then((data: any) => {
      this.loading = false;
      this.activationCount = data.activationCount;
      this.total = data.total;
      this.tableData = data.data;
      console.log('用户列表数据',this.tableData,data);
    }).catch((err) => {
      this.loading = false;
    });
  }
  //获取用户详情信息
  getDetails(){
    let dataObj = {} as any;
    dataObj.params = {};
    dataObj.userId = this.uId;
    UserModule.GetUserDetails(dataObj).then((data: any) => {
      console.log('用户列表数据',data);
      this.tableInfo = data;
      this.tableInfo.orgId = this.orgId;
      this.roleName = this.tableInfo.roleName;
    }).catch((err) => {

    });
  }
  //获取部门分组
  getUserGroup(){
    let params = {} as any;
    let that = this as any;
    UserModule.GetUserGroup(params).then((data: any) => {
      console.log('分组数据',data);
      this.treeData = data.data;
      that.addGroupObj.treeData = data.data;
      that.clickTreeData = data.data[0];

      //默认选中第一项
      that.clickVal(that.treeData[0])

    }).catch((err) => {

    });
  }
  mounted(){
    let that = this as any;
    that.leftTreeData.actionArray = [that.$permission('002304'), that.$permission('002304'), that.$permission('002103'), that.$permission('002205'), that.$permission('002406')];
    permissionOptions.map(item =>{
      item.permissions.map(i =>{
        let checkedItem = item.id + i.text;
        this.checkedPermissions.push("checkedItem");
      })
    })
    this.searchUserList();
    this.getUserGroup();
    this.searchData();

  }
  //点击目录树
  clickVal(localData: any){
    console.log(localData);
    this.currentNodeKey = localData.id
    this.clickTreeData = localData
    this.clickTree = true;
    this.orgId = localData.id;
    this.page = 1;
    if(this.input == ''){
      this.searchUserList();
    }else{
      this.search();
    }
  }
  disBtn(){
    this.showBtn = false;
    this.showSelect = true;
  }
  $refs !:{
    tables:HTMLFormElement,
    lefttree:HTMLFormElement,
  };

  comeHome(){
    this.$refs.tables && this.$refs.tables.clearSelection();
    this.showBtn = true;
    this.showSelect = false;
  }
  //查看详情
  showDetail(localData: any) {
    let that = this;
    this.showGroupDetails = true;
    this.groupActionObj.title = "详情";
    this.groupActionObj.type = "detail";
    this.groupActionObj.localData = localData;
    //查询分组详情
    UserModule.GetGroupDetails(this.groupActionObj.localData.id).then((data: any) => {
      that.groupDetailsObj = data;
      console.log(that.groupDetailsObj);
    }).catch((err) => {

    });
  }

  //关闭详情
  closeGroupDetails(){
    this.showGroupDetails = false;
  }
  //添加数据
  addData(flag: any, localData: any) {
    this.showGroupAdd = true;
    this.groupActionObj.title = flag == 'level' ? "添加同级分组" : "添加下级分组"
    this.groupActionObj.type = flag == 'level' ? "addLevel" : "addNext"
    this.groupActionObj.localData = localData;
    // console.log(this.groupActionObj);
  }
  opendStart(num){
    let that = this as any;
    if(this.multipleSelection.length === 0){
      this.$message({
        showClose: true,
        // message: "请选择用户",
        message: that.$t('usermanagement.titleSelectUser'),
        type: 'error'
      });
    }else{
      this.showStart = true;
      this.disStyle = num;
    }
  }
  //禁用按钮
  opendStop(num){
    let that = this as any;
    if(this.multipleSelection.length === 0){
      this.$message({
        showClose: true,
        // message: "请选择用户",
        message: that.$t('usermanagement.titleSelectUser'),
        type: 'error'
      });
    }else{
      this.showDisplay = true;
      this.disStyle = num;
    }
  }
  //关闭分组添加
  closeGroupAdd(){
    this.showGroupAdd = false;
  }
  //点击关闭用户删除
  closeUserDelete(){
    this.showUserDelete = false;
  }
  //点击展示用户删除
  deleteUser(index:any,data:any){
    this.uId = data[index].userId;
    console.log(this.uId);
    this.showUserDelete = true;
  }
  //关闭用户详情
  closeUserDetails(){
    this.showUserDetails = false;
  }
  //打开详情
  openDetails(index:any,data:any){

    console.log(index,data);
    this.uId = data[index].userId;
    console.log(this.uId);
    // this.getDetails();
    let dataObj = {} as any;
    dataObj.params = {};
    dataObj.userId = this.uId;
    UserModule.GetUserDetails(dataObj).then((data: any) => {
      console.log('用户列表数据',data);
      this.tableInfo = data;
      this.tableInfo.orgId = this.orgId;
      this.roleName = this.tableInfo.roleName;
      this.showUserDetails = true;
    }).catch((err) => {

    });
  }
  //打开用户编辑
  openEdit(index,data){
    console.log(index,data);
    this.uId = data[index].userId;
    console.log(this.uId);
    // this.getDetails();
    let dataObj = {} as any;
    dataObj.params = {};
    dataObj.userId = this.uId;
    UserModule.GetUserDetails(dataObj).then((data: any) => {
      console.log('用户列表数据',data);
      this.tableInfo = data;
      this.tableInfo.orgId = this.orgId;
      this.roleName = this.tableInfo.roleName;
      this.showUserEdit = true;
    }).catch((err) => {

    });
  }
  //关闭用户编辑
  closeUserEdit(){
    this.showUserEdit = false;
  }
  //编辑数据
  updateData(localData: any) {
    this.showGroupEdit = true;
    this.groupActionObj.title = "编辑";
    this.groupActionObj.type = "edit";
    this.groupActionObj.localData = localData;
    console.log(this.groupActionObj);
  }
  //关闭编辑
  closeGroupEdit(){
    this.showGroupEdit = false;
  }
  //删除数据
  deleteData(localData: any) {
    this.showGroupDelete = true;
    this.groupActionObj.title = "删除"
    this.groupActionObj.type = "delete"
    this.groupActionObj.localData = localData;
    console.log(this.groupActionObj);
  }
  //关闭删除分组
  closeGroupDelete(){
    this.showGroupDelete = false;
  }
  handleCheckAllChange(val) {
    this.checkedCities = val ? this.checkedPermissions : [];
    this.isIndeterminate = false;
  }
  handleCheckedCitiesChange(value) {
    let checkedCount = value.length;
    this.checkAll = checkedCount === this.cities.length;
    this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
  }

  handleNodeClick(data:any) {
    console.log(data);
  }
  showData(){
    //console.log(this.$data);
  }

  //分组增加操作
  handleGroupAction(obj, valueData){
    let that = this as any;
    let params = {} as any;
    switch (obj.type){
      //同级添加分组
      case "addLevel":
        params.name = valueData;
        params.parentId = obj.localData.parentId;
        UserModule.AddUserGroup(params).then((data: any) => {
          if (data.code == "407003") {
            // that.$message.error('已存在相同名字的分组,请重新命名添加!');
            that.$message.error({showClose: true,message:that.$t('imagemanagement.NameRepetition')});
            return;
          }
          that.$message({
            showClose: true,
            // message: "添加同级分组成功",
            message: that.$t('devicemanagement.groupAddSuccess'),
            type: 'success'
          })
          this.getUserGroup();
        }).catch((err) => {

        });
        break;
      //添加下一级分组
      case "addNext":
        params.name = valueData;
        params.parentId = obj.localData.id;
        UserModule.AddUserGroup(params).then((data: any) => {
          if (data.code == "407003") {
            // that.$message.error('已存在相同名字的分组,请重新命名添加!');
            that.$message.error({showClose: true,message:that.$t('imagemanagement.NameRepetition')});
            return;
          }
          that.$message({
            showClose: true,
            // message: "添加下级分组成功",
            message: that.$t('devicemanagement.groupNextAddSuccess'),
            type: 'success'
          })
          this.getUserGroup();
        }).catch((err) => {

        });
        break;
      //修改分组
      case "edit":
        let objData = {} as any;
        objData.params = {name: valueData}
        objData.id = obj.localData.id
        UserModule.UpdateGroup(objData).then((data: any) => {
          if (data.code == "407003") {
            // that.$message.error('已存在相同名字的分组,请重新命名修改!');
            that.$message.error({showClose: true,message:that.$t('imagemanagement.NameRepetition')});
            return;
          }
          // that.$message({
          //   message: '修改分组成功',
          //   type: 'success'
          // })
          this.getUserGroup();
        }).catch((err) => {

          console.log(err)
        });
        //这里
        break;
      //删除分组
      case "delete":
        UserModule.DeleteGroup(obj.localData.id).then((data: any) => {
          that.$message({
            showClose: true,
            // message: "删除分组成功",
            message: that.$t('devicemanagement.groupDeleteSuccess'),
            type: 'success'
          })
          this.getUserGroup();
          this.orgId = 1;
          this.searchUserList();
        }).catch((err) => {

        });
        break;
    }
  }
  //关闭用户添加
  closeUserAdd(){
    this.showUserAdd = false;
  }
  //打开用户导出
  userExport(){
     this.showUserOut = true;
  }
  //关闭用户导出
  closeUserOut(){
    this.showUserOut = false;
  }
  handleLogin() {
    //test permission
  }
  //关闭添加分组
  closeAddGroup() {
    this.showUserAddGroup = false
  }
  //点击添加分组按钮
  UserGroup(){
    if(this.multipleSelection.length > 0){
      this.showUserAddGroup = true;
      this.addGroupObj.title = '添加到分组';
      this.addGroupObj.type = 'addGroup';
      this.addGroupObj.checkList =  this.multipleSelection;
    }else{
      let that = this as any;
      this.$message({
        showClose: true,
        // message: "请选择用户",
        message: that.$t('usermanagement.titleSelectUser'),
        type: 'error'
      });
    }
  }
  //打开修改权限
  openUserAuthority(){
    if(this.multipleSelection.length > 0){
      this.showUserAuthority = true;
      this.roleObj.title = '修改角色';
      this.roleObj.type = 'upDataRole';
      this.roleObj.checkList =  this.multipleSelection;
    }else{
      let that = this as any;
      this.$message({
        showClose: true,
        // message: "请选择用户",
        message: that.$t('usermanagement.titleSelectUser'),
        type: 'error'
      });
    }
  }
  //关闭修改权限
  closeUserAuthority(){
    this.showUserAuthority = false;
  }
  //关闭修改密码
  closeUserPassword(){
    this.showUserPassword = false;
  }
  //分码大小处理
  handleSizeChange(val){
    this.page = 1;
    this.size = val;
    if(this.input.length>0){
      this.search()
    }else{
      this.searchUserList();
    }
  }
  //当前页变动处理
  handleCurrentChange(val){
    this.page = val;
    if(this.input.length>0){
      this.search()
    }else{
      this.searchUserList();
    }
  }
  renderUseStatus(h, {column, $index}) {
    let that = this as any;
    return h("el-dropdown", {
      style: {
        paddingLeft: 0,
        marginTop: '5px'
      },
      props: {
        trigger: 'click',
      },
      on: {
        command: this.handleCommand
      }
    }, [
      h("span", {
        style: {
          marginTop: '10px',
          color: '#99a5b9'
        },
        class: "el-dropdown-link",
      }, [that.$t('usermanagement.labelStatus'), h("i", {class: "el-icon-arrow-down el-icon--right"})]),
      h("el-dropdown-menu", {
        slot: "dropdown",
      }, [
        h("el-dropdown-item", {props: {command: ''}}, that.$t('usermanagement.listStatusAll')),//'不限'
        h("el-dropdown-item", {props: {command: '1'}}, that.$t('usermanagement.listStatusEnabled')),//'激活'
        h("el-dropdown-item", {props: {command: '0'}}, that.$t('usermanagement.listStatusDisabled'))//'禁用'
      ]),
    ])
  }
  handleCommand(command) {
    console.log(command);
    this.state = command;
    this.searchUserList();
  }
  handleSelectionChange(val) {
    this.multipleSelection = val;
    console.log(this.multipleSelection);
  }
  //批量删除
  deleteCheck(){
    let that = this as any;
    if(this.multipleSelection.length===0){
      this.$message({
        showClose: true,
        // message: '请选择要删除的用户',
        message:  that.$t('devicemanagement.chooseUser'),
        type: 'error'
      });
    }else{
      this.showAllDelete = true;
    }
  }
  //点击删除发送请求
  deleteAll(){
    let that = this as any;
    this.userIdArr = [];
    this.multipleSelection.forEach((item:any)=>{
      this.userIdArr.push(item.userId);
    })
    UserModule.DeleteAll(this.userIdArr).then((data: any) => {
      console.log('删除用户',data);
      this.$message({
        showClose: true,
        // message: "删除用户成功",
        message: that.$t('globaltip.tipmsgBatchDeleteUser'),
        type: 'success'
      });
      this.showAllDelete = false;
      this.userIdArr = [];
     this.searchUserList();
    }).catch((err) => {

    });
  }
  //时间排序
  dateSort(val){
    console.log(val);
    if (val.prop == 'createTime') {
      this.sort = val.order == 'ascending' ? 'ASC' : val.order == 'descending' ? 'DESC' : 'DESC'
    }
    this.page = 1;
    this.searchUserList();
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
$bg:#2d3a4b;
$light_gray:#eee;
/*.side-title{*/
  /*margin: 4px;*/
  /*font-size: 16px;*/
  /*padding: 38px 20px 16px 0;*/
/*}*/
.el-breadcrumb{
  padding: 10px;
}
.wrap{padding:0 8px;}
.row-bg {padding-bottom: 15px ;}

.role-permission .el-form-item{
  margin-bottom: 0;
}
.wrap .row-bg{
  padding: 10px 0;
}
.title{
  line-height: 52px;
  padding-left: 20px;
}
.center{
  line-height: 32px;
  display: flex;
}
.icon-fanhui{
  font-weight:600;
  font-size: 20px;
  cursor: pointer;
  margin-right: 20px;
}
  .userInp ::v-deep .el-input__prefix{
    left: 170px;
  }
  .active{
    color: #BE0000;
    text-align: left;
    font-weight: 600;
    cursor: pointer;
  }

::v-deep .el-dialog__footer{
  text-align: center !important;
}
//修改分组名称格式问题
/*::v-deep .el-dialog__body {*/
  /*padding: 0 0 20px 0 !important;*/
/*}*/
.tips{
  text-align: center;
  padding: 30px 0;
  width: 100%;
  word-break: break-all;
  white-space:pre-wrap;
  word-wrap:break-word;
//overflow:hidden;
}
::v-deep .el-table th, .el-table td{
  padding: 10px 0 !important;
  /*text-align: center;*/
}
/*::v-deep .el-table--enable-row-transition .el-table__body td{*/
    /*text-align: center !important;*/
  /*}*/
.content{
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  padding: 20px;
}
.content>div{
  width: 45%;
}
.content>div span{
  width: 100%;
  display: flex;
  line-height: 16px;
  margin-top: 10px;
}
.content .left span{
  padding-left: 70%;
  font-weight: 600;
}
::v-deep .el-dropdown{
     cursor: pointer;
  }
::v-deep .el-table__body-wrapper{
  height: calc(100% - 65px);
  overflow-y: auto;
}
.rule-list-operation-item {
  cursor: pointer;
  margin-right: 10px;
  i.iconfont {
    font-size: 19px;
  }
}
  ::v-deep .el-table__column-filter-trigger {
    margin-left: 10px;

    i {
      color: black;
      font-size: 16px;
    }
  }
  .addShadow{
    @include shadowBox();
  }
</style>
