<template>
  <div>
    <el-dialog
      :title="dataObj.title"
      :visible.sync="dialogShowVisible"
      width="584px">

      <div class="content">
        <div class="div-class-delete" v-if="dataObj.type == 'delete'">
          {{deleteInfo}}
        </div>
        <div class="div-class-delete" v-if="dataObj.type == 'updateStatus'">
          {{dataObj.roleObj.state == 1 ? $t('rolemanagement.popmsgRoleDisable') : $t('rolemanagement.popmsgRoleEnable')}}
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" v-if="dataObj.type == 'updateStatus'" @click="handleAction">{{$t('rolemanagement.buttonOK')}}</el-button>
        <el-button type="danger" v-if="dataObj.type == 'delete'" @click="handleAction">{{$t('rolemanagement.contDelete')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('rolemanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';

  @Component({

  })
  export default class groupAction extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    valueData = "";
    deleteInfo = ""
    @Prop(Object) dataObj!: any[];
    @Prop({required: true, default: false}) dialogVisible!: boolean;

    mounted(){
      let that = this as any;
      that.deleteInfo = that.$t('rolemanagement.popmsgRoleDelete')
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeRoleAction")
      }
    }

    @Watch('dataObj.type')
    onDialogShowTitleChange(val: any) {
      console.log(val)
    }

    handleAction() {
      let data = this.dataObj as any;
      this.$emit("handleAction", data.type, data.roleObj)
      this.dialogShowVisible = false
    }

  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  ::v-deep .el-dialog__body {
    padding: 0px 0px
  }

  ::v-deep .el-input {
    width: 224px;
    height: 32px;
  }

  ::v-deep .el-dialog__footer {
    text-align: center;
  }

  .content {
    height: 200px;
  }

  .div-class-edit {
    text-align: center;
    padding-top: 100px;
  }

  .div-class-delete {
    text-align: center;
    padding-top: 100px;
    word-break: break-word;
  }

  .div-class-detail {
  }

  .div-class-detail > div {
    padding: 50px 20px 0 200px;
  }

  .div-class-detail > div > span {
    margin-right: 30px;
    width: 56px;
    height: 14px;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: bold;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
  }
</style>
