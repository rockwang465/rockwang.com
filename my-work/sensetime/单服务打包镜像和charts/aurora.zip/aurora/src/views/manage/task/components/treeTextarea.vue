<template>
  <div class="treetextarea-container">
    <el-popover
      ref="treetextarea-popover"
      placement="bottom"
      trigger="click"
      v-model="visible">
        <div slot="reference"  class="treetextarea-selected" >
          <el-input type="text" :placeholder="$t('rule.contPleaseSelect')" readonly  :value="defaultSelected.length>0 ? $t('rule.textboxNumberSelected',{number:defaultSelected.length}):$t('rule.contPleaseSelect')"/>
        </div>
        <div class="treetextarea-content">
          <div>
            <el-tree
              :data="data"
              show-checkbox
              node-key="id"
              ref="tree"
              class="treetextarea-tree"
              default-expand-all
              :render-content="renderContent"
              @node-click="nodeClick"
              @check-change="checkChange"
              >
            </el-tree>
          </div>
          <div style="width:250px;padding-left:10px;">
            <el-input
              type="textarea"
              :placeholder="$t('form.texterrEnterWelcome')"
              v-model="textarea"
              maxlength="24"
              show-word-limit
              :disabled="!currentLibrary"
              @change="inputChange"
              rows="5"
            >
            </el-input>
            <span>{{currentLibrary && currentLibrary.name}}</span>
            <div class="treetextarea-textarea-button">
              <el-button @click="sure" type="primary">{{$t('rule.buttonOK')}}</el-button>
            </div>
          </div>
        </div>
    </el-popover>
  </div>
</template>

<script lang="tsx">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import {cloneDeep} from 'lodash';
@Component({
  components: {

  },
})
export default class TreeTextarea extends Vue {

  /* props */
  @Prop({default: [] }) data!: any[];
  @Prop({default: [] }) defaultSelected!: any[];//默认选中

  /* watch */
  @Watch('visible', { immediate: false, deep: false })
  onVisibleChanged(val: boolean, oldVal: boolean) {
    val && this.initData()
  }
  @Watch('defaultSelected', { immediate: true, deep: false })
  onDefaultDataChanged(val: any, oldVal: any) {
    if(val && val.length>0){
      this.selsectData = cloneDeep(val);
      this.setCheckedKeys(val);
    }
  }
  /* data */
  $refs!: {
    tree: HTMLFormElement
  };
  visible:boolean=false;
  inputText:string="";
  textarea:string='';
  selsectData:any[]=[];
  currentLibrary:any=null;
  defaultCheckedKeys:any[]=[];
  /* methods */
  mounted() {
    
  }
  initData(){
    if(this.defaultSelected.length == 0){
      this.selsectData = [];
      this.$refs.tree.setCheckedKeys([]);
    }
  }
  renderContent(h,{node,data,store}){
    node.isLeaf = data.id > 0;
    return  <span class="treetextarea-node" title={data.name}>{data.name}</span>;
  }
  nodeClick(data,node,h){
    if(data.id>0){
      this.setTextareaValue(data.id)
      this.currentLibrary = data;  
    }else{
      this.currentLibrary = null;  
    }
  }
  setTextareaValue(clickId){
    if(clickId>0){
      let len = this.selsectData.length;
      this.textarea = '';
      if(len>0){
        for(let i=0;i<len;i++){
          let item = this.selsectData[i];
          if(clickId == item.libraryId) {
            this.textarea = item.welcomingRemarks; 
            break;
          };
        }
      }  
    }
    
  }
  checkChange(data,check,childcheck){
    this.$refs.tree.setCurrentKey(data.id)
    //select
    if(check && !this.selsectData.some(item=>item.libraryId == data.id)){
      if(data.id>0){
        this.currentLibrary = data
        this.selsectData.push({
          libraryId:data.id,
          welcomingRemarks:''
        })
      }else{
        this.currentLibrary = null;
      };
    }
    //cancel select
    if(!check && this.selsectData.some(item=>item.libraryId == data.id)){
      this.currentLibrary = null;
      let index = -1;
      this.selsectData.map((s,s_index)=>{
        if(s.libraryId == data.id) index = s_index;
      });
      if(index>=0){
        this.selsectData.splice(index,1)
      }
    }
    if(check && this.selsectData.some(item=>item.libraryId == data.id)){
      this.currentLibrary = data
    }
    this.setTextareaValue(data.id)
  }
  setCheckedKeys(data){
    let keys:any[] = [];
    keys = data.map(item=> item.libraryId);
    setTimeout(()=>{//wait for dom
      this.$refs.tree.setCheckedKeys(keys);
    },100)
  }
  inputChange(v){
    this.selsectData.map(item=>{
      if(item.libraryId == this.currentLibrary.id){
        item.welcomingRemarks = v;
      }
    })
  }
  sure(){
    let data = cloneDeep(this.selsectData);//if not clone it will change data when selsectData change
    this.$emit('selectlib',data)
    this.visible = false;
  }
  changeDefaultChecked(){
    let data = cloneDeep(this.selsectData);//if not clone it will change data when selsectData change
    this.$emit('selectlib',data)
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .treetextarea-container{
    display: inline-block;
    position: relative;
    background-color: #fff;
    width: 100%;
  }
  .treetextarea-selected{
    position: relative;
  }
  .treetextarea-content{
    display:flex;
    flex-wrap:nowrap;
    .treetextarea-tree{
      height: 175px;
      overflow: auto;
      max-width:200px;
    }
    .treetextarea-textarea-button{
      width:100%;
      text-align:right;
      padding-top:24px;
    }
  }
  ::v-deep .el-tree-node__content .treetextarea-node{
    display:inline-block;
    max-width:80px;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  ::v-deep .el-textarea .el-input__count{
    color: #909399;
  }
  ::v-deep .treetextarea-tree .el-tree-node .el-tree-node__children .el-tree-node.is-current{
    background-color: #E8EBF5;
    position: relative;
    padding-right: 10px;
    &::after{
      position: absolute;
      right:1px;
      top: 9px;
      content:'';
      display: block;
      width:0;
      height:0;
      border-top:5px solid transparent;
      border-bottom:5px solid transparent;
      border-left:6px solid black;
    }
  }
  ::v-deep .el-tree-node:focus > .el-tree-node__content {
    background-color: #E8EBF5;
  }
  ::v-deep .treetextarea-tree .el-tree-node .el-tree-node__children .el-tree-node:hover > .el-tree-node__content {
    background-color: #E8EBF5;
  }
</style>
