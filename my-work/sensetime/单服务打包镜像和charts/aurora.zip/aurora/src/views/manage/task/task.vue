<template>
  <div class="task-container">
    <TaskMenu @taskModelChange="handleTaskModelChange" :currentModel="taskModel" />
    <TaskTable :currentModel="taskModel"  />
  </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import TaskMenu from "./task-menu.vue";
import TaskTable from "./task-table.vue";
import {taskType} from '@/utils/constants.ts';

@Component({
  components: {
    TaskMenu,
    TaskTable
  },
})
export default class Task extends Vue {


    /* props */

    /* watch */

    /* data */
    taskModel:string=taskType[0].name;

    /* methods */
    handleTaskModelChange(model){
      this.taskModel = model;
    }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.task-container{
  display: flex;
  height: 100%;
}
::v-deep .right-tips{
  position: absolute;
  right: -20px;
  top: 1px;
}
</style>
