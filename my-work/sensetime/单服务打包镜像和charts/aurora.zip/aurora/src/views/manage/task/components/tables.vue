<template>
    <div class="tables-container">
        <el-table
        v-if="showTable"
        ref="tb"
        :stripe="true"
        @selection-change="selectionChange"
        v-loading="loading"
        :data="tableData"
        @filter-change="tableFilterChange"
        @header-click="headerClick"
        :height="tableHeight"
        style="width: 100%;">

            <el-table-column
            v-if="showSelection"
            type="selection"
            width="55">
            </el-table-column>
            <el-table-column
            width="30">
            </el-table-column>
            <el-table-column
                prop="taskName"
                :label="$tc('task.contTaskName')">
            </el-table-column>
            <el-table-column
                prop="device"
                :label="$t('rule.labelDevice')">
            </el-table-column>
            <el-table-column
                prop="deviceGroup"
                :label="$t('rule.labelDeviceGroup')" >
                <template slot="header" slot-scope="scope">
                    <el-popover
                    placement="bottom"
                    width="160"
                    popper-class="th-drop"
                    v-model="deviceGroupFilterVisible">
                    <div class="rule-list-td-popover" >
                        <div class="rule-list-td-popover-treebox" >
                        <el-tree
                            ref="deviceGroupTree"
                            node-key="id"
                            @check="handleDeviceGroupTreeCheck"
                            :props="{label:'name'}"
                            :indent="0"
                            :show-checkbox="true"
                            :render-content="renderDeviceGroupContent"
                            :data="deviceGroupTreeData"></el-tree>
                        </div>

                        <div class="rule-list-td-popover-footer" >
                        <el-button size="mini" type="text" :disabled="deviceGroupTreeCheckedKeys.length == 0" @click="handleFilterDeviceGroup(scope)">{{$t('rule.contSearch')}}</el-button>
                        <el-button type="text" style="font-size:12px"  @click="handleClearFilterDeviceGroup(scope)">{{$t('rule.contReset')}}</el-button>
                        </div>
                    </div>
                    <span slot="reference" :class="deviceGroupTreeCheckedKeys.length>0?'rule-list-td-popover-content':''" >
                        <span>{{$t('rule.labelDeviceGroup')}}</span>
                        <i v-show="!deviceGroupFilterVisible" class="el-icon-arrow-down rule-list-td-popover-icon" ></i>
                        <i v-show="deviceGroupFilterVisible" class="el-icon-arrow-up rule-list-td-popover-icon" ></i>
                    </span>
                    </el-popover>
                </template>
                <template slot-scope="scope">
                    <el-tooltip popper-class="th-drop" effect="dark" :content="scope.row.deviceGroup.groupNames" placement="bottom">
                    <span>
                        {{scope.row.deviceGroup.groupName}}
                    </span>
                    </el-tooltip>
                </template>
            </el-table-column>
            <el-table-column v-if="currentModel === 'vpi'"
                prop="timeLimit"
                :label="$tc('task.contStopCarTimeline')">
            </el-table-column>
            <el-table-column v-if="currentModel !== 'cs'"
                prop="specialAttribute"
                :filter-multiple="true"
                :label="$t('rule.labelAttribute')"
                :filters="specialAttributeOptions"
                column-key="taskAttributeIds">
            </el-table-column>
            <el-table-column v-if="(currentModel === 'ac')"
                prop="timezoneNumber"
                :label="$tc('rule.labelTimezone')">
            </el-table-column>
            <el-table-column v-if="(currentModel === 'ac' || currentModel === 'td' || currentModel === 'cs')"
                prop="threshold"
                :label="currentModel === 'cs' ? $t('task.crowdThreshold') :$tc('rule.contThreshold')">
                <template slot-scope="scope">
                    <span v-if="currentModel !== 'cs'" v-show="scope.row.threshold">{{ parseInt(scope.row.threshold * 100) +'%'}}</span>
                    <span v-else v-show="scope.row.threshold">{{ scope.row.threshold}}{{scope.row.thresholdUnit == 2? $t('pedestrian.crowdUnit2') : $t('pedestrian.crowdUnit1') }}</span>
                </template>
            </el-table-column>
            <!-- <el-table-column v-if="currentModel === 'cs'"
                             prop="duration"
                             label="时间阈值">
              <template slot-scope="scope">
                <span>{{ scope.row.duration}}{{ scope.row.durationUnit == 1?"s": scope.row.durationUnit == 2?"min":'hour'}}</span>
              </template>
            </el-table-column> -->
            <!-- status -->
            <el-table-column
                :filter-multiple="false"
                :filters="[{text: $t('rule.buttonRuleStausEnabled'), value: 1}, {text: $t('rule.buttonRuleStausDisabled'), value: 0}]"
                column-key="runStatus"
                prop="enableStatus"
                :label="$tc('welcome.tableTaskStatus')">
                <template slot-scope="scope">
                    <el-switch
                    :disabled="getStatusPermission()"
                    @change="(v)=>changeTaskStatus(v,scope.row)"
                    v-model="scope.row.enableStatus"
                    :active-value="1"
                    :inactive-value="0"
                    active-color="#13ce66"
                    inactive-color="#ff4949">
                    </el-switch>
                </template>
            </el-table-column>
            <!-- operate -->
            <el-table-column class-name="tables-operate" :label="$tc('welcome.tableOperation')">
                <template slot-scope="scope">
                    <span class="task-list-operation-item" @click="handleView(scope.$index, scope.row)">
                    <i class="iconfont icon-view"  ></i>
                    </span>
                    <span class="task-list-operation-item" @click="handleEdit(scope.$index, scope.row)" v-if="getEditPermission()">
                    <i class="iconfont icon-edit" ></i>
                    </span>
                    <span class="task-list-operation-item" @click="handleDelete(scope.$index, scope.row)" v-if="getDeletePermission()" >
                    <i class="iconfont icon-delete" ></i>
                    </span>
                </template>
            </el-table-column>
            <div slot="empty" style="width:100%" >
                <img src="/images/task-nodata.png" alt="" srcset="">
                <p>{{$tc('task.contTaskEmpty')}}</p>
            </div>
        </el-table>
        <!-- messageBox delete -->
        <el-dialog
        :append-to-body="true"
        :visible="showDeleteDialog"
        :before-close="()=>this.showDeleteDialog = false"
        width="400px">
        <p style="max-width:350px;text-align:center;line-height:20px;word-break: break-word;">{{$t('rule.popmsgRulesetDelete')}}</p>
        <div slot="title" >
            <span>{{$t('rule.listDelete')}}</span>
        </div>
        <span slot="footer">
            <el-button type="danger" @click="ensureDelete" :loading="deleteLoading">{{$t('rule.buttonOperationDelete')}}</el-button>
            <el-button @click="showDeleteDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
        </span>
        </el-dialog>
        <!-- messageBox change status -->
        <el-dialog
        :append-to-body="true"
        :visible="showStatusDialog"
        :before-close="()=>this.showStatusDialog = false"
        width="400px">
        <p style="max-width:350px;text-align:center;line-height:20px;word-break: break-word;">{{statusText}}</p>
        <div slot="title" >
            <span>{{$t('rule.titleReminder')}}</span>
        </div>
        <span slot="footer">
            <el-button type="primary" @click="ensureChangeStatus" :loading="statusLoading">{{$t('rule.buttonOK')}}</el-button>
            <el-button @click="showStatusDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
        </span>
        </el-dialog>
        <!-- view td -->
        <ViewTaskTD
            :visible="showViewTaskTDDialog"
            :ruleId="currentTaskId"
            :backgroundImage="welcomebg" @hide="(isEdit)=>{showViewTaskTDDialog=false;showEditTaskTDDialog = isEdit}"/>
        <!-- view ac -->
        <ViewTaskAC :visible="showViewTaskACDialog" :ruleId="currentTaskId" @hide="(isEdit)=>{showViewTaskACDialog=false;showEditTaskACDialog = isEdit}"/>
        <!-- view pc -->
        <ViewTaskPC :visible="showViewTaskPCDialog" :taskId="currentTaskId" @hide="(isEdit)=>{showViewTaskPCDialog=false;showEditTaskPCDialog = isEdit}" />
        <!-- view pai -->
        <ViewTaskPAI :visible="showViewTaskPAIDialog" :taskId="currentTaskId" @hide="(isEdit)=>{showViewTaskPAIDialog=false;showEditTaskPAIDialog = isEdit}" />
        <!-- view vpi -->
        <ViewTaskVPI :visible="showViewTaskVPIDialog" :taskId="currentTaskId" @hide="(isEdit)=>{showViewTaskVPIDialog=false;showEditTaskVPIDialog = isEdit}" />
      <!-- view cs -->
        <ViewTaskCS :visible="showViewTaskCSDialog" :taskId="currentTaskId" @hide="(isEdit)=>{showViewTaskCSDialog=false;showEditTaskCSDialog = isEdit}" />
        <!-- edit td -->
        <EditTaskTD :visible="showEditTaskTDDialog"
            :ruleId="currentTaskId"
            @successcal="editsuccesscal"
            :backgroundImage="welcomebg"
            :taskId="currentTaskId"
            @hide="showEditTaskTDDialog=false"/>
        <!-- edit ac -->
        <EditTaskAC :visible="showEditTaskACDialog" :ruleId="currentTaskId" :backgroundImage="''"
            :taskId="currentTaskId"
            @successcal="editsuccesscal"
            @hide="showEditTaskACDialog=false"/>
        <!-- edit pc -->
        <EditTaskPC :visible="showEditTaskPCDialog" :ruleId="currentTaskId" :backgroundImage="''"
            :taskId="currentTaskId"
            @successcal="editsuccesscal"
            @errorcal="editerrorcal"
            @hide="showEditTaskPCDialog=false"/>
        <!-- edit pai -->
        <EditTaskPAI :visible="showEditTaskPAIDialog" :ruleId="currentTaskId" :backgroundImage="''"
            :taskId="currentTaskId"
            @successcal="editsuccesscal"
            @errorcal="editerrorcal"
            @hide="showEditTaskPAIDialog=false"/>
        <!-- edit pai -->
        <EditTaskVPI :visible="showEditTaskVPIDialog" :ruleId="currentTaskId" :backgroundImage="''"
            :taskId="currentTaskId"
            @successcal="editsuccesscal"
            @errorcal="editerrorcal"
            @hide="showEditTaskVPIDialog=false"/>
      <!-- edit cs -->
        <EditTaskCS :visible="showEditTaskCSDialog" :ruleId="currentTaskId" :backgroundImage="''"
            :taskId="currentTaskId"
            @successcal="editsuccesscal"
            @errorcal="editerrorcal"
            @hide="showEditTaskCSDialog=false"/>
    </div>
</template>

<script lang="tsx">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {getDevicesGroupTreeData,getSpecialAttrs} from '@/api/rule';
import {startTDTask,stopTDTask,startACTask,stopACTask,startPCTask,stopPCTask,startPAITask,stopPAITask,
        deleteTDTask,deleteACTask,deletePCTask,deletePAITask,
        startTDTasksBatch,stopTDTasksBatch,deleteTDTasksBatch,
        startPCTasksBatch,startPAITasksBatch,stopPCTasksBatch,
        stopPAITasksBatch,deletePCTasksBatch,deletePAITasksBatch,
        startACTasksBatch,stopACTasksBatch,deleteACTasksBatch,
        startVPITask,stopVPITask,startCSTask,stopCSTask,startVPITasksBatch,stopVPITasksBatch,deleteVPITask,
        startCSTasksBatch,stopCSTasksBatch,deleteCSTasksBatch, deleteCSTask,deleteVPITasksBatch
        } from '@/api/task';
import ViewTaskTD from '../dialog/viewTask/viewTask-td.vue';
import ViewTaskAC from '../dialog/viewTask/viewTask-ac.vue';
import ViewTaskPC from '../dialog/viewTask/viewTask-pc.vue';
import ViewTaskPAI from '../dialog/viewTask/viewTask-pai.vue';
import ViewTaskVPI from '../dialog/viewTask/viewTask-vpi.vue';
import ViewTaskCS from '../dialog/viewTask/viewTask-cs.vue';
import EditTaskTD from '../dialog/editTask/editTask-td.vue';
import EditTaskAC from '../dialog/editTask/editTask-ac.vue';
import EditTaskPC from '../dialog/editTask/editTask-pc.vue';
import EditTaskPAI from '../dialog/editTask/editTask-pai.vue';
import EditTaskVPI from '../dialog/editTask/editTask-vpi.vue';
import EditTaskCS from '../dialog/editTask/editTask-cs.vue';
import i18n from '@/lang/index';

@Component({
    components: {
        ViewTaskTD,
        ViewTaskAC,
        ViewTaskPC,
        ViewTaskPAI,
        ViewTaskVPI,
        ViewTaskCS,
        EditTaskTD,
        EditTaskAC,
        EditTaskPC,
        EditTaskPAI,
        EditTaskVPI,
        EditTaskCS,
    },
})
export default class Tables extends Vue {
    /* props */
    @Prop({default: false,required:false }) showSelection!: boolean;//默认选中
    @Prop({required:true }) tableData!: any[];
    @Prop({required:true }) currentModel!: string;
    @Prop({required:true }) loading!: boolean;
    @Prop({required:true }) tableHeight!: any;
    /* watch */
    @Watch('currentModel',{ immediate: true})
    onVisibleChange(n,o){
        this.initData();
    }
    /* data */
    $refs !:{
        deviceGroupTree:HTMLFormElement,
        tb:HTMLFormElement
    };
    showTable:boolean=true;
    timer:any=null;
    filterCondition:any={};
    deviceGroupFilterVisible:boolean=false;
    deviceGroupTreeCheckedKeys:any[]=[];
    deviceGroupTreeData:any[]=[];
    specialAttributeOptions:any[]=[];
    showDeleteDialog:boolean=false;
    listCurrentTaskId:any=null;
    deleteLoading:boolean=false;
    showStatusDialog:boolean=false;
    statusLoading:boolean=false;
    selectedTasks:any[]=[];
    statusText:string=i18n.tc('task.propChangeStatus');
    currentTaskStatusValue:any={};

    showViewTaskTDDialog:boolean=false;
    currentTaskId:any='';
    welcomebg:string='';
    showViewTaskACDialog:boolean=false;
    showViewTaskPCDialog:boolean=false;
    showViewTaskPAIDialog:boolean=false;
    showViewTaskVPIDialog:boolean=false;
    showViewTaskCSDialog:boolean=false;
    showEditTaskTDDialog:boolean=false;
    showEditTaskACDialog:boolean=false;
    showEditTaskPCDialog:boolean=false;
    showEditTaskPAIDialog:boolean=false;
    showEditTaskVPIDialog:boolean=false;
    showEditTaskCSDialog:boolean=false;
    /* methods */
    mounted(){

    }
    initData(){
        this.filterCondition={};
        this.deviceGroupFilterVisible=false;
        this.deviceGroupTreeCheckedKeys=[];
        this.deviceGroupTreeData=[];
        this.specialAttributeOptions = [];
        this.showDeleteDialog=false;
        this.deleteLoading=false;
        this.showStatusDialog = false;
        this.statusLoading=false;
        this.selectedTasks=[];
        this.currentTaskStatusValue={};
        this.showViewTaskTDDialog = false;
        this.currentTaskId='';
        this.welcomebg='';
        this.showViewTaskACDialog = false;
        this.showViewTaskPCDialog=false;
        this.showViewTaskPAIDialog = false;
        this.showViewTaskVPIDialog = false;
        this.showViewTaskCSDialog = false;
        this.showEditTaskTDDialog=false;
        this.showEditTaskPCDialog=false;
        this.showEditTaskPAIDialog=false;
        this.showEditTaskVPIDialog = false;
        this.showEditTaskCSDialog = false;
        this.$refs.tb && this.$refs.tb.clearFilter();

        this.getDeviceGroupsList();
        this.getSpecialAttributes();

        //reload table to fix column order confusion ↓
        if(this.timer) window.clearTimeout(this.timer);
        this.showTable=false;
        this.timer=setTimeout(()=>{
            this.showTable=true;
        },10)
        //reload table to fix column order confusion ↑
    }
    handleView(i,r){
        this.currentTaskId = r.taskId;
        switch (this.currentModel) {
            case 'td':
                this.welcomebg = r.backgroundImage;
                this.showViewTaskTDDialog = true;
                break;
            case 'ac':
                this.showViewTaskACDialog = true;
                break;
            case 'pc':
                this.showViewTaskPCDialog = true;
                break;
            case 'pai':
                this.showViewTaskPAIDialog = true;
                break;
            case 'vpi':
                this.showViewTaskVPIDialog = true;
                break;
            case 'cs':
                this.showViewTaskCSDialog = true;
                break;

            default:
                break;
        }

    }
    handleEdit(i,r){
        this.currentTaskId = r.taskId;
        switch (this.currentModel) {
            case 'td':
                this.welcomebg = r.backgroundImage;
                this.showEditTaskTDDialog = true;
                break;
            case 'ac':
                this.showEditTaskACDialog = true;
                break;
            case 'pc':
                this.showEditTaskPCDialog = true;
                break;
            case 'pai':
                this.showEditTaskPAIDialog = true;
                break;
            case 'vpi':
                this.showEditTaskVPIDialog = true;
                break;
            case 'cs':
                this.showEditTaskCSDialog = true;
                break;

            default:
                break;
        }
    }
    getEditPermission(){
        let isShow = false;
        switch (this.currentModel) {
            case 'td':
                this.$permission('006215') && (isShow = true);
                break;
            case 'ac':
                this.$permission('006203') && (isShow = true);
                break;
            case 'pc':
                this.$permission('006217') && (isShow = true);
                break;
            case 'pai':
                this.$permission('006218') && (isShow = true);
                break;
            case 'vpi':
                this.$permission('006216') && (isShow = true);
                break;
            case 'cs':
                this.$permission('006217') && (isShow = true);
                break;

            default:
                break;
        }
        return isShow;
    }
    getDeletePermission(){
        let isShow = false;
        switch (this.currentModel) {
            case 'td':
                this.$permission('006417') && (isShow = true);
                break;
            case 'ac':
                this.$permission('006404') && (isShow = true);
                break;
            case 'pc':
                this.$permission('006427') && (isShow = true);
                break;
            case 'pai':
                this.$permission('006429') && (isShow = true);
                break;
            case 'vpi':
                this.$permission('006425') && (isShow = true);
                break;
            case 'cs':
                this.$permission('006427') && (isShow = true);
                break;

            default:
                break;
        }
        return isShow;
    }
    getStatusPermission(){
        let isDisabled = true;
        switch (this.currentModel) {
            case 'td':
                this.$permission('006324') && this.$permission('006325') && (isDisabled = false);
                break;
            case 'ac':
                this.$permission('006308') && this.$permission('006309') && (isDisabled = false);
                break;
            case 'pc':
                this.$permission('006336') && this.$permission('006337') && (isDisabled = false);
                break;
            case 'pai':
                this.$permission('006340') && this.$permission('006341') && (isDisabled = false);
                break;
            case 'vpi':
                this.$permission('006332') && this.$permission('006333') && (isDisabled = false);
                break;
            case 'cs':
                this.$permission('006336') && this.$permission('006337') && (isDisabled = false);
                break;

            default:
                break;
        }
        return isDisabled;
    }
    handleDelete(i,r){
        this.listCurrentTaskId = r.taskId;
        this.showDeleteDialog = true;
    }
    ensureDelete(){
        this.deleteLoading = true;
        this.listCurrentTaskId && this.deleteTask(this.listCurrentTaskId,this.currentModel).finally(()=>{
            this.showDeleteDialog = false;
            this.deleteLoading=false;
            this.$emit('refreshTableData');
        })
    }
    changeTaskStatus(v,row){
        row.enableStatus = v==0?1:0;
        this.showStatusDialog = true;
        this.currentTaskStatusValue['row'] = row;
        this.currentTaskStatusValue['v'] = v;
    }
    ensureChangeStatus(){
        this.statusLoading=true;
        let row = this.currentTaskStatusValue['row'],v=this.currentTaskStatusValue['v'];
        v == 1 && this.startTask(row.taskId,this.currentModel).then(res=>{
            this.showStatusDialog = false;
        }).catch(err=>{
            this.showStatusDialog = false;
        }).finally(()=>{this.$emit('refreshTableData');this.statusLoading=false;});
        v == 0 && this.stopTask(row.taskId,this.currentModel).then(res=>{
            this.showStatusDialog = false;
        }).catch(err=>{
            this.showStatusDialog = false;
        }).finally(()=>{this.$emit('refreshTableData');this.statusLoading=false;});
    }
    tableFilterChange(filter){
        this.deviceGroupFilterVisible=false;
        let condition = Object.keys(filter)[0];
        if(condition == 'runStatus'){
            filter['runStatus'] = filter['runStatus'][0];
        }
        this.filterCondition[condition] = filter[condition];
        this.$emit('refreshTableData',true);
    }
    headerClick(column, event){ //hide devicegroup filter popver
        this.deviceGroupFilterVisible = column.property == "deviceGroup"?true:false;
    }
    handleFilterDeviceGroup(row){
        let filter = {deviceGroupIds:this.$refs.deviceGroupTree.getCheckedKeys()};
        this.deviceGroupTreeCheckedKeys = filter.deviceGroupIds;
        this.tableFilterChange(filter);
        this.deviceGroupFilterVisible = false;
    }
    handleDeviceGroupTreeCheck(){
        this.deviceGroupTreeCheckedKeys = this.$refs.deviceGroupTree.getCheckedKeys();
    }
    getDeviceGroupsList(){
        getDevicesGroupTreeData().then(res=>{
            res && res.data && (this.deviceGroupTreeData = res.data);
        })
    }
    getSpecialAttributes(){
        let arr :any[] = [];
        let type_ = this.currentModel == 'ac'?0:(this.currentModel == 'td'?1:3);
        getSpecialAttrs(type_).then((res:any)=>{
            res && res.list.map(item=>{
                arr.push({
                    value:item.taskAttributeId,
                    text:this.$tc(`rule.${item.taskAttributeName}`)
                })
            });
            this.specialAttributeOptions = arr;
        })
    }
    formatDeviceSpecialAttribute(deviceSpecialAttribute){
        let str = '';
        deviceSpecialAttribute && deviceSpecialAttribute.map(item=>{
        str= str+' '+this.$tc(`rule.${item.taskAttributeName}`);
        });
        return str;
    }
    selectionChange(selection){
        this.selectedTasks = selection;
    }
    ensureBatchChangeStatus(status,startcal,successcal,errorcal){
        if(this.selectedTasks.length == 0) return ;
        let taskIds = this.selectedTasks.map(item=>{return item.taskId});
        startcal && startcal();
        status === 'start' && this.startTasksBatch(taskIds,this.currentModel).then(res=>{
            successcal && successcal(res);
        }).catch((err)=>{
            errorcal && errorcal();
        });
        status === 'stop' && this.stopTasksBatch(taskIds,this.currentModel).then(res=>{
            successcal && successcal(res);
        }).catch((err)=>{
            errorcal && errorcal();
        });
    }
    ensureBatchDeleteTasks(startcal,successcal,errorcal){
        if(this.selectedTasks.length == 0) return ;
        let taskIds = this.selectedTasks.map(item=>{return item.taskId});
        startcal && startcal();
        this.deleteTasksBatch(taskIds,this.currentModel).then(res=>{
            successcal && successcal();
        }).catch((err)=>{
            errorcal && errorcal();
        });
    }
    editsuccesscal(type){
        this.$emit('refreshTableData');
    }
    editerrorcal(type){

    }
    handleClearFilterDeviceGroup(){
        let filter = {deviceGroupIds:[]};
        this.tableFilterChange(filter);
        this.$refs.deviceGroupTree.setCheckedKeys([]);
        this.deviceGroupTreeCheckedKeys = [];
        this.deviceGroupFilterVisible = false;
    }
    renderDeviceGroupContent(h, { node, data, store }){
        return <span title={data.name} style="white-space: nowrap;text-overflow: ellipsis;overflow: hidden;" >{data.name}</span>;
    }
    async startTask(taskId,currentModel){
        switch (currentModel) {
            case 'td': return await  startTDTask(taskId);
            case 'ac': return await startACTask(taskId);
            case 'pc': return await startPCTask(taskId);
            case 'pai': return await startPAITask(taskId);
            case 'vpi': return await startVPITask(taskId);
            case 'cs': return await startCSTask(taskId);
            default: return false;
        }
    }
    async stopTask(taskId,currentModel){
        switch (currentModel) {
            case 'td': return await stopTDTask(taskId);
            case 'ac': return await stopACTask(taskId);
            case 'pc': return await stopPCTask(taskId);
            case 'pai': return await stopPAITask(taskId);
            case 'vpi': return await stopVPITask(taskId);
            case 'cs': return await stopCSTask(taskId);
            default: return false;
        }
    }
    async deleteTask(taskId,currentModel){
        switch (currentModel) {
            case 'td': return await deleteTDTask(taskId);
            case 'ac': return await deleteACTask(taskId);
            case 'pc': return await deletePCTask(taskId);
            case 'pai': return await deletePAITask(taskId);
            case 'vpi': return await deleteVPITask(taskId);
            case 'cs': return await deleteCSTask(taskId);
            default: return false;
        }
    }
    async startTasksBatch(taskIds,currentModel){
        switch (currentModel) {
            case 'td': return await  startTDTasksBatch(taskIds);
            case 'ac': return await startACTasksBatch(taskIds);
            case 'pc': return await startPCTasksBatch(taskIds);
            case 'pai': return await startPAITasksBatch(taskIds);
            case 'vpi': return await startVPITasksBatch(taskIds);
            case 'cs': return await startCSTasksBatch(taskIds);
            default: return false;
        }
    }
    async stopTasksBatch(taskIds,currentModel){
        switch (currentModel) {
            case 'td': return await  stopTDTasksBatch(taskIds);
            case 'ac': return await stopACTasksBatch(taskIds);
            case 'pc': return await stopPCTasksBatch(taskIds);
            case 'pai': return await stopPAITasksBatch(taskIds);
            case 'vpi': return await stopVPITasksBatch(taskIds);
            case 'cs': return await stopCSTasksBatch(taskIds);
            default: return false;
        }
    }
    async deleteTasksBatch(taskIds,currentModel){
        switch (currentModel) {
            case 'td': return await  deleteTDTasksBatch(taskIds);
            case 'ac': return await deleteACTasksBatch(taskIds);
            case 'pc': return await deletePCTasksBatch(taskIds);
            case 'pai': return await deletePAITasksBatch(taskIds);
            case 'vpi': return await deleteVPITasksBatch(taskIds);
            case 'cs': return await deleteCSTasksBatch(taskIds);
            default: return false;
        }
    }

    clearSelection(){
        this.$refs.tb && this.$refs.tb.clearSelection();
    }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.tables-container{
    .task-list-operation-item{
        cursor: pointer;
        margin-right: 8px;
        i.iconfont{
            font-size:19px;
        }
    }
}
::v-deep .el-table__column-filter-trigger{
    &>i{
        color: #28354D;
    }
}
.rule-list-td-popover-icon{
    transform: scale(.65);
    color: #28354D;
}
.rule-list-td-popover{
    .rule-list-td-popover-treebox{
        max-height: 200px;
        overflow: auto;
    }
    .rule-list-td-popover-footer{
        border-top: 1px solid #ccc;
        button.el-button {
        color:#28354d;
        &:hover{
            color:#2a5af5;
        }
        }
        button.el-button.is-disabled {
        color:#c0c4cc;
        }
    }
}
::v-deep .el-table__empty-block{
    background-color: white;
    padding-top: 160px;
}

</style>
