<template>
  <div>
    <!--删除弹框-->
    <!--删除-->
    <el-dialog
      :title="$t('imagemanagement.listDelete')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <!--分组删除后，将不能恢复！-->
      <div v-if="true" class="content">
        {{$t('imagemanagement.popmsgGroupDelete')}}
      </div>
      <div v-else class="content">
        <!--分组正在使用，不能删除！-->
        {{$t('imagemanagement.popmsgGroupOccupied')}}
      </div>
      <span slot="footer" class="dialog-footer">
        <!--删 除-->
        <el-button v-if="true" type="danger" @click="handleGroupAction">{{$t('imagemanagement.buttonDelete')}}</el-button>
        <el-button v-else type="primary" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button type="info" class="cancel" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--删除弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';

  @Component({

  })
  export default class groupDelete extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    @Prop(Object) dataObj!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    handleGroupAction() {
      this.$emit("handleGroupAction", this.dataObj)
      this.dialogShowVisible = false;
    }
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeDelete")
      }
    }


  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .content{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  .content .left span{
    padding-left: 70%;
    font-weight: 600;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
</style>
