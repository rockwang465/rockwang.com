<template>
  <el-dialog
  :title="$t('rolemanagement.titleReminder')"
  :visible.sync="visible"
  width="30%"
  :center="true"
  :before-close="handleClose">
  <!-- title -->
  <p slot="title" style="text-align:left" >{{$t('rule.titleAcRulesetEdit')}}</p>
  <!-- content -->
    <el-form ref="form" :model="form" :rules="rules" label-position="left" :label-width="language == 'en'?'125px':'115px'">
      <br />
      <el-form-item prop="ruleGroupName"  :label="$t('rule.contRulesetName')">
        <span>{{form.ruleGroupName}}</span>
      </el-form-item>
      <el-form-item prop="ruleName"  :label="$t('rule.labelRuleName')">
        <el-input type="text" v-model="form.ruleName" ></el-input>
      </el-form-item>
      <el-form-item prop="defaultKeeperName"  :label="$t('rule.contDevice')">
        <!-- <el-input type="text" v-model="form.defaultKeeperName" readonly ></el-input> -->
        <span>{{form.defaultKeeperName}}</span>
      </el-form-item>
      <!-- <el-form-item prop="defaultChechedKeys" :label="$t('rule.contDevice')">
        <TreeSelectRadio
          :data="treeData"
          @check="deviceSlected"
          :defaultChechedKeys="form.defaultChechedKeys"
          />
      </el-form-item> -->
      <el-form-item prop="specialAttribute" :label="$t('rule.contAttribute')">
        <el-select
          v-model="form.specialAttribute"
          default-first-option
          multiple
          collapse-tags
          :placeholder="$t('rule.listAttributeNone')">
          <el-option
            v-for="(item,itemIndex) in specialAttributeOptions"
            :key="itemIndex"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="threshold" :label="$t('rule.contThreshold')">
        <el-select
          class="edit-rule-ac-threshold"
          v-model="form.threshold"
          filterable
          allow-create
          default-first-option
          :placeholder="$t('rule.contThreshold')">
          <el-option
            v-for="(item,itemIndex) in thresholdOptions"
            :key="itemIndex"
            :label="Number(item*100).toFixed(1)"
            :value="item">
          </el-option>
        </el-select> %
      </el-form-item>
    </el-form>
    <div class="sapce-border" ></div>
    <div class="edit-rule-ac-timeAndLibs" style="width:100%;">
      <div v-if="currentDeviceType != 6">
        <header class="edit-rule-ac-libsheader-time">{{$t('rule.labelTimezoneList')}}</header>
        <div class="edit-rule-ac-timeAndLibs-scrollbox edit-rule-ac-timeAndLibs-scrollbox-times" >
          <el-tree
            :data="timezoneList"
            ref="timezoneList"
            node-key="id"
            show-checkbox
            :default-checked-keys="timezoneListDefaultChecked"
            @check-change="handleTimezoneListCheckChange"
            @node-click="timezoneListNodeClick" ></el-tree>
        </div>
      </div>
      <div>
        <header class="edit-rule-ac-libsheader">{{$t('rule.labelImageLibraryList')}}</header>
        <div  class="edit-rule-ac-timeAndLibs-scrollbox edit-rule-ac-timeAndLibs-scrollbox-libs">
          <el-tree :data="libsList" ref="libsList" node-key="id" show-checkbox default-expand-all @check-change="handleLibsListCheckChange" ></el-tree>
        </div>

      </div>
    </div>

    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="submitData" :loading="loading">{{$t('rule.buttonOK')}}</el-button>
      <el-button @click="hide" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>
</template>

<script lang="ts">
import { Component, Vue , Watch, Prop} from 'vue-property-decorator';
import TreeSelect from '@/components/tree-select/index.vue';
import {getTimezone,getTimezoneWithIntervals,editRuleAC,getSpecialAttrs,getDevices,getRuleDetail,getDevicesTreeData,getLibsList} from '@/api/rule';
const defaultAcThreshold = window.globalConfig.acThreshold;
import {ruleThresholdOptions} from '@/utils/constants';
import {trim} from 'lodash';
import { setTimeout } from 'timers';
import i18n from '@/lang/index';
import { AppModule } from '@/store/modules/app';
// import TreeSelectRadio from "../../components/treeSelectRadio.vue";

@Component({
  components: {
    TreeSelect,
    // TreeSelectRadio
  },
})
export default class EditRuleAC extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:''}) ruleId!: string;
  @Prop({default:'',required:false}) groupId!: string;
  /* watch */
  @Watch('visible', { immediate: true, deep: true })
  onVisibleChange(n,o){
    n && this.initRuleData();
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  $refs!:{
    timezoneList:HTMLFormElement,
    libsList:HTMLFormElement,
    form:HTMLFormElement
  }
  labelWidth:string='115px';
  selectedKeeperId:any;
  form:{
    ruleGroupName:string;
    ruleName:string;
    defaultKeeperName:string;
    // defaultChechedKeys:any[];
    specialAttribute:any[];
    threshold:any;
  }={
    ruleGroupName:'',
    ruleName:'',
    defaultKeeperName:'',
    // defaultChechedKeys:[],
    specialAttribute:[],
    threshold:0
  };
  loading:boolean=false;
  validateGroupName=(rule, value, callback) => {
    let str = value;
    if (str === '') {
      callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
    } else {
      //去除两头空格:
      let regx = /^\s+|\s+$/g;
      while (regx.test(str)) {
        str   =  trim(str);
      };
      str   =  trim(str);
      if(str){
        callback();
      }else{
        callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
      }
    }
  };
  rules={
    ruleName:[
      { required: true, validator: this.validateGroupName, trigger: 'blur' },
      // { min: 1, max: 40, message: '长度在 1 到 40 个字符', trigger: 'blur' }
    ],
    specialAttribute:[
      { required: false },
    ],
    // defaultChechedKeys:[
    //   { required: true, message: i18n.t('form.texterrSelectDevice')+""},
    // ],
    threshold:[
      { required: true, message: i18n.t('form.texterrEnterThreshold')+"", trigger: 'change' },
    ],
  };
  timezoneLibraryRelation:any[]=[];
  timeCheckListModel:any[]=[];
  timezoneListDefaultChecked:any[]=[];
  libsCheckListModel:any[]=[];
  timezoneList:any[]=[];
  currentTimezoneIndex:number=0;
  treeData:any[] = [];
  libsList:any[]=[{id:0,label:'',children:[]}];
  props:any=this.$props;
  thresholdOptions = ruleThresholdOptions;
  specialAttributeOptions:any[]=[];
  currentDeviceType:any='';

  /* methods */
  initRuleData(){
    this.$refs.form && this.$refs.form.clearValidate();
    //初始化数据
    this.form.ruleGroupName = '';
    this.form.ruleName = '';
    // this.form.defaultChechedKeys = [];
    this.form.defaultKeeperName = "";
    this.form.specialAttribute = [];
    this.form.threshold = defaultAcThreshold;

    this.libsList=[{id:0,label:this.$tc('rule.contWhitelist'),children:[]}];
    this.timezoneListDefaultChecked=[];

    //请求
    Promise.all([getSpecialAttrs(0),getTimezoneWithIntervals(),getDevicesTreeData({deviceType:20,filter:0}) ]).then(res=>{
      this.setDataForSpecialAttrs(res[0]);
      this.setDataForTimezone(res[1]);
      this.setDataForDevices(res[2]);
      // this.setDataForLibs(res[3]);
      this.getRuleDetail();
    });

  }
  getRuleDetail(){
    getRuleDetail(this.ruleId).then((res:any)=>{
      let deviceType:any=null;
      this.setDataForRuleDetail(res);
      deviceType = res.deviceVo.deviceType;
      getLibsList().then(libsList=>{
        this.setDataForLibs(libsList,deviceType);
      })
    })
  }
  setDataForRuleDetail(res){
    this.form.ruleGroupName=res.taskGroupVo.taskGroupName;
    this.form.ruleName = res.taskName;
    this.form.specialAttribute=this.formatAttributeForDetail(res.taskAttributeVos);

    if(!this.thresholdOptions.some((item)=>item == res.threshold)){
      this.thresholdOptions.push(res.threshold);
    }
    this.form.threshold = res.threshold;

    this.currentDeviceType = res.deviceVo.deviceType;
    res.deviceVo.deviceType == 6 && this.$refs.libsList.setCheckedKeys(res.passLibraryVos.map(item=> item.libraryId));
    // this.form.defaultChechedKeys = [res.deviceVo.deviceId];
    this.form.defaultKeeperName = res.deviceVo.deviceName;
    this.selectedKeeperId = res.deviceVo.deviceId;
    this.timezoneLibraryRelation = res.timezoneLibraryRelation?res.timezoneLibraryRelation:[];

    //default check timezone
    this.timezoneListDefaultChecked = this.getOnlyTimezoneIds(res.timezoneLibraryRelation);
    this.setDefaultShowLibs(this.timezoneListDefaultChecked);
  }
  setDefaultShowLibs(timezoneListDefaultChecked){
    if(timezoneListDefaultChecked.length>0 && this.$refs.libsList){
      let firstCheckedTimezoneId = timezoneListDefaultChecked[0];
      firstCheckedTimezoneId && this.timezoneListNodeClick({id:firstCheckedTimezoneId});
    }
  }
  formatAttributeForDetail(Attributes){
    let arr:any = [];
    Attributes.map((item:any)=>{
      arr.push(item.taskAttributeId)
    });
    return arr;
  }
  formatTimezoneListForDetail(timezones:any){
    timezones.map((item:any)=>{
      this.timezoneList.push({
        id:item.timezoneVo.timeZoneId,
        label:item.timezoneVo.timeZoneName
      })
    })
  }
  setDataForSpecialAttrs(res){
    this.specialAttributeOptions = [];
    res.list.map(item=>{
      this.specialAttributeOptions.push({
        id:item.taskAttributeId,
        name:this.$tc(`rule.${item.taskAttributeName}`)
      })
    })
  }
  getTimezoneList(){
    this.timezoneList = [];
    getTimezoneWithIntervals().then((res:any)=>{
      this.setDataForTimezone(res)
    })
  }
  setDataForTimezone(res){
    res && this.formatTimezoneList(res.data);
  }
  setDataForDevices(res){
    this.treeData = [];
    this.formatTreeData(res.data);
  }
  formatTreeData(list){
    this.treeData = list;
  }
  formatTimezoneList(timezoneList){
    this.timezoneList = [];
    timezoneList && timezoneList.map((item,itemIndex)=>{
      this.timezoneList.push({
        id:item.timeZoneId,
        label:item.timeZoneName
      })
    })
  }

  setDataForLibs(res,deviceType){
    this.libsList=[];
    res && this.formatLibs(res,deviceType);
  }
  formatLibs(res,deviceType){
    this.libsList = [{id:0,label:this.$tc('rule.contWhitelist'),children:[]}];
    res.whitelists && res.whitelists.map((item:any)=>{
      // this.libsList[0].children.push({
      //   id:item.libraryId,
      //   label:item.libraryName
      // })
      if(deviceType == 6 ){//前端比对设备对应人像库
        this.libsList[0].children.push({
          id:item.libraryId,
          label:item.libraryName
        });
      }else if(deviceType != 6){//非前端比对设备对应人像库
        this.libsList[0].children.push({
          id:item.libraryId,
          label:item.libraryName
        });
      }
    });
  }
  hide(){
    this.$emit('hideEditRuleacDialog');
  }
  handleClose(){
    this.hide();
  }
  handleLibsListCheckChange(data, checked, indeterminate){
    if(this.timezoneLibraryRelation[this.currentTimezoneIndex]){
      let currentLibsIds = this.timezoneLibraryRelation[this.currentTimezoneIndex]['libraryVos'];
      let index = currentLibsIds.findIndex(item => item.libraryId == data.id);
      if(checked && index<0 && data.id>0){
        currentLibsIds.push({libraryId:data.id})
      }
      if(!checked && index>=0){
        currentLibsIds.splice(index,1);
      }
    }
  }
  handleTimezoneListCheckChange(data, checked, indeterminate){
    this.$refs.timezoneList.setCurrentKey(data.id);
    let currentIndex = this.timezoneLibraryRelation.findIndex(item => item.timezoneVo.timeZoneId == data.id );
    if(checked && currentIndex < 0 ){
      this.timezoneLibraryRelation.push({
        timezoneVo:{timeZoneId:data.id},
        libraryVos:[]
      });
    }
    if(!checked && currentIndex>=0){
      this.timezoneLibraryRelation.splice(currentIndex,1);
    }
    this.timezoneListNodeClick(data);
  }
  timezoneListNodeClick(data){
    let currentIndex = this.timezoneLibraryRelation.findIndex(item => item.timezoneVo.timeZoneId == data.id );
    this.currentTimezoneIndex = currentIndex;
    if(currentIndex >= 0){
      let libraryVos = this.timezoneLibraryRelation[currentIndex].libraryVos;
      this.$refs.libsList.setCheckedKeys(this.getOnlylibraryIds(libraryVos));
    }else{
      this.$refs.libsList.setCheckedKeys([]);
    }
  }
  getOnlylibraryIds(list){
    let arr:any = [];
    list.map((item:any)=>{
      arr.push(item.libraryId)
    });
    return arr;
  }
  getOnlyTimezoneIds(timezones){
    let arr:any = [];
    timezones && timezones.map((item:any)=>{
      arr.push(item.timezoneVo.timeZoneId)
    });
    return arr;
  }
  formatTimezoneLibraryRelationData(timezoneLibraryRelation){
    let arr:any = [];
    timezoneLibraryRelation.map((item:any)=>{
      arr.push({
        "libraryIds": this.getOnlylibraryIds(item.libraryVos),
        "timezoneId": item.timezoneVo.timeZoneId
      })
    })
    return arr;
  }
  formatSubmitData(){

    let data = {
      "deviceId": this.selectedKeeperId,
      "taskName":this.form.ruleName,
      "taskAttributes": this.form.specialAttribute,
      "taskGroupVo": {'taskGroupId':this.groupId},
      "taskType": 0,//ac->0  td->1
      "threshold": this.form.threshold,
      "timezoneLibraryRelation": this.formatTimezoneLibraryRelationData(this.timezoneLibraryRelation),
      "passLibraryIds":this.$refs.libsList.getCheckedKeys(true)
    };
    if(data.threshold>0 && data.threshold<100 && !this.thresholdOptions.some((item)=> data.threshold == item)){
      data.threshold = (data.threshold*1000)/100000 ;
    }
    return data;
  }
  submitData(){
    let data = this.formatSubmitData();
    //name min:1 max:40 get40
    if(trim(data.taskName).length>40){
      data.taskName = trim(data.taskName).substr(0,40);
    };
    this.$refs.form.validate(valid=>{
      if(valid){
        if(this.currentDeviceType == 6){
          if(data.passLibraryIds && data.passLibraryIds.length>0){
            this.loading = true;
            editRuleAC(data,this.ruleId).then(res=>{
              this.$emit('editsuccess')
              this.hide();
            }).finally(()=>{
              this.loading = false;
            })
          }else{
            this.$message.error(this.$tc('form.texterrSelectImageLib'));
          }
        }else if(this.validateTimezoneLibraryRelation(data.timezoneLibraryRelation)){
          this.loading = true;
          editRuleAC(data,this.ruleId).then(res=>{
            this.$emit('editsuccess')
            this.hide();
          }).finally(()=>{
            this.loading = false;
          })
        }else{
          this.$message.error(this.$tc('rule.errmsgSelectTimeLib') as string);
        }
      }else{
        return false;
      }
    })

  }
  validateTimezoneLibraryRelation(timezoneLibraryRelation){
    if(timezoneLibraryRelation.length == 0){
      return false;
    }else{
      let isLibIds = timezoneLibraryRelation.some((item:any)=>{
        return item.libraryIds && item.libraryIds.length >0;
      });
      return isLibIds?true:false;
    }
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .edit-rule-ac-threshold{
    width: 120px;
  }
  .edit-rule-ac-timeAndLibs{
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    &>div{
      width: 50%;
    }
    .edit-rule-ac-libsheader{
      height: 24px;
      background-color: $--background-color-header;
      line-height: 24px;
      color: $--color-black;
      text-indent: 8px;
    }
    .edit-rule-ac-libsheader-time{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;
    }
    .edit-rule-ac-timeAndLibs-scrollbox{
      width: 100%;
      max-height: 225px;
      overflow: auto;
    }

  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
  // ::v-deep .el-form{
  //     max-width: 330px;
  //     margin: 0 auto;
  //   }
  .edit-rule-ac-keepertreeinput{
    width: 100%;
  }
  // ::v-deep .el-tree .el-tree-node.is-current .el-tree-node__content{
  //   background-color: $--color-reserved-6;
  // }

::v-deep .edit-rule-ac-timeAndLibs-scrollbox-times .el-tree .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .edit-rule-ac-timeAndLibs-scrollbox-times .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .edit-rule-ac-timeAndLibs-scrollbox-libs .el-tree .el-tree-node .el-tree-node__children .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .edit-rule-ac-timeAndLibs-scrollbox-libs .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }

// ::v-deep .el-form-item.is-required:not(.is-no-asterisk)>.el-form-item__label{
//     position: relative;
//     &:before {
//       position: absolute;
//       left: -8px;
//     }
//   }
  ::v-deep .el-form-item__content .el-select .el-select__tags .el-select__tags-text{
    color:#28354d;
  }
</style>
