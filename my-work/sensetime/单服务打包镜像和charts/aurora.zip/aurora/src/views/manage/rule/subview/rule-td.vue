<template>
  <div class="rule-td-container">
    <header v-if="groupModel" >
      <el-dropdown @command="handleCommandCreateRule" v-if="$permission('006314') || $permission('006318')">
        <el-button type="primary"> <i class="iconfont icon-add" ></i> {{$t('rule.buttonRuleAdd')}} </el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="one" v-if="$permission('006314')">{{$t('rule.listSingle')}}</el-dropdown-item>
          <el-dropdown-item command="more" v-if="$permission('006318')">{{$t('rule.listMultiple')}}</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </header>
    <div class="rule-td-contents" >
      <transition name="component-fade" mode="out-in">
        <RuleListTD  v-if="!groupModel" />
        <GruopTD v-else @viewrules="handleViewRules" :refreshList="refreshList" />
      </transition>
    </div>
    <!-- add rule dialog -->
    <AddRuleTD :visible="showAddRuletdDialog" @hideAddRuletdDialog="showAddRuletdDialog=false" @refresh="refreshGroupList" />
    <!-- add rule Multiple dialog -->
    <AddRuleTDMultiple :visible="showAddRuletdMultipleDialog" @hideAddRuletdMultipleDialog="showAddRuletdMultipleDialog=false" @refresh="refreshGroupList" />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import GruopTD from './group/group-td.vue';
import RuleListTD from './list/rule-list-td.vue';
import AddRuleTD from './dialog/td/add-rule-td.vue';
import AddRuleTDMultiple from './dialog/td/add-rule-td-multiple.vue';

@Component({
  components: {
    GruopTD,
    RuleListTD,
    AddRuleTD,
    AddRuleTDMultiple
  },
})
export default class RuleTD extends Vue {
  /* props */

  /* watch */
  @Watch('$route')
  onRouterChanged(val: any, oldVal: any) {     
    this.groupModel = val.hash.indexOf('#rulestd?groupId')>=0?false:true;
  }

  /* data */
  groupModel:boolean = location.hash.indexOf('#rulestd?groupId')>=0?false:true;
  showAddRuletdDialog:boolean=false;
  showAddRuletdMultipleDialog:boolean=false;
  refreshList:boolean = false;


  /* methods */
  handleViewRules(group){
    this.$router.push(`/manage/rule#rulestd?groupId=${group.groupId}&groupName=${group.groupName}`);
  }
  handleCommandCreateRule(command){
    this.refreshList = false;
    command == 'one' && (this.showAddRuletdDialog = true);
    command == 'more' && (this.showAddRuletdMultipleDialog = true);
  }
  refreshGroupList(data){
    data && (this.refreshList = true);
  }


}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .rule-td-container{
    height: 100%;
    .rule-td-contents{
      height: calc(100% - 34px);
    }
    .component-fade-enter-active, .component-fade-leave-active {
      transition: opacity .3s ease;
    }
    .component-fade-enter, .component-fade-leave-to{
      opacity: 0;
    }
  }
</style>
