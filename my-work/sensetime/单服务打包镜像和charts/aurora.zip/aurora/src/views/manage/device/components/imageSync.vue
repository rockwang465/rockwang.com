<template>
    <el-dialog
    :title="$tc('devicemanagement.titleDialogImageAsync')"
    :visible.sync="visible"
    width="56%"
    class="isroll"
    :before-close="handleClose">
    <div class="imagessync-box" >
        <el-row style="padding-bottom:8px">
            <el-col :span="6">
                <el-button v-if="$permission('007325')" type="primary" size="medium" icon="el-icon-upload2" @click="exportFail" :disabled="!(failedRecord>0)">{{$tc('devicemanagement.btnExportAsyncFail')}}</el-button>    
            </el-col>
            <el-col :span="12" style="text-align: center;height:36px;line-height:36px">
                <span >
                    <span>{{$tc('devicemanagement.contAsyncSuccess')}} {{succeedRecord}}</span>
                    <span> | </span>
                    <span style="color:red">{{$tc('devicemanagement.contAsyncFail')}} {{failedRecord}}</span>
                </span>
            </el-col>
            <el-col :span="6" style="position:relative">
                <div :style="{position: 'absolute',top: '8px',left: '-24px',}">
                    <el-popover
                        placement="bottom-start"
                        width="271"
                        trigger="hover">
                        <div class="content">
                        {{$tc('devicemanagement.tipcontImageSearch')}}
                        </div>
                        <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
                    </el-popover>
                </div>
                <el-input
                    @keydown.native="keydown"
                    :placeholder="$tc('devicemanagement.asyncSearchPlaceHolder')"
                    v-model="searchValue">
                    <span slot="suffix" class="el-input__icon">
                        <i class="el-icon-circle-close" v-if="searchValue" @click="clearSearch" ></i>
                        <i class="el-icon-search" @click="search"></i>
                    </span>
                </el-input>
            </el-col>
        </el-row>
        <el-table
        ref="table"
        v-loading="loading"
        @filter-change="tableFilterChange"
        :data="tableData" :height="480">
            <el-table-column
                prop="imageUrl"
                :label="$tc('devicemanagement.labelImage')">
                <template slot-scope="scope">
                    <div  >
                        <el-image :src="processImgurl(scope.row.imageUrl)" style="height:80px;width:60px;text-align:center;" >
                            <template slot="placeholder" >
                                <i class="el-icon-loading" ></i>
                            </template>
                        </el-image>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                prop="name"
                :label="$tc('devicemanagement.labelName')">
            </el-table-column>
            <el-table-column
                prop="identity"
                label="ID">
            </el-table-column>
            <el-table-column
                prop="groups"
                :label="$tc('devicemanagement.labelLibraryGroup')">
            </el-table-column>
            <el-table-column
                column-key="status"
                :filter-multiple="false"
                :filters="[{text:$tc('devicemanagement.contAsyncStatus1') , value: 1}, {text: $tc('devicemanagement.contAsyncStatus2'), value: 2}, {text: $tc('devicemanagement.contAsyncStatus3'), value: 3}]"
                prop="status"
                :label="$tc('devicemanagement.labelAsyncStatus')">
                <template slot-scope="scope">
                    <span :class="scope.row.status == 3?'asyncimage-err':(scope.row.status == 2?'asyncimage-success':'asyncimage-processing')">{{getStatusText(scope.row.status)}}</span>
                </template>
            </el-table-column>
            <el-table-column
                prop="updateTime"
                :label="$tc('devicemanagement.labelAsyncTime')">
            </el-table-column>
        </el-table>
        <el-pagination
        style="display:flex;justify-content: center;margin-top:8px"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="paginationPageSizes"
        :page-size="currentPageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
        </el-pagination>
    </div>
    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="handleClose" v>{{$t('rule.buttonOK')}}</el-button>
      <el-button @click="handleClose" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
    <!-- messageBox export ensure -->
    <el-dialog
    :class="{diablogAnimation:true,hidden:isHide}"
    :append-to-body="true"
    :visible="showExportDialog"
    :before-close="()=>this.showExportDialog = false"
    width="400px">
    <p style="max-width:350px;text-align:center;line-height:20px;word-break: break-word;">{{$tc('devicemanagement.contExportAll')}}</p>
    <div slot="title" >
        <span>{{$tc('devicemanagement.contAsyncExport')}}</span>
    </div>
    <span slot="footer">
        <el-button type="primary" @click="ensureExport" :loading="exportLoading">{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="showExportDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
    </el-dialog>
    </el-dialog>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import api from '@/api/device';
import {paginationPageSizes} from '@/utils/constants.ts';
import {processImgurl} from '@/utils/image';

const defaultMiniMax = {//default value
    miniNumber:{width:0,height:0},
    maxNumber:{width:0,height:0}
};

@Component({
    components: {
       
    },
})
export default class ImagesSync extends Vue {
    /* props */
    @Prop({default:false}) visible!: boolean;
    @Prop({required:true}) deviceId!: string;
    /* watch */
    @Watch('visible',{ immediate: true})
    onVisibleChange(n,o){
        n && this.initData();
        !n && this.clearTableFilter();
    }
    
    /* data */
    $refs!:{
        table:HTMLFormElement
    }
    searchValue:string=''
    tableData:any[]=[];
    currentPage:number=1;
    paginationPageSizes:any=paginationPageSizes;
    currentPageSize:number = paginationPageSizes[0];
    total:number=0;
    failedRecord:number=0;
    succeedRecord:number=0;
    filterStatus:any=null;
    processImgurl:any=processImgurl;
    isHide:boolean=false;
    showExportDialog:boolean=false;
    exportLoading:boolean=false;
    loading:boolean=false;
    /* methods */
    mounted(){

    }
    initData(){
        this.searchValue = ''
        this.tableData = [];
        this.currentPage = 1;
        this.paginationPageSizes = paginationPageSizes;
        this.currentPageSize = paginationPageSizes[0];
        this.total = 0;
        this.failedRecord = 0;
        this.succeedRecord = 0;
        this.filterStatus = null;
        this.isHide = false;
        this.showExportDialog=false;
        this.exportLoading=false;
        this.loading=false;
        this.getData();
    }
    getData(){
        let condition=this.searchValue||null;
        let status = this.filterStatus;
        let sync = 1;
        sync = condition === null && status === null ?1:0;
        this.tableData = [];
        this.loading=true;
        api.getDeviceImagesSync({id:this.deviceId,pageNumber:this.currentPage,pageSize:this.currentPageSize,status,condition,sync}).then((res:any)=>{
            this.loading=false;
            res && this.formatData(res);
        }).finally(()=>{
            this.loading=false;
        })
    }
    formatData(res){
        this.tableData = [];
        this.total = res.total;
        if(res.data){
            this.failedRecord = res.data.failed_record;
            this.succeedRecord =  res.data.succeed_record;
            res.data.person_infos && res.data.person_infos.length>0 && res.data.person_infos.forEach(person => {
                this.tableData.push({
                    imageUrl:person.imageUrl,
                    name:person.name,
                    identity:person.identity,
                    groups:person.groups,
                    status:person.status,
                    updateTime:person.update_time
                })
            });
        }
    }
    handleClose(){
        this.$emit('close')
    }
    clearSearch(){
        this.searchValue = '';
        this.search();
    }
    search(){
        this.currentPage=1;
        this.getData();
    }
    keydown(e){
        e.keyCode == '13' && this.search();
    }
    exportFail(){
        this.showExportDialog=true;
    }
    handleSizeChange(v){
        this.currentPageSize = v;
        this.currentPage = 1;
        this.getData();
    }
    handleCurrentChange(v){
        this.currentPage = v;
        this.getData();
    }
    tableFilterChange(filter){
        this.filterStatus = filter.status[0]||null;
        this.currentPage=1;
        this.getData();
    }
    getStatusText(status){
        switch (status) {
            case 1:
                
                return this.$tc('devicemanagement.contAsyncStatus1');
        
            case 2:
                
                return this.$tc('devicemanagement.contAsyncStatus2');
            case 3:
                
                return this.$tc('devicemanagement.contAsyncStatus3');
        }
        return '';
    }
    ensureExport(){
        this.exportLoading=true;
        api.exportdeviceAsyncFailTargets(this.deviceId).then(res=>{
            this.$message({
                showClose: true,
                message:this.$tc('log.exportSuccess'),
                type: 'success'
            });
            this.showExportDialog=false;
            this.isHide = true;
            setTimeout(()=>{
                this.isHide = false;
            },1010)
        }).finally(()=>{
            this.exportLoading=false;
        })
    }
    clearTableFilter(){
        this.$refs.table && this.$refs.table.clearFilter();
    }
    

    
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.imagessync-box{
    width: 100%;
}
.asyncimage-err{
    color: #f56c6c;
}
.asyncimage-success{
    color: #67c23a;
}
.asyncimage-processing{
    color: #e6a23c;
}
::v-deep .el-input{
    .el-input__inner{
        padding-right: 40px;
    }
    .el-input__suffix{
        .el-input__icon {
            .el-icon-circle-close{
                margin-right: 4px;
            }
            i{
                cursor: pointer;
            }    
        }
    } 
}
::v-deep .el-pagination__sizes{
    width: 100px;
}
.diablogAnimation{
    width: 100%;
    height: 100%;
}
.hidden {
    transition: all 1s;
    overflow: hidden;
    display: block !important;
    position: fixed;
    top: -10%;
    bottom: 110%;
    right: 5%;
    left: 95%;
    width: 0;
    height: 0;
    opacity: 0;
    ::v-deep .el-dialog {
      min-width: 30%;
      min-width: 30%;
      height: 30%;
      overflow: hidden;

    }
  }

  ::v-deep .el-dialog__footer{
      padding-top: 40px;
  }
</style>
