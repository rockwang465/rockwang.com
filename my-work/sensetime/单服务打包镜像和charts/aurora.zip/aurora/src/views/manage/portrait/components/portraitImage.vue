<template>
    <div class="portraitimage-box" >
        <div class="portraitimage-image" >
            <el-popover
                placement="bottom-start"
                title=""
                transition=""
                :open-delay="0"
                :close-delay="0"
                popper-class="portraitimage-popover"
                width="230"
                style="nackground-color:red"
                trigger="hover">
                <div class="portraitimage-popover-text" >
                    <p>{{$tc('imagemanagement.contUploadTime')}}：{{data.uploadTime}}</p>
                    <p>{{$tc('imagemanagement.contFailReason.Title')}}：{{data.failReason}}</p>
                    <p>{{$tc('imagemanagement.contImageLibrary')}}：{{data.libraryNames}}</p>
                </div>
                <el-image slot="reference" :src="processImgurl(data.url)" :fit="fit" lazy>
                    <div slot="placeholder" class="portraitimage-image-slot">
                        <i class="el-icon-loading" ></i>
                    </div>
                </el-image>    
            </el-popover> 
        </div>
        <div class="portraitimage-text">
            <p :title="data.name">{{$tc('imagemanagement.labelName')}}:{{data.name||''}}</p>
            <p :title="data.identity">NO.:{{data.identity||''}}</p>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {processImgurl} from '@/utils/image';

@Component({
    components: {
        
    },
})
export default class PortraitImage extends Vue {
    /* props */
    @Prop(Object) data!: any;
    /* watch */
    
    /* data */
    fit:string="cover";
    processImgurl:any=processImgurl;
    /* methods */
    
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.portraitimage-box{
    width: 120px;
    display: inline-block;
    margin-right: 8px;
    margin-bottom: 8px;
    .portraitimage-image{
        width: 100%;
        height: 160px;
        // border: 1px dashed #ccc;
        .portraitimage-image-slot{
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    }
    .portraitimage-text {
        padding-top: 4px;
        p{
            overflow:hidden; //超出的文本隐藏
            text-overflow:ellipsis; //溢出用省略号显示
            white-space:nowrap; //溢出不换行
        }
    }
    
    
}
::v-deep .el-image{
    width: 100%;
    height: 100%;
}
 
</style>
<style rel="stylesheet/scss" lang="scss">
.el-popover.portraitimage-popover{
    border-color: #495d88;
    background-color: #495d88;
    color: #bacef5;
    .popper__arrow::after{
        border-bottom-color: #495d88;
    }
}
</style>
