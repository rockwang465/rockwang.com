<template>
  <div>
    <!--删除弹框-->
    <el-dialog
      :title="$t('usermanagement.listDelete')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <div v-if="true" class="content">
        <!--删除后，已选用户将不再支持使用！-->
        {{$t('usermanagement.popmsgUserDelete')}}
      </div>
      <span slot="footer" class="dialog-footer">
        <!--删 除-->
        <el-button v-if="true" type="danger" @click="deleteUser">{{$t('usermanagement.buttonDelete')}}</el-button>
        <!--确 定-->
        <el-button v-else type="primary" @click="dialogShowVisible = false">{{$t('usermanagement.buttonOK')}}</el-button>
        <!--取 消-->
        <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--删除弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {UserModule} from '@/store/modules/user';
  @Component({

  })
  export default class userDelete extends Vue {
    @Prop(Object) deleteInfo!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    @Prop({required: true, default: false}) usId!: number;
    //编辑的表单里的值
    dialogShowVisible = false;
    userId = 1;
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeUserDelete")
      }
    }
    @Watch('usId')
    onUsIdChange(val: any) {
      this.userId = val;
    }
    deleteUser(){
      this.userDelete();
      this.dialogShowVisible = false;
    }
    //删除用户请求
    userDelete(){
      let that = this as any;
      let dataObj = {}  as any;
      dataObj.params = {};
      dataObj.userId = this.userId;
        UserModule.UserDelete(dataObj).then((data: any) => {
          console.log('删除用户',data);
          this.$message({
            showClose: true,
            // message: "所选用户删除成功",
            message: that.$t('globaltip.tipmsgDeleteUser'),
            type: 'success'
          })
          this.$emit("searchUserList");
        }).catch((err) => {

        });
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .content{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    padding: 20px;
  }
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  .content .left span{
    padding-left: 70%;
    font-weight: 600;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
</style>
