<template>
  <div>
    <!--修改密码弹框-->
    <el-dialog
      title="修改密码"
      :visible.sync="dialogShowVisible"
      width="30%">

      <el-row>
        <el-row class="row">
          <el-col :span="4">旧密码 </el-col>
          <el-col :span="9"><el-input></el-input></el-col>
        </el-row>
        <el-row class="row">
          <el-col :span="4">新密码 </el-col>
          <el-col :span="9"><el-input></el-input></el-col>
        </el-row>
        <el-row class="row">
          <el-col :span="4">再次输入 </el-col>
          <el-col :span="9"><el-input></el-input></el-col>
        </el-row>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogShowVisible = false">确 定</el-button>
        <el-button class="cancel" @click="dialogShowVisible = false">取 消</el-button>
     </span>
    </el-dialog>
    <!--修改密码弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch} from 'vue-property-decorator';

  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    }
  })
  export default class userPassword extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeUserPassword")
      }
    }


  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  ::v-deep .el-dialog__body {
    padding: 0 0 20px 0 !important;
  }
  ::v-deep .el-input__inner{
    height: 32px;
  }
  .row{
    display: flex;
    justify-content: center;
    margin-top: 10px;
  }
  .el-col{
    line-height: 32px;
  }
  .sx{
    padding-left: 23%;
  }
</style>
