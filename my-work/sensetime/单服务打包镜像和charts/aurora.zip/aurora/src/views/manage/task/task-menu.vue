<template>
    <div class="task-menu-container">
        <div class="task-menu-title" >{{$t('task.taskTitle')}}</div>
        <ul class="task-menu-list">
            <li v-for="(taskT,TaskIindex) in taskType" :key="TaskIindex"
                :class="currentModel == taskT.name?'task-menu-list-current':''" 
                @click="modelChange(taskT.name)"> {{taskT.label}}</li>
        </ul>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {taskType} from '@/utils/constants.ts';

@Component({
    components: {
        
    },
})
export default class TaskMenu extends Vue {
    /* props */
    @Prop({required:true }) currentModel!: string;
    /* watch */
    
    /* data */
    taskType:any[]=taskType;
    /* methods */
    modelChange(model:string){
        this.$emit('taskModelChange',model)
    }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .task-menu-container{
        width: 312px;
        padding: 16px;
        .task-menu-title{
            font-size: 16px;
            font-weight: 900;
            border-bottom:1px solid $--color-top;
            padding-bottom: 16px;
        }
        .task-menu-list{
            &>li{
                margin-top: 8px;
                padding:8px;
                font-weight: 500;
                background:rgba(255,255,255,1);
                @include shadowBox();
                opacity:1;
                border-radius:4px;
                cursor: pointer;
            }
            &>li.task-menu-list-current{
                background:rgba(1,28,80,1);
                color: #fff;
            }
        }
  }
</style>
