<template>
  <div>
    <el-dialog class="details"
               :title="$t('imagemanagement.listDetail')"
               :visible.sync="dialogShowVisible"
               width="30%">
      <div class="content">
        <div class="left">
          <!--分组类型-->
          <span>{{$t('imagemanagement.contGroupType')}}</span>
          <!--分组名称-->
          <span>{{$t('usermanagement.contGroupName')}}</span>
          <!--创建时间-->
          <span>{{$t('imagemanagement.contTimeCreation')}}</span>
          <!--创建者-->
          <span>{{$t('usermanagement.contCreator')}}</span>
        </div>
        <div class="right">
          <span>{{dataObj.type === 1 ? $t('imagemanagement.contWhiltelist'): $t('imagemanagement.contBlacklist')}}</span>
          <el-tooltip v-if="dataObj.name&&dataObj.name.length>16" class="item" effect="dark" :content="dataObj.name" placement="top">
            <span class="type-name">{{dataObj.name}}</span>
          </el-tooltip>
          <span class="type-name" v-else>{{dataObj.name}}</span>
          <span>{{dataObj.createTime}}</span>
          <span>{{dataObj.createUserName}}</span>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <!--确定-->
        <el-button type="primary" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonOK')}}</el-button>
        <!--取消-->
      <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';

  @Component({

  })
  export default class portraitDetails extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    @Prop(Object) dataObj!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;

    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeDetails")
      }
    }


  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .type-name{
    /*width: 100%;*/
    overflow: hidden; /*超出部分隐藏*/
    white-space: nowrap; /*规定段落中的文本不进行换行 */
    text-overflow: ellipsis; /* 超出部分显示省略号 */
  }
  .left{
    margin-right: 20px;
  }
  .content{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    /*width: 60%;*/
  }
  .content>div{
    /*width: 45%;*/
  }
  .content>div>span{
    width: 100%;
    display: block;
    line-height: 16px;
    margin-top: 10px;
  }
  .content .left span{
    /*padding-left: 40%;*/
    font-weight: 600;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  .dialog-footer{
    margin-top: 15px;
  }
</style>
