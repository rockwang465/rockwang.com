<template>
  <div @drop="dddrop">
    <!--添加人像弹框-->
    <el-dialog
      top="10vh"
      :title="$t('imagemanagement.buttonAddImage')"
      :visible.sync="dialogShowVisible"
      class="isroll"
      :width="formLabelWidth2">
      <el-form
        :rules="rulesList"
        label-position="right"
        ref="dataForm" :model="form">
        <div class="wrap">
          <div class="top"
               @dragover="dragover"
               @drop="dddrop">
            <label for="img-upload-btn" class="upload">
              <span v-show="showIcon"><i class="iconfont el-icon-plus"></i></span>
              <img v-show="!showIcon" id="selectedImg" src="" alt="">
            </label>
            <el-form-item prop="image" :label-width="formLabelWidth">
              <input type="file" id="img-upload-btn"
                     accept="image/*" @change="upImage($event)"/>
            </el-form-item>
          </div>
          <div class="detail">
            <el-form-item :label="$t('imagemanagement.labelName')" prop="name" :label-width="formLabelWidth">
              <el-input
                @input="inputName"
                size="small" v-model="form.name" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <el-form-item :label="$t('imagemanagement.contAlias')" :label-width="formLabelWidth">
              <el-input
                @input="inputName2"
                size="small" v-model.trim="form.aliasName" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <el-form-item :label="$t('imagemanagement.contID')" prop="ID" :label-width="formLabelWidth">
              <!--请输入数字和字母的组合-->
              <el-input
                :placeholder="$t('form.texterrPersonIDPolicy')"
                size="small" v-model.trim="form.ID" maxlength="32"  autocomplete="off"></el-input>
            </el-form-item>
            <!--人像库-->
            <el-form-item :label="$t('imagemanagement.contImageLibrary')" prop="libraryIds" :label-width="formLabelWidth">
              <!--多选-->
              <!--<el-select-->
              <!--v-model="form.libraryId" @change="selectPortrait" size="small" class="el-list">-->
              <!--<el-option-->
              <!--v-for="item in treeData"-->
              <!--:key="item.id"-->
              <!--:label="item.libraryName"-->
              <!--:value="item.libraryId">-->
              <!--</el-option>-->
              <!--</el-select>-->
              <TreeSelect size="small" :data="treeData"
                          @selected="handleSelected"
                          show-checkbox
                          style="width:90%"
                          :dataObj="dataUserIdsObj"/>
            </el-form-item>
          </div>
        </div>
        <el-row class="option">{{$t('imagemanagement.contOtherInfo')}}</el-row>
        <div class="bottom">
          <div class="bline1">
            <el-form-item style="width: 50%;" prop="gender" :label="$t('imagemanagement.contGender')" :label-width="formLabelWidth">
              <el-radio v-model="form.gender" :label="1">{{$t('imagemanagement.contMale')}}</el-radio>
              <el-radio v-model="form.gender" :label="2">{{$t('imagemanagement.contFemale')}}</el-radio>
            </el-form-item>
            <!--年龄-->
            <el-form-item class="age" style="width: 50%;" :label="$t('imagemanagement.contAge')" :label-width="formLabelWidth3">
              <!--请输入0-150之间的数字-->
              <el-input
                @input="inputAgeNum"
                :placeholder="$t('form.texterrAgePolicy')"
                size="small" v-model="form.age" autocomplete="off" maxlength="3"></el-input>
            </el-form-item>
          </div>
          <div class="bline1">
            <!--公司-->
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contCompany')" :label-width="formLabelWidth">
              <el-input size="small" v-model="form.company" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contDepartment')" :label-width="formLabelWidth3">
              <el-input size="small" v-model="form.dept" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
          </div>
          <div class="bline1">
            <!--联系方式-->
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contContact')" :label-width="formLabelWidth">
              <el-input size="small" v-model="form.phone" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <!--车牌号-->
            <el-form-item style="width: 50%;" :label="$t('visitor.visitorlist.labelCarNumber')" :label-width="formLabelWidth3">
              <el-input
                size="small" v-model="form.vehiclePlateNumber" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
          </div>
          <div class="lang">
            <!--<el-form-item :style="{width:this.formLabelWidth == '80px'?'95%':'87%'}" :label="$t('imagemanagement.contContact')" :label-width="formLabelWidth">-->
              <!--<el-input size="medium" v-model="form.phone" autocomplete="off" maxlength="40"></el-input>-->
            <!--</el-form-item>-->
            <el-form-item :style="{width:this.formLabelWidth == '80px'?'95%':'87%'}" :label="$t('imagemanagement.contAddress')" :label-width="formLabelWidth">
              <el-input v-model="form.address" :class="formLabelWidth == '80px'?'':'en-address'" autocomplete="off" maxlength="30"></el-input>
            </el-form-item>
          </div>

          <div class="bline1" v-if="!worb">
            <!--激活状态-->
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contTimeActivation')" prop="activationTime" :label-width="formLabelWidth">
              <el-date-picker class="starTime"
                              v-model="form.activationTime"
                              type="datetime"
                              value-format="yyyy-MM-dd HH:mm:ss"

                              :placeholder="$t('imagemanagement.contTimeSet')">
              </el-date-picker>
              <!--:picker-options="startDatePicker"-->
            </el-form-item>
            <!--启用/停用-->
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.EnabledAndDisabled')" :label-width="formLabelWidth4">
              <!--<el-select v-model="form.enableState" @change="selectState" size="small" class="el-list">-->
                <!--<el-option-->
                  <!--v-for="item in selectData"-->
                  <!--:key="item.id"-->
                  <!--:label="item.label"-->
                  <!--:value="item.id">-->
                <!--</el-option>-->
              <!--</el-select>-->
              <el-switch
                @change="updateStates(form.enableState)"
                v-model="form.enableState === 1"
                active-color="#13ce66"
                inactive-color="#ff4949">
              </el-switch>
            </el-form-item>
          </div>
          <div class="bline1" v-if="!worb">
            <!--prop="expirationTime"-->
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contTimeExpiration')"  :label-width="formLabelWidth">
              <el-date-picker class="cancelTime"
                              :disabled="worb"
                              v-model="form.expirationTime"
                              type="datetime"

                              value-format="yyyy-MM-dd HH:mm:ss"
                              :placeholder="$t('imagemanagement.contTimeSet')">
              </el-date-picker>
              <!--:picker-options="endDatePicker"-->
            </el-form-item>
          </div>
        </div>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="okDisabled" @click="subInfo">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" type="info" @click="cancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--添加弹框-->
    <!--替换弹框-->
    <el-dialog
      :title="$t('imagemanagement.titleAlarm')"
      :visible.sync="replaceBool"
      width="584px">
      <div class="warn-wrap">
        <el-alert
          :title="$t('imagemanagement.popmsgIDOccupied')"
          type="warning">
        </el-alert>
        <br>
        <div class="content">

          <div class="avatar">
            <img :src="processImgurl(idData.imageUrl)">
          </div>
          <div class="name">
            <div class="line">
              <!--姓名-->
              <div class="left">{{$t('imagemanagement.contName')}}</div>
              <div class="right">{{idData.name}}</div>
            </div>
            <div class="line">
              <!--别名-->
              <div class="left">{{$t('imagemanagement.contAlias')}}</div>
              <div class="right">{{idData.aliasName}}</div>
            </div>
            <div class="line">
              <!--ID-->
              <div class="left">{{$t('imagemanagement.contID')}}</div>
              <div class="right">{{idData.ID}}</div>
            </div>
            <div class="line2">
              <!--人像库-->
              <div class="left">{{$t('imagemanagement.contImageLibrary')}}</div>
              <div class="right">
                <ul>
                  <li v-for="(item,key) in idData.libraryVos" :key="key">{{item.name}}</li>
                  <!-- <li v-for="item in idData.libraryVos">{{item.name}}</li> -->
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="danger" @click="replaceSubInfo" :loading="replaceLoading">{{$t('imagemanagement.buttonReplace')}}</el-button>
        <el-button class="cancel" @click="replaceBool = false">{{$t('imagemanagement.buttonDiscard')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {PortraitModule} from '@/store/modules/portrait';
  import TreeSelect from "@/components/portraitDeviceAdd/index.vue";
  import {isEmpty} from '@/utils/validate';
  import {fileValidate} from '@/utils/validate';
  import {AppModule} from '@/store/modules/app';
  import ImageSelect from '@/components/image-select/index.vue';
     import {processImgurl} from '@/utils/image.ts';
  let stp = false;
  let vm = null as any;
  const nameTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrEnterName')))//请输入名字
    }else{
      callback()
    }
  }
  const timeTip = (rule, value = '', callback) => {
    if (value === ''|| value === null){
      callback(new Error(vm.$t('form.texterrSelectTime')))//请选择时间
    }else{
      callback()
    }
  }
  const imgTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrUploadImage')))//请输入图片
    }else{
      callback()
    }
  }
  const genderTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrSelectGender')))//请选择性别
    }else{
      callback()
    }
  }
  const requiredTime = (rule, value = '', callback) => {
    // debugger
    if (stp){
      callback()
    } else{
      if (value === ''|| value === null) {
        // debugger
        callback(new Error(vm.$t('form.texterrSelectTime')))
      } else {
        callback()
      }
    }

  }
  const libraryIdsTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrSelectImageLib')))//请选择人像库
    }else{
      callback()
    }
  }
  const idTip = (rule, value = '', callback) => {
    if (value === ''|| value === null) {
      callback(new Error(vm.$t('form.texterrEnterID')))//"请输入ID"
    }

    // let re = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{1,40}$/ as any
    let re =/^[0-9a-zA-Z]+$/
    if (re.test(value)) {
      callback()
    }else{
      callback(new Error(vm.$t('form.texterrPersonIDPolicy')))//"请输入数字和字母的组合"
    }
  }
  @Component({
    components: {
      TreeSelect,
      ImageSelect
    },
    computed: {
      rulesList: function () {
        let that = this as any;
        return that.rules1
      },
      selectData:function () {
        let that = this as any;
        return [{
          id: 1,
          label: that.$t('usermanagement.listStatusEnabled'),
        }, {
          id: 2,
          label: that.$t('usermanagement.listStatusDisabled'),
        }]
      },
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '80px';
      },
      formLabelWidth2: function () {
        let that = this as any;
        return that.language == 'en' ? '720px' : '584px';
      },
      formLabelWidth3: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '70px';
      },
      formLabelWidth4: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '100px';
      }
    }
  })
  export default class portraitAdd extends Vue {
    get language() {
      return AppModule.language;
    }

    okDisabled = false as any;
    startDatePicker= this.beginDate();
    endDatePicker= this.processDate();
    imageName="";
    // formLabelWidth = '80px';
    // formLabelWidth2 = '584px';
    dialogShowVisible = false;
    replaceBool = false;
    radio = "1";
    time1 = "";
    time2 = "";
    processImgurl:any=processImgurl;
    // value = "激活";
    showIcon = true;
    worb = false;//判断是白名单还是黑名单
    // tips1 = (this as any).$t('form.texterrEnterName')
    rules1 = {
      name: [{required: true, trigger: 'blur',  validator: nameTip}],//'请输入姓名'
      ID: [{required: true, trigger: 'blur', validator: idTip}],
      activationTime: [{required: true, trigger: 'blur', validator: timeTip}],//'请选择时间'
      expirationTime: [{required: true, trigger: 'blur', validator: requiredTime}],
      libraryIds: [{required: true, trigger: 'change', validator: libraryIdsTip}],
      image: [{required: true, trigger: 'change', validator:imgTip}],//'请上传本地人像照片'
      gender: [{required: true, validator:genderTip, trigger: 'change'}],
    };

    dataUserIdsObj = {
      userIds: [],
      defaultIds: [],
      type: null as any
    } as any;
    conditions = {file: null}; //添加文件
    //传入后端参数
    form = {
      ID: "",
      activationTime: "",
      enableState: 1,
      address: "",
      age: null,
      aliasName: "",
      company: "",
      dept: "",
      expirationTime: "",
      vehiclePlateNumber:'',
      gender: 1,
      image: "",
      libraryIds: [] as any,
      name: "",
      phone: "",
      replace: 0
    }  as any;
    idData = {} as any;
    replaceLoading:boolean = false;
    // token = null as any;
    host = window.globalConfig.host as any;
    @Prop(Array) treeData!: any;
    @Prop(Number) libraryId!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;

    created(){
      vm = this as any;
    }
    @Watch('worb')
    onWorbChange(val: any) {
      this.form.activationTime = '';
      this.form.expirationTime = '';
    }

    // @Watch('form.activationTime')
    // onActivationTimeChange(val:any){
    //   if (this.form.expirationTime) {
    //     if (new Date(this.form.activationTime).getTime() > new Date(this.form.expirationTime).getTime()){
    //       this.form.activationTime = '';
    //     }
    //   }
    // }
    //
    // @Watch('form.expirationTime')
    // onExpirationTimeChange(val:any){
    //   if (this.form.activationTime) {
    //     if (new Date(this.form.expirationTime).getTime() < new Date(this.form.activationTime).getTime()){
    //       this.form.expirationTime = '';
    //     }
    //   }
    // }

    @Watch('form.age')
    onFormChange(val: any) {
      if (val - 0 > 150){
        this.form.age = 150;
      }
      if (val < 0){
        this.form.age = 0;
      }
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      //初始化
      this.dataUserIdsObj = {
        userIds: [],
        defaultIds: [],
        type: null as any
      } as any;
      this.worb = false
      stp = false
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      let that = this as any;
      if (!val) {
        that.$refs['dataForm'].resetFields()
        this.$emit("closePortraitAdd")
        this.cleaData();
      }
    }

    //输入验证
    inputAgeNum(val){
      if(this.verifySize(val)){
        this.form.age = val
      }else{
        this.form.age = '';
      }

    }

    //输入验证
    inputName(val){
      if(this.verifySize2(val)){
        this.form.name = val
      }else{
        this.form.name = '';
      }

    }
    //输入验证
    inputName2(val){
      if(this.verifySize2(val)){
        this.form.aliasName = val
      }else{
        this.form.aliasName = '';
      }

    }
    inputVehiclePlateNumber(val){
      if(this.verifySize3(val)){
        this.form.vehiclePlateNumber = val
      }else{
        console.log(val)
        this.form.vehiclePlateNumber = '';
      }
    }
    //输入验证
    verifySize(val){//数字
      let reg = /^([0-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        return true;
      }else{
        return false;
      }
    }

    //输入验证
    verifySize2(val){//无空格
      // let reg = /^\d*$/
      let reg = /^\S+/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }

    //输入验证
    verifySize3(val){//无特殊字符
      // let reg = /^([\u4e00-\u9fa5]+|[a-zA-Z0-9]+)$/
      let reg = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }

    //时间判断
    beginDate(){
      const self = this
      return {
        disabledDate(time){
          if (self.form.expirationTime) {  //如果结束时间不为空，则小于结束时间
            return new Date(self.form.expirationTime).getTime() < time.getTime()
          } else {
            // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
          }
        }
      }
    }
    handleSelected(obj) {
      console.log(obj);
      // this.form.deviceIds = obj.userIds;
      this.dataUserIdsObj = obj;
      this.form.libraryIds = obj.userIds;
      this.dataUserIdsObj.type == 2 ? this.worb = true : this.worb = false;
      this.dataUserIdsObj.type == 2 ? stp = true : stp = false;
      (this.$refs.dataForm as any).validateField('libraryIds');
    }
    processDate() {
      const  self = this
      return {
        disabledDate(time) {
          if (self.form.activationTime) {  //如果开始时间不为空，则结束时间大于开始时间
            return new Date(self.form.activationTime).getTime() > time.getTime()
          } else {
            // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
          }
        }
      }
    }

    dddrop(evt){
      // debugger
      let vm = this as any;
      console.log(evt)
      evt.stopPropagation();
      evt.preventDefault();
      let picLink = evt.dataTransfer.getData("text/plain") || evt.dataTransfer.getData("URL");
      if(picLink){
        //web页面拖拽
        var image = new Image();
        image.src = picLink;
        image.setAttribute("crossOrigin",'Anonymous');
        image.onload = function(){
          picLink = getBase64Image(image);
          function getBase64Image(img) {
            var canvas = document.createElement("canvas") as any;
            canvas.width = img.width;
            canvas.height = img.height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, img.width, img.height);
            var ext = img.src.substring(img.src.lastIndexOf(".")+1).toLowerCase();
            var dataURL = canvas.toDataURL("image/"+ext);
            return dataURL;
          }
          let params = {} as any;
          params.image = picLink;
          PortraitModule.protraitDetection(params).then((data:any)=>{
            console.log(data)
            vm.showIcon = false;
            let selectImg =  document.getElementById("selectedImg") as any;
            console.log(picLink);
            selectImg.setAttribute("src",picLink);
            vm.form.image = picLink;
          })
        }
      }else{
        // 文件拖拽
        let vm = this as any;
        let file = evt.dataTransfer.files[0];
        let reader = new FileReader() as any;

        let Orientation ;
        let _this = vm;
        vm.EXIF.getData(file, ()=> {
        Orientation =  _this.EXIF.getTag(file , 'Orientation')
        //将文件以Data URL形式读入页面
          reader.readAsDataURL(file);
          reader.onload = function() {
            //显示文件
            let params = {} as any;
            params.image = this.result;
            PortraitModule.protraitDetection(params).then((data:any)=>{
              console.log(data , '----------------------')
              vm.showIcon = false;
              let selectImg =  document.getElementById("selectedImg") as any;


                  switch (Orientation) {
                  case 1:
                    selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                    break;
                  case undefined:
                    selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                    break;
                  case 6:
                    selectImg.style = 'transform: rotate(90deg);width :158px;height : 118px '
                    break;
                  case 3:
                    selectImg.style = 'transform: rotate(180deg);width :118px;height : 158px '
                    break;
                  case 8:
                    selectImg.style = 'transform: rotate(-90deg);width :158px;height : 118px '
                    break;
                }

              selectImg.setAttribute("src",this.result);
              vm.form.image = this.result;
            }).catch((err)=>{

            })
          };
        })
      }
    }
    dragover(evt){
      evt.stopPropagation();
      evt.preventDefault();
    }

    //上传图片前端展示
    upImage(e){
      console.log(e)
      let vm = this as any;
      let Orientation ;
      this.conditions.file = e.target.files[0];
      //处理exif属性
      let _this = vm
      vm.EXIF.getData(this.conditions.file, ()=> {
        // console.log(this.conditions.file);

        Orientation =  _this.EXIF.getTag(this.conditions.file , 'Orientation') // 此处打印的为选中图片的数据
        // let orientation =_this.EXIF.getAllTags(this.conditions.file).Orientation

        let bool = vm.beforePicUpload(this.conditions.file);
        if (bool == false){
          return;
        }
        let reader = new FileReader() as any;
        //将文件以Data URL形式读入页面
        reader.readAsDataURL(this.conditions.file);
        reader.onload = function() {
          //显示文件
          let params = {} as any;
          params.image = this.result;
          PortraitModule.protraitDetection(params).then((data:any)=>{
            let selectImg =  document.getElementById("selectedImg") as any;
            switch (Orientation) {
              case 1:
                selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                break;
              case undefined:
                selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                break;
              case 6:
                selectImg.style = 'transform: rotate(90deg);width :158px;height : 118px '
                break;
              case 3:
                selectImg.style = 'transform: rotate(180deg);width :118px;height : 158px '
                break;
              case 8:
                selectImg.style = 'transform: rotate(-90deg);width :158px;height : 118px '
                break;
            }

            console.log(data)
            vm.showIcon = false;
            selectImg.setAttribute("src",this.result);
            vm.form.image = this.result;
            vm.$refs.dataForm.validateField('image');

          }).catch((err)=>{
            e.target.value = ''
          })
        };
      })


    }


    //图片验证
    beforePicUpload(file){
      let that = this as any;
      let isFile = fileValidate(file,['png','jpg','jpeg','bmp'],16);
      if(!isFile.type){
        this.$message.error({showClose: true,message:that.$t('imagemanagement.tipsPicType')});
        return false;
      }
      if (!isFile.size) {
        this.$message.error({showClose: true,message:that.$t('imagemanagement.tipsOversize')});
        return false;
      }
    }
    //选择激活状态
    selectState(){
      // if(this.value == '激活'){
      //    this.form.enableState = 1;
      // }else if(this.value == '未激活'){
      //   this.form.enableState = 2;
      // }
    }
    //提交表单
    subInfo(){
      this.okDisabled = true;
      setTimeout(()=>{
        this.okDisabled = false;
      },2000)
      let that = this as any;
      // if (new Date().getTime() - 180000 > new Date(this.form.activationTime).getTime()){
      //   // 保留3分钟的误差
      //   this.form.activationTime = '';
      //   this.form.expirationTime = '';
      //   this.$message({
      //     // message:that.$t('globaltip.tipmsgAddImage'),
      //     message:'激活时间需晚于当前时间',
      //     type: 'error'
      //   })
      //   return;
      // }
      if (!this.worb && this.form.expirationTime && new Date(this.form.expirationTime).getTime() < new Date(this.form.activationTime).getTime()){
        this.form.activationTime = '';
        this.form.expirationTime = '';
        this.$message({
          message:that.$t('imagemanagement.timeTips'),
          // message:'激活时间需早于失效时间',
          type: 'error'
        })
        return;
      }
      // if(this.form.vehiclePlateNumber){
      //   let reg = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/;
      //   if (!reg.test(this.form.vehiclePlateNumber)||this.form.vehiclePlateNumber.length < 7){
      //     this.$message({
      //       message:that.$t('visitor.visitorlist.tipsCarNumberErr'),
      //       type: 'error'
      //     })
      //     return
      //   }
      // }
      (that.$refs.dataForm as any).validate((valid) => {
        console.log(valid)
        if (valid) {
          // if (this.form.expirationTime == ""){
          //   this.form.expirationTime = "3019-02-13 00:00:00"
          // }
          console.log(this.form)
          this.form.libraryType = this.dataUserIdsObj.type;
          this.form.libraryIds = this.dataUserIdsObj.userIds
          this.form.activeState = this.form.enableState;
          PortraitModule.PortraitAdd(this.form).then((data: any) => {
            console.log("返回数据",data);
            if (data.code == '408006'){
              this.replaceBool = true
              let params = {} as any;
              params.ID = this.form.ID;
              PortraitModule.protraitIdDetails(params).then((data: any) => {
                console.log('idData',data);
                // this.token = JSON.parse((localStorage as any).getItem("accessToken")).value;
                data.imageUrl =  data.imageUrl;
                this.idData = data;
              }).catch((err) => {

              });
            } else if (!data.code) {
              let that = this as any;
              this.dialogShowVisible = false;
              this.$emit("inIt");
              this.$message({
                showClose: true,
                // message: "添加人像成功",
                message:that.$t('globaltip.tipmsgAddImage'),
                type: 'success'
              })
              this.cleaData();
            }
          }).catch((err) => {
            console.log("返回数据",err);
            // this.$message(err);
            // if (err.code == 408006){
            //   alert(1)
            // }
          });
        }
      })

    }
    //提交表单
    replaceSubInfo(){
      this.replaceLoading = true;
      let that = this as any;
      (that.$refs.dataForm as any).validate((valid) => {
        console.log(valid)
        if (valid) {
          // if (this.form.expirationTime == ""){
          //   this.form.expirationTime = "3019-02-13 00:00:00"
          // }
          this.form.replace = 1;
          console.log(this.form)
          this.form.libraryType = this.dataUserIdsObj.type;
          this.form.libraryIds = this.dataUserIdsObj.userIds
          PortraitModule.PortraitAdd(this.form).then((data: any) => {
            console.log("返回数据",data);
            if (data.code == '408006'){

            } else if (!data.code){
              this.dialogShowVisible = false;
              this.$emit("inIt");
              this.$message({
                showClose: true,
                // message: "添加人像成功",
                message:that.$t('globaltip.tipmsgAddImage'),
                type: 'success'
              })
              this.cleaData();
              this.replaceBool = false;
            }
          }).catch((err) => {
            console.log("返回数据",err);
            // this.$message(err);
            // if (err.code == 408006){
            //   alert(1)
            // }
          }).finally(()=>{
            this.replaceLoading = false;
          });
        }
      })

    }
    cancel(){
      this.cleaData();
      this.dialogShowVisible = false;
    }
    //清除表单
    cleaData(){
      this.form = {
        ID: "",
        activationTime: "",
        enableState: 1,
        address: "",
        age: null,
        aliasName: "",
        company: "",
        dept: "",
        expirationTime: "",
        vehiclePlateNumber:'',
        gender: 1,
        image: "",
        libraryIds: [] as any,
        name: "",
        phone: "",
        replace: 0
      } as any;
      let selectImg =  document.getElementById("selectedImg") as any;
      selectImg.src = "";
      this.showIcon = true
      let file = document.getElementById("img-upload-btn") as any;
      file.value = '';
    }

    //改变人像状态
    updateStates(obj) {
      console.log(obj);
      if (obj == 1){
        this.form.enableState = 2
      } else{
        this.form.enableState = 1
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;

  .warn-wrap{
    width: 100%;
    .el-alert--warning{
      word-break: break-all;
    }
  }
  .warn-wrap>p{
    border-top: solid 1px #8e99aa;
    text-align: center;
    padding: 30px 0;
  }
  .warn-wrap .content{
    width: 100%;
    display: flex;
    justify-content: center;
  }
  .warn-wrap .content .avatar{
    width: 120px;
    height: 160px;
    /*margin-left: 140px;*/
    margin-right: 30px;
    flex-shrink:0;
  }
  .warn-wrap .content .avatar>img{
    width: 100%;
    height: 100%;
  }
  .warn-wrap .content .name{
    width: 240px;
  }
  .warn-wrap .content .name .line{
    width: 100%;
    display: flex;
    padding: 10px 0;
  }
  .warn-wrap .content .name .line2{
    width: 100%;
    display: flex;
    padding: 10px 0;
  }
  .warn-wrap .content .name .left{
    width: 50%;
    font-weight: bolder;
    flex-shrink:0;
  }
  .warn-wrap .content .name .right{
    overflow: auto;
    word-break: break-all;
    text-align: left;
  }

  .active{
    color:#fc3d1a;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  ::v-deep .el-dialog__body{
    //padding: 0 20px 20px !important;
    box-sizing: border-box;
  }
  .wrap{
    width: 100%;
    display: flex;
    border-bottom: solid 1px #b3c1d2;
  }
  .wrap .top{
    width: 120px;
    height: 182px;
    margin: 40px 70px 55px 48px;
    position: relative;
  }
  .wrap .top .tips{
    position: absolute;
    width: 200px;
    font-size: 8px;
    left: -25px;
  }
  .wrap .top ::v-deep .el-form-item__error{
    width: 200px;
  }
  .wrap .detail{
    flex-grow:1;
    height: 100%;
    margin: 32px 0 23px;
  }
  .bottom{
    width: 100%;
  }
  .bottom .bline1{
    width: 100%;
    display: flex;
    justify-content: space-between;
  }
  .pic{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  #img-upload-btn{
    /*opacity: 0;*/
    display: none;
  }
  #selectedImg{
    width: 118px;
    height: 158px;
  }
  .upload{
    width: 120px;
    height: 160px;
    border: 1px dashed #707070;
    border-radius: 3px;
    display: flex;
    justify-content: center;
    align-items: center;
    .el-icon-plus{
      font-size:30px;
    }
  }
  .upload>span{
    width: 68px;
    height: 68px;
    border:1px dashed #707070;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .info{
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    height: 160px;
    justify-content: space-between;
    align-items: center;
  }
  .icon-upload-copy{
    font-size: 40px;
  }
  ::v-deep .el-input__inner{
    width: 90%;
    height: 32px !important;
    font-size: 12px !important;
  }
  .age ::v-deep .el-input__inner{
    padding-right: 0!important;
  }
  .starTime{
    width: 100% !important;
  }
  .starTime ::v-deep .el-input__inner{
    padding: 10px !important;
    text-align: left !important;
  }
  .starTime ::v-deep .el-input__prefix{
    display: none;
  }
  .cancelTime ::v-deep .el-input__inner{
    padding: 10px !important;
    text-align: left !important;
  }
  .cancelTime ::v-deep .el-input__prefix{
    display: none;
  }

  .el-inp{
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    height: 160px;
    justify-content: space-between;
    align-items: center;
  }
  ::v-deep .el-input__suffix{
    right: 28px !important;

  }
  .el-row{
    line-height: 32px;
  }
  .option{
    font-weight: bolder;
    padding-top: 30px;
  }
  .item{
    line-height: 32px;
    margin-top: 10px;
    padding-left: 10px;
  }
  .adrs ::v-deep .el-input__inner{
    width: 94% !important;
  }
  .right{
    text-align: center;
  }
  /*.cancelTime >>> .el-input__inner{*/
  /*width: 100% !important;*/
  /*}*/
  .lang ::v-deep .el-form-item__content{
    width: 94%;
  }
  .top ::v-deep .el-form-item__content{
    margin-left: 0!important;
  }
  .bline1 ::v-deep .el-radio{
    margin-right: 20px;
  }
  ::v-deep .en-address{
    input{
      width: 91%;
    }
  }
</style>
