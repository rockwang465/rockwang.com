<template>
  <div>
    <!--导出人像弹框-->
    <el-dialog
      :class="{hidden:isHide}"
      class="dialog-custom"
      :title="$t('imagemanagement.titleExport')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <div class="outNum">
        <!--导出数量-->
        <span class="num">{{$t('imagemanagement.contQuantity')}}</span>
        <el-input
          @input="inputStartNum"
          v-model="starNum"></el-input>
        <span class="xian">~</span>
        <el-input
          @input="inputEndNum"
          v-model="endNum"></el-input>
      </div>
      <!--提示语-->
      <div style="height: 20px;line-height:20px;color: red;text-align: center;margin-top: 5px;">
        {{tipsWords}}
      </div>
      <span slot="footer" class="dialog-footer">
        <!--确定-->
        <el-button type="primary" :disabled="!(starNum > 0 && endNum > 0)" @click="clickBtn">{{$t('imagemanagement.buttonOK')}}</el-button>
        <!--取消-->
      <el-button class="cancel" type="info" @click="closeSelf">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--导出人像弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {PortraitModule} from '@/store/modules/portrait';
  import {AppModule} from '@/store/modules/app';
  import {Cache} from '@/utils/cache';

  @Component({

  })
  export default class portraitUpFailOut extends Vue {
    get language() {
      return AppModule.language;
    }
    @Prop(Number) libraryId!: any[];
    @Prop(Number) libraryType!: any[];
    @Prop(Number) total!: any[];
    @Prop(Array) time!: any[];
    @Prop(Boolean) dialogVisible!: any[];
    dialogShowVisible = false;
    starNum = null as any;
    endNum = null as any;
    tipsWords = '' as any;
    isHide = false;
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.starNum = '';
      this.endNum = '';
      if (val){
        this.isHide = false;
      }
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closePortraitOut")
      }
    }


    //输入验证
    inputStartNum(val){
      if(this.verifySize(val)){
        this.starNum = val
      }else{
        this.starNum = '';
      }
    }
    //输入验证
    inputEndNum(val){
      if(this.verifySize(val)){
        this.endNum = val
      }else{
        this.endNum = '';
      }

    }
    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([1-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        this.tipsWords="";
        return true;
      }else{
        this.tipsWords= this.$t("records.exportError");
        setTimeout(()=>{
          this.tipsWords=""
        },2000)
        return false;
      }
    }

    clickBtn(){
      let that = this as any;
      if (this.endNum > this.total||this.starNum > this.total){
        // this.tipsWords = '导出区间不能超过上传失败总条数'
        this.tipsWords = that.$t('form.texterrExport3',{number:this.total})
        setTimeout(()=>{
          this.tipsWords = '';
        },2000)
        return;
      }
      //判断开始和结束的数字规范
      if(this.endNum-this.starNum>=1000){
        // this.tipsWords = '请输入规范的数字，每次支持导出1000条'
        this.tipsWords = that.$t('form.texterrExport1')
        setTimeout(()=>{
          this.tipsWords = '';
        },2000)
        return;
      }
      if (this.endNum-this.starNum<0){
        // this.tipsWords = '导出区间不能超过人像库总条数'
        this.tipsWords = that.$t('form.texterrExport2')
        setTimeout(()=>{
          this.tipsWords = '';
        },2000)
        return;
      }


      this.tipsWords = '';
      this.isHide = true;
      this.closeSelf();

      let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
      let userId = user.userId as any;
      let params = {
        featureStatus : 0,
        from: this.starNum,
        to:this.endNum,
        libraryId:this.libraryId?this.libraryId:null,
        libraryType:this.libraryType?this.libraryType:null,
        startTime:this.time?this.time[0]:null,
        endTime:this.time?this.time[1]:null,
        userId:userId,
        sort: "ASC",
        language:this.language == 'en' ? 2 : 1
      } as any;
      PortraitModule.protraitBuildDownloadData(params).then((data:any)=>{
        console.log(data);
        this.$message({
          showClose: true,
          // message: '导出成功',
          message:that.$t('log.exportSuccess'),
          type: 'success'
        });
      }).catch((err) => {

      });
    }
    closeSelf(){
      this.dialogShowVisible = false;
    }

  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .dialog-custom{
    // display:block !important;
    width:100%;
    height:100%;
  }
  .hidden {
    display: block !important;
    position: fixed;
    top: -10%;
    bottom: 110%;
    right: 5%;
    left: 95%;
    width: 0;
    height: 0;
    overflow: hidden;
    transition: all 1s;
    ::v-deep .el-dialog {
      min-width: 30%;
      min-width: 30%;
      height: 30%;
      overflow: hidden;

    }
  }

  $bg: #2d3a4b;
  $light_gray: #eee;
  .content{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  .outNum{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .outNum span{
    margin-right: 10px;
  }
  .outNum .xian{
    margin-left: 10px;
  }
  .outNum ::v-deep .el-input{
    width: 25%;
  }
  .el-list ::v-deep .el-input__suffix{
    right: 10px !important;
    top: 3px !important;
  }
  .right-name ::v-deep .el-input{
    width: 75%;
  }
  .upFile{
    color: #2a5af5;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  ::v-deep .el-input__inner{
    height: 32px !important;
  }

  //批量的number样式
  .outNum ::v-deep  input::-webkit-outer-spin-button,
  .outNum ::v-deep  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }
  .outNum ::v-deep  input[type="number"]{
    -moz-appearance: textfield;
  }

</style>
