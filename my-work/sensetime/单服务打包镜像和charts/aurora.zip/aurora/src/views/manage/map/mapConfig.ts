import L from 'leaflet';

var drawSetting = {
	// format: {
	// 	numeric: {
	// 		delimiters: {
	// 			thousands: ',',
	// 			decimal: '.'
	// 		}
	// 	}
	// },
	draw: {
		toolbar: {
			// this should be reorganized where actions are nested in actions
			// ex: actions.undo  or actions.cancel
			actions: {
				title: 'Cancel drawing',
				text: '取消'
			},
			finish: {
				title: 'Finish drawing',
				text: '完成'
			},
			undo: {
				title: 'Delete last point drawn',
				text: '回退'
			},
			buttons: {
				polyline: 'Draw a polyline',
				polygon: 'Draw a polygon',
				rectangle: 'Draw a rectangle',
				circle: 'Draw a circle',
				marker: 'Draw a marker',
				circlemarker: 'Draw a circlemarker'
			}
		},
		handlers: {
			circle: {
				tooltip: {
					start: 'Click and drag to draw circle.'
				},
				radius: 'Radius'
			},
			circlemarker: {
				tooltip: {
					start: 'Click map to place circle marker.'
				}
			},
			marker: {
				tooltip: {
					start: 'Click map to place marker.'
				}
			},
			polygon: {
				tooltip: {
					start: '点击开始绘制',
					cont: 'Click to continue drawing shape.',
					end: 'Click first point to close this shape.'
				}
			},
			polyline: {
				error: '<strong>Error:</strong> shape edges cannot cross!',
				tooltip: {
					start: 'Click to start drawing line.',
					cont: 'Click to continue drawing line.',
					end: 'Click last point to finish line.'
				}
			},
			rectangle: {
				tooltip: {
					start: 'Click and drag to draw rectangle.'
				}
			},
			simpleshape: {
				tooltip: {
					end: 'Release mouse to finish drawing.'
				}
			}
		}
	},
	edit: {
		toolbar: {
			actions: {
				save: {
					title: 'Save changes',
					text: '保存'
				},
				cancel: {
					title: 'Cancel editing, discards all changes',
					text: '取消'
				},
				clearAll: {
					title: 'Clear all layers',
					text: '清除所有'
				}
			},
			buttons: {
				edit: 'Edit layers',
				editDisabled: 'No layers to edit',
				remove: 'Delete layers',
				removeDisabled: 'No layers to delete'
			}
		},
		handlers: {
			edit: {
				tooltip: {
					text: 'Drag handles or markers to edit features.',
					subtext: 'Click cancel to undo changes.'
				}
			},
			remove: {
				tooltip: {
					text: 'Click on a feature to remove.'
				}
			}
		}
	}
};

let markerIcon = {
  default:L.icon({
    iconUrl: '/images/marker-icon.png',
    iconSize: [16, 26],
    iconAnchor: [8, 24],
    popupAnchor: [-2, -28]
  }),
  offLine:L.icon({
    iconUrl: '/images/marker-icon-offline.png',
    iconSize: [16, 26],
    iconAnchor: [8, 24],
    popupAnchor: [-2, -28]
  }),
  warning : L.icon({
    iconUrl: '/images/marker-icon-warning.png',
    iconSize: [25, 41],
    iconAnchor: [12, 39],
    popupAnchor: [-2, -28]
  }),
  editing : L.icon({
    iconUrl: '/images/icon-camera.png',
    iconSize: [17, 28],
    iconAnchor: [9, 28],
    popupAnchor: [-2, -28]
  })

}
let deviceList:any   = [
  { name: '餐厅',id:1,isShow:false, icon:markerIcon.default, lng: 675.2, lat: 345.0 },
  { name: '走廊',id:671,isShow:false, icon:markerIcon.default, lng: 741.6, lat: 430.1 },
  { name: '大门',id:3,isShow:false, icon:markerIcon.offLine, lng: 383.4, lat: 156.5 },
  { name: '电梯',id:769,isShow:false, icon:markerIcon.warning, lng: 568.7, lat: 220.3 }
];

let drawPoint = new L.DivIcon({
  iconSize: new L.Point(14, 14)
});
let localDeviceList = [
  {
    "deviceId":671,
    "peopleNumber":5,
    "point":[675,345]
  },
  {
    "deviceId":672,
    "peopleNumber":70,
    "point":[568.7,220.3]
  },
  {
    "deviceId":673,
    "peopleNumber":17,
    "point":[383.4,156.5]
  },
  {
    "deviceId":674,
    "peopleNumber":27,
    "point":[741.6,430.1]
  },
  {
    "deviceId":675,
    "peopleNumber":137,
    "point":[941.6,330.1]
  }
];

let mapBase = {
  crs     : L.CRS.Simple,
  bounds  : [[0,0], [1080, 1920]],
  center  : [540,800],
  zoom    : -1,
  minZoom : -2,
  maxZoom : 1,
}

let mapBaseOptions = {
  attributionControl: false,
  zoomSnap: false,
  drawControl: false,
  zoomControl: false,
  zoomsliderControl: true,
};

//export default{};
export{ drawSetting , markerIcon, drawPoint, localDeviceList, mapBase, mapBaseOptions }
