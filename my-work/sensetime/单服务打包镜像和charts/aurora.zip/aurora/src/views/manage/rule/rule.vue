<template>
  <div class="rule-container">
    <RuleNav @ruleModel='handleRuleModelChange' />
    <div class="rule-contents" >
      <transition name="component-fade" mode="out-in">
        <RuleAC v-if="ruleModel === 'ac'" />
        <RuleTD v-else />
      </transition>
    </div>

  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import {RuleNav,RuleAC,RuleTD} from './subview';

@Component({
  components: {
    RuleNav,
    RuleAC,
    RuleTD,
  },
})
export default class Rule extends Vue {
  /* props */

  /* watch */
  
  /* data */
  ruleModel:string=location.hash.indexOf('#rulestd')>=0?'td':'ac';


  testModel='';
  /* methods */
  handleRuleModelChange(ruleModel){
    this.ruleModel = ruleModel;
    if(ruleModel === 'td'){
      this.$router.push(`/manage/rule#rulestd`);
    }else{
      this.$router.push(`/manage/rule`);
    }
  }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .rule-container{
    background-color: $--color-bg-1;
    font-size: $--font-size-base;
    width: 100%;
    height: 100%;
    .rule-contents{
      background-color:$--background-color-module;
      height: calc(100% - 70px);
      padding: 16px;
      .component-fade-enter-active, .component-fade-leave-active {
        transition: opacity .3s ease;
      }
      .component-fade-enter, .component-fade-leave-to{
        opacity: 0;
      }
    }
  }
</style>
