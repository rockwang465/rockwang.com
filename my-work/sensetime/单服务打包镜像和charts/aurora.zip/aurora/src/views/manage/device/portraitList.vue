<template>
    <div>
      <el-dialog :title="$t('devicemanagement.synchronizationPerson')" :visible="dialogVisible" :before-close="hide" >
        <div class="portraitList-header" >
          <el-button type="primary" icon="iconfont icon-upload" @click="exportClick" > {{$t('devicemanagement.exportFailsynchronizationPerson')}}</el-button>
          <div>
            <span>{{$t('devicemanagement.contAsyncSuccess')}} {{ numberSuccessful}}</span>|
            <span style="color:rgba(237, 58, 51, 1);text-decoration:underline;" >{{$t('devicemanagement.contAsyncFail')}}{{numberFailure}}</span>
          </div>
          <div>
            <el-input
              :placeholder="$t('devicemanagement.labelName')/'ID'"
              v-model="inputSearchValue"
              @keydown.native="keydown"
              @clear="clearSearchVal">
              <span slot="suffix" >
                <i
                  style="cursor:pointer;"
                  v-if="inputSearchValue"
                  class="el-icon-circle-close"
                  @click="()=>{inputSearchValue = '' ,clearSearchVal()}"></i>
                <i
                style="cursor:pointer;"
                class="el-input__icon el-icon-search"
                @click="()=>inputKeywordChange()"></i>
              </span>
            </el-input>
          </div>
        </div>
        <div class="portraitList-content">
          <div style="width:calc(30% - 8px);margin-right:8px;" >
            <div class="portraitList-content-treeheader">
              {{$t('devicemanagement.labelLibraryGroup')}}
            </div>
            <div style="height:calc(100% - 60px);overflow-y: auto;">
              <el-tree
              :data="treeData"
              node-key="id"
              :render-content="renderTreeContent"
              @current-change="treeNodeClick"
              ref="tree" ></el-tree>
            </div>

          </div>
          <div style="width:70%;">
            <el-table
            v-loading="loading"
              stripe
              header-row-class-name="portraitList-table-header"
              height="450"
              :data="tableData">
              <el-table-column
                prop="img"
                :label="$t('devicemanagement.labelImage')">
                <template slot-scope="scope">
                  <img height="80px" width="60px" :src="processImgurl(scope.row.img)" alt="">
                </template>
              </el-table-column>
              <el-table-column
                prop="name"
                :label="$t('devicemanagement.labelName')">
              </el-table-column>
              <el-table-column
                prop="id"
                label="ID">
              </el-table-column>
              <el-table-column
                prop="state"
                :label="$t('devicemanagement.labelAsyncStatus')">
                <template slot-scope="scope">
                  {{getTextState(scope.row.state)}}
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              layout="total,prev, pager, next"
              :page-size="pageSize"
              :current-page="currentPage"
              @current-change="handleCurrentPageChange"
              :total="total">
            </el-pagination>
          </div>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button class="cancel" type="primary" @click="hide">{{$t('devicemanagement.buttonOK')}}</el-button>
          <el-button class="cancel" type="info" @click="hide">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </div>
      </el-dialog>
      <!-- messageBox export -->
      <el-dialog
      :append-to-body="true"
      :visible="showExportDialog"
      :before-close="()=>this.showExportDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{$t('devicemanagement.contExportAll')}}</p>
      <div slot="title" >
          <span>{{$t('rolemanagement.titleReminder')}}</span>
      </div>
      <span slot="footer">
          <el-button type="primary" @click="exportPelple" :loading="exportDialogLoading">{{$t('devicemanagement.buttonOK')}}</el-button>
          <el-button @click="showExportDialog = false" type="info">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </span>
      </el-dialog>
    </div>
</template>

<script lang="tsx">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import api from "@/api/device";
  import {processImgurl} from '@/utils/image.ts';
  import {Cache} from '@/utils/cache';

  @Component({})

  export default class PortraitList extends Vue {
     /* props */
    @Prop({default:false}) dialogVisible!: boolean;
    @Prop({required:false}) deviceObj!: any;

    /* watch */
    @Watch('dialogVisible',{ immediate: true})
    onVisibleChange(n,o){
        n && this.initData();
    }
    /* data */
    $refs!:{
      tree:HTMLFormElement,
    };
    inputSearchValue:string='';
    treeData:any[]=[];
    tableData:any[]=[];
    deviceId:number=0;
    currentLibraryIds:number[]=[];

    total:number=0;
    pageSize:number=10;
    currentPage:number=1;
    numberFailure:number=0;
    numberSuccessful:number=0;
    processImgurl:any=processImgurl;
    loading:boolean=false;

    showExportDialog:boolean=false;
    exportDialogLoading:boolean=false;
    /* methods */
    mounted(){

    }
    initData(){
      this.inputSearchValue='';
      this.treeData=[];
      this.tableData=[];
      this.numberFailure = 0;
      this.numberSuccessful = 0;
      this.deviceId = this.deviceObj.deviceId;
      this.loading = false;
      this.showExportDialog = false;
      this.exportDialogLoading = false;
      this.getLibraryList();
    }
    getTextState(state){
      //1-同步中 2-同步失败 3-同步成功
      switch (state) {
        case 1:

          return this.$t("devicemanagement.contAsyncStatus1");
        case 2:

          return this.$t("devicemanagement.contAsyncFail");;
        case 3:

          return this.$t("devicemanagement.contAsyncSuccess");;

        default:
          return state;
      };
    }
    hide(){
      this.$emit("closeProtraitList")
    }
    clearSearchVal(){
      this.inputKeywordChange();
    }
    handleCurrentPageChange(page){
      this.currentPage = page;
      page && this.getPeopleList();
    }
    getLibraryList(){
      api.getDeviceSyncLibraryList(this.deviceId).then((res:any)=>{
        res && this.formatLibs(res)
      })
    }
    getPeopleList(){
      this.numberFailure = 0;
      this.numberSuccessful = 0;
      this.tableData = [];
      this.loading = true;
      api.getDeviceSyncPeopleList(this.deviceId,{
        "keyWord": this.inputSearchValue,
        "libraryIds": this.currentLibraryIds,
        "page": this.currentPage,
        "size": this.pageSize
      }).then((res:any)=>{
        this.total = res.total||0;
        res && res.listAsSynchronizationVoList && this.formatPeopleList(res.listAsSynchronizationVoList);
        this.numberFailure = res.numberFailure;
        this.numberSuccessful = res.numberSuccessful;
      }).finally(()=>{
        this.loading = false;
      })
    }
    getAllLibraryIds(){
      return this.treeData[0].children.map(item=>item.id).concat(this.treeData[1].children.map(item=>item.id));
    }
    formatLibs(res){
      this.treeData = [{id:-1,label:this.$tc('rule.contWhitelist'),isLeaf:false,children:[]},{id:-2,label:this.$tc('rule.contBlacklist'),isLeaf:false,children:[]}];
      res.whitelists && res.whitelists.map((item:any)=>{
        this.treeData[0].children.push({
          id:item.libraryId,
          label:item.libraryName
        })
      });
      res.blacklists && res.blacklists.map((item:any)=>{
        this.treeData[1].children.push({
          id:item.libraryId,
          label:item.libraryName
        })
      });
    }
    formatPeopleList(listAsSynchronizationVoList){
      this.tableData = [];
      listAsSynchronizationVoList.map(item=>{
        this.tableData.push(item)
      })

    }
    treeNodeClick(data,node){
      this.inputSearchValue = '';
      data.id && this.$refs.tree.setCurrentKey(data.id>0?data.id:null);//UI
      if(data.id && data.id>0){//library
        this.currentLibraryIds = [data.id];
      }else if(data.id<0){//library group
        let get_ids = this.treeData[-data.id - 1].children.map(item=>item.id);
        this.currentLibraryIds = get_ids.length>0?get_ids:[0];//[0]->防止[]返回所有数据
      }
      this.currentPage = 1;
      data.id && this.getPeopleList();
    }
    keydown(e){
        e.keyCode == '13' && this.inputKeywordChange();
    }
    inputKeywordChange(){
      this.$refs.tree.setCurrentKey(null);
      let ids = this.getAllLibraryIds();
      this.currentLibraryIds = ids;
      this.currentPage = 1;
      this.getPeopleList();
    }
    renderTreeContent(h, { node, data, store }){
      return <span title={data.label} style="white-space: nowrap;text-overflow: ellipsis;overflow: hidden;">{data.label}</span>
    }
    exportClick(){
      this.showExportDialog = true;
    }
    exportPelple(){
      const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
      this.exportDialogLoading = true;
      api.exportMFailPeople({"deviceId": this.deviceId,"userId": userInfo.userId}).then(s=>{
        this.$message.success(this.$tc('log.exportSuccess'))
      }).finally(()=>{
        this.exportDialogLoading = false;
        this.showExportDialog = false;
      })
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.portraitList-header{
  display: flex;
  flex-wrap: nowrap;
  justify-content:space-between;
  align-items:center;
  width: 100%;
}
.portraitList-content{
  width: 100%;
  padding-top: 24px;
  display: flex;
  flex-wrap: nowrap;
  .portraitList-content-treeheader{
    background-color: rgba(180, 189, 208, 1);
    color: rgba(40, 53, 77, 1);
    font-size: 14px;
    padding: 7px 0px 5px 18px;
    font-weight: 800;
  }
  ::v-deep .el-table .portraitList-table-header th.is-leaf{
    background-color: rgba(180, 189, 208, 1);
    font-size: 14px;
    color: rgba(40, 53, 77, 1);
    font-weight: 800;
    padding-top: 2px;
    padding-bottom: 3px;
  }
  ::v-deep .el-tree-node.is-current .el-tree-node__content{
    background-color: #6d7c96
  }

}
</style>
