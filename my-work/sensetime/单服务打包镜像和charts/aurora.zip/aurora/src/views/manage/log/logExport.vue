<template>

  <div >
    <!--导出日志弹框-->
    <el-dialog
      :class="{hidden:isHidden}"
      class="dialog-custom"
      :title="$t('log.buttonExport')"
      :visible.sync="dialogShowVisible"
      width="584px">

      <div class="outNum">
        <span class="num">{{$t('log.contQuantity')}}</span><!--导出数量-->
        <el-input v-model="numStart"
                  onkeyup="this.value=this.value.replace(/^(0+)|[^\d]+/g,'')"></el-input>
        <span class="xian">~</span>
        <el-input v-model="numEnd" onkeyup="this.value=this.value.replace(/^(0+)|[^\d]+/g,'')"></el-input>
      </div>
      <br>
      <div v-if="errorConfirmFlag">
        <br>
        <span class="error-confirm">{{errorConfirm}}</span>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="loading" @click="exportAction" :disabled="confirmButtonFlag">{{$t('log.buttonOK')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('log.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--导出人像弹框-->
  </div>

</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {LogModule} from '@/store/modules/log';
  import {Cache} from '@/utils/cache';
  import {isEmpty} from '@/utils/validate';

  @Component({
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    }
  })
  export default class portraitOut extends Vue {
    confirmButtonFlag = true;
    errorConfirmFlag = false;
    errorConfirm = "";
    dialogShowVisible = false;
    numStart = '' as any;
    numEnd = '' as any;
    isHidden:boolean=false;
    loading:boolean=false;
    @Prop(Object) query!: any[];
    @Prop(Number) total!: any[];


    exportAction() {
      let that = this as any;
      let params = that.query;
      this.loading = true;
      // setTimeout(()=>{
      //   this.loading=false;
      // },1100)
      that.numStart = Number(that.numStart);
      that.numEnd = Number(that.numEnd);
      that.total = Number(that.total);
      if (isEmpty(that.numStart) || isEmpty(that.numEnd)) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('log.exportError1');
        that.clearError();
        this.loading=false;
        return
      }
      if (that.numStart <= 0 || that.numEnd <= 0 || that.numStart > that.numEnd) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('rolemanagement.exportError2');
        that.clearError();
        this.loading=false;
        return
      }
      if (that.numEnd > that.total) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('log.exportError3', {number: that.total});
        that.clearError();
        this.loading=false;
        return
      }
      if ((that.numEnd - that.numStart) >= 10000) {
        that.errorConfirmFlag = true;
        that.errorConfirm = that.$t('log.exportError4', {number: that.total});
        that.clearError();
        this.loading=false;
        return
      }
      params.from = that.numStart;
      params.to = that.numEnd;
      let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
      params.userId = user.userId;

      LogModule.ExportLog(that.query).then((data: any) => {
        that.$message({
          showClose: true,
          message: that.$t('log.exportSuccess'),
          type: 'success'
        })
        that.isHidden=true;
        setTimeout(()=>{
          that.isHidden=false;
        },1100)
        that.dialogShowVisible = false


      }).catch((err) => {
        console.log(err)
      }).finally(() =>{
        that.loading = false;
      })


    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      this.errorConfirmFlag = false;
      this.numStart = '';
      this.numEnd = '';
      if (!val) {
        this.$emit("closePortraitOut")
      }
    }

    @Watch('numStart')
    onDialogStartNumChange(val: any) {
      if (val < 1) {
        this.numStart = "";
      }
      if (!isEmpty(this.numStart) && !isEmpty(this.numEnd)) {
        this.confirmButtonFlag = false;
      } else {
        this.confirmButtonFlag = true;
      }
    }

    @Watch('numEnd')
    onDialogEndNumChange(val: any) {
      if (val < 1) {
        this.numEnd = "";
      }
      if (!isEmpty(this.numStart) && !isEmpty(this.numEnd)) {
        this.confirmButtonFlag = false;
      } else {
        this.confirmButtonFlag = true;
      }
    }
    clearError(){
      setTimeout(()=>{
        this.errorConfirmFlag = false;
        this.errorConfirm = "";
      },2000)
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  .content {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }

  .content > div {
    width: 45%;
  }

  .content > div span {
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }

  .outNum {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .outNum span {
    margin-right: 10px;
  }

  .outNum .xian {
    margin-left: 10px;
  }

  .outNum ::v-deep .el-input {
    width: 25%;
  }

  .el-list ::v-deep .el-input__suffix {
    right: 10px !important;
    top: 3px !important;
  }

  .right-name ::v-deep .el-input {
    width: 75%;
  }

  .upFile {
    color: #2a5af5;
  }

  ::v-deep .el-dialog__footer {
    text-align: center !important;
  }

  ::v-deep .el-input__inner {
    height: 32px !important;
  }
  .error-confirm {
    color: red;
  }


  .dialog-custom{
    // display:block !important;
    width:100%;
    height:100%;
  }
  .hidden {
    display: block !important;
    position: fixed;
    top: -10%;
    bottom: 110%;
    right: 5%;
    left: 95%;
    width: 0;
    height: 0;
    overflow: hidden;
    transition: all 1s;
    ::v-deep .el-dialog {
      min-width: 30%;
      min-width: 30%;
      height: 30%;
      overflow: hidden;

    }
  }
</style>
