<template>
  <el-container style="height: calc(100% - 16px);padding:0 8px;">
    <el-main style="overflow: hidden">
      <el-row class="row-bg" style="height: 62px;">
        <el-button type="primary" icon="el-icon-upload2" @click="LogExportShowFlag=true"
                   v-if="$permission('003305')">
          {{$t('log.buttonExport')}}
        </el-button><!--导出-->
      </el-row>
      <el-row>
        <el-col :span="20">
          <!--时段检索-->
          {{$t('log.contTimeFilter')}}：
          <el-date-picker
            v-model="dateArray"
            type="daterange"
            size="small"
            range-separator="-"
            value-format="yyyy-MM-dd"
            :start-placeholder="$t('visitor.visitorlist.labelStartTime')"
            :end-placeholder="$t('visitor.visitorlist.labelEndTime')">
            <!--点击设置时间段-->
          </el-date-picker>
        </el-col>
        <el-col :span="4">
          <!-- <el-input
            :placeholder="$t('log.searchPlaceHolder')"
            class="inp-search"
            size="small"
            v-model="query.username">
            <span class="suffix-icon" slot="suffix">
              <Icon
                v-if="showSearchClose"
                type="ele"
                cursor="pointer"
                name="circle-close"
                @click="clickClearKeywords"
              />
              <Icon
                type="ele"
                cursor="pointer"
                name="search"
                @click="onDialogUsernameChange"
              />
            </span>
          </el-input> -->
        </el-col>
      </el-row>
      <br>
      <el-row class="addShadow" style="height: calc(100% - 120px);background-color: #ffffff">
        <el-col :span="24" style="height: calc(100% - 10px);">
          <el-table
            stripe
            ref="logTable"
            @filter-change="tableFilterChange"
            v-loading="loading"
            :data="tableData"
            style="width: 100%;height: calc(100% - 44px)"
            @sort-change="sortChange1">
            <!--间隔-->
            <!-- <el-table-column
              prop=""
              label=" "
              min-width="30">
            </el-table-column> -->
            <el-table-column
              :label="$t('log.labelModule')"
              align="left"
              prop="moduleName"
              width="200"
              column-key="moduleName"
              :filter-multiple="false"
              :filters="moduleCondition"
            >
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--操作-->
            <el-table-column
              align="left"
              prop="operateType"
              :label="$t('log.labelOperation')"
              width="150"
              column-key="operateType"
              :filter-multiple="false"
              :filters="actionCondition"
            >
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              min-width="20">
            </el-table-column>
            <!--详情-->
            <el-table-column
              align="left"
              prop="operateFunction"
              :label="$t('log.labelDetail')"
              width="500">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--用户-->
            <el-table-column
              align="left"
              prop="username"
              :label="$t('log.labelUser')"
              width="120">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              align="left"
              prop="orgName"
              width="120"
              :label="$t('log.labelUserGroup')">
              <template slot="header" slot-scope="scope">
                <el-popover
                  placement="bottom"
                  width="160"
                  trigger="click"
                  v-model="userGroupFilterVisible">
                  <el-tree ref="tree"
                           style="max-height: 200px;overflow: auto"
                           :data="groupTree"
                           :props="defaultProps"
                           node-key="id"
                           @check="groupTreeCheck"
                           show-checkbox
                  />
                  <div class="div-footer">
                    <el-button type="text" :disabled="checkedKeys.length == 0" @click="handleCommandGroup">{{$t('rule.contSearch')}}</el-button>
                    <el-button type="text" @click="resetUserGroupSearchData">{{$t('rule.contReset')}}</el-button>
                  </div>
                  <span slot="reference" >
                <span>{{$t('log.labelUserGroup')}}</span>
                <i v-show="!userGroupFilterVisible" class="el-icon-arrow-down rule-list-td-popover-icon" ></i>
                <i v-show="userGroupFilterVisible" class="el-icon-arrow-up rule-list-td-popover-icon" ></i>
              </span>
                </el-popover>
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--时间-->
            <el-table-column
              align="left"
              prop="operateTime"
              min-width="154"
              :label="$t('log.labelTime')"
              sortable="custom"
            >
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              min-width="30">
            </el-table-column>
          </el-table>
          <el-pagination class="page" @size-change="handleSizeChange" @current-change="handleCurrentChange"
                       :current-page="query.page"
                       :page-sizes="[13, 26, 39, 52,65]" :page-size="query.size"
                       layout="total, sizes, prev, pager, next, jumper" :total="total">
          </el-pagination>
        </el-col>
      </el-row>

    </el-main>

    <!--<div class="org-tree-class" id="org-tree-class">-->
      <!--<el-tree ref="tree"-->
               <!--:data="groupTree"-->
               <!--:props="defaultProps"-->
               <!--node-key="id"-->
               <!--@check="groupTreeCheck"-->
               <!--show-checkbox-->
      <!--/>-->
      <!--<div class="div-footer">-->
        <!--<el-button type="text" :disabled="checkedKeys.length == 0" @click="handleCommandGroup">{{$t('rule.contSearch')}}</el-button>-->
        <!--<el-button type="text" @click="resetUserGroupSearchData">{{$t('rule.contReset')}}</el-button>-->
      <!--</div>-->
    <!--</div>-->
    <LogExport :dialogVisible="LogExportShowFlag" :total="total" @closePortraitOut="closeLogExport"
               :query="query"></LogExport>
  </el-container>
</template>

<script lang="ts">
  import {Component, Vue, Watch} from 'vue-property-decorator';
  import LogExport from './logExport.vue';
  import {isEmpty} from '@/utils/validate';
  import {LogModule} from '@/store/modules/log';
  import {UserModule} from '@/store/modules/user';
  import {AppModule} from '@/store/modules/app';
  import Icon from '@/components/icon-wrap/index.vue';
  import {Table as ElTable} from "element-ui/types/element-ui";

  @Component({
    components: {
      LogExport,
      Icon
    },
  })
  export default class Log extends Vue {
    LogExportShowFlag = false;
    checkedKeys:any=[];

    get language() {
      return AppModule.language;
    }

    loading = false;
    dateArray = '';
    tableData = [];
    total = 0;
    query = {
      page: 1,
      number: 13,
      moduleName: "",
      operateType: "",
      startTime: "",
      endTime: "",
      sort: 1,
      username: "",
      language: ''
    } as any;
    orgIds = "";
    groupTree = [];
    defaultProps = {
      children: 'children',
      label: 'name',
    };
    showSearchClose = false;
    userGroupFilterVisible = false;

    created() {
      let that = this as any;
      this.query.language = this.language == 'en' ? 2 : 1
      this.searchData();
      this.searchCondition();
      this.searchUserOrgGroup();
      // document.onkeydown = function (event) {
      //   let e = event || window.event || arguments.callee.caller.arguments[0];
      //   //回车键检索
      //   if (e && e.key == 'Enter') {
      //     that.onDialogUsernameChange();
      //   }
      // };
    }

    @Watch('language')
    onDialogLanguageChange(val: any) {
      this.query.language = this.language == 'en' ? 2 : 1
      this.searchData();
      this.searchCondition();
    }
    groupTreeCheck(){
      let ids = (this.$refs.tree as any).getCheckedKeys();
      this.checkedKeys = ids
    }

    //获取日志list
    searchData() {
      let that = this as any;
      that.loading = true;
      let param = {
        query: that.query,
        orgIds: that.orgIds
      }
      LogModule.GetLogList(param).then((data: any) => {
        that.loading = false;
        that.total = data.total;
        that.tableData = data.list;
      }).catch((err) => {
        that.loading = false;
        console.log(err)
      });
    }

    //获取角色list
    searchUserOrgGroup() {
      let that = this as any;
      UserModule.GetUserGroup({}).then((data: any) => {
        this.groupTree = data.data
      }).catch((err) => {
        console.log(err)
      });
    }

    moduleCondition = [];
    actionCondition = [];
    allActionCondition = [];

    //获取日志检索条件
    searchCondition() {
      let that = this as any;
      that.moduleCondition = [];
      that.actionCondition = [];
      that.allActionCondition = [];
      LogModule.GetLogSearchCondition({
        language: that.language == 'en' ? 2 : 1
      }).then((data: any) => {
        let list = data.list as any;
        for (let i = 0; i < list.length; i++) {
          let param = {
            text: list[i].moduleName,
            value: list[i].moduleName,
          } as any;
          let array = [] as any;
          for (let j = 0; j < list[i].operatList.length; j++) {
            let param2 = {
              text: list[i].operatList[j],
              value: list[i].operatList[j],
            }
            array.push(param2);
          }
          param.operatList = array;
          that.moduleCondition.push(param);
          console.log(that.moduleCondition)
        }
        let operateList = data.operateList as any;
        for (let i = 0; i < operateList.length; i++) {
          let param1 = {
            text: operateList[i],
            value: operateList[i],
          }
          that.allActionCondition.push(param1);
          that.actionCondition.push(param1);
        }
      }).catch((err) => {
        console.log(err)
      });
    }

    handleSizeChange(val) {
      this.query.page = 1;
      this.query.number = val;
      this.searchData();
    }

    handleCurrentChange(val) {
      this.query.page = val;
      this.searchData();
    }


    sortChange1(obj) {
      this.query.page = 1;
      this.query.sort = obj.order == "descending" ? 1 : 0;
      this.searchData();
    }

    closeLogExport() {
      this.LogExportShowFlag = false;
    }

    renderUserGroup(h, {node, data, store}) {
      let that = this as any;
      return h("span", {
        style: {
          cursor: "pointer",
          color: this.orgIds?'#2a5af5':'#99a5b9'
        },
        on: {
          click: this.showHandleCommandGroup
        }
      }, [that.$t('log.labelUserGroup'),  //用户分组
        h("i", {
          attrs: {
            class: "el-icon-arrow-down el-icon--right"
          },
          className: "el-icon-arrow-down el-icon--right"
        })
      ])
    }

    showHandleCommandGroup(e: any) {
      // console.log(e);
      // let menu = document.getElementById("org-tree-class") as any;
      // menu.style.left = e.clientX - 150 + 'px';
      // menu.style.top = e.clientY - 50 + 'px';
      // menu.style.width = '220px';
      // menu.style.display = 'block';
      this.userGroupFilterVisible = true;
      console.log(this.userGroupFilterVisible);
    }

    cancelHandleCommandGroup() {
      // let menu = document.getElementById('org-tree-class') as any
      // menu.style.display = 'none';
      this.userGroupFilterVisible = false;
    }
    resetUserGroupSearchData(){
      this.orgIds='';
      this.checkedKeys=[];
      (this.$refs.tree as any).setCheckedKeys([]);
      this.searchData();
      this.cancelHandleCommandGroup();
    }
    handleCommandGroup() {
      let ids = (this.$refs.tree as any).getCheckedKeys();
      this.query.page = 1;
      let str = "";
      for (let i = 0; i < ids.length; i++) {
        if (i == 0) {
          str += ids[i];
        } else {
          str += "&orgIds=" + ids[i];
        }
      }
      this.orgIds = str;
      this.searchData();
      this.cancelHandleCommandGroup();
    }

    @Watch('dateArray')
    onDialogStartTimeChange(val: any) {
      if (isEmpty(val) || val.length == 0) {
        this.query.startTime = '';
        this.query.endTime = '';
      } else {
        this.query.startTime = val[0] + ' 00:00:00';
        this.query.endTime = val[1] + ' 23:59:59';
      }
      this.query.page = 1;
      this.searchData();
    }

    @Watch('query.username')
    onQueryUsernameChange(val: any) {
      if (!isEmpty(val)) {
        this.showSearchClose = true
      } else {
        this.showSearchClose = false
        this.query.page = 1
        this.searchData()
      }
    }

    onDialogUsernameChange() {
      this.query.page = 1
      this.searchData()
    }

    clickClearKeywords() {
      this.query.username = '';
      this.showSearchClose = false
      this.query.page = 1
      this.searchData()
    }

    tableFilterChange(filter) {
      let that = this as any;
      that.query.page = 1;
      that.query.operateType = '';//选中项会和实际结果不符
      if (filter.moduleName) {
        //修改模块的时候，操作会随着模块而改变
        let data = this.moduleCondition as any;
        if (isEmpty(filter.moduleName[0])) {
          this.actionCondition = this.allActionCondition
        } else {
          for (let i = 0; i < data.length; i++) {
            if (data[i].value == filter.moduleName[0]) {
              this.actionCondition = data[i].operatList;
              break;
            }
          }
        }
        (this.$refs.logTable as any).clearFilter('operateType');
        that.query.moduleName = isEmpty(filter.moduleName[0]) ? "" : filter.moduleName[0];
      }
      if (filter.operateType) {
        that.query.operateType = isEmpty(filter.operateType[0]) ? "" : filter.operateType[0];
      }
      that.searchData();
    }

  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .wrap {
    padding: 0 15px;
  }

  .row-bg {
    padding: 15px 0;
  }

  .div-footer {
    // text-align: center;
    // padding: 10px 0;
  }

  .org-tree-class {
    width: 220px;
    max-height: 250px;
    overflow: auto;
    position: absolute;
    left: 1000px;
    top: 200px;
    background-color: rgb(255, 255, 255);
    border: 1px solid #e0e4ee;
    border-radius: 2px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    padding: 10px;
    /*display: none;*/
    .div-footer{
      border-top: 1px solid #ccc;
      button.el-button--text {
        color:#28354d;
        &:hover{
          color:#2a5af5;
        }
      }
      button.el-button--text.is-disabled {
        color:#c0c4cc;
      }
    }

  }

  ::v-deep .el-table__body-wrapper {
    max-height: calc(100% - 65px);
    overflow-y: auto;
  }

  ::v-deep .el-table__column-filter-trigger {
    margin-left: 10px;
    i {
      color: black;
      font-size: 16px;
    }
  }
  ::v-deep .rule-list-td-popover-icon{
    cursor: pointer;
    font-size: 12px;
    color: #28354d;
    margin-left: 10px;
  }
  .addShadow{
    @include shadowBox();
  }

</style>
