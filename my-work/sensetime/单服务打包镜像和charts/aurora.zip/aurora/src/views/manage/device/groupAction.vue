<template>
  <div v-if="dialogShowVisible">
    <el-dialog
      :title="dataObj.title"
      :visible.sync="dialogShowVisible"
      width="584px">
      <div class="content">
        <div class="div-class-edit"
             v-if="dataObj.type == 'edit' || dataObj.type == 'addLevel' || dataObj.type == 'addNext'">
          <el-form
            :rules="rules"
            ref="dataForm" :model="form" @submit.native.prevent>
            <el-form-item :label="$t('devicemanagement.contGroupName')" :label-width="formLabelWidth" prop="valueData">
              <el-input @input="inputName" v-model="form.valueData" class="el-input" maxLength="40"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div class="div-class-detail" v-if="dataObj.type == 'detail'">
          <div>
            <div class="div-left-detail">{{$t('devicemanagement.contGroupName')}}</div>
            <div class="div-right-detail">{{dataObj.localData.name}}</div>
          </div><!--分组名称-->
          <div>
            <div class="div-left-detail">{{$t('devicemanagement.contTimeCreation')}}</div>
            <div class="div-right-detail">{{dataObj.localData.createTime}}</div>
          </div>
          <!--创建时间-->
          <div>
            <div class="div-left-detail">{{$t('devicemanagement.contCreator')}}</div>
            <div class="div-right-detail">{{dataObj.localData.createUserName}}</div>
          </div><!--创建者-->
        </div>
        <div class="div-class-delete" v-if="dataObj.type == 'delete'">
          {{$t('devicemanagement.popmsgGroupDelete')}}
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button v-if="dataObj.type == 'delete'" type="danger" @click="handleGroupAction">{{$t('devicemanagement.buttonDelete')}}</el-button>
        <el-button v-if="dataObj.type != 'delete'" type="primary" @click="handleGroupAction">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {AppModule} from '@/store/modules/app';

  let vm = null as any
  const requiredGroupName = (rule, value = '', callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateDeviceGroupName')))
    } else {
      callback()
    }
  }
  @Component({
    computed: {
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '140px' : '120px';
      }
    },
  })
  export default class groupAction extends Vue {
    rules = {
      valueData: [{required: true, trigger: 'blur', validator: requiredGroupName}],
    };

    get language() {
      return AppModule.language;
    }

    //编辑的表单里的值
    dialogShowVisible = false;
    form = {
      valueData: ''
    } as any;
    @Prop(Object) dataObj!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;

    created() {
      vm = this as any;
    }

    //输入验证
    inputName(val){
      if(this.verifySize2(val)){
        this.form.valueData = val
      }else{
        this.form.valueData = '';
      }

    }
    //输入验证
    verifySize2(val){
      // let reg = /^\d*$/
      let reg = /^\S+/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }

    handleGroupAction() {
      //新增，修改是需要加验证  "addLevel"  "addNext" "detail" "edit" delete
      let that = this as any;
      if (this.dataObj.type == "addLevel" || this.dataObj.type == "addNext" || this.dataObj.type == "edit") {
        (that.$refs['dataForm'] as any).validate((valid) => {
          if (valid) {
            that.$emit("handleDeviceGroupAction", this.dataObj, this.form.valueData)
            this.dialogShowVisible = false
          }
        })
      } else if (this.dataObj.type == "delete") {
        this.dialogShowVisible = false
        that.$emit("handleDeviceGroupAction", this.dataObj, this.form.valueData)
      }else if (this.dataObj.type == "detail") {
        this.dialogShowVisible = false
      }

    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      if (this.dataObj.type == 'edit') {
        this.form.valueData = this.dataObj.localData.name
      } else {
        this.form.valueData = ""
      }
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeEdit")
      }
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  ::v-deep .el-dialog__body {
    padding: 0px 0px
  }

  ::v-deep .el-input__inner {
    width: 224px;
    height: 32px;
  }

  ::v-deep .el-dialog__footer {
    text-align: center;
  }

  .content {
    min-height: 200px;
    width: 420px;
  }

  .div-class-edit {
    /* text-align: center;*/
    padding-top: 100px;
  }

  .div-class-delete {
    text-align: center;
    padding-top: 100px;
  }

  .div-class-detail {
  }

  .div-class-detail > div {
    padding: 50px 20px 0 50px;
  }

  .div-class-detail > div > span {
    margin-right: 30px;
    width: 56px;
    height: 14px;
    font-size: 14px;
    font-weight: bold;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
  }

  .div-left-detail {
    width: 40%;
    float: left;
    font-size: 14px;
    font-weight: bold;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
  }

  .div-right-detail {
    width: 60%;
    float: left;
    font-size: 14px;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
    word-wrap: break-word;
    word-break:break-all;
    overflow:hidden; text-overflow:ellipsis;
  }
</style>
