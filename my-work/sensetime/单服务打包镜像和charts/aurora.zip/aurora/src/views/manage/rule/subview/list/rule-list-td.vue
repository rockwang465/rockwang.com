<template>
  <div class="rule-list-td-container">
    <header>
      <div class="rule-list-td-header-text" >
        <span>  <router-link to="/manage/rule#rulestd" ><i class="el-icon-arrow-left" ></i> {{$t('rule.contRulesetBack')}}</router-link> </span>
        <span> {{$t('rule.contTotal')}} <span>{{total}}</span> {{$t('rule.contRecords')}}</span>
      </div>
      <div class="rule-list-td-header-addbtns" >
          <div v-if="!multipleModel" >
            <el-dropdown @command="handleCommandCreateRule" v-if="$permission('006314') || $permission('006318')">
              <el-button type="primary"> <i class="iconfont icon-add" ></i> {{$t('rule.buttonRuleAdd')}} </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="one" v-if="$permission('006314')">{{$t('rule.listSingle')}}</el-dropdown-item>
                <el-dropdown-item command="more" v-if="$permission('006318')">{{$t('rule.listMultiple')}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <el-button type="primary" class="marginleft" @click="multipleModel=true" > <i class="iconfont icon-batch-handle" ></i> {{$t('rule.buttonBatch')}} </el-button>
          </div>
          <div v-else>
            <el-button type="text" @click="multipleModel=false"> <i class="iconfont icon-fanhui rule-list-td-back" ></i></el-button>
            <el-button type="danger" v-if="$permission('006423')" @click="deleteRulesBatch"> <i class="iconfont icon-delete" ></i> {{$t('rule.buttonBatchDelete')}} </el-button>
            <el-button type="primary" v-if="$permission('006324')" @click="startRulesBatch"> <i class="iconfont icon-on-off" ></i> {{$t('rule.buttonBatchEnable')}} </el-button>
            <el-button type="primary" v-if="$permission('006325')" @click="stopRulesBatch"> <i class="iconfont icon-disable" ></i> {{$t('rule.buttonBatchDisable')}} </el-button>
          </div>
      </div>
    </header>
    <div class="rule-list-td-table" >
      <el-table
        ref="rulesList"
        :data="tableData"
        :stripe="true"
        @selection-change="selectionChange"
        @filter-change="tableFilterChange"
        style="width: 100%">
        <el-table-column  v-if="multipleModel" type="selection" width="55"></el-table-column>
        <el-table-column  prop="ruleName" :label="$t('rule.labelRuleName')" ></el-table-column>
        <el-table-column  prop="deviceName" :label="$t('rule.contDevice')" ></el-table-column>
        <el-table-column
          prop="deviceGroup"
          :label="$t('rule.labelDeviceGroup')" >
          <template slot="header" slot-scope="scope">
            <el-popover
              placement="bottom"
              width="160"
              v-model="deviceGroupFilterVisible">
              <div class="rule-list-td-popover" >
                <div class="rule-list-td-popover-treebox" >
                  <el-tree
                    ref="deviceGroupTree"
                    node-key="id"
                    @check="handleDeviceGroupTreeCheck"
                    :props="{label:'name'}"
                    :indent="0"
                    :show-checkbox="true"
                    :data="deviceGroupTreeData"></el-tree>
                </div>

                <div class="rule-list-td-popover-footer" >
                  <el-button size="mini" type="text" :disabled="deviceGroupTreeCheckedKeys.length == 0" @click="handleFilterDeviceGroup(scope)">{{$t('rule.contSearch')}}</el-button>
                  <el-button type="text"  @click="handleClearFilterDeviceGroup(scope)">{{$t('rule.contReset')}}</el-button>
                </div>
              </div>
              <span slot="reference" :class="deviceGroupTreeCheckedKeys.length>0?'rule-list-td-popover-content':''" >
                <span>{{$t('rule.labelDeviceGroup')}}</span>
                <i v-show="!deviceGroupFilterVisible" class="el-icon-arrow-down rule-list-td-popover-icon" ></i>
                <i v-show="deviceGroupFilterVisible" class="el-icon-arrow-up rule-list-td-popover-icon" ></i>
              </span>
            </el-popover>
          </template>
          <template slot-scope="scope">
            <el-tooltip effect="dark" :content="scope.row.deviceGroup.groupNames" placement="bottom">
              <span>
                {{scope.row.deviceGroup.groupName}}
              </span>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column
          prop="deviceSpecialAttribute"
          :filter-multiple="true"
          :label="$t('rule.labelAttribute')"
          :filters="specialAttributeOptions"
          column-key="taskAttributeIds">
          <template slot-scope="scope">
            <el-button type="primary" size="small" @click="welcomeEnyrance(scope.row)" v-if="scope.row.deviceSpecialAttribute.some(item=>item.taskAttributeId == 5)">{{$t('rule.listAttributeWelcomeGuests')}}</el-button>
            <span v-else >{{formatDeviceSpecialAttribute(scope.row.deviceSpecialAttribute)}}</span>
          </template>
        </el-table-column>
        <el-table-column width="220" prop="keeperNum" :label="$t('rule.labelAssociatedKeeper')" ></el-table-column>
        <el-table-column  prop="library" :label="$t('rule.labelImageLibrary')" ></el-table-column>
        <el-table-column  prop="threshold" :label="$t('rule.labelThreshold')" >
          <template slot-scope="scope">
            {{(scope.row.threshold*100).toFixed(1)}}%
          </template>
        </el-table-column>
        <el-table-column
          column-key="runStatus"
          :filter-multiple="false"
          :filters="[{text: $t('rule.buttonRuleStausEnabled'), value: 1}, {text: $t('rule.buttonRuleStausDisabled'), value: 0}]"
          prop="status"
          :label="$t('rule.labelRuleStaus')" >
          <template slot-scope="scope">
            <el-switch
              @change="(v)=>changeRuleStatus(v,scope.row)"
              v-model="scope.row.status"
              :active-value="1"
              :inactive-value="0"
              active-color="#13ce66"
              inactive-color="#ff4949">
            </el-switch>
          </template>
        </el-table-column>
        <el-table-column  prop="operation" :label="$t('rule.labelOperation')"  >
          <template slot-scope="scope">
            <span class="rule-list-operation-item" @click="handleView(scope.$index, scope.row)">
              <i class="iconfont icon-view"  ></i>
            </span>
            <span class="rule-list-operation-item" v-if="$permission('006215')"  @click="handleEdit(scope.$index, scope.row)">
              <i class="iconfont icon-edit" ></i>
            </span>
            <span class="rule-list-operation-item" v-if="$permission('006417')"  @click="handleDelete(scope.$index, scope.row)">
              <i class="iconfont icon-delete" ></i>
            </span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="rule-list-td-footer" >
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
    <!-- edit rule td dialog -->
    <EditRuleTD :visible="showEditRuleTDDialog" @hideEditRuleTDDialog="()=>{showEditRuleTDDialog = false}" :ruleId="currentRuleId" :backgroundImage="welcomebg"/>
    <!-- view rule td dialog -->
    <ViewRuleTD :visible="showViewRuleTDDialog" @hideViewRuletdDialog="(isEdit)=>{showViewRuleTDDialog = false;isEdit?showEditRuleTDDialog = true:'';}" :ruleId="currentRuleId" :backgroundImage="welcomebg"/>
    <!-- add rule td dialog -->
    <AddRuleTD :visible="showAddRuletdDialog" @hideAddRuletdDialog="showAddRuletdDialog=false" :groupId="groupId" :groupName="groupName" @refreshList="refreshList" />
    <!-- add rule Multiple dialog -->
    <AddRuleTDMultiple :visible="showAddRuletdMultipleDialog" @hideAddRuletdMultipleDialog="showAddRuletdMultipleDialog=false" @refreshList="refreshList" :groupId="groupId" :groupName="groupName" />
    <!-- messageBox delete -->
    <el-dialog
      :append-to-body="true"
      :visible="showDeleteDialog"
      :before-close="()=>this.showDeleteDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{$t('rule.popmsgRulesetDelete')}}</p>
      <div slot="title" >
        <span>{{$t('rule.listDelete')}}</span>
      </div>
      <span slot="footer">
        <el-button type="danger" @click="()=>ensureDelete()">{{$t('rule.buttonOperationDelete')}}</el-button>
        <el-button @click="showDeleteDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!-- messageBox change status -->
    <el-dialog
      :append-to-body="true"
      :visible="showStatusDialog"
      :before-close="()=>this.showStatusDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{statusText}}</p>
      <div slot="title" >
        <span>{{$t('rule.titleReminder')}}</span>
      </div>
      <span slot="footer">
        <el-button type="primary" @click="()=>ensureChangeStatus()">{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="showStatusDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!-- welcome -->
    <Welcome
      :visible="showWelcome"
      @close="handleCloseWelcome"
      :backgroundImage="welcomebg"
      :deviceId ="welcomeDeviceId"
      :ruleId="welcomeRuleId" />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import EditRuleTD from '../dialog/td/edit-rule-td.vue';
import ViewRuleTD from '../dialog/td/view-rule-td.vue';
import AddRuleTD from '../dialog/td/add-rule-td.vue';
import AddRuleTDMultiple from '../dialog/td/add-rule-td-multiple.vue';
import {deleteRuleTD,getRulesTDList,startRuleTD,stopRuleTD,
        startRuleTDBatch,
        stopRuleTDBatch,
        deleteRuleTDBatch,
        getSpecialAttrs,getDevices,
        getDevicesGroupTreeData
      } from '@/api/rule';
import {EventBus} from '@/utils/eventbus';
import {Popover,Button} from 'element-ui';
import Welcome from '../components/welcome.vue';
import {paginationPageSizes} from '@/utils/constants';

@Component({
  components: {
    EditRuleTD,
    AddRuleTD,
    AddRuleTDMultiple,
    ViewRuleTD,
    Welcome
  },
})
export default class RuleListAC extends Vue {
  // 计算属性

  /* props */

  /* watch */
  @Watch('multipleModel')
  onMultipleModelChange(n,o){
    n && this.$refs.rulesList.clearSelection();
  }

  /* data */
  $refs!:{
    rulesList:HTMLFormElement,
    deviceGroupTree:HTMLFormElement
  };
  groupId:string=this.getParamsValueFromURL('groupId');
  groupName:string=this.getParamsValueFromURL('groupName');
  tableData:any[]= [];
  showEditRuleTDDialog:boolean =false;
  showViewRuleTDDialog:boolean = false;
  showAddRuletdDialog:boolean = false;
  showAddRuletdMultipleDialog:boolean = false;
  multipleModel:boolean=false;
  currentRuleId:string='';
  //分页
  currentPage:number=1;
  totalPage:number=1;
  total:number=0;
  pageSizes=paginationPageSizes;
  pageSize:number=this.pageSizes[0];
  acRulesListCondition:any;
  groupListData:any[] = [];
  //batch
  selectedRules:any[]=[];
  //filter
  filterCondition:{
    taskAttributeIds:any[];
    runStatus:string
  }={
    taskAttributeIds:[],
    runStatus:''
  };
  specialAttributeOptions:any[]=[];
  keyword:string="";
  deviceGroupFilterVisible:boolean=false;
  deviceGroupTreeData:any[]=[];
  deviceGroupTreeCheckedKeys:any[]=[];
  //delete
  showDeleteDialog:boolean=false;
  deleteRuleIds:any=null;
  deleteModel:string="";
  currentDeleteText:string='';
  //status
  showStatusDialog:boolean=false;
  statusModel:string='';
  statusText:string='';
  statuRulesIds:any=null;
  //welcome
  showWelcome:boolean=false;
  welcomebg:string='';
  welcomeDeviceId:string='';
  welcomeRuleId:string='';
  /* methods */
  getParamsValueFromURL(key){
    let url_string = location.href.split('?')[1];
    let searchParams = new URLSearchParams(url_string);
    return searchParams.get(key) || '';
  }
  mounted() {
    this.initData();
    EventBus.$on('rule-refresh-ruleslistTD',(data)=>{this.getRuleList()});
    EventBus.$on('rule-search-list-td',this.handleSearchList);
  }
  initData(){
    this.keyword = '';
    this.deviceGroupTreeData = [];
    this.deviceGroupTreeCheckedKeys=[];
    this.getRuleList();
    this.getSpecialAttrs();
    this.getDeviceGroupsList();
    this.showWelcome = false;
    this.welcomebg = '';
    this.welcomeDeviceId='';
    this.welcomeRuleId = '';
  }
  getRuleList(params?){
    let condition = {page:this.currentPage,num:this.pageSize,...this.filterCondition,keyWord:this.keyword,...params};
    getRulesTDList(condition,this.groupId).then((res:any)=>{
       res.list && this.formatRulesList(res.list)
       this.total = res.total;
    })
  }
  handleSearchList(keyword){
    this.currentPage = 1;
    this.keyword = keyword;
    this.getRuleList();
  }
  getDeviceGroupsList(){
    getDevicesGroupTreeData().then(res=>{
      res && res.data && (this.deviceGroupTreeData = res.data);
    })
  }
  getSpecialAttrs(){
    this.specialAttributeOptions = [];
    getSpecialAttrs(1).then((res:any)=>{
      res && res.list.map(item=>{
        this.specialAttributeOptions.push({
          value:item.taskAttributeId,
          text:this.$tc(`rule.${item.taskAttributeName}`)
        })
      })
    })
  }
  getDeviceGroups(){

  }
  formatRulesList(list){
    this.tableData = [];
    list.map((item)=>{
      this.tableData.push({
        ruleId:item.taskId,
        ruleName: item.taskName,
        deviceName: item.deviceVo?item.deviceVo.deviceName:'',
        deviceGroup: item.deviceVo?this.formatGroupName(item.deviceVo.deviceGroupList):'',
        // deviceSpecialAttribute:this.formatDeviceSpecialAttribute(item.taskAttributeVos),
        deviceSpecialAttribute:item.taskAttributeVos,
        keeperNum:item.acTaskNum,
        timezones:item.timeZoneNum,
        library:item.libraryNum,
        threshold:item.threshold || 0,
        status:item.taskStatus,
        deviceVo:item.deviceVo,
        backgroundImage:item.backgroundImage
      })
    })
  }
  formatDeviceSpecialAttribute(deviceSpecialAttribute){
    let str = '';
    deviceSpecialAttribute && deviceSpecialAttribute.map(item=>{
      str= str+' '+this.$tc(`rule.${item.taskAttributeName}`);
    });
    return str;
  }
  formatGroupName(deviceGroupList){
    let groupName:string='',groupNames:string='',len = deviceGroupList.length;
    groupName = deviceGroupList[len-1].name;
    deviceGroupList.map((item,itemIndex)=>{
      groupNames+=item.name+(itemIndex == (len -1)?'':'>');
    });
    return {groupName,groupNames};
  }
  handleView(index,row){
    this.welcomebg = row.backgroundImage;
    this.currentRuleId = row.ruleId;
    this.showViewRuleTDDialog = true;
  }
  handleEdit(index,row){
    this.welcomebg = row.backgroundImage;
    this.currentRuleId = row.ruleId;
    this.showEditRuleTDDialog = true;
  }
  ensureDelete(){
    if(this.deleteModel == '1'){
      deleteRuleTD(this.currentRuleId).then(res=>{
        this.getRuleList();
        // this.$message({
        //   type: 'success',
        //   message: '删除成功!'
        // });
      }).finally(()=>{
        this.showDeleteDialog = false;
      })
    }
    if(this.deleteModel == '2'){
      deleteRuleTDBatch(this.deleteRuleIds).then(res=>{
        this.getRuleList();
        // this.$message({
        //   type: 'success',
        //   message: '删除成功!'
        // });
      }).finally(()=>{
        this.showDeleteDialog = false;
      })
    }

  }
  handleDelete(index,row){
    this.deleteModel = '1';
    this.currentRuleId = row.ruleId;
    this.currentDeleteText = this.$tc('rule.popmsgRulesetDelete') ;
    this.showDeleteDialog = true;
    // this.$confirm(this.$tc('rule.popmsgRulesetDelete') as string, this.$tc('rule.titleDelete') as string, {
    //   confirmButtonText: this.$tc('rule.buttonDelete') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    //   center:true
    // }).then(() => {
    //   deleteRuleTD(row.ruleId).then(res=>{
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '删除成功!'
    //     // });
    //   }).finally(()=>{
    //     this.getRuleList();
    //   })

    // }).catch(() => {
    //   // this.$message({
    //   //   type: 'info',
    //   //   message: '已取消删除'
    //   // });
    // });
  }
  handleCommandCreateRule(command){
    command == 'one' && (this.showAddRuletdDialog = true);
    command == 'more' && (this.showAddRuletdMultipleDialog = true);
  }
  handleSizeChange(v){
    this.pageSize = v;
    this.getRuleList();
  }
  handleCurrentChange(v){
    this.currentPage = v;
    this.getRuleList();
  }
  tableFilterChange(filter){
    let condition = Object.keys(filter)[0];
    if(condition == 'runStatus'){
      filter['runStatus'] = filter['runStatus'][0];
    }
    this.filterCondition[condition] = filter[condition];
    this.getRuleList();
  }
  handleFilterDeviceGroup(row){
    let filter = {deviceGroupIds:this.$refs.deviceGroupTree.getCheckedKeys()};
    this.deviceGroupTreeCheckedKeys = filter.deviceGroupIds;
    this.tableFilterChange(filter);
    this.deviceGroupFilterVisible = false;
  }
  handleClearFilterDeviceGroup(){
    let filter = {deviceGroupIds:[]};
    this.tableFilterChange(filter);
    this.$refs.deviceGroupTree.setCheckedKeys([]);
    this.deviceGroupTreeCheckedKeys = [];
    this.deviceGroupFilterVisible = false;
  }
  handleDeviceGroupTreeCheck(){
    this.deviceGroupTreeCheckedKeys = this.$refs.deviceGroupTree.getCheckedKeys();
  }
  changeRuleStatus(v,row){
    row.status = v==0?1:0;
    if( v ==1 && this.$permission('006321')){
      this.startRule(row.ruleId);
    }
    if(v ==0 && this.$permission('006322')){
      this.stopRule(row.ruleId);
    }
    // v == 1 && this.startRule(row.ruleId);
    // v == 0 && this.stopRule(row.ruleId);
  }
  ensureChangeStatus(){
    if(this.statusModel == 'start'){
      startRuleTD(this.currentRuleId).then(res=>{
        // this.$message({
        //   type: 'success',
        //   message: '开启成功!'
        // });
        this.getRuleList();
      }).finally(()=>{
        this.showStatusDialog = false;
      })
    }
    if(this.statusModel == 'stop'){
      stopRuleTD(this.currentRuleId).then(res=>{
        // this.$message({
        //   type: 'success',
        //   message: '关闭成功!'
        // });
        this.getRuleList();
      }).finally(()=>{
        this.showStatusDialog = false;
      });
    }
    if(this.statusModel == 'startBatch'){
      startRuleTDBatch(this.statuRulesIds).then(res=>{
        this.getRuleList();
        // this.$message({
        //   type: 'success',
        //   message: '开启成功!'
        // });
      }).finally(()=>{
        this.showStatusDialog = false;
      })
    }
    if(this.statusModel == 'stopBatch'){
      stopRuleTDBatch(this.statuRulesIds).then(res=>{
        this.getRuleList();
        // this.$message({
        //   type: 'success',
        //   message: '关闭成功!'
        // });
      }).finally(()=>{
        this.showStatusDialog = false;
      })
    }
  }
  startRule(ruleId){
    this.statusModel = 'start';
    this.currentRuleId = ruleId;
    this.statusText = this.$tc('rule.popmsgBatchEnable');
    this.showStatusDialog = true;

    // this.$confirm(this.$tc('rule.popmsgBatchEnable') as string, this.$tc('rolemanagement.titleReminder') as string, {
    //   confirmButtonText: this.$tc('rule.buttonOK') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    // }).then(() => {
    //   startRuleTD(ruleId).then(res=>{
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '开启成功!'
    //     // });
    //   }).finally(()=>{
    //     this.getRuleList();
    //   });
    // }).catch(()=>{});
  }
  stopRule(ruleId){
    this.statusModel = 'stop';
    this.currentRuleId = ruleId;
    this.statusText = this.$tc('rule.popmsgBatchDisable');
    this.showStatusDialog = true;

    // this.$confirm(this.$tc('rule.popmsgBatchDisable') as string, this.$tc('rolemanagement.titleReminder') as string, {
    //   confirmButtonText: this.$tc('rule.buttonOK') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    // }).then(() => {
    //   stopRuleTD(ruleId).then(res=>{
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '关闭成功!'
    //     // });
    //   }).finally(()=>{
    //     this.getRuleList();
    //   });
    // }).catch(()=>{});
  }
  refreshList(){
    this.getRuleList();
  }
  selectionChange(selection){
    this.selectedRules = selection;
  }
  deleteRulesBatch(){
    if(this.selectedRules.length == 0){
      this.$message.error(this.$tc('rule.errmsgSelsectRules'));
      return false;
    }
    let ruleIds:any = [];
    this.selectedRules.map((item:any)=>{
      ruleIds.push(item.ruleId)
    });
    this.deleteModel = '2';
    this.currentDeleteText = this.$tc('rule.popmsgRulesetDelete');
    this.deleteRuleIds = ruleIds;
    this.showDeleteDialog = true;
    // this.$confirm(this.$tc('rule.popmsgRulesetDelete') as string, this.$tc('rule.listDelete') as string, {
    //   confirmButtonText: this.$tc('rule.buttonDelete') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    // }).then(() => {
    //   deleteRuleTDBatch(ruleIds).then(res=>{
    //     this.getRuleList();
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '删除成功!'
    //     // });
    //   })
    // }).catch(()=>{});

  }
  startRulesBatch(){
    if(this.selectedRules.length == 0){
      this.$message.error(this.$tc('rule.errmsgSelsectRules'));
      return false;
    }
    let ruleIds:any = [];
    this.selectedRules.map((item:any)=>{
      ruleIds.push(item.ruleId)
    });
    this.statusModel = 'startBatch';
    this.statuRulesIds = ruleIds;
    this.statusText = this.$tc('rule.popmsgBatchEnable');
    this.showStatusDialog = true;



    // this.$confirm(this.$tc('rule.popmsgBatchEnable') as string, this.$tc('rolemanagement.titleReminder') as string, {
    //   confirmButtonText: this.$tc('rule.buttonOK') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    // }).then(() => {
    //   startRuleTDBatch(ruleIds).then(res=>{
    //     this.getRuleList();
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '开启成功!'
    //     // });
    //   })
    // }).catch(()=>{});

  }
  stopRulesBatch(){
    if(this.selectedRules.length == 0){
      this.$message.error(this.$tc('rule.errmsgSelsectRules'));
      return false;
    }
    let ruleIds:any = [];
    this.selectedRules.map((item:any)=>{
      ruleIds.push(item.ruleId)
    });

    this.statusModel = 'stopBatch';
    this.statuRulesIds = ruleIds;
    this.statusText = this.$tc('rule.popmsgBatchDisable');
    this.showStatusDialog = true;


    // this.$confirm(this.$tc('rule.popmsgBatchDisable') as string, this.$tc('rolemanagement.titleReminder') as string, {
    //   confirmButtonText: this.$tc('rule.buttonOK') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    // }).then(() => {
    //   stopRuleTDBatch(ruleIds).then(res=>{
    //     this.getRuleList();
    //     // this.$message({
    //     //   type: 'success',
    //     //   message: '关闭成功!'
    //     // });
    //   })
    // }).catch(()=>{});

  }
  welcomeEnyrance(row){
    this.welcomebg = row.backgroundImage;
    this.welcomeDeviceId = row.deviceVo.deviceId || '';
    this.welcomeRuleId = row.ruleId;
    this.showWelcome = true;
  }
  handleCloseWelcome(){
    this.showWelcome = false;
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .rule-list-td-container{
    height: 100%;
    overflow: auto;
    .rule-list-td-table{
      height: calc(100% - 146px);
      overflow-y: auto;
    }
    .rule-list-td-footer{
      margin-top: 10px;
      text-align: center;
    }
    .rule-list-td-header-text{
      display: flex;
      justify-content: space-between;
      color: $--color-black;
      padding: 5px 0;
      padding-bottom:16px;
      border-bottom:1px solid $--border-color-base;
    }
    .rule-list-td-header-addbtns{
      padding: 10px 0;
      padding-top: 16px;
      .marginleft{
        margin-left: 10px;
      }
      .rule-list-td-back{
        color: $--color-black;
        font-weight: 600;
      }
    }
     .rule-list-operation-item{
      cursor: pointer;
      margin-right: 10px;
      i.iconfont{
        font-size:19px;
      }
    }
    ::v-deep .el-table__column-filter-trigger .el-icon-arrow-down{
      color:#28354d;
      font-size: 14px;
    }
    ::v-deep .rule-list-td-popover-icon{
      cursor: pointer;
      font-size: 14px;
      color: #28354d;
      margin-left: 10px;
      transform: scale(0.75);
    }
  }
  .rule-list-td-popover{
    .rule-list-td-popover-treebox{
      max-height: 200px;
      overflow: auto;
    }
    .rule-list-td-popover-footer{
      border-top: 1px solid #ccc;
      button.el-button {
        color:#28354d;
        &:hover{
          color:#2a5af5;
        }
      }
      button.el-button.is-disabled {
        color:#c0c4cc;
      }
    }
  }
  .rule-list-td-popover-content span{
    color: #2a5af5;
  }
</style>
