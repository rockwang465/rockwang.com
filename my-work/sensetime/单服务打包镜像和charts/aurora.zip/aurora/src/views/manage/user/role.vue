<template>
  <el-container>
    <el-main class="wrap">
      <el-row class="row-bg">
        <el-col :span="10" style="height: 32px;">
          <el-button @click="showAddRole('')" v-if="$permission('002310')" type="primary" size="small" icon="iconfont icon-add-user">
            {{$t('rolemanagement.buttonRoleAdd')}}<!--添加角色-->
          </el-button>
          <el-button type="primary" size="small" icon="el-icon-upload2" @click="showRoleExport"
                     v-if="$permission('002314')">
            {{$t('rolemanagement.buttonExport')}}
          </el-button>&nbsp;
        </el-col>
        <el-col :span="10" class="center">
          <span>{{$t('rolemanagement.contTotalRole',{number:total})}}<!--角色数量--></span> <i
          class="iconfont icon icon-separator"></i> <span class="active">{{$t('rolemanagement.contEnabledRole',{number:activationCount})}}
          <!--激活--></span>
          &nbsp;
        </el-col>
        <el-col :span="4">
          <!--角色名称-->
          <el-input
            :placeholder="$t('rolemanagement.contRoleName')"
            size="medium"
            v-model="keywords"
            @focus="inputFocus"
            @blur="inputBlur"
            class="search-input-role">
           <span class="suffix-icon" slot="suffix">
             <Icon
               v-if="showSearchClose"
               type="ele"
               size="15"
               cursor="pointer"
               name="circle-close"
               @click="clickClearKeywords"
             />
            <Icon
              type="ele"
              size="15"
              cursor="pointer"
              name="search"
              @click="keywordsChange"
            />
          </span>
          </el-input>
        </el-col>
      </el-row>
      <el-row class="addShadow" style="height: calc(100% - 98px);">
        <el-col :span="24" style="height:100%">
          <el-table
            stripe
            v-loading="loading"
            :data="tableData"
            @sort-change="sortChange"
            @filter-change="tableFilterChange"
            style="width: 100%;height: calc(100% - 50px)">
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="30">
            </el-table-column>
            <!--名称-->
            <el-table-column
              align="left"
              prop="name"
              :label="$t('rolemanagement.labelRoleName')"
              width="280">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--添加时间-->
            <el-table-column
              align="left"
              prop="createTime"
              :label="$t('rolemanagement.labelTimeCreation')"
              width="254"
              sortable="custom">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--添加者-->
            <el-table-column
              align="left"
              prop="createUserName"
              :label="$t('rolemanagement.labelOperator')"
              width="220">
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <el-table-column
              align="left"
              width="150"
              prop="roleStatus"
              column-key="roleStatus"
              :filter-multiple="false"
              :filters="[{text: $t('usermanagement.buttonEnable'), value: '1'},{text: $t('devicemanagement.listActiveStatusDisabled'), value: '0'}]"
              :label="$t('devicemanagement.labelActiveStatus')"
            >
              <!--:render-header="renderStatus"-->
              <template slot-scope="scope">
                <el-switch
                  :disabled="!$permission('002213')"
                  @change="showUpdateStates(scope.row)"
                  v-model="scope.row.state == '1'"
                  active-color="#13ce66"
                  inactive-color="#ff4949">
                </el-switch>
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              width="20">
            </el-table-column>
            <!--操作-->
            <el-table-column
              align="left"
              :label="$t('rolemanagement.labelOperation')"
              min-width="112">
              <template slot-scope="scope">
                <span class="role-list-operation-item" v-if="$permission('002109')"
                      @click="showDetailRole(scope.row)">
                      <i class="iconfont icon-view"></i>
                    </span>
                <!--打开编辑-->
                <span class="role-list-operation-item" v-if="$permission('002211')" @click="showAddRole(scope.row)">
                      <i class="iconfont icon-edit"></i>
                    </span>
                <!--删除-->
                <span class="role-list-operation-item" v-if="$permission('002412')"
                      @click="showDeleteRole(scope.row)">
                      <i class="iconfont icon-delete"></i>
                    </span>
              </template>
            </el-table-column>
            <!--间隔-->
            <el-table-column
              prop=""
              label=" "
              min-width="30">
            </el-table-column>
          </el-table>

          <el-pagination class="page"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="page"
            :page-sizes="[10, 20, 30, 50,100]"
            :page-size="size"
            :total="total"
            layout="total, sizes, prev, pager, next, jumper">
          </el-pagination>
        </el-col>
      </el-row>
    </el-main>

    <RoleExport :dialogVisible="dialogExportVisible" :total="total" @closeRoleExport="closeRoleExport"
                :query="query"></RoleExport>
    <RoleAdd :dialogVisible="dialogAddRoleVisible" @closeRoleAdd="closeRoleAdd"
             :editObjectData="editObjectData" :checkRelate="checkRelate" @refreshData="refreshData"></RoleAdd>
    <RoleAction :dialogVisible="dialogActionVisible" @closeRoleAction="closeRoleAction" :dataObj="dataObj"
                @handleAction="handleAction"></RoleAction>
    <RoleDetail :dialogVisible="dialogRoleDetailVisible" @closeRoleDetail="closeRoleDetail"
                @detailToEditRole="detailToEditRole"
                :localObject="localObject"></RoleDetail>
  </el-container>
</template>

<script lang="ts">

  import {Component, Vue, Watch} from 'vue-property-decorator';
  import {RoleModule} from '@/store/modules/role';
  import RoleExport from './roleAction/roleExport.vue';
  import RoleAdd from './roleAction/roleAdd.vue';
  import RoleAction from './roleAction/roleAction.vue';
  import RoleDetail from './roleAction/roleDetail.vue';
  import {isEmpty} from '@/utils/validate';
  import Icon from '@/components/icon-wrap/index.vue';
  import {AppModule} from '@/store/modules/app';

  @Component({
    components: {
      RoleExport,
      RoleAdd,
      RoleAction,
      RoleDetail,
      Icon
    },
  })
  export default class Role extends Vue {
    get language() {
      return AppModule.language;
    }

    focusEnter = false;
    loading = false;
    dialogActionVisible = false;
    dialogExportVisible = false;
    dialogAddRoleVisible = false;
    dialogRoleDetailVisible = false;
    dataObj = {
      type: "",
      title: "",
    } as any;
    localObject = {} as any;
    editObjectData = {} as any;
    keywords = '';
    page = 1;
    size = 10;
    state = "";
    total = 0;
    sort = 'DESC';
    activationCount = 0;//激活数量
    tableData = [];
    checkRelate = {};
    query = {} as any;
    showSearchClose = false;

    mounted() {
      let that = this as any;
      this.searchData();
      this.getPermissions();
      this.getRoleRelate();
      // document.onkeydown = function (event) {
      //   let e = event || window.event || arguments.callee.caller.arguments[0];
      //   //回车键检索
      //   if (e && e.key == 'Enter') {
      //     that.keywordsChange();
      //   }
      // };
    }

    inputFocus(){
      this.focusEnter = true;
      let that = this as any;
      window.document.onkeydown = function(event){
        if (that.focusEnter) {
          if (event.keyCode == 13){
            that.keywordsChange();
          }
        }

      }
    }
    inputBlur(){
      this.focusEnter = false;
    }

    //导出
    getRoleRelate() {
      let that = this as any
      RoleModule.GetRoleRelate().then((data: any) => {
        let arr = data.data
        let checkRelate = {};
        for (let i = 0; i < arr.length; i++) {
          if (!isEmpty(arr[i].relation) && arr[i].relation.length != 0) {
            checkRelate[arr[i].buttonId] = arr[i].relation
          }
        }
        that.checkRelate = checkRelate
      }).catch((err) => {
        console.log(err)
      });
    }

    //获取角色list
    searchData() {
      this.loading = true;
      let that = this as any;
      let params = {
        page: that.page,
        size: that.size,
        sort: that.sort,
        state: that.state,
        keywords: that.keywords
      };
      RoleModule.GetRoleList(params).then((data: any) => {
        that.activationCount = data.activationCount;
        that.total = data.total;
        that.tableData = data.data;
        this.loading = false;
      }).catch((err) => {
        this.loading = false;
        console.log(err)
      });
    }

    @Watch('language')
    onLanguageChanged() {
      this.getPermissions();
    };

    //获取权限list
    getPermissions() {
      let that = this as any
      RoleModule.GetPermissions({
        language: that.language == 'en' ? 2 : 1
      }).then((data: any) => {
        let array = [] as any;
        let allArray = [] as any;
        let selectParams = {} as any;
        for (let i = 0; i < data.list.length; i++) {
          let params = {
            moduleCode: data.list[i].moduleCode,
            moduleName: data.list[i].moduleName,
          } as any;
          let moduleArray = [] as any;
          let typePermission = data.list[i].typePermissionVos;
          for (let j = 0; j < typePermission.length; j++) {
            let typePermissionVo = {} as any;
            typePermissionVo.typeName = typePermission[j].typeName;
            typePermissionVo.moduleId = typePermission[j].moduleId;
            typePermissionVo.typeId = typePermission[j].typeId;
            typePermissionVo.onlyCode = typePermission[j].moduleId + '-' + typePermission[j].typeId;
            let codes = "" as any;
            let permissionVo = typePermission[j].permissionVos;
            for (let k = 0; k < permissionVo.length; k++) {
              // codes += permissionVo[k].permissionCode + ",";19-12-23,字段由code改为id
              codes += permissionVo[k].modulePermissionId + ",";
            }
            typePermissionVo.codes = codes.substring(0, codes.length - 1)
            selectParams[typePermissionVo.onlyCode] = typePermissionVo.codes
            allArray.push(typePermissionVo.onlyCode)
            //allArray.push(codes.substring(0, codes.length - 1))
            moduleArray.push(typePermissionVo)
          }
          params.moduleArray = moduleArray;
          array.push(params);
        }
        this.editObjectData.selectParams = selectParams;
        this.editObjectData.allCheckedData = allArray;
        this.editObjectData.permissionOptions = array;
      }).catch((err) => {
        console.log(err)
      });
    }

    handleSizeChange(val) {
      this.page = 1;
      this.size = val;
      this.searchData();
    }

    handleCurrentChange(val) {
      this.page = val;
      this.searchData();
    }

    closeRoleAdd(obj) {
      this.dialogAddRoleVisible = false;
    }

    closeRoleExport() {
      this.dialogExportVisible = false;
    }

    showRoleExport() {
      let that = this;
      that.query = {
        page: that.page,
        size: that.size,
        sort: that.sort,
        state: that.state,
        keywords: that.keywords
      };
      that.dialogExportVisible = true;
    }

    showAddRole(obj) {
      if (!isEmpty(obj)) {
        this.editObjectData.roleId = obj.roleId;
        this.editObjectData.name = obj.name;
        RoleModule.DetailRolePermissions(obj.roleId).then((data: any) => {
          this.editObjectData.checkedArray = this.getCheckedRoles(this.editObjectData.allCheckedData, data.list);
          console.log(this.editObjectData)
          this.dialogAddRoleVisible = true
        }).catch((err) => {
          console.log(err)
        });
      } else {
        //有些是必填项
        this.editObjectData.checkedArray = ['1-1', '2-1', '2-3']
        this.editObjectData.roleId = '';
        this.editObjectData.name = '';
        this.dialogAddRoleVisible = true
      }
    }

    detailToEditRole(obj) {
      this.editObjectData.roleId = obj.roleId;
      this.editObjectData.name = obj.name;
      this.editObjectData.checkedArray = obj.checkedArray
      this.dialogAddRoleVisible = true
    }

    closeRoleDetail() {
      this.dialogRoleDetailVisible = false
    }

    showDetailRole(obj) {
      let that = this as any;
      this.localObject.name = obj.name;
      this.localObject.roleId = obj.roleId;
      RoleModule.DetailRolePermissions(obj.roleId).then((data: any) => {
        this.localObject.permissionOptions = this.editObjectData.permissionOptions;
        this.localObject.checkedArray = this.getCheckedRoles(this.editObjectData.allCheckedData, data.list);
        this.dialogRoleDetailVisible = true
      }).catch((err) => {
        console.log(err)
      });
    }

    getCheckedRoles(codesArray, array) {
      let checkedArray = [] as any;
      for (let i = 0; i < codesArray.length; i++) {
        if (this.isIn(codesArray[i], array)) {
          checkedArray.push(codesArray[i]);
        }
      }
      return checkedArray;
    }

    isIn(code, array) {
      for (let i = 0; i < array.length; i++) {
        let codes = array[i].moduleId + '-' + array[i].typeId;
        if (code == codes) {
          return true
        }
      }
      return false
    }

    checkInRoles(code, array) {
      for (let i = 0; i < array.length; i++) {
        if (code == array[i].permissionCode) {
          return true
        }
      }
      return false;
    }

    //点击删除按钮显示操作框
    showDeleteRole(obj) {
      let that = this as any;
      this.dialogActionVisible = true
      this.dataObj.type = "delete"
      this.dataObj.title = that.$t('rolemanagement.contDelete');//删除
      this.dataObj.roleObj = obj
    }

    //点击修改状态按钮显示操作框
    showUpdateStates(obj) {
      let that = this as any;
      this.dialogActionVisible = true
      this.dataObj.type = "updateStatus"
      this.dataObj.title = that.$t('rolemanagement.titleReminder');//提示
      this.dataObj.roleObj = obj
    }

    //处理操作框的方法
    handleAction(flag, roleObj) {
      let that = this as any;
      switch (flag) {
        //删除操作
        case "delete":
          if (roleObj.defaultRole == 1) {
            that.$message.error({showClose: true,message:that.$t('rolemanagement.roleAdminNotDel')});
            return
          }
          RoleModule.DeleteRole(roleObj.roleId).then((data: any) => {
            this.searchData();
            that.$message({
              showClose: true,
              message: that.$t('rolemanagement.roleDeleteSuccess'),
              type: 'success'
            });
          }).catch((err) => {
            console.log(err)
          });
          break
        case "updateStatus":
          RoleModule.UpdateRoleStatus({state: roleObj.state == 1 ? 0 : 1, id: roleObj.roleId},).then((data: any) => {
            this.searchData();
            that.$message({
              showClose: true,
              message: roleObj.state == 1 ? that.$t('rolemanagement.roleStopSuccess') : that.$t('rolemanagement.roleStartSuccess'),
              type: 'success'
            });
          }).catch((err) => {
            console.log(err)
          });
      }
    }

    closeRoleAction() {
      this.dialogActionVisible = false
    }

    keywordsChange() {
      this.page = 1
      this.searchData()
    }

    @Watch('keywords')
    watchKeywordsChange(val: any) {
      if (!isEmpty(val)) {
        this.showSearchClose = true
      } else {
        this.showSearchClose = false
        this.page = 1
        this.searchData()
      }
    }

    clickClearKeywords() {
      this.keywords = '';
      this.showSearchClose = false
      this.page = 1
      this.searchData()
    }

    refreshData() {
      this.page = 1
      this.keywords = '';
      this.searchData()
    }

    //时间排序
    sortChange(a) {
      if (a.prop == 'createTime') {
        this.sort = a.order == 'ascending' ? 'ASC' : a.order == 'descending' ? 'DESC' : 'DESC'
      }
      this.page = 1;
      this.searchData();
    }

    tableFilterChange(filter) {
      this.page = 1
      this.state = filter.roleStatus[0];
      this.searchData()
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .el-breadcrumb {
    padding: 10px;
  }

  .wrap {
    padding: 0 16px;
  }

  .row-bg {
    padding: 32px 0 16px 0;
    height: 80px;
  }

  .role-permission .el-form-item {
    margin-bottom: 0;
  }

  .active {
    color: #BE0000;
    text-align: left;
    font-weight: 600;
    cursor: pointer;
  }

  .center {
    line-height: 32px;
    display: flex;
  }

  ::v-deep .el-table__body-wrapper {
    max-height: calc(100% - 65px);
    overflow-y: auto;
  }

  .role-list-operation-item {
    cursor: pointer;
    margin-right: 10px;

    i.iconfont {
      font-size: 19px;
    }
  }

  ::v-deep .el-table__column-filter-trigger{
    margin-left: 10px;

    i{
      color: black;
      font-size: 16px;
    }
  }
  .addShadow{
    @include shadowBox();
  }
</style>
