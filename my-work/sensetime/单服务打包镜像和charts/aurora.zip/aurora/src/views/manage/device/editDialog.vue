<template>
  <div class="deviceAdd" v-if="dialogShowVisible">
    <el-dialog class="isroll" :title="form.deviceId ? $t('devicemanagement.titleEdit') : $t('devicemanagement.buttonAddDevice')"
               :visible.sync="dialogShowVisible" :width="width">
      <div class="scrollable">
        <br>
      <el-form
        ref="dataForm"
        :rules="rulesList"
        :model="form"
        class="form-group"
        label-position="right">
        <div class="form-group-item">
          <el-form-item :label="$t('devicemanagement.contDeviceType')" :label-width="formLabelWidth"
                        prop="emptyVal"><!--设备类型-->
            <el-select size="small" class="filter-item" v-model="form.deviceType" style="width:224px">
              <el-option v-for="item in deviceTypeArray" :key="item.value" :value="item.value"
                         :label="item.name"></el-option>
            </el-select>
          </el-form-item>
          <!--小盒子设备选择-->
          <el-form-item v-if="form.deviceType==3" prop="mData.mVersion" :label="$t('devicemanagement.version')" :label-width="formLabelWidth">
            <el-select size="small" class="filter-item" v-model="form.mData.mVersion" style="width:224px">
              <el-option v-for="item in mDeviceTypeArray" :key="item.value" :value="item.value" :label="item.name"></el-option>
            </el-select>
          </el-form-item>

          <!--人脸识别机前设备选择-->
          <el-form-item v-if="form.deviceType==6" prop="passData.passDeviceType" :label="$t('devicemanagement.frontendDevices')"
                        :label-width="formLabelWidth">
            <el-select size="small" class="filter-item" v-model="form.passData.passDeviceType" style="width:224px">
              <el-option v-for="item in passDeviceTypeArray" :key="item.value" :value="item.value"
                         :label="item.name"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceName')" :label-width="formLabelWidth" prop="name">
            <!--名称-->
            <el-input v-model.trim="form.name" class="input-width" autocomplete="off" maxlength="40"></el-input>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceID')"
                        :label-width="formLabelWidth" prop="ID">
            <el-input size="small" v-model.trim="form.ID" class="input-width" autocomplete="off" maxlength="40"></el-input>
            <div :style="{position: 'absolute',top: 0,right: language == 'en' ? '-20px' : '-8px',}" v-if="form.deviceType==6">
              <el-popover
                placement="bottom-start"
                width="271"
                trigger="hover">
                <div class="content">
                  {{$tc('devicemanagement.tipcontDeviceID')}}
                </div>
                <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
              </el-popover>
            </div>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceGroup')" :label-width="formLabelWidth" prop="emptyVal">
            <!--分组-->
            <EditAddGroup ref="editaddgroup" size="small" :selectGroupObj="selectGroupObj"
                          @selected="handleEditAddGroup"/>
          </el-form-item>

          <el-form-item :label="$t('devicemanagement.contLocation')" :label-width="formLabelWidth" prop="emptyVal">
            <!--地点-->
            <i class="iconfont icon-place"></i>
            <span class="address-class" v-if="form.point"
                  @click="addDevice">{{form.floorName + ',' + form.point}}</span>
            <span class="address-class" v-else @click="addDevice">{{$t('devicemanagement.deviceSetAddress')}}</span>
          </el-form-item>
          <!--经纬度-->
          <el-form-item :label="$t('devicemanagement.trapeze')"
                        v-show="form.deviceType==3"
                        :label-width="formLabelWidth">
            <el-input size="small" class="input-width" v-model.trim="form.latitudeLongitude" autocomplete="off" maxlength="48"></el-input>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contAssignedUser')" :label-width="formLabelWidth"><!--分配用户-->
            <TreeSelect size="small" :data="treeData" @selected="handleSelected" show-checkbox
                        :dataObj="dataUserIdsObj"/>
          </el-form-item>
        </div>
        <div v-if="showVideo" class="rtsp-video">
          <br>
          <div class="rtsp-video-see-cancel">
            <el-button type="danger" size="mini" @click="showVideo = !showVideo">
              {{$t('devicemanagement.buttonCancel')}}
            </el-button>
          </div>
          <br>
          <div class="rtsp-video-see">
            <MediaPlayer type="1" :name="form.name" :url="form.rtspAddress"/>
          </div>
        </div>
        <hr v-if="form.deviceType==1 || form.deviceType==4 || form.deviceType == 3 " >
        <br>

        <!-- 盒子 -->
        <!-- <el-form-item v-if="form.deviceType==3 "
          label="设备IP" prop="ip" :label-width="formLabelWidth">
          <el-input v-model="form.ip" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==3 "
          label="Port" prop="port" :label-width="formLabelWidth">
          <el-input v-model="form.port" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==3 "
          label="用户名" prop="username" :label-width="formLabelWidth">
          <el-input v-model="form.username" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==3 "
          label="密码" prop :label-width="formLabelWidth">
          <el-input v-model="form.password" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item> -->

         <!-- <el-form-item :label="$t('rule.labelImageLibraryList')" :label-width="formLabelWidth" v-if="form.deviceType==3">
          <PortraitSelect :data="propTreeData" @selected="handleSelectedP" show-checkbox
                          :dataObj="dataLibraryIdsObj"/>
        </el-form-item> -->

        <!--属性-->
        <!-- <el-form-item :label="$t('devicemanagement.contOtherInfo')" :label-width="formLabelWidth">
        </el-form-item> -->
        <!--<el-form-item class="form-item-text" v-show="form.deviceType==3"-->
                      <!--:label="$t('devicemanagement.contProtocol')"-->
                      <!--:label-width="formLabelWidth">&lt;!&ndash;协议&ndash;&gt;-->
          <!--<el-radio v-for="item in httpTypeArray" v-model="form.protocolType2" :label="item.value" :key="item.value">-->
            <!--{{item.name}}-->
          <!--</el-radio>-->
        <!--</el-form-item>-->
        <!--类型-->
        <el-form-item v-show="form.deviceType==1" :label="$t('devicemanagement.contCameraType')"
                      :label-width="formLabelWidth">
          <el-radio v-for="item in attributeArray" v-model="form.streamType" :label="item" :key="item">{{item}}
          </el-radio>
        </el-form-item>
        <el-form-item v-show="form.deviceType==1 && form.streamType=='RTSP'" :label="$t('devicemanagement.contRTSP2')"
                      :label-width="formLabelWidth"
                      prop="rtspAddress">
          <el-input onkeyup="this.value=this.value.replace(/\s+/g,'')" size="small" v-model.trim="form.rtspAddress"  class="input-width" style="width: 224px"
                    autocomplete="off"></el-input>&nbsp;&nbsp;
          <i v-if="$permission('007118')" style="cursor: pointer" @click="showVideo=!showVideo"
             class="iconfont icon-view"></i>
        </el-form-item>
        <el-form-item class="form-item-text" v-show="form.deviceType==1 && form.streamType=='RTSP'"
                      :label="$t('devicemanagement.contEncodeType')"
                      :label-width="formLabelWidth"><!--编码类型-->
          <el-radio v-for="item in codeTypeArray" v-model="form.codeType" :label="item.value" :key="item.value">
            {{item.name}}
          </el-radio>
        </el-form-item>
        <el-form-item class="form-item-text" v-show="form.deviceType==1 && form.streamType=='RTSP'"
                      :label="$t('devicemanagement.contProtocol')"
                      :label-width="formLabelWidth"><!--传输协议-->
          <el-radio v-for="item in transportProtocolArray" v-model="form.protocolType" :label="item" :key="item">
            {{item}}
          </el-radio>
        </el-form-item>
        <!--抓拍机类型-->
        <el-form-item v-if="form.deviceType==4" prop="name" :label="$t('devicemanagement.manufacturer')"
                      :label-width="formLabelWidth">
          <el-select size="small" class="filter-item" v-model="form.manufacturer" style="width:224px">
            <el-option v-for="item in manufacturerArray" :key="item.value" :value="item.value"
                       :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-if="form.deviceType==1 && form.streamType=='ONVIF'||form.deviceType==4 ||form.deviceType==3" :label="$t('devicemanagement.contIP')"
                      prop="ip"
                      :label-width="formLabelWidth">
          <el-input class="input-width" size="small" v-model="form.ip" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==1 && form.streamType=='ONVIF'||form.deviceType==4 ||form.deviceType==3" :label="$t('devicemanagement.contPort')"
                      prop="port"
                      :label-width="formLabelWidth">
                      <span v-if="form.deviceType==3">{{form.port = "80"}}</span>
          <!-- <el-input v-if="form.deviceType==3"
            @input="inputPortNum"
            v-model="form.port" autocomplete="off" size="small" class="input-width" :disabled="true"></el-input> -->
          <el-input v-else
            @input="inputPortNum"
            v-model="form.port" autocomplete="off" size="small" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==1 && form.streamType=='ONVIF'||form.deviceType==4 ||form.deviceType==3" :label="$t('devicemanagement.contUsername')"
                      prop="username"
                      :label-width="formLabelWidth">
          <el-input v-model.trim="form.username" autocomplete="off" maxlength="40" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==1 && form.streamType=='ONVIF'||form.deviceType==4 ||form.deviceType==3" :label="$t('devicemanagement.contPassword')"
                      prop="password"
                      :label-width="formLabelWidth">
          <el-input v-model.trim="form.password" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==6" prop="verifyThreshold" :label="$t('rule.contThreshold')" :label-width="formLabelWidth">
          <el-select
            style="width:90px"
              class=""
              v-model="form.verifyThreshold"
              filterable
              allow-create
              default-first-option
              :placeholder="$t('rule.contThreshold')">
              <el-option v-for="(item,itemIndex) in thresholdOptions" :key="itemIndex" :label="Number(item*100).toFixed(1)" :value="item">
              </el-option>
          </el-select> %
        </el-form-item>
        <div v-if="form.deviceType==6" style="width:410px">
            <LibraryToTimezone ref="librarytotimezone" :data="librarytotimezoneData" />
            <div>
              <p style="color:#ccc;word-break: break-all;">
                *{{$tc('devicemanagement.contTimezoneWarn')}}
              </p>
            </div>
        </div>

        <!--人脸抓拍机（前）配置项-->
        <div  class="deviceType6" v-if="form.deviceType==6">
          <div class="more-config-btn"  @click="isRotate = !isRotate" >
            <div>
              <!--更多配置-->
              {{$t('devicemanagement.contMoreConfiguration')}}
          </div>
            <i class="el-icon-arrow-up" :class="isRotate?'rotateDown':'rotateUp'"></i>
          </div>
          <div class="more-config" v-show="isRotate" v-if="form.passData.passDeviceType">
            <div>
              <div class="config-type">
                {{$t('devicemanagement.contLogon')}}
                <!--登陆设置-->
                <hr>
                <br>
              </div>

                <el-form-item prop="passData.passUsername" :label="$t('devicemanagement.contAccountNum')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('passUsername')">
                  <!--账号  （默认admin1234）-->
                  <p style="text-indent: 14px;">{{form.passData.passUsername}}</p>
                  <!-- <el-input v-model.trim="form.passData.passUsername" class="input-width" autocomplete="off" maxlength="25"></el-input> -->
                </el-form-item>
                <el-form-item prop="passData.passPassword"  :label="$t('devicemanagement.contPassword')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('passPassword') && dataObj.deviceId">
                  <!--密码-->
                  <el-input v-model.trim="form.passData.passPassword" class="input-width"  maxlength="20"></el-input>
                </el-form-item>
            </div>


            <div>
              <div class="config-type">
                <!--功能设置-->
                {{$t('devicemanagement.contFunctionSet')}}
                <hr>
                <br>
              </div>
              <el-form-item :label="$t('devicemanagement.contInitiateMode')" v-if="isCurrentTypeHasFormItem('deviceRunType')"
                            :label-width="formLabelWidth">
                <!--启用状态-->
                <el-select size="small" class="filter-item" v-model="form.passData.deviceRunType" style="width:224px" >
                  <el-option v-for="item in passFormData.deviceRunTypeList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contModeSelection')"
                            :label-width="formLabelWidth" v-if="form.passData.passDeviceType != 3&&form.passData.passDeviceType == 1" > -->
              <el-form-item :label="$t('devicemanagement.contModeSelection')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('useMode')" >
                <!--模式选择-->
                <el-select size="small" class="filter-item" v-model="form.passData.useMode" style="width:224px">
                  <el-option v-for="item in getPropUseModeOptions()" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contModeSelection')"
                            :label-width="formLabelWidth" v-if="form.passData.passDeviceType != 3&&form.passData.passDeviceType != 1"> -->
                <!--模式选择-->
                <!-- <el-select size="small" class="filter-item" v-model="form.passData.useMode" style="width:224px">
                  <el-option v-for="item in passFormData.modeSelectionList2" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item> -->
              <el-form-item :label="$t('devicemanagement.contCheckPattern')" v-if="isCurrentTypeHasFormItem('mode')"
                            :label-width="formLabelWidth">
                <!--核验模式-->
                <el-select size="small" class="filter-item" v-model="form.passData.mode" style="width:224px">
                  <el-option v-for="item in getProopModeOptions()" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contIntelligentFillLight')"
                            :label-width="formLabelWidth"  v-if="form.passData.passDeviceType == 3"> -->
              <el-form-item :label="$t('devicemanagement.contIntelligentFillLight')"  v-if="isCurrentTypeHasFormItem('fillLight')"
                            :label-width="formLabelWidth" >
                <!--智能补光灯-->
                <el-select size="small" class="filter-item" v-model="form.passData.fillLight" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contVoiceBroadcast')"
                            :label-width="formLabelWidth" v-if="form.passData.passDeviceType != 1"> -->
              <el-form-item :label="$t('devicemanagement.contVoiceBroadcast')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('voiceBroadcast')">
                <!--语音播报-->
                <el-select size="small" class="filter-item" v-model="form.passData.voiceBroadcast" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelStrongTips')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('strongHint')">
                <!--强提示-->
                <el-select size="small" class="filter-item" v-model="form.passData.strongHint" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelTouchRecognition')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('touchRecognition')">
                <!--触摸识别-->
                <el-select size="small" class="filter-item" v-model="form.passData.touchRecognition" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelImageSelf')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('touchRecognition') && form.passData.touchRecognition">
                <!--自定义图片-->
                <ImageSelect :showClose="false" @select="(base64)=>customImagesSelect(base64)" :defaultImgUrl="imgSrcIsBase64(form.passData.backgroundImg)?form.passData.backgroundImg:processImgurl(form.passData.backgroundImg)" />
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelBack')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('touchRecognitionReturnTime') && form.passData.touchRecognition">
                <!--完成返回-->
                <el-input-number v-model="form.passData.touchRecognitionReturnTime" :min="5" :step="1" :max="30"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelBackLater')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('touchRecognitionTimeout') && form.passData.touchRecognition">
                <!--超时返回-->
                <el-input-number v-model="form.passData.touchRecognitionTimeout" :min="5" :step="1" :max="30"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelSaveElecMode')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('saveElecMode')">
                <!--省流模式-->
                <el-select size="small" class="filter-item" v-model="form.passData.saveElecMode" style="width:224px" >
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelTemperatureDetect')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('temperatureDetect')">
                <!--体温检测-->
                <el-select size="small" class="filter-item" v-model="form.passData.temperatureDetect" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelFeverTemperature')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('feverTemperature') && form.passData.temperatureDetect">
                <!--体温检测阈值(℃)-->
                <el-input-number v-model="form.passData.feverTemperature" :min="34.5" :precision="2" :step="0.1" :max="42.5"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelNoAccessToFevers')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('noAccessToFevers') && form.passData.temperatureDetect">
                <!--体温异常禁止通行-->
                <el-select size="small" class="filter-item" v-model="form.passData.noAccessToFevers" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelShowThermalScreen')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('showThermalScreen') && form.passData.temperatureDetect">
                <!--热力图展示-->
                <el-select size="small" class="filter-item" v-model="form.passData.showThermalScreen" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelIndoorTemperature')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('indoorTemperature') && form.passData.temperatureDetect">
                <!--室内温度(℃)-->
                <el-input-number v-model="form.passData.indoorTemperature" :min="5.0" :precision="2" :step="0.1" :max="45.0"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelTemperatureDetectDistance')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('temperatureDetectDistance') && form.passData.temperatureDetect">
                <!--体温检测距离(m)-->
                <el-input-number v-model="form.passData.temperatureDetectDistance" :min="0.5" :precision="2" :step="0.1" :max="1.5"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelQuickDetectMode')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('quickDetectMode') && form.passData.temperatureDetect">
                <!--快速测温模式-->
                <el-select size="small" class="filter-item" v-model="form.passData.quickDetectMode" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelMaskDetect')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('maskDetect')">
                <!--口罩识别-->
                <el-select size="small" class="filter-item" v-model="form.passData.maskDetect" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.labelNoAccessWithoutMask')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('noAccessWithoutMask') && form.passData.maskDetect">
                <!--未戴口罩禁止通行-->
                <el-select size="small" class="filter-item" v-model="form.passData.noAccessWithoutMask" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </div>

            <div>
              <div class="config-type">
                <!--自定义设置-->
                {{$t('devicemanagement.contCustomSettings')}}
                <hr>
                <br>
              </div>
              <el-form-item :label="$t('devicemanagement.contDeviceWelcomes')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('welcomeTip')">
                <!--设备主欢迎语-->
                <el-input v-model.trim="form.passData.welcomeTip" class="input-width" autocomplete="off" maxlength="40"></el-input>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contWelcomes')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('verifySuccessTip')">
                <!--识别成功页欢迎语-->
                <el-input v-model.trim="form.passData.verifySuccessTip" class="input-width" autocomplete="off" maxlength="40"></el-input>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contFailureMessage')" v-if="isCurrentTypeHasFormItem('verifyFaultTip')"
                            :label-width="formLabelWidth">
                <!--识别失败提示语-->
                <el-input v-model.trim="form.passData.verifyFaultTip" class="input-width" autocomplete="off" maxlength="40"></el-input>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contExtraDisplayFields')"
                            :label-width="formLabelWidth" v-if="form.passData.passDeviceType != 4"> -->
              <el-form-item :label="$t('devicemanagement.contExtraDisplayFields')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('showUserInfo')">
                <!--识别成功页额外展示字段-->
                <el-select size="small"
                           multiple
                           collapse-tags
                           class="filter-item"
                           v-model="form.passData.showUserInfo"
                           style="width:224px">
                  <el-option v-for="item in passFormData.showUserInfoList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contExtraImage')" v-if="isCurrentTypeHasFormItem('useShowAvatar')"
                            :label-width="formLabelWidth">
                <!--识别成功页展示头像-->
                <el-select size="small" class="filter-item" v-model="form.passData.useShowAvatar" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contAdditionalDisplay')" v-if="isCurrentTypeHasFormItem('showUserName')"
                            :label-width="formLabelWidth">
                <!--识别成功后额外展示姓名-->
                <el-select size="small" class="filter-item" v-model="form.passData.showUserName" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contBlacklistPrompt')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('blackListTip')">
                <!--黑名单提示语-->
                <el-input v-model.trim="form.passData.blackListTip" class="input-width" autocomplete="off" maxlength="40"></el-input>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contIsTheBlacklistOpen')"  v-if="isCurrentTypeHasFormItem('blackListOpen')"
                            :label-width="formLabelWidth">
                <!--黑名单是否开门-->
                <el-select size="small" class="filter-item" v-model="form.passData.blackListOpen" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </div>


            <div>
              <div class="config-type">
                <!--人脸设置-->
                {{$t('devicemanagement.contFaceSet')}}
                <hr>
                <br>
              </div>
              <el-form-item :label="$t('devicemanagement.contVivoDetectionThreshold')" v-if="isCurrentTypeHasFormItem('liveness')"
                            :label-width="formLabelWidth">
                <!--活体检测-->
                <el-select size="small" class="filter-item" v-model="form.passData.liveness" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contInVivoDetectionThreshold')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('livenessThreshold')">
                <!--活体检测阈值-->
                <el-input-number v-model="form.passData.livenessThreshold" :min="0" :precision="2" :step="0.01" :max="1"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contFaceRecognitionThreshold')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('verifyThreshold')">
                <!--人脸识别阈值-->
                <el-input-number v-model="form.passData.verifyThreshold" :min="0" :precision="2" :step="0.01" :max="1"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contThresholdWitnessContrast')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('certificateThreshold')">
                <!--人证对比阈值-->
                <el-input-number v-model="form.passData.certificateThreshold" :min="0" :precision="2" :step="0.01" :max="1"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contFaceRecognitionDistance')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('recognitionDistance')">
                <!--人脸识别距离-->
                <el-input-number v-model="form.passData.recognitionDistance" :min="0.5" :precision="1" :step="0.1" :max="2"></el-input-number>
              </el-form-item>
            </div>



            <div>
              <div class="config-type">
                <!--门禁设置-->
                {{$t('devicemanagement.contEntranceGuardSettings')}}
                <hr>
                <br>
              </div>
              <el-form-item :label="$t('devicemanagement.contOpenType')" v-if="isCurrentTypeHasFormItem('openDoorType')"
                            :label-width="formLabelWidth">
                <!--开门方式-->
                <el-select size="small" class="filter-item" v-model="form.passData.openDoorType" style="width:224px">
                  <el-option v-for="item in passFormData.openDoorTypeList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item prop="passData.networkRelayAddress" :label="$t('devicemanagement.contNetworkRelayAddress')" :label-width="formLabelWidth" v-if="form.passData.openDoorType == 4"> -->
              <el-form-item prop="passData.networkRelayAddress" :label="$t('devicemanagement.contNetworkRelayAddress')"
                :rules="[{required: true, trigger: 'blur', validator: requiredIP}]"
                :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('networkRelayAddress') && form.passData.openDoorType == 4">
                <!-- 网络继电器地址-->
                <el-input v-model.trim="form.passData.networkRelayAddress" class="input-width" autocomplete="off" maxlength="18"></el-input>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contOpenTime')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('keepDoorOpenDuration') && form.passData.openDoorType">
                <!--开门时间(s)-->
                <el-input-number v-model="form.passData.keepDoorOpenDuration" :min="1" :max="30"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contRerecognitionInterval')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('openInterval')">
                <!--再次识别间隔(s)-->
                <el-input-number v-model="form.passData.openInterval" :min="1" :max="30"></el-input-number>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contGPIOAInput')"
                            :label-width="formLabelWidth"  v-if="form.passData.passDeviceType == 1||form.passData.passDeviceType == 2"> -->
              <el-form-item :label="$t('devicemanagement.contGPIOAInput')"
                            :label-width="formLabelWidth"  v-if="isCurrentTypeHasFormItem('gpioA')">
                <!--GPIOA-输出口-->
                <el-select size="small" class="filter-item" v-model="form.passData.gpioA" style="width:224px">
                  <el-option v-for="item in passFormData.gpioA" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contGPIOBInput')"
                            :label-width="formLabelWidth" v-if="form.passData.passDeviceType == 1||form.passData.passDeviceType == 2"> -->
              <el-form-item :label="$t('devicemanagement.contGPIOBInput')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('gpioB')">
                <!--GPIOB-输出口-->
                <el-select size="small" class="filter-item" v-model="form.passData.gpioB" style="width:224px">
                  <el-option v-for="item in passFormData.gpioB" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contGPIOCInput')"
                            :label-width="formLabelWidth" v-if="form.passData.passDeviceType == 1||form.passData.passDeviceType == 2"> -->
              <el-form-item :label="$t('devicemanagement.contGPIOCInput')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('gpioC')">
                <!--GPIOC-输出口-->
                <el-select size="small" class="filter-item" v-model="form.passData.gpioC" style="width:224px">
                  <el-option v-for="item in passFormData.gpioC" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contWiganInput')" v-if="isCurrentTypeHasFormItem('wiganInput')"
                            :label-width="formLabelWidth">
                <!--韦根输入口-->
                <el-select size="small" class="filter-item" v-model="form.passData.wiganInput" style="width:224px">
                  <el-option v-for="item in passFormData.wiganInputList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <!-- <el-form-item :label="$t('devicemanagement.contBuzzerAlarmSwitch')"
                            :label-width="formLabelWidth" v-if="form.passData.passDeviceType == 1||form.passData.passDeviceType == 2"> -->
              <el-form-item :label="$t('devicemanagement.contBuzzerAlarmSwitch')"
                            :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('buzzerStatus')">
                <!--蜂鸣器报警开关-->
                <el-select size="small" class="filter-item" v-model="form.passData.buzzerStatus" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.doorSensorTimeout')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('doorSensorTimeout')">
                <!--门磁超时时间（s）-->
                <el-input-number v-model="form.passData.doorSensorTimeout" :min="1" :step="1" :max="255"></el-input-number>
              </el-form-item>
            </div>

            <div>
              <div class="config-type">
                <!--系统设置-->
                {{$t('devicemanagement.contSystemSettings')}}
                <hr>
                <br>
              </div>
              <el-form-item :label="$t('devicemanagement.contSystemVoice')" v-if="isCurrentTypeHasFormItem('languageType')"
                            :label-width="formLabelWidth">
                <!--系统语音-->
                <el-select size="small" class="filter-item" v-model="form.passData.languageType" style="width:224px">
                  <el-option v-for="item in passFormData.languageTypeList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item  :label="$t('devicemanagement.contAutomaticStandby')" v-if="isCurrentTypeHasFormItem('standbyOpen')"
                             :label-width="formLabelWidth">
                <!--自动待机-->
                <el-select size="small" class="filter-item" v-model="form.passData.standbyOpen" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contStandbyTime')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('waitTime')">
                <!--待机时长(min)-->
                <el-input-number v-model="form.passData.waitTime" :min="3" :max="30"></el-input-number>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contAutoReboot')" v-if="isCurrentTypeHasFormItem('autoReboot')"
                            :label-width="formLabelWidth">
                <!--自动重启-->
                <el-select size="small" class="filter-item" v-model="form.passData.autoReboot" style="width:224px">
                  <el-option v-for="item in passFormData.switchList" :key="item.value" :value="item.value"
                             :label="item.name"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item :label="$t('devicemanagement.contRestartTime')" v-if="isCurrentTypeHasFormItem('rebootTime')"
                            :label-width="formLabelWidth">
                <!--重启时间-->
                <el-time-picker
                  v-model="form.passData.rebootTime"
                  :picker-options="{
                    selectableRange: '00:00:00 - 23:59:59'
                  }"
                  value-format='HH:mm:ss'
                  style="width:224px">
                </el-time-picker>
              </el-form-item>
              <el-form-item prop="passData.wifiSsid"  :label="$t('devicemanagement.wifiSsid')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('wifiSsid')">
                  <!--WIFI SSID-->
                  <el-input v-model.trim="form.passData.wifiSsid" class="input-width"  maxlength="30"></el-input>
                </el-form-item>
                <el-form-item prop="passData.wifiPwd"  :label="$t('devicemanagement.wifiPwd')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('wifiPwd')">
                  <!--WIFI 密码-->
                  <el-input v-model.trim="form.passData.wifiPwd" class="input-width"  maxlength="30"></el-input>
                </el-form-item>
              <el-form-item prop="passData.wakeDistance"  :label="$t('devicemanagement.wakeDistance')" :label-width="formLabelWidth" v-if="isCurrentTypeHasFormItem('wakeDistance')">
                <!--待机唤醒距离（cm）-->
                <el-input-number v-model="form.passData.wakeDistance" :min="50" :step="10" :max="200"></el-input-number>
              </el-form-item>
            </div>


          </div>


        </div>

          <!--&lt;!&ndash;          人像库&ndash;&gt;-->
        <div>
          <el-form-item :label="$t('rule.labelImageLibraryList')" :label-width="formLabelWidth" v-if="form.deviceType==3">
          <PortraitSelect :data="propTreeData" @selected="handleSelectedP" show-checkbox
                          :dataObj="dataLibraryIdsObj"/>
        </el-form-item>
        </div>



        <!--<div v-if="dataObj.showNoSenseSwitch">-->
        <div>
          <!--无感门禁-->
          <hr v-if="form.deviceType==1 || form.deviceType==4" :title="$t('devicemanagement.entranceGuard')">
          <br>
          <el-form-item v-if="form.deviceType==1 || form.deviceType==4" :label="$t('devicemanagement.noSenseSwitch')"
            prop="noSenseSwitch"
            :label-width="formLabelWidth2"
          >
            <el-switch size="mini" @change="handleNoSenseSwitch" v-model="form.noSenseSwitch" active-value=1 inactive-value=0 active-color="#13ce66" inactive-color="#C4C4C4"></el-switch>
          </el-form-item>
        </div>

        <div v-if="form.noSenseSwitch == '1'">
          <el-form-item v-if="form.deviceType==1 || form.deviceType==4" :label="$t('devicemanagement.noSenseIp')" prop="noSenseIp" :label-width="formLabelWidth">
            <el-input size="small" v-model="form.noSenseIp" autocomplete="off" :placeholder="$t('devicemanagement.noSenseIpTips')"></el-input>
          </el-form-item>
          <el-form-item v-if="form.deviceType==1 || form.deviceType==4" :label="$t('devicemanagement.noSensePort')" prop="noSensePort" :label-width="formLabelWidth">
            <el-input @input="inputNoSensePortNum" size="small" v-model="form.noSensePort" autocomplete="off"></el-input>
          </el-form-item>
        </div>

      </el-form>
      </div>
      <div slot="footer" class="dialog-footer" style="padding-top:16px">
        <el-button type="primary" @click="handleEditDevice" :loading="btnLoading">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>

    <!-- 设备添加地图点位 -->
    <el-dialog :title="$t('devicemanagement.titleDeviceLocation')" width="80%"
      :visible.sync="isMapDevice"
      v-if="isMapDevice"
      class="dialog-track">
      <el-form :model="form" style="width:100%;min-height:530px">
        <map-device
          :handleType="form.deviceId == '' ? 'add' : 'edit'"
          :deviceInfo="deviceInfo"
          :key="deviceInfo.length != 0 ? deviceInfo[0].id : ''"
          @deviceVal="getDevicePlace"
        />
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="mapDeviceConfirm" type="primary">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button @click="mapDeviceCancle" type="info">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import EditAddGroup from "@/components/deviceUserAdd/editAddGroup.vue";
  import TreeSelect from "@/components/deviceUserAdd/index.vue";
  import {DeviceModule} from '@/store/modules/device';
  import {isEmpty} from '@/utils/validate';
  import MediaPlayer from '@/components/media-player/index.vue';
  import {UserModule} from '@/store/modules/user';
  import MapDevice from '../map/map-device.vue';
  import {AppModule} from '@/store/modules/app';
  import {deviceType as deviceTypeList }  from '@/utils/constants';
  import {mDeviceType as mDeviceTypeList }  from '@/utils/constants';
  import historyApi from "@/api/history-record";
  import ChooseTree from "@/views/manage/device/components/choose-tree.vue";
  import {passDeviceType as passDeviceTypeList }  from '@/utils/constants';
  import {passForm} from '@/.././public/deviceData.js';
  import i18n from '@/lang/index';
  import {ruleThresholdOptions} from '@/utils/constants';
  import LibraryToTimezone from './components/libraryToTimezone.vue';
  import formItemConfig from './components/constprops';
  import ImageSelect from '@/components/image-select/index.vue';
  import PortraitSelect from "@/views/manage/device/components/tree-select.vue";
  import {PortraitModule} from "@/store/modules/portrait";
  import {processImgurl} from '@/utils/image';
  var _ = require('lodash/lang');

  let vm = null as any

  const requireDeviceName = (rule, value = '', callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateDeviceName')))
    } else {
      callback()
    }
  }

  const requiredTip = (rule, value = '', callback) => {
    let flag = 0;
    let regEnUp = /[A-Z]+/,//大写字母
      regEnLow = /[a-z]+/,//小写字母
      regNum = /[0-9]+/;//数字
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    }else if(value){
      if(regEnUp.test(value)){
        flag += 1;
      }
      if (regEnLow.test(value)){
        flag += 1;
      }
      if (regNum.test(value)) {
        flag += 1;
      }

    }
    if (flag == 0){
      callback(new Error(vm.$t('devicemanagement.validateErr')))
    }else{
      callback()
    }
  }

  const requiredPassPwd = (rule, value = '', callback) => {
    let regEnUp = /[A-Z]+/,//大写字母
      regEnLow = /[a-z]+/,//小写字母
      regNum = /[0-9]+/,//数字
      regEnSymbol = /[-`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im;//英文特殊字符
    // regEnSymbol = /[`~!@#$%^&*()_=+{}:;'"\/<,.>?[\]]/im,//英文特殊字符
    // regCnSymbol = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im;//中文特殊字符
    if (value === '' || value == null) {
      vm.isRotate = true
      callback(new Error(vm.$t('form.texterrPasswordPolicy')))
    } else if (value.length < 8) {
      vm.isRotate = true
      callback(new Error(vm.$t('form.texterrPasswordPolicy')))//请输入8位数以上的密码
    }
    let i = 0;
    if (regEnUp.test(value)) {
      i++;
    }
    if (regEnLow.test(value)) {
      i++;
    }
    if (regNum.test(value)) {
      i++;
    }
    if (regEnSymbol.test(value)) {
      i++;
    }
    if (i < 3) {
      callback(new Error(vm.$t('form.texterrPasswordPolicy')))//密码格式不正确，请重新输入
    } else {
      callback()
    }
  }

  const requiredUsername = (rule, value = '', callback) => {
    let flag = 0;
    let regEnUp = /[A-Z]+/,//大写字母
      regEnLow = /[a-z]+/,//小写字母
      regNum = /[0-9]+/,//数字
      re3 = /\_+/g as any;
    if (value === '') {
      vm.isRotate = true
      callback(new Error(vm.$t('form.texterrUsernamePolicy')))
    }else if(value){
      if (value.length < 6) {
        vm.isRotate = true
        callback(new Error(vm.$t('form.texterrUsernamePolicy')))
      }
      if(regEnUp.test(value)){
        flag += 1;
      }
      if (regEnLow.test(value)){
        flag += 1;
      }
      if (regNum.test(value)){
        flag += 1;
      }
      if (re3.test(value)){
        flag += 1;
      }
      if (flag === 0){
        vm.isRotate = true
        callback(new Error(vm.$t('form.texterrUsernamePolicy')))
      }else{
        callback()
      }
    }
  }

  const requiredVideoPath = (rule, value = '', callback) => {

    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    }else if (value.substring(0, 7) != 'rtsp://') {
        callback(new Error(vm.$t('devicemanagement.rtspCheck')))
    } else {
      callback()
    }
  }

  const requiredIP = (rule, value = '', callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    }
    let flag = false;
    let re = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/ as any;
    if (re.test(value)) {
      if ((RegExp.$1 as any) < 256 && (RegExp.$2 as any) < 256 && (RegExp.$3 as any) < 256 && (RegExp.$4 as any) < 256)
        flag = true;
    }
    if (!flag) {
      callback(new Error(vm.$t('devicemanagement.deviceIpValid')))
    } else {
      callback()
    }
  }

  const requiredPort = (rule, value, callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    }
    if (value <= 0 || value > 65535) {
      callback(new Error(vm.$t('devicemanagement.devicePortValid')))
    } else {
      callback()
    }
  }
  const requiredchooseDevice = (rule, value, callback) => {
    if (value === ''||value == null) {
      callback(new Error(vm.$t('devicemanagement.chooseDevice')))
    } else {
      callback()
    }
  }

  const defaultThreshold = 0.9;


  @Component({
    components: {
      ChooseTree,
      TreeSelect,
      MediaPlayer,
      MapDevice,
      EditAddGroup,
      LibraryToTimezone,
      ImageSelect,
      PortraitSelect
    },
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    },

    computed: {
      rulesList: function () {
        let that = this as any;
        if (that.form.deviceType == 1 && that.form.streamType == 'RTSP') {
          return that.rules1
        } else if (that.form.deviceType == 1 && that.form.streamType == 'ONVIF') {
          return that.rules2
        } else if (that.form.deviceType == 2||that.form.deviceType == 5) {
          return that.rules3
        }else if (that.form.deviceType == 4) {
          return that.rules4
        } else if(that.form.deviceType == 3){
          return that.rules6
        } else if (that.form.deviceType  == 6) {
          return that.rules5
        }
      },
      width:function(){
        let that = this as any;
        return that.language == 'en' ? '684px' : '584px';
      },
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '210px' : '170px';
      },
      formLabelWidth2: function () {
        let that = this as any;
        return that.language == 'en' ? '310px' : '260px';
      },
      codeTypeArray: function () {
        let that = this as any;
        return [{
          name: that.$t('devicemanagement.contDirectConnection'),
          value: 1
        }, {name: that.$t('devicemanagement.contTranscode'), value: 2}]
      }
    },
  })
  export default class EditDevice extends Vue {
    get language() {
      return AppModule.language;
    }

    $refs!:{
      librarytotimezone:HTMLFormElement,
      editaddgroup:HTMLFormElement
    }

    processImgurl:any=processImgurl;

    isEmpty:any=isEmpty;

    requiredIP:any=requiredIP;

    btnLoading = false;
    isMapDevice = false;
    deviceInfo = [] as any;
    defaultDevice = [] as any;
    rules1 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      rtspAddress: [{required: true, trigger: 'blur', validator: requiredVideoPath}],
      emptyVal: [{required: true, trigger: 'blur'}],
      noSenseIp: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSensePort:[{required: true, trigger: 'blur', validator: requiredPort}],
    };
    rules2 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      ip: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSenseIp: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSensePort:[{required: true, trigger: 'blur', validator: requiredPort}],
      port: [{required: true, trigger: 'blur', validator: requiredPort}],
      username: [{required: true, trigger: 'blur', validator: requiredTip}],
      password: [{required: true, trigger: 'blur', validator: requiredTip}],
      emptyVal: [{required: true, trigger: 'blur'}],
    };
    rules3 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      emptyVal: [{required: true, trigger: 'blur'}],
    };
    rules4 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      ip: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSenseIp: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSensePort:[{required: true, trigger: 'blur', validator: requiredPort}],
      port: [{required: true, trigger: 'blur', validator: requiredPort}],
      username: [{required: true, trigger: 'blur', validator: requiredTip}],
      password: [{required: true, trigger: 'blur', validator: requiredTip}],
      emptyVal: [{required: true, trigger: 'blur'}],
    };

    rules6 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      ip: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSenseIp: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSensePort:[{required: true, trigger: 'blur', validator: requiredPort}],
      port: [{required: true, trigger: 'blur', validator: requiredPort}],
      username: [{required: true, trigger: 'blur', validator: requiredTip}],
      password: [{required: true, trigger: 'blur', validator: requiredTip}],
      emptyVal: [{required: true, trigger: 'blur'}],
      'mData.mVersion': [{required: true, trigger: 'change', validator: requiredchooseDevice}],
    };
    // deviceTypeArray = [{name: 'Camera', value: 1}, {name: 'SenseKeeper', value: 2},{name: 'SenseDLC', value: 4},{name: 'SenseID', value: 5}];/*, 'SenseNebula-M', 'SenseDLC'*/
    deviceTypeArray:any[] = deviceTypeList;
    mDeviceTypeArray:any[] = mDeviceTypeList;
    rules5 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      verifyThreshold: [{required: true, trigger: 'blur', message: i18n.tc('form.texterrEnterThreshold')}],
      'passData.passDeviceType': [{required: true, trigger: 'change', validator: requiredchooseDevice}],
      // 'passData.networkRelayAddress':[{required: true, trigger: 'blur', validator: requiredIP}],
      emptyVal: [{required: true, trigger: 'blur'}],
      // 'passData.passUsername': [{required: true, trigger: 'blur', validator: requiredUsername}],
      'passData.passPassword': [{required: true, trigger: 'blur', validator: requiredPassPwd}],
    };
    // deviceTypeArray = [{name: 'Camera', value: 1}, {name: 'SenseKeeper', value: 2},{name: 'SenseDLC', value: 4},{name: 'SenseID', value: 5}];/*, 'SenseNebula-M', 'SenseDLC'*/

    passDeviceTypeArray:any[] = passDeviceTypeList;
    attributeArray = ['RTSP', 'ONVIF'];
    transportProtocolArray = ['TCP', 'UDP'];
    dialogShowVisible = false;
    showVideo = false as any;
    treeData = [];
    dataUserIdsObj = {
      userIds: [],
      defaultIds: []
    } as any;
    dataLibraryIdsObj = {
      libraryIds: [],
      defaultIds: []
    } as any;
    tempAddressLocal={
      floorId:'',
      point:[],
      floorName:''
    }as any
    // 厂商信息
    manufacturerArray = [];
    manufacturerNum = 0;
    isRotate = false;//控制箭头旋转

    passFormData = passForm

    librarytotimezoneData:any[]=[];

    watchList:any=[];//黑白名单人像库
    labraryIdsList:any = [];


    created() {
      vm = this as any;
    }

    @Prop(Object) dataObj!: any[];
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    //编辑的表单里的值
    form = {
      value1:"",
      devicePlace: "",
      deviceId: "",
      deviceType: 1,//设备类型
      name: "",//名称
      ID: "",//ID
      groupId: '',//分组id
      groupName: '',
      point: "",//点位
      streamType: 'RTSP',//类型
      codeType: 1,//编码类型
      protocolType: "TCP",//传输协议 TCP/UDP
      rtspAddress: "",//rtsp视频地址
      port: "",
      username: "",
      password: "",
      ip: "",
      userIds: [],
      floorId: '',
      floorName: '',
      emptyVal: '123',
      manufacturer:1,//厂商

      noSenseIp:'',
      noSensePort:'',
      noSenseSwitch:0,

      // 防疫版
      mData:{
        mVersion:1,
      } as any,
      verifyThreshold:defaultThreshold,

      //1.5.0-patch
      passUsername:'',
      passPassword:'',
      networkRelayAddress:'',//网络继电器地址
      passData:{passDeviceType: null},
      // passData: {
      //   passDeviceType: null,//前端比对设备类型：1–pass，2–passPro，3–keeper，4–ID
      //   passUsername:'',
      //   passPassword:'',
      //   deviceRunType:1,//运行状态
      //   useMode:1,//模式选择
      //   mode:9,//核验模式
      //   fillLight:1,//智能补光灯
      //   voiceBroadcast:1,//语音播报
      //   saveElecMode:1,//省流模式
      //   welcomeTip:'',//设备主欢迎语
      //   verifySuccessTip:'',//识别成功页欢迎语
      //   verifyFaultTip:'',//识别失败提示语
      //   showUserInfo:[],//识别成功页额外展示字段
      //   useShowAvatar:1,//识别成功后展示头像
      //   showUserName:1,//识别成功后展示姓名
      //   blackListTip:'',//黑名单提示语
      //   blackListOpen:0,//黑名单是否开门
      //   liveness:1,//活体检测
      //   livenessThreshold:0.98,//活体检测阈值
      //   verifyThreshold:0.90,//人脸识别阈值
      //   certificateThreshold:0.60,//人证对比阈值
      //   recognitionDistance:1.5,//人脸识别距离
      //   openDoorType:0,//开门方式
      //   networkRelayAddress:'',//网络继电器地址
      //   keepDoorOpenDuration:6,//开门时间(s)
      //   openInterval:5,//二次开门时间间隔
      //   gpioA:1,//gpioA
      //   gpioB:1,//gpioB
      //   gpioC:1,//gpioC
      //   wiganInput:1,//韦根输入
      //   buzzerStatus:1,//蜂鸣器报警开关
      //   languageType:1,//系统语言
      //   standbyOpen:1,//自动待机
      //   waitTime:5,//待机时长(min)
      //   autoReboot:1,//自动重启
      //   rebootTime:'02:00:00',//重启时间
      // }
    } as any;
    formBackups = {
      value1:"",
      devicePlace: "",
      deviceId: "",
      deviceType: 1,//设备类型
      name: "",//名称
      ID: "",//ID
      groupId: '',//分组id
      groupName: '',
      point: "",//点位
      streamType: 'RTSP',//类型
      codeType: 1,//编码类型
      protocolType: "TCP",//传输协议 TCP/UDP
      rtspAddress: "",//rtsp视频地址
      port: "",
      username: "",
      password: "",
      ip: "",
      userIds: [],
      floorId: '',
      floorName: '',
      emptyVal: '123',
      manufacturer:1,//厂商

      noSenseIp:'',
      noSensePort:'',
      noSenseSwitch:0,
      verifyThreshold:defaultThreshold,
      //1.5.0-patch
      passUsername:'',
      passPassword:'',
      networkRelayAddress:'',//网络继电器地址
      mData:{
        mVersion:1,
      } as any,
      passData:{passDeviceType: null},
      // passData: {
      //   passDeviceType: null,//前端比对设备类型：1–pass，2–passPro，3–keeper，4–ID
      //   passUsername:'',
      //   passPassword:'',
      //   deviceRunType:1,//运行状态
      //   useMode:1,//模式选择
      //   mode:9,//核验模式
      //   fillLight:1,//智能补光灯
      //   voiceBroadcast:1,//语音播报
      //   saveElecMode:1,//省流模式
      //   welcomeTip:'',//设备主欢迎语
      //   verifySuccessTip:'',//识别成功页欢迎语
      //   verifyFaultTip:'',//识别失败提示语
      //   showUserInfo:[],//识别成功页额外展示字段
      //   useShowAvatar:1,//识别成功后展示头像
      //   showUserName:1,//识别成功后展示姓名
      //   blackListTip:'',//黑名单提示语
      //   blackListOpen:0,//黑名单是否开门
      //   liveness:1,//活体检测
      //   livenessThreshold:0.98,//活体检测阈值
      //   verifyThreshold:0.90,//人脸识别阈值
      //   certificateThreshold:0.60,//人证对比阈值
      //   recognitionDistance:1.5,//人脸识别距离
      //   openDoorType:0,//开门方式
      //   networkRelayAddress:'',//网络继电器地址
      //   keepDoorOpenDuration:6,//开门时间(s)
      //   openInterval:5,//二次开门时间间隔
      //   gpioA:1,//gpioA
      //   gpioB:1,//gpioB
      //   gpioC:1,//gpioC
      //   wiganInput:1,//韦根输入
      //   buzzerStatus:1,//蜂鸣器报警开关
      //   languageType:1,//系统语言
      //   standbyOpen:1,//自动待机
      //   waitTime:5,//待机时长(min)
      //   autoReboot:1,//自动重启
      //   rebootTime:'02:00:00'//重启时间
      // },

      //小盒子二期新增
      latitudeLongitude:'',//经纬度
      libraryIds: [],//人像库
      protocolType2:'HTTP',//M的协议
    } as any;
    selectGroupObj = {} as any;
    thresholdOptions:any=ruleThresholdOptions;

    propTreeData = [
      {
        id: 'root',
        libraryName: '白名单',
        children: []
      },
      {
        id: 'root',
        libraryName: '黑名单',
        children: []
      }];
    httpTypeArray = [
      {name: 'HTTP',
        value: 'HTTP'},
      {name: 'HTTPS',
        value: 'HTTPS'},
    ];

    handleSelected(obj) {
      this.form.userIds = obj.userIds;
      this.dataUserIdsObj = obj;
    }
    isCurrentTypeHasFormItem(prop){
      let isHas = false;
      if(this.form.passData.passDeviceType){
        console.log(this.form.passData.passDeviceType)
        let current_type_code = this.passDeviceTypeArray.find(de=>de.value == this.form.passData.passDeviceType).code;
        console.log(current_type_code+'Props')
        isHas = formItemConfig[current_type_code+'Props'].hasOwnProperty(prop)?true:false;
      }
      return isHas;
    }
    initDeviceProps(){
      if(this.passDeviceTypeArray.find(de=>de.value == this.form.passData.passDeviceType)){
        let current_type_code = this.passDeviceTypeArray.find(de=>de.value == this.form.passData.passDeviceType).code;
        let current_props = formItemConfig[current_type_code+'Props'];
        for(let key in current_props){
          this.formBackups.passData[key] = current_props[key];
          this.$set(this.form.passData,key,current_props[key]);
        }
      }
    }
    getSubmitFormPropsData(params){
      let data:any={};
      let current_type_code = this.passDeviceTypeArray.find(de=>de.value == this.form.passData.passDeviceType).code;
      let current_props = formItemConfig[current_type_code+'Props'];
      for(let key in current_props){
        data[key] = params[key];
      };
      return data;
    }
    getPropUseModeOptions(){
      //8 火神/13 风神/6 passC 的模式选择都改为"单人模式/多人模式" //sensen
      let options:any = this.passFormData.modeSelectionList;
      (this.form.passData.passDeviceType == 1
      || this.form.passData.passDeviceType == 9)
      && (options = this.passFormData.modeSelectionList);

      (this.form.passData.passDeviceType == 2
      || this.form.passData.passDeviceType == 3
      || this.form.passData.passDeviceType == 6
      || this.form.passData.passDeviceType == 8
      || this.form.passData.passDeviceType == 13
      || this.form.passData.passDeviceType == 4)
      && (options = this.passFormData.modeSelectionList2);
      console.log(options)
      return options;
    }
    customImagesSelect(base64){
      this.form.passData.backgroundImg = base64;
    }
    getProopModeOptions(){
      let options:any = this.passFormData.checkPatternList;
      options = this.form.passData.passDeviceType == 5?this.passFormData.checkPatternList2:this.passFormData.checkPatternList;
      return options;
    }

    handleSelectedP(obj) {
      this.form.libraryIds = obj.libraryIds;
      this.dataLibraryIdsObj = obj;
    }

    //输入验证
    inputPortNum(val){
      if(this.verifySize(val)){
        this.form.port = val
      }else{
        this.form.port = '';
      }

    }
    inputNoSensePortNum(val){
      if(this.verifySize(val)){
        this.form.noSensePort = val
      }else{
        this.form.noSensePort = '';
      }
    }
    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([1-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        return true;
      }else{
        return false;
      }
    }


    mounted() {
      // this.searchOrgUserTree();
      // this.initGroupTree();
      this.getFirmsData();
    }

    imgSrcIsBase64(src){
      let reg = /^\s*data:([a-z]+\/[a-z0-9-+.]+(;[a-z-]+=[a-z0-9-]+)?)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s]*?)\s*$/i;
      return reg.test(src);
    }

    //初始化设备树
    initGroupTree() {
      let that = this as any;
      DeviceModule.GetGroupList({keyword: ""}).then((data: any) => {
        that.selectGroupObj.treeData = data.data;
      }).catch((err) => {
        // console.log(err)
      });
    }


    //初始化厂商信息
    getFirmsData(){
      let that = this as any;
      //G厂商
      DeviceModule.queryFirms({isMVendor:0}).then((data: any) => {
        //console.log(data)
        let arr = [] as any;
        for(let i = 0;i < data.length;i++){
          let o = {} as any;
          o.name = data[i].firmName;
          o.value = data[i].id;
          arr.push(o)
        }
        that.manufacturerArray = arr;
        that.form.manufacturer = arr[0].value;
        that.manufacturerNum = arr[0].value;
      }).catch((err) => {
        // console.log(err)
      });
    }

    //选取人像库
    checkoutWatchList(ids){
      this.labraryIdsList=ids
      console.log(ids)
    }

    //获取黑白名单人像库
    fetchWatchList(state){
      //state为true 展开，false 收缩
      if(this.watchList.length==0){
        historyApi.fetchLibrary().then((data)=>{
          let obj1={
            libraryName:this.$t("rule.contWhitelist"),
            libraryId:"g_1",
            children:(data as any).whitelists
          };
          let obj2={
            libraryName:this.$t("rule.contBlacklist"),
            libraryId:"g_2",
            children:(data as any).blacklists
          };
          this.$set(this.watchList,0,obj1)
          this.$set(this.watchList,1,obj2)
        })
      }
    }

    addDevice(e) {
      if (e) {
        this.isMapDevice = true;
      } else {
        this.isMapDevice = false;
      }
    }

    getDevicePlace(deviceInfo) {
      if(deviceInfo.coords.length > 0){
        this.tempAddressLocal.floorId = deviceInfo.floorId;
        this.tempAddressLocal.point = JSON.stringify(deviceInfo.coords);
        this.tempAddressLocal.floorName = deviceInfo.pathName
      }else{
        this.tempAddressLocal.point = '';
      }
    }

    mapDeviceConfirm() {
      this.form.floorId = this.tempAddressLocal.floorId
      this.form.point = this.tempAddressLocal.point
      this.form.floorName = this.tempAddressLocal.floorName
      this.isMapDevice = false;
      // console.log(this.form)
    }

    mapDeviceCancle() {
      this.isMapDevice = false;
    }

    handleEditDevice() {
      let that = this as any;
      (that.$refs['dataForm'] as any).validate((valid,option) => {
        if (valid) {
          that.handleEditDeviceV();
        }
        if (option){
          // console.log(option)
        }
      })
    }

    handleEditDeviceV() {
      let that = this as any;
      (that.$refs['dataForm'] as any).validate((valid) => {
        if (valid) {
          if (isEmpty(that.form.floorId) || isEmpty(that.form.point)) {
            that.$message.error({showClose: true,message:that.$t('devicemanagement.chooseAddress')})
            return
          }
          that.btnLoading = true;
          // that.form.port = +that.form.port;
          let params = {} as any;
          params.deviceType = that.form.deviceType;
          params.name = that.form.name;
          params.groupId = that.form.groupId;
          params.point = that.form.point;
          params.userIds = that.form.userIds;
          params.floorId = that.form.floorId;
          params.ID = that.form.ID;
          //分配用户暂时没有
          if (that.form.deviceType == 1 && that.form.streamType == 'RTSP') {
            //camera Rtsp
            params.streamType   = that.form.streamType;
            params.rtspAddress  = that.form.rtspAddress;
            params.codeType     = that.form.codeType;
            params.protocolType = that.form.protocolType;

            //无感门禁
            // params.noSenseSwitch = Number(that.form.isContactDoorGuard);
            if (Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch) === 1){
              params.noSenseSwitch = Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch);
              // params.noSenseIp     = that.form.doorGuardIp;
              // params.noSensePort   = that.form.doorGuardPort;
              params.noSenseIp     = that.form.noSenseIp;
              params.noSensePort   = that.form.noSensePort;
            }
          } else if (that.form.deviceType == 1 && that.form.streamType == 'ONVIF') {
            //camera ONVIF
            params.streamType = that.form.streamType;
            params.ip         = that.form.ip;
            params.port       = that.form.port;
            params.username   = that.form.username;
            params.password   = that.form.password;

            //无感门禁
            if (Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch) === 1){
              params.noSenseSwitch = Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch);
              // params.noSenseIp     = that.form.doorGuardIp;
              // params.noSensePort   = that.form.doorGuardPort;
              params.noSenseIp     = that.form.noSenseIp;
              params.noSensePort   = that.form.noSensePort;
            }

          } else if (that.form.deviceType == 2) {
            //SenseKeeper

          } else if (that.form.deviceType == 3) {
            //SenseNebula-M
            //console.log(that.form.port)
            that.form.port = "80";
            params.ip         = that.form.ip;
            params.port       = that.form.port;
            params.username   = that.form.username;
            params.password   = that.form.password;
            params.nebulaVersion   = that.form.mData.mVersion;//新增小盒子设备
            params.latitudeLongitude   = that.form.latitudeLongitude;//经纬度
            params.libraryIds   = that.form.libraryIds;//人像库
            params.protocolType = that.form.protocolType2;//协议

          } else if (that.form.deviceType == 4){
            //SenseDLC
            params.firmId = that.form.manufacturer;
            params.ip = that.form.ip;
            params.port = that.form.port;
            params.username = that.form.username;
            params.password = that.form.password;

            //无感门禁
            if (Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch) === 1){
              params.noSenseSwitch = Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch);
              // params.noSenseIp     = that.form.doorGuardIp;
              // params.noSensePort   = that.form.doorGuardPort;
              params.noSenseIp     = that.form.noSenseIp;
              params.noSensePort   = that.form.noSensePort;
            }
          } else if (that.form.deviceType == 6){
            let configVos = this.$refs.librarytotimezone.getCheckedData();
            if(configVos == null || !configVos.length) {
              that.btnLoading = false;
              return ;
            }
            params.configVos = configVos;
            params.verifyThreshold = that.form.verifyThreshold;
            // SenseGate
            let data = that.form.passData
            data.showUserInfo = (function (){
              let str = [0,0,0,0,0]
              if(data.showUserInfo){
                for (let i of data.showUserInfo){
                  str[i] = 1;
                }
              }
              return str.join("")
            }());

            for(let i in data){
              params[i] = data[i];
            }
            // console.log(params);
            // if (data.passDeviceType == 1){
            //   params.fillLight = null;
            //   params.voiceBroadcast = null;
            // }else if (data.passDeviceType == 2){
            //   params.fillLight = null;
            // }else if (data.passDeviceType == 3){
            //   params.useMode = null;
            //   params.buzzerStatus = null;
            //   params.gpioA = null;
            //   params.gpioB = null;
            //   params.gpioC = null;
            // }else if (data.passDeviceType == 4){
            //   params.fillLight = null;
            //   params.showUserInfo = null;
            //   params.gpioA = null;
            //   params.gpioB = null;
            //   params.gpioC = null;
            // }
            // params = this.getSubmitFormPropsData(params);
            // console.log(params)
            // params['configVos'] = this.$refs.librarytotimezone.getCheckedData();
            // console.log(params)

          }
          //关闭触摸 清空图片
          params['touchRecognition'] == 0 &&  delete params['backgroundImg'] ;
          //新增
          if (isEmpty(that.form.deviceId)) {
            //delete password
            delete params['passPassword']
            // console.log("新增",params)
            DeviceModule.AddDevice(params).then((data: any) => {
              that.$emit("resetDeviceList");
              that.$message({
                showClose: true,
                // message: 'success',
                message: that.$t('devicemanagement.deviceAddSuccess'),
                type: 'success'
              });
              this.dialogShowVisible = false;
            }).catch((err) => {
              // console.log(err)
            }).finally(()=>{
              that.btnLoading = false;
            });
          } else {
            //编辑
            // console.log("开始编辑",that.form)
            DeviceModule.UpdateDevice({params: params, id: that.form.deviceId}).then((data: any) => {
              that.$emit("resetDeviceList");
              // that.$message({
              //   message: 'success',
              //   type: 'success'
              // });
              this.dialogShowVisible = false;
            }).catch((err) => {
              // console.log(err)
            }).finally(()=>{
              that.btnLoading = false;
            })
          }
        }
      })
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      if (val) {
        this.searchOrgUserTree();
        this.initGroupTree();
        // this.getFirmsData();
      }
      if (!val){
        this.defaultDevice = [];
      }
      let data = this.dataObj as any;
      // console.log("拿到父级数据",this.dataObj)
      if (!isEmpty(data.deviceId)) {
        this.selectGroupObj.checked = data.groupId + ',' + data.groupName;
        this.selectGroupObj.checkedLabel = data.groupName;
        if (this.$refs.editaddgroup) {
          (this.$refs.editaddgroup as any).checkedLabelV = data.groupName;
        }
        this.dataUserIdsObj = {
          userIds: data.userIds,
          defaultIds: data.userIds
        }
        this.dataLibraryIdsObj = {
          libraryIds: data.libraryVos?data.libraryVos:[],
          defaultIds: data.libraryVos?data.libraryVos:[]
        }
        // console.log('第一2步');
        this.deviceInfo = [{
          deviceId: data.deviceId,
          floorId: data.floorId,
          floorName: data.floorName
        }]
        this.form.deviceId = data.deviceId
        this.form.deviceType = data.deviceType
        this.form.name = data.deviceName
        this.form.ID = data.deviceCode || ''
        this.form.groupId = data.groupId
        this.form.groupName = data.groupNamen
        this.form.streamType = data.streamType || 'RTSP'
        this.form.rtspAddress = data.rtspAddress || ''
        this.form.codeType = data.codeType || 1
        this.form.protocolType = data.protocolType || 'TCP'
        this.form.port = data.port || ''
        this.form.username = data.username || ''
        this.form.password = data.password || ''
        this.form.ip = data.ip || ''
        this.form.point = data.point
        this.form.floorId = data.floorId
        this.form.floorName = data.floorName
        this.form.verifyThreshold = data.verifyThreshold;
        //新增
        this.form.manufacturer = data.firmId

        //无感门禁
        // console.log("无感1",data)
        this.form.noSenseIp = data.noSenseIp == 0?"":data.noSenseIp
        this.form.noSensePort = data.noSensePort == 0?"":data.noSensePort
        this.form.noSenseSwitch = data.noSenseSwitch+'';

        console.log(this.form.noSenseSwitch)

        //防疫版
        if(data.deviceType == 3){
          this.form.mData.mVersion = data.nebulaVersion;
        }

        this.librarytotimezoneData = data.configVos||[];
        // console.log(this.form.noSenseSwitch)

        // 1.5.0-patch
        if (data.deviceType == 6){
          this.form.passData.passDeviceType = data['passDeviceType'];
          this.$nextTick(()=>{
            let datas = this.form.passData
            for (let i in datas){
              datas[i] = data[i];
            }
            setTimeout(()=>{
              data['passPassword'] && (datas['passPassword'] = data['passPassword'] )
            },0)
            let arrUserInfo = [] as any;
            // debugger
            if (data.showUserInfo) {
              for(let j =0;j< data.showUserInfo.length;j++){
                if (data.showUserInfo[j]>0){
                  arrUserInfo.push(j)
                }
              }
            }
            // console.log(arrUserInfo)
            datas.showUserInfo = arrUserInfo;
          })
        }
        //小盒子二期新增
        this.form.latitudeLongitude=data.latitudeLongitude//经纬度
        this.form.libraryIds=data.libraryVos//人像库
        this.form.protocolType2=data.protocolType//人像库

      } else {
        this.selectGroupObj.checked = data.localClickGroup.id + ',' + data.localClickGroup.name;
        this.selectGroupObj.checkedLabel = data.localClickGroup.name;
        if (this.$refs.editaddgroup) {
          (this.$refs.editaddgroup as any).checkedLabelV = data.localClickGroup.name;
        }
        this.deviceInfo = []

        //TODO： 表单第一次解决冲突完成
        this.form = {
          // 防疫版
          mData:{
            mVersion:1,
          } as any,
        };
        this.form = {
          devicePlace: "",
          deviceId: "",
          deviceType: 1,//设备类型
          passDeviceType: 1,
          name: "",//名称
          ID: "",//ID
          groupId: data.localClickGroup.id,//分组id
          groupName: data.localClickGroup.name,
          point: "",//点位
          streamType: 'RTSP',//类型
          codeType: 1,//编码类型
          protocolType: "TCP",//传输协议 TCP/UDP
          rtspAddress: "",//rtsp视频地址
          port: "",
          username: "",
          password: "",
          ip: "",
          userIds: [],
          floorId: '',
          emptyVal: '123',
          manufacturer:this.manufacturerNum,

          //无感门禁
          noSenseIp:'',
          noSensePort:'',
          noSenseSwitch:'0',

          deviceRunType:1,

          // 防疫版
          mData:{
            mVersion:1,
          } as any,

          //小盒子二期新增
          latitudeLongitude:'',
          // libraryIds: [],//人像库
          protocolType2:'HTTP',
        };
        this.form = _.cloneDeep(this.formBackups);//初始化数据
        this.formInit()//初始化数据
        this.form.manufacturer = this.manufacturerNum
        this.form.groupId = data.localClickGroup.id//分组id
        this.form.groupName = data.localClickGroup.name
        this.librarytotimezoneData = [];
        // this.dataUserIdsObj = {
        //   userIds: [],
        //   defaultIds: [] //rrrr
        // }
        this.dataLibraryIdsObj = {
          libraryIds: data.libraryVos?data.libraryVos:[],
          defaultIds: data.libraryVos?data.libraryVos:[]
        }
        this.dataUserIdsObj = {
          userIds:  this.defaultDevice,
          defaultIds:  this.defaultDevice
        }
      }
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      this.isRotate = false;
      if (!val) {
        this.showVideo = false
        // this.form = this.formBackups//初始化数据
        this.formInit()//初始化数据
        this.$emit("closeEdit")
      }
    }

    //获取用户数
    searchOrgUserTree() {
      let that = this as any;
      UserModule.GetOrgUserTree().then((data: any) => {
        let arr = data.data;
        this.filterData(arr);
        // that.treeData = data.data;
        that.treeData = arr;
      }).catch((err) => {
        // console.log(err)
      });

      let params = {} as any;
      params.keywords = '';
      PortraitModule.SearchLibraries(params).then((data: any)=>{
        console.log(data,'人像库列表');
        this.propTreeData[0].children = data.whitelists;
        this.propTreeData[0].libraryName = that.$t('imagemanagement.contWhiltelist');
        this.propTreeData[1].children = data.blacklists;
        this.propTreeData[1].libraryName = that.$t('imagemanagement.contBlacklist');
      })
    }
    // 筛选
    filterData(arr){
      for (let i = 0;i < arr.length;i++){
        if (arr[i].adminRole&&arr[i].adminRole == 1){//是管理员
          // arr.splice(i,1);
          // i-=1;
          this.defaultDevice.push(arr[i].id)
          arr[i].disabled = true;
        }
        if (arr[i].type == 0&&arr[i].children.length>0){
          this.filterData(arr[i].children);
        }
      }
    }

    handleEditAddGroup(id, name) {
      this.selectGroupObj.checked = id + ',' + name;
      this.selectGroupObj.checkedLabel = name;
      this.form.groupId = id;
      this.form.groupName = name;
    }

    handleNoSenseSwitch(value){
      if(value =="0"){
        this.form.noSenseIp ='';
        this.form.noSensePort='';
        this.form.noSenseSwitch='0';
      }
    }

    formInit(){
      for(let i in this.form){
        if(typeof this.form[i] != 'object'){
          this.form[i] = this.formBackups[i]
        }
      }
      for(let j in this.form.passData){
        if(typeof this.form.passData[j] != 'object'){
          this.form.passData[j] = this.formBackups.passData[j]
        }
      }
    }

    @Watch('form.deviceType')
    onFormDeviceTypeChange() {
      let that = this as any;
      setTimeout(function () {
        if(that.$refs['dataForm']){
          that.$refs['dataForm'].resetFields();
        }
      }, 100)

    }
    @Watch('form.passData.passDeviceType')
    onFormPassDeviceTypeChange(val) {
      // console.log(val)
      val && this.initDeviceProps();
      // let that = this as any;
      // if (val == 2 || val == 4){
      //   that.form.passData.useMode = 3;
      // }else{
      //   that.form.passData.useMode = 1;
      // }
    }

  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .deviceAdd{
    .deviceType6{
      /*width: 536px;*/
      hr{
        //margin-left: -32%;
        //margin-right: -31%;
      }
      .more-config-btn{
        font-weight: 600;
        font-size: 15px;
        text-align: center;
        cursor: pointer;
        user-select: none;
        i{
          transition: all .5s;
        }
        .rotateUp{
          transform: rotateZ(180deg);
        }
        .rotateDown{
          transform: rotateZ(0deg);
        }
      }
      .more-config{
        .config-type{
          font-size: 15px;
          font-weight: 600;
          //margin-left: -17%;
        }
        ::v-deep .el-input-number__decrease{
          background-color: #f5f7fa;
        }
        ::v-deep .el-input-number__increase{
          background-color: #f5f7fa;
        }

      }
      ::v-deep .el-form-item{
        margin-bottom: 30px;
      }

    }
  }
.dialog-track{
  .device-wrapper{
    min-height: 530px;
    .device-view{
      min-height: 530px;
    }
  }
}
  .el-input {
    width: 224px
  }
  .form-item-text{margin-bottom: 4px;}
  .form-group{
    hr{
      margin-left: -10%;
      margin-right: -10%;
    }
  }

  .icon-place {
    font-size: 22px;
    vertical-align: sub;
    color: #c4cce6
  }

  .address-class {
    cursor: pointer;
    width: 224px;
    height: 14px;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #2a5af5;
    border-bottom: 1px solid #2a5af5;
  }

  ::v-deep .el-dialog__footer {
    text-align: center;
  }

  ::v-deep .el-input__inner {
    height: 32px !important;
  }
  ::v-deep .input-width > input {
    width: 224px
  }
  ::v-deep .noclose .imageselsect-imagebox:hover .imageselsect-imagebox-close{
    display: none;
  }
  .rtsp-video {
    position: absolute;
    left: 0px;
    top: 0px;
    z-index: 1;
  }

  .rtsp-video-see-cancel {
    text-align: right;
    position: relative;
    top: 44px;
    z-index: 10;
  }

  .rtsp-video-see {
    width: 570px;
    margin-left: 7px
  }
</style>
