<template>
  <div class="treeselsectradio-container">
    <el-popover
      ref="treeselsectradio-popover"
      placement="bottom"
      trigger="click"
      v-model="visible">
        <div slot="reference"  class="treeselsectradio-selected" >
          <el-input type="text" :placeholder="$t('rule.contPleaseSelect')" readonly v-model="inputText" />
          <!-- <div v-else class="treeselsectradio-selected-text" tabindex="-1">
            <div  :class="['treeselsectradio-selected-contents',type==='border'?'treeselsectradio-selected-contents-border':'']" :style="{width:`calc(${inputWidth} - 15px)`}" >{{ selectedNodes.length>0 ? $t('rule.textboxNumberSelected',{number:selectedNodes.length}):$t('rule.contPleaseSelect')}}</div>
            <span  :class="['treeselsectradio-selected-icon',type==='border'?'treeselsectradio-selected-icon-border':'']" >
              <i class="el-icon-arrow-down" v-show="type==='border'" ></i>
            </span>
          </div> -->
        </div>
        <div class="treeselsectradio-content">
          <el-input
            :placeholder="$t('liveservice.contDeviceSearch')"
            v-model="filterText">
          </el-input>
          <div >
            <el-tree
              :data="data"
              node-key="id"
              ref="tree"
              class="treeselsectradio-tree"
              :filter-node-method="filterNode"
              default-expand-all
              :render-content="renderContent"
              >
            </el-tree>
          </div>

          <!-- <div class="treeselsectradio-btns" >
            <el-button size="mini" type="text" @click="visible = false">{{$t('rule.buttonCancel')}}</el-button>
            <el-button type="primary" size="mini" @click=" ensureSelect ">{{$t('rule.buttonOK')}}</el-button>
          </div> -->
        </div>
    </el-popover>
  </div>
</template>

<script lang="tsx">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import { setTimeout } from 'timers';

@Component({
  components: {

  },
})
export default class TreeSelectRadio extends Vue {

  /* props */
  @Prop(Array) data!: any[];
  @Prop({default: [] }) defaultChechedKeys!: any[];//默认选中

  /* watch */
  @Watch('visible', { immediate: false, deep: false })
  onVisibleChanged(val: boolean, oldVal: boolean) {

  }
  @Watch('filterText', { immediate: false, deep: false })
  onfilterTextChanged(val: string, oldVal: string) {
    this.$refs.tree.filter(val);
  }
  @Watch('radioModel', { immediate: false, deep: false })
  onradioModelChanged(val: any, oldVal: any) {
    this.radioChange(val);
  }
  @Watch('defaultChechedKeys', { immediate: false, deep: false })
  ondefaultChechedKeysChanged(val: any[], oldVal: any[]) {
    if(val.length>0 && val[0]){
      let id = val[0];
      let data = this.$refs.tree.getNode(id).data;
      this.radioModel = data;
    }else{
      this.radioModel = {};
    }
  }
  /* data */
  $refs!: {
    tree: HTMLFormElement
  };
  visible:boolean=false;
  inputText:string="";
  filterText:string="";

  radioModel:any={};
  /* methods */
  mounted() {
    this.radioModel={};
  }
  filterNode(value, data) {
    if (!value) return true;
    return data.name.indexOf(value) !== -1;
  }
  renderContent(h,{node,data,store}){
    node.isLeaf = data.type == 1;
    return  data.type == 1?<el-radio v-model={this.radioModel} label={data} ><span title={data.name}>{data.name}</span></el-radio>
                          :<span title={data.name}>{data.name}</span>
  }
  radioChange(currentLabel){
    if(currentLabel && currentLabel.id){
      this.$emit('check',[currentLabel]);
      this.inputText = currentLabel.name;
    }else{
      this.inputText = this.$tc('rule.contPleaseSelect');
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .treeselsectradio-container{
    display: inline-block;
    position: relative;
    background-color: #fff;
    width: 100%;
  }
  .treeselsectradio-selected{
    // padding: 5px 0;
    position: relative;

    // .treeselsectradio-selected-icon{
    //   background-color: rgba(162, 176, 199, 0.48);
    //   cursor: pointer;
    //   color: #28354d;
    //   padding: 5px 0 6px;
    // }

    // .treeselsectradio-selected-icon-border{
    //   background-color: rgba(162, 176, 199, 0.48);
    //   cursor: pointer;
    //   color: #28354d;
    //   padding: 12px 0 13px;
    //   position: relative;
    //   left: -15px;
    // }
    // .treeselsectradio-selected-text{
    //   border:1px solid #c2cad8;
    //   padding: 5px 0;
    // }
    // .treeselsectradio-selected-text:focus{
    //   border-color:#2a5af5;
    // }
  }
  .treeselsectradio-content{
    .treeselsectradio-btns{
      width: 100%;
      text-align: right;
    }
    .treeselsectradio-tree{
      max-width:300px;
      min-height: 200px;
      max-height: 300px;
      overflow: auto;
    }

  }
  // ::v-deep .el-tree.treeselsectradio-tree{
  //   overflow:auto;
  // }

</style>
