<template>
    <div class="librarytimezone" >
        <div class="librarytimezone-header" >
            <div>{{$tc('devicemanagement.contLabelLibrary')}}</div>
            <div>{{$tc('devicemanagement.contLabelTimezone')}}</div>
        </div>
        <!-- library --> 
        <el-tree
        ref="tree"
        :data="libraryData"
        :render-content="renderLibContent"
        @check="handleLibraryCheck"
        @current-change="handleLibraryCurrentChange"
        node-key='id'
        :show-checkbox="viewModel?false:true">
        </el-tree>
        <!-- timezone -->
        <div v-if="viewModel" class="el-radio-group" >
            <div class="el-radio"  >{{viewcurrentTimezoneName}}</div>
        </div>
        <el-radio-group v-else v-model="timezoneRadio" @change="handleTimezoneRadioChange">
            <el-radio v-for="(timezone,timezoneIndex) in timezoneList" :key="timezoneIndex" :label="timezone.id" :disabled="timezone.disabled">{{timezone.label}}</el-radio>
        </el-radio-group>
    </div>
</template>

<script lang="tsx">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import api from '@/api/device';

@Component({
    components: {
       
    },
})
export default class LibraryToTimezone extends Vue {
    /* props */
    @Prop(Array) data!: any[];
    @Prop({default:false}) viewModel!: boolean;//view
    /* watch */
    @Watch('data',{ immediate: true})
    ondataChange(n,o){
        this.setDefaultData(n);
    }
    /* data */
    $refs!:{
        tree:HTMLFormElement
    }
    libraryData:any[]=[];
    timezoneList:any[]=[];
    timezoneRadio:any='';
    mapping:any={};
    currentLibraryId:any='';
    viewcurrentTimezoneName:string='';
    /* methods */
    mounted(){
        this.getLibsList();
        this.getTimezoneList();
    }
    setDefaultData(data){
        if(data && data.length>0){
            data.forEach(element => {
                this.$set(this.mapping,element.libraryId,element.timezoneId)
            });
        }else{
            this.mapping = {}
        }
    }
    getLibsList(keywords?){
        api.getLibsList(keywords).then(res=>{
        this.libraryData=[];
        res && this.formatLibs(res);
        })
    }
    updateSetMapData(){
        if(this.viewModel === true){ return ;}
        this.$nextTick(()=>{
            this.$refs.tree && this.$refs.tree.setCheckedKeys(this.data.map(i=>i.libraryId))
        })
    }
    formatLibs(res){
        this.libraryData = [{id:-1,label:this.$tc('rule.contWhitelist'),children:[]},{id:-2,label:this.$tc('rule.contBlacklist'),children:[]}];
        res.whitelists && res.whitelists.forEach((item:any)=>{
            if(this.viewModel === true && !this.data.find(it=>it.libraryId == item.libraryId)){
                 return true ;
            }
            this.libraryData[0].children.push({
                id:item.libraryId,
                label:item.libraryName,
                disabled:false
            })
        });
        res.blacklists && res.blacklists.forEach((item:any)=>{
            if(this.viewModel === true && !this.data.find(it=>it.libraryId == item.libraryId)){
                 return true ;
            }
            this.libraryData[1].children.push({
                id:item.libraryId,
                label:item.libraryName,
                disabled:false
            })
        });
        this.updateSetMapData();
    }
    renderLibContent(h, { node, data, store }){
        return  <div class="librarytimezone-tree-leaf" >
                    {data.label}
                    {node.isLeaf && <i class="el-icon-arrow-right librarytimezone-tree-leaf-right" ></i>}
                </div>
    }
    getTimezoneList(){
        this.timezoneList = [];
        api.getTimezoneWithIntervals().then((res:any)=>{
            res && this.formatTimezoneList(res.data);
        })
    }
    formatTimezoneList(timezoneList){
        timezoneList && timezoneList.forEach((item,itemIndex)=>{
            this.timezoneList.push({
                id:item.timeZoneId,
                label:item.timeZoneName,
                disabled:false
            })
        })
        this.updateSetMapData();
    }
    handleLibraryCheck(data,{checkedNodes,checkedKeys,halfCheckedNodes,halfCheckedKeys}){
        let checked = checkedKeys.includes(data.id);
        this.$refs.tree.setCurrentKey(data.id);
        this.handleLibraryCurrentChange(data,{checked});
    }
    handleLibraryCurrentChange(data,node){
        if(data && data.id>0){
            this.setTimezoneListDisable(false);
            this.currentLibraryId = data.id;
            if(node.checked){
                this.timezoneRadio = this.mapping[data.id]
            }else{
                this.timezoneRadio = '';
                delete this.mapping[data.id]
            }
        }else{
            this.setTimezoneListDisable(true)
        }
        if(this.viewModel === true){
            if(data && data.id>0){
                let currentView = this.data.find(item=>item.libraryId == data.id);
                if(currentView){
                    this.viewcurrentTimezoneName = this.timezoneList.find(item=>item.id == currentView.timezoneId)?this.timezoneList.find(item=>item.id == currentView.timezoneId).label:'';
                }
            }else{
                this.viewcurrentTimezoneName='';
            }
            
           
        }
    }
    handleTimezoneRadioChange(timezoneId){
        this.currentLibraryId>0 && (this.mapping[this.currentLibraryId] = timezoneId);
    }
    setTimezoneListDisable(isDisabled){
        this.timezoneRadio='';
        this.timezoneList && this.timezoneList.length>0 && this.timezoneList.forEach((time,timeIndex)=>{
            time.disabled = isDisabled;
            this.$set(this.timezoneList,timeIndex,time)
        })
    }
    getCheckedData(){
        let data:any=[];
        let library_checked = this.$refs.tree.getCheckedKeys(true);
        library_checked.forEach(item=>{
            !this.mapping.hasOwnProperty(item) && (this.mapping[item] = null);
        });
        if(Object.keys(this.mapping).length == 0 ) {
            this.$message({message: this.$tc('devicemanagement.warnTimezoneLibrary'),type: 'error'});
            return null;
        }
        // for(let check in this.mapping ){
        //     if(!this.mapping[check]){
        //         this.$message({
        //             message: '请选择人像库对应时间条件',
        //             type: 'error'
        //         });
        //         return null;
        //     }
        //     data.push({
        //         "libraryId": check,
        //         "timezoneId": this.mapping[check]
        //     })
        // }
        for(let i=0;i<library_checked.length; i++  ){
            let check = library_checked[i];
            if(!this.mapping[check]){
                this.$message({
                    message: this.$tc('devicemanagement.warnTimezoneLibrary2'),
                    type: 'error'
                });
                return null;
            }
            data.push({
                "libraryId": check,
                "timezoneId": this.mapping[check]
            })
        }
        return data;
    }
    
    

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.librarytimezone{
    display: flex;
    flex-wrap:wrap ;
    width: 100%;
    justify-content: center;
    padding-bottom: 8px;
}
.librarytimezone-header{
    width: 100%;
    display: flex;
    justify-content: center;
    padding-bottom: 8px;
    div{
        width: 200px;
        background-color: #E8EBF5;
        padding-left: 2px;
    }
    div:first-child{
        margin-right: 8px;
    }

}
::v-deep .el-tree{
    width: 200px;
    max-height: 200px;
    overflow-y: auto;
    .librarytimezone-tree-leaf{
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        padding-right: 10px;
        position: relative;
        width: 100%;
        .librarytimezone-tree-leaf-right{
            position: absolute;
            right: 2px;
            top: 2px;
        }
    }
    .el-tree-node.is-current>.el-tree-node__content>.librarytimezone-tree-leaf {
        color: #2a5af5;
        // color: red;
    }
}
::v-deep .el-radio-group{
    width: 200px;
    max-height: 200px;
    overflow-y: auto;
    margin-left: 8px;
    .el-radio {
        margin: 0;
        display: block;
        width: 100%;
        height: 20px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
}
</style>
