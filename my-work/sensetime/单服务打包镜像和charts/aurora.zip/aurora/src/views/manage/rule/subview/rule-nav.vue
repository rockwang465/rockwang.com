<template>
  <div class="rule-nav-container">
    <div class="rule-nav-btns" >
      <div :class="['rule-nav-btn',model == 'ac' && 'rule-nav-btn-active']" @click="changeMonitorModel('ac')" > <i class="iconfont icon-rke" ></i> {{$t('rule.labelAcRule')}}</div>
      <div :class="['rule-nav-btn',model == 'td' && 'rule-nav-btn-active']" @click="changeMonitorModel('td')"> <i class="iconfont icon-monitor-rules" ></i> {{$t('rule.labelTdRule')}}</div>
    </div>
    <div :class="['rule-nav-search',language == 'en'?'rule-nav-search-en':'']" >
      <el-input
        :clearable="true"
        :placeholder="$t('rule.textboxRulesetSearch')"
        @keydown.native="keydown"
        @clear="clear"
        v-model="searchModel">
        <i
          class="el-input__icon el-icon-search"
          slot="suffix"
          @click="()=>inputKeywordChange(searchModel)">
        </i>
      </el-input>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue,Watch } from 'vue-property-decorator';
import { RuleModule } from '@/store/modules/rule';
import {EventBus} from '@/utils/eventbus';
import { AppModule } from '@/store/modules/app';

@Component({
  components: {

  },
})
export default class RuleNav extends Vue {

  /* props */

  /* watch */

  get language() {
    return AppModule.language;
  }
  /* data */
  searchModel:string='';
  model:string=location.hash.indexOf('#rulestd')>=0?'td':'ac';

  /* methods */
  changeMonitorModel(ruleModel){
    this.model = ruleModel;
    this.$emit('ruleModel',ruleModel)
  }
  inputKeywordChange(n){
    //search ac group
    // this.$store.commit('SET_KEYWORD',n);
    //ac search
    if(this.model == 'ac' && this.getParamsValueFromURL('groupId')){
      EventBus.$emit('rule-search-list-ac',n);
    }else if(this.model == 'ac'){
      EventBus.$emit('rule-search-group-ac',n);
    }
    if(this.model == 'td' && this.getParamsValueFromURL('groupId')){
      //search td rules list
      EventBus.$emit('rule-search-list-td',n);
    }else if(this.model == 'td'){
      //search td group
      EventBus.$emit('rule-search-group-td',n);
    }

  }
  clear(){
    this.inputKeywordChange('');
  }
  keydown(e){
    e.keyCode == '13' && this.inputKeywordChange(this.searchModel);
  }
  getParamsValueFromURL(key){
    let url_string = location.href.split('?')[1];
    let searchParams = new URLSearchParams(url_string);
    return searchParams.get(key) || '';
  }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .rule-nav-container{
    padding-top: 30px;
    display: flex;
    flex-wrap: nowrap;
    justify-content: space-between;
    border-bottom: 1px solid $--color-primary;
    .rule-nav-btns{
      display: flex;
      align-items:flex-end;
    }
    .rule-nav-btn{
      display:inline-block;
      margin-left: 20px;
      padding: 5px 25px;
      cursor: pointer;
    }
    .rule-nav-btn-active{
      background-color: $--color-primary;
      color: $--color-white;
      border-radius: 5px 5px 0 0 ;
    }
    .rule-nav-btn:hover{
      background-color: $--color-primary;
      color: $--color-white;
      border-radius: 5px 5px 0 0 ;
    }
    .rule-nav-search{
      padding-right: 16px;
      position:relative;
      top:-5px;
      width:270px;
    }
    .rule-nav-search-en{
      width: 390px;
    }
  }
// ::v-deep .el-input__suffix-inner{
//     display: flex;
//     flex-direction: row-reverse;
//     align-items: center;
//     .el-input__icon.el-input__clear{
//       position: static;
//     }
//   }
</style>
