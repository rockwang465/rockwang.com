<template>
  <div  class="tree-input">
      <span
        v-if="name"
        class="title"
      >
        {{name}}
      </span>
    <el-dropdown
      class="dropdown"
      trigger="click"
      placement="bottom-start"
      @visible-change="handleDropdown"
      ref="imageDrop"
    >
      <el-input
        :value="inputText"
      >
       <span class="suffix-icon" slot="suffix">
         <Icon
           v-show="IconShow"
           type="ele"
           size="15"
           cursor="pointer"
           name="circle-close"
           @click="clkShow"
         />
       </span>
      </el-input>

      <el-dropdown-menu class="tree-container" slot="dropdown">
        <div class="filter-input">
          <el-input
            prefix-icon="el-icon-search"
            placeholder=""
            v-model="filterWord"
          >
          </el-input>
        </div>

<!--        隐藏全选-->
<!--        <el-checkbox v-model="checked" style="margin-left: 24px;" @change="checkedAll">{{$t('records.contSelectAll')}}</el-checkbox>-->

        <el-tree
          show-checkbox
          :data="data"
          :props="defaultProps"
          :filter-node-method="filterNode"
          @check-change="handleCheckChange"
          ref="tree"
          :node-key="nodeKey"
          @check='pitchOn'
        >
        </el-tree>
        <div class="treeselsect-btns">
          <el-button size="mini" type="text" @click="btnCancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
          <el-button type="primary" size="mini" @click="btnOk">{{$t('imagemanagement.buttonOK')}}</el-button>
        </div>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch, Emit,Prop } from 'vue-property-decorator';
  import  Icon from '@/components/icon-wrap/index.vue';
  import {EventBus} from '@/utils/eventbus';

  @Component({
    components:{
      Icon
    }

  })
  export default class ChooseTree  extends Vue{
    @Prop({default:[]}) data!:Array<String>
    @Prop({default:""}) name!:String
    @Prop({default:"id"}) nodeKey!:String
    @Prop({default:"label"}) label!:String
    @Prop({default:"children"}) children!:String

    filterWord="";
    count:any=0;
    checked:boolean = false;
    get inputText(){
      return this.$t("records.contSelected",{number:this.count})
    }
    get defaultProps(){
      return {
        children: this.children,
        label: this.label,
        id:this.nodeKey,
      }
    }
    IconShow :boolean= false;

    @Watch("loading")
    onloading(val){
    }
    @Watch("filterWord")
    filterTree(val){
      (this.$refs.tree as any).filter(val);
    }

    @Emit("dropDown") //下拉框事件
    handleDropdown(val){
      return val;
    }
    @Emit("checkout")
    handleCheckChange(data, checked, indeterminate) {//选择复选框事件
      let key=(this.$refs.tree as any) .getCheckedKeys(true)
      // console.log(key)

      let reg = /^g_/
      key = key.filter((val)=>{
        return !reg.test(val)
      })
      this.count = key.length
      if(this.count == 0){
        this.IconShow = false
      }else {
        this.IconShow = true
      }
      return key
    }
    //设置选中为空
    clearCheckout() {
      let key=(this.$refs.tree as any) .setCheckedKeys([])
    }
    mounted(){
    }

    created() {
      EventBus.$on('clearAll' , data=> this.checked = data as boolean)
    }

    filterNode(value, data) {
      if (!value) return true;
      return data[this.label+''].indexOf(value) !== -1;
    }

    //全选
    checkedAll() {

      if(this.checked) {
        (this.$refs.tree as any).setCheckedNodes(this.data)
      }else {
        (this.$refs.tree as any).setCheckedNodes([])
      }
    }


    pitchOn(){

      let data =  this.$props.data
      let fData :any= []
      data.forEach(item => {
        fData.push((this.$refs.tree as any) .getNode(item).checked)
      });

      let check = fData.every(item=>item)
      this.checked = check

    }

    clkShow(e){
      this.IconShow = false;
      e.stopPropagation();
      (this.$refs.tree as any).setCheckedNodes([]);
      this.checked= false
    }
    btnCancel(){
      this.clearCheckout();
      (this.$refs.imageDrop as any).hide();
    }
    btnOk(){
      (this.$refs.imageDrop as any).hide();
    }

  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .tree-input{
    display: inline-block;
    // padding: 3px 10px;
    .title{
      padding-right:3px;
      padding-left:10px;
      display: inline-block;
      /*line-height: 28px;*/
      white-space:nowrap;
    }
  }
  .tree-container{
    max-height:400px;
    overflow: scroll;
  }
  .filter-input{
    padding: 5px 15px;
  }

  ::v-deep .el-checkbox__label {
    padding: 0px;
  }
  .dropdown{
    width: 224px;
  }
  .treeselsect-btns {
    width: 100%;
    text-align: right;
    padding: 0 15px;
  }
</style>

