<template>
  <div>
    <!--详情弹框-->
    <el-dialog
      :title="$t('usermanagement.titleDetail')"
      :visible.sync="dialogShowVisible"
      :width="formLabelWidth2">
      <div class="user-details">
        <div class="top">
          <div class="t-left">
            <div class="detail">
              <!--用户名-->
              <div class="left">{{$t('usermanagement.labelUsername')}}</div>
              <el-tooltip class="item" v-if="detailsInfo.username&&detailsInfo.username.length>10" effect="dark" :content="detailsInfo.username" placement="top">
                <span class="right">{{detailsInfo.username?detailsInfo.username:' '}}</span>
              </el-tooltip>
              <div class="right" v-else>{{detailsInfo.username ? detailsInfo.username : ""}}</div>
            </div>
            <div class="detail">
              <!--姓名-->
              <div class="left">{{$t('usermanagement.contRealname')}}</div>
              <el-tooltip class="item" v-if="detailsInfo.realname&&detailsInfo.realname.length>10" effect="dark" :content="detailsInfo.realname" placement="top">
                <span class="right">{{detailsInfo.realname?detailsInfo.realname:' '}}</span>
              </el-tooltip>
              <div class="right" v-else>{{detailsInfo.realname ? detailsInfo.realname : ""}}</div>
            </div>
            <div class="detail">
              <!--角色-->
              <div class="left">{{$t('usermanagement.contRole')}}</div>
              <div class="right">{{detailsInfo.roleName ? detailsInfo.roleName : ""}}</div>
            </div>
          </div>
          <div class="t-right">
            <div class="detail">
              <!--ID-->
              <div class="left">{{$t('usermanagement.contID')}}</div>
              <el-tooltip class="item" v-if="detailsInfo.ID&&detailsInfo.ID.length>10" effect="dark" :content="detailsInfo.ID" placement="top">
                <span class="right">{{detailsInfo.ID?detailsInfo.ID:' '}}</span>
              </el-tooltip>
              <div class="right" v-else>{{detailsInfo.ID ? detailsInfo.ID : ""}}</div>
            </div>
            <div class="detail">
              <!--设备分配-->
              <div class="left">{{$t('usermanagement.contAssignedDevice')}}</div>
              <!--已选设备{{detailsInfo.deviceCount}}个-->
              <div class="right">{{$t('rule.contSelected',{number:detailsInfo.deviceCount})}}</div>
            </div>
          </div>
        </div>
      </div>
      <!--分割线-->
      <div style="width: 92%;margin: 0 auto;height: 2px;background-color: #c2cad8"></div>
      <div class="bottom-details">
        <!--属性-->
        <div class="detail" style="font-weight: bolder;margin-left: 26px;padding-bottom: 24px;">{{$t('usermanagement.contOtherInfo')}}</div>
        <div class="bottom">
          <div class="t-left">
            <div class="detail">
              <!--性别-->
              <div class="left">{{$t('usermanagement.contGender')}}</div>
              <div class="right">{{gender}}</div>
            </div>
            <div class="detail">
              <!--公司-->
              <div class="left">{{$t('usermanagement.contCompany')}}</div>
              <el-tooltip class="item" v-if="detailsInfo.company&&detailsInfo.company.length>7" effect="dark" :content="detailsInfo.company" placement="top">
                <span class="right">{{detailsInfo.company?detailsInfo.company:' '}}</span>
              </el-tooltip>
              <div class="right" v-else>{{detailsInfo.company ? detailsInfo.company : ""}}</div>
            </div>
            <div class="detail">
              <!--联系方式-->
              <div class="left">{{$t('usermanagement.contContact')}}</div>
              <el-tooltip class="item" v-if="detailsInfo.telephone&&detailsInfo.telephone.length>7" effect="dark" :content="detailsInfo.telephone" placement="top">
                <span class="right">{{detailsInfo.telephone?detailsInfo.telephone:' '}}</span>
              </el-tooltip>
              <div class="right" v-else>{{detailsInfo.telephone ? detailsInfo.telephone : ""}}</div>
            </div>
            <div class="detail">
              <!--激活状态-->
              <div class="left">{{$t('usermanagement.contActiveStatus')}}</div>
              <div class="right">{{detailsInfo.state == 1 ? $t('usermanagement.listActiveStatusActivated') : $t('usermanagement.listActiveStatusInvalid')}}</div>
            </div>
          </div>
          <div class="t-right">
            <div class="detail">
              <!--年龄-->
              <div class="left">{{$t('usermanagement.contAge')}}</div>
              <div class="right">{{detailsInfo.age ? detailsInfo.age : ""}}</div>
            </div>
            <div class="detail">
              <!--部门-->
              <div class="left">{{$t('usermanagement.contDepartment')}}</div>
              <el-tooltip class="item" v-if="detailsInfo.dept&&detailsInfo.dept.length>7" effect="dark" :content="detailsInfo.dept" placement="top">
                <span class="right">{{detailsInfo.dept?detailsInfo.dept:' '}}</span>
              </el-tooltip>
              <div class="right" v-else>{{detailsInfo.dept ? detailsInfo.dept : ""}}</div>
            </div>
            <div class="detail">
              <!--住址-->
              <div class="left">{{$t('usermanagement.contAddress')}}</div>
              <el-tooltip class="item" v-if="detailsInfo.address&&detailsInfo.address.length>7" effect="dark" :content="detailsInfo.address" placement="top">
                <span class="right">{{detailsInfo.address?detailsInfo.address:' '}}</span>
              </el-tooltip>
              <div class="right" v-else>{{detailsInfo.address ? detailsInfo.address : ""}}</div>
            </div>
          </div>
        </div>
      </div>

      <span slot="footer" class="dialog-footer">
        <!--重置密码-->
        <el-button v-if="$permission('002224')" type="primary" @click="showresetPassword = true">{{$t('usermanagement.buttonResetPassword')}}</el-button>
        <!--编 辑-->
        <el-button v-if="$permission('002220')" type="primary" @click="openUserEdit">{{$t('usermanagement.buttonOperationEdit')}}</el-button>
        <!--取 消-->
        <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--详情弹框-->
    <!--重置密码-->
    <el-dialog
      :title="$t('usermanagement.titleReminder')"
      :visible.sync="showresetPassword"
      width="584px">

      <el-row class="res">
        <!--是否确认重置密码?-->
        {{$t('usermanagement.popmsgResetPassword')}}?
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="resetPassWord">{{$t('usermanagement.buttonOK')}}</el-button>
        <el-button class="cancel" type="info" @click="showresetPassword = false">{{$t('usermanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!--重置密码成功-->
    <el-dialog
      :title="$t('usermanagement.titleReminder')"
      :visible.sync="showNewPassword"
      width="584px">
      <div>
        <!--<span style="font-weight: 600">密码已经成功重置为：</span>-->
        <span style="font-weight: 600">{{$t('usermanagement.copyPwdTips')}}</span>
        <span>{{newPassword}} </span>
        <span @click="copyPwd" class="copyPwd"> {{$t('usermanagement.copyPwd')}}</span>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="copyPassWord">{{$t('usermanagement.buttonOK')}}</el-button>
        <el-button class="cancel" type="info" @click="copyPassWord">{{$t('usermanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!--用户编辑组件-->
    <userEdit :dialogVisible="showUserEdit" :userInfo="userInfo" :roleName="roleName" :roleObj="roleObj" @closeUserEdit="closeUserEdit" @closeUserDetails="closeUserDetails"></userEdit>
    <!--用户编辑组件-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {UserModule} from '@/store/modules/user';
  import userEdit from './userEdit.vue';
  import {AppModule} from '@/store/modules/app';
  @Component({
    components:{
      userEdit
    },
    computed:{
      formLabelWidth2: function () {
        let that = this as any;
        return that.language == 'en' ? '684px' : '584px';
      },
      gender:function () {
        let that = this as any;
        return that.detailsInfo.gender == 1 ? that.$t('imagemanagement.contMale') : that.$t('imagemanagement.contFemale')
      }
    }
  })
  export default class userDetails extends Vue {
    get language() {
      return AppModule.language;
    }
    @Prop(Object) userInfo!:any;
    @Prop(Array) roleObj!:any;
    @Prop(String) roleName!:any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    //编辑的表单里的值
    dialogShowVisible = false;
    showUserEdit = false;
    showresetPassword = false;
    showNewPassword = false;
    newPassword = '';
    detailsInfo = {} as any;
    // gender = '' as any;
    blank = ' ' as any;

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }
    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeUserDetails")
      }
    }
    @Watch('userInfo')
    onUserInfoChange(val: any) {
      this.detailsInfo = val;
      console.log(val);
    }
    mounted(){

    }
    //打开编辑
    openUserEdit(){
      this.showUserEdit = true;
    }
    //关闭编辑
    closeUserEdit(){
      this.showUserEdit = false;
    }
    //关闭详情页
    closeUserDetails(){
       this.dialogShowVisible = false;
    }
    resetPassWord(){
      let that = this as any;
      let dataObj : any = {};
      dataObj.params = {};
      dataObj.id = this.detailsInfo.userId;
      UserModule.ResetPassWord(dataObj).then((data: any) => {
        console.log(data);
        this.showNewPassword = true;
        this.newPassword = data.password
        // this.$message({
        //   // message: "重置密码成功",
        //   message: that.$t('globaltip.tipmsgPwd'),
        //   type: 'success'
        // })
        // this.showresetPassword = false;
        // this.dialogShowVisible = false;
      }).catch((err) => {

      });

    }
    copyPwd(){
      let that = this as any;
      var oInput = document.createElement('input');
      oInput.value = this.newPassword;
      document.body.appendChild(oInput);
      oInput.select(); // 选择对象
      document.execCommand("Copy"); // 执行浏览器复制命令
      oInput.className = 'oInput';
      oInput.style.display='none';
      this.$message({
        showClose: true,
        // message: "已复制密码至剪切板",
        message: that.$t('usermanagement.copyPwdTips2'),
        type: 'success'
      })
      this.showNewPassword = false;
      this.showresetPassword = false;
      this.dialogShowVisible = false;
    }
    copyPassWord(){
      this.showNewPassword = false;
      this.showresetPassword = false;
      this.dialogShowVisible = false;
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  ::v-deep .el-dialog__body {
    padding: 0 0 20px 0 !important;
  }
  .el-row{
    line-height: 32px;
  }
  .row{
    text-align: center;
    color: #28354d;
  }
  .sx{
    width: 25%;
    text-align: center;
  }
  .col{
    color: #28354d;
    opacity: 0.8;
  }
  .res{
     text-align: center;
     padding: 20px 0;
  }

  .user-details{
    width: 95%;
    margin: 0 32px;
    /*border-top: solid 1px #8e99aa;*/
    /*border-bottom: solid 1px #8e99aa;*/
    padding: 20px 0;
    box-sizing: border-box;
  }

  .user-details .top{
    /*margin: 0 auto;*/
    width: 100%;
    display: flex;
    justify-content: space-around;
  }
  .top .t-left{
    width: 40%;
  }
  .top .t-right{
    width: 40%;
  }
  .user-details .detail{
    display: flex;
    padding: 10px 0;
  }
  .user-details .left{
    font-weight: bolder;
    text-align: right;
    margin-right: 10px;
    width: 45%;
  }
  .user-details .right{
    width: 50%;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  .bottom-details{
    width: 95%;
    margin: 0 32px;
    padding: 20px 0;
    box-sizing: border-box;
  }
  .bottom-details .detail{
    display: flex;
    padding: 10px 0;
  }
  .bottom-details .left{
    font-weight: bolder;
    text-align: right;
    margin-right: 10px;
    width: 45%;
  }
  .bottom-details .right{
    width: 50%;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  .bottom{
    width: 100%;
    display: flex;
    justify-content: space-around;
  }
  .bottom .t-left{
    width: 40%;
  }
  .bottom .t-right{
    width: 40%;
  }
  .copyPwd{
    color: #2A5AF5;
    text-decoration:underline;
    cursor: pointer;
  }
</style>
