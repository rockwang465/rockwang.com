<template>
  <div class="file-upload" >
    <div v-show="false" >
      <el-upload
        :auto-upload="true"
        :show-file-list="false"
        accept="image"
        :on-progress="handleProcess"
        :before-upload="beforeAvatarUpload"
        :on-error="pictureUploadError"
        :on-success="pictureUploadSuccess"
        :action="action">
        <el-button ref="btn" type="text">{{$t('rule.contlUploadbg')}}</el-button>
      </el-upload>
    </div>
    <transition name="fade">
      <div class="file-upload-imgbox" v-if="!showBg && src">
        <img class="file-upload-image" :src="processImgurl(src)"  />
      </div>
    </transition>

    <el-progress :percentage="percentage" v-if="showBg"   ></el-progress>
    <div>
      <el-button @click="clickUpload" v-if="src" type="text">{{$t('rule.contlUploadbgEdit')}}</el-button>
      <el-button @click="clickUpload" v-else type="text">{{$t('rule.contlUploadbg')}}</el-button>
    </div>
  </div>
</template>

<script lang="tsx">
import { Component, Vue,Watch ,Prop} from 'vue-property-decorator';
import {Cache} from '@/utils/cache';
import {processImgurl} from '@/utils/image';
const ruleHost = window.globalConfig.acHost;

@Component({
  components: {

  },
  directives:{

  }
})

export default class fileUpload extends Vue {

  /* props */
  @Prop({required:true}) action!: string;
  @Prop({default:''}) src!: string;
  /* watch */

  /* data */
  // src:string='';
  $refs !:{
    btn:HTMLFormElement
  }
  formData:any=null;
  // accessToken:string=Cache.localGet('accessToken') || Cache.sessionGet('accessToken');
  percentage:number=0;
  showBg:boolean=false;
  processImgurl:any=processImgurl;
  /* methods */
  mounted() {

  }
  beforeAvatarUpload(file){
    const isJPG = file.type === 'image/jpeg' || file.type === 'image/png' || file.type === 'image/jpg';
    const isLt16M = file.size / 1024 / 1024 < 16;
    if (!isJPG) {
      this.$message.error(this.$tc('rule.tipsPicType'));
    }
    if (!isLt16M) {
      this.$message.error(this.$tc('rule.tipsOversize'));
    }
    isJPG && isLt16M && (this.showBg = true);
    return isJPG && isLt16M;
  }
  pictureUploadError(error){
    this.showBg = false;
    this.$emit('error',error)
  }
  pictureUploadSuccess(file,list){
    this.showBg = false;
    this.percentage = 0;
    this.$emit('success',file)
  }
  handleProcess(event, file, fileList){
    this.percentage = parseInt(event.percent);
  }
  clickUpload(){
    this.$refs.btn.$el.click();
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.file-upload{
  width: 100%;
  .file-upload-imgbox{
    width: 100%;
    border:1px dashed black;
    background-color: #C2CAD8;
  }
  img{
    width:100%;
    display: block;
  }
}
.fade-enter-active, .fade-leave-active {
  transition: opacity 1s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
