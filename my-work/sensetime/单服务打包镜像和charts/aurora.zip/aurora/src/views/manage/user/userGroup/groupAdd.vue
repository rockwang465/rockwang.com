<template>
  <div>
    <!--添加弹框-->
    <el-dialog
      :title="dataObj.type == 'addLevel'?$t('devicemanagement.listPeerGroupCreate'):$t('devicemanagement.listSubGroupCreate')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <div class="content">
        <span class="left-name">
          <span style="color: #BE0000">* </span>
          <!--分组名称-->
          {{$t('usermanagement.contGroupName')}}
        </span>
        <span id="red" class="right-name"><el-input
          @input="inputName"
          maxlength="40" size="small" v-model="valueData"></el-input></span>
        <span class="left-name2"></span>
        <span class="right-name2">
          <!--请输入分组名称-->
          <div class="tips"><span v-show="isShow" style="color: #BE0000">{{$t('form.texterrEnterGroupName')}}</span></div>
        </span>
      </div>
      <!--请输入分组名称-->
      <!--<div class="tips"><span v-show="isShow" style="color: #BE0000">{{$t('form.texterrEnterGroupName')}}</span></div>-->
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleGroupAction">{{$t('usermanagement.buttonOK')}}</el-button>
      <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--添加弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';

  @Component({

  })
  export default class groupAdd extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    valueData = "";
    isShow = false;
    @Prop(Object) dataObj!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;

    //确定按钮
    handleGroupAction() {
      if (this.valueData == ''){
        let inp = document.querySelector("#red .el-input input") as any;
        inp.style.borderColor='#BE0000';
        this.isShow = true
        return
      }
      let inp = document.querySelector("#red .el-input input") as any;
      inp.style.borderColor='#c0c4cc';
      this.isShow = false
      this.$emit("handleGroupAction", this.dataObj, this.valueData)
      this.dialogShowVisible = false;
    }
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.isShow = false;
      this.valueData = '';
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        let inp = document.querySelector("#red .el-input input") as any;
        inp.style.borderColor='#c0c4cc';
        this.$emit("closeGroupAdd")
      }
    }

    //输入验证
    inputName(val){
      if(this.verifySize2(val)){
        this.valueData = val
      }else{
        this.valueData = '';
      }

    }
    //输入验证
    verifySize2(val){
      // let reg = /^\d*$/
      let reg = /^\S+/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  .tips{
    height: 16px;
    line-height: 16px;
    margin: 2px 0;
    font-size: 12px;
    text-align: left;
  }
  .content{
    width: 80%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    /*padding: 20px 0;*/
  }
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  .content>span{
    width: 50%;
    line-height: 32px;
    margin-top: 10px;
  }
  .content .left-name{
    padding-left: 15%;
    width: 40%;
    font-weight: bolder;
  }
  .content .right-name{
    width: 60%;
  }
  .el-select{
    width: 100%;
  }

  .el-list ::v-deep .el-input__suffix{
    right: 10px !important;
    top: 3px !important;
  }
  .right-name ::v-deep .el-input{
    width: 75%;
  }
  .upFile{
    color: #2a5af5;
  }
  .left-name{
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
  }
  .content .left-name2{
    width: 40%;
    margin: 0;
    line-height: 0;
  }
  .content .right-name2{
    width: 60%;
    margin: 0;
    line-height: 0;
  }
</style>
