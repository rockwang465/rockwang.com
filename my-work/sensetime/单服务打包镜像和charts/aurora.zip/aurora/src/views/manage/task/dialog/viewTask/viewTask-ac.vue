<template>
  <el-dialog
  :title="$t('task.titleDetailTask')"
  :visible.sync="visible"
  width="30%"
  :center="true"
  :before-close="handleClose">
  <!-- title -->
  <!-- content -->
    <el-form ref="form" :model="form" label-position="right" :label-width="language == 'en'?'125px':'115px'">
      <br/>
      <el-form-item :label="$t('task.contTaskName')">
        <span>{{taskName}}</span>
      </el-form-item>
      <el-form-item :label="$t('rule.contDevice')">
        <span>{{form.deviceName}}</span>
      </el-form-item>
      <el-form-item :label="$t('rule.contAttribute')">
        <span v-for="(attr,attrIndex) in form.specialAttribute" :key="attrIndex">{{attr.name}} </span>
      </el-form-item>
      <el-form-item :label="$t('rule.contThreshold')">
        <span>{{form.threshold}}</span>
      </el-form-item>
    </el-form>
    <div class="sapce-border" ></div>
    <div class="view-rule-ac-timeAndLibs" style="width:100%;" v-if="deviceType == 6">
      <div>
        <header class="view-rule-ac-libsheader">{{$t('rule.labelImageLibraryList')}}</header>
        <div  class="view-rule-ac-timeAndLibs-scrollbox view-rule-ac-timeAndLibs-scrollbox-libs">
          <el-tree :data="libsList" default-expanded-all ></el-tree>
        </div>
      </div>
    </div>
    <div class="view-rule-ac-timeAndLibs" style="width:100%;" v-else>
      <div>
        <header class="view-rule-ac-libsheader-time">{{$t('rule.labelTimezoneList')}}</header>
        <div class="view-rule-ac-timeAndLibs-scrollbox view-rule-ac-timeAndLibs-scrollbox-times" >
          <el-tree :data="timezoneList" class="view-rule-ac-timezonetree" ref="timezoneList" node-key="id" default-expanded-all  @node-click="handleTimezoneListNodeClick" ></el-tree>
        </div>
      </div>
      <div>
        <header class="view-rule-ac-libsheader">{{$t('rule.labelImageLibraryList')}}</header>
        <div  class="view-rule-ac-timeAndLibs-scrollbox view-rule-ac-timeAndLibs-scrollbox-libs">
          <el-tree :data="libsList" default-expanded-all ></el-tree>
        </div>

      </div>
    </div>

    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="hide(true)" v-if="$permission('006203')">{{$t('rule.buttonOperationEdit')}}</el-button>
      <el-button @click="hide(false)" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>
</template>

<script lang="ts">
import { Component, Vue , Watch, Prop} from 'vue-property-decorator';
import TreeSelect from '@/components/tree-select/index.vue';
import {getRuleDetail} from '@/api/rule';
import { AppModule } from '@/store/modules/app';

@Component({
  components: {
    TreeSelect
  },
})
export default class ViewRuleAC extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:''}) ruleId!: string;
  /* watch */
  @Watch('visible')
  onvisibleChange(n,o){
    n && this.getRuleDetail()
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  $refs!:{
    timezoneList:HTMLFormElement
  }
  labelWidth:string='100px';
  form:any={
    deviceName:"",
    specialAttribute:[],
    threshold:0
  };
  libsList:any=[];
  timezoneList:any[]=[];
  props:any=this.$props;
  timezoneLibraryRelation:any=[];
  deviceType:any=null;
  taskName:string='';

  /* methods */
  hide(isEdit:boolean){
    this.$emit('hide',isEdit)
  }
  handleClose(){
    this.hide(false);
  }
  handleLibsListClick(data){

  }
  handleTimezoneListNodeClick(data){
    this.libsList = [];
    let index = this.timezoneLibraryRelation.findIndex(item=>item.timezoneVo.timeZoneId == data.id);
    if(index>=0 && this.timezoneLibraryRelation[index].libraryVos.length>0){
      this.timezoneLibraryRelation[index].libraryVos.map((item:any)=>{
        this.libsList.push({
          id:item.libraryId,
          label:item.libraryName
        })
      })
    }
  }
  getRuleDetail(){
    this.form.ruleGroupName = '';
    this.form.deviceName = '';
    this.form.specialAttribute = [];
    this.form.threshold = 0;
    this.timezoneList=[];
    this.timezoneLibraryRelation = [];
    this.libsList = [];
    getRuleDetail(this.ruleId).then((res:any)=>{
      this.taskName = res.taskName;
      this.deviceType = res.deviceVo.deviceType;
      (res.deviceVo.deviceType == 6) && this.setlibsList(res.passLibraryVos);
      this.form={
        deviceName:res.deviceVo.deviceName,
        specialAttribute:this.formatAttribute(res.taskAttributeVos),
        threshold:(res.threshold*100).toFixed(1)+'%'
      };
      this.timezoneLibraryRelation = res.timezoneLibraryRelation;
      this.formatTimezoneList(res.timezoneLibraryRelation,()=>{
        this.setDefaultShowLibs(res.timezoneLibraryRelation);
      });
      
    })
  }
  setlibsList(arr){
    let arrl:any[]=[];
    arr && arr.map(item=>{
      arrl.push({
        id:item.libraryId,
        label:item.libraryName
      })
    });
    this.libsList = arrl;
    
  }
  setDefaultShowLibs(timezoneLibraryRelation){
    if(timezoneLibraryRelation && timezoneLibraryRelation.length>0 && this.$refs.timezoneList){
      let timezoneId = timezoneLibraryRelation[0].timezoneVo.timeZoneId;
      this.$refs.timezoneList.setCurrentKey(timezoneId);
      timezoneId && this.handleTimezoneListNodeClick({id:timezoneId});
    }
  }
  formatAttribute(Attributes){
    let arr:any = [];
    Attributes.map((item:any)=>{
      arr.push({id:item.taskAttributeId,name: this.$tc(`rule.${item.taskAttributeName}`)})
    });
    return arr;
  }
  formatTimezoneList(timezones,cal?){
    timezones && timezones.map((item:any)=>{
      this.timezoneList.push({
        id:item.timezoneVo.timeZoneId,
        label:item.timezoneVo.timeZoneName
      })
    })
    this.$nextTick(()=>{
      cal && cal();
    })
  }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .view-rule-ac-threshold{
    width: 120px;
  }
  .view-rule-ac-timeAndLibs{
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    &>div{
      width: 50%;
    }
    .view-rule-ac-libsheader{
      height: 24px;
      background-color: $--background-color-header;
      line-height: 24px;
      color: $--color-black;
      text-indent: 8px;
    }
    .view-rule-ac-libsheader-time{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;
    }
    .view-rule-ac-timeAndLibs-scrollbox{
      width: 100%;
      max-height: 225px;
      overflow: auto;
    }

  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
  // ::v-deep .el-form{
  //     max-width: 330px;
  //     margin: 0 auto;
  //   }
  .view-rule-ac-keepertreeinput{
    width: 100%;
  }
::v-deep .view-rule-ac-timeAndLibs-scrollbox-times .el-tree .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .view-rule-ac-timeAndLibs-scrollbox-times .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .view-rule-ac-timeAndLibs-scrollbox-libs .el-tree .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .view-rule-ac-timeAndLibs-scrollbox-libs .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }

::v-deep .el-form-item.is-required:not(.is-no-asterisk)>.el-form-item__label{
    position: relative;
    &:before {
      position: absolute;
      left: -8px;
    }
  }
  ::v-deep .view-rule-ac-timezonetree .el-tree-node.is-current{
    position: relative;
    &:after{
      content: '';
      position: absolute;
      top: 7px;
      right: 0;
      display: block;
      width: 0;
      height: 0;
      border: 5px solid transparent;
      border-left: 5px solid black;
    }
  }
</style>
