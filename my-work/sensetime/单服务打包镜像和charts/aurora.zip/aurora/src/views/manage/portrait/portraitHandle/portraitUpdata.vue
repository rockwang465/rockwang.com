<template>
  <div>
    <!--批量上传弹框-->
    <el-dialog
      :class="{hidden:isHide}"
      class="dialog-custom"
      :title="$t('imagemanagement.titleBulkUpload')"
      :visible.sync="dialogShowVisible"
      :show-close="showClose"
      :close-on-press-escape="false"
      :close-on-click-modal="false"
      :width="formWidth">
      <el-form
        v-loading="loading"
        :element-loading-text="textTips"
        element-loading-spinner="el-icon-loading"
        :disabled="dontMove"
        :rules="rulesList"
        label-position="right"
        ref="dataForm" :model="form">
        <div class="detail">
          <el-form-item :label="$t('imagemanagement.contLibraryType')" :label-width="formLabelWidth">
            <el-select v-model="currentLibrary" size="small" class="el-list">
              <el-option
                v-for="item in leftTreeData"
                :key="item.id"
                :label="item.libraryName"
                :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('imagemanagement.contLibraryGroup')" :label-width="formLabelWidth">
            <el-select @change="typeChange" v-model="currentLibraryGroup" size="small" class="el-list">
              <el-option
                v-for="item in options"
                :key="item.libraryId"
                :label="item.libraryName"
                :value="item.libraryId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="worb" prop="activationTime" :label="$t('imagemanagement.contTimeActivation')" :label-width="formLabelWidth">
            <el-date-picker class="cancelTime"
                            size="small"
                            v-model="form.activationTime"
                            type="datetime"
                            value-format="yyyy-MM-dd HH:mm:ss"
                            :placeholder="$t('imagemanagement.contTimeSet')">
            </el-date-picker>
            <!--:picker-options="startDatePicker"-->
          </el-form-item>
          <el-form-item v-if="worb" :label="$t('imagemanagement.contTimeExpiration')" :label-width="formLabelWidth">
            <el-date-picker class="cancelTime"
                            size="small"
                            v-model="form.expirationTime"
                            type="datetime"
                            value-format="yyyy-MM-dd HH:mm:ss"
                            :placeholder="$t('imagemanagement.contTimeSet')">
            </el-date-picker>
            <!--:picker-options="endDatePicker"-->
          </el-form-item>
          <!--选择文件夹-->
          <el-form-item :label="$t('imagemanagement.contSelectFile')" :label-width="formLabelWidth">
            <div style="position: absolute;top: 0px;right: 10px;">
              <el-popover
                placement="bottom-start"
                width="355"
                trigger="hover">
                <div class="content" style="word-break: normal">
                  <!--1.上传前请将图片(jpg/png/bmp格式)放在同一文件夹内，不要设置子文件夹，图片数量不超过10万张，单张图片在16MB以内-->
                  <!-- {{$t('imagemanagement.upDataTips1')}} -->
                  <div class="named-suggest" v-html="$t('imagemanagement.upDataTips1')"></div>
                  <!--2.图片命名请以“姓名_ID_性别_公司_部门_年龄”加后缀名的格式，其中性别可输入“Unknown”或“M”或“F”，年龄请输入0-150之间的数字-->
                  <!-- {{$t('imagemanagement.upDataTips2')}} -->
                  <div class="named-suggest" v-html="$t('imagemanagement.upDataTips2')"></div>
                  <!--3-->
                  <!-- {{$t('imagemanagement.upDataTips3')}} -->
                  <div class="named-suggest" v-html="$t('imagemanagement.upDataTips3')"></div>
                </div>
                <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
              </el-popover>
            </div>
            <label class="right-name upFile" for="fileUp"><i class="iconfont icon-upload-copy"></i>{{$t('imagemanagement.contSelectFile')}}</label>
            <input v-if="dialogShowVisible" type="file" id="fileUp" ref="files" webkitdirectory multiple style="display: none" @change="preView($event)">
          </el-form-item>
          <el-form-item :label="$t('imagemanagement.contSelectedFile')" :label-width="formLabelWidth">
            {{folder ? folder  : $t('imagemanagement.contSelectedFile')}}
          </el-form-item>
        </div>
        <!--<div style="width: 100%; text-align: center;padding: 0px 0 20px 0;">-->
          <!--<el-button type="primary" :disabled="!taskId" @click="filesUpdata(),this.loading=true;">{{$t('imagemanagement.buttonOK')}}</el-button>-->
          <!--<el-button class="cancel" type="info" @click="showcancel = true">{{$t('imagemanagement.buttonCancel')}}</el-button>-->
        <!--</div>-->
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="!taskId || loading" @click="filesUpdata()">{{$t('imagemanagement.buttonOK')}}</el-button>
        <!--<el-button class="cancel" :disabled="!taskId || loading" type="info" @click="cancleUpdata">{{$t('imagemanagement.buttonCancel')}}</el-button>-->
        <el-button class="cancel" :disabled="!showClose" type="info" @click="cancleUpdata">{{$t('imagemanagement.buttonCancel')}}</el-button>
        <!--@click="showcancel = true"-->
     </span>
    </el-dialog>
    <!--批量上传弹框-->
    <!--取消上传弹框-->
    <el-dialog
      :title="$t('imagemanagement.buttonBulkUpload')"
      :visible.sync="showcancel"
      width="30%">
      <div class="title">
        <el-row>{{$t('imagemanagement.popmsgUploadCancel')}}</el-row>
        <!--<el-row>取消后，已上传的人像将保留在人像库中。</el-row>-->
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="timeCheckOut">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" type="info" @click="showcancel = false;taskId = null">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--取消上传弹框-->
  </div>
</template>
<script lang="ts">
  let isSave =false;
  let texts = '正在上传，请勿关闭页面避免上传失败';
  let token = '' as any;
  function save(){

  }

  // window.onunload =function() {
  //   if(isSave){
  //     save();
  //   }
  // }
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {PortraitModule} from '@/store/modules/portrait';
  import {fileValidate,isEmpty} from '@/utils/validate';
  import {AppModule} from '@/store/modules/app';
  import {Cache} from '@/utils/cache';


  window.onbeforeunload =function() {
    if(isSave){
      // return  confirm('正在上传，关闭页面会导致上传失败，确定要离开？');
      return '正在上传，关闭页面会导致上传失败，确定要离开？'
    }
  }
  window.onunload=function () {
    if(isSave){

    }
  }

  let vm = null as any;
  const requiredTip = (rule, value = '', callback) => {
    // debugger
    if (value === ''|| value === null) {
      // debugger
      callback(new Error(vm.$t('form.texterrSelectTime')))
    } else {
      callback()
    }
  }

  @Component({
    computed: {
      rulesList: function () {
        let that = this as any;
        return that.rules1
      },
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '180px' : '120px';
      },
      formWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '684px' : '584px';
      }
    }
  })
  export default class portraitUpData extends Vue {
    get language() {
      return AppModule.language;
    }
    startDatePicker= this.beginDate();
    endDatePicker= this.processDate();
    @Prop(Array) leftTreeData!: any[];
    @Prop(Object) currentTree!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    //传入后端参数
    form = {
      ID: "",
      activationTime: "",
      activeState: 1,
      address: "",
      age: null,
      aliasName: "",
      company: "",
      dept: "",
      expirationTime: "",
      gender: 1,
      image: "",
      libraryId: null,
      libraryType:null,
      name: "",
      phone: "",
      replace: 1,
    }  as any;
    currentLibrary = null
    currentLibraryGroup = ''
    // formLabelWidth = '120px';
    dontMove = false;
    loading = false;
    isHide = false;
    textTips = '正在上传，请勿关闭页面避免上传失败' as any;
    dialogShowVisible = false;
    showcancel = false;
    filesPath='';//批量上传数据
    userId=null;//批量上传数据
    taskId=null as any;//批量上传数据
    groupName = '' as any;//批量上传数据
    worb = true
    folder = "" as any;
    // value = null;//批量上传数据
    // value1 = 0;
    options = [] as any;
    filesName = [] as any;//批量上传数据
    filesData = [] as any;//批量上传数据
    len1 = 0;
    num = 0;
    inp = null as any;
    rules1 = {
      activationTime: [{required: true, trigger: 'blur', validator: requiredTip}],
      expirationTime: [{required: true, trigger: 'blur', validator: requiredTip}],
    };
    showClose=true;
    strTips=''

    created(){
      vm = this as any;
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      if(val){
        this.isHide = false;
      }
      this.dialogShowVisible = val;

      this.taskId = null;//初始化批量上传数据
      this.folder = '';//初始化批量上传数据

      //人像库和分组根据左侧选择自动选中
      if(Object.entries(this.currentTree).length >0){
        if(this.currentTree.libraryId){
          this.currentLibraryGroup = this.currentTree.libraryId;
          this.groupName = this.currentTree.libraryName;
        }else{
          this.currentLibraryGroup = ''
          this.groupName = '';
        }

        if(this.currentTree.parent){
          this.currentLibrary = this.currentTree.parent.id;
          this.options = this.leftTreeData[this.currentTree.parent.id-1].children; //把id-1对应数组索引


        }else{
          this.currentLibrary = this.currentTree.id;
        }

      }else{
        this.currentLibrary = this.leftTreeData[0].id;
      }

    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      let that = this as any;
      if (!val) {
        that.$refs['dataForm'].resetFields();
        that.form.expirationTime = "";
        this.$emit("closePortraitUpData")
      }
    }
    @Watch("leftTreeData")
    onleftTreeDataChange(val: any) {
      console.log(val)
    }
    @Watch("loading")
    onLoadingChange(val: any) {
      isSave = val;
      texts = this.textTips;
    }
    @Watch("taskId")
    onTaskIdChange(val:any){
      token = val
    }
    @Watch("currentLibrary")
    onvalue1Change(val: any) {
      let num = val - 1 as any;
      this.options = this.leftTreeData[num].children;

      //this.currentLibraryGroup = this.options[0].libraryId;
      //this.groupName = this.options[0].libraryName;
      if (val == 1){
        this.worb = true
      } else{
        this.worb = false
      }

    }
    @Watch("currentLibraryGroup")
    onvalueChange(val: any) {

    }

    timeCheckOut(){
      let that = this as any;
      if (new Date(this.form.expirationTime).getTime() < new Date(this.form.activationTime).getTime()){
        this.form.activationTime = '';
        this.form.expirationTime = '';
        this.$message({
          showClose: true,
          message:that.$t('imagemanagement.timeTips'),
          // message:'激活时间需早于失效时间',
          type: 'error'
        })
        return;
      }
      this.dialogShowVisible = false;
      this.showcancel = false;
    }
    //时间判断
    beginDate(){
      const self = this
      return {
        disabledDate(time){
          if (self.form.expirationTime) {  //如果结束时间不为空，则小于结束时间
            return new Date(self.form.expirationTime).getTime() < time.getTime()
          } else {
            // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
          }
        }
      }
    }
    processDate() {
      const  self = this
      return {
        disabledDate(time) {
          if (self.form.activationTime) {  //如果开始时间不为空，则结束时间大于开始时间
            return new Date(self.form.activationTime).getTime() > time.getTime()
          } else {
            // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
          }
        }
      }
    }

    typeChange(val){
      for(let i = 0;i < this.options.length;i++){
        if (this.options[i].libraryId == val) {
          this.groupName = this.options[i].libraryName;
        }
      }
    }
    preView(e){
      let that = this as any;
      if(!this.currentLibraryGroup){
        this.$message({
          showClose: true,
          //请选择人像库
          message:that.$t('form.texterrSelectImageLib'),
          type: 'error'
        });
        return;
      }
      this.textTips = that.$t('imagemanagement.titleUpdateTips');
      this.loading = true;
      this.filesName = [];
      let files = e.target.files;
      //console.log(files)
      //FIXME:过滤文件夹内的图片格式
      let allowFile ;

      //测试
      // var file = files[0];
      // var url = this.getObjectURL(file);

      for(let i = 0;i < files.length;i++){
        allowFile = fileValidate(files[i],['png','jpg','bmp'])
        if(allowFile.type){
          this.filesName.push(files[i].name)
        }
      }
      console.log(this.filesName)
      if(files.length<1){
        this.loading = false;
        return;
      }
      this.folder = files[0].webkitRelativePath.split("/")[0];
      let filesPath = this.$refs.files as any;
      this.filesPath = filesPath.value;
      let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
      this.userId = user.userId;


      //将所有的照片名传给后端
      let createTaskParam = {
        // fileName: [],
        folderUrl: "123123",
        activationDate:'2019-01-01 00:00:00',
        expirationDate :'2019-01-01 00:00:00',
        libraryId: "",
        userId: "",
        libraryType:''
      } as any;


      createTaskParam.fileName       = this.filesName;
      createTaskParam.folderUrl      = this.filesPath;
      createTaskParam.libraryId      = this.currentLibraryGroup;
      createTaskParam.userId         = this.userId;
      createTaskParam.libraryType    = this.currentLibrary;
      createTaskParam.activationDate = this.form.activationTime;
      createTaskParam.expirationDate = this.form.expirationTime;
      PortraitModule.protraitNameList(createTaskParam).then((data: any) => {
        this.loading = false
        if(!data){
          return;
        }
        this.taskId = data.taskId;
        PortraitModule.SET_TASK_ID(data.taskId);
      }).catch((err) => {
        this.loading = false;
        this.showClose = true;
      });

    }
    filesUpdata(){
      let that = this as any;
      let base = 100 as any;
      if(!this.currentLibraryGroup){
        this.$message({
          showClose: true,
          //请选择人像库
          message:that.$t('form.texterrSelectImageLib'),
          type: 'error'
        });
        return;
      }
      // let timer = 1 as any;
      (that.$refs.dataForm as any).validate((valid) => {
        console.log(valid)
        if (valid){
          if (this.worb && this.form.expirationTime && new Date(this.form.expirationTime).getTime() < new Date(this.form.activationTime).getTime()){
            this.form.activationTime = '';
            this.form.expirationTime = '';
            this.$message({
              showClose: true,
              message:that.$t('imagemanagement.timeTips'),
              // message:'激活时间需早于失效时间',
              type: 'error'
            })
            return;
          }
          this.loading=true;
          // this.textTips = '正在上传，请勿关闭页面避免上传失败';
          this.textTips = that.$t('imagemanagement.titleUpdateTips');
          this.showClose = false;
          if (!this.inp){
            let inp = document.getElementById('fileUp') as any;
            //将文件传值store
            // PortraitModule.SET_PICS(inp.files,this.taskId);
            that.$message({
              showClose: true,
              // message: that.folder + ' 正在上传，请等待，请勿关闭和刷新页面',
              message: that.$t('imagemanagement.upDataTips4',{filename:that.folder}),
              customClass:'info-tips',
              type:'info',
              // message: that.$t('form.texterrSelectImage'),
              duration:4000
            });


            // this.num = inp.files.length;
            // this.inp = inp.files;
            this.strTips = that.$t('globaltip.tipmsgBatchUpload',{filename:that.folder});

            PortraitModule.SET_INP(inp.files)
            PortraitModule.SET_PARAMS(this)
            PortraitModule.fILES_UPDATA(this.$message,this.strTips);
            inp = null;
            // this.$message({
            //   // message: "上传成功",
            //   message:that.$t('globaltip.tipmsgBatchUpload',{filename:that.folder}),
            //   type: 'success'
            // });
            this.cancleUpdata()
            this.isHide = true;
            return;
          }

          // this.isHide = true;

          let num2 = 0;
          if (this.num - this.len1 >= base){
            num2 = this.len1 + base;
          } else{
            num2 = this.num
          }
          let formdata = new FormData() as any;
          for(let i = this.len1;i < num2;i++){
            formdata.append("img", this.inp[i]);
          }
          let filesPath = this.$refs.files as any;

          formdata.append('taskId',this.taskId);
          formdata.append('libraryId',this.currentLibraryGroup);
          formdata.append('userId',this.userId);
          formdata.append('libraryType',this.currentLibrary);
          formdata.append('activationDate',this.worb?this.form.activationTime:'');
          formdata.append('expirationDate',this.worb?this.form.expirationTime:'');
          formdata.append('currentRequestNum',Math.ceil(num2/base));//当前请求数
          formdata.append('requestTotalNum',Math.ceil(this.num/base));//请求总数
          formdata.append('fileTotalNumber',this.num);//文件总数
          formdata.append('groupName',this.groupName);
          console.log(formdata)


          this.len1 += base;
          if (this.len1 - this.num > base){
            // inp.value = '';
            // inp.outerHTML=inp.outerHTML;//清空input的files
            this.taskId = null;
            this.len1 = 0;
            this.num = 0;
            this.loading = false;
            this.showClose = true;
            this.inp = null;
            let that = this as any;
            this.$message({
              showClose: true,
              // message: "上传成功",
              message:that.$t('globaltip.tipmsgBatchUpload',{filename:that.folder}),
              type: 'success'
            });
            this.$emit("closePortraitUpData")
            return;
          } else {
            PortraitModule.protraitAddTargetBulkTool(formdata).then((data)=>{
              that.filesUpdata();
            }).catch((err) => {
              that.cancleUpdata();
            });

          }
        }
      })
    }
    //点击取消
    cancleUpdata(){
      this.taskId = null;
      this.len1 = 0;
      this.num = 0;
      this.loading = false;
      this.showClose = true;
      this.inp = null;
      this.$emit("closePortraitUpData")
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .dialog-custom{
    // display:block !important;
    width:100%;
    height:100%;
  }
  .hidden {
    display: block !important;
    position: fixed;
    top: -10%;
    bottom: 110%;
    right: 5%;
    left: 95%;
    width: 0;
    height: 0;
    overflow: hidden;
    transition: all 1s;
    ::v-deep .el-dialog {
      min-width: 30%;
      height: 30%;
      overflow: hidden;

    }
  }

  $bg: #2d3a4b;
  $light_gray: #eee;
  .content{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    text-align: left;
    white-space: normal;
    word-break: break-all;
    .named-suggest{
      white-space: normal;
      word-break: break-all;
      margin-bottom: 4px;
      ::v-deep i{
        color: #BE0000;
      }
    }
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  .content>span{
    width: 50%;
    line-height: 25px;
    margin-top: 10px;
  }
  .content .left-name{
    padding-left: 21%;
    width: 40%;
  }
  .content .right-name{
    width: 60%;
  }
  .el-select{
    width: 100%;
  }

  .el-list ::v-deep .el-input__suffix{
    right: 10px !important;
    top: 3px !important;
  }
  .right-name ::v-deep .el-input{
    width: 75%;
  }
  .upFile{
    color: #2a5af5;
  }
  .left-name{
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
  }
  .file-name{
    color:rgba(162,176,199,0.8);
  }
  .upFile{
    padding-top: 12px;
  }
  .title{
    text-align: center;
    line-height: 24px;
  }
  .item{
    line-height: 32px;
    margin-top: 10px;
    padding-left: 10px;
  }
  .detail{
    height: 100%;
    margin: 32px 100px 23px;
  }
  .starTime ::v-deep .el-input__prefix{
    display: none;
  }
  .cancelTime ::v-deep .el-input__inner{
    text-align: left !important;
  }
  .cancelTime ::v-deep .el-input__prefix{
    display: none;
  }
</style>
