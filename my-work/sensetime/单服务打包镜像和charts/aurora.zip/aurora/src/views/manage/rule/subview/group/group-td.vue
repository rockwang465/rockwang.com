<template>
  <div class="group-td-container">
    <div class="group-td-contents" >
      <GroupCard
        v-for="(group,groupIndex) in groupListData" :key="groupIndex"
        type="td"
        :title="group.title"
        :devices="group.devices"
        :libs="group.libs"
        :groupId="group.groupId"
        @view="handleView"
        @edit="(groupId)=>handleEdit(groupId,group.title)"
        @delete="handleDelete" />
    </div>
    <div class="group-td-footer" >
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
    <el-dialog
      class="group-td-dialog"
      :visible="showRenameDialog"
      :before-close="()=>this.showRenameDialog = false"
      width="400px">
      <el-form ref="formname" :model="form" :rules="rules" label-width="120px">
        <el-form-item :label="$t('rule.contRulesetName')" prop="groupName">
          <el-input v-model="form.groupName"></el-input>
        </el-form-item>
      </el-form>
      <div slot="title" class="group-td-dialog-header" >
        <span>{{$t('rule.titleEdit')}}</span>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="ensureEdit">{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="showRenameDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!-- delete dialog -->
    <el-dialog
      :visible="showDeleteDialog"
      :before-close="()=>this.showDeleteDialog = false"
      width="400px">
      <p style="max-width:350px;text-align:center;line-height:20px;">{{this.$t('rule.popmsgRulesetDelete')}}</p>
      <div slot="title" class="group-td-dialog-header" >
        <span>{{this.$t('rule.titleDelete')}}</span>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="danger" @click="ensureDelete">{{$t('rule.buttonOperationDelete')}}</el-button>
        <el-button @click="showDeleteDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import GroupCard from './group-card.vue';
import {getGroupsTDList,editGroupName,deleteRulesGroup} from '@/api/rule';
import {EventBus} from '@/utils/eventbus';
import {trim} from 'lodash';
import i18n from '@/lang/index';
import {paginationPageSizes} from '@/utils/constants';

@Component({
  components: {
    GroupCard
  },
})
export default class GroupTD extends Vue {
  /* props */
  @Prop({default:false}) refreshList!: boolean;

  /* watch */
  @Watch('showRenameDialog', { immediate: false, deep: true })
  onShowRenameDialogChange(n,o){
    if(n){
      // this.form.groupName = '';
      this.$refs.formname && this.$refs.formname.clearValidate();
    }
  }
  /* data */
  $refs !:{
    formname:HTMLFormElement
  };
  showRenameDialog:boolean=false;
  form:{groupName:string;}={groupName:''};
  validateGroupName=(rule, value, callback) => {
    let str = value;
    if (str === '') {
      callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
    } else {
      //去除两头空格:
      let regx = /^\s+|\s+$/g;
      while (regx.test(str)) {
        str   =  trim(str);
      };
      str   =  trim(str);
      if(str){
        callback();
      }else{
        callback(new Error(i18n.t('form.texterrEnterRulesetName')+""));
      }

    }
  };
  rules={
    groupName:[
      { required:true,validator: this.validateGroupName, trigger: 'blur' },
      // { min: 1, max: 40, message: '长度在 1 到 40 个字符', trigger: 'blur' }
    ],
  };
  //分页
  currentPage:number=1;
  totalPage:number=1;
  total:number=0;
  pageSizes=paginationPageSizes;
  pageSize:number=this.pageSizes[0];
  acRulesListCondition:any;
  groupListData:any[] = [];
  keyword:string='';

  currentGroupId:any='';

  //delete
  showDeleteDialog:boolean=false;
  currentDeleteId:any='';

  /* methods */
  mounted() {
    this.initData();
    EventBus.$on('rule-refresh-grouptd',()=>{this.getGroupList()});
    EventBus.$on('rule-search-group-td',this.handleSearch);
  }
  handleSearch(data){
    this.keyword=data;this.getGroupList();
  }
  initData(){
    this.keyword = '';
    this.getGroupList();
  }
  getGroupList(params?){
    let condition = {...params,page:this.currentPage,num:this.pageSize,keyword:this.keyword};
    getGroupsTDList(condition).then((res:any)=>{
      this.formatGroupListData(res.list);
      this.totalPage = res.totalPage;
      this.total = res.total;
    })
  }
  formatGroupListData(list){
    this.groupListData = [];
    list && list.map(item=>{
      this.groupListData.push({
        title:item.taskGroupName,
        devices:item.deviceNum,
        libs:item.libraryNum,
        groupId:item.taskGroupId
      })
    })
  }
  editGroupName(groupId,groupName){
    //name min:1 max:40 get40
    if(trim(groupName).length>40){
      groupName = trim(groupName).substr(0,40);
    };
    editGroupName({"taskGroupId": groupId,"taskGroupName": groupName}).then(res=>{
      // this.$message({
      //   message: '修改成功',
      //   type: 'success'
      // });
      this.getGroupList();
    }).catch(err=>{

    })
  }
  handleView(group){
    this.$emit('viewrules',group)
  }
  handleEdit(groupId,groupName){
    this.form.groupName = groupName;
    this.currentGroupId = groupId;
    this.showRenameDialog = true;
  }
  ensureEdit(){
    this.$refs.formname.validate((valid)=>{
      if(valid){
        this.editGroupName(this.currentGroupId,this.form.groupName);
        this.showRenameDialog = false;
      }
    });

  }
  ensureDelete(){
    let groupId = this.currentDeleteId;
    groupId && deleteRulesGroup(groupId).then(res=>{
      // this.$message({
      //   message: '删除成功',
      //   type: 'success'
      // });
      this.showDeleteDialog = false;
      this.getGroupList();
    }).catch(err=>{
      this.showDeleteDialog = false;
    })
  }
  handleDelete(groupId){
    this.currentDeleteId = groupId;
    this.showDeleteDialog = true;
    // this.$confirm(this.$tc('rule.popmsgRulesetDelete') as string, this.$tc('rule.buttonDelete') as string, {
    //   confirmButtonText: this.$tc('rule.buttonDelete') as string,
    //   cancelButtonText: this.$tc('rule.buttonCancel') as string,
    //   center: true
    // }).then(() => {
    //   deleteRulesGroup(groupId).then(res=>{
    //     // this.$message({
    //     //   message: '删除成功',
    //     //   type: 'success'
    //     // });
    //     this.getGroupList();
    //   })
    // }).catch(() => {

    // });
  }
  handleSizeChange(val){
    this.pageSize = val;
    this.getGroupList({keyword:this.keyword})
  }
  handleCurrentChange(val){
    this.currentPage  = val;
    this.getGroupList({keyword:this.keyword})
  }


}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";
  .group-td-container{
    padding-top:10px;
    height: 100%;
    .group-td-contents{
      height: calc(100% - 32px);
      padding: 10px 0;
      overflow-y: auto;
      display: grid;
      grid-gap: 8px;
      // grid-template-columns: repeat(auto-fit, minmax(325px, 1fr));
      grid-template-rows: repeat(2, 220px);
      grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
    }
    .group-td-footer{
      text-align: center;
    }
  }
  // ::v-deep .group-td-dialog .group-td-dialog-header{
  //   padding: 10px 2px;
  //   border-bottom:1px solid $--border-color-form;
  // }
</style>
