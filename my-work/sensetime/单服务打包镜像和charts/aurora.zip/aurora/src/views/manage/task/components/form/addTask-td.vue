<template>
    <div style="display:flex;flex-direction: column;align-items: center;" v-if="visible" >
        <el-form ref="form" :model="form" :rules="rules" label-position="right" :label-width="labelWidth">
            <el-form-item :label="$t('task.contTaskName')" prop="taskName">
                <el-input v-model="form.taskName" placeholder=""></el-input>
            </el-form-item>
            <el-form-item  prop="defaultCheckedCameras" :label="$t('rule.contDevice')">
                <!-- <TreeSelect
                :defaultChechedKeys="form.defaultCheckedCameras"
                :multiple="false"
                @selected="selectedCamera"
                type="border" inputWidth="100%"
                :data="treeDataCameras" show-checkbox  /> -->
                <TreeSelectRadio
                :data="treeDataCameras"
                @check="selectedCamera"
                @clear="clearTreeSelectRadio"
                :defaultChechedKeys="form.defaultCheckedCameras"
                />
            </el-form-item>
            <el-form-item prop="snapStrategy" :label="$t('task.labelSnapStrategy')">
                <el-select
                @change="snapStrategyChange"
                v-model="form.snapStrategy"
                default-first-option>
                  <el-option :label="'定时模式'" :value="1"></el-option>
                  <el-option :label="'实时模式'" :value="0"></el-option>
                  <el-option :label="'精准模式'" :value="-1"></el-option>
                </el-select>
                <el-popover
                 class="right-tips"
                  placement="bottom-start"
                  width="400"
                  trigger="hover"
                  >
                  <div class="moudle-tips" v-html="$t('task.moudleTips')"></div>
                  <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
                </el-popover>

            </el-form-item>
            <el-form-item prop="quickresponsetime" v-if="form.snapStrategy>0" :label="$t('task.labelQuickresponsetime')">
                <el-input-number style="width:217px" v-model="form.quickresponsetime" :min="1" :max="999" step-strictly :step="1" ></el-input-number>
                <span class="right-tips">{{$t("pedestrian.sec")}}</span>
            </el-form-item>
            <el-form-item prop="specialAttribute" :label="$t('rule.contAttribute')">
                <el-select
                multiple
                collapse-tags
                v-model="form.specialAttribute"
                @change="specialAttributeChange"
                default-first-option
                :placeholder="$t('rule.listAttributeNone')">
                <el-option
                    v-for="item in specialAttributeOptions"
                    :key="item.id"
                    :label="item.name"
                    :disabled="item.disabled"
                    :value="item.id">
                </el-option>
                </el-select>
            </el-form-item>
            <el-form-item v-if="showKeepersSelect" prop="defaultCheckedKeepers" :label="$t('rule.labelAssociatedKeeper')">
                <KeeperSelect :devices="treeDataKeepers" :checkedDevices="form.defaultCheckedKeepers" @selecte="selectedKeeper" @blur="KeeperSelectBlur" />
            </el-form-item>
            <el-form-item prop="library" :label="$t('rule.labelOnlistLibrary')" v-show="showLibsList">
                <Select ref="treeLibs" :data="libsList" @ensure="handleEnsureLibrarySelect" :checkedKeys="form.library" />
            </el-form-item>
        </el-form>
        <div class="sapce-border"  ></div>
        <!-- <el-row style="width: 61%;margin:0 auto;" >
            <el-col :span="24" v-show="showLibsList">
                <div class="add-rule-td-libs" >
                    <header class="add-rule-td-libsheader-libs">
                    <span> <b>{{$t('rule.labelOnlistLibrary')}}</b> </span>
                    <span>{{ this.$t('rule.textboxNumberSelected',{number:libsCheckList.length})}}</span>
                    </header>
                    <div  class="add-rule-td-libs-scrollbox">
                    <el-tree
                        @check="handleLibsCheck"
                        :data="libsList"
                        node-key="id"
                        ref="treeLibs"
                        show-checkbox
                        :default-expanded-keys="autoExpandedLibsList"></el-tree>
                    </div>
                </div>
            </el-col>
        </el-row> -->
        <div style="width: 68%;margin:0 auto;">
        <el-form ref="form2" :model="form2" :rules="rules2" label-position="right" :label-width="language =='en'?'155px':labelWidth" >
          <div style="width:100%"></div>
            <el-form-item  prop="threshold" :label="$t('rule.contThreshold')">
                <el-select
                  style="width:90px"
                    class="add-rule-td-threshold"
                    v-model="form2.threshold"
                    filterable
                    allow-create
                    default-first-option
                    :placeholder="$t('rule.contThreshold')">
                    <el-option
                    v-for="(item,itemIndex) in thresholdOptions"
                    :key="itemIndex"
                    :label="Number(item*100).toFixed(1)"
                    :value="item">
                    </el-option>
                </el-select> %
            </el-form-item>
            <el-form-item prop="welcome" :label="$t('rule.labelOnlistLibrary')" v-if="this.form.specialAttribute.indexOf(5)>=0">
                <TreeTextarea :defaultSelected="form2.welcome" :data="libsList" @selectlib="welcomeSelect" />
            </el-form-item>
            <el-form-item prop="welcomebg" :label="$t('rule.contWelconebg')" v-if="this.form.specialAttribute.indexOf(5)>=0">
                <FileUpload :action="`${ruleHost}/api/v1/td/tasks/upload_file_osg`"
                :src="form2.welcomebg"
                @error="pictureUploadError"
                @success="pictureUploadSuccess" />
            </el-form-item>
        </el-form>
        </div>

        <el-row>
            <el-col :span="24" >
                <strong>{{$t('rule.contOtherSetting')}}</strong>
            </el-col>
            <el-col :span="24" style="padding-top:20px;">
                <div class="sapce-border" ></div>
            </el-col>
            <el-col :span="24">
                <el-row>
                    <el-col class="add-rule-td-other-header" >
                        <div :class="['add-rule-td-other-header-label',language == 'en'?'add-rule-td-other-header-label-en':'']" ><span>{{$t('rule.contMinFaceSize')}}</span> </div>
                        <div :class="['add-rule-td-other-header-input',language == 'en'?'add-rule-td-other-header-input-en':'']" >
                        <div :class="['add-rule-td-inputsnumber',minFaceInputError?'add-rule-td-inputsnumber-error':'']" ><el-input type="number" @keydown.native="inputLimit" :disabled="!isLoadedVideo" v-model="minFaceVal" @change="(v)=>handleInputFace(v,'min')"></el-input></div>
                        <div class="add-rule-td-inputsnumber" >X</div>
                        <div :class="['add-rule-td-inputsnumber',minFaceInputError?'add-rule-td-inputsnumber-error':'']" ><el-input type="number" @keydown.native="inputLimit" :disabled="!isLoadedVideo" v-model="minFaceVal" @change="(v)=>handleInputFace(v,'min')"></el-input></div>
                        <div>
                            <span class="tips-gray">
                            {{$t('rule.contmini')}}({{CONT_MINFACEVAL}}
                              <!-- -{{CONT_MAXFACELIMIT}} -->
                              )</span><br>
                            <el-button type="text" :disabled="!isLoadedVideo" @click="showFaceZoneOnVideo(minFaceVal)" v-if="showDrawer" >{{$t('rule.contPreviewDraw')}}</el-button>
                            <el-button v-if="isLoadedVideo" type="text" @click="resetDraw('minFace')">{{$t('rule.contResetDefault')}}</el-button>

                        </div>
                        </div>
                    </el-col>
                    <el-col class="add-rule-td-other-header" >
                        <div :class="['add-rule-td-other-header-label',language == 'en'?'add-rule-td-other-header-label-en':'']" ><span>{{$t('rule.contMaxFaceSize')}}</span> </div>
                        <div :class="['add-rule-td-other-header-input',language == 'en'?'add-rule-td-other-header-input-en':'']" >
                        <div :class="['add-rule-td-inputsnumber',maxFaceInputError?'add-rule-td-inputsnumber-error':'']" ><el-input type="number" @keydown.native="inputLimit" :disabled="!isLoadedVideo" :max="CONT_MAXFACELIMIT" v-model="maxFaceVal" @change="(v)=>handleInputFace(v,'max')"></el-input></div>
                        <div class="add-rule-td-inputsnumber" >X</div>
                        <div :class="['add-rule-td-inputsnumber',maxFaceInputError?'add-rule-td-inputsnumber-error':'']" ><el-input type="number" @keydown.native="inputLimit" :disabled="!isLoadedVideo" :max="CONT_MAXFACELIMIT" v-model="maxFaceVal" @change="(v)=>handleInputFace(v,'max')"></el-input></div>
                        <div>
                            <span class="tips-gray">
                              {{$t('rule.contLimit')}}(
                              <!-- {{CONT_MINFACEVAL}}- -->
                              {{CONT_MAXFACELIMIT}}
                              )</span><br>
                            <el-button type="text" :disabled="!isLoadedVideo" @click="showFaceZoneOnVideo(maxFaceVal)" v-if="showDrawer" >{{$t('rule.contPreviewDraw')}}</el-button>
                            <el-button v-if="isLoadedVideo" type="text"  @click="resetDraw('maxFace')">{{$t('rule.contResetDefault')}}</el-button>

                        </div>
                        </div>
                    </el-col>
                    <el-col class="add-rule-td-other-header" >
                        <div :class="['add-rule-td-other-header-label',language == 'en'?'add-rule-td-other-header-label-en':'']" ><span>{{$t('rule.contRecognitionArea')}}</span> </div>
                        <div :class="['add-rule-td-other-header-input',language == 'en'?'add-rule-td-other-header-input-en':'']" >
                        <span style="line-height:40px;" >{{hotZoneInput}}</span>
                        <div>
                            <el-button type="text" :disabled="!isLoadedVideo" @click="drawPreviewVideo('hot')" v-if="showDrawer" >{{$t('rule.contPreviewDraw')}}</el-button>
                            <el-button type="text" :disabled="!isLoadedVideo" @click="resetDraw('hot')" v-if="showDrawer">{{$t('rule.contResetDefault')}}</el-button>
                        </div>
                        </div>
                    </el-col>
                    <el-col :span="24" style="padding:0 40px">
                      <el-col :span="24" class="add-rule-td-videodrawer" v-show="showDrawer" >
                          <PolygonDrawer v-if="showDrawer"
                          ref="polygonDrawer"
                          :videoUrl="currentCamera.videoPath"
                          :polygons="polygonsData"
                          :rects="rectsData"
                          @finish="drawerPolygonsFinsh"
                          @loadedmetadata="handleLoadedmetadata"
                          :drawingPolygon="drawingPolygon"
                          :drawingRect="drawingRect" />
                      </el-col>
                    </el-col>
                </el-row>
            </el-col>
        </el-row>
    </div>
</template>

<script lang="ts">
import { Component, Vue , Watch, Prop} from 'vue-property-decorator';
import TreeSelect from '@/components/tree-select/index.vue';
import {cloneDeep} from 'lodash';
import PolygonDrawer from '../polygon-drawer.vue';
import {addTDRule,getSpecialAttrs,getDevices,getRuleListByKeepers,getLibsList, getDevicesTreeData} from '@/api/rule';
import {EventBus} from '@/utils/eventbus';
const defaultAcThreshold = window.globalConfig.acThreshold;
import {ruleThresholdOptions} from '@/utils/constants';
import {trim} from 'lodash';
import i18n from '@/lang/index';
import { AppModule } from '@/store/modules/app';
import { parse } from 'path';
import KeeperSelect from '../keeperSelect.vue';
import TreeTextarea from '../treeTextarea.vue';
import FileUpload from '../fileUpload.vue';
import {Cache} from '@/utils/cache';
const ruleHost = window.globalConfig.acHost;
import Select from "@/components/select/index.vue";
import TreeSelectRadio from "../treeSelectRadio.vue";

@Component({
  components: {
    TreeSelect,
    PolygonDrawer,
    KeeperSelect,
    TreeTextarea,
    FileUpload,
    Select,
    TreeSelectRadio
  },
})
export default class AddRuleTD extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({required:true}) labelWidth!: string;
  /* watch */
  @Watch('visible',{ immediate: true})
  onVisibleChange(n,o){
    n && this.initData();
  }
  @Watch('showLibsList',{ immediate: true})
  onshowLibsListChange(n,o){
    this.rules['library'][0].required = n;
  }
  @Watch('form.specialAttribute')
  onSpecialAttributeChange(n,o){
    this.rules2.welcome[0].required =  n.indexOf(5)>=0?true:false;
    // this.rules2.welcomebg[0].required =  n.indexOf(5)>=0?true:false;//修改为非必需

  }

  get language() {
    return AppModule.language;
  }
  /* data */
  $refs!:{
    treeLibs:HTMLFormElement,
    form:HTMLFormElement,
    form2:HTMLFormElement,
    polygonDrawer:HTMLFormElement
  };
  ruleHost:string=ruleHost;
  // accessToken:string=Cache.localGet('accessToken') || Cache.sessionGet('accessToken');

  // labelWidth:string='155px';
  form:{
    taskName:string;
    defaultCheckedCameras:any[];
    defaultCheckedKeepers:any[];
    specialAttribute:any[];
    threshold:any;
    library:any[];
    quickresponsetime:number;
    snapStrategy:number;
  }={
    taskName:'',
    defaultCheckedCameras:[],
    defaultCheckedKeepers:[],
    specialAttribute:[],
    threshold:0,
    library:[],
    quickresponsetime:1,
    snapStrategy:1
  };
  rules={
    taskName:[
        { required: true,validator:this.validateTaskName, trigger: 'blur' },
    ],
    specialAttribute:[
      { required: false },
    ],
    defaultCheckedCameras:[
      { required: true, message: i18n.t('form.texterrSelectDevice')+""},
    ],
    defaultCheckedKeepers:[
      { required: false, message: i18n.t('form.texterrSelectDevice')+""},
    ],
    library:[
      { required: true,message: i18n.t('form.texterrSelectImageLib') },
    ],
    quickresponsetime:[
      { required: true,message: i18n.t('form.texterrQuickresponsetime') },
    ],
    snapStrategy:[
      { required: true,message: '' },
    ],
  };
  form2:any={
    threshold:defaultAcThreshold,
    welcome:[],
    welcomebg:''
  };
  rules2={
    threshold:[
      { required: true, message: i18n.t('form.texterrEnterThreshold')+"", trigger: 'change' },
    ],
    welcome:[
      { required: false, message: i18n.t('form.texterrEnterWelcome')+"",trigger: 'blur' },
    ],
    welcomebg:[
      { required: false, message: i18n.t('form.texterrEnterWelcomebg')+"", trigger: 'blur'},
    ],
  };

  timeCheckListModel:any[]=[];
  libsCheckListModel:any[]=[];
  libsList:any[]=[{id:-1,label:"",children:[]},{id:0,label:"",children:[]}];

  treeDataCameras:any[] = [];
  treeDataKeepers:any[] = [];
  props:any=this.$props;
  thresholdOptions = ruleThresholdOptions;
  specialAttributeOptions:any[]=[];

  selectedSenseKeeperList:any[]=[];
  selectedSenseKeeperRuleIds:any[]=[];
  selectedTimesList:any[]=[];
  selectedLibsList:any[]=[];

  hotZoneInput:string="";
  hotZone:any=[];

  currentCamera:any;

  polygonsData:any[] = [];
  rectsData:any[]=[];
  drawPolygonsFinistData:any[]=[];
  drawingPolygon:boolean = false;
  drawingRect:boolean = false;

  showDrawer:boolean=false;
  currentEditType:string="";

  showVideo:boolean=false;
  keepersTimezoneLibsRelation:any[]=[];
  autoExpandedLibsList:any[]=[];

  keeperDisabledLibs:any[]=[];
  //hot validate

  showLibsList:boolean=true;
  libsCheckList:any[]=[];

  showKeepersSelect:boolean=false;
  //validate hot face

  CONT_MINFACELIMIT:number=30;
  CONT_MINFACEVAL:number=30;
  CONT_MAXFACEVAL:number=300;
  CONT_MAXFACELIMIT:number=1080;

  minFaceLimit:number=this.CONT_MINFACELIMIT;
  minFaceVal:number=this.CONT_MINFACEVAL;
  maxFaceVal:number=this.CONT_MAXFACEVAL;
  maxFaceLimit:number=this.CONT_MAXFACELIMIT;

  minFaceInputError:boolean=false;
  maxFaceInputError:boolean=false;
  isLoadedVideo:boolean=false;
  videoWidth:number=1920;
  videoHeight:number=1080;

  loading:boolean=false;
  /* methods */
  //validate
  validateTaskName(rule, value, callback){
      let str = value;
      if (str === '') {
      callback(new Error(i18n.tc('task.texterrEnterTaskName')));
      } else {
          //去除两头空格:
          let regx = /^\s+|\s+$/g;
          while (regx.test(str)) {
              str   =  trim(str);
          };
          str   =  trim(str);
          if(str && str.length<=40){
              callback();
          }else{
              callback(new Error(i18n.tc('task.texterrEnterTaskName')));
          }
      }
  }
  getParamsValueFromURL(key){
    let url_string = location.href.split('?')[1];
    let searchParams = new URLSearchParams(url_string);
    return searchParams.get(key) || '';
  }
  initData(){
    setTimeout(() => {
      this.$refs.form && this.$refs.form.clearValidate();
      this.$refs.form2 && this.$refs.form2.clearValidate();
    }, 30);

    this.libsCheckList = [];

    this.loading = false;
    //defaultCheckedKeepers validate
    this.rules.defaultCheckedKeepers[0]['required'] = false;

    this.treeDataCameras= [];
    this.treeDataKeepers= [];
    this.form.defaultCheckedCameras = [];
    this.form.defaultCheckedKeepers = [];
    this.form.library=[];
    this.form.quickresponsetime=1;
    this.form.snapStrategy=1;
    this.currentCamera = null;
    this.specialAttributeOptions = [];
    this.form.specialAttribute = [];
    this.form.taskName = '';
    this.form2.threshold = defaultAcThreshold;
    this.form2.welcome = [];
    this.form2.welcomebg = '';

    this.selectedSenseKeeperList=[];
    this.selectedSenseKeeperRuleIds=[];
    this.selectedTimesList=[];
    this.selectedLibsList=[];

    this.showDrawer = false;
    this.hotZoneInput = this.$tc('rule.contNone');
    this.hotZone=[];

    this.keeperDisabledLibs = [];

    this.showLibsList = true;

    this.showKeepersSelect = false;

    this.minFaceVal=this.CONT_MINFACEVAL;
    this.maxFaceVal=this.CONT_MAXFACEVAL;

    this.minFaceInputError=false;
    this.maxFaceInputError=false;
    this.rectsData = [];
    this.isLoadedVideo = false;
    this.videoWidth=1920;
    this.videoHeight=1080;

    this.getLibsList();
    this.getSpecialAttrs();
    this.getDevices(14);//camera
    this.getDevices(2);//keeper
  }
  handleEnsureLibrarySelect(keys){
    this.form.library = [];
    keys && keys.length>0 && keys.map(i=>{ i && i>0 && this.form.library.push(i)})
  }
  inputLimit(e){
    let key = e.key;
    if (key === 'e' || key === '.') {
      e.returnValue = false
      return false
    }
    return true
  }
  handleInputFace(val,type){
    val = parseInt(val);
    //input min face value
    if(type == 'min'){
      this.minFaceVal = val
      if(val >= this.CONT_MINFACELIMIT && val <= this.CONT_MAXFACELIMIT && val <= this.maxFaceVal){
        this.minFaceInputError = false;
        this.maxFaceInputError = false;
      }else{
        this.minFaceInputError = true;
      }
    }
    //input max face value
    if(type == 'max'){
      this.maxFaceVal = val
      if(val >= this.CONT_MINFACELIMIT && val <= this.CONT_MAXFACELIMIT && val >= this.minFaceVal){
        this.minFaceInputError = false;
        this.maxFaceInputError = false;
      }else{
        this.maxFaceInputError = true;
      }
    }
  }
  snapStrategyChange(v){
    v <= 0 && (this.form.quickresponsetime = v);
  }
  showFaceZoneOnVideo(val){
    val = parseInt(val);
    this.setFaceZone(val)
  }
  setFaceZone(val){
    let video_w = this.videoWidth,video_h=this.videoHeight;
    if(val){
      let leftTop = {x:video_w/2 - val/2,y:video_h/2 - val/2};
      let rightBottom = {x:video_w/2 + val/2,y:video_h/2 + val/2};
      this.rectsData = [{leftTop,rightBottom}];
    }else{
      this.rectsData = [];
    }
  }
  getSpecialAttrs(){
    getSpecialAttrs(1).then((res:any)=>{
      res && res.list.map(item=>{
        this.specialAttributeOptions.push({
          id:item.taskAttributeId,
          name:this.$tc(`rule.${item.taskAttributeName}`),
          disabled:false
        })
      })
    })
  }
  getDevices(type?){
    let deviceType = type?type:1;
    let filter = deviceType == 2?2:0;
    getDevicesTreeData({deviceType,filter}).then(res=>{
      this.formatTreeData(res.data,type);
    })
  }
  formatTreeData(data,type){
    type == 14 && (this.treeDataCameras = data);
    type == 2 && (this.treeDataKeepers = data);
  }
  hide(){
    this.$emit('hideAddRuletdDialog')
  }
  handleClose(){
    this.hide();
  }
  selectedKeeper(data){
    if(data && data.length>0){
      this.form.defaultCheckedKeepers = data;
      this.getRuelIdsBykeepersIds(data);
    }else{
      this.form.defaultCheckedKeepers=[];
      this.getRuelIdsBykeepersIds([]);
    }
    this.$refs.form.validateField('defaultCheckedKeepers');
  }
  KeeperSelectBlur(e){
    this.$refs.form.validateField('defaultCheckedKeepers');
  }
  getOnlyKeeperIds(list){
    let arr:any = [];
    list.map((item)=>{
      arr.push(item.id)
    })
    return arr;
  }
  selectedCamera(cameras){
    this.isLoadedVideo = false;
    if(cameras.length>0){
      let camera = cameras[0];
      this.form.defaultCheckedCameras = this.getOnlyKeeperIds(cameras);
      this.currentCamera = camera;
      if(this.currentCamera && this.currentCamera.videoPath){
        this.showDrawer = true;
      }else{
        this.showDrawer = false;
      }
    }else{
      this.showDrawer = false;
      this.form.defaultCheckedCameras=[];
      this.currentCamera=null;
    }
    this.$refs.form.validateField('defaultCheckedCameras');
  }
  clearTreeSelectRadio(){
    this.showDrawer = false;
    this.form.defaultCheckedCameras=[];
    this.currentCamera=null;
    this.$refs.form.validateField('defaultCheckedCameras');
  }
  setKeeperListActiveEmpty(){
    this.selectedSenseKeeperList && this.selectedSenseKeeperList.map((keeper,keeperIndex)=>{
      let keeper_clone = cloneDeep(keeper);
      keeper_clone['active'] = false;
      Vue.set(this.selectedSenseKeeperList,keeperIndex,keeper_clone);
    })
  }
  setTimezoneListActiveEmpty(){
    this.selectedTimesList && this.selectedTimesList.map((timezone,timezoneIndex)=>{
      let timezone_clone = cloneDeep(timezone);
      timezone_clone['active'] = false;
      Vue.set(this.selectedTimesList,timezoneIndex,timezone_clone);
    });
  }
  clickKeeperItem(keeper,keeperIndex){
    this.setKeeperListActiveEmpty();
    let keeper_clone = cloneDeep(keeper);
    keeper_clone['active'] = true;
    Vue.set(this.selectedSenseKeeperList,keeperIndex,keeper_clone);
    //点击keeper
    this.selectedTimesList = [];
    this.selectedTimesList = this.getTimezonesFromRelations(keeper.id);
  }
  clickTimezoneItem(timezone,timezoneIndex){
    this.setTimezoneListActiveEmpty();
    let timezone_clone = cloneDeep(timezone);
    timezone_clone['active'] = true;
    Vue.set(this.selectedTimesList,timezoneIndex,timezone_clone);
    //点击timezone
    this.selectedLibsList = [];
    this.selectedLibsList = timezone.libraryVos;
  }
  getTimezonesFromRelations(keeperid){
    let currentKeeperIndex = this.keepersTimezoneLibsRelation.findIndex(item=> item.deviceVo.deviceId == keeperid);
    let currentKeeper = this.keepersTimezoneLibsRelation[currentKeeperIndex];
    let currentTimezones:any[]=[];
    if(currentKeeper){
      currentTimezones = currentKeeper.timezoneLibraryRelation;
    }
    return currentTimezones;
  }
  specialAttributeChange(v){
    if(v.indexOf(3) >= 0){//防尾随
      this.setAllLibsListDisadled();
      this.rules['defaultCheckedKeepers'][0]['required'] = true;
      this.showLibsList = false;
      //keeper
      this.showKeepersSelect = true;
      this.form.defaultCheckedKeepers = [];
      this.selectedSenseKeeperList=[];
      this.getRuelIdsBykeepersIds([]);
    }else{
      this.$refs.form.clearValidate('defaultCheckedKeepers');
      this.rules['defaultCheckedKeepers'][0]['required'] = false;
      this.clearLibsListDisadled();
      // this.showLibsList = true;
      this.showLibsList = v.indexOf(5) < 0;//迎宾
      //keeper
      this.form.defaultCheckedKeepers = [];
      this.selectedSenseKeeperList=[];
      this.getRuelIdsBykeepersIds([]);
      this.showKeepersSelect = false;
    };

    if(v.indexOf(3) >= 0 && v.length>0){
      this.specialAttributeOptions.map(sa=>{
        if(sa.id != 3) sa.disabled = true;
      })
    }else if(v.length>0){
      this.specialAttributeOptions.map(sa=>{
        if(sa.id == 3) sa.disabled = true;
      })
    }
    if(v.length == 0){
      this.specialAttributeOptions.map(sa=>{
        sa.disabled = false;
      })
    }
  }
  //libslist
  getLibsList(keywords?){
    getLibsList(keywords).then(res=>{
      this.libsList=[];
      res && this.formatLibs(res);
    })
  }
  formatLibs(res){
    this.libsList = [{id:-1,name:this.$tc('rule.contWhitelist'),children:[]},{id:0,name:this.$tc('rule.contBlacklist'),children:[]}];
    res.whitelists && res.whitelists.map((item:any)=>{
       this.libsList[0].children.push({
        id:item.libraryId,
        name:item.libraryName,
        disabled:false
      })
    });
    res.blacklists && res.blacklists.map((item:any)=>{
       this.libsList[1].children.push({
        id:item.libraryId,
        name:item.libraryName,
        disabled:false
      })
    });
  }
  setLibsListDisadled(libraryIds){
    let checkeds:any[] =  this.$refs.treeLibs.$refs.tree.getCheckedKeys(true);
    //set the disabled leaf disabled no check
    this.$refs.treeLibs.$refs.tree.setChecked(libraryIds,false);
    //set disadled
    this.libsList[0].children.map((item,itemIndex)=>{
      item.disabled = libraryIds.some(i=>i == item.id);
      item.disabled && this.keeperDisabledLibs.push(item.id);
    });
    this.libsList[1].children.map((item,itemIndex)=>{
      item.disabled = libraryIds.some(i=>i == item.id);
      item.disabled && this.keeperDisabledLibs.push(item.id);
    });
    this.$refs.treeLibs.$refs.tree.updateKeyChildren(-1,cloneDeep(this.libsList[0].children));
    this.$refs.treeLibs.$refs.tree.updateKeyChildren(0,cloneDeep(this.libsList[1].children));
    //set checked filter
    let checkedIds:any[]=[];
    checkeds.map(checkedlibId=>{
      libraryIds.indexOf(checkedlibId) < 0 && checkedIds.push(checkedlibId);
    });
    Vue.nextTick(()=> {
      this.$refs.treeLibs.$refs.tree.setCheckedKeys(checkedIds);
    });
  }
  setAllLibsListDisadled(){
    this.libsList[0].children.map((item,itemIndex)=>{item.disabled = true});
    this.libsList[1].children.map((item,itemIndex)=>{item.disabled = true});
    this.$refs.treeLibs.$refs.tree.updateKeyChildren(-1,cloneDeep(this.libsList[0].children));
    this.$refs.treeLibs.$refs.tree.updateKeyChildren(0,cloneDeep(this.libsList[1].children));
  }
  clearLibsListDisadled(){
    let checkeds:any[] =  this.$refs.treeLibs.$refs.tree.getCheckedKeys(true);
    this.libsList[0].children.map((item,itemIndex)=>{
      !this.keeperDisabledLibs.some(it=>it == item.id) && (item.disabled =  false);
    });
    this.libsList[1].children.map((item,itemIndex)=>{
      !this.keeperDisabledLibs.some(it=>it == item.id) && (item.disabled =  false);
    });
    this.$refs.treeLibs.$refs.tree.updateKeyChildren(-1,cloneDeep(this.libsList[0].children));
    this.$refs.treeLibs.$refs.tree.updateKeyChildren(0,cloneDeep(this.libsList[1].children));
    Vue.nextTick(()=> {
      this.$refs.treeLibs.$refs.tree.setCheckedKeys(checkeds);
    });
  }
  handleLoadedmetadata(data){
    if(data.isLoaded) this.isLoadedVideo = true;
    if(data && data.w>0 && data.h>0) this.videoWidth = data.w,this.videoHeight = data.h;
  }
  drawPreviewVideo(type){
    this.currentEditType = type;
    this.editTypeChange(type);
  }
  resetDraw(type:string){
    this.drawingRect = false;
    this.drawingPolygon = false;

    if(type === 'minFace'){
      this.minFaceInputError=false;
      this.rectsData = [];
      this.minFaceVal=this.CONT_MINFACEVAL;
    };
    if(type === 'maxFace'){
      this.maxFaceInputError=false;
      this.rectsData = [];
      this.maxFaceVal=this.CONT_MAXFACEVAL;
    };
    if(type === 'hot'){
      this.polygonsData = [];
      this.hotZone = [];
      this.hotZoneInput = this.$tc('rule.contNone');
    };
  }
  drawerPolygonsFinsh(data){
    this.drawPolygonsFinistData = data;
    if(this.currentEditType == 'hot' ){
      this.hotZone = this.setZeroOfPoints(data);
      this.hotZoneInput = this.$tc('rule.contDrawn');
    }else if(this.currentEditType == 'minFace') {
      // this.minFace = this.calculationRect(data);
    }else if(this.currentEditType == 'maxFace'){
      // this.maxFace = this.calculationRect(data);
    }
  }
  setZeroOfPoints(list){
    let arr:any[]=[];
    list && list.length>0 && list.map(item =>{
      if(item.x<0){
        item.x = 0;
      }
      if(item.y<0){
        item.y = 0;
      }
      arr.push(item);
    });
    return arr;
  }
  clearHotDraw(){
    this.drawingPolygon = false;
    this.drawingRect = false;
    this.polygonsData = [];
  }
  editTypeChange(type:string){
    if(type === 'minFace'){
      this.drawingPolygon = false;
      this.drawingRect = true;
    }
    if(type === 'maxFace'){
      this.drawingPolygon = false;
      this.drawingRect = true;
    }
    if(type === 'hot'){
      this.drawingPolygon = true;
      this.drawingRect = false;
    }
  }
  calculationRect(data){
    let w:number = data.rightBottom && data.leftTop? data.rightBottom.x -data.leftTop.x : 0;
    let h:number = data.rightBottom && data.leftTop? data.rightBottom.y -data.leftTop.y : 0;
    let obj = {width:Math.round(w),height:Math.round(h),pointVos:[data.leftTop,data.rightBottom]};
    return obj;
  }
  handleLibsCheck(data,check){
    this.libsCheckList=[];
    check && check.checkedKeys && check.checkedKeys.length>0 && check.checkedKeys.map(item=>{
      item>0 && this.libsCheckList.push(item);
    })

  }
  getRuelIdsBykeepersIds(keeperIds){
    if(keeperIds && keeperIds.length == 0){
      this.keeperDisabledLibs = [];
      this.selectedSenseKeeperRuleIds = [];
      this.keepersTimezoneLibsRelation = [];
      this.selectedTimesList=[];
      this.selectedLibsList=[];
      this.selectedSenseKeeperRuleIds=[];
      //clear libs disabled
      this.clearLibsListDisadled();
      return false;
    }
    keeperIds && getRuleListByKeepers(keeperIds).then((res:any)=>{
      this.selectedSenseKeeperRuleIds = [];
      res && (this.keepersTimezoneLibsRelation = res.list);
      res && (this.selectedSenseKeeperRuleIds = this.getOnlyRuleIds(res.list));
      //set libs disabled by keeperIds
      let relationLibsIds = this.getLibsIdsFromTimezoneLibsRelation(res.list);
      relationLibsIds.length>0 && this.setLibsListDisadled(relationLibsIds);

    }).catch().finally(()=>{
      if(this.form.specialAttribute.indexOf(3) >=0){
        this.setAllLibsListDisadled();
      }
    });
  }
  getLibsIdsFromTimezoneLibsRelation(timezoneLibsRelation){
    let libsArr:any[]=[];
    timezoneLibsRelation && timezoneLibsRelation.length>0 && timezoneLibsRelation.map(relation=>{
      relation.timezoneLibraryRelation && relation.timezoneLibraryRelation.length>0 && relation.timezoneLibraryRelation.map(timezoneLibrary=>{
        timezoneLibrary.libraryVos && timezoneLibrary.libraryVos.length> 0 && timezoneLibrary.libraryVos.map(library=>{
          let libraryId = library.libraryId;
          libraryId && libsArr.indexOf(libraryId) < 0 && libsArr.push(libraryId);
        })
      })
    });
    return libsArr;
  }
  getOnlyRuleIds(keepersTimezoneLibsRelation:any[]){
    let arr:any = [];
    keepersTimezoneLibsRelation.map((item)=>{
      arr.push(item.taskId)
    });
    return arr;
  }
  // getOnlyLeafTreeLibs(){
  //   let list = this.$refs.treeLibs.$refs.tree.getCheckedKeys(true);
  //   let lis:any[]=[];
  //   list.map(item=>{
  //     item > 0 && lis.push(item);
  //   });
  //   return lis;
  // }
  welcomeSelect(dat){
    this.form2.welcome = dat;
    this.$refs.form2.validateField('welcome');
  }
  pictureUploadError(error){
    let data = error.message?JSON.parse(error.message):null;
    data && this.$message.error({showClose:true,message:this.$te(data.code)?this.$t(data.code):data.message});
    this.$refs.form2.validateField('welcomebg');
  }
  pictureUploadSuccess(file){
    this.form2.welcomebg = file;
    this.$refs.form2.validateField('welcomebg');
  }
  getLibraryIdsFromWelcome(welcome){
    let arr:any[]=[];
    welcome && welcome.length>0 &&( arr =  welcome.map(item=>item.libraryId))
    return arr;
  }
  handleHotzoneData(hotZone){//format to [0,1]
  if(this.showDrawer === false) return [];
    let arr:any[] = [], _w = this.$refs.polygonDrawer.canvasStyle.width, _h = this.$refs.polygonDrawer.canvasStyle.height;
    if(_w > 0 && _h > 0 && hotZone && hotZone.length > 0){
      arr = hotZone.map(item =>{
        let x = item.x/_w , y = item.y/_h;
        return {x,y}
      })
    }
    if(arr.length>1){
       arr[0].x == arr[arr.length-1].x
    && arr[0].y == arr[arr.length-1].y
    && arr.splice(arr.length-1,1)
    }
    return arr.length>0?arr:hotZone;
  }
  formatSubmitData(){
    let data = {
      "deviceId": this.currentCamera?this.currentCamera.id:'',
      "hotRegionVo": {
        "hotRegionPoints": this.handleHotzoneData(this.hotZone),
        // "maxFace":this.maxFace,
        "maxFace":{width:this.maxFaceVal,height:this.maxFaceVal},
        // "minFace":this.minFace,
        "minFace":{width:this.minFaceVal,height:this.minFaceVal},
      },
      "acTaskIds": this.selectedSenseKeeperRuleIds || [],
      // "libraryIds": this.form.specialAttribute.indexOf(5)>=0?this.getLibraryIdsFromWelcome(this.form2.welcome):this.getOnlyLeafTreeLibs(),//迎宾人像库处理为正常人象库
      "libraryIds": this.form.specialAttribute.indexOf(5)>=0?this.getLibraryIdsFromWelcome(this.form2.welcome):this.form.library,//迎宾人像库处理为正常人象库
      "taskAttributeIds": this.form.specialAttribute,
      "taskType": 1,//0->ac 1->td
      "threshold": this.form2.threshold,
      "welcomeRemarksRequests":this.form2.welcome,
      "backgroundImage":this.form2.welcomebg,
      "taskName":this.form.taskName,
      "quickResponseTime":this.form.quickresponsetime
    };
    if(data.threshold>0 && data.threshold<100 && !this.thresholdOptions.some((item)=> data.threshold == item)){
      data.threshold = (data.threshold*1000)/100000 ;
    }
    return data;
  }
  ensure(startcal,successcal,errorcal){
    let data = this.formatSubmitData();
    this.$refs.form.validate(valid=>{
      valid && this.$refs.form2.validate(vali=>{
        if(vali && !this.maxFaceInputError && !this.minFaceInputError){
          if(this.form.specialAttribute.indexOf(3)<0 && data.libraryIds.length == 0){
            this.$message.error({showClose:true,message:this.$tc('form.texterrSelectImageLib')});
            return false;
          }
          startcal && startcal();
          addTDRule(data).then(res=>{
            this.loading = false;
            this.hide();
            successcal && successcal(res);
          }).catch((error)=>{
            errorcal && errorcal(error);
          })
          .finally(()=>{

          })
        }
      })
    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .add-rule-td-threshold{
    width: 120px;
  }
  .add-rule-td-libs{
    padding-bottom: 20px;
    &>div{
      box-sizing:border-box;
    }
    .add-rule-td-border-left{
      border-left: 1px solid $--border-color-form;
    }
    .add-rule-td-libsheader{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;

    }
    .add-rule-td-libsheader-libs{
      height: 24px;
      display: flex;
      justify-content: space-between;
      line-height: 24px;
      color: $--color-black;
    }
    .add-rule-td-libs-scrollbox{
      width: 100%;
      max-height: 225px;
      overflow: auto;
      min-height: 50px;
      .add-rule-td-listitem{
        padding:8px 5px;
        cursor: pointer;
      }
      .add-rule-td-listitem:hover{
        background-color: $--color-bg-3;
      }
      .add-rule-td-listitem-active{
        background-color: $--color-bg-3;
        position: relative;
        .add-rule-td-icon-right{
          position: absolute;
          right: 5px;
          top: calc(50% - 8px);
        }
      }
      .add-rule-td-listitem-text{
        display: inline-block;
        width: calc(100% - 20px);
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap
      }
    }
  }
  .add-rule-td-other-header{
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    .add-rule-td-other-header-label{
      padding-top: 12px;
      line-height: 16px;
      width: 182px;
      margin-right: 10px;
      text-align: right;
      word-wrap: break-word;
      word-break: normal;
    }
    .add-rule-td-other-header-label-en{
      width: 220px;
    }
    .add-rule-td-other-header-input{
      width:252px;
      .add-rule-td-inputsnumber{
        width: 70px;
        text-align: center;
        display: inline-block;
        .el-input{
          ::v-deep input[type=number]::-webkit-inner-spin-button,
          input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
          }
        }

      }
    }
    .add-rule-td-other-header-input-en{
      width:288px;
    }
  }
  .add-rule-td-videodrawer{
    background-color: $--color-black;
    padding: 10px;
  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
::v-deep .el-form{
      max-width: 372px;
      margin: 0 auto;
    }
  .add-rule-td-keepertreeinput{
    width: 100%;
  }
::v-deep .add-rule-td-inputsnumber-error .el-input .el-input__inner{
    border-color: #db4436;
  }
::v-deep .add-rule-td-libs .el-tree>.el-tree-node>.el-tree-node__content{
    background-color: #e8ebf5;
  }
::v-deep .el-select__tags .el-tag--info {
    color: #28354d;
  }
::v-deep  .el-select-group__title {
    color: #909399;
}
::v-deep .el-select{
  width: 100%;
}
</style>
