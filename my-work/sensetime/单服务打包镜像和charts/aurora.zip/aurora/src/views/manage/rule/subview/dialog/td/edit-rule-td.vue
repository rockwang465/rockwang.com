<template>
  <el-dialog
  :title="$t('rolemanagement.titleReminder')"
  :visible.sync="visible"
  width="30%"
  custom-class="edit-rule-td-dialog-container"
  :center="true"
  :before-close="handleClose">
  <!-- title -->
  <p slot="title" style="text-align:left" >{{$t('rule.listEdit')}}</p>
  <!-- content -->
  <div style="max-height:calc(70vh - 106px);overflow:auto;">
    <el-form ref="form" :model="form" :rules="rules" label-position="left">
      <br/>
      <el-form-item :label-width="labelWidth" prop="ruleGroupName" :label="$t('rule.contRulesetName')">
        {{form.ruleGroupName}}
      </el-form-item>
      <el-form-item :label-width="labelWidth" prop="ruleName" :label="$t('rule.labelRuleName')">
        <el-input v-model="form.ruleName" type="text" ></el-input>
      </el-form-item>
      <el-form-item :label-width="labelWidth" prop="deviceName" :label="$t('rule.contDevice')">
        {{form.deviceName}}
      </el-form-item>
      <el-form-item :label-width="labelWidth" prop="deviceGroupName" :label="$t('rule.labelDeviceGroup')">
        {{form.deviceGroupName}}
      </el-form-item>
      <!-- <el-form-item :label-width="labelWidth" prop="defaultCheckedCameras" label="设备">
        <TreeSelect
          :defaultChechedKeys="form.defaultCheckedCameras"
          :multiple="false"
          @selected="selectedCamera"
          type="border" inputWidth="100%"
          :data="treeDataCameras" show-checkbox  />
      </el-form-item> -->
      <el-form-item :label-width="labelWidth" prop="specialAttribute" :label="$t('rule.labelAttribute')">
        <el-select
          multiple
          collapse-tags
          v-model="form.specialAttribute"
          @change="specialAttributeChange"
          default-first-option
          :placeholder="$t('rule.listAttributeNone')">
          <el-option
            v-for="item in specialAttributeOptions"
            :key="item.id"
            :label="item.name"
            :disabled="item.disabled"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="showKeepersSelect" :label-width="labelWidth" :label="$t('rule.labelAssociatedKeeper')" prop="defaultCheckedKeepers">
        <KeeperSelect :devices="treeDataKeepers" :checkedDevices="form.defaultCheckedKeepers" @selecte="selectedKeeper" @blur="KeeperSelectBlur" />
      </el-form-item>
    </el-form>
    <div class="sapce-border" ></div>
    <el-row style="width: 61%;margin:0 auto;" >
        <el-col :span="24" v-show="showLibsList">
          <div class="edit-rule-td-libs" >
            <header class="edit-rule-td-libsheader-libs">
              <span> <b>{{$t('rule.labelOnlistLibrary')}}:</b> </span>
              <span>{{ this.$t('rule.textboxNumberSelected',{number:libsCheckList.length})}}</span>
            </header>
            <div  class="edit-rule-td-libs-scrollbox">
              <el-tree :data="libsList"
                @check="handleLibsCheck"
                node-key="id"
                ref="treeLibs"
                show-checkbox
                :default-expanded-keys="autoExpandedLibsList" ></el-tree>
            </div>
          </div>
        </el-col>
        <el-col :span="24" >
          <el-form ref="form2" :model="form2" :rules="rules2" label-position="left" >
            <el-form-item :label-width="labelWidth" prop="threshold" :label="$t('rule.contThreshold')">
              <el-select
                class="edit-rule-td-threshold"
                v-model="form2.threshold"
                filterable
                allow-create
                default-first-option
                :placeholder="$t('rule.contThreshold')">
                <el-option
                  v-for="(item,itemIndex) in thresholdOptions"
                  :key="itemIndex"
                  :label="Number(item*100).toFixed(1)"
                  :value="item">
                </el-option>
              </el-select> %
            </el-form-item>
            <el-form-item :label-width="labelWidth" prop="welcome" :label="$t('rule.contWelcone')" v-if="this.form.specialAttribute.indexOf(5)>=0">
              <TreeTextarea :defaultSelected="form2.welcome" :data="libsList" @selectlib="welcomeSelect" />
            </el-form-item>
            <el-form-item :label-width="labelWidth" prop="welcomebg" :label="$t('rule.contWelconebg')" v-if="this.form.specialAttribute.indexOf(5)>=0">
              <!-- <el-upload
                :file-list="uploadImageList"
                :headers="{accessToken}"
                :limit="1"
                :on-exceed="handleUploadExceed"
                :on-change="handleUploadChange"
                :on-remove="handleUploadRemove"
                list-type="picture"
                :before-upload="beforeAvatarUpload"
                :on-error="pictureUploadError"
                :on-success="pictureUploadSuccess"
                :action="`${ruleHost}/api/v1/td/tasks/upload_file_osg`">
                <el-button type="text">{{$t('rule.contlUploadbg')}}</el-button>
              </el-upload> -->
              <FileUpload :action="`${ruleHost}/api/v1/td/tasks/upload_file_osg`"
                :src="form2.welcomebg"
                @error="pictureUploadError"
                @success="pictureUploadSuccess" />
            </el-form-item>
          </el-form>
        </el-col>
    </el-row>

    <el-row>
      <el-col :span="24" >
        <b>{{$t('rule.contOtherSetting')}}</b>
      </el-col>
      <el-col :span="24" style="padding-top:20px;">
        <div class="sapce-border" ></div>
      </el-col>
      <el-col :span="24">
        <el-row>
          <el-col class="edit-rule-td-other-header" >
            <div class="edit-rule-td-other-header-label" >{{$t('rule.contMinFaceSize')}}</div>
            <div :class="['edit-rule-td-other-header-input',language == 'en'?'edit-rule-td-other-header-input-en':'']" >
              <div :class="['edit-rule-td-inputsnumber',minFaceInputError?'edit-rule-td-inputsnumber-error':'']" ><el-input type="number" v-model="minFaceVal" @change="(v)=>handleInputFace(v,'min')"></el-input></div>
              <div class="edit-rule-td-inputsnumber" >X</div>
              <div :class="['edit-rule-td-inputsnumber',minFaceInputError?'edit-rule-td-inputsnumber-error':'']" ><el-input type="number" v-model="minFaceVal" @change="(v)=>handleInputFace(v,'min')"></el-input></div>
              <div>
                <el-button type="text" :disabled="!isLoadedVideo" @click="showFaceZoneOnVideo(minFaceVal)" v-if="showDrawer" >{{$t('rule.contPreviewDraw')}}</el-button>
                <el-button type="text" :disabled="!isLoadedVideo" @click="resetDraw('minFace')">{{$t('rule.contResetDefault')}}</el-button>
                <span>({{CONT_MINFACEVAL}}-{{CONT_MAXFACEVAL}})</span>
              </div>
            </div>
          </el-col>
          <el-col class="edit-rule-td-other-header" >
            <div class="edit-rule-td-other-header-label" >{{$t('rule.contMaxFaceSize')}}</div>
            <div :class="['edit-rule-td-other-header-input',language == 'en'?'edit-rule-td-other-header-input-en':'']" >
              <div :class="['edit-rule-td-inputsnumber',maxFaceInputError?'edit-rule-td-inputsnumber-error':'']" ><el-input type="number" v-model="maxFaceVal" @change="(v)=>handleInputFace(v,'max')"></el-input></div>
              <div class="edit-rule-td-inputsnumber" >X</div>
              <div :class="['edit-rule-td-inputsnumber',maxFaceInputError?'edit-rule-td-inputsnumber-error':'']" ><el-input type="number" v-model="maxFaceVal"  @change="(v)=>handleInputFace(v,'max')"></el-input></div>
              <div>
                <el-button type="text" :disabled="!isLoadedVideo" @click="showFaceZoneOnVideo(maxFaceVal)" v-if="showDrawer" >{{$t('rule.contPreviewDraw')}}</el-button>
                <el-button type="text" :disabled="!isLoadedVideo" @click="resetDraw('maxFace')">{{$t('rule.contResetDefault')}}</el-button>
                <span>({{CONT_MINFACEVAL}}-{{CONT_MAXFACEVAL}})</span>
              </div>
            </div>
          </el-col>
          <el-col class="edit-rule-td-other-header" >
            <div class="edit-rule-td-other-header-label" >{{$t('rule.contRecognitionArea')}}</div>
            <div :class="['edit-rule-td-other-header-input',language == 'en'?'edit-rule-td-other-header-input-en':'']" >
              <span style="line-height:40px;" >{{hotZoneInput}}</span>
              <div>
                <el-button type="text" :disabled="!isLoadedVideo" @click="drawPreviewVideo('hot')" v-if="showDrawer" >{{$t('rule.contPreviewDraw')}}</el-button>
                <el-button type="text" :disabled="!isLoadedVideo" @click="resetDraw('hot')" v-if="showDrawer">{{$t('rule.contResetDefault')}}</el-button>
                <!-- <el-button type="text" @click="clearHotDraw">{{$t('rule.contClear')}}</el-button> -->
              </div>
            </div>
          </el-col>
          <el-col :span="24" class="edit-rule-td-videodrawer" v-if="showDrawer && visible" >
            <PolygonDrawer v-if="showDrawer"
              :videoUrl="currentCamera? currentCamera.videoPath:''"
              :polygons="polygonsData"
              :rects="rectsData"
              @finish="drawerPolygonsFinsh"
              @loadedmetadata="handleLoadedmetadata"
              :drawingPolygon="drawingPolygon"
              :drawingRect="drawingRect" />
          </el-col>
        </el-row>
      </el-col>
    </el-row>
  </div>


    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="ensure" :loading="loading">{{$t('rule.buttonOK')}}</el-button>
      <el-button @click="hide" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>
</template>

<script lang="ts">
import { Component, Vue , Watch, Prop} from 'vue-property-decorator';
import TreeSelect from '@/components/tree-select/index.vue';
import {cloneDeep} from 'lodash';
import PolygonDrawer from '../../components/polygon-drawer.vue';
import {updateRuleTd,getSpecialAttrs,getRuleListByKeepers,getLibsList,getDevicesTreeData,getRuleTDDetail} from '@/api/rule';
const defaultAcThreshold = window.globalConfig.acThreshold;
import {ruleThresholdOptions} from '@/utils/constants';
import {EventBus} from '@/utils/eventbus';
import { close } from 'fs';
import {trim} from 'lodash';
import i18n from '@/lang/index';
import { AppModule } from '@/store/modules/app';
import KeeperSelect from '../../components/keeperSelect.vue';
import TreeTextarea from '../../components/treeTextarea.vue';
import FileUpload from '../../components/fileUpload.vue';
import {Cache} from '@/utils/cache';
import {processImgurl} from '@/utils/image';
const ruleHost = window.globalConfig.acHost;

@Component({
  components: {
    TreeSelect,
    PolygonDrawer,
    KeeperSelect,
    TreeTextarea,
    FileUpload
  },
})
export default class EditRuleTD extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:''}) groupId!: string;
  @Prop({default:''}) ruleId!: string;
  @Prop({default:''}) backgroundImage!: string;

  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.initData();
  };
  @Watch('form.specialAttribute')
  onSpecialAttributeChange(n,o){
    this.rules2.welcome[0].required =  n.indexOf(5)>=0?true:false;
    this.rules2.welcomebg[0].required =  n.indexOf(5)>=0?true:false;
  }
  @Watch('backgroundImage')
  onbackgroundImageChange(n,o){
    if(n){
      this.form2.welcomebg = n
    }else{
      this.form2.welcomebg = ''
    }
  }

  get language() {
    return AppModule.language;
  }
  /* data */
  $refs!:{
    treeLibs:HTMLFormElement,
    form:HTMLFormElement,
    form2:HTMLFormElement,
  };
  processImgurl:any=processImgurl;
  ruleHost:string=ruleHost;
  // accessToken:string=Cache.localGet('accessToken') || Cache.sessionGet('accessToken');
  labelWidth:string='145px';

  form:{
    ruleGroupName:string;
    ruleName:string;
    deviceName:string;
    deviceGroupName:string;
    defaultCheckedCameras:any[];
    specialAttribute:any[];
    defaultCheckedKeepers:any[];
  }={
    ruleGroupName:"",
    ruleName:'',
    deviceName:'',
    deviceGroupName:'',
    defaultCheckedCameras:[],
    specialAttribute:[],
    defaultCheckedKeepers:[]
  };
  validateRuleName=(rule, value, callback) => {
    let str = value;
    if (str === '') {
      callback(new Error(i18n.tc('form.texterrEnterRulesetName')));
    } else {
      //去除两头空格:
      let regx = /^\s+|\s+$/g;
      while (regx.test(str)) {
        str   =  trim(str);
      };
      str   =  trim(str);
      if(str){
        callback();
      }else{
        callback(new Error(i18n.tc('form.texterrEnterRulesetName')));
      }

    }
  };
  validateDefaultCheckedKeepers=(rule, value, callback) => {
    if(rule.required == false){
      callback();
    }else if( value && value.length>0){
      callback();
    }else{
      callback(new Error(i18n.t('form.texterrSelectDevice')+''));
    }
  };
  rules:any = {
    ruleName:[
      { required: true, validator: this.validateRuleName, trigger: 'blur' },
    ],
    specialAttribute:[
      { required: false },
    ],
    defaultCheckedKeepers:[
      { required: false,
        validator: this.validateDefaultCheckedKeepers,
      },
    ]
  };
  form2:any={
    threshold:defaultAcThreshold,
    welcome:[],
    welcomebg:''
  };
  rules2:any = {
    threshold:[
      { required: true, message: i18n.tc('form.texterrEnterThreshold'), trigger: 'blur' },
    ],
    welcome:[
      { required: false, message: i18n.t('form.texterrEnterWelcome')+"",trigger: 'blur' },
    ],
    welcomebg:[
      { required: false, message: i18n.t('form.texterrEnterWelcomebg')+"", trigger: 'blur'},
    ],
  };
  timeCheckListModel:any[]=[];
  libsCheckListModel:any[]=[];
  libsList:any[]=[{id:-1,label:"",children:[]},{id:0,label:"",children:[]}];
  defaultCheckedLibs:any[]=[];

  treeDataCameras:any[] = [];
  treeDataKeepers:any[] = [];
  defaultCheckedCameras:any[] = [];
  defaultCheckedKeepers:any[] = [];
  props:any=this.$props;
  thresholdOptions = ruleThresholdOptions;
  specialAttributeOptions:any[]=[];

  selectedSenseKeeperList:any[]=[];
  selectedSenseKeeperRuleIds:any[]=[];
  selectedTimesList:any[]=[];
  selectedLibsList:any[]=[];
  autoExpandedLibsList:any[]=[];

  hotZoneInput:string="";
  minFace:any={width:50,height:50};
  maxFace:any={width:100,height:100};
  hotZone:any=[];

  currentCamera:any;

  polygonsData:any[] = [];
  rectsData:any[]=[];
  drawPolygonsFinistData:any[]=[];
  drawingPolygon:boolean = false;
  drawingRect:boolean = false;

  showDrawer:boolean=false;
  currentEditType:string="";

  showVideo:boolean=false;
  keepersTimezoneLibsRelation:any[]=[];

  hideLibs:boolean = false;

  keeperDisabledLibs:any[]=[];
  //hot validate

  showLibsList:boolean=true;
  libsCheckList:any[]=[];

  showKeepersSelect:boolean=false;
  //validate hot face
  CONT_MINFACEVAL:number=30;
  CONT_MAXFACEVAL:number=300;
  minFaceVal:number=this.CONT_MINFACEVAL;
  maxFaceVal:number=this.CONT_MAXFACEVAL;
  minFaceInputError:boolean=false;
  maxFaceInputError:boolean=false;
  loading:boolean=false;
  isLoadedVideo:boolean=false;
  videoWidth:number=1920;
  videoHeight:number=1080;
  /* methods */
  initData(){
    this.$refs.form && this.$refs.form.clearValidate();
    this.libsCheckList=[];
    this.treeDataCameras= [];
    this.treeDataKeepers= [];
    this.form.defaultCheckedCameras = [];
    this.form.defaultCheckedKeepers = [];
    this.currentCamera = null;
    this.specialAttributeOptions = [];
    this.form.specialAttribute = [];
    this.form.ruleName = '';
    this.form.ruleGroupName = '';
    this.form.deviceName = '';
    this.form.deviceGroupName = '';
    this.form2.threshold = defaultAcThreshold;
    this.form2.welcome = [];

    this.selectedSenseKeeperList=[];
    this.selectedSenseKeeperRuleIds=[];
    this.selectedTimesList=[];
    this.selectedLibsList=[];

    this.showDrawer = false;
    this.hotZoneInput = this.$tc('rule.contNone');
    this.hotZone=[];
    this.polygonsData = [];

    this.drawingPolygon = false;
    this.drawingRect = false;

    this.keeperDisabledLibs = [];

    this.showLibsList = true;
    this.libsList = [{id:-1,label:this.$tc('rule.contWhitelist'),isLeaf:false,children:[]},{id:0,label:this.$tc('rule.contBlacklist'),isLeaf:false,children:[]}];

     //defaultCheckedKeepers validate
    this.rules.defaultCheckedKeepers[0]['required'] = false;

    this.minFaceVal=this.CONT_MINFACEVAL;
    this.maxFaceVal=this.CONT_MAXFACEVAL;
    this.minFaceInputError=false;
    this.maxFaceInputError=false;
    this.rectsData = [];
    this.loading=false;
    this.isLoadedVideo = false;
    this.videoWidth=1920;
    this.videoHeight=1080;

    Promise.all([getDevicesTreeData({deviceType:14}),getSpecialAttrs(1),getDevicesTreeData({deviceType:2,filter:2}),getLibsList()]).then((res)=>{
      this.formatTreeData(res[0].data,14);
      this.setSpecialAttrs(res[1]);
      this.formatTreeData(res[2].data,2);
      this.setLibsList(res[3]);
      //detail
      getRuleTDDetail(this.ruleId).then((res:any)=>{
        this.setDetailData(res);
        //welcome
        this.form2.welcome = res.welcomeRemarkList || [];
      });
    });
  }
  setDetailData(data){
    this.form.ruleGroupName = data.taskGroupVo.taskGroupName;
    this.form.ruleName = data.taskName;
    this.form.deviceName = data.deviceVo?data.deviceVo.deviceName:'';
    this.form.deviceGroupName =this.getDeviceGroupName(data);
    this.form.defaultCheckedCameras = [data.deviceVo.deviceId];
    if(!this.thresholdOptions.some((item)=>item == data.threshold)){
      this.thresholdOptions.push(data.threshold);
    }
    this.form2.threshold = data.threshold;
    //current Camera
    data.deviceVo && (this.currentCamera = {id:data.deviceVo.deviceId,name:data.deviceVo.deviceName,videoPath:data.deviceVo.videoPath});
    this.setDrawData();
    //set hotzone
    this.initHotzoneData(data);
    //minface
    this.minFaceVal = data.hotRegionVo?data.hotRegionVo.minFace.width:this.CONT_MINFACEVAL;
    //maxface
    this.maxFaceVal = data.hotRegionVo?data.hotRegionVo.maxFace.width:this.CONT_MAXFACEVAL;

    this.form.specialAttribute = this.getAttrsIds(data.taskAttributeVos);
    this.specialAttributeChange(this.form.specialAttribute);
    let defaultKeeperIds = this.formatOnlyKeepersIds(data.bindAcTasks);
    this.form.defaultCheckedKeepers = defaultKeeperIds;
    //set defaut keeper list
    this.setDefaultSelectedKeeperList(data.bindAcTasks);
    this.getRuelIdsBykeepersIds(defaultKeeperIds);

    this.defaultCheckedLibs = this.getCheckedLibsIds(data.whiteLibraries,data.blackLibraries);
    this.libsCheckList = this.getCheckedLibsIds(data.whiteLibraries,data.blackLibraries);
    this.$refs.treeLibs.setCheckedKeys(this.defaultCheckedLibs)
    // if(this.form.specialAttribute.indexOf(3) >=0){
    //   this.setAllLibsListDisadled();
    //   this.showLibsList = false;
    //   this.showKeepersSelect = true;
    //   this.rules['defaultCheckedKeepers'][0]['required'] = true;
    // }else{
    //   this.showLibsList = true;
    //   this.showKeepersSelect = false;
    //   this.rules['defaultCheckedKeepers'][0]['required'] = false;
    // }
  }
  setDefaultSelectedKeeperList(bindAcTasks){
    if(bindAcTasks && bindAcTasks.length>0){
      bindAcTasks.map(item=>{
        this.selectedSenseKeeperList.push({
          id:item.deviceVo.deviceId,
          name:item.deviceVo.deviceName
        });
      });
      let firstKeeper = this.selectedSenseKeeperList[0];
      getRuleListByKeepers([firstKeeper.id]).then((res:any)=>{
        res && (this.keepersTimezoneLibsRelation = res.list);
        this.clickKeeperItem(this.selectedSenseKeeperList[0],0);
        this.selectedTimesList.length>0 && this.selectedTimesList[0] && this.clickTimezoneItem( this.selectedTimesList[0],0);
      });

    };
  }
  getDeviceGroupName(data){
    let str:string='',obj:any=null;;
    if(data.deviceVo && data.deviceVo.deviceGroupList && data.deviceVo.deviceGroupList.length>0){
      obj = data.deviceVo.deviceGroupList[data.deviceVo.deviceGroupList.length-1];
      if(obj){str = obj.name};
    };
    return str?str:'';
  }
  initHotzoneData(data){
    this.selectedCamera([{id:data.deviceVo.deviceId,name:data.deviceVo.deviceName,videoPath:data.deviceVo.videoPath}]);
    if(data.hotRegionVo && data.hotRegionVo.hotRegionPoints.length>0){
      this.polygonsData = data.hotRegionVo?[{points:data.hotRegionVo.hotRegionPoints || []}]:[];

    }else{
      this.polygonsData = [];
    }
    if(data.hotRegionVo && data.hotRegionVo.hotRegionPoints && data.hotRegionVo.hotRegionPoints.length>0){
      this.hotZone = data.hotRegionVo.hotRegionPoints;
      this.hotZoneInput = this.$tc('rule.contDrawn')
    }else{
      this.hotZone = [];
      this.hotZoneInput = this.$tc('rule.contNone');
    }
  }
  formatOnlyKeepersIds(bindAcTasks){
    let arr:any = [];
    bindAcTasks.map((item)=>{
      arr.push(item.deviceVo.deviceId)
    });
    return arr;
  }
  getAttrsIds(list){
    let arr:any = [];
    list.map(item=>{
      arr.push(item.taskAttributeId);
    });
    return arr;
  }
  getCheckedLibsIds(whitelists,blacklists){
    let arr:any=[];
    whitelists && whitelists.map(item=>{
      arr.push(item.libraryId)
    });
    blacklists && blacklists.map(ite=>{
      arr.push(ite.libraryId)
    });
    return arr;
  }
  setSpecialAttrs(data){
    data && data.list.map(item=>{
      this.specialAttributeOptions.push({
        id:item.taskAttributeId,
        name:this.$tc(`rule.${item.taskAttributeName}`)
      })
    })
  }
  getSpecialAttrs(){
    getSpecialAttrs(1).then((res:any)=>{
      res && res.list.map(item=>{
        this.specialAttributeOptions.push({
          id:item.taskAttributeId,
          name:this.$tc(`rule.${item.taskAttributeName}`)
        })
      })
    })
  }
  formatTreeData(data,type){
    type == 14 && (this.treeDataCameras = data);
    type == 2 && (this.treeDataKeepers = data);
  }
  hide(){
    this.$emit('hideEditRuleTDDialog')
  }
  handleLibsCheck(data,check){
    this.libsCheckList=[];
    check && check.checkedKeys && check.checkedKeys.length>0 && check.checkedKeys.map(item=>{
      item>0 && this.libsCheckList.push(item);
    })

  }
  handleClose(){
    this.hide();
  }
  selectedKeeper(data){
    if(data.length>0){
      this.form.defaultCheckedKeepers = data;
      this.getRuelIdsBykeepersIds(data);
    }else{
      this.form.defaultCheckedKeepers=[];
      this.getRuelIdsBykeepersIds([]);
    }
    this.$refs.form.validateField('defaultCheckedKeepers');
  }
  KeeperSelectBlur(){
    this.$refs.form.validateField('defaultCheckedKeepers');
  }
  getOnlyKeeperIds(list){
    let arr:any = [];
    list.map((item)=>{
      arr.push(item.id)
    })
    return arr;
  }
  selectedCamera(camera){
    if(camera && camera.length>0){
      this.form.defaultCheckedCameras = this.getOnlyKeeperIds(camera);
      this.currentCamera = camera[0];
      if(this.currentCamera.videoPath){
        this.showDrawer = true;
      }
    }else{
      this.form.defaultCheckedCameras = [];
      this.currentCamera = null;
      this.showDrawer = false ;
    }

  }
  setDrawData(){
    if(this.currentCamera && this.currentCamera.videoPath){
      this.showDrawer = true;
    }else{
      this.showDrawer = false ;
    }
  }
  setKeeperListActiveEmpty(){
    this.selectedSenseKeeperList && this.selectedSenseKeeperList.map((keeper,keeperIndex)=>{
      let keeper_clone = cloneDeep(keeper);
      keeper_clone['active'] = false;
      Vue.set(this.selectedSenseKeeperList,keeperIndex,keeper_clone);
    })
  }
  setTimezoneListActiveEmpty(){
    this.selectedTimesList && this.selectedTimesList.map((timezone,timezoneIndex)=>{
      let timezone_clone = cloneDeep(timezone);
      timezone_clone['active'] = false;
      Vue.set(this.selectedTimesList,timezoneIndex,timezone_clone);
    });
  }
  clickKeeperItem(keeper,keeperIndex){
    this.setKeeperListActiveEmpty();
    let keeper_clone = cloneDeep(keeper);
    keeper_clone['active'] = true;
    Vue.set(this.selectedSenseKeeperList,keeperIndex,keeper_clone);
    //点击keeper
    this.selectedTimesList = [];
    this.selectedTimesList = this.getTimezonesFromRelations(keeper.id);
  }
  clickTimezoneItem(timezone,timezoneIndex){
    this.setTimezoneListActiveEmpty();
    let timezone_clone = cloneDeep(timezone);
    timezone_clone['active'] = true;
    Vue.set(this.selectedTimesList,timezoneIndex,timezone_clone);
    //点击timezone
    this.selectedLibsList = [];
    this.selectedLibsList = timezone.libraryVos;
  }
  getTimezonesFromRelations(keeperid){
    let currentKeeperIndex = this.keepersTimezoneLibsRelation.findIndex(item=> item.deviceVo.deviceId == keeperid);
    let currentKeeper = this.keepersTimezoneLibsRelation[currentKeeperIndex];
    let currentTimezones:any[]=[];
    if(currentKeeper){
      currentTimezones = currentKeeper.timezoneLibraryRelation;
    }
    return currentTimezones;
  }
  //libslist
  setLibsList(data){
    this.libsList = [{id:-1,label:this.$tc('rule.contWhitelist'),isLeaf:false,children:[]},{id:0,label:this.$tc('rule.contBlacklist'),isLeaf:false,children:[]}];
    data && this.formatLibs(data);
  }
  getLibsList(keywords?){
    getLibsList(keywords).then(res=>{
      this.libsList=[];
      res && this.formatLibs(res);
    })
  }
  formatLibs(res){
    this.libsList = [{id:-1,label:this.$tc('rule.contWhitelist'),isLeaf:false,children:[]},{id:0,label:this.$tc('rule.contBlacklist'),isLeaf:false,children:[]}];
    res.whitelists && res.whitelists.map((item:any)=>{
       this.libsList[0].children.push({
        id:item.libraryId,
        label:item.libraryName
      })
    });
    res.blacklists && res.blacklists.map((item:any)=>{
       this.libsList[1].children.push({
        id:item.libraryId,
        label:item.libraryName
      })
    });
  }
  drawPreviewVideo(type){
    this.currentEditType = type;
    this.editTypeChange(type);
  }
  resetDraw(type:string){
    this.drawingRect = false;
    this.drawingPolygon = false;
    if(type === 'minFace'){
      this.rectsData = [];
      // this.minFace = {width:50,height:50};
      this.minFaceVal=this.CONT_MINFACEVAL;
    };
    if(type === 'maxFace'){
      this.rectsData = [];
      // this.maxFace = {width:100,height:100};
      this.maxFaceVal=this.CONT_MAXFACEVAL;
    };
    if(type === 'hot'){
      this.polygonsData = [];
      this.hotZone = [];
      this.hotZoneInput = this.$tc('rule.contNone');
    };
  }
  drawerPolygonsFinsh(data){
    this.drawPolygonsFinistData = data;
    if(this.currentEditType == 'hot' ){
      this.hotZone = this.setZeroOfPoints(data);
      this.hotZoneInput = this.$tc('rule.contDrawn');
    }else if(this.currentEditType == 'minFace') {
      // this.minFace = this.calculationRect(data);
    }else if(this.currentEditType == 'maxFace'){
      // this.maxFace = this.calculationRect(data);
    }
  }
  setZeroOfPoints(list){
    let arr:any[]=[];
    list && list.length>0 && list.map(item =>{
      if(item.x<0){
        item.x = 0;
      }
      if(item.y<0){
        item.y = 0;
      }
      arr.push(item);
    });
    return arr;
  }
  clearHotDraw(){
    this.drawingPolygon = false;
    this.drawingRect = false;
    this.polygonsData = [];
  }
  editTypeChange(type:string){
    if(type === 'minFace'){
      this.drawingPolygon = false;
      this.drawingRect = true;
    }
    if(type === 'maxFace'){
      this.drawingPolygon = false;
      this.drawingRect = true;
    }
    if(type === 'hot'){
      this.drawingPolygon = true;
      this.drawingRect = false;
    }
  }
  calculationRect(data){
    let w:number = data.rightBottom && data.leftTop? data.rightBottom.x -data.leftTop.x : 0;
    let h:number = data.rightBottom && data.leftTop? data.rightBottom.y -data.leftTop.y : 0;
    let obj = {width:Math.round(w),height:Math.round(h),pointVos:[data.leftTop,data.rightBottom]};
    return obj;
  }
  getRuelIdsBykeepersIds(keeperIds){
    if(keeperIds && keeperIds.length == 0){
      this.keeperDisabledLibs = [];
      this.selectedSenseKeeperRuleIds = [];
      this.keepersTimezoneLibsRelation = [];
      this.selectedTimesList=[];
      this.selectedLibsList=[];
      this.selectedSenseKeeperRuleIds=[];
      //clear libs disabled
      this.clearLibsListDisadled();
      return false;
    };
    keeperIds && keeperIds.length>0 && getRuleListByKeepers(keeperIds).then((res:any)=>{
      this.selectedSenseKeeperRuleIds = [];
      res && (this.keepersTimezoneLibsRelation = res.list);
      res && (this.selectedSenseKeeperRuleIds = this.getOnlyRuleIds(res.list));
      //set libs disabled by keeperIds
      let relationLibsIds = this.getLibsIdsFromTimezoneLibsRelation(res.list);
      relationLibsIds.length>0 && this.setLibsListDisadled(relationLibsIds);
    }).catch().finally(()=>{
      if(this.form.specialAttribute.indexOf(3) >=0){
        this.setAllLibsListDisadled();
      }
    });
  }
  getLibsIdsFromTimezoneLibsRelation(timezoneLibsRelation){
    let libsArr:any[]=[];
    timezoneLibsRelation && timezoneLibsRelation.length>0 && timezoneLibsRelation.map(relation=>{
      relation.timezoneLibraryRelation && relation.timezoneLibraryRelation.length>0 && relation.timezoneLibraryRelation.map(timezoneLibrary=>{
        timezoneLibrary.libraryVos && timezoneLibrary.libraryVos.length> 0 && timezoneLibrary.libraryVos.map(library=>{
          let libraryId = library.libraryId;
          libraryId && libsArr.indexOf(libraryId) < 0 && libsArr.push(libraryId);
        })
      })
    });
    return libsArr;
  }
  clearLibsListDisadled(){
    this.libsList[0].children.map((item,itemIndex)=>{
      !this.keeperDisabledLibs.some(it=>it == item.id) && (item.disabled =  false);
    });
    this.libsList[1].children.map((item,itemIndex)=>{
      !this.keeperDisabledLibs.some(it=>it == item.id) && (item.disabled =  false);
    });
    this.$refs.treeLibs.updateKeyChildren(-1,cloneDeep(this.libsList[0].children));
    this.$refs.treeLibs.updateKeyChildren(0,cloneDeep(this.libsList[1].children));
    this.$refs.treeLibs.setCheckedKeys(this.defaultCheckedLibs);
  }
  setLibsListDisadled(libraryIds){
    //set the disabled leaf disabled no check
    this.$refs.treeLibs.setChecked(libraryIds,false);
    //set disadled
    this.libsList[0].children.map((item,itemIndex)=>{
      item.disabled = libraryIds.some(i=>i == item.id);
      item.disabled && this.keeperDisabledLibs.push(item.id);
    });
    this.libsList[1].children.map((item,itemIndex)=>{
      item.disabled = libraryIds.some(i=>i == item.id);
      item.disabled && this.keeperDisabledLibs.push(item.id);
    });
    this.$refs.treeLibs.updateKeyChildren(-1,cloneDeep(this.libsList[0].children));
    this.$refs.treeLibs.updateKeyChildren(0,cloneDeep(this.libsList[1].children));
    //set checked filter
    let checkedIds:any[]=[];
    this.defaultCheckedLibs.map(checkedlibId=>{
      libraryIds.indexOf(checkedlibId) < 0 && checkedIds.push(checkedlibId);
    });
    Vue.nextTick(()=> {
      this.$refs.treeLibs.setCheckedKeys(checkedIds);
    });
  }
  setAllLibsListDisadled(){
    let white_clone:any = [];
    this.libsList[0].children.map((item,itemIndex)=>{
      item.disabled = true;
      let item_clone = cloneDeep(item);
      white_clone.push(item);
    });
    this.$refs.treeLibs.updateKeyChildren(-1,white_clone);
    let black_clone:any = [];
    this.libsList[1].children.map((item,itemIndex)=>{
      item.disabled = true;
      let item_clone = cloneDeep(item);
      black_clone.push(item);
    });
    this.$refs.treeLibs.updateKeyChildren(0,black_clone);
  }
  getOnlyRuleIds(keepersTimezoneLibsRelation:any[]){
    let arr:any = [];
    keepersTimezoneLibsRelation.map((item)=>{
      arr.push(item.taskId)
    });
    return arr;
  }
  handleLoadedmetadata(data){
    if(data.isLoaded) this.isLoadedVideo = true;
    if(data && data.w>0 && data.h>0) this.videoWidth = data.w,this.videoHeight = data.h;
  }
  handleInputFace(val,type){
    val = parseInt(val);
    let CONT_MINFACEVAL = this.CONT_MINFACEVAL;
    let CONT_MAXFACEVAL = this.CONT_MAXFACEVAL;
    //input min face value
    if(type == 'min'){
      if(val >= CONT_MINFACEVAL && val <= CONT_MAXFACEVAL && val <= this.maxFaceVal){
        this.minFaceInputError = false;
      }else{
        this.minFaceInputError = true;
      }
    }
    //input max face value
    if(type == 'max'){
      if(val >= CONT_MINFACEVAL && val <= CONT_MAXFACEVAL && val >= this.minFaceVal){
        this.maxFaceInputError = false;
      }else{
        this.maxFaceInputError = true;
      }
    }
  }
  showFaceZoneOnVideo(val){
    val = parseInt(val);
    this.setFaceZone(val)
  }
  setFaceZone(val){
    let video_w = this.videoWidth,video_h=this.videoHeight;
    if(val){
      let leftTop = {x:video_w/2 - val/2,y:video_h/2 - val/2};
      let rightBottom = {x:video_w/2 + val/2,y:video_h/2 + val/2};
      this.rectsData = [{leftTop,rightBottom}];
    }else{
      this.rectsData = [];
    }
  }
  specialAttributeChange(v){
    if(v.indexOf(3) >= 0){
      this.setAllLibsListDisadled();
      this.rules['defaultCheckedKeepers'][0]['required'] = true;
      this.showLibsList = false;
      //keeper
      this.showKeepersSelect = true;
      this.form.defaultCheckedKeepers = [];
      this.selectedSenseKeeperList=[];
      this.getRuelIdsBykeepersIds([]);
    }else{
      this.$refs.form.clearValidate('defaultCheckedKeepers');
      this.rules['defaultCheckedKeepers'][0]['required'] = false;
      this.clearLibsListDisadled();
      // this.showLibsList = true;
      this.showLibsList = v.indexOf(5) < 0;//迎宾
      //keeper
      this.form.defaultCheckedKeepers = [];
      this.selectedSenseKeeperList=[];
      this.getRuelIdsBykeepersIds([]);
      this.showKeepersSelect = false;
    };
    if(v.indexOf(3) >= 0 && v.length>0){
      this.specialAttributeOptions.map(sa=>{
        if(sa.id != 3) sa.disabled = true;
      })
    }else if(v.length>0){
      this.specialAttributeOptions.map(sa=>{
        if(sa.id == 3) sa.disabled = true;
      })
    }
    if(v.length == 0){
      this.specialAttributeOptions.map(sa=>{
        sa.disabled = false;
      })
    }
  }
  getOnlyLeafTreeLibs(){
    let list = this.$refs.treeLibs.getCheckedKeys(true);
    let lis:any[]=[];
    list.map(item=>{
      item > 0 && lis.push(item);
    });
    return lis;
  }
  welcomeSelect(dat){
    this.form2.welcome = dat;
    this.$refs.form2.validateField('welcome');
  }
  pictureUploadError(error){
    this.$message.error(i18n.tc(error.response.data.code));
    this.$refs.form2.validateField('welcomebg');
  }
  pictureUploadSuccess(file){
    this.form2.welcomebg = file;
    this.$refs.form2.validateField('welcomebg');
  }
  getLibraryIdsFromWelcome(welcome){
    let arr:any[]=[];
    welcome && welcome.length>0 &&( arr =  welcome.map(item=>item.libraryId))
    return arr;
  }
  formatSubmitData(){
    // let host = location.hostname ,protocol = location.protocol,str=host+protocol,reg = new RegExp(str,"g");
    // console.log(this.uploadImageList[0]?this.uploadImageList[0].url.replace(reg,''):'')
    let data = {
      "taskName":this.form.ruleName,
      "acTaskIds": this.selectedSenseKeeperRuleIds,
      "hotRegionVo": {
        "hotRegionPoints": this.hotZone,
        // "maxFace":this.maxFace,
        "maxFace":{width:this.maxFaceVal,height:this.maxFaceVal},
        // "minFace":this.minFace,
        "minFace":{width:this.minFaceVal,height:this.minFaceVal},
      },
      "libraryIds": this.form.specialAttribute.indexOf(5)>=0?this.getLibraryIdsFromWelcome(this.form2.welcome):this.getOnlyLeafTreeLibs(),//迎宾人像库处理为正常人象库
      "taskAttributeIds": this.form.specialAttribute,
      "taskId": this.ruleId,
      "threshold": this.form2.threshold,
      "welcomeRemarksRequests":this.form2.welcome,
      "backgroundImage":this.form2.welcomebg
    };
    if(data.threshold>0 && data.threshold<100 && !this.thresholdOptions.some((item)=> data.threshold == item)){
      data.threshold = (data.threshold*1000)/100000 ;
    }
    return data;
  }
  ensure(){
    let data = this.formatSubmitData();
    if(data.taskName){
      //name min:1 max:40 get40
      if(trim(data.taskName).length>40){
        data.taskName = trim(data.taskName).substr(0,40);
      };
    }
    this.$refs.form.validate(validate=>{
      this.$refs.form2.validate(validate2=>{
        if(validate && validate2 && !this.maxFaceInputError && !this.minFaceInputError){
          if(this.form.specialAttribute.indexOf(3)<0 && data.libraryIds.length == 0){
            this.$message.error(this.$tc('form.texterrSelectImageLib'));
            return false;
          }
          this.loading = true;
          updateRuleTd(data).then(res=>{
            EventBus.$emit('rule-refresh-ruleslistTD');
            this.hide();
          }).finally(()=>{
            this.loading = false;
          })
        }
      })

    });
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .edit-rule-td-threshold{
    width: 120px;
  }
  .edit-rule-td-libs{
    // border-bottom: 1px solid $--border-color-form;
    padding-bottom: 20px;
    &>div{
      box-sizing:border-box;
    }
    .edit-rule-td-border-left{
      border-left: 1px solid $--border-color-form;
    }
    .edit-rule-td-libsheader{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;

    }
    .edit-rule-td-libsheader-libs{
      height: 24px;
      line-height: 24px;
      color: $--color-black;
      display: flex;
      justify-content: space-between;
    }
    .edit-rule-td-libs-scrollbox{
      width: 100%;
      max-height: 225px;
      overflow: auto;
      min-height: 50px;
      .edit-rule-td-listitem{
        padding:8px 5px;
        cursor: pointer;
      }
      .edit-rule-td-listitem:hover{
        background-color: $--color-bg-3;
      }
      .edit-rule-td-listitem-active{
        background-color: $--color-bg-3;
        position: relative;
        .edit-rule-td-icon-right{
          position: absolute;
          right: 5px;
          top: calc(50% - 8px);
        }
      }
      .edit-rule-td-listitem-text{
        display: inline-block;
        width: calc(100% - 20px);
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap
      }
    }


  }
  .edit-rule-td-other-header{
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    .edit-rule-td-other-header-label{
      line-height: 40px;
      width: 115px;
      margin-right: 10px;
      text-align: left;
    }
    .edit-rule-td-other-header-input{
      width:252px;
      .edit-rule-td-inputsnumber{
        width: 70px;
        text-align: center;
        display: inline-block;
        .el-input{
          ::v-deep input[type=number]::-webkit-inner-spin-button,
          input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
          }
        }

      }
    }
    .edit-rule-td-other-header-input-en{
      width:280px;
    }
  }
  .edit-rule-td-videodrawer{
    background-color: $--color-black;
    padding: 10px;
  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
::v-deep .el-form{
      max-width: 330px;
      margin: 0 auto;
    }
  .edit-rule-td-keepertreeinput{
    width: 100%;
  }
::v-deep .edit-rule-td-dialog-container{
    max-height: 70vh;
    min-width: 600px;
    // overflow: auto; //避免出现两个滚动条
  }
::v-deep .edit-rule-td-inputsnumber-error .el-input .el-input__inner{
    border-color: #BE0000;
  }
::v-deep .edit-rule-td-libs .el-tree>.el-tree-node>.el-tree-node__content{
    background-color: #e8ebf5;
    color: #2a5af5;
  }
::v-deep .edit-rule-td-libs .el-tree .el-tree-node .el-tree-node__content:hover{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
::v-deep .edit-rule-td-libs .el-tree .el-tree-node .el-tree-node__children .el-tree-node.is-current .el-tree-node__content{
    background-color:#e8ebf5;
    color: #2a5af5;
  }
// ::v-deep .el-form-item.is-required:not(.is-no-asterisk)>.el-form-item__label{
//     position: relative;
//     &:before {
//       position: absolute;
//       left: -8px;
//     }
//   }
  ::v-deep .el-select__tags .el-tag--info {
    color: #28354d;
  }
</style>
