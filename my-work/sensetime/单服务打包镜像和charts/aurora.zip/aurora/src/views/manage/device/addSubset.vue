<template>
  <div v-if="dialogShowVisible">
    <el-dialog class="isroll" :title="form.deviceId ? $t('devicemanagement.titleEdit') : $t('devicemanagement.buttonAddDevice')"
               :visible.sync="dialogShowVisible" width="584px">
      <el-form
        ref="dataForm"
        :rules="rulesList"
        :model="form"
        class="form-group"
        label-position="right">
        <div class="form-group-item">
          <el-form-item :label="$t('devicemanagement.contDeviceType')" :label-width="formLabelWidth"
                        prop="emptyVal"><!--设备类型-->
            <el-select size="small" class="filter-item" v-model="form.deviceType" style="width:224px" :disabled="!isAdd" @change="">
              <el-option v-for="item in deviceTypeArray" :key="item.value" :value="item.value"
                         :label="item.name"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.fpoint')" :label-width="formLabelWidth"><!--所属节点-->
            {{deviceObj.deviceName}}
          </el-form-item>
          <!--小盒子设备选择-->
          <el-form-item v-if="form.deviceType==3" prop="mData.mVersion" :label="$t('devicemanagement.version')"
                        :label-width="formLabelWidth">
            <el-select size="small" class="filter-item" v-model="form.mData.mVersion" style="width:224px">
              <el-option v-for="item in mDeviceTypeArray" :key="item.value" :value="item.value"
                         :label="item.name"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceName')" :label-width="formLabelWidth" prop="name">
            <!--名称 小盒子设备名称最大长度改为20-->
            <el-input v-model.trim="form.name" class="input-width" autocomplete="off" maxlength="20"></el-input>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceID')"
                        :label-width="formLabelWidth" prop="ID">
            <el-input size="small" v-model.trim="form.ID" class="input-width" autocomplete="off" maxlength="40"></el-input>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contDeviceGroup')" :label-width="formLabelWidth" prop="emptyVal">
            <!--分组-->
            <EditAddGroup ref="editaddgroup" size="small" :disabled="true" :selectGroupObj="selectGroupObj"
                          @selected="handleEditAddGroup"/>
          </el-form-item>

          <el-form-item :label="$t('devicemanagement.contLocation')" :label-width="formLabelWidth" prop="emptyVal">
            <!--地点-->
            <i class="iconfont icon-place"></i>
            <span class="address-class" v-if="form.point"
                  @click="addDevice">{{form.floorName + ',' + form.point}}</span>
            <span class="address-class" v-else @click="addDevice">{{$t('devicemanagement.deviceSetAddress')}}</span>
          </el-form-item>
          <!--经纬度-->
          <el-form-item :label="$t('devicemanagement.trapeze')"
                        :label-width="formLabelWidth">
            <el-input size="small" class="input-width" v-model="form.latitudeLongitude" autocomplete="off" maxlength="48"></el-input>
          </el-form-item>
          <el-form-item :label="$t('devicemanagement.contAssignedUser')" :label-width="formLabelWidth"><!--分配用户-->
            <TreeSelect size="small" :disabled="true" :data="treeData" @selected="handleSelected" show-checkbox
                        :dataObj="dataUserIdsObj"/>
          </el-form-item>
        </div>
        <div v-if="showVideo" class="rtsp-video">
          <br>
          <div class="rtsp-video-see-cancel">
            <el-button type="danger" size="mini" @click="showVideo = !showVideo">
              {{$t('devicemanagement.buttonCancel')}}
            </el-button>
          </div>
          <br>
          <div class="rtsp-video-see">
            <MediaPlayer type="1" :name="form.name" :url="form.rtspAddress"/>
          </div>
        </div>
        <hr v-if="form.deviceType==1 || form.deviceType==4||form.deviceType==3">
        <!--<br>-->
        <!--属性-->
        <!-- <el-form-item :label="$t('devicemanagement.contOtherInfo')" :label-width="formLabelWidth">
        </el-form-item> -->
        <!--类型-->
        <el-form-item v-show="form.deviceType==1" :label="$t('devicemanagement.contCameraType')"
                      :label-width="formLabelWidth">
          <el-select v-model="form.streamType" style="width: 224px">
            <el-option
              v-for="item in attributeArray"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <!--抓拍策略-->
        <el-form-item v-show="form.deviceType==1" :label="$t('devicemanagement.capturingstrategies')"
                      :label-width="formLabelWidth">
          <el-select v-model="form.captureStrategy" style="width: 224px">
            <el-option
              v-for="item in captureStrategyTypeArray"
              :key="item.value"
              :label="item.name"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>


        <el-form-item v-show="form.deviceType==1 && form.streamType=='RTSP'" label="URL"
                      :label-width="formLabelWidth"
                      prop="rtspAddress">
          <el-input size="small" v-model="form.rtspAddress" class="input-width" style="width: 224px"
                    autocomplete="off"></el-input>&nbsp;&nbsp;
        <!-- <i v-if="$permission('007118')" style="cursor: pointer" @click="showVideo=!showVide"
          class="iconfont icon-view"></i> -->
        </el-form-item>
       <!-- <el-form-item class="form-item-text" v-show="form.deviceType==1 && form.streamType=='RTSP'"
                     :label="$t('devicemanagement.contEncodeType')"
                     :label-width="formLabelWidth">&lt;!&ndash;编码类型&ndash;&gt;
         <el-radio v-for="item in codeTypeArray" v-model="form.codeType" :label="item.value" :key="item.value">
           {{item.name}}
         </el-radio>
       </el-form-item> -->
<!--        <el-form-item class="form-item-text" v-show="form.deviceType==1 && form.streamType=='RTSP'"-->
<!--                      :label="$t('devicemanagement.contProtocol')"-->
<!--                      :label-width="formLabelWidth">&lt;!&ndash;传输协议&ndash;&gt;-->
<!--          <el-radio v-for="item in transportProtocolArray" v-model="form.protocolType" :label="item" :key="item">-->
<!--            {{item}}-->
<!--          </el-radio>-->
<!--        </el-form-item>-->
        <!--抓拍机类型-->
        <!--厂商-->
        <el-form-item v-if="form.deviceType==4"  :label="$t('devicemanagement.manufacturer')"
          prop="manufacturer" :label-width="formLabelWidth">
          {{form.manufacturer}}
          <el-select size="small" class="filter-item" v-model="form.manufacturer" style="width:224px">
            <el-option v-for="item in manufacturerArray" :key="item.value" :value="item.value" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
<!--        非人脸过滤-->
        <el-form-item v-show="form.deviceType==4 && isNebulaVersion"  :label="$t('devicemanagement.noFace')"
          prop="filterNoface" :label-width="formLabelWidth">
          <el-select size="small" class="filter-item" v-model="form.filterNoface" style="width:224px">
            <el-option v-for="item in noFaceArray" :key="item.value" :value="item.value" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item v-show="form.deviceType==1 && (form.streamType=='ONVIF' ||form.streamType=='GB28181')||form.deviceType==4 ||form.deviceType==3"
        :label="form.streamType=='GB28181' &&form.deviceType==1 ? 'SIP服务器IP' :$t('devicemanagement.contIP')"
                      prop="ip"
                      :label-width="formLabelWidth">
          <el-input class="input-width" size="small" v-model="form.ip" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item v-show="form.deviceType==1 && (form.streamType=='ONVIF' ||form.streamType=='GB28181')||form.deviceType==4 ||form.deviceType==3"
                    :label="form.streamType=='GB28181'&&form.deviceType==1 ? 'SIP服务器端口' :$t('devicemanagement.contPort') "
                      prop="port"
                      :label-width="formLabelWidth">
          <el-input
            @input="inputPortNum"
            v-model="form.port" autocomplete="off" size="small" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-show="(form.deviceType==1 && form.streamType=='ONVIF')||form.deviceType==4||form.deviceType==3" :label="$t('devicemanagement.contUsername')"
                      prop="username"
                      :label-width="formLabelWidth">
          <el-input v-model.trim="form.username" autocomplete="off" maxlength="40" class="input-width"></el-input>
        </el-form-item>
        <el-form-item v-if="form.deviceType==1 && form.streamType=='ONVIF'||form.deviceType==4||form.deviceType==3" :label="$t('devicemanagement.contPassword')"
                      prop="password"
                      :label-width="formLabelWidth">
          <el-input v-model.trim="form.password" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>

        <!-- SIP -->
        <!-- <el-form-item v-if="form.deviceType==1 && form.streamType=='GB28181'"
          label="SIP服务器IP" prop="ip" :label-width="formLabelWidth">
          <el-input v-model="form.ip" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item> -->

        <!-- <el-form-item v-if="form.deviceType==1 && form.streamType=='GB28181'"
          label="SIP服务器端口" prop="port" :label-width="formLabelWidth">
          <el-input v-model="form.port" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item> -->

        <el-form-item v-show="form.deviceType==1 && form.streamType=='GB28181'"
          label="SIP服务器ID" prop="serverSipId" :label-width="formLabelWidth">
          <el-input v-model.trim="form.serverSipId" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>

        <el-form-item v-show="form.deviceType==1 && form.streamType=='GB28181'"
          label="SIP相机ID" prop="cameraSipId" :label-width="formLabelWidth">
          <el-input v-model.trim="form.cameraSipId" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>

        <el-form-item :label="$t('rule.labelImageLibraryList')" :label-width="formLabelWidth">
          <!--          人像库-->
          <PortraitSelect :data="propTreeData" @selected="handleSelectedP" show-checkbox
                          :dataObj="dataLibraryIdsObj"/>
        </el-form-item>

<!--        阈值-->
        <el-form-item v-if="dataLibraryIdsObj.libraryIds.length > 0" :label="$t('rule.contThreshold')"
                      prop="threshold"
                      :label-width="formLabelWidth">
          <el-select
            class="add-rule-td-multiple-threshold"
            v-model="form.threshold"
            filterable
            allow-create
            default-first-option
            :placeholder="$t('form.texterrEnterThreshold')">
            <el-option
              v-for="(item,itemIndex) in thresholdOptions"
              :key="itemIndex"
              :label="Number(item)"
              :value="item">
            </el-option>
          </el-select> %
        </el-form-item>

        <!-- 鉴权 -->
        <el-form-item v-show="form.deviceType==1 && form.streamType=='GB28181'"
          label="鉴权"  :label-width="formLabelWidth">
          <el-switch
            v-model="isAuthentication"
            active-color="#13ce66"
            inactive-color="#ff4949"
            @change="()=>{ form.password = ''}" >
          </el-switch>
        </el-form-item>

        <el-form-item v-if="form.deviceType==1 && form.streamType=='GB28181' && isAuthentication"
          label="密码" prop="password" :label-width="formLabelWidth">
          <el-input v-model="form.password" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item>

        <!-- <el-form-item v-if="form.deviceType==1 && form.streamType=='ONVIF'||form.deviceType==4||form.deviceType==3 || form.streamType=='GB28181' && isAuthentication" :label="$t('devicemanagement.contPassword')"
                      prop="password"
                      :label-width="formLabelWidth">
          <el-input v-model.trim="form.password" autocomplete="off" maxlength="20" class="input-width"></el-input>
        </el-form-item> -->


<!--        <div v-if="form.noSenseSwitch == '1'">-->
<!--          <el-form-item v-if="form.deviceType==1 || form.deviceType==4" :label="$t('devicemanagement.noSenseIp')" prop="noSenseIp" :label-width="formLabelWidth">-->
<!--            <el-input size="small" v-model="form.noSenseIp" autocomplete="off" :placeholder="$t('devicemanagement.noSenseIpTips')"></el-input>-->
<!--          </el-form-item>-->
<!--          <el-form-item v-if="form.deviceType==1 || form.deviceType==4" :label="$t('devicemanagement.noSensePort')" prop="noSensePort" :label-width="formLabelWidth">-->
<!--            <el-input @input="inputNoSensePortNum" size="small" v-model="form.noSensePort" autocomplete="off"></el-input>-->
<!--          </el-form-item>-->
<!--        </div>-->

      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleEditDevice" :loading="btnLoading">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>

    <!-- 设备添加地图点位 -->
    <el-dialog :title="$t('devicemanagement.titleDeviceLocation')" width="80%"
               :visible.sync="isMapDevice"
               v-if="isMapDevice"
               class="dialog-track">
      <el-form :model="form" style="width:100%;min-height:530px">
        <map-device
          :handleType="form.deviceId == '' ? 'add' : 'edit'"
          :deviceInfo="deviceInfo"
          :key="deviceInfo.length != 0 ? deviceInfo[0].id : ''"
          @deviceVal="getDevicePlace"
        />
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="mapDeviceConfirm" type="primary">{{$t('devicemanagement.buttonOK')}}</el-button>
        <el-button @click="mapDeviceCancle" type="info">{{$t('devicemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import EditAddGroup from "@/components/deviceUserAdd/editAddGroup.vue";
  import TreeSelect from "@/components/deviceUserAdd/index.vue";
  import {DeviceModule} from '@/store/modules/device';
  import {isEmpty} from '@/utils/validate';
  import MediaPlayer from '@/components/media-player/index.vue';
  import {UserModule} from '@/store/modules/user';
  import MapDevice from '../map/map-device.vue';
  import {AppModule} from '@/store/modules/app';
  import {subsetDeviceType as deviceTypeList }  from '@/utils/constants';
  import {mDeviceType as mDeviceTypeList }  from '@/utils/constants';
  import {captureStrategyType as captureStrategyTypeList }  from '@/utils/constants';
  import {noFaceType as noFaceTypeList }  from '@/utils/constants';
  import historyApi from "@/api/history-record";
  import ChooseTree from "@/views/manage/device/components/choose-tree.vue";
  import PortraitSelect from "@/views/manage/device/components/tree-select.vue";
  import {PortraitModule} from "@/store/modules/portrait";
  import {deviceThresholdOptions} from '@/utils/constants';

  let vm = null as any

  const requireDeviceName = (rule, value = '', callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateDeviceName')))
    } else {
      callback()
    }
  }

  const requiredTip = (rule, value = '', callback) => {
    if (value === ''||value === null) {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    } else {
      callback()
    }
  }

  const requiredUsername = (rule, value = '', callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateDeviceUserName')))
    } else {
      callback()
    }
  }

  const requiredVideoPath = (rule, value = '', callback) => {
    /*else if (value.substring(0, 7) != 'rtsp://') {
        callback(new Error("请以rtsp://开头输入"))
      }*/
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    } else {
      callback()
    }
  }

  const requiredIP = (rule, value = '', callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    }
    let flag = false;
    let re = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/ as any;
    if (re.test(value)) {
      if ((RegExp.$1 as any) < 256 && (RegExp.$2 as any) < 256 && (RegExp.$3 as any) < 256 && (RegExp.$4 as any) < 256)
        flag = true;
    }
    if (!flag) {
      callback(new Error(vm.$t('devicemanagement.deviceIpValid')))
    } else {
      callback()
    }
  }

  const requiredPort = (rule, value, callback) => {
    if (value === '') {
      callback(new Error(vm.$t('devicemanagement.validateNotNull')))
    }
    if (value <= 0 || value > 65535) {
      callback(new Error(vm.$t('devicemanagement.devicePortValid')))
    } else {
      callback()
    }
  }
  const requiredchooseDevice = (rule, value, callback) => {
    if (value === ''||value == null) {
      callback(new Error(vm.$t('devicemanagement.chooseDevice')))
    } else {
      callback()
    }
  }


  @Component({
    components: {
      ChooseTree,
      TreeSelect,
      MediaPlayer,
      MapDevice,
      EditAddGroup,
      PortraitSelect
    },
    props: {
      dialogVisible: {
        type: Boolean,
        required: true,
        default: false
      },
    },

    computed: {
      rulesList: function () {

        let that = this as any;
        if (that.form.deviceType == 1 && that.form.streamType == 'RTSP') {
          return that.rules1
        } else if (that.form.deviceType == 1 && that.form.streamType == 'ONVIF') {
          return that.rules2
        }else if (that.form.deviceType == 4) {

          return that.rules4
        }else if(that.form.deviceType == 1 && that.form.streamType == 'GB28181'){
          return that.rules3
        }
      },
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '170px' : '100px';
      },
      codeTypeArray: function () {
        let that = this as any;
        return [{
          name: that.$t('devicemanagement.contDirectConnection'),
          value: 1
        }, {name: that.$t('devicemanagement.contTranscode'), value: 2}]
      }
    },
  })
  export default class AddSubset extends Vue {
    get language() {
      return AppModule.language;
    }

    btnLoading = false;
    isMapDevice = false;
    deviceInfo = [] as any;
    defaultDevice = [] as any;
    // requiredIP:any=requiredIP;

    rules1 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      rtspAddress: [{required: true, trigger: 'blur', validator: requiredVideoPath}],
      emptyVal: [{required: true, trigger: 'blur'}],
      noSenseIp: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSensePort:[{required: true, trigger: 'blur', validator: requiredPort}],
      threshold:[{required: true, trigger: 'change', validator: requiredTip}],
    };
    rules2 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      ip: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSenseIp: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSensePort:[{required: true, trigger: 'blur', validator: requiredPort}],
      port: [{required: true, trigger: 'blur', validator: requiredPort}],
      username: [{required: true, trigger: 'blur', validator: requiredUsername}],
      password: [{required: true, trigger: 'blur', validator: requiredTip}],
      emptyVal: [{required: true, trigger: 'blur'}],
      threshold:[{required: true, trigger: 'change', validator: requiredTip}],
    };
    //emptyVal,mVersion,name,ID,emptyVal,
    //'ip','noSenseIp','noSensePort','port','username','password','threshold'
    rules3 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      ip: [{required: true, trigger: 'blur', validator: requiredIP}],
      serverSipId: [{required: true, trigger: 'blur', validator: requiredTip}],
      cameraSipId:[{required: true, trigger: 'blur', validator: requiredTip}],
      cameraPwd: [{required: true, trigger: 'blur', validator: requiredTip}],
      password: [{required: true, trigger: 'blur', validator: requiredTip}],
      port: [{required: true, trigger: 'blur', validator: requiredPort}],
      // username: [{required: true, trigger: 'blur', validator: requiredUsername}],
      emptyVal: [{required: true, trigger: 'blur'}],
      threshold:[{required: true, trigger: 'change', validator: requiredTip}],
    };
    rules4 = {
      name: [{required: true, trigger: 'blur', validator: requireDeviceName}],
      ID: [{required: true, trigger: 'blur', validator: requiredTip}],
      ip: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSenseIp: [{required: true, trigger: 'blur', validator: requiredIP}],
      noSensePort:[{required: true, trigger: 'blur', validator: requiredPort}],
      port: [{required: true, trigger: 'blur', validator: requiredPort}],
      username: [{required: true, trigger: 'blur', validator: requiredUsername}],
      password: [{required: true, trigger: 'blur', validator: requiredTip}],
      emptyVal: [{required: true, trigger: 'blur'}],
      threshold:[{required: true, trigger: 'change', validator: requiredTip}],
    };



    deviceTypeArray:any[] = deviceTypeList;
    mDeviceTypeArray:any[] = mDeviceTypeList;
    captureStrategyTypeArray:any[] = captureStrategyTypeList;
    noFaceArray:any[] = noFaceTypeList;
    // attributeArray = ['RTSP', 'ONVIF'];
    attributeArray = [{
      value: 'RTSP',
      label: 'RTSP'
    }, {
      value: 'ONVIF',
      label: 'ONVIF'
    }, {
      value: 'GB28181',
      label: 'GB28181'
    }];
    transportProtocolArray = ['TCP', 'UDP'];
    dialogShowVisible = false;
    showVideo = false as any;
    treeData = [];
    dataUserIdsObj = {
      userIds: [],
      defaultIds: []
    } as any;
    dataLibraryIdsObj = {
      libraryIds: [],
      defaultIds: []
    } as any;
    tempAddressLocal={
      floorId:'',
      point:[],
      floorName:''
    }as any
    // 厂商信息
    manufacturerArray = []
    manufacturerNum = ''//修复初始化表单项为0的bug

    isNebulaVersion = false;


    watchList:any=[];//黑白名单人像库
    labraryIdsList:any = [];
    thresholdOptions = deviceThresholdOptions;

    // 鉴权
    isAuthentication:boolean= false

    created() {
      vm = this as any;
    }

    @Prop(Object) dataObj!: any[];
    @Prop(Object) deviceObj!: any;
    @Prop({ default: '' }) handleType!: any;//操作类型
    //编辑的表单里的值
    form = {
      devicePlace: "",
      deviceId: "",
      deviceType: 1,//设备类型
      name: "",//名称
      ID: "",//ID
      groupId: '',//分组id
      groupName: '',
      point: "",//点位
      streamType: 'RTSP',//类型
      codeType: 1,//编码类型
      protocolType: "TCP",//传输协议 TCP/UDP
      rtspAddress: "",//rtsp视频地址
      port: "",
      username: "",
      password: "",
      ip: "",
      userIds: [],
      floorId: '',
      floorName: '',
      emptyVal: '123',
      manufacturer:'',//厂商

      noSenseIp:'',
      noSensePort:'',
      noSenseSwitch:0,

      // 防疫版
      mData:{
        mVersion:1,
      } as any,

      //小盒子二期新增
      threshold:85, //阈值
      filterNoface:0,//非人脸过滤
      captureStrategy: 2,//抓拍策略
      latitudeLongitude:'',//经纬度
      libraryIds: [],//人像库

      // SIP
      serverSipId:'',
      cameraSipId:'',
      // cameraPwd:''

    } as any;
    selectGroupObj = {} as any;
    isAdd = true
    @Watch('handleType')
    onhandleTypeChange(val: any) {
      if(val =="add"){
        this.isAdd = true
      }
      if(val =="edit"){
        this.isAdd = false
      }
    }

    propTreeData = [
      {
        id: 'root',
        libraryName: '白名单',
        children: []
      },
      {
        id: 'root',
        libraryName: '黑名单',
        children: []
      }];

    handleSelected(obj) {
      this.form.userIds = obj.userIds;
      this.dataUserIdsObj = obj;
    }

    handleSelectedP(obj) {
      this.form.libraryIds = obj.libraryIds;
      this.dataLibraryIdsObj = obj;
    }



    //输入验证
    inputPortNum(val){
      if(this.verifySize(val)){
        this.form.port = val
      }else{
        this.form.port = '';
      }

    }
    inputNoSensePortNum(val){
      if(this.verifySize(val)){
        this.form.noSensePort = val
      }else{
        this.form.noSensePort = '';
      }
    }
    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([1-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        return true;
      }else{
        return false;
      }
    }

    mounted() {
      // this.searchOrgUserTree();
      // this.initGroupTree();
      this.isAuthentication = !!this.form.password
      // this.getFirmsData();
    }

    //初始化设备树
    initGroupTree() {
      let that = this as any;
      DeviceModule.GetGroupList({keyword: ""}).then((data: any) => {
        that.selectGroupObj.treeData = data.data;
      }).catch((err) => {
        console.log(err)
      });
    }


    //初始化厂商信息
    getFirmsData(isMVendor){
      let that = this as any;
      //M厂商
      DeviceModule.queryFirms({isMVendor}).then((data: any) => {
        console.log(data)
        let arr = [] as any;
        for(let i = 0;i < data.length;i++){
          let o = {} as any;
          o.name = data[i].firmName;
          o.value = data[i].id;
          arr.push(o)
        }
        that.manufacturerArray = arr;


        if (!isEmpty((this.dataObj as any).deviceId)){
         that.form.manufacturer =  that.form.manufacturer ? that.form.manufacturer :arr[0].value;
         console.log(that.form.manufacturer)
        }else {
          that.form.manufacturer = arr[0].value;
        }
        that.manufacturerNum = arr[0].value;
        that.form.manufacturer = arr[0].value;

      }).catch((err) => {
        console.log(err)
      }).then(()=>{
        console.log('初始化厂商信息',that.form.manufacturer)
        setTimeout(()=>{
          console.log('初始化厂商信息2',this.manufacturerNum)
        },2000)
      });
    }

    //选取人像库
    checkoutWatchList(ids){
      this.labraryIdsList=ids
      console.log(ids)
    }

    //获取黑白名单人像库
    fetchWatchList(state){
      //state为true 展开，false 收缩
      if(this.watchList.length==0){
        historyApi.fetchLibrary().then((data)=>{
          let obj1={
            libraryName:this.$t("rule.contWhitelist"),
            libraryId:"g_1",
            children:(data as any).whitelists
          };
          let obj2={
            libraryName:this.$t("rule.contBlacklist"),
            libraryId:"g_2",
            children:(data as any).blacklists
          };
          this.$set(this.watchList,0,obj1)
          this.$set(this.watchList,1,obj2)
        })
      }
    }

    addDevice(e) {
      if (e) {
        this.isMapDevice = true;
      } else {
        this.isMapDevice = false;
      }
    }

    getDevicePlace(deviceInfo) {
      if(deviceInfo.coords.length > 0){
        this.tempAddressLocal.floorId = deviceInfo.floorId;
        this.tempAddressLocal.point = JSON.stringify(deviceInfo.coords);
        this.tempAddressLocal.floorName = deviceInfo.pathName
      }else{
        this.tempAddressLocal.point = '';
      }
    }

    mapDeviceConfirm() {
      this.form.floorId = this.tempAddressLocal.floorId
      this.form.point = this.tempAddressLocal.point
      this.form.floorName = this.tempAddressLocal.floorName
      this.isMapDevice = false;
      console.log(this.form)
    }

    mapDeviceCancle() {
      this.isMapDevice = false;
    }

    handleEditDevice() {
      let that = this as any;
      (that.$refs['dataForm'] as any).validate((valid) => {
        if (valid) {
          that.handleEditDeviceV();
        }
      })
    }

    handleEditDeviceV() {
      let that = this as any;
      console.log('handleEditDeviceV');
      (that.$refs['dataForm'] as any).validate((valid) => {
        if (valid) {
          if (isEmpty(that.form.floorId) || isEmpty(that.form.point)) {
            that.$message.error(that.$t('devicemanagement.chooseAddress'))
            return
          }
          that.btnLoading = true;
          let params = {} as any;
          params.subordinateToNodeId = that.deviceObj.deviceId;
          params.deviceType = that.form.deviceType;
          params.name = that.form.name;
          params.groupId = that.form.groupId;
          params.point = that.form.point;
          // params.userIds = that.form.userIds;
          params.floorId = that.form.floorId;
          params.ID = that.form.ID;
          params.libraryIds = that.form.libraryIds;//人像库
          params.latitudeLongitude = that.form.latitudeLongitude;//经纬度
          params.captureStrategy = that.form.captureStrategy;//抓拍策略
          if (params.libraryIds.length > 0){
            params.threshold = that.form.threshold;
          }
          //分配用户暂时没有
          if (that.form.deviceType == 1 && that.form.streamType == 'RTSP') {
            //camera Rtsp
            params.streamType   = that.form.streamType;
            // params.codeType     = that.form.codeType;//子设备不传
            // params.protocolType = that.form.protocolType;//子设备不传
            // params.captureStrategy = that.form.captureStrategy;//抓拍策略
            params.rtspAddress  = that.form.rtspAddress;//rtsp地址

            //无感门禁
            // params.noSenseSwitch = Number(that.form.isContactDoorGuard);
            if (Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch) === 1){
              params.noSenseSwitch = Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch);
              // params.noSenseIp     = that.form.doorGuardIp;
              // params.noSensePort   = that.form.doorGuardPort;
              params.noSenseIp     = that.form.noSenseIp;
              params.noSensePort   = that.form.noSensePort;
            }
          } else if (that.form.deviceType == 1 && that.form.streamType == 'ONVIF') {
            //camera ONVIF
            params.streamType = that.form.streamType;
            params.ip         = that.form.ip;
            params.port       = that.form.port;
            params.username   = that.form.username;
            params.password   = that.form.password;
            // params.captureStrategy   = that.form.captureStrategy;//抓拍策略

            //无感门禁
            if (Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch) === 1){
              params.noSenseSwitch = Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch);
              // params.noSenseIp     = that.form.doorGuardIp;
              // params.noSensePort   = that.form.doorGuardPort;
              params.noSenseIp     = that.form.noSenseIp;
              params.noSensePort   = that.form.noSensePort;
            }
          } else if (that.form.deviceType == 1 && that.form.streamType == 'GB28181'){
            params.streamType = that.form.streamType;
            params.ip         = that.form.ip;
            params.port       = that.form.port;
            params.serverSipId = this.form.serverSipId;
            params.cameraSipId = this.form.cameraSipId;
            // this.isAuthentication ? params.cameraPwd = this.form.cameraPwd : null;
            params.password = this.isAuthentication? this.form.password  :'';
          } else if (that.form.deviceType == 2) {
            //SenseKeeper

          } else if (that.form.deviceType == 3) {
            //SenseNebula-M
            params.ip         = that.form.ip;
            params.port       = that.form.port;
            params.username   = that.form.username;
            params.password   = that.form.password;
            params.nebulaVersion   = that.form.mData.mVersion;//新增小盒子设备

          } else if (that.form.deviceType == 4){
            //SenseDLC
            params.firmId = that.form.manufacturer;
            console.log("这里？firmId",that.form.manufacturer)
            params.ip = that.form.ip;
            params.port = that.form.port;
            params.username = that.form.username;
            params.password = that.form.password;
            params.filterNoface = that.form.filterNoface;//非人脸
            delete params.captureStrategy ;

            //无感门禁
            if (Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch) === 1){
              params.noSenseSwitch = Number(that.form.noSenseSwitch === undefined ?false:that.form.noSenseSwitch);
              // params.noSenseIp     = that.form.doorGuardIp;
              // params.noSensePort   = that.form.doorGuardPort;
              params.noSenseIp     = that.form.noSenseIp;
              params.noSensePort   = that.form.noSensePort;
            }
          }
          //新增
          if (isEmpty(that.form.deviceId)) {
            console.log("新增",params)
            DeviceModule.AddDevice(params).then((data: any) => {
              that.$emit("resetDeviceList");
              that.$message({
                // message: 'success',
                message: that.$t('devicemanagement.deviceAddSuccess'),
                type: 'success'
              });
              this.dialogShowVisible = false;
            }).catch((err) => {
              console.log(err)
            }).finally(()=>{
              that.btnLoading = false;
            });
          } else {
            //编辑
            console.log("开始编辑",that.form)
            DeviceModule.UpdateDevice({params: params, id: that.form.deviceId}).then((data: any) => {
              that.$emit("resetDeviceList");
              // that.$message({
              //   message: 'success',
              //   type: 'success'
              // });
              this.dialogShowVisible = false;
            }).catch((err) => {
              console.log(err)
            }).finally(()=>{
              that.btnLoading = false;
            })
          }
        }
      })
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      if (val) {
        this.searchOrgUserTree();
        this.initGroupTree();
        // this.getFirmsData();
      }
      if (!val){
        this.defaultDevice = [];
      }
      let data = this.dataObj as any;
      console.log("这个data",data)

      if (!isEmpty(data.deviceId)) {
        // console.log("拿到父级数据",this.dataObj ,data.deviceId ,!isEmpty(data.deviceId))
        this.selectGroupObj.checked = data.groupId + ',' + data.groupName;
        this.selectGroupObj.checkedLabel = data.groupName;
        if (this.$refs.editaddgroup) {
          (this.$refs.editaddgroup as any).checkedLabelV = data.groupName;
        }
        this.dataUserIdsObj = {
          userIds: data.userIds,
          defaultIds: data.userIds
        }
        this.dataLibraryIdsObj = {
          libraryIds: data.libraryVos?data.libraryVos:[],
          defaultIds: data.libraryVos?data.libraryVos:[]
        }
        console.log('第一2步');
        this.deviceInfo = [{
          deviceCode: data.deviceCode,
          deviceId: data.deviceId,
          floorId: data.floorId,
          floorName: data.floorName
        }]
        this.form.deviceId = data.deviceId
        this.form.deviceType = data.deviceType
        this.form.name = data.deviceName
        this.form.ID = data.deviceCode || ''
        this.form.groupId = data.groupId
        this.form.groupName = data.groupName
        this.form.streamType = data.streamType || 'RTSP'
        this.form.rtspAddress = data.rtspAddress || ''
        this.form.codeType = data.codeType || 1
        this.form.protocolType = data.protocolType || 'TCP'
        this.form.port = data.port || ''
        this.form.username = data.username || ''
        this.form.password = data.password || ''
        this.form.ip = data.ip || ''
        this.form.point = data.point
        this.form.floorId = data.floorId
        this.form.floorName = data.floorName
        //新增
        this.form.manufacturer = data.firmId
        console.log("这里？",this.form.manufacturer)

        //无感门禁
        console.log("无感1",data)
        this.form.noSenseIp = data.noSenseIp
        this.form.noSensePort = data.noSensePort
        this.form.noSenseSwitch = data.noSenseSwitch+'';
        console.log(this.form.noSenseSwitch)

        //防疫版
        if(data.deviceType == 3){
          this.form.mData.mVersion = data.nebulaVersion;
        }

        //小盒子二期新增
        this.form.latitudeLongitude=data.latitudeLongitude//经纬度
        this.form.libraryIds=data.libraryVos//人像库
        this.form.threshold=data.threshold?data.threshold:85, //阈值
        this.form.captureStrategy=data.captureStrategy//抓拍策略
        this.form.filterNoface=data.filterNoface//非人脸过滤
        this.form.serverSipId = data.serverSipId
        this.form.cameraSipId = data.cameraSipId
        this.isNebulaVersion =  data.nebulaVersion == 2;
        // console.log(data.nebulaVersion , '-----------');
        this.getFirmsData(this.isNebulaVersion?2:1)
      } else {
        this.selectGroupObj.checked = data.localClickGroup.id + ',' + data.localClickGroup.name;
        this.selectGroupObj.checkedLabel = data.localClickGroup.name;
        if (this.$refs.editaddgroup) {
          (this.$refs.editaddgroup as any).checkedLabelV = data.localClickGroup.name;
        }
        this.deviceInfo = []

        this.form = {
          devicePlace: "",
          deviceId: "",
          deviceType: 1,//设备类型
          name: "",//名称
          ID: "",//ID
          groupId: data.localClickGroup.id,//分组id
          groupName: data.localClickGroup.name,
          point: "",//点位
          streamType: 'RTSP',//类型
          codeType: 1,//编码类型
          protocolType: "TCP",//传输协议 TCP/UDP
          rtspAddress: "",//rtsp视频地址
          port: "",
          username: "",
          password: "",
          ip: "",
          userIds: [],
          floorId: '',
          emptyVal: '123',
          manufacturer:this.manufacturerNum,

          //无感门禁
          noSenseIp:'',
          noSensePort:'',
          noSenseSwitch:'0',

          // 防疫版
          mData:{
            mVersion:1,
          } as any,

          //小盒子二期新增
          threshold:85, //阈值
          filterNoface:0,//非人脸过滤
          captureStrategy: 2,//抓拍策略
          latitudeLongitude:'',//经纬度
          libraryIds: [],//人像库
          serverSipId:'',
          cameraSipId:'',

        };
        console.log('manufacturerNum====',this.form)//18
        // this.dataUserIdsObj = {
        //   userIds: [],
        //   defaultIds: [] //rrrr
        // }
        DeviceModule.GetDeviceDetail(this.deviceObj.deviceId).then((data: any) => {
          console.log(data);
          this.isNebulaVersion =  data.nebulaVersion == 2;
          this.dataUserIdsObj = {
            userIds: data.userIds,
            defaultIds: data.userIds
          }
          // console.log('第2步' , this.isNebulaVersion , data.nebulaVersion);
          this.getFirmsData(this.isNebulaVersion?2:1)
        }).catch((err) => {
          console.log(err)
        });
        this.dataLibraryIdsObj = {
          libraryIds: [],
          defaultIds: []
        }

      }
      console.log("...." ,this.isNebulaVersion);

      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.showVideo = false
        this.$emit("closeEdit")
      }
      this.isAuthentication = !!this.form.password
    }

    //获取用户数
    searchOrgUserTree() {
      let that = this as any;
      UserModule.GetOrgUserTree().then((data: any) => {
        let arr = data.data;
        console.log(arr)
        this.filterData(arr);
        // that.treeData = data.data;
        that.treeData = arr;
      }).catch((err) => {
        console.log(err)
      });

      DeviceModule.getLibrarys(that.deviceObj.deviceId).then((data: any)=>{
        console.log(data,'人像库列表');
        this.propTreeData[0].children = data.whitelists;
        this.propTreeData[0].libraryName = that.$t('imagemanagement.contWhiltelist');
        this.propTreeData[1].children = data.blacklists;
        this.propTreeData[1].libraryName = that.$t('imagemanagement.contBlacklist');


      })
    }
    // 筛选
    filterData(arr){
      for (let i = 0;i < arr.length;i++){
        if (arr[i].adminRole&&arr[i].adminRole == 1){//是管理员
          // arr.splice(i,1);
          // i-=1;
          this.defaultDevice.push(arr[i].id)
          arr[i].disabled = true;
        }
        if (arr[i].type == 0&&arr[i].children.length>0){
          this.filterData(arr[i].children);
        }
      }
      console.log('第一步');
    }

    handleEditAddGroup(id, name) {
      this.selectGroupObj.checked = id + ',' + name;
      this.selectGroupObj.checkedLabel = name;
      this.form.groupId = id;
      this.form.groupName = name;
    }

    handleNoSenseSwitch(value){
      console.log(value =="0")
      if(value =="0"){
        this.form.noSenseIp ='';
        this.form.noSensePort='';
        this.form.noSenseSwitch='0';
      }
    }

    @Watch('form.deviceType')
    onFormDeviceTypeChange() {
      let that = this as any;
      // this.form.streamType = 'RTSP'

      setTimeout(function () {
        if(that.$refs['dataForm']){
          that.$refs['dataForm'].resetFields();
          that.form.manufacturer = ''//manufacturer 变为了0,重新置空
        }

      }, 100)
    }
    @Watch('form.streamType')
    onFormstreamTypeChange() {
      let that = this as any;
      // this.$nextTick(()=>{
        that.$refs['dataForm'].clearValidate();

      // })

    }
  }

</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .dialog-track{
    .device-wrapper{
      min-height: 530px;
      .device-view{
        min-height: 530px;
      }
    }
  }
  .el-input {
    width: 224px
  }
  .form-item-text{margin-bottom: 4px;}
  .form-group{
    hr{
      margin-left: -10%;
      margin-right: -10%;
    }
  }

  .icon-place {
    font-size: 22px;
    vertical-align: sub;
    color: #c4cce6
  }

  .address-class {
    cursor: pointer;
    width: 224px;
    height: 14px;
    font-family: Hiragino Sans GB;
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #2a5af5;
    border-bottom: 1px solid #2a5af5;
  }

  ::v-deep .el-dialog__footer {
    text-align: center;
  }

  ::v-deep .el-input__inner {
    height: 32px !important;
  }
  ::v-deep .input-width > input {
    width: 224px
  }

  .rtsp-video {
    position: absolute;
    left: 0px;
    top: 0px;
    z-index: 1;
  }

  .rtsp-video-see-cancel {
    text-align: right;
    position: relative;
    top: 44px;
    z-index: 10;
  }

  .rtsp-video-see {
    width: 570px;
    margin-left: 7px
  }
</style>
