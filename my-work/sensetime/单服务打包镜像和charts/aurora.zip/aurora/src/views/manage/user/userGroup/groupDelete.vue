<template>
  <div>
    <!--删除弹框-->
    <el-dialog
      :title="$t('usermanagement.listDelete')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <div class="content">
        <!--分组删除后，将不能恢复！-->
        {{$t('usermanagement.popmsgGroupDelete')}}
      </div>
      <!--<div v-else class="content">-->
        <!--分组下有用户，不能删除！-->
      <!--</div>-->
      <span slot="footer" class="dialog-footer">
        <!--删 除-->
        <el-button v-if="true" type="danger" @click="handleGroupAction">{{$t('usermanagement.buttonDelete')}}</el-button>
        <!--确 定-->
        <el-button v-else type="primary" @click="dialogShowVisible = false">{{$t('usermanagement.buttonOK')}}</el-button>
        <!--取 消-->
        <el-button type="info" class="cancel" @click="dialogShowVisible = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--删除弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';

  @Component({

  })
  export default class portraitDetails extends Vue {
    @Prop(Object) dataObj!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    dialogShowVisible = false;
    valueData = "";
    handleGroupAction() {
      this.$emit("handleGroupAction", this.dataObj, this.valueData);
      this.dialogShowVisible = false
    }
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeGroupDelete")
      }
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .content{
    width: 80%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  .content .left span{
    padding-left: 70%;
    font-weight: 600;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
</style>
