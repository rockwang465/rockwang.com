<template>
  <transition name="fade">
    <div v-show="visible" :style="style" class="welcome-box">
      <div class="welcome-massage" v-show="showMassage" >{{$t('rule.popmsgESC')}}</div>
      <transition-group name="list-complete" tag="div" class="welcome-transition welcome-transition-up" >
        <div :class="['welcome-card', documentVisibilityState?'list-complete-item':'']"  v-for="(item) in dataArray" :key="item.id">
          <div class="welcome-imgbox">
            <img :src="processImgurl(item.faceImage)" class="welcome-img"/>
          </div>
          <div class="welcome-text">
            <p class="welcome-name">{{item.name}}</p>
            <p class="welcome-msg">{{item.welcomeMsg}}</p>
          </div>
        </div>
      </transition-group>
      <transition-group name="list-complete-down" tag="div" class="welcome-transition welcome-transition-down" >
        <div :class="['welcome-card', documentVisibilityState?'list-complete-down-item':'']"  v-for="(item) in dataArrayDown" :key="item.id">
          <div class="welcome-imgbox">
            <img :src="processImgurl(item.faceImage)" class="welcome-img"/>
          </div>
          <!-- <div class="welcome-text">
            <p class="welcome-name">{{item.name}}</p>
            <p class="welcome-msg">{{item.welcomeMsg}}</p>
          </div> -->
        </div>
      </transition-group>
    </div>
  </transition>
</template>

<script lang="tsx">
import { Component, Vue,Watch ,Prop} from 'vue-property-decorator';

import SockJS from "sockjs-client";
import { Stomp } from "stompjs/lib/stomp.min.js";
import {Cache} from '@/utils/cache';
import {processImgurl} from '@/utils/image';
import {getGroupsTDList} from '@/api/rule';

const refreshTokenTime = window.globalConfig.refreshTokenTime;
const tdwsHost = window.globalConfig.tdwsHost;
@Component({
  components: {

  },
  directives:{

  }
})

export default class Welcome extends Vue {

  get style(){
    let style = {
      "font-size":this.fontSizeNum+'px',
      "background-image":`url(${processImgurl(this.backgroundImage)})`
    };
    return style;
  }

  get fontSizeNum(){
    return 14*this.clientWidth/1920;
  }

  /* props */
  @Prop({default: false,required:true }) visible!: boolean;
  @Prop({default: '',required:false }) backgroundImage!: string;
  @Prop({default: '',required:true }) deviceId!: string;
  @Prop({default: '',required:true }) ruleId!: string;

  /* watch */
  @Watch('visible', { immediate: false, deep: false })
  onVisibleChanged(val: boolean, oldVal: boolean) {
    val && this.initData();
    !val && this.destoryData();
  }

  /* data */
  clientWidth:number=document.body.clientWidth;
  clientHeight:number=document.body.clientHeight;

  //ws
  sessionId:string='';
  socket:any=null;
  socketClient:any=null;

  //wsdata
  name:string='';
  faceImage:string='';
  welcomeMsg:string='';

  processImgurl:any=processImgurl;

  dataArray:any[]=[];
  dataArrayDown:any[]=[];
  showMassage:boolean=false;

  timer:any=null;
  documentVisibilityState:boolean=true;

  upLimitNum:number=4;
  downLimitNum:number=10;
  refreshTimer:any=null;

  // testData:any={"welcomeRemarks":{"libraryId":129,"taskId":1044,"welcomeRemarks":"nosense 666","backgroundImage":"senseguard-oauth2/api/v1/osg/images/OTHER/20190703-112944a47-1391a1de66fadd-00000000-0006045a"},"record":{"serialNumber":"1146606260498599936","eventDescriptor":"ONGOING","confirmationStatus":0,"deviceId":316,"deviceName":"liqiang_nosense","url":"senseguard-oauth2/api/v1/osg/images/video_face/20190704-022650a8-13a34ae7d4db4d-00000000-000015a9","floorId":1,"score":0.45961934,"picUrl":"senseguard-oauth2/api/v1/osg/images/GLOBAL/20190703-105343a2-138d73d81f90ba-00000000-0002e3e3","comparedType":1,"identity":"liqitian3344","imageUrl":"senseguard-oauth2/api/v1/osg/images/video_panoramic/20190704-022650a15-13a3496dda750c-00000000-00030bb7","name":"李辉","captureDate":"2019-07-04 10:26:49","eventNum":0},"welcome":true,"recordDetail":{"preCaptureDate":null,"serialNumber":"1146606260498599936","targetId":"281513","faceAttributeInfo":{"ethicCode":"others","mustacheStyle":"mustache_style_type_none","expression":"st_calm","gender":"female","ageValue":"34.000000","skinColor":"yellow","respiratorColor":"color_type_none","capStyle":"cap","age":"adult","glassesStyle":"glasses_style_type_none"},"confirmationStatus":0,"trackId":1084,"description":"STRANGER","userName":"李辉","operatorName":"","bigPicture":{"imgUrl":"senseguard-oauth2/api/v1/osg/images/video_panoramic/20190704-022650a15-13a3496dda750c-00000000-00030bb7","width":1920,"portraitImageCoordinateInfo":{"endY":751,"endX":1682,"startY":648,"startX":1611},"height":1080},"url":"senseguard-oauth2/api/v1/osg/images/video_face/20190704-022650a8-13a34ae7d4db4d-00000000-000015a9","picUrl":"senseguard-oauth2/api/v1/osg/images/GLOBAL/20190703-105343a2-138d73d81f90ba-00000000-0002e3e3","score":0.45961934,"compareType":"1","ruleName":"3b4b0a1cf1804f27803766487e85e27a","targetLibraryName":"nosense","captureDate":"2019-07-04 10:26:49","id":"liqitian3344","place":"liqiang_nosense","devicePlaceInfo":{"floorId":1,"name":"liqiang_nosense","id":316,"position":{"lng":"656.38","lat":"604.69"},"url":"/senseguard-map-management/api/v1/floor/check/1"}}};
  /* methods */
  mounted() {
    document.addEventListener('visibilitychange',(e)=>{
      this.documentVisibilityState = document.visibilityState == 'visible'?true:false;
    })
  }
  initData(){
    document.body.appendChild(this.$el);
    this.documentVisibilityState = true;
    this.sessionId = '';
    this.socket = null;
    this.socketClient = null;
    this.name='';
    this.faceImage='';
    this.welcomeMsg='';
    this.dataArray = [];
    this.dataArrayDown=[];
    this.showMassage=true;
    this.refreshTimer = null;
    this.connect();
    document.addEventListener('keyup',(e)=>{
      if(e.keyCode == 27){
        this.close();
      }
    });
    // setInterval(()=>{//for dev
    //   let res = this.testData;
    //   res.welcomeRemarks.welcomeRemarks = new Date().toLocaleTimeString();
    //   if(res.welcome){
    //         this.parseMsg(res)
    //       }
    // },4000)
    this.timer = setTimeout(()=>{
      this.showMassage = false;
    },5000);

    this.refreshToken();
  }
  refreshToken(){
    if(this.refreshTimer) clearTimeout(this.refreshTimer);
    getGroupsTDList({page:1,num:1})
    this.refreshTimer = setTimeout(()=>{
      this.refreshToken();
    },refreshTokenTime);
  }
  connect(){
    this.sessionId = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socket = new SockJS(`${tdwsHost}/senseguard-td-result-consume/stomp`,[], {
      sessionId: ()=>{
       return this.sessionId;
      }
    });
    this.socketClient = Stomp.over(this.socket);
    this.socketClient.debug = null;
    // const token = Cache.sessionGet("accessToken");
    this.socketClient.connect(
      // {"accessToken":token},
      (frame)=> {
        this.socketClient.subscribe(`/queue/${this.sessionId}`,  (res) =>{
          res = JSON.parse(res.body) ;
          if(res.welcome){
            this.parseMsg(res)
          }
        });
        setTimeout(()=>{
          this.sendmsg()
        },200)
      },(error)=> {

      }
    );
    //reconnect
    this.socket.onclose = (e) =>{
      this.visible && setTimeout(()=>{
       this.connect();
      },2000);
    };
  }
  sendmsg() {
    // const accessToken = Cache.sessionGet("accessToken");
    const requestBody = JSON.stringify({
      sessionId:this.sessionId,
      deviceIds:[this.deviceId],
      compareTypes:[],
      ruleGroupIds:[],
      // accessToken,
      ruleId:this.ruleId
    });
    this.socketClient.send(`/app/filter_condition`,{},requestBody);
  }
  destoryData(){
    this.$el && this.$el.parentNode && this.$el.parentNode.removeChild(this.$el);
    this.socket && this.socket.close();
    this.socket = null;
    this.socketClient = null;
    document.removeEventListener('keyup',(e)=>{
      if(e.keyCode == 27){
        this.close();
      }
    });
    this.timer && clearTimeout(this.timer);
    this.refreshTimer && clearTimeout(this.refreshTimer);
  }
  destroyed() {
    this.destoryData()
  }
  close(){
    this.$emit('close')
  }
  parseMsg(res){
    let faceImage = res.recordDetail.picUrl,
    welcomeMsg = res.welcomeRemarks.welcomeRemarks,
    name = res.recordDetail.userName || '',
    id=new Date().getTime()+''+parseInt(Math.random()*10000+'');
    let alarm = {faceImage,welcomeMsg,name,id};

    if(this.dataArray.length>(this.upLimitNum-1)){
      if(this.dataArrayDown.length>(this.downLimitNum-1)){
        this.dataArrayDown.splice(this.downLimitNum-1,1);
      }
      this.dataArrayDown.unshift(this.dataArray[0]);
      this.dataArray.splice(0,1);
    }
    this.dataArray.push(alarm);
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.welcome-box{
  width:100%;
  height:100%;
  position:absolute;
  top:0;
  left:0;
  z-index:9999999;
  background-color:#b3c1d2;
  background-size: cover;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.welcome-massage{
  padding: 10px;
  font-size: 1em;
  left: 50%;
  background-color:rgba(0,0,0,0.7);
  color: white;
  border-radius: 5px;
  top: 20px;
  position: absolute;
  margin: 0 auto;
}
.welcome-transition{
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.welcome-card{
  width: 26em;
  height: 35em;
  background-color:rgba(0,0,0,0.3);
  border-radius: 1.5em;
  box-shadow: $--box-shadow-dark;
  overflow: hidden;
}
.welcome-imgbox{
  width: 24.64em;
  height: 24.64em;
  border-radius: 50%;
  margin: 0 auto;
  margin-top: 0.6em;
  background: linear-gradient(#89f104, #02e2fa);
  display: flex;
  align-items: center;
  justify-content: center;
}
.welcome-img{
  width: 23.1em;
  height: 23.1em;
  border-radius: 50%;
  border:none;
  display: block;
}
.welcome-text{
  p{
    text-align: center;
    color: white;
  }
  .welcome-name{
    font-size: 2.3em;
    line-height: 2.5em;
  }
  .welcome-msg{
    font-size: 1.35em;
    line-height: 2.14em;
  }
}
.welcome-transition-down{
  margin-top: 10em;
  .welcome-card{
    width: 11em;
    height: 11em;
    border-radius: 50%;
    .welcome-imgbox{
      width: 11em;
      height: 11em;
      margin: 0;
    }
    .welcome-img{
      width: 10em;
      height: 10em;
    }
  }
}



.list-complete-item {
  transition: all 1s;
  display: inline-block;
  margin-right: 10px;
}
.list-complete-enter, .list-complete-leave-to {
  opacity: 0;
}
.list-complete-enter{
  transform: translateX(300px) scale(1);
}
.list-complete-leave-to{
  transform: translate(-750px,450px) scale(.3);
}
.list-complete-leave-active {
  position: absolute;
}


.list-complete-down-item {
  transition: all 1s;
  display: inline-block;
  margin-right: 10px;
}
.list-complete-down-enter, .list-complete-down-leave-to {
  opacity: 0;
}
.list-complete-down-enter{
  transform: translate(0px,0px);
}
.list-complete-down-leave-to{
  transform: translateX(1000px);
}
.list-complete-down-leave-active {
  position: absolute;
}
</style>
