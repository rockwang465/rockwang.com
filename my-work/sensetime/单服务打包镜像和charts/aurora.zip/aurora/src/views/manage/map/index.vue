<template>
  <el-container class="wrap">
    <el-aside width="312px">
      <h2 class="side-title"><i class="iconfont icon-map-list"></i><span>{{$t('map.labelMapList')}}</span></h2>
      <LeftTree
        ref="sideMapTree"
        :treeData="treeData"
        :leftTreeData="leftTreeData"
        :currentNodeKey="currentNodeKey"
        @clickVal="handleClick"
        @addData="handleAdd"
        node-key="id"
        :current-node-key="currentNodes"
        :default-expanded-keys="[]"
        :props="defaultProps"
        @updateData="handleUpdate"
        :key="treeKey"
        @deleteData="handleDelete">
      </LeftTree>
    </el-aside>
    <el-main class="main">
      <div class="main_head">
        <div v-if="hasMap">
          <el-button v-if="$permission('010308')" @click="switchDrawTools(false)" type="primary" :icon="mapEditIcon">
            <span v-if='!drawView'>{{$t('map.buttonAreaEdit')}}</span>
            <span v-else>{{$t('map.buttonFinishEdit')}}</span>
          </el-button>
          <el-button v-if="$permission('010314')" @click="mapImgChange('change')" type="primary" icon="iconfont icon-map-list">{{$t('map.buttonMapReplace')}}</el-button>
          <el-button v-if="$permission('010415')" @click="mapImgChange('delect')" type="danger" icon="iconfont icon-delete">{{$t('map.buttonMapDelete')}}</el-button>
        </div>
      </div>

      <div class="map_layer">
        <div v-if="noData" class="no-map">
          <el-upload
            v-if="$permission('010302')"
            class="map-upload"
            drag
            :action="UploadUrl()"
            :before-upload="beforeMapUpload"
            :on-success="mapUploadSuccess"
            multiple>
            <i class="iconfont icon-map-list"></i>
            <div class="el-upload__text">{{$t('map.contMapUpload')}}</div>
            <div class="el-upload__tip" slot="tip">
              <ol>
                <li>{{$t('map.contMapType')}}</li>
                <li>{{$t('map.contMapSize')}}</li>
              </ol>
            </div>
          </el-upload>
        </div>
        <!-- <div class="no-map-data" @click="drawInit" v-if="!noData && noMapData && $permission('010308')">
          <p>
            {{$t('map.contAreaDraw')}}
          </p>
        </div> -->

        <l-map ref="map"
          :style="!visibility"
          v-loading="showLoading"
          :crs     ="mapSet.crs"
          :center  ="mapSet.center"
          :zoom    ="mapSet.zoom"
          :min-zoom="mapSet.minZoom"
          :max-zoom="mapSet.maxZoom"
          :key="mapSet.key"
          :options="mapOptions">
          <!-- <l-draw-toolbar position="topleft"></l-draw-toolbar> -->

          <!-- <l-control position="topleft" ref="refDrawControl">
            <button >
              I am a useless button!
            </button>
          </l-control> -->
          <l-control-scale position="topright" scale="imperial" ></l-control-scale>
          <l-image-overlay
            :url="mapSet.bgUrl+'?timestamp='+ +new Date()"
            className="mapStyle"
            name="mapImgBg"
            :key="mapbgKey"
            :bounds="mapSet.bounds"/>
          <l-polyline :lat-lngs="travel" />

          <l-layer-group
            layer-type="overlay"
            name="Layer polyline"
          >
            <l-marker v-for="item in deviceList"
              :lat-lng.sync="item.position"
              :icon="item.icon"
              :key="item.id">
              <l-popup>
                {{$tc('map.deviceName')}}
                {{item.deviceName}}
                <br/>
                {{$tc('map.deviceId')}}
                {{item.deviceId}}
              </l-popup>
            </l-marker>
          </l-layer-group>
          <l-geo-json
          v-if="region.geojson"
          :geojson="region.geojson"
          :key="region.geoJsonKey"
          :options="region.options" />

          <!-- <l-control-zoom  class="aurora-zoom" position="bottomright"></l-control-zoom> -->
          <!-- <l-control position="topleft" class="aurora-control"> </l-control>-->
        </l-map>
      </div>

      <!-- 地图关联 -->
      <el-dialog title="选择须关联的地图" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="关联地图" :label-width="formLabelWidth">
            <el-select size="small" v-model="form.region" placeholder="请选择对应地图">
              <el-option label="一楼" value="floor1"></el-option>
              <el-option label="二楼" value="floor2"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
          <el-button type="info" @click="dialogFormVisible = false">取 消</el-button>
        </div>
      </el-dialog>

      <!-- 地图层级添加 -->
      <el-dialog :title="dialogTitle" :visible.sync="isTreeAdd" v-if="isTreeAdd" class="dialog-track">
        <el-form :model="form" ref="regionRules" :rules="regionRules" v-if="isTreeAdd">
          <el-form-item :label="$t('map.contMapName')" :label-width="formLabelWidth" prop="name">
            <el-input size="small" v-model="form.name" maxlength="40" autocomplete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" :loading="isSubmit" @click="addTree">{{$t('map.buttonOK')}}</el-button>
          <el-button type="info" @click="isTreeAdd = false">{{$t('map.buttonCancel')}}</el-button>
        </div>
      </el-dialog>

      <!-- 地图层级修改 -->
      <el-dialog :title="dialogTitle" :visible.sync="isTreeEdit"  v-if="isTreeEdit" class="dialog-track">
        <el-form :model="form" ref="regionRules" :rules="regionRules">
          <el-form-item :label="$t('map.contMapName')" :label-width="formLabelWidth" prop="name">
            <el-input size="small" v-model="form.name" maxlength="40" :value="form.name" autocomplete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="editTree">{{$t('map.buttonOK')}}</el-button>
          <el-button type="info" @click="isTreeEdit = false">{{$t('map.buttonCancel')}}</el-button>
        </div>
      </el-dialog>

      <!-- 区域名称设置 -->
      <el-dialog class="dialog-track"
        :title="dialogTitle"
        :visible.sync="isRegionEdit"
        v-if="isRegionEdit"
        :show-close="false"
        :close-on-press-escape="false"
        :close-on-click-modal="false"
      >
        <el-form :model="form" ref="regionRules" :rules="regionRules" v-if="isRegionEdit">
          <el-form-item :label="$t('map.contAreaName')" :label-width="formLabelWidth" prop="areaName">
            <el-input v-model="form.areaName" size="small" name ="areaName" maxlength='40' :value="form.region.areaName" autocomplete="off"></el-input>
          </el-form-item>
          <!-- <el-form-item :label="$t('map.contTag')" :label-width="formLabelWidth">
            <el-select
              class="select-tag"
              size="small"
              popper-class="select-tag-drop-layer"
              v-model="form.tagList"
              multiple
              filterable
              allow-create
              default-first-option
              :placeholder="$t('map.contCustomizeTag')">
              <el-option
                v-for="item in tagList"
                :key="item.id"
                :label="item.name"
                :value="item.id">
              </el-option>
            </el-select>
          </el-form-item> -->
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" :loading="isSubmit" @click="regionEdit">{{$t('map.buttonOK')}}</el-button>
          <el-button type="info" @click="regionCancel">{{$t('map.buttonCancel')}}</el-button>
        </div>
      </el-dialog>
    </el-main>
  </el-container>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import {Tree as ElTree} from 'element-ui';
import { Route } from 'vue-router';
import L from 'leaflet';
import { LMap, LImageOverlay, LMarker, LPopup,LPolyline,LGeoJson,LControl,LControlLayers,LControlScale,LControlZoom,LLayerGroup } from 'vue2-leaflet';
//import LDrawToolbar from '@/components/vue2-leaflet-draw/App.vue';

import i18n from '@/lang/index' // Internationalization
import { Form as ElForm } from 'element-ui';
//
import {Cache} from '@/utils/cache';
import LeftTree from '@/components/leftTree/index.vue';

import PopupContent from './geo-json-popup.vue';
import {fileValidate,isEmpty} from '@/utils/validate';
import {transport} from '@/utils/image';

//draw-module
import 'leaflet-draw';
import 'leaflet-toolbar';

import '@/assets/js/plugins/leaflet.draw-toolbar.js';
import '@/assets/js/plugins/L.Control.Zoomslider.js';

//api
import api from '@/api/map';
import { MapModule } from '@/store/modules/map';
import api_device from '@/api/device';

//mapConfig
import {drawSetting,markerIcon,drawPoint,mapBase} from './mapConfig';

let validateName = (rule, value, callback) => {
  value = value.trim();
  //console.log(rule, value, callback)
  if (value === '') {
    callback(new Error(i18n.tc("form.texterrEnterGroupName")))
  } else {
    callback()
  }
}
let validateAreaName = (rule, value, callback) => {
  //console.log(rule, value, callback)
  value = value.trim();
  if (value === '') {
    callback(new Error(i18n.tc("form.texterrEnterAreaName")))
  } else {
    callback()
  }
}


@Component({
  components: {
    LMap, LImageOverlay, LMarker, LPopup,LPolyline,
    LGeoJson,
    LeftTree,
    LControl,
    LControlScale,
    LControlLayers,
    LControlZoom,
    LLayerGroup,
    //LDrawToolbar
  },
})
export default class Map extends Vue {
  //data-begin
  map:any = "";
  isMapTrack=false;
  isTreeHandle=false;
  mapOptions= {
    attributionControl: false,
    zoomSnap: false,
    drawControl: false,
    zoomControl: false,
    zoomsliderControl: true,
  };
  currentNodeKey = 0;
  currentNodes = '';
  currentNodesArr:any = [];
  heatLayer:any = null;
  actionUrl:any = null;
  isChild=false;
  deleteTips:any = "";
  mapbgKey = '';
  redirect: string | undefined = undefined;
  travel  = [];
  show= true
  geojson= null
  loading = true
  noData=false;
  visibility = "visibility:visible"
  noMapData=false;
  drawView=false;
  heatmapView=false;
  formLabelWidth = "100px";
  dialogFormVisible= false;
  dialogTitle=i18n.t('rolemanagement.contAdd');
  isEdit=false;
  isTreeAdd = false;
  isTreeEdit = false;
  isTreeDelete = false;
  isRegionEdit = false;
  isAdd=false;
  isMapDevice=false;
  hasMap=false;
  // uploadHeader={
  //   accessToken:Cache.localGet("accessToken") || Cache.sessionGet("accessToken")
  // };
  deviceIcon:any;

  form:any={
    name: '',
    areaName:'',
    region: [Array],
    parentId:'',
    parentLabel:'',
    floorId:'',
    state:1,
    tagList:[],
    type:""
  }
  defaultProps = {
    children: 'children',
    label: 'label',
  };
  isSubmit= false;

  tagList= [];
  leftTreeData = {
    label: 'name',
    actionArray: [1, 1, 0, 1, 1] //设备树的按钮显示影藏 创建同级 创建下一级 详情 重命名 分组
  } as any;
  treeData:any = [];
  mapEditIcon="iconfont icon-edit";
  mapBase
  deviceList:any   = [];
  mapSet:any = Object.assign(mapBase,{
    //key     : +new Date(),
    bgUrl   : '/images/floor00.png',
    dataUrl : '/mock/floor0.json',
    reset   : true
  });
  enableTooltip= true;
  floorInfo:any = {
    name: "string",
    parentId: 0,
    id:2
  }
  region = {
    geojson: null,
    geoJsonKey: 1,
    options: {
      style: function (feature) {
        return {
          weight: 2,
          color: '#2a5af5',
          opacity: 1,
          fillColor: "#b7cbf4",
          fillOpacity: 0.6
        };
      },
      // pointToLayer: function (feature, latlng) {
      //   return L.marker(latlng, {
      //     icon: defaultIcon
      //   });
      // },
      filter: function (feature, layer) {
        if (feature.properties) {
          return feature.properties.underConstruction !== undefined ? !feature.properties.underConstruction : true;
        }
        return false;
      },
      onEachFeature: this.onEachFeature
    }
  }
  deviceLocation:any=[];

  regionRules={
    name: [
      { required: true, trigger: 'blur', validator: validateName},
      { max: 40, message: '', trigger: 'blur' }
    ],
    areaName: [
      { required: true, trigger: 'blur', validator: validateAreaName},
      { max: 40, message: '', trigger: 'blur' }
    ]
  }
  drawnItems:any;
  drawControl:any;
  editActions:any=[];
  uploadType='';
  showLoading = false;
  treeKey = 0
  //data-end

  @Watch('$route', { immediate: true })
  @Watch('floorInfo')
  OnRouteChange(route: Route) {
    this.redirect = route.query && route.query.redirect as string;
  }
  mounted(){
    this.leftTreeData.actionArray = [this.$permission('010301'),this.$permission('010301'),false,this.$permission('010204'),this.$permission('010403')];
    //console.log(this.leftTreeData.actionArray)
    //console.log(L);
    this.mapSet = Object.assign(mapBase,this.mapSet);
    this.drawnItems = new L.FeatureGroup();
    if(this.$permission('010307')){
      this.treeInit();
    }
    this.getTagList();
    this.$nextTick(()=>{
      //this.$refs.map.$el.getElementsByClassName('leaflet-draw-toolbar')
    })
  }

  onEachFeature (feature, layer) {
    //console.log(feature, layer)
    let _this =this;
    let areaContent = feature.properties.name
    let PopupCont = Vue.extend(PopupContent);
    let popup = new PopupCont({ propsData: { type: feature.geometry.type, text: feature.properties.name } });
    //layer.bindPopup(popup.$mount().$el);
    layer.bindTooltip(popup.$mount().$el,{direction:'bottom',permanent:true,className:'area-name',pane:'overlayPane'});

    layer.on('click', function(event) {
      // _this.prevLayerJson = event.target.getLatLngs();
      // console.log(_this.prevLayerJson)
      //layer.editing.enable();
      let actionsItems:any = [];
      if(_this.$permission('010309')){
        actionsItems.push((L as any).Toolbar2.EditAction.Popup.Edit)
      }
      if(_this.$permission('010410')){
        actionsItems.push((L as any).Toolbar2.EditAction.Popup.Delete)
      }

      new (L as any).Toolbar2.Popup(event.latlng, {
        actions: actionsItems
      }).addTo(_this.map, layer);
      _this.isAdd = false;
      //console.log(actionsItems)

    });
  }
  getTagList(){
    api.getRegionTagList().then((resp)=>{
      this.tagList = resp.data;
    })
  }

  treeInit(defaultFloor?:any){
    let _this = this;
    this.showLoading = true;
    //console.log(this.showLoading)
    MapModule.TreeList().then((resp:any) => {

      this.showLoading = false;
      //console.log(this.showLoading,resp);
      if(resp.data){

        this.treeData = resp.data;
        if(resp.data.length > 0){
          this.hasMap = true;
          if(defaultFloor){
            this.currentNodeKey = defaultFloor.floorId;
            this.treeKey = +new Date();
            resp.data.map((level1,index)=>{
              if(level1.id == defaultFloor.floorId){
                this.floorInfo.id = level1.id;
                this.mapSet.key = +new Date();
                this.mapbgKey += new Date();
                if(level1.url){
                  this.mapSet.bgUrl = transport(level1.url);
                }else{
                  this.mapSet.bgUrl = '';
                  this.hasMap = false;
                }
                this.mapSet.dataUrl = api.getMapData(level1.id);
              }else if(level1.children){
                level1.children.map((level2)=>{
                  if(level2.id == defaultFloor.floorId){
                    console.log(level2);
                    if(level2.url){
                      this.mapSet.bgUrl = transport(level2.url);
                    }else{
                      this.mapSet.bgUrl = '';
                      this.hasMap = false;
                    }
                    this.floorInfo.id = level2.id;
                    this.mapSet.key = +new Date();
                    this.mapbgKey += new Date();
                    this.mapSet.dataUrl = api.getMapData(level2.id);
                  }
                })
              }
            })

          }else{
            //console.log(resp.data)
            function readTreeInfo(floorObj){
              //console.log(floorObj)
              _this.floorInfo.id = floorObj.id;
              _this.mapSet.bgUrl = transport(floorObj.url);
              _this.mapSet.dataUrl = api.getMapData(floorObj.id);
              _this.currentNodeKey = floorObj.id;
              _this.currentNodes = floorObj.id;
              _this.currentNodesArr = [floorObj.id];
              _this.leftTreeData.expandArr = [floorObj.id]


              if(floorObj.children && floorObj.children.length > 0){
                readTreeInfo(floorObj.children[0])// 递归叶子节点
              }
            }
            readTreeInfo(resp.data[0])
            //console.log(_this.currentNodesArr,_this.mapSet.bgUrl,_this.treeData)

            //默认读取的地图数据,需要优化
            // if(resp.data[0].children){
            //   this.floorInfo.id = resp.data[0].children[0].id;
            //   this.mapSet.bgUrl = transport(this.treeData[0].children[0].url);
            //   this.mapSet.dataUrl = api.getMapData(this.treeData[0].children[0].id)
            // }else{
            //   this.floorInfo.id = resp.data[0].id;
            //   this.mapSet.bgUrl = transport(this.treeData[0].url);
            //   this.mapSet.dataUrl = api.getMapData(this.treeData[0].id)
            // }
          }

        }else{
          this.noData = true;
          this.visibility = "visibility:visible"
          this.hasMap = false;
        }
      }else{
        this.treeData = [
          {
            id: "null",
            name: '+',
          }
        ]
      }

    }).then(()=>{
      if(this.$permission('007117')){
        this.loadDevice();
      }
     //debugger

      //console.log(this.currentNodeKey,this.mapSet)
      _this.mapInit(this.mapSet);

    });
  }

  UploadUrl(){
    const params = {
      id:this.floorInfo.id,
      // token:Cache.localGet("accessToken") || Cache.sessionGet("accessToken"),
      type:this.uploadType
    }
    return api.mapUpload(params)
  }

  beforeMapUpload(file){
    //console.log(file);
    //let isWidth = false;
    let allowFile = fileValidate(file,['png','jpg','bmp'],5);
    //console.log(allowFile)
    if(!allowFile.type){
      console.log("格式不合法")
      this.$message.error(this.$tc('map.errmsgImageType'));
      return false;
    }
    //console.log(!isFile.size,!isWidth)
    if (!allowFile.size) {
      console.log("大小不合法")
      this.$message.error(this.$tc('map.errmsgImageSize'));
      return false;
    }
    if (!allowFile.len) {
      console.log("长宽不合法")
      this.$message.error(this.$tc('map.errmsgImageSize'));
      return false;
    }
  }

  mapUploadSuccess(res, file) {
    //console.log(res,file)
    this.drawView = false;
    this.treeInit(res);

    this.hasMap = true;
    //console.log(this.drawView)
  }

  mapImgChange(type){
    this.floorInfo.state = 0;
    let confirmTitle = this.$tc('map.buttonDelete');
    let confirmButtonCon = this.$tc('map.buttonDelete');
    let successMessage = this.$tc('map.mapDeleteSuccess');
    this.deleteTips = this.$tc('map.popmsgMapDelete');
    let redClass = "el-button--danger";
    if(type == 'change'){
      confirmTitle = this.$tc('map.buttonReplace');
      confirmButtonCon = this.$tc('map.buttonReplace');
      this.deleteTips = this.$tc('map.popmsgMapReplace');
      successMessage = this.$tc('map.mapChangeSuccess');
      redClass = '';
    }
    this.$confirm(this.deleteTips, confirmTitle, {
      cancelButtonText: this.$tc('map.buttonCancel'),
      confirmButtonText: confirmButtonCon,
      confirmButtonClass: redClass,
      cancelButtonClass:'el-button--info'
    }).then(() => {
      this.floorInfo.state = 1;
      if(type == 'change'){
        this.uploadType = 'change';
        api.mapImgUpdate(this.floorInfo).then((resp:any)=>{
          console.log(resp)
          this.noData = true;
          this.visibility = "visibility:visible";

        })
      }else{
        api.mapImgDelete(this.floorInfo).then((resp:any)=>{
          this.$message({
            showClose:true,
            message: successMessage,
            type: 'success'
          });
          this.noData = true;
          this.visibility = "visibility:visible";
          this.hasMap = false;
          this.region.geojson = null;
          this.form.region = null;
          this.treeInit(resp)
        })
      }
    }).catch((error) => {
      console.log("error",error);
    });
  }
  resetMap(){
    this.map.setView(new L.LatLng(540, 960), 15);
  }
  mapInit(mapSet){
    //console.log('绘图数据？？',this.region)
    let _this = this;
    if(this.$refs.map){
        this.map = (this.$refs.map as any).mapObject;
        //console.log(this.map)
        this.map.addLayer(this.drawnItems);
        //window.L.drawLocal = drawSetting;
        //var drawnItems = new window.L.FeatureGroup();
        var options = {
          draw : {
            position : 'topright',
            polygon : {
                title : 'Draw a sexy polygon!',
                allowIntersection : false,
                drawError : {
                  color : '#b00b00',
                  timeout : 1000
                },
                touchIcon: new L.DivIcon({
                  iconSize: new L.Point(10, 10),
                  className: 'leaflet-div-icon leaflet-editing-icon leaflet-touch-icon'
                }),
                guidelineDistance:10,
                shapeOptions : {
                  iconSize: new L.Point(10, 20),
                  color : '#bada55',
                  weight: 2,
                  dashArray:'5'
                },
                icon: drawPoint,
                showArea : true
            },
            polyline : undefined,
            rectangle : {
                title : 'Draw a sexy polygon!',
                allowIntersection : false,
                drawError : {
                  color : '#b00b00',
                  timeout : 1000
                },
                touchIcon: new L.DivIcon({
                  iconSize: new L.Point(10, 10),
                  className: 'leaflet-div-icon leaflet-editing-icon leaflet-touch-icon'
                }),
                guidelineDistance:10,
                shapeOptions : {
                  iconSize: new L.Point(10, 20),
                  color : '#bada55',
                  weight: 2,
                  dashArray:'5'
                },
                icon: drawPoint,
                showArea : true
            },
            circlemarker : undefined,
            circle : undefined,
            marker: undefined//{icon: iconDefault}
          },
          edit: undefined,
          hideSingleBase: true,
          // edit: {
          //   featureGroup: this.drawnItems
          // }
        };

        this.drawControl = new window.L.Control.Draw(options);
        //console.log(this.drawControl,this.$refs.refDrawControl)
        //this.$refs.refDrawControl.addLayer(this.drawControl);
        this.map.addControl(this.drawControl);
        this.map._controlCorners.topleft.style.display ='none'
        //console.log(this.map._controlCorners.topleft)
        //alert('添加工具')

        this.map.on('draw:edited', function (e) {
          let layers = e.layers;
          _this.dialogTitle = _this.$t('map.contAreaEdit')

          layers.eachLayer(function (layer) {

            let coords = _this.toCoords(layer.getLatLngs()[0]);
            _this.form.name ='';
            if(layer.feature){
              _this.form.id = layer.feature.properties.regionId;
              _this.form.type = layer.feature.geometry.type;
              _this.form.name = layer.feature.properties.name;
              _this.form.areaName = layer.feature.properties.name;
            }
            _this.form.floorId = _this.floorInfo.id;
            _this.isRegionEdit =true;
            _this.form.region = coords;

          });
        });

        //FIXME: 区域删除(事件监测不到问题)
        this.map.on('draw:deleted', (e)=> {
          e.layers.eachLayer(function (layer) {
            if(layer.feature){
              let regionInfo={
                id:layer.feature.properties.regionId,
                state:1,
                // token:Cache.localGet("accessToken") || Cache.sessionGet("accessToken")
              }

              _this.$confirm(_this.$tc('map.listAreaDelete'), _this.$tc('rolemanagement.titleReminder'), {
                confirmButtonText: _this.$tc('map.buttonDelete'),
                cancelButtonText: _this.$tc('map.buttonCancel'),
                confirmButtonClass:'el-button--danger',
                cancelButtonClass:'el-button--info'
                //type: 'warning'
              }).then(() => {
                api.regionDelect(regionInfo).then((resp)=>{
                  _this.$message({
                    showClose:true,
                    type: 'success',
                    message: _this.$tc('map.mapAreaDeleteSuccess')
                  });
                  _this.loadMapJson();
                });
              }).catch(() => {
                // _this.$message({
                //   showClose:true,
                //   type: 'success',
                //   message: 'Cancel'
                // });
              });
            }

          })
        });

        //区域添加
        this.map.on("draw:created", function (ev) {
          //console.log(ev.layer.getLatLngs())
          var coords=new Array;
          var shaptype = ev.layerType;
          _this.dialogTitle = _this.$t('map.buttonAreaEdit')

          if(shaptype =="polygon" || shaptype =="rectangle"){
            coords = _this.toCoords(ev.layer.getLatLngs()[0]);
            shaptype ="polygon";
          }else if(shaptype =="polyline"){
            coords = _this.toCoords(ev.layer.getLatLngs());
          }else{
            coords = L.GeoJSON.latLngToCoords(ev.layer.getLatLng());
          }

          // console.log("绘制创建完成",shaptype,coords);
          // console.log(_this.form)
          _this.isAdd = true;
          var layer = ev.layer;
          _this.drawnItems.addLayer(layer);

          let newType = shaptype.charAt(0).toUpperCase() + shaptype.slice(1);
          //console.log(newType);
          _this.form.floorId = _this.floorInfo.id;
          _this.form.type = newType;
          _this.form.region = coords;
          _this.form.name = "";
          _this.form.areaName = "";
          _this.isRegionEdit = true;
        });
      }

    this.loadMapJson(mapSet)
  }
  loadMapJson(mapSet?){
    console.log(this.mapSet)
    this.showLoading = true;
    //console.log(this.showLoading)
    if(this.mapSet.bgUrl){
      this.noData = false;
      this.visibility = "visibility:hidden"
      this.region.geojson = null;
      this.drawnItems.clearLayers();

      api.getMapGeojson(this.floorInfo).then((resp:any)=>{
        console.log(resp)

        this.showLoading = false;
        if(resp.data && resp.data.features){
          this.noMapData = false;
          this.region.geojson = resp.data;
          //console.log(this.region.geojson)
        }else{
          this.noMapData = true;
        }

      })

    }else{
      this.noData = true;
      this.visibility = "visibility:visible"
    }
  }
  toCoords(latLngs) {
    //latLngs={lng:经度,latitude:维度}
    let coords:any = [];
    for (let i = 0, len = latLngs.length; i < len; i++) {
      coords.push([latLngs[i].lng, latLngs[i].lat]);
    }
    return coords;
  }

  regionCancel(e){
    this.isRegionEdit = false;
    this.drawnItems.clearLayers();
    this.region.geoJsonKey += 1;
    //this.loadMapJson();
  }

  regionEdit(regionInfo){
    (this.$refs.regionRules as ElForm).validate((valid: boolean) => {
      if (valid) {
        //console.log(this.form)
        if(this.isAdd){
          api.regionCreate(this.form).then((resp:any)=>{
            this.isRegionEdit = false;
            this.loadMapJson();
            this.$message({
              showClose:true,
              type: 'success',
              message: this.$tc('map.mapAreaAddSuccess')
            });
          })
        }else{
          api.regionUpdate(this.form).then((resp:any)=>{
            this.isRegionEdit = false;
            this.loadMapJson();
            this.$message({
              showClose:true,
              type: 'success',
              message: this.$tc('map.mapAreaUpdateSuccess')
            });
          })
        }

      }
    });
  }
  switchDrawTools(isInit?){
    if(this.$permission('010308')){
      //console.log(isInit)
      //this.drawView = isInit;
      // if(isInit){
      //   this.drawView = false;
      //   this.map._controlCorners.topleft.style.display ='none';
      //   this.mapEditIcon="iconfont icon-edit";
      // }else{
        //console.log(this.drawView)
        if(this.drawView){
          this.map._controlCorners.topleft.style.display ='none';
          this.mapEditIcon="iconfont icon-edit";
        }else{
          this.map._controlCorners.topleft.style.display ='block';
          this.mapEditIcon="iconfont icon-edit-end";
        }
        this.drawView = !this.drawView;
      //}

    }
  }
  drawInit(){
    //console.log(this.map,this.drawControl)
    this.noMapData = false;
    let _this = this;

    //this.drawView = !this.drawView;
    //this.drawView = false;
    //if(this.$permission('010308')){
      if(!this.drawView){
        //this.mapEditIcon="iconfont icon-edit-end";
        //_this.map.addControl(this.drawControl);
      }else{
        //this.drawView = false;
        //this.mapEditIcon="iconfont icon-edit";
        //_this.map.removeControl(this.drawControl);
      }
    //}

  }

  loadTrack(e){
    if(e){
      this.isMapTrack=true;
    }else{
      this.isMapTrack=false;
    }
  }
  addDevice(e){
    if(e){
      this.isMapDevice=true;
    }else{
      this.isMapDevice=false;
    }
  }

  handleClick(treeData: any){
    let _this = this;
    _this.isRegionEdit = false;
    _this.uploadType ='';
    if(treeData.isLeaf && this.$permission('010307')){
      _this.showLoading= true;
      setTimeout(()=>{
        _this.showLoading= false;
      },1000)
      if(treeData.url){
        this.noData = false;
        this.visibility = "visibility:hidden"
        this.hasMap = true;
        this.drawInit();
        this.drawnItems.clearLayers();
      }else{
        this.noData = true;
        this.visibility = "visibility:visible"
        this.hasMap = false;
      }
      let mapHeight = treeData.height;
      let mapWidth = treeData.width;
      let coef = mapWidth / 1920;

      this.floorInfo.id = treeData.id;
      this.mapSet.floorID = treeData.id;
      this.mapSet.bgUrl = transport(treeData.url);
      if(this.$permission('010105')){
        this.mapSet.dataUrl = api.getMapData(treeData.id);
      }

      //key:+new Date(),
      //this.mapSet.key = +new Date();
      this.drawView = true;
      this.switchDrawTools(this.drawView)
      //this.mapInit(this.mapSet);
      if(this.$permission('007117')){
        this.loadDevice();
      }
      console.log(treeData)
      this.loadMapJson()
    }
  }

  loadDevice(){
    this.deviceList = [];
    api_device.floorDeviceList({id:this.floorInfo.id}).then((resp)=>{
      resp.data.map((item,i)=>{
        //console.log(item,i)
        if(item.point){
          let pointStr = item.point.substring(1,item.point.length-1);
          let pointArr = pointStr.split(',');
          this.deviceIcon = markerIcon.default;
          if(item.accessState =='0'){
            this.deviceIcon = markerIcon.offLine
          }
          let newJson = {
            id:item.ID,
            deviceId:item.deviceId,
            deviceName:item.deviceName,
            name : this.$tc('map.deviceName')+item.deviceName+"<br>"+this.$tc('map.deviceId')+item.deviceId,
            isShow:false,
            icon:this.deviceIcon,
            position :{
              lng:pointArr[0],
              lat:pointArr[1],
            }
          }
          this.deviceList.push(newJson);
        }

      })
    })
  }

  //添加楼层
  handleAdd(flag,treeData: any) {
    this.dialogTitle = this.$t('map.listPeerGroupCreate');
    this.isEdit = false;
    this.isTreeAdd = true;
    this.form.name=""
    if(flag =="next"){
      this.dialogTitle = this.$t('map.listSubGroupCreate');
      this.isChild = true;
      this.form.parentId = treeData.id
      this.form.parentLabel = treeData.name
    }else{
      this.isChild = false;
      this.form.parentId = treeData.parentId
    }
  }
  addTree(){
    let _this = this;
    (this.$refs.regionRules as ElForm).validate((valid: boolean) => {
      if (valid) {
        this.isSubmit = true;
        let successTips = this.$tc('map.treeAddSiblingsSuccess');
        if(this.isChild){
          successTips = this.$tc('map.treeAddChildrenSuccess');
        }
        api.mapTreeAdd(this.form).then((resp:any)=>{
          this.$message({
            showClose:true,
            type: 'success',
            message: successTips
          });
          this.treeInit()
          this.isTreeAdd = false;
          this.isSubmit = false;
        })
        setTimeout(()=>{
          _this.isSubmit  = false;
        },1200);
      }
    })
  }

  //修改楼层
  handleUpdate(treeData: any) {
    this.isEdit = true;
    this.dialogTitle = this.$t('map.listRename');
    this.form.name = treeData.name;

    this.form.floorId = treeData.id;
    this.isTreeEdit = true;
  }
  editTree(){
    let _this = this;
    (this.$refs.regionRules as ElForm).validate((valid: boolean) => {
      if (valid) {
        this.isSubmit = true;
        api.mapTreeEdit(this.form).then((resp:any)=>{
          this.$message({
            showClose:true,
            type: 'success',
            message: this.$tc('map.listRename')+this.$tc('map.success')
          });
          this.treeInit()
          this.isTreeEdit = false;
          this.isSubmit = false;
        });
        setTimeout(()=>{
          _this.isSubmit  = false;
        },1200);
      }
    })
  }

  //删除数据
  handleDelete(treeData: any) {
    let _this = this;
    this.form.floorId = treeData.id;
    this.form.state = 0;
    this.deleteTips = "“"+treeData.name+"” "+this.$t('map.popmsgMapDelete')

    this.$confirm(this.deleteTips, this.$tc('usermanagement.listDelete'), {
      confirmButtonText: this.$tc('map.buttonDelete'),
      cancelButtonText: this.$tc('map.buttonCancel'),
      confirmButtonClass:'el-button--danger',
      cancelButtonClass:'el-button--info'
    }).then(() => {
      //submit
      this.form.state = 1;
      api.mapTreeDelete(this.form).then((resp:any)=>{
        this.$message({
          showClose:true,
          type: 'success',
          message: this.$tc('map.titleGroupDelete')+this.$tc('map.success')
        });
      }).then(()=>{
        this.treeInit()
      })
    }).catch(() => {
      //canned
    });

  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
@import "src/assets/style/leaflet.scss";
@import "src/assets/style/leaflet.draw.scss";
$bg:#2d3a4b;
$light_gray:#eee;
.wrap{
  padding: 0 8px;
}
.el-breadcrumb{
  padding: 10px;
}

.gap3{padding-right: 24px;}

.map_layer{
  //border: 1px dashed rgba(6,77,41,.5);
  height: calc(100% - 104px);
  background-color: #fff;
  position: relative;
  .leaflet-container{
    z-index: 0;
    width: 100%;
    height: 100%;
  }
}
.leaflet-div-icon{
  border-radius: 14px;
  transform: scale(1.3);
  background:rgba(255,204,0,.5);
  border:1px dashed rgb(255, 153, 0);
}


.no-map{
  position: absolute;
  left: 0;
  top:0;
  width: 100%;
  height: 100%;
  z-index: 600;
}
.no-map-data{
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 10;
  background-color:rgba(40,53,77,.2);
  display: flex;
  align-items: center;
  text-align: center;
  justify-content: center;
  p{
    font-size: 16px;
    line-height: 2;
  }
}
.leaflet-image-layer{z-index: 0!important;}
.select-tag{width: 100%;}
.select-tag-drop-layer{
  // width: 35%;
  .el-select-dropdown__list{padding: 6px;}
  .el-select-dropdown__item{
    display: inline-block;padding-right: 40px;
    border: 1px solid #fff;

  }
  .el-select-dropdown__item:hover,
  .el-select-dropdown__item.hover{
    background: transparent;
    border: 1px dashed #ccc;
    border-radius: 5px;
  }

}
.hidden{
  visibility:hidden;
}

</style>
