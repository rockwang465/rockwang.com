<template>
  <div>
    <!--添加弹框-->
    <!--添加分组-->
    <el-dialog
      :title="dataObj.type == 'addLevel'?$t('devicemanagement.listPeerGroupCreate'):$t('devicemanagement.listSubGroupCreate')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <div class="content">
        <!--分组类型-->
        <span class="left-name">{{$t('imagemanagement.contGroupType')}}</span>
        <span class="right-name">
          <el-select v-model="type" @change="selectGroup" size="small" class="el-list">
              <el-option
                v-for="item in options"
                :key="item.id"
                :label="item.label"
                :value="item.value">
              </el-option>
          </el-select>
        </span>
        <!--分组名称-->
        <span class="left-name"><span style="color: #BE0000;margin-left: -10px;">* </span>{{$t('usermanagement.contGroupName')}}</span>
        <span id="red" class="right-name"><el-input
          @input="inputName"
          ref="red" v-model="valueData" size="small" maxlength="40"></el-input></span>
        <span class="left-name2"></span>
        <span class="right-name2">
          <!--请输入分组名称-->
          <div class="tips"><span v-show="isShow" style="color: #BE0000">{{$t('form.texterrEnterGroupName')}}</span></div>
        </span>
        <!-- frontend compare -->
        <!--<div class="frontend-compare" >  &lt;!&ndash; 暂时屏蔽前端比对 &ndash;&gt;-->
          <!--<div class="frontend-compare-name" >{{$t('imagemanagement.labelFrontend')}}</div>-->
          <!--<div>-->
            <!--<el-switch-->
              <!--v-model="frontend"-->
              <!--active-value="0"-->
              <!--inactive-value="1"-->
              <!--active-color="#13ce66"-->
              <!--inactive-color="#ff4949">-->
            <!--</el-switch>-->
          <!--</div>-->
        <!--</div>-->
        <!--<div class="frontend-compare tips">-->
          <!--&lt;!&ndash;前端比对人像库不做特征提取&ndash;&gt;-->
          <!--{{$t('imagemanagement.groupAddTips')}}-->
        <!--</div>-->
        <!-- <div style="font-size:12px;color:#909191;padding:0 62px;width:100%;">{{$t('imagemanagement.contTextOnlyFront')}}</div> --> <!-- 暂时屏蔽前端比对 -->
      </div>
      <!--请输入分组名称-->
      <!--<div class="tips"><span v-show="isShow" style="color: #BE0000">{{$t('form.texterrEnterGroupName')}}</span></div>-->


      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleGroupAction">{{$t('imagemanagement.buttonOK')}}</el-button>
      <el-button type="info" class="cancel" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--添加弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {AppModule} from '@/store/modules/app';

  @Component({
    computed:{
      options:function () {
        let that = this as any;
        return [{
          id:1,
          value: 1,
          label: that.$t('imagemanagement.contWhiltelist')
        },{
          id:2,
          value: 2,
          label: that.$t('imagemanagement.contBlacklist')
        }];
      }
    }
  })
  export default class groupAdd extends Vue {
    get language() {
      return AppModule.language;
    }
    //编辑的表单里的值
    dialogShowVisible = false;
    isShow = false;
    valueData = "";
    type = 1;
    frontend:string='1';
    // options = [{
    //   id:1,
    //   value: 1,
    //   label: '白名单'
    // },{
    //   id:2,
    //   value: 2,
    //   label: '黑名单'
    // }];
    @Prop(Object) dataObj!: any;
    @Prop(Array) treeData!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    //确定按钮
    handleGroupAction() {
      if (this.valueData == ''){
        let inp = document.querySelector("#red .el-input input") as any;
        inp.style.borderColor='#BE0000';
        this.isShow = true
        return
      }
      let inp = document.querySelector("#red .el-input input") as any;
      inp.style.borderColor='#c0c4cc';
      this.isShow = false
      this.$emit("handleGroupAction", this.dataObj, this.valueData,this.type,this.frontend)
      this.dialogShowVisible = false;
    }
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.valueData = '';
      if (this.dataObj.localData.children ||this.dataObj.localData.children == null ){
        this.type = this.dataObj.localData.id
      }
      if (this.dataObj.localData.libraryType == 1){
        this.type = 1
      }
      if (this.dataObj.localData.libraryType == 2){
        this.type = 2
      }
      this.isShow = false;

    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeAdd");
        let inp = document.querySelector("#red .el-input input") as any;
        inp.style.borderColor='#c0c4cc';
      }
      val && (this.frontend = '1');
    }
    selectGroup(val){
      this.type = val;
    }

    //输入验证
    inputName(val){
      if(this.verifySize2(val)){
        this.valueData = val
      }else{
        this.valueData = '';
      }

    }
    //输入验证
    verifySize2(val){
      // let reg = /^\d*$/
      let reg = /^\S+/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  .tips{
    height: 16px;
    line-height: 16px;
    font-size: 12px;
    font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB, Microsoft YaHei, Arial, sans-serif;
    margin: 2px 0;
    text-align: left;
  }
  .content{
    width: 80%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  .content>span{
    width: 50%;
    line-height: 25px;
    margin-top: 10px;
  }
  .content .left-name{
    padding-left: 15%;
    width: 40%;
    font-weight: bolder;
  }
  .content .right-name{
    width: 60%;
  }
  .el-select{
    width: 100%;
  }

  .el-list ::v-deep .el-input__suffix{
    right: 10px !important;
    top: 3px !important;
  }
  .right-name ::v-deep .el-input{
    width: 75%;
  }
  .upFile{
    color: #2a5af5;
  }
  .left-name{
    font-size: 14px;
    font-weight: normal;
    font-stretch: normal;
    line-height: 16px;
    letter-spacing: 0px;
    color: #28354d;
  }
  .red-border{
    border-color: red;
  }

  .content .left-name2{
    width: 40%;
    margin: 0;
    line-height: 0;
  }
  .content .right-name2{
    width: 60%;
    margin: 0;
    line-height: 0;
  }
  .content{

    .frontend-compare{
      display: flex;
      justify-content: space-between;
      width: 100%;
      padding:0 62px;
      .frontend-compare-name{
        font-weight: 900;
      }
    }
  }

</style>
