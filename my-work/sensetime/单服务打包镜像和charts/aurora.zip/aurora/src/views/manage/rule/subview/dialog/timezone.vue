<template>
<el-dialog
  :visible.sync="visible"
  width="98%"
  custom-class="timezone-dialog-container"
  :before-close="handleClose">
  <div class="timezone-container" style="width:100%;">
    <div class="timezone-left" ref="timezoneLeft" >
      <div class="timezone-left-popper" v-show="showTimezoneLeftPopper && ($permission('011203') || $permission('011402'))" @mouseenter="mouseenterPopper" @mouseleave="mouseleavePopper" :style="{left:timezoneLeftPopperLeft+'px',top:timezoneLeftPopperTop+'px'}" >
         <div v-if="$permission('011203')"><span @click="hoverRename" > <i class="iconfont icon-edit" ></i> {{$t('rule.listRename')}}</span></div>
         <div v-if="$permission('011402')"><span @click="hoverDelete"> <i class="iconfont icon-delete" ></i> {{$t('rule.buttonDelete')}}</span></div>
      </div>
      <!-- 假期定义 -->
      <header class="timezone-header-title" >{{$t('rule.labelHoliday')}}</header>
      <el-table
      :data="holidayTableData"
      class="timezone-table"
      height="290"
      @cell-mouse-enter="tableRowMouseEnter"
      @cell-mouse-leave="tableRowMouseLeave"
      header-cell-class-name="timezone-table-header"
      stripe>
        <el-table-column
          prop="holidayNo"
          :label="$t('rule.labelNumber')"
          width="60">
        </el-table-column>
        <el-table-column
          class-name="timezone-name-table-column"
          prop="holidayName"
          :label="$t('rule.labelHolidayName')"
          width="">
           <template slot-scope="{row, column, $index}">
            <div>
              <el-button v-if="!row.holidayName" @click="addHoliday(row,column,$index)" type="text" >{{$t('rule.contHolidayDefine')}}</el-button>
              <span v-else @click="addHoliday(row,column,$index)" >{{row.holidayName}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="holidayDate"
          :label="$t('rule.labelHolidayDate')">
          <template slot-scope="{row, column, $index}">
            <div>
              <el-button v-if="!row.holidayDate" @click="addHolidayDate(row,column,$index)" type="text" >{{$t('rule.contDateDefine')}}</el-button>
              <span v-else @click="addHolidayDate(row,column,$index)" >{{row.holidayDate[0]+' - '+row.holidayDate[1]}}</span>
              <div style="width:0;height:0;overflow:hidden;display:inline-block;position: relative;top: -30px;" >
                <el-date-picker
                  @change="(date)=>holidayDateChange(row,column,$index,date)"
                  value-format="yyyy-MM-dd"
                  :ref= "'addHolidayDate'+$index"
                  v-model="row.holidayDate"
                  type="daterange"
                  range-separator="-"
                  start-placeholder="start"
                  end-placeholder="end">
                </el-date-picker>
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <!-- 特殊工作日定义 -->
      <header class="timezone-header-title" >{{$t('rule.labelWorkday')}}</header>
      <el-table
      :data="workdayTableData"
      class="timezone-table"
      height="290"
      @cell-mouse-enter="tableRowMouseEnter"
      @cell-mouse-leave="tableRowMouseLeave"
      header-cell-class-name="timezone-table-header"
      stripe>
        <el-table-column
          prop="workdayNo"
          :label="$t('rule.labelNumber')"
          width="60">
        </el-table-column>
        <el-table-column
          class-name="timezone-name-table-column"
          prop="workdayName"
          :label="$t('rule.labelWorkdayName')"
          width="">
          <template slot-scope="{row, column, $index }" >
            <div>
              <el-button v-if="!row.workdayName" type="text" @click="addWorkday(row,column,$index)" >{{$t('rule.contWorkdayDefine')}}</el-button>
              <span v-else @click="addWorkday(row,column,$index)" >{{row.workdayName}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="workdayDate"
          :label="$t('rule.labelWorkdayDate')">
          <template slot-scope="{row, column, $index}">
            <div>
              <el-button v-if="!row.workdayDate" @click="addWorkdayDate(row,column,$index)" type="text" >{{$t('rule.contDateDefine')}}</el-button>
              <span v-else @click="addWorkdayDate(row,column,$index)" >{{row.workdayDate[0]+' - '+row.workdayDate[1]}}</span>
              <div style="width:0;height:0;overflow:hidden;display:inline-block;position: relative;top: -30px;" >
                <el-date-picker
                  @change="(date)=>workdayDateChange(row,column,$index,date)"
                  value-format="yyyy-MM-dd"
                  :ref= "'addWorkdayDate'+$index"
                  v-model="row.workdayDate"
                  type="daterange"
                  range-separator="-"
                  start-placeholder="start"
                  end-placeholder="end">
                </el-date-picker>
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 时间条件列表 -->
    <div class="timezone-right" >
      <header class="timezone-header-title" >{{$t('rule.labelTimezoneList')}}</header>
      <el-row>
        <el-col class="timezone-header" :style="{width:timezoneWidth.name+'%'}" >
          <span :title="$t('rule.labelTimezoneName')"> {{$t('rule.labelTimezoneName')}} <i v-if="$permission('011310')" class="el-icon-plus timezone-add-icon" @click="addTimezoneName" ></i> </span>
        </el-col>
        <el-col class="timezone-header" :style="{width:timezoneWidth.period+'%'}">
          <span :title="$t('rule.labelInterval')"> {{$t('rule.labelInterval')}} <i v-if="$permission('011306')" class="el-icon-plus timezone-add-icon" @click="addTimezoneInterval" ></i> </span>
        </el-col>
        <el-col class="timezone-header" :style="{width:timezoneWidth.week+'%'}">
          <span :title="$t('rule.labelWeekdayTick')" > {{$t('rule.labelWeekdayTick')}}  </span>
        </el-col>
        <el-col class="timezone-header" :style="{width:timezoneWidth.holiday+'%'}">
          <span :title="$t('rule.labelHolidayTick')"> {{$t('rule.labelHolidayTick')}}  </span>
        </el-col>
        <el-col class="timezone-header" :style="{width:timezoneWidth.work+'%'}">
          <span :title="$t('rule.labelWorkdayTick')"> {{$t('rule.labelWorkdayTick')}}  </span>
        </el-col>
      </el-row>
      <el-row class="timezone-timezone-content" >
        <el-tabs v-model="activeTimezone" @tab-click="handleTabClick" tab-position="left" >

          <el-tab-pane v-for="(timezone,timezoneIndex) in timezoneList" :key="timezoneIndex+'timezoneIndex'" :label="timezone.timeZoneName" :name="timezone.timeZoneId+''">
            <div slot="label" class="timezone-timezonename-header" :title="timezone.timeZoneName" >
              <el-popover
                :disabled="!$permission('011211') && !$permission('011412')"
                placement="right-start"
                width="100"
                trigger="hover"
                :content="timezone.timeZoneName">
                <el-button class="timezone-timezonename-header-btn" slot="reference" type="text"> {{timezone.timeZoneName}}</el-button>
                <div class="timezone-popover" >
                  <p v-if="$permission('011211')"><span @click="(e)=>renameTimezone(timezone)"><i class="iconfont icon-edit" ></i> {{$t('rule.listRename')}}</span></p>
                  <p v-if="$permission('011412')"><span @click="(e)=>deleteTimezone(timezone)"><i class="iconfont icon-delete" ></i> {{$t('rule.listDelete')}}</span></p>
                </div>
              </el-popover>
            </div>

            <el-row v-for="(interval,IntervalIndex) in intervalList" :key="IntervalIndex+'IntervalIndex'" class="timezone-timezonename-content" >
              <el-col :style="{width:getContentWidthPersent('period')}" class="timezone-timezonename-content-col" >
                <div class="timezone-timezonename-content-col-content" >
                  <el-popover
                    :disabled="!$permission('011407')"
                    placement="right-start"
                    width="120"
                    trigger="hover">
                    <span slot="reference" type="text">
                      <TextTimepicker
                        :disabled="!$permission('011208')"
                        is-range
                        @changetime="(data)=>intervalTimesChange(data,interval)"
                        value-format="HH:mm"
                        format="HH:mm"
                        :timesValue="interval.times"
                        range-separator="-"
                        start-placeholder="start"
                        end-placeholder="end"
                        placeholder="" />
                    </span>
                    <div class="timezone-popover" >
                      <p><span @click="(e)=>deleteTimezoneInerval(interval,timezone)"><i class="iconfont icon-delete" ></i> {{$t('rule.listDelete')}}</span></p>
                    </div>
                  </el-popover>
                  </div>
                  <!-- <div class="timezone-disable-permission" v-if="!$permission('011208')" ></div> -->
              </el-col>
              <el-col :style="{width:getContentWidthPersent('week')}" class="timezone-timezonename-content-col" >
                <div class="timezone-timezonename-content-col-content" >
                  <el-checkbox-group v-model="interval.weekCheckList" @change="(v)=>checkListChange('weekday',v,interval)" >
                    <el-checkbox-button v-for="(week,weekIndex) in weekday" :label="week.id" :key="weekIndex" :value="week.id" >{{week.name}}</el-checkbox-button>
                  </el-checkbox-group>
                </div>
                <div class="timezone-disable-permission" v-if="!$permission('011208')" ></div>
              </el-col>
              <el-col :style="{width:getContentWidthPersent('holiday')}" class="timezone-timezonename-content-col" >
                <div class="timezone-timezonename-content-col-content" >
                  <el-checkbox-group v-model="interval.holidayCheckList" @change="(v)=>checkListChange('holiday',v,interval)">
                    <el-checkbox :label="holiday.holidayId" v-for="(holiday,holidayIndex) in interval.holidayList" :key="holidayIndex" :disabled="!holiday.holidayId" >{{holiday.holidayNo}}</el-checkbox>
                  </el-checkbox-group>
                </div>
                <div class="timezone-disable-permission" v-if="!$permission('011208')" ></div>
              </el-col>
              <el-col :style="{width:getContentWidthPersent('work')}" class="timezone-timezonename-content-col" >
                <div class="timezone-timezonename-content-col-content" >
                  <el-checkbox-group v-model="interval.workdayCheckList" @change="(v)=>checkListChange('workday',v,interval)">
                    <el-checkbox :label="work.workdayId" v-for="(work,workIndex) in interval.workdayList" :key="workIndex" :disabled="!work.workdayId" >{{work.workdayNo}}</el-checkbox>
                  </el-checkbox-group>
                </div>
                <div class="timezone-disable-permission" v-if="!$permission('011208')" ></div>
              </el-col>
            </el-row>
          </el-tab-pane>
        </el-tabs>
      </el-row>
      <!-- <div class="timezone-timezone-footer" >
        <el-button @click="hide" type="primary" >{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="hide" type="info">{{$t('rule.buttonCancel')}}</el-button>
      </div> -->
    </div>

  </div>
  <!-- title -->
  <span slot="title" class="timezone-title" > <i class="iconfont icon-time-set" ></i> {{$t('rule.buttonTimezoneSetting')}}</span>
  <!-- messageBox -->
  <el-dialog
    :append-to-body="true"
    class="timezone-rename-dialog"
    :visible="showRenameDialog"
    :before-close="()=>this.showRenameDialog = false"
    width="400px">
    <el-form ref="formname" :model="form" :rules="rules" label-width="120px">
      <el-form-item :label="renameText.label" prop="name">
        <el-input v-model="form.name"></el-input>
      </el-form-item>
    </el-form>
    <div slot="title" class="timezone-rename-dialog-header" >
      <span>{{renameText.title}}</span>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="()=>ensureEdit(renameCurrentData)">{{$t('rule.buttonOK')}}</el-button>
      <el-button @click="showRenameDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>
  <!-- messageBox delete -->
  <el-dialog
    :append-to-body="true"
    class="timezone-delete-dialog"
    :visible="showDeleteDialog"
    :before-close="()=>this.showDeleteDialog = false"
    width="400px">
    <p>{{deleteText}}</p>
    <div slot="title" class="timezone-rename-dialog-header" >
      <span>{{$t('rule.listDelete')}}</span>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button type="danger" @click="()=>ensureDelete(deleteText)">{{$t('rule.buttonOperationDelete')}}</el-button>
      <el-button @click="showDeleteDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>

</el-dialog>

</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import {cloneDeep} from 'lodash';
import {getHolidayList,addHoliday,addWorkday,editHoliday,deleteDay,
        getTimezone,editTimezone,
        getTimezoneIntervals,addTimezone,
        deleteTimezone,deleteTimezoneIntervals,addTimezoneIntervals,editTimezoneIntervals} from '@/api/rule';
import { setTimeout, clearTimeout } from 'timers';
import dayjs from 'dayjs';
import TextTimepicker from '@/components/text-timepicker/index.vue';
import {trim} from 'lodash';


@Component({
  components: {
    TextTimepicker
  },
})
export default class Timezone extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;

  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.fetchGetHolidayOrWorkdatList(0);
    n && this.fetchGetHolidayOrWorkdatList(1);
    n && this.getTimezoneList();
  };
  @Watch('intervalList', { immediate: true, deep: true })
  onIntervalListChange(n,o){
    n.length>0 && n.map(interval=>{
      let isHas:boolean = this.submitIntervalList.some(item => {
        return item.intervalId == interval.intervalId;
      });
      !isHas && this.submitIntervalList.push(interval);

    });
  }
  /* data */
  $refs!:{
    timezoneLeft:HTMLFormElement,
    formname:HTMLFormElement,
    intervalTimePickerText:HTMLFormElement
  };
  holidayTableData:any[] = this.getEmptyHolidayTableData('holiday');//假期列表
  workdayTableData:any[]=this.getEmptyHolidayTableData('workday');//特殊工作日列表



  activeTimezone:string="0";

  timezoneWidth={//100 即为width:100%
    name:15,
    period:9,
    week:24,
    holiday:26,
    work:26
  };

  timezoneList:any[]=[];
  intervalList:any[]=[];

  weekday:any[]=[
    {id:1,name:'Mon'},
    {id:2,name:'Tue'},
    {id:3,name:'Wed'},
    {id:4,name:'Thur'},
    {id:5,name:'Fri'},
    {id:6,name:'Sat'},
    {id:7,name:'Sun'}
  ];

  showTimezoneLeftPopper:boolean = false;
  timezoneLeftPopperLeft:number = 0;
  timezoneLeftPopperTop:number = 0;
  timer :any;
  currentHoverRow:any;
  currentTabTimezone:any;
  submitIntervalList:any[]=[];
  //rename dialog
  showRenameDialog:boolean=false;
  renameDialogModel:string="";//addholiday editholiday addworkday editworkday addtimezone edittimezone
  renameText={label:'',title:'',content:''};
  form:{name:string}={name:''};
  validateName=(rule, value, callback) => {
    let str = value;
    if (str === '') {
      callback(new Error(this.renameText.label));
    } else {
      //去除两头空格:
      let regx = /^\s+|\s+$/g;
      while (regx.test(str)) {
        str=trim(str);
      };
      str=trim(str);
      str?callback():callback(new Error(this.renameText.label));
    }
  };
  rules={
    name:[
      { required:true,validator: this.validateName, trigger: 'blur' },
      // { min: 1, max: 40, message: '长度在 1 到 40 个字符', trigger: 'blur' }
    ],
  };
  renameCurrentData:any=null;

  //delete dialog
  showDeleteDialog:boolean=false;
  deleteText:string='';
  currentDeleteType:string='';
  currentDeleteId:any='';
  currentDeleteTimezoneId:any='';
  /* methods */
  mounted() {

  }
  initRenameData(){
    this.showRenameDialog = false;
    this.renameDialogModel = '';
    this.renameText.label = '';
    this.renameText.title = '';
    this.renameText.content = '';
    this.form.name = '';
  }
  setRenameData(renameDialogModel,contentText?){
    this.renameText.content = contentText?contentText:'';
    this.form.name = this.renameText.content;
    this.renameDialogModel = renameDialogModel;
    this.$refs.formname && this.$refs.formname.clearValidate();
    switch (renameDialogModel) {
      case 'addholiday':
        this.renameText.label = this.$tc('rule.contHolidayName');
        this.renameText.title = this.$tc('rule.titleAddHoliday');
        Vue.set(this.renameText,'label',this.$tc('rule.contHolidayName'));
        Vue.set(this.renameText,'title',this.$tc('rule.titleAddHoliday'));
        break;
      case 'editholiday':
        this.renameText.label = this.$tc('rule.contHolidayName');
        this.renameText.title = this.$tc('rule.titleHolidayEdit');
        Vue.set(this.renameText,'label',this.$tc('rule.contHolidayName'));
        Vue.set(this.renameText,'title',this.$tc('rule.titleHolidayEdit'));
        break;
      case 'addworkday':
        this.renameText.label = this.$tc('rule.contWorkdayName');
        this.renameText.title = this.$tc('rule.titleAddWorkday');
        Vue.set(this.renameText,'label',this.$tc('rule.contWorkdayName'));
        Vue.set(this.renameText,'title',this.$tc('rule.titleAddWorkday'));
        break;
      case 'editworkday':
        this.renameText.label = this.$tc('rule.contWorkdayName');
        this.renameText.title = this.$tc('rule.titleWorkdayEdit');
        Vue.set(this.renameText,'label',this.$tc('rule.contWorkdayName'));
        Vue.set(this.renameText,'title',this.$tc('rule.titleWorkdayEdit'));
        break;
      case 'addtimezone':
        this.renameText.label = this.$tc('rule.contTimezoneName');
        this.renameText.title = this.$tc('rule.titleTimezoneAdd');
        Vue.set(this.renameText,'label',this.$tc('rule.contTimezoneName'));
        Vue.set(this.renameText,'title',this.$tc('rule.titleTimezoneAdd'));
        break;
      case 'edittimezone':
        this.renameText.label = this.$tc('rule.contTimezoneName');
        this.renameText.title = this.$tc('rule.titleTimezoneRename');
        Vue.set(this.renameText,'label',this.$tc('rule.contTimezoneName'));
        Vue.set(this.renameText,'title',this.$tc('rule.titleTimezoneRename'));
        break;

      default:
        this.renameText.label = '';
        this.renameText.title = '';
        Vue.set(this.renameText,'label','');
        Vue.set(this.renameText,'title','');
        break;
    }
  }
  ensureEdit(data){
    this.$refs.formname.validate((valid)=>{
      if(valid){
        switch (this.renameDialogModel) {
          case 'addholiday':{
            let row = this.renameCurrentData.row;
            let $index = this.renameCurrentData.$index;
            row['holidayName'] = this.form.name;
            //name min:1 max:40 get40
            if(trim(row['holidayName']).length>40){
              row['holidayName'] = trim(row['holidayName']).substr(0,40);
            };
            Vue.set(this.holidayTableData,$index,cloneDeep(row));
            if(row.id == undefined && row.holidayName && row.holidayDate){//新增 holiday
              this.fetchAddHoliday(row.holidayName,row.holidayDate.toString(),$index+1)
            }
          }
            break;
          case 'editholiday':{
            let row = this.renameCurrentData.row;
            let $index = this.renameCurrentData.$index;
            row['holidayName'] = this.form.name;
            //name min:1 max:40 get40
            if(trim(row['holidayName']).length>40){
              row['holidayName'] = trim(row['holidayName']).substr(0,40);
            };
            Vue.set(this.holidayTableData,$index,cloneDeep(row));
            if(row.id != undefined){//编辑名称
              this.fetchEditHoliday({holidayName:row.holidayName},row.id);
            }
          }
            break;
          case 'addworkday':{
            let row = this.renameCurrentData.row;
            let $index = this.renameCurrentData.$index;
            row['workdayName'] = this.form.name;
            //name min:1 max:40 get40
            if(trim(row['workdayName']).length>40){
              row['workdayName'] = trim(row['workdayName']).substr(0,40);
            };
            Vue.set(this.workdayTableData,$index,cloneDeep(row));
            if(row.id == undefined && row.workdayName && row.workdayDate){//新增 workday
              this.fetchAddWorkday(row.workdayName,row.workdayDate.toString(),$index+1)
            }
          }
            break;
          case 'editworkday':{
            let row = this.renameCurrentData.row;
            let $index = this.renameCurrentData.$index;
            row['workdayName'] = this.form.name;
            //name min:1 max:40 get40
            if(trim(row['workdayName']).length>40){
              row['workdayName'] = trim(row['workdayName']).substr(0,40);
            };
            Vue.set(this.workdayTableData,$index,cloneDeep(row));
            if(row.id != undefined){//编辑名称
              this.fetchEditWorkday({holidayName:row.workdayName},row.id);
            }
          }
            break;
          case 'addtimezone':
            //name min:1 max:40 get40
            if(this.form.name && trim(this.form.name).length>40){
              this.form.name = this.form.name.substr(0,40);
            };
            this.form.name && addTimezone(this.form.name).then(res=>{
              //刷新列表
              this.getTimezoneList();
            });
            break;
          case 'edittimezone':{
            let timezone = this.renameCurrentData.timezone;
            let name = this.form.name;
            //name min:1 max:40 get40
            if(trim(name).length>40){
              name = trim(name).substr(0,40);
            };
            name && editTimezone({timeZoneName:name},timezone.timeZoneId).then(res=>{
              //刷新列表
              this.getTimezoneList();
            });
          }
            break;

          default:

            break;
        };
        this.initRenameData();
      }
    })


  }
  initDayTableData(){
    this.holidayTableData= this.getEmptyHolidayTableData('holiday');//假期列表
    this.workdayTableData=this.getEmptyHolidayTableData('workday');//特殊工作日列表
  }
  initDayTableDataSet(type:number){
    if(type === 0){
      this.holidayTableData= this.getEmptyHolidayTableData('holiday');//假期列表
      this.holidayTableData.map((item,index)=>{
        Vue.set(this.holidayTableData,index,item)
      });
    }else if(type === 1){
      this.workdayTableData=this.getEmptyHolidayTableData('workday');//特殊工作日列表
      this.workdayTableData.map((item,index)=>{
        Vue.set(this.workdayTableData,index,item)
      })
    }else{
      this.holidayTableData= this.getEmptyHolidayTableData('holiday');//假期列表
      this.workdayTableData=this.getEmptyHolidayTableData('workday');//特殊工作日列表
      this.holidayTableData.map((item,index)=>{
        Vue.set(this.holidayTableData,index,item)
      });
      this.workdayTableData.map((item,index)=>{
        Vue.set(this.workdayTableData,index,item)
      });
    }

  }
  handleClose(){
    this.hide();
  }
  hide(){
    this.$emit('hideTimezoneDialog');
  }
  handleTabClick(tab, event){
    this.currentTabTimezone = tab;
    this.getIntervalList(tab.name);
  }
  getContentWidthPersent(name:string){
    return (this.timezoneWidth[name]/(100-this.timezoneWidth.name))*100+'%';
  }
  checkListChange(type,checkedVal,interval){
    let timeZoneId = this.currentTabTimezone.name;
    let intervalId = interval.intervalId;
    let data = this.formatSubmitIntervalData(type,checkedVal);
    data['timeZoneId'] = timeZoneId;
    data['intervalId'] = intervalId;
    editTimezoneIntervals(data).then((res:any)=>{
      // this.$message({
      //   message: '修改Interval成功',
      //   type: 'success'
      // });
      this.getIntervalList(timeZoneId);
    })
  }
  formatSubmitIntervalData(type,checkedVal){
    let data :any;
    switch (type) {
      case 'weekday':
        data = {days:this.formatWeekday(checkedVal)};
        break;
      case 'holiday':
        data = {tzHtype:this.formatCheckedVal(checkedVal)};
        break;
      case 'workday':
        data = {tzWtype:this.formatCheckedVal(checkedVal)};
        break;
      default:
        data = {};
        break;
    };
    return data;
  }
  formatWeekday(weekIds:any[]){
    let str = '0,0,0,0,0,0,0',str_arr = str.split(',');
    weekIds.map(item=>{
      str_arr[(item - 1)] = '1';
    });
    return str_arr.join('');
  }
  formatCheckedVal(v:any[]){
    let arr:any[]=[];
    v && v.length>0 && v.map(item=>{
      item && arr.push(item)
    });
    return arr.toString();
  }
  ensure(){

  }
  getEmptyHolidayTableData(type){
    let arr_ :any[]=[];
    for(let i=0;i<10;i++){
      let index_str = ''+(i+1);
      if(index_str.length<2 ){index_str = '0'+index_str};
      if(type === 'holiday'){
        index_str = 'H'+index_str;
        arr_.push({ holidayNo : index_str,type:'h'});
      }
      if(type === 'workday'){
        index_str = 'W'+index_str;
        arr_.push({ workdayNo : index_str,type:'w'});
      }
    };
    return arr_;
  }
  addHoliday(row,column?,$index?){
    if(row.id != undefined){//编辑
      if(this.$permission('011203')){
        this.showRenameDialog = true;
        this.setRenameData('editholiday',row.holidayName);
        this.renameCurrentData = {row,column,$index};
      }
    }else{//新增
      if(this.$permission('011301')){
        this.showRenameDialog = true;
        this.setRenameData('addholiday');
        this.renameCurrentData = {row,column,$index};
      }
    }

  }
  addHolidayDate(row,column,$index){
    let ref = 'addHolidayDate'+$index;
    this.$refs[ref].focus();
  }
  addWorkday(row,column?,$index?){
    if(row.id != undefined){//编辑
      this.showRenameDialog = true;
      this.setRenameData('editworkday',row.workdayName);
      this.renameCurrentData = {row,column,$index};
    }else{//新增
      this.showRenameDialog = true;
      this.setRenameData('addworkday');
      this.renameCurrentData = {row,column,$index};
    }
  }
  addWorkdayDate(row,column,$index){
    let ref = 'addWorkdayDate'+$index;
    this.$refs[ref].focus();
  }
  addTimezoneName(){
    this.showRenameDialog = true;
    this.setRenameData('addtimezone');
    this.renameCurrentData = null;
  }
  addTimezoneInterval(){
    let startTime = '00:00',endTime = '23:59',timeZoneId = this.currentTabTimezone?this.currentTabTimezone.name:'',days='1111111';//新增默认interval
    if(!timeZoneId){
      this.$message.error(this.$tc('form.texterrSelectTimezone') as string);
      return false;
    }
    timeZoneId && addTimezoneIntervals({startTime,endTime,timeZoneId,days}).then(res=>{
      this.getIntervalList(timeZoneId)
    });
  }
  tableRowMouseEnter(row, column, cell, event){
    if(!row.id){
      return false;
    }
    this.showTimezoneLeftPopper = true;
    this.currentHoverRow = row;
    let box_client_x = this.$refs.timezoneLeft.getBoundingClientRect().left,
      box_client_y = this.$refs.timezoneLeft.getBoundingClientRect().top,
      target_w = event.target.offsetWidth,
      target_h = event.target.offsetHeight;
    this.timezoneLeftPopperLeft = event.target.getBoundingClientRect().left - box_client_x + target_w - 10;
    this.timezoneLeftPopperTop = event.target.getBoundingClientRect().top - box_client_y + target_h - 20;
  }
  tableRowMouseLeave(row, column, cell, event){
    this.showTimezoneLeftPopper = false;
  }
  mouseenterPopper(){
    this.showTimezoneLeftPopper = true;
  }
  mouseleavePopper(){
    this.showTimezoneLeftPopper = false;
  }
  fetchGetHolidayOrWorkdatList(type:number=0){
    this.initDayTableDataSet(type);//初始化
    getHolidayList(type).then(res =>{//0 holiday，1 workday
      if(res.data && res.data.length>0){
        res.data.map((item,itemIndex)=>{
          let order:number = item.order;//order 正常>0,未设置order则为0；
          let day = this.formatData(item,itemIndex,type,order);
          type == 0 && Vue.set(this.holidayTableData,order>0?(order-1):itemIndex,day);
          type == 1 && Vue.set(this.workdayTableData,order>0?(order-1):itemIndex,day);
        })
      }
    })
  }
  formatData(resData,index,type,order){
    let data = {},index_str = ''+ (order>0?order:(index+1));
    if(index_str.length<2 ){index_str = '0'+index_str};
    index_str = (type == 0?'H':'W') + index_str;
    let startDate = '',endDate = '';
    if(resData.hdate){
      startDate = resData.hdate.split(',')[0];
      endDate = resData.hdate.split(',')[1] || '';
    };
    if(type == 0){
      data['type'] = 'h';
      data['holidayNo'] = index_str;
      data['id'] = resData.holidayId;
      data['holidayName'] = resData.holidayName;
      data['holidayDate'] = [startDate,endDate];
    }else if(type == 1){
      data['type'] = 'w';
      data['workdayNo'] = index_str;
      data['id'] = resData.holidayId;
      data['workdayName'] = resData.holidayName;
      data['workdayDate'] = [startDate,endDate];
    };
    return data;
  }
  fetchAddHoliday(holidayName:string,holidayDate:string,order:number){
    addHoliday(holidayName,holidayDate,order).then(res=>{
      // this.$message({
      //   message: '新增Holiday成功',
      //   type: 'success'
      // });
      //刷新
      this.fetchGetHolidayOrWorkdatList(0);
    }).catch(()=>{
      this.fetchGetHolidayOrWorkdatList(0);
    });
  }
  fetchAddWorkday(workayName:string,workayDate:string,order:number){
    addWorkday(workayName,workayDate,order).then(res=>{
      // this.$message({
      //   message: '新增Workday成功',
      //   type: 'success'
      // });
      //刷新
      this.fetchGetHolidayOrWorkdatList(1)
    }).catch(()=>{
      this.fetchGetHolidayOrWorkdatList(1);
    });
  }
  fetchEditHoliday(params,holidayId){
    editHoliday(params,holidayId, 0).then(res=>{
      // this.$message({
      //   message: '修改Holiday成功',
      //   type: 'success'
      // });
      //刷新
      this.fetchGetHolidayOrWorkdatList(0)
    }).catch(()=>{
      this.fetchGetHolidayOrWorkdatList(0);
    });
  }
  fetchEditWorkday(params,workdayId){
    editHoliday(params,workdayId,1).then(res=>{
      // this.$message({
      //   message: '修改Woliday成功',
      //   type: 'success'
      // });
      //刷新
      this.fetchGetHolidayOrWorkdatList(1);
    }).catch(()=>{
      this.fetchGetHolidayOrWorkdatList(1);
    });
  }
  holidayDateChange(row,column,$index,date){
    if(row.id == undefined && row.holidayName && row.holidayDate && this.$permission('011301')){//新增
      this.fetchAddHoliday(row.holidayName,row.holidayDate.toString(),$index+1)
    }
    if(row.id != undefined && this.$permission('011203')){//修改
      this.fetchEditHoliday({hdate:`${date[0]},${date[1]}`},row.id);
    }
  }
  workdayDateChange(row,column,$index,date){
    if(row.id == undefined && row.workdayName && row.workdayDate && this.$permission('011301')){//新增
      this.fetchAddWorkday(row.workdayName,row.workdayDate.toString(),$index+1)
    }
    if(row.id != undefined && this.$permission('011203')){//修改
      this.fetchEditWorkday({hdate:`${date[0]},${date[1]}`},row.id);
    }
  }
  hoverRename(){
    if(this.currentHoverRow.id != undefined ){
      this.currentHoverRow.type === 'h' && this.addHoliday(this.currentHoverRow);
      this.currentHoverRow.type === 'w' && this.addWorkday(this.currentHoverRow);
    }
  }
  hoverDelete(){
    // this.$confirm(this.$tc('rule.popmsgWorkdayDelete'), this.$tc('rule.listDelete'), {
    //   confirmButtonText: this.$tc('rule.buttonDelete'),
    //   cancelButtonText: this.$tc('rule.buttonCancel'),
    // }).then(() => {
    //   if(this.currentHoverRow.id != undefined ){
    //     deleteDay(this.currentHoverRow.id).then(()=>{
    //       // this.$message({
    //       //   message: '删除成功',
    //       //   type: 'success'
    //       // });
    //       //刷新
    //       this.fetchGetHolidayOrWorkdatList(this.currentHoverRow.type === 'h'?0:1);
    //     })
    //   }
    // }).catch(() => {

    // });
    let type:string=this.currentHoverRow.type;
    this.deleteText = type == 'h'?this.$tc('rule.popmsgHolidayDelete'):this.$tc('rule.popmsgWorkdayDelete');
    this.currentDeleteType = type;
    this.showDeleteDialog = true;
  }
  ensureDelete(){
    let type:string=this.currentDeleteType;
    if(type && (type == 'h' || type == 'w' )){
      if(this.currentHoverRow.id != undefined ){
        this.deleteHolidayOrWorkday(this.currentHoverRow.id);
      }
    }else if(type && (type == 't' || type == 'ti' )){
      this.deleteTimezoneOrInterval(type,this.currentDeleteId);
    }

  }
  deleteHolidayOrWorkday(id){
    deleteDay(this.currentHoverRow.id).then(()=>{
      // this.$message({
      //   message: '删除成功',
      //   type: 'success'
      // });
      //刷新
      this.showDeleteDialog = false;
      this.fetchGetHolidayOrWorkdatList(this.currentHoverRow.type === 'h'?0:1);
    }).catch(err=>{
      this.showDeleteDialog = false;
    })
  }
  getTimezoneList(){
    getTimezone().then((res:any)=>{
      this.timezoneList = [];
      setTimeout(()=>{res.data && res.data.length>0 && (this.timezoneList = res.data)},50)
    });
  }
  getIntervalList(timezoneId){
    this.intervalList = [];
    getTimezoneIntervals(timezoneId).then((res:any) =>{
      res && res.data && res.data.length>0 && res.data.map((item,index)=>{
        let ob_ = {
          ...item,
          weekCheckList:this.formatWeekCheckList(item.days|| '0000000'),
          holidayCheckList:this.formatCheckList(item.tzHtype),
          workdayCheckList:this.formatCheckList(item.tzWtype),
          holidayList:this.formatHoliadyListForCheck(item.tzHtypeIdsOrder?item.tzHtypeIdsOrder:item.tzHtypeIds || [],'holiday'),
          workdayList:this.formatHoliadyListForCheck(item.tzWtypeIdsOrdery?item.tzWtypeIdsOrdery:item.tzWtypeIds || [],'workday'),
          // times:item.startTime+','+item.endTime.
          times:[item.startTime,item.endTime]
        };
        this.intervalList.push(ob_);
      });
    });
  }
  formatHoliadyListForCheck(holidayIds:any[],type:string){
    let holidays = this.getEmptyHolidayTableData(type);
    holidayIds && holidayIds.length>0 && holidayIds.map((holid:any,holidIndex)=>{
      if(holid.order != undefined && holid.order>0){
        let index_order = holid.order-1;
        holidays[index_order][type+'Id'] = holid.holidayId;
      }else if(holid.order == 0){
         holidays[holidIndex][type+'Id'] = holid.holidayId;
      }else{
        holidays[holidIndex][type+'Id'] = holid;
      }
    });
    return  holidays;
  }
  formatWeekCheckList(week:string){
    let arr_:any[] = [];
    for(let i = 0;i<week.length;i++){
      let week_item = week.charAt(i);
      if(week_item == '1'){
        arr_.push(i+1)
      }
    }
    return arr_;
  }
  formatCheckList(str){
    let arr:any = [];
    str && str.split(',').map(item=>{
      item && arr.push(parseInt(item));
    });
    return arr;
  }
  renameTimezone(timezone){
    this.showRenameDialog = true;
    this.setRenameData('edittimezone',timezone.timeZoneName);
    this.renameCurrentData = {timezone};
  }
  deleteTimezone(timezone){
    //timezone.status == 1 is default timezine can not delete
    // if(timezone.status == 1){
    //   this.$message.error('默认时间条件不能删除');
    //   return false;
    // }


    // this.$confirm(this.$tc('rule.popmsgTimezoneDelete'), this.$tc('rule.titleDelete'), {
    //   confirmButtonText: this.$tc('rule.buttonDelete'),
    //   cancelButtonText: this.$tc('rule.buttonCancel'),
    // }).then(() => {
    //   if(timezone){
    //     deleteTimezone(timezone.timeZoneId).then(()=>{
    //       // this.$message({
    //       //   message: '删除成功',
    //       //   type: 'success'
    //       // });
    //       //刷新列表
    //       this.getTimezoneList();
    //     })
    //   }
    // }).catch(() => {

    // });

    //delete
    this.currentDeleteType = 't';
    this.currentDeleteId = timezone.timeZoneId;
    this.currentDeleteTimezoneId = timezone.timeZoneId;
    this.showDeleteDialog = true;
    this.deleteText = this.$tc('rule.popmsgTimezoneDelete');
  }
  deleteTimezoneInerval(interval,timezone){
    // this.$confirm(this.$tc('rule.popmsgIntervalDelete'), this.$tc('rule.titleDelete'), {
    //   confirmButtonText: this.$tc('rule.buttonDelete'),
    //   cancelButtonText: this.$tc('rule.buttonCancel'),
    // }).then(() => {
    //   if(interval){
    //     deleteTimezoneIntervals(interval.intervalId).then(()=>{
    //       // this.$message({
    //       //   message: '删除成功',
    //       //   type: 'success'
    //       // });
    //       //刷新列表
    //       this.getIntervalList(timezone.timeZoneId);
    //     })
    //   }
    // }).catch(() => {

    // });
    //delete
    this.currentDeleteType = 'ti';
    this.currentDeleteId = interval.intervalId;
    this.currentDeleteTimezoneId = timezone.timeZoneId;
    this.showDeleteDialog = true;
    this.deleteText = this.$tc('rule.popmsgIntervalDelete');
  }
  deleteTimezoneOrInterval(type,id){
    if(type && id){
      type == 't' && deleteTimezone(id).then(()=>{
        // this.$message({
        //   message: '删除成功',
        //   type: 'success'
        // });
        //刷新列表
        this.showDeleteDialog = false;
        this.getTimezoneList();
        this.currentTabTimezone = null;
      }).catch(err=>{
        this.showDeleteDialog = false;
      });
      type == 'ti' && deleteTimezoneIntervals(id).then(()=>{
          // this.$message({
          //   message: '删除成功',
          //   type: 'success'
          // });
          //刷新列表
          this.showDeleteDialog = false;
          this.getIntervalList(this.currentDeleteTimezoneId);
        }).catch(err=>{
          this.showDeleteDialog = false;
        })
    }
  }
  editIntervalTimes(interval){
    let ref = 'intervalTimes'+interval.intervalId;
    this.$refs[ref][0].focus();

  }
  intervalTimesChange(time,interval){
    let timeZoneId = this.currentTabTimezone.name;
    let intervalId = interval.intervalId;
    let data = {
      startTime:time[0] || '',
      endTime:time[1] || '',
    };
    data['timeZoneId'] = timeZoneId;
    data['intervalId'] = intervalId;
    editTimezoneIntervals(data).then((res:any)=>{
      // this.$message({
      //   message: '修改Interval成功',
      //   type: 'success'
      // });
      this.getIntervalList(timeZoneId);
    })
  }
  handleClickIntervalTimePicker(){
    this.$refs['intervalTimePickerText0'][0] && this.$refs['intervalTimePickerText0'][0].focus();
  }
  formatGetTime(time){
    let times:any = '';
    if(this.isArray(time)){
      times = time[0]+'-'+time[1];
    }
    if(this.isString(time)){
      times = time.split(',')[0]+'-'+time.split(',')[1];
    }
    return times;
  }
  isArray(obj){
    return (typeof obj=='object')&&obj.constructor==Array;
  }
  isString(str){
    return (typeof str=='string')&&str.constructor==String;
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
 ::v-deep .el-dialog .el-dialog__header::after{
    width: 100%;
    left: 0;
  }
::v-deep .el-dialog .el-dialog__body{
    padding: 0;
  }
::v-deep .el-checkbox-button__inner{
    border-left:1px solid #c2cad8;
  }
  .timezone-title{
    font-size: $--font-size-card;
    color: $--color-black;
  }
::v-deep .timezone-dialog-container{
    max-height: 80vh;
    overflow: auto;
  }
::v-deep .el-dialog__body{
    padding-top: 0;
    padding-left: 0;
    padding-bottom: 0;
    .el-checkbox{
      margin-left: 2px;
      .el-checkbox__label{
        margin-left: 0;
      }
    }
    .el-tabs{
      background-color: $--background-color-module;
      height: 100%;
      .el-tabs__header{
        background-color: $--color-white;
        .el-tabs__item.is-active{
          background-color: $--background-color-module;
        }
      }
    }
  }
::v-deep .el-checkbox-button{
    margin-right: 5px;
    .el-checkbox-button__inner{
      padding: 1px;
    }
  }
::v-deep .el-checkbox-group{
    .el-checkbox{
      display: inline-flex;
      flex-direction: column-reverse;
      justify-content: flex-start;
      margin-left: 5px;
      .el-checkbox__label{
        padding-left: 0;
      }
      .el-checkbox__inner{
        position: relative;
        left: 5px;
      }
    }
  }
  .timezone-name-table-column .cell{
    & > div{
      overflow: hidden;
      text-overflow:ellipsis;
      white-space: nowrap;
    }

  }
  .timezone-container{
    display: flex;
    .timezone-table{
      border-top:none;
      ::v-deep .el-table__header{
        border-top: none;
        .timezone-table-header{
          background-color: $--color-primary;
          color: $--color-white;
          .gutter{
            background-color: $--color-primary;
          }
        }
      }
    }
    ::v-deep .timezone-table .has-gutter .gutter{
      background-color: $--color-primary;
      position: relative;
      top: -1px;
    }

    .timezone-left{
      width: 30%;
      background-color: $--color-bg-1;
      padding-left: 16px;
      height: 100%;
      padding-bottom: 30px;
      padding-right: 10px;
      position: relative;
      .timezone-left-popper{
        position: absolute;
        z-index: 10;
        border:1px solid $--border-color-lighter;
        box-shadow:0 2px 12px 0 rgba(0, 0, 0, 0.1);
        background-color: $--color-white;
        width: 90px;
        height: 70px;
        &>div{
          cursor: pointer;
          padding: 5px;
        }
      }
    }
    .timezone-right{
      width: 70%;
      background-color: $--color-white;
      padding-left: 16px;
      padding-bottom: 30px;
      padding-right: 16px;
      ::v-deep .el-tabs {
        .el-tab-pane{
          height: 581px;
          overflow: auto;
        }
        width: 100%;
        .el-tabs__header.is-left{
          margin-right: 0;
          padding: 0;
          width: 15%;
          .el-tabs__item.is-left{
            padding: 0;
          }
        }
      }
      .timezone-header{
        height: 48px;
        line-height: 48px;
        background-color: $--color-primary;
        color: $--color-white;
        font-weight: 500;
        box-sizing: border-box;
        border-right: 1px solid $--color-white;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        span{
          padding-left: 10px;
        }
      }
      .timezone-add-icon{
        cursor: pointer;
      }
      .timezone-timezone-content{
        height: calc(100% - 97px);
        overflow: auto;
        // background-color: $--background-color-module;
      }
      .timezone-timezonename-header{
        text-align: left;
        text-overflow:ellipsis;
        overflow:hidden;
        padding-left: 10px;
      }
      .timezone-timezone-footer{
        text-align: center;
        padding-top: 20px;
      }
      .timezone-timezonename-content{
        border-bottom: 1px solid $--border-color-base;
        .timezone-timezonename-content-col{
          position: relative;
          .timezone-timezonename-content-col-content{
            padding-left: 10px;
            padding-top: 10px;
            line-height: 20px;
          }
          .timezone-disable-permission{
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            position: absolute;
            z-index: 10;
            cursor: not-allowed;
          }
        }
      }
    }
    .timezone-header-title {
      padding: 16px 0;
      font-weight: 600;
      color: $--color-black;
      font-size: $--font-size-card;
    }
  }
  .timezone-popover{
    p{
      line-height: 25px;
      cursor: pointer;
    }
  }
::v-deep .timezone-timezonename-header-btn{
    width:100%;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
    text-align:left;
  }

  ::v-deep .el-tabs__nav.is-left{
    height: 581px;
    overflow-y: auto;
  }

</style>
