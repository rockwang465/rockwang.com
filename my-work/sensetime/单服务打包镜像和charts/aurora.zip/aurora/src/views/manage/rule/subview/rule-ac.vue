<template>
  <div class="rule-ac-container">
    <header v-show="groupModel">
      <el-button type="primary" @click="addRuleAC" v-if="$permission('006301')" > <i class="iconfont icon-add" ></i> {{$t('rule.buttonRuleAdd')}} </el-button>
      <el-button type="info" @click="showTimezone" > <i class="iconfont icon-timezone-set" ></i> {{$t('rule.buttonTimezoneSetting')}} </el-button>
    </header>
    <div class="rule-ac-contents" >
      <transition name="component-fade" mode="out-in">
        <RuleListAC  v-if="!groupModel"  />
        <GruopAC v-else @viewrules="handleViewRules" :addruleSuccess="addRuleSuccess"  />
      </transition>
    </div>

    <!-- add rule ac dialog -->
    <AddRuleAC :visible="showAddRuleACDialog" @hideAddRuleacDialog="()=>{showAddRuleACDialog = false}" @addsuccess="addACruleSuccess" />
      <!-- timezone dialog -->
    <Timezone :visible="showTimezoneDialog" @hideTimezoneDialog="()=>{showTimezoneDialog = false}" />
  </div>
</template>

<script lang="ts">
import { Component, Vue ,Watch} from 'vue-property-decorator';
import GruopAC from './group/group-ac.vue';
import RuleListAC from './list/rule-list-ac.vue';
import AddRuleAC from './dialog/ac/add-rule-ac.vue';
import Timezone from './dialog/timezone.vue';

@Component({
  components: {
    GruopAC,
    RuleListAC,
    AddRuleAC,
    Timezone
  },
})
export default class RuleAC extends Vue {
  /* props */

  /* watch */
  @Watch('$route')
  onRouterChanged(val: any, oldVal: any) {
    this.groupModel = val.hash.indexOf('#rulesac')>=0?false:true;
  }

  /* data */
  groupModel:boolean=location.hash.indexOf('#rulesac')>=0?false:true;// true=group  false=rules
  showAddRuleACDialog:boolean=false;
  showTimezoneDialog:boolean=false;
  addRuleSuccess:boolean = false;

  /* methods */
  mounted() {

  }
  handleViewRules(group){
    this.$router.push(`/manage/rule#rulesac?groupId=${group.groupId}&groupName=${group.groupName}`)
  }
  addRuleAC(){
    this.addRuleSuccess = false;
    this.showAddRuleACDialog = true;
  }
  showTimezone(){
    this.showTimezoneDialog = true;
  }
  addACruleSuccess(data){
    data && (this.addRuleSuccess = true);
  }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .rule-ac-container{
    height: 100%;
    .rule-ac-contents{
      height: calc(100% - 34px);
    }
    .component-fade-enter-active, .component-fade-leave-active {
      transition: opacity .3s ease;
    }
    .component-fade-enter, .component-fade-leave-to{
      opacity: 0;
    }
  }

</style>
