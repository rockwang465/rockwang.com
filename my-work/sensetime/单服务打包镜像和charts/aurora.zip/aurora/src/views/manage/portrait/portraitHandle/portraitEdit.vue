<template>
  <div v-if="dialogShowVisible">
    <!--添加弹框-->
    <el-dialog
      top="10vh"
      class="isroll"
      :title="$t('imagemanagement.buttonEdit')"
      :visible.sync="dialogShowVisible"
      :width="formLabelWidth2">
      <el-form
        :rules="rulesList"
        v-loading="dataLoading"
        label-position="right"
        ref="dataForm" :model="tableInfo">
        <div class="wrap">
          <div class="top"
               @dragover="dragover"
               @drop="dddrop">
            <label for="img-upload-btn2" class="upload">
              <span v-show="showIcon"><i class="iconfont icon-upload-copy"></i></span>
              <img v-show="!showIcon" id="selectedImg2" :src="tableInfo.image" alt="">
            </label>
            <el-form-item prop="image" :label-width="formLabelWidth">
              <input type="file" id="img-upload-btn2"
                     accept="image/*" @change="upImage($event)"/>
            </el-form-item>
          </div>
          <div class="detail">
            <el-form-item :label="$t('imagemanagement.contName')" prop="name" :label-width="formLabelWidth">
              <el-input
                @input="inputName"
                size="small" v-model="tableInfo.name" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <el-form-item :label="$t('imagemanagement.contAlias')" :label-width="formLabelWidth">
              <el-input
                @input="inputName2"
                size="small" v-model.trim="tableInfo.aliasName" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <el-form-item :label="$t('imagemanagement.contID')" prop="ID" :label-width="formLabelWidth">
<!--              <el-input size="small" v-model.trim="tableInfo.ID" autocomplete="off" maxlength="32"></el-input>-->
              <!-- <el-input size="small" v-model.trim="encryptionId" @input="()=>{tableInfo.ID = encryptionId}" @focus="idFocus" @blur="idBlur" autocomplete="off" maxlength="32"></el-input> -->
              <el-input size="small" v-model.trim="tableInfo.ID"  @focus="idFocus" @blur="idBlur" autocomplete="off" maxlength="32"></el-input>
            </el-form-item>
            <!--人像库-->
            <el-form-item :label="$t('imagemanagement.contImageLibrary')" prop="libraryIds" :label-width="formLabelWidth">
              <TreeSelect size="small" :data="tree"
                          @selected="handleSelected"
                          show-checkbox
                          style="width:90%"
                          :dataObj="dataUserIdsObj"/>
              <!--<el-select v-model="tableInfo.libraryId" @change="selectPortrait" size="small" class="el-list">-->
                <!--<el-option-->
                  <!--v-for="item in treeData"-->
                  <!--:key="item.id"-->
                  <!--:label="item.libraryName"-->
                  <!--:value="item.libraryId">-->
                <!--</el-option>-->
              <!--</el-select>-->
            </el-form-item>
          </div>
        </div>
        <el-row class="option">{{$t('imagemanagement.contOtherInfo')}}</el-row>
        <div class="bottom">
          <div class="bline1">
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contGender')" prop="gender" :label-width="formLabelWidth">
              <el-radio-group v-model="tableInfo.gender">
                <el-radio :label="1">{{$t('imagemanagement.contMale')}}</el-radio>
                <el-radio :label="2">{{$t('imagemanagement.contFemale')}}</el-radio>
              </el-radio-group>
              <!--<el-radio v-model="tableInfo.gender" :label="1">男</el-radio>-->
              <!--<el-radio v-model="tableInfo.gender" :label="2">女</el-radio>-->
            </el-form-item>

            <!--年龄-->
            <el-form-item class="age" style="width: 50%;" :label="$t('imagemanagement.contAge')" :label-width="formLabelWidth3">
              <el-input
                @input="inputAgeNum"
                :placeholder="$t('form.texterrAgePolicy')"
                size="small" v-model="tableInfo.age" autocomplete="off" maxlength="3"></el-input>
            </el-form-item>
          </div>
          <div class="bline1">
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contCompany')" :label-width="formLabelWidth">
              <el-input size="small" v-model="tableInfo.company" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contDepartment')" :label-width="formLabelWidth3">
              <el-input size="small" v-model="tableInfo.dept" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
          </div>
          <div class="bline1">
            <!--联系方式-->
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contContact')" :label-width="formLabelWidth">
              <el-input size="small" v-model="tableInfo.phone" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
            <!--车牌号-->
            <el-form-item style="width: 50%;" :label="$t('visitor.visitorlist.labelCarNumber')" :label-width="formLabelWidth3">
              <el-input size="small" v-model="tableInfo.vehiclePlateNumber" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
          </div>
          <div class="lang">
            <!--<el-form-item :style="{width:this.formLabelWidth == '80px'?'95%':'87%'}" :label="$t('imagemanagement.contContact')" :label-width="formLabelWidth">-->
              <!--<el-input size="medium" v-model="tableInfo.phone" autocomplete="off" maxlength="40"></el-input>-->
            <!--</el-form-item>-->
            <el-form-item :style="{width:this.formLabelWidth == '80px'?'95%':'87%'}" :label="$t('imagemanagement.contAddress')" :label-width="formLabelWidth">
              <el-input v-model="tableInfo.address" :class="formLabelWidth == '80px'?'':'en-address'" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
          </div>

          <div class="bline1"  v-if="!worb">
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contTimeActivation')" prop="activationTime" :label-width="formLabelWidth">
              <el-date-picker class="starTime"
                              v-model="tableInfo.activationTime"
                              type="datetime"
                              value-format="yyyy-MM-dd HH:mm:ss"
                              :placeholder="$t('imagemanagement.contTimeSet')">
              </el-date-picker>
            </el-form-item>
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.EnabledAndDisabled')" :label-width="formLabelWidth4">
              <!--<el-select v-model="tableInfo.enableState" @change="selectState" size="small" class="el-list">-->
                <!--<el-option-->
                  <!--v-for="item in selectData"-->
                  <!--:key="item.id"-->
                  <!--:label="item.label"-->
                  <!--:value="item.id">-->
                <!--</el-option>-->
              <!--</el-select>-->
              <el-switch
                @change="updateStates(tableInfo.enableState)"
                v-model="tableInfo.enableState === 1"
                active-color="#13ce66"
                inactive-color="#ff4949">
              </el-switch>
            </el-form-item>
          </div>
          <div class="bline1"  v-if="!worb">
            <el-form-item style="width: 50%;" :label="$t('imagemanagement.contTimeExpiration')" :label-width="formLabelWidth">
              <el-date-picker class="cancelTime"
                              :disabled="worb"
                              v-model="tableInfo.expirationTime"
                              type="datetime"
                              value-format="yyyy-MM-dd HH:mm:ss"
                              :placeholder="$t('imagemanagement.contTimeSet')">
              </el-date-picker>
            </el-form-item>
          </div>
        </div>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="btnLoading" @click="editSuccess()">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button class="cancel" type="info" @click="cancle()">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--添加弹框-->
    <!--替换弹框-->
    <el-dialog
      :title="$t('imagemanagement.titleAlarm')"
      :visible.sync="replaceBool"
      width="584px">
      <div class="warn-wrap">
        <!--<p style="color: #fc3d1a;">{{$t('imagemanagement.popmsgIDOccupied')}}</p>-->
        <el-alert
          :title="$t('imagemanagement.popmsgIDOccupied')"
          type="warning">
        </el-alert>
        <br>
        <div class="content">
          <div class="avatar">
            <img :src="processImgurl(idData.imageUrl)">
          </div>
          <div class="name">
            <div class="line">
              <!--姓名-->
              <div class="left">{{$t('imagemanagement.contName')}}</div>
              <div class="right item">{{idData.name}}</div>
            </div>
            <div class="line">
              <!--别名-->
              <div class="left">{{$t('imagemanagement.contAlias')}}</div>
              <div class="right item">{{idData.aliasName}}</div>
            </div>
            <div class="line">
              <!--ID-->
              <div class="left">{{$t('imagemanagement.contID')}}</div>
              <div class="right item">{{idData.ID}}</div>
            </div>
            <div class="line2">
              <!--人像库-->
              <div class="left">{{$t('imagemanagement.contImageLibrary')}}</div>
              <div class="right">
                <!--<ul>-->
                  <!--<li v-for="(item,key) in idData.libraryVos" :key="key">{{item.name}}</li>-->
                  <!--&lt;!&ndash; <li v-for="item in idData.libraryVos">{{item.name}}</li> &ndash;&gt;-->
                <!--</ul>-->
                <div style="max-height: 100px;overflow-y: auto;">
                  <span class="detailsLibraryName" style="display: block;position: relative;height: 100%;" v-for="(item,key) in idData.libraryVos" :key="key">
                     <el-tooltip class="item" v-if="item.name&&item.name.length>9" effect="dark" :content="item.name" placement="top">
                       <span style="display: block;text-align: left">{{item.name ? item.name : " "}}</span>
                     </el-tooltip>
                    <span v-else class="item" style="display: block;text-align: left;">{{item.name ? item.name : " "}}</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="danger" @click="replaceSubInfo" :loading="replaceLoading">{{$t('imagemanagement.buttonReplace')}}</el-button>
        <el-button class="cancel" @click="replaceBool = false">{{$t('imagemanagement.buttonDiscard')}}</el-button>
      </span>
    </el-dialog>

      <!--    输入密码显示id弹窗-->
    <el-dialog
      :title="$t('imagemanagement.importPassWord')"
      :visible.sync="isShowIdVisible"
    >
      <el-form :model="pwd" :rules="ruleList" ref="pwdForm" label-width="150px" @submit.native.prevent>
        <el-form-item :label="$t('imagemanagement.userPassWord')" prop="password">
          <el-input type="password" v-model="pwd.password"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
          <el-button type="primary" class="deleteBtn" @click="showIdFn">{{$t('imagemanagement.buttonOK')}}</el-button>
          <el-button @click="isShowIdVisible = false" type="info" class="cancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {PortraitModule} from '@/store/modules/portrait';
  import TreeSelect from "@/components/portraitDeviceAdd/index.vue";
  import {isEmpty} from '@/utils/validate';
  import {processImgurl} from '@/utils/image';
  import {fileValidate} from '@/utils/validate';
  import {AppModule} from '@/store/modules/app';
  import {UserModule} from '@/store/modules/user';
  import i18n from "@/lang";
  let stp = false;
  let vm = null as any;
  let idNoChange:boolean = true;//判断加密id是否变更
  const nameTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrEnterName')))//请输入名字
    }else{
      callback()
    }
  }
  const timeTip = (rule, value = '', callback) => {
    if (value === ''|| value === null){
      callback(new Error(vm.$t('form.texterrSelectTime')))//请输入时间
    }else{
      callback()
    }
  }
  const imgTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrUploadImage')))//请选择照片
    }else{
      callback()
    }
  }
  const genderTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrSelectGender')))//请选择性别
    }else{
      callback()
    }
  }
  const requiredTime = (rule, value = '', callback) => {
    if (stp){
      callback()
    } else{
      if (value === ''|| value === null) {
        // debugger
        callback(new Error(vm.$t('form.texterrSelectTime')))
      } else {
        callback()
      }
    }

  }
  const libraryIdsTip = (rule, value = '', callback) => {
    if (value.length == 0){
      callback(new Error(vm.$t('form.texterrSelectImageLib')))//请选择人像库
    }else{
      callback()
    }
  }
  const idTip = (rule, value = '', callback) => {
    if (value === ''|| value === null) {
      callback(new Error(vm.$t('form.texterrEnterID')))//"请输入ID"
    }
    if (idNoChange){
      callback();
    }

    // let re = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{1,40}$/ as any
    let re =/^[0-9a-zA-Z]+$/
    if (re.test(value)) {
      callback()
    }else{
      callback(new Error(vm.$t('form.texterrPersonIDPolicy')))//"请输入数字和字母的组合"
    }
  }

  @Component({
    components: {
      TreeSelect
    },
    computed: {
      rulesList: function () {
        let that = this as any;
        return that.rules1
      },
      selectData:function () {
        let that = this as any;
        return [{
          id: 1,
          label: that.$t('usermanagement.listStatusEnabled'),
        }, {
          id: 2,
          label: that.$t('usermanagement.listStatusDisabled'),
        }]
      },
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '80px';
      },
      formLabelWidth2: function () {
        let that = this as any;
        return that.language == 'en' ? '720px' : '584px';
      },
      formLabelWidth3: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '70px';
      },
      formLabelWidth4: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '100px';
      }
    }
  })
  export default class portraitEdit extends Vue {
    get language() {
      return AppModule.language;
    }

    dataLoading = false;
    btnLoading = false;
    startDatePicker= this.beginDate();
    endDatePicker= this.processDate();
    dialogShowVisible = false;
    processImgurl=processImgurl;
    // formLabelWidth = '80px';
    showIcon = true;
    worb = false;//判断是白名单还是黑名单
    rules1 = {
      name: [{required: true, trigger: 'blur',  validator: nameTip}],//'请输入姓名'
      ID: [{required: true, trigger: 'blur', validator: idTip}],
      activationTime: [{required: true, trigger: 'blur', validator: timeTip}],//'请选择时间'
      expirationTime: [{required: true, trigger: 'blur', validator: requiredTime}],
      libraryIds: [{required: true, trigger: 'blur', validator: libraryIdsTip}],
      image: [{required: true, trigger: 'blur', validator:imgTip}],//'请上传本地人像照片'
      gender: [{required: true, validator:genderTip, trigger: 'change'}],
    };
    tree = [] as any;
    dataUserIdsObj = {
      userIds: [] as any,
      defaultIds: [] as any,
      type: null as any
    } as any;
    tableInfo = {
      ID: "",
      activationTime: "",
      enableState: 1,
      address: "",
      age: null,
      aliasName: "",
      company: "",
      dept: "",
      vehiclePlateNumber:'',
      expirationTime: "",
      gender: 1,
      image: "",
      libraryIds: [] as any,
      name: "",
      phone: "",
      replace: 0
    } as any;
    idData = {} as any;
    replaceBool = false;
    replaceLoading:boolean = false;
    targetId = null as any;
    // treeData = [] as any;
    conditions = {file: null}; //添加文件
    encryptionId:string = '';
    @Prop(Object) dataObj!: any;
    @Prop(Array) treeData!: any;
    @Prop(Number) libraryId!: any;
    @Prop(Number) libraryType!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;

    isNunberChange = ''
    isShowId = false
    isShowIdVisible = false;
    pwd = {
      password: ''
    };
    ruleList = {
      password:[
        { required: true, message: i18n.t('imagemanagement.passWordImport')+"", trigger: 'blur' }
      ]
    };

    created(){
      vm = this as any;
    }


    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.dataLoading = true;
      setTimeout(()=>{
        this.dataLoading = false;
      },1000)
      this.showIcon = false;
      idNoChange = true;
      this.tableInfo.replace = 0;

      this.tree = [];
      //判断黑名单还是白名单
      if (this.libraryType == 1){
        this.tree.push(this.treeData[0])
      }
      if (this.libraryType == 2){
        this.tree.push(this.treeData[1])
      }
    }
    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      let that = this as any;
      if (!val) {
        that.$refs['dataForm'].resetFields()
        this.$emit("closePortraitEdit");
        this.clear();
        this.restoreImg()
        this.isShowId = false
      }
    }

    @Watch('worb')
    onWorbChange(val: any) {
      if(this.libraryType == 2){
        this.tableInfo.activationTime = '';
        this.tableInfo.expirationTime = '';
      }
    }

    // @Watch('tableInfo.activationTime')
    // onActivationTimeChange(val:any){
    //   if (this.tableInfo.expirationTime) {
    //     if (new Date(this.tableInfo.activationTime).getTime() > new Date(this.tableInfo.expirationTime).getTime()){
    //       this.tableInfo.activationTime = '';
    //     }
    //   }
    // }
    //
    // @Watch('tableInfo.expirationTime')
    // onExpirationTimeChange(val:any){
    //   if (this.tableInfo.activationTime) {
    //     if (new Date(this.tableInfo.expirationTime).getTime() < new Date(this.tableInfo.activationTime).getTime()){
    //       this.tableInfo.expirationTime = '';
    //     }
    //   }
    // }
    @Watch('tableInfo.age')
    onTableInfoChange(val: any) {
      if (val - 0 > 150){
        this.tableInfo.age = 150;
      }
      if (val < 0){
        this.tableInfo.age = 0;
      }
    }

    @Watch('dataObj')
    onDataObjChange(val: any) {
      this.tableInfo.ID = val.ID;
      this.encryptionId = val.ID;//生成加密id；
      this.tableInfo.activationTime = val.activationTime;
      this.tableInfo.enableState = val.enableState;
      this.tableInfo.address = val.address;
      this.tableInfo.age = val.age;
      this.tableInfo.aliasName = val.aliasName;
      this.tableInfo.company = val.company;
      this.tableInfo.dept = val.dept;
      this.tableInfo.vehiclePlateNumber = val.vehiclePlateNumber;
      // this.tableInfo.expirationTime = val.expirationTime == '3019-02-13 00:00:00' ? '' : val.expirationTime;
      this.tableInfo.expirationTime = val.expirationTime;
      this.tableInfo.gender = val.gender == 3 ? "":val.gender;
      this.tableInfo.image = this.processImgurl(val.imageUrl);
      // this.tableInfo.libraryId = val.libraryId;
      this.tableInfo.name = val.name;
      this.tableInfo.phone = val.phone;
      this.targetId = val.targetId;

      let arr = [] as any;
      if (val.libraryVos) {
        for(let i = 0;i < val.libraryVos.length;i++){
          arr.push(val.libraryVos[i].libraryId)
        }
      }
      this.dataUserIdsObj.userIds = arr;
      this.tableInfo.libraryIds = arr;
      this.dataUserIdsObj.defaultIds = arr;
      this.dataUserIdsObj.type = val.libraryType;

      //获取到人像信息时，判断是黑名单还是白名单。若为黑名单，禁用结束时间
      if(val.libraryType == 2){
        this.worb = true;
        stp = true;
      }
      if(val.libraryType == 1){
        this.worb = false;
        stp = false;
      }

      idNoChange = true;
      this.dataLoading = false;

      this.isNunberChange = val.ID
    }

    //id加密后的修改逻辑
    idFocus(){
      // this.encryptionId = '';
      // idNoChange = false;
      // console.log(this.dataObj)
      // this.tableInfo.ID = this.encryptionId;
      if(!this.isShowId)
      this.isShowIdVisible = true;
    }
    idBlur(){
      // if (this.encryptionId === ''){
      //   idNoChange = true;
      //   this.encryptionId = this.dataObj.ID;
      // }else{
      //   idNoChange = false;
        // this.tableInfo.ID = this.encryptionId;
      // }
      // console.log(this.tableInfo.ID,'ID');
      if(this.isNunberChange != this.tableInfo.ID){
        idNoChange = false;
      }else {
        idNoChange = true;
      }
    }

    showIdFn(){

      (this.$refs.pwdForm as any).validate((valid) => {
        if (valid) {
          let params = {
            password:'',
            secret:''
          };
          params.password = this.pwd.password;
          params.secret = this.dataObj.cipherText;
          UserModule.getPortraitId(params).then((res)=>{
            // this.encryptionId = (res as any).decryptStr;
            this.tableInfo.ID = (res as any).decryptStr;
            this.isShowId = true;
          }).finally(()=>{
            this.isShowIdVisible = false;
            this.pwd.password = '';
          })
        }else {
          return false;
        }
      });
    }


    //输入验证
    inputAgeNum(val){
      if(this.verifySize(val)){
        this.tableInfo.age = val
      }else{
        this.tableInfo.age = '';
      }

    }

    inputVehiclePlateNumber(val){
      if(this.verifySize3(val)){
        this.tableInfo.vehiclePlateNumber = val
      }else{
        this.tableInfo.vehiclePlateNumber = '';
      }
    }

    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([0-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        return true;
      }else{
        return false;
      }
    }

    //输入验证
    inputName(val){
      if(this.verifySize2(val)){
        this.tableInfo.name = val
      }else{
        this.tableInfo.name = '';
      }

    }
    //输入验证
    inputName2(val){
      if(this.verifySize2(val)){
        this.tableInfo.aliasName = val
      }else{
        this.tableInfo.aliasName = '';
      }

    }
    //输入验证
    verifySize2(val){
      // let reg = /^\d*$/
      let reg = /^\S+/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }
    //输入验证
    verifySize3(val){//无特殊字符
      let reg = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }


    handleSelected(obj) {
      console.log(obj);
      // this.form.deviceIds = obj.userIds;
      this.dataUserIdsObj = obj;
      this.tableInfo.libraryIds = obj.userIds;
      this.dataUserIdsObj.type == 2 ? this.worb = true : this.worb = false;
      this.dataUserIdsObj.type == 2 ? stp = true : stp = false;
      (this.$refs.dataForm as any).validateField('libraryIds');
      console.log(stp,'stp')
    }


    //时间判断
    beginDate(){
      const self = this
      return {
        disabledDate(time){
          if (self.tableInfo.expirationTime) {  //如果结束时间不为空，则小于结束时间
            return new Date(self.tableInfo.expirationTime).getTime() < time.getTime()
          } else {
            // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
          }
        }
      }
    }
    processDate() {
      const  self = this
      return {
        disabledDate(time) {
          if (self.tableInfo.activationTime) {  //如果开始时间不为空，则结束时间大于开始时间
            return new Date(self.tableInfo.activationTime).getTime() > time.getTime()
          } else {
            // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
          }
        }
      }
    }

    dddrop(evt){
      // debugger
      let vm = this as any;
      console.log(evt)
      evt.stopPropagation();
      evt.preventDefault();
      let picLink = evt.dataTransfer.getData("text/plain") || evt.dataTransfer.getData("URL");
      if(picLink){
        //web页面拖拽
        var image = new Image();
        image.src = picLink;
        image.setAttribute("crossOrigin",'Anonymous');
        image.onload = function(){
          picLink = getBase64Image(image);
          function getBase64Image(img) {
            var canvas = document.createElement("canvas") as any;
            canvas.width = img.width;
            canvas.height = img.height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, img.width, img.height);
            var ext = img.src.substring(img.src.lastIndexOf(".")+1).toLowerCase();
            var dataURL = canvas.toDataURL("image/"+ext);
            return dataURL;
          }
          let params = {} as any;
          params.image = picLink;
          PortraitModule.protraitDetection(params).then((data:any)=>{
            console.log(data)
            vm.showIcon = false;
            let selectImg =  document.getElementById("selectedImg2") as any;
            selectImg.setAttribute("src",picLink);
            vm.tableInfo.image = picLink;
          })
        }

      }else{
        // 文件拖拽
        let vm = this as any;
        let file = evt.dataTransfer.files[0];
        let reader = new FileReader() as any;

        let Orientation ;
        let _this = vm;
        vm.EXIF.getData(file, ()=> {
          Orientation =  _this.EXIF.getTag(file , 'Orientation')
          //将文件以Data URL形式读入页面
            reader.readAsDataURL(file);
            reader.onload = function() {
              //显示文件
              let params = {} as any;
              params.image = this.result;
              PortraitModule.protraitDetection(params).then((data:any)=>{
                // console.log(this.result,'-------------------------------');


                vm.showIcon = false;
                let selectImg =  document.getElementById("selectedImg2") as any;
                // console.log(Orientation ,selectImg, '----------------------')


                  switch (Orientation) {
                    case 1:
                      selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                      break;
                    case undefined:
                      selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                      break;
                    case 6:
                      selectImg.style = 'transform: rotate(90deg);width :158px;height : 118px '
                      break;
                    case 3:
                      selectImg.style = 'transform: rotate(180deg);width :118px;height : 158px '
                      break;
                    case 8:
                      selectImg.style = 'transform: rotate(-90deg);width :158px;height : 118px '
                      break;
                  }

                selectImg.setAttribute("src",this.result);
                vm.tableInfo.image = this.result;
                vm.$refs.dataForm.validateField('image');

              }).catch((err)=>{

              })
            };
        })
      }
    }
    dragover(evt){
      evt.stopPropagation();
      evt.preventDefault();
    }

    //上传图片前端展示
    // upImage(e) {
    //   let vm = this;
    //   let a = e.target.files as any;
    //   this.conditions.file = a[0];
    //   let bool = vm.beforePicUpload(this.conditions.file);
    //   if (bool == false){
    //     return;
    //   }
    //   let reader = new FileReader() as any;
    //   //将文件以Data URL形式读入页面
    //   reader.readAsDataURL(this.conditions.file);
    //   reader.onload = function () {
    //     // debugger
    //     //显示文件
    //     let params = {} as any;
    //     params.image = this.result;
    //     PortraitModule.protraitDetection(params).then((data:any)=>{
    //       console.log(data)
    //       vm.showIcon = false;
    //       let selectImg =  document.getElementById("selectedImg2") as any;
    //       selectImg.setAttribute("src",this.result);
    //       vm.tableInfo.image = this.result;
    //     }).catch((err)=>{
    //       e.target.value = ''
    //     })
    //   };
    // }

        //上传图片前端展示
    upImage(e){
      console.log(e)
      let vm = this as any;
      let Orientation ;
      this.conditions.file = e.target.files[0];
      //处理exif属性
      let _this = vm
      vm.EXIF.getData(this.conditions.file, ()=> {
        // console.log(this.conditions.file);

        Orientation =  _this.EXIF.getTag(this.conditions.file , 'Orientation') // 此处打印的为选中图片的数据
        // let orientation =_this.EXIF.getAllTags(this.conditions.file).Orientation

        let bool = vm.beforePicUpload(this.conditions.file);
        if (bool == false){
          return;
        }
        let reader = new FileReader() as any;
        //将文件以Data URL形式读入页面
        reader.readAsDataURL(this.conditions.file);
        reader.onload = function() {
          //显示文件
          let params = {} as any;
          params.image = this.result;
          PortraitModule.protraitDetection(params).then((data:any)=>{
            let selectImg =  document.getElementById("selectedImg2") as any;
            switch (Orientation) {
              case 1:
                selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                break;
              case undefined:
                selectImg.style = 'transform: rotate(0deg); width :118px;height : 158px '
                break;
              case 6:
                selectImg.style = 'transform: rotate(90deg);width :158px;height : 118px '
                break;
              case 3:
                selectImg.style = 'transform: rotate(180deg);width :118px;height : 158px '
                break;
              case 8:
                selectImg.style = 'transform: rotate(-90deg);width :158px;height : 118px '
                break;
            }

            console.log(data)
            vm.showIcon = false;

            selectImg.setAttribute("src",this.result);
            vm.tableInfo.image = this.result;
          }).catch((err)=>{
            e.target.value = ''
          })
        };
      })


    }

    restoreImg(){
      let selectImg =  document.getElementById("selectedImg2") as any;
       selectImg.style ='none';
       console.log('----------none----------');

    }
    //图片验证
    beforePicUpload(file){
      let that = this as any;
      let isFile = fileValidate(file,['png','jpg','jpeg','bmp'],16);
      if(!isFile.type){
        this.$message.error({showClose: true,message:that.$t('imagemanagement.tipsPicType')});
        return false;
      }
      if (!isFile.size) {
        this.$message.error({showClose: true,message:that.$t('imagemanagement.tipsOversize')});
        return false;
      }
    }

    cancle(){
      this.dialogShowVisible = false;
      this.clear();

    }
    clear(){
      let selectImg =  document.getElementById("selectedImg2") as any;
      // selectImg.src = "";
      this.tableInfo.image = this.processImgurl(this.dataObj.imageUrl);
      this.showIcon = true
      let file = document.getElementById("img-upload-btn2") as any;
      file.value = '';
      console.log('clear');
    }

    //选择黑白名单
    selectPortrait(){

    }
    //选择激活状态
    selectState(val){
      console.log(val,this.tableInfo.enableState)
    }
    //确认编辑
    editSuccess() {
      let that = this as any;
      if (!this.worb && this.tableInfo.expirationTime  && new Date(this.tableInfo.expirationTime).getTime() < new Date(this.tableInfo.activationTime).getTime()){
        this.tableInfo.activationTime = '';
        this.tableInfo.expirationTime = '';
        this.$message({
          showClose: true,
          message:that.$t('imagemanagement.timeTips'),
          // message:'激活时间需早于失效时间',
          type: 'error'
        })
        return;
      }

      // //车牌号校验
      // if(this.tableInfo.vehiclePlateNumber){
      //   let reg = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/;
      //   if (!reg.test(this.tableInfo.vehiclePlateNumber)||this.tableInfo.vehiclePlateNumber.length < 7){
      //     this.$message({
      //       message:that.$t('visitor.visitorlist.tipsCarNumberErr'),
      //       type: 'error'
      //     })
      //     return
      //   }
      // }
      (this.$refs.dataForm as any).validate(valid => {
        if (valid) {
          console.log(this.tableInfo);
          this.btnLoading = true;
          // this.tableInfo.replace = 1;
          // if (this.tableInfo.expirationTime == ""){
          //   this.tableInfo.expirationTime = "3019-02-13 00:00:00"
          // }
          let obj = {
            ID: '',
            activationTime: '',
            enableState: '',
            address: '',
            age: '',
            aliasName: '',
            company: '',
            dept: '',
            vehiclePlateNumber:'',
            expirationTime: '',
            gender: '',
            image: null,
            libraryIds: [] as any,
            libraryType: null as any,
            name: '',
            phone: '',
            replace: '',
          } as any;
          obj.ID = idNoChange?this.dataObj.cipherText:this.tableInfo.ID;
          obj.activationTime = this.tableInfo.activationTime;
          obj.enableState = this.tableInfo.enableState;
          obj.address = this.tableInfo.address;
          obj.age = this.tableInfo.age;
          obj.aliasName = this.tableInfo.aliasName;
          obj.company = this.tableInfo.company;
          obj.dept = this.tableInfo.dept;
          obj.vehiclePlateNumber = this.tableInfo.vehiclePlateNumber;
          obj.expirationTime = this.tableInfo.expirationTime;
          // if (obj.expirationTime == ""){
          //   obj.expirationTime = "3019-02-13 00:00:00"
          // }
          obj.gender = this.tableInfo.gender;
          if (this.tableInfo.image.substring(0, 11) == 'data:image/') {
            // base64 图片操作
            obj.image = this.tableInfo.image;
          } else {
            //path 图片操作
          }
          obj.libraryIds = this.dataUserIdsObj.userIds;
          obj.libraryType = this.dataUserIdsObj.type;
          obj.name = this.tableInfo.name;
          obj.phone = this.tableInfo.phone;
          obj.replace = this.tableInfo.replace;
          console.log(obj)
          let datas = {
            params: obj,
            id: this.targetId
          }
          let that = this as any;
          PortraitModule.protraitEditData(datas).then((data: any) => {
            if (data.code == '408006'){
              this.replaceBool = true
              let params = {} as any;
              params.ID = this.tableInfo.ID;
              PortraitModule.protraitIdDetails(params).then((data: any) => {
                console.log('idData',data);
                // this.token = JSON.parse((localStorage as any).getItem("accessToken")).value;
                data.imageUrl =  data.imageUrl;
                this.idData = data;
              }).catch((err) => {

              });
            }else if(!data.code){
              console.log("确认编辑", data);
              this.dialogShowVisible = false;
              this.$emit('showPortraitList')
            }

          }).catch((err) => {

          }).finally(()=>{
            this.btnLoading = false;
          })
        } else {
          console.log(that.$refs['dataForm'])
        }
      })
    }

    //提交表单
    replaceSubInfo(){
      this.replaceLoading = true;
      let that = this as any;
      (that.$refs.dataForm as any).validate((valid) => {
        console.log(valid)
        if (valid) {
          // if (this.form.expirationTime == ""){
          //   this.form.expirationTime = "3019-02-13 00:00:00"
          // }
          this.tableInfo.replace = 1;
          console.log(this.tableInfo)
          let obj = {
            ID: '',
            activationTime: '',
            enableState: '',
            address: '',
            age: '',
            aliasName: '',
            company: '',
            dept: '',
            vehiclePlateNumber:'',
            expirationTime: '',
            gender: '',
            image: null,
            libraryIds: [] as any,
            libraryType: null as any,
            name: '',
            phone: '',
            replace: '',
          } as any;
          obj.ID = idNoChange?this.dataObj.cipherText:this.tableInfo.ID;
          obj.activationTime = this.tableInfo.activationTime;
          obj.enableState = this.tableInfo.enableState;
          obj.address = this.tableInfo.address;
          obj.age = this.tableInfo.age;
          obj.aliasName = this.tableInfo.aliasName;
          obj.company = this.tableInfo.company;
          obj.dept = this.tableInfo.dept;
          obj.vehiclePlateNumber = this.tableInfo.vehiclePlateNumber;
          obj.expirationTime = this.tableInfo.expirationTime;
          // if (obj.expirationTime == ""){
          //   obj.expirationTime = "3019-02-13 00:00:00"
          // }
          obj.gender = this.tableInfo.gender;
          if (this.tableInfo.image.substring(0, 11) == 'data:image/') {
            // base64 图片操作
            obj.image = this.tableInfo.image;
          } else {
            //path 图片操作
          }
          obj.libraryIds = this.dataUserIdsObj.userIds;
          obj.libraryType = this.dataUserIdsObj.type;
          obj.name = this.tableInfo.name;
          obj.phone = this.tableInfo.phone;
          obj.replace = this.tableInfo.replace;
          let datas = {
            params: obj,
            id: this.targetId
          }
          PortraitModule.protraitEditData(datas).then((data: any) => {
            console.log("返回数据",data);
            if (data.code == '408006'){

            } else if (!data.code){
              this.dialogShowVisible = false;
              this.$emit('showPortraitList')
              this.replaceBool = false;
            }
          }).catch((err) => {
            console.log("返回数据",err);
            // this.$message(err);
            // if (err.code == 408006){
            //   alert(1)
            // }
          }).finally(()=>{
            this.replaceLoading = false;
          });
        }
      })

    }

    //改变人像状态
    updateStates(obj) {
      console.log(obj);
      if (obj == 1){
        this.tableInfo.enableState = 2
      } else{
        this.tableInfo.enableState = 1
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  $bg: #2d3a4b;
  $light_gray: #eee;
  .active{
    color:#fc3d1a;
  }
  .warn-wrap{
    width: 100%;
    word-break: break-word;
    margin-bottom: 20px;
  }
  .warn-wrap>p{
    border-top: solid 1px #8e99aa;
    text-align: center;
    padding: 30px 0;
  }
  .warn-wrap .content{
    width: 100%;
    display: flex;
    justify-content: center;
  }
  .warn-wrap .content .avatar{
    width: 120px;
    height: 160px;
    /*margin-left: 140px;*/
    margin-right: 30px;
    flex-shrink:0;
  }
  .warn-wrap .content .avatar>img{
    width: 100%;
    height: 100%;
  }
  .warn-wrap .content .name{
    width: 310px;
  }
  .warn-wrap .content .name .line{
    width: 100%;
    display: flex;
    padding: 10px 0;
  }
  .warn-wrap .content .name .line2{
    width: 100%;
    display: flex;
    padding: 10px 0;
  }
  .warn-wrap .content .name .left{
    width: 50%;
    font-weight: bolder;
    flex-shrink:0;
    text-align: right;
  }
  .warn-wrap .content .name .right{
    overflow: auto;
  }
  .warn-wrap .content  .detailsLibraryName{
    width: 140px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  ::v-deep .el-dialog__body{
    //padding: 0 20px 20px !important;
    box-sizing: border-box;
  }
  .wrap{
    width: 100%;
    display: flex;
    border-bottom: solid 1px #b3c1d2;
  }
  .wrap .top{
    margin: 40px 70px 55px 48px;
  }
  .wrap .detail{
    flex-grow:1;
    height: 100%;
    margin: 32px 0 23px;
  }
  .bottom{
    width: 100%;
  }
  .bottom .bline1{
    width: 100%;
    display: flex;
    justify-content: space-between;
  }
  .pic{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  #img-upload-btn2{
    display: none;
  }
  #selectedImg2{
    width: 118px;
    height: 158px;
  }
  .upload{
    width: 120px;
    height: 160px;
    border: 1px dashed #707070;
    border-radius: 3px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .upload>span{
    width: 68px;
    height: 68px;
    border:1px dashed #707070;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .info{
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    height: 160px;
    justify-content: space-between;
    align-items: center;
  }
  .icon-upload-copy{
    font-size: 40px;
  }
  ::v-deep .el-input__inner{
    width: 90%;
    height: 32px !important;
    font-size: 12px !important;
  }
  .age ::v-deep .el-input__inner{
    padding-right: 0!important;
  }
  .starTime{
    width: 100% !important;
  }
  .starTime ::v-deep .el-input__inner{
    padding: 10px !important;
    text-align: left !important;
  }
  .starTime ::v-deep .el-input__prefix{
    display: none;
  }
  .cancelTime ::v-deep .el-input__inner{
    padding: 10px !important;
    text-align: left !important;
  }
  .cancelTime ::v-deep .el-input__prefix{
    display: none;
  }

  .el-inp{
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    height: 160px;
    justify-content: space-between;
    align-items: center;
  }
  ::v-deep .el-input__suffix{
    right: 28px !important;

  }
  .el-row{
    line-height: 32px;
  }
  .option{
    font-weight: bolder;
    padding-top: 30px;
  }
  .item{
    /*line-height: 32px;*/
    /*margin-top: 10px;*/
    padding-left: 10px;
  }
  .adrs ::v-deep .el-input__inner{
    width: 94% !important;
  }
  .right{
    text-align: center;
  }
  /*.cancelTime ::v-deep .el-input__inner{*/
    /*!*width: 100% !important;*!*/
  /*}*/
  .lang ::v-deep .el-form-item__content{
    width: 94%;
  }

  .bline1 ::v-deep .el-radio{
    margin-right: 20px;
  }
  ::v-deep .en-address{
    input{
      width: 91%;
    }
  }
</style>
