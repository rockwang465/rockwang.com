<template>
  <div class="group-card-container">
    <header>
      <i v-popover:cardpopover class="group-card-more el-icon-more" ></i>
    </header>
    <div class="group-card-content" >
      <div class="group-card-info" >
        <p :title="title" >{{title}}</p>
      </div>
      <div class="group-card-items" >
        <span class="group-card-tag" > <i class="iconfont icon-device" ></i> {{$t('rule.contDevice')}} <span>{{devices}}</span></span>
        <span class="group-card-tag tag-margin" v-if="type =='ac'" > <i class="iconfont icon-timezone-set" ></i> {{$t('rule.contTimezone')}} <span>{{times}}</span></span>
        <span class="group-card-tag" > <i class="iconfont icon-portrait-manage" />  {{$t('rule.contImageLibrary')}} <span>{{libs}}</span></span>
      </div>
    </div>
    <el-popover
      ref="cardpopover"
      placement="right-start"
      trigger="click">
      <div class="popover-container" >
        <p class="group-card-popover-p" @click="view" > <span  ><i class="iconfont icon-view group-card-popover" ></i> {{$t('rule.listView')}}</span> </p>
        <div class="blank-border" ></div>
        <p class="group-card-popover-p" v-if="$permission('006212')" @click="edit"> <span ><i class="iconfont icon-edit group-card-popover" ></i> {{$t('rule.listRename')}}</span> </p>
        <div class="blank-border" ></div>
        <p class="group-card-popover-p" v-if="$permission('006413')" @click="deleteGroup"> <span class="delete"  ><i class="iconfont icon-delete group-card-popover" ></i> {{$t('rule.buttonDelete')}}</span> </p>
      </div>
    </el-popover>
  </div>
</template>

<script lang="ts">
import { Component, Vue ,Prop} from 'vue-property-decorator';

@Component({
  components: {

  },
})
export default class GroupCard extends Vue {
  /* props */
  @Prop({default:''}) title!: string;
  @Prop({default:''}) type!: string;
  @Prop({default:0}) devices!: number;
  @Prop({default:0}) times!: number;
  @Prop({default:0}) libs!: number;
  @Prop({default:0}) groupId!: number;

  /* watch */

  /* data */
  
  /* methods */
  view(){
    this.$emit('view',{groupId:this.groupId,groupName:this.title})
  }
  edit(){
    this.$emit('edit',this.groupId);
  }
  deleteGroup(){
    this.$emit('delete',this.groupId);
  }


}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .group-card-container{
    // margin-right: 10px;
    // margin-bottom: 10px;
    max-width: 440px;
    display: inline-block;
    background-color: $--color-white;
    box-shadow: $--box-shadow-base;
    border-radius: $--border-radius-base;
    header{
      background-color: $--color-primary;
      text-align-last: right;
      color: $--color-white;
      padding: 8px 10px 8px 0;
      .group-card-more{
        transform:rotate(90deg);
        cursor: pointer;
      }
    }
    .group-card-content{
      padding: 0 16px;
      .group-card-items{
        padding-bottom: 16px;
        display: flex;
        justify-content: space-around;
        .group-card-tag{
          padding: 6px 12px;
          background-color: $--color-bg-3;
          border-radius: $--border-radius-base;
        }
        
      }
    }
    .group-card-info{
      height: 110px;
      font-size: $--font-size-card;
      color: $--color-black;
      margin-bottom: 10px;
      // width: 295px;
      width:100%;
      display: flex;
      align-items: center;
      p{
        text-align: center;
        width: 100%;
        max-height: 110px;
        word-wrap:break-word;
        word-break:normal;
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }

  }
  .popover-container{
    .blank-border{
      height: 1px;
      background-color: $--border-color-base;
      width: 100%;
    }
    p{
      line-height: 25px;
      text-indent: 10px;
      cursor: pointer;
      // span{
      //   cursor: pointer;
      // }
    }
  }
  .group-card-popover-p{
    padding-left: 16px;
  }
  .group-card-popover{
    margin-right: 10px;
  }
</style>
