<template>
  <div class="info-container">
      <el-row class="title-one">
          <!--<el-col class="title"></el-col>-->
          <el-col class="title">
             <el-row>
               <!--基本信息-->
              <el-col :span="16" class="xin"><span class="circle"></span>{{$t('personalinfo.labelBasicInfo')}}</el-col>
               <!--修改密码-->
              <el-col :span="8"><el-button v-if="$permission('002223')" class="btn" type="primary" size="small" icon="iconfont icon-permission" @click="showUpdataPass">{{$t('personalinfo.buttonResetPassword')}}</el-button></el-col>
             </el-row>
              <el-row class="info">
                <!--账户-->
                <el-col :span="6" class="info-title">{{$t('personalinfo.contUsername')}}</el-col>
                <el-col :span="18" class="info-msg">{{userInfo.username}}</el-col>
              </el-row>
            <el-row class="info">
              <!--姓名-->
              <el-col :span="6" class="info-title">{{$t('personalinfo.contName')}}</el-col>
              <el-col :span="18" class="info-msg">{{userInfo.realname}}</el-col>
            </el-row>
            <el-row class="info">
              <!--角色-->
              <el-col :span="6" class="info-title">{{$t('personalinfo.contRole')}}</el-col>
              <el-col :span="18" class="info-msg">{{userInfo.roleName}}</el-col>

            </el-row>
            <!--<el-row class="info">-->
              <!--<el-col class="info-title">设备分配</el-col>-->
              <!--<el-col class="info-msg" width="500px">已选择{{userInfo.deviceIds}}个设备</el-col>-->
            <!--</el-row>-->
            <el-row class="info">
              <!--语言-->
              <el-col :span="6" class="info-title">{{$t('personalinfo.languageType')}}</el-col>
              <el-col :span="10" class="info-msg">{{$t('langName')}}</el-col>
              <el-col :span="8">

                <lang-select ref="langSelect" @changeLang="changeLanguage" size="16px">
                  <el-button class="personLanguage" type="primary" size="small">
                    <i class="iconfont icon-en"></i>
                    {{$t('personalinfo.languageSwitch')}}
                  </el-button>
                </lang-select>

              </el-col>
            </el-row>
            <hr style="background-color:#c2cad8;height: 1px;border:none;margin: 50px 0" />
            <el-row>
              <!--其他信息-->
              <el-col :span="12" class="xin"><span class="circle"></span>{{$t('personalinfo.labelOtherInfo')}}</el-col>
            </el-row>
            <el-row class="info-two">
              <!--性别-->
              <el-col class="cc">{{$t('personalinfo.contGender')}}</el-col>
              <el-col class="dd" >{{userInfo.gender?userInfo.gender == 1?$t('imagemanagement.contMale') : $t('imagemanagement.contFemale'):''}}</el-col>
              <!--年龄-->
              <el-col class="cc">{{$t('personalinfo.contAge')}}</el-col>
              <el-col class="dd">{{userInfo.age}}</el-col>
            </el-row>
            <el-row class="info-two">
              <!--公司-->
              <el-col class="cc">{{$t('personalinfo.contCompany')}}</el-col>
              <el-tooltip v-if="userInfo.company&&userInfo.company.length>10" class="item" effect="dark" :content="userInfo.company" placement="top">
                <el-col class="dd">{{userInfo.company}}</el-col>
              </el-tooltip>
              <el-col class="dd" v-else>{{userInfo.company}}</el-col>
              <!--部门-->
              <el-col class="cc">{{$t('personalinfo.contDepartment')}}</el-col>
              <el-tooltip v-if="userInfo.dept&&userInfo.dept.length>10" class="item" effect="dark" :content="userInfo.dept" placement="top">
                <el-col class="dd">{{userInfo.dept}}</el-col>
              </el-tooltip>
              <el-col class="dd" v-else>{{userInfo.dept}}</el-col>
            </el-row>
            <el-row class="info-two">
              <!--联系方式-->
              <el-col class="cc">{{$t('personalinfo.contContact')}}</el-col>
              <el-tooltip v-if="userInfo.telephone&&userInfo.telephone.length>10" class="item" effect="dark" :content="userInfo.telephone" placement="top">
                <el-col class="dd">{{userInfo.telephone}}</el-col>
              </el-tooltip>
              <el-col class="dd" v-else>{{userInfo.telephone}}</el-col>
              <!--住处-->
              <el-col class="cc">{{$t('personalinfo.contAddress')}}</el-col>
              <el-tooltip v-if="userInfo.address&&userInfo.address.length>10" class="item" effect="dark" :content="userInfo.address" placement="top">
                <el-col class="dd">{{userInfo.address}}</el-col>
              </el-tooltip>
              <el-col class="dd" v-else>{{userInfo.address}}</el-col>
            </el-row>
            <el-row class="info-two">
              <!--激活状态-->
              <el-col class="cc">{{$t('personalinfo.contActiveStatus')}}</el-col>
              <el-col class="dd">{{userInfo.state?userInfo.state == 0?$t('personalinfo.contDisable'):userInfo.state == 1?$t('personalinfo.contEnable'):$t('personalinfo.contLock'):''}}</el-col>
              <el-col class="cc"></el-col>
              <el-col class="dd"></el-col>
            </el-row>
          </el-col>
          <!--<el-col class="title"></el-col>-->
      </el-row>


    <!--修改密码弹框-->
    <!--:title="firstShow == false ?'首次登陆请先修改密码':'修改密码'"-->
    <el-dialog
      :title="$t('personalinfo.titleResetPassword')"
      :visible.sync="dialogShowVisible"
      :close-on-click-modal="firstShow"
      :close-on-press-escape="firstShow"
      :show-close="firstShow"
      width="584px">
      <el-form
        :rules="rulesList"
        label-position="right"
        ref="dataForm" :model="form">
      <el-row>
        <el-row class="row">
          <!--旧密码-->
          <el-form-item :label="$t('personalinfo.contCurrentPassword')" prop="oldpwd" :label-width="formLabelWidth">
            <el-input v-model="form.oldpwd" type="password" autocomplete="off" maxlength="20"></el-input>
          </el-form-item>
        </el-row>
        <el-row class="row">
          <!--新密码-->
          <el-form-item :label="$t('personalinfo.contNewPassword')" prop="newpwd" :label-width="formLabelWidth">
            <el-input v-model="form.newpwd" type="password"  autocomplete="off" minlength="8" maxlength="20"></el-input>
          </el-form-item>
          <div style="position: absolute;top: 8px;right: -20px;">
            <el-popover
              placement="bottom-start"
              width="271"
              trigger="hover">
              <div class="content">
                {{$t('personalinfo.hovmsgPasswordPolicy')}}
                <!--密码支持8-20个字符，且至少包含以下格式中三种类型字符：-->
                <!--<br>-->
                <!--1.大写字符（ABCDEF）；-->
                <!--<br>-->
                <!--2.小写字母（abcdef）；-->
                <!--<br>-->
                <!--3.数字（1234567890）；-->
                <!--<br>-->
                <!--4.特殊字符（，。/‘’！；：[]、-=!@#$%%^&*()）；-->
              </div>
              <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
            </el-popover>
          </div>
        </el-row>
        <el-row class="row">
          <!--再次输入-->
          <el-form-item :label="$t('personalinfo.contConfirmPassword')" prop="newpwd2" :label-width="formLabelWidth">
            <el-input v-model="form.newpwd2" type="password"  autocomplete="off" minlength="8" maxlength="20"></el-input>
          </el-form-item>
        </el-row>
      </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer" style="margin-bottom: 20px">
          <el-button type="primary" @click="updatePwd">{{$t('usermanagement.buttonOK')}}</el-button>
          <el-button type="info" class="cancel"  @click="cancelUpdate">{{$t('usermanagement.buttonCancel')}}</el-button>
       </span>
    </el-dialog>
    <!--修改密码弹框-->
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch } from 'vue-property-decorator';
  import {logout} from '@/store/modules/login';
  import {UserModule} from '@/store/modules/user';
  import {Cache} from '@/utils/cache';
  import {AppModule} from '@/store/modules/app';
  import LangSelect from '@/components/lang-select/index.vue';
  let vm = null as any;
  const requiredTip = (rule, value = '', callback) => {
    // debugger
    if (value === ''|| value === null) {
      // debugger
      callback(new Error(vm.$t('form.texterrCurrentPassword')))//旧密码
    } else {
      callback()
    }
  }
  let newPassword = null as any;
  const newPwd = (rule, value = '', callback) => {
    newPassword = value;
    let regEnUp = /[A-Z]+/,//大写字母
      regEnLow = /[a-z]+/,//小写字母
      regNum = /[0-9]+/,//数字
      regEnSymbol = /[-`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im;//英文特殊字符
      // regEnSymbol = /[`~!@#$%^&*()_=+{}:;'"\/<,.>?[\]]/im,//英文特殊字符
      // regCnSymbol = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im;//中文特殊字符
    if (value === '') {
      callback(new Error(vm.$t('form.texterrNewPassword')))//请输入非空内容
    } else if (value.length < 8) {
      callback(new Error(vm.$t('form.texterrPasswordPolicy')))//请输入8位数以上的密码
    }
    let i = 0;
    if (regEnUp.test(value)) {
      i++;
    }
    if (regEnLow.test(value)) {
      i++;
    }
    if (regNum.test(value)) {
      i++;
    }
    if (regEnSymbol.test(value)) {
      i++;
    }
    if (i < 3) {
      callback(new Error(vm.$t('form.texterrPasswordPolicy')))//密码格式不正确，请重新输入
    } else {
      callback()
    }
  }


  const newPwd2 = (rule, value = '', callback) => {
    if (value === ''|| value === null) {
      // debugger
      callback(new Error(vm.$t('form.texterrConfirmPassword')))//再次输入新密码
    }
    // debugger
    if (value !== newPassword) {
      // debugger
      callback(new Error(vm.$t('personalinfo.errmsgUnmatchPassword')))//两次密码输入不相同
    } else {
      callback()
    }
  }

  @Component({
    components: {
      LangSelect,
    },
    computed: {
      rulesList: function () {
        let that = this as any;
        return that.rules1
      },
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '180px' : '80px';
      },
      dataObj:function () {
        let that = this as any;
        let obj = {} as any;
        obj.a = that.$t('form.texterrConfirmPassword');
        return obj;
      }
    }

  })
  export default class PersonInfo extends Vue {
    get language() {
      return AppModule.language;
    }

    dialogShowVisible = false;
    userInfo = {} as any;
    oldpwd = '' as any;
    newpwd = '' as any;
    newpwd2 = '' as any;
    // formLabelWidth = '180px'
    first = null as any;
    firstShow = false;
    form = {
      oldpwd : '' as any,
      newpwd : '' as any,
      newpwd2 : null as any
    } as any;
    rules1 = {
      oldpwd: [{required: true, trigger: 'blur', validator: requiredTip}],
      newpwd: [{required: true, trigger: 'blur', validator: newPwd}],
      newpwd2: [{required: true, trigger: 'blur', validator: newPwd2}],
    };
    currentLang=null


    //展示修改密码
    showUpdataPass(){
      this.dialogShowVisible = true;
    }

    created(){
      vm = this as any;
      let that = this as any;
      let userInfo = sessionStorage.getItem('userInfo') as any;
      this.first = JSON.parse(userInfo).value.first;
      console.log('session',this.first);
      if (this.first == 0){
        this.dialogShowVisible = true;
        this.firstShow = false;
        // this.$message({
        //   message: '首次登陆请先修改密码',
        //   type: 'success'
        // });
      }else{
        this.dialogShowVisible = false;
        this.firstShow = true;
      }
      let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
      let id = user.userId;
      UserModule.getOneUserDetail(id).then((data: any) => {
        console.log('用户数据详情',data);
        this.userInfo = data;
        let str = '';
        for(let i = 0;i < this.userInfo.deviceIds.length;i++){
          str += this.userInfo.deviceIds[i] + ' ';
        }
        // this.userInfo.deviceIds = str;
        this.userInfo.deviceIds = this.userInfo.deviceIds.length;
        // if (this.userInfo.gender == 1){
        //   this.userInfo.gender = that.male//that.$t('imagemanagement.contMale')//'男'
        // } else if (this.userInfo.gender == 2){
        //   this.userInfo.gender = that.female//that.$t('imagemanagement.contFemale')//'女'
        // }else if (this.userInfo.gender == 3){
        //   this.userInfo.gender = '其他'
        // }
        let that = this as any;
        if (this.userInfo.state == 0){
          // this.userInfo.state = '未激活'
          // this.userInfo.state = that.dataObj.a
        } else if (this.userInfo.state == 1){
          // this.userInfo.state = '已激活'
          // this.userInfo.state = that.dataObj.a
        }else if (this.userInfo.state == 2){
          // this.userInfo.state = '锁定'
        }
      }).catch((err) => {

      });
    }
    langSelect(){
      //(this.$refs as any).langSelect.handleSetLanguage();
    }
    updatePwd(){
      let that = this as any;
      (that.$refs.dataForm as any).validate((valid) => {
        if (valid) {
          let user:any = Cache.localGet('userInfo') || Cache.sessionGet('userInfo');
          let userId = user.userId;
          let obj = {
            params:{
              confirmPassword:this.form.newpwd2,
              newPassword: this.form.newpwd,
              oldPassword: this.form.oldpwd
            },
            id: userId
          } as any;
          console.log(obj)
          UserModule.updataPassWord(obj).then(() => {
            this.$message({
              showClose: true,
              // message: '修改密码成功',
              message: that.$t('globaltip.tipmsgChangePassword'),
              type: 'success'
            });
            // if(this.first == 0){
            logout()
            // }
            this.dialogShowVisible = false;
            this.firstShow = true;
          }).catch((err) => {
            console.log(err)
            // this.$message(err);
          });
        }
      })

    }
    cancelUpdate(){
      if (this.first == 0){
        logout();
        return;
      }
      let that = this as any;
      that.$refs['dataForm'].resetFields()
      this.dialogShowVisible = false;
      this.firstShow = true;
    }
    changeLanguage(){
      this.currentLang = this.$store.state.app.language;
    }

  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.personLanguage{
  position: relative;
  padding-left: 38px;
  i.iconfont{
    font-size: 16px;
    position: absolute;
    left: 17px;
    top: 7px;
  }
}
  .circle {
    display: block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #011c50;
    position: absolute;
    top: 13px;
    left: -20px;
  }
   .title-one{
      display: flex;
      justify-content: center;
      margin-top: 80px;
   }
   .title{
      width: 33.3%;
      font-family: "Hiragino Sans GB";
      color: #28354d;
   }
   .icon-user{
     color:#b3c1d2;
     font-size: 20px;
     vertical-align: middle;
   }
  .xin{
    line-height: 32px;
    color: #28354d;
    font-size: 20px;
    font-family: "Hiragino Sans GB";
  }
  .btn{
    height: 32px;
    /*width: 104px;*/
  }
  .info{
    display: flex;
    width: 100%;
  }
  .info-title,.info-msg{
    font-size: 14px;
    color: #28354d;
  }
  .info-title{
    color: #28354d;
    text-align: right;
    margin-right: 10px;
    /*width: 81px;*/
  }
   .info-msg{
     color: #2a5af5;
     opacity: 0.8;
   }
  .info-two{
    display: flex;
  }
  .cc{
    text-align: right;
    margin-right: 10px;
    /*width: 111px;*/
  }
  .dd{
    color: #2a5af5;
    opacity: 0.8;
    overflow: hidden; /*超出部分隐藏*/
    text-overflow: ellipsis; /* 超出部分显示省略号 */
    white-space: nowrap; /*规定段落中的文本不进行换行 */
  }
  .el-col{
    line-height: 32px;
  }
  ::v-deep .el-dialog__footer{
     text-align: center !important;
   }

  ::v-deep .el-input__inner{
     height: 32px;
   }
   .row{
     display: flex;
     justify-content: center;
     margin-top: 10px;
     position: relative;
   }
   .el-col{
     line-height: 32px;
   }
   .sx{
     padding-left: 23%;
   }

  .content{
    /*width: 251px;*/
    /*height: 144px;*/
    font-size: 12px;
    line-height: 20px;
    color: #28354d;
    /*background-color: #fff9d6;*/
    white-space: normal;
    word-break: break-all;
  }

  .info-container .dialog-footer{
    display: flex;
    justify-content: center;
    margin-top: 20px;
  }
</style>
