<template>
  <div v-if="dialogShowVisible">
    <!--导出人像弹框-->
    <!--上传失败-->
    <el-dialog
      :title="$t('imagemanagement.titleUploadFail')"
      :visible.sync="dialogShowVisible"
      width="1330px">
      <div style="position: relative;margin-top: 20px;width: 100%;">
          <div  class="title-wrap" style="width:100%;">
            <!--时间-->
              <div class="title" >{{$t('records.contTime')}}:</div>
              <div  class="time">
                <el-date-picker
                  v-model="value4"
                  type="datetimerange"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  range-separator="-"
                  :start-placeholder="$t('imagemanagement.contTimeSet')"
                  :end-placeholder="$t('imagemanagement.contTimeSet')">
                </el-date-picker>
              </div>
            <!--筛选-->
            <el-button style="margin-left: 16px;" type="primary" icon="iconfont icon-filter" @click="find(1)">
              {{$t('imagemanagement.buttonFilter')}}
            </el-button>
              <div  class="btn-list">
                <!--导出人像-->
                <!--v-show="btnShow && failCount != 0"-->
                <i @click="comeHome" style="cursor: pointer" v-show="showSelect" class="iconfont icon-fanhui"></i>
                <el-checkbox  style="margin-left: 16px" v-show="showSelect" :loading="isClearAll" :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">{{$t('rule.listDeviceAll')}}</el-checkbox>
                <el-button style="margin-left: 16px" v-show="showSelect" v-if="$permission('023402')" type="danger" size="small" icon="iconfont icon-delete" @click="chooseDelete(1)">{{$t('imagemanagement.buttonDelete')}}</el-button>
                <!--批量操作-->
                <el-button icon="iconfont icon-batch-handle" v-if="$permission('023402')" type="primary" @click="showSelect = true" v-show="failCount != 0&&!showSelect">{{$t('imagemanagement.buttonBatch')}}</el-button>
                <!--一键清空-->
                <el-button icon="iconfont icon-delete" type="primary"  :disabled="showSelect" v-if="$permission('023401')" :loading="isClearAll" @click="chooseDelete(2)" v-show="failCount != 0">{{$t('imagemanagement.Empty')}}</el-button>

                <el-button v-if="$permission('016301')" icon="el-icon-upload2" v-show="failCount != 0" :disabled="showSelect" type="primary" @click="exportPic">{{$t('imagemanagement.buttonExport')}}</el-button>
              </div>
          </div>
        <!--图片-->
          <div class="content" style="height: 345px;overflow: auto">
            <!--<el-checkbox-group v-model="portraitOption" @change="handleCheckedChange">-->
              <!--<el-col>-->
              <!--</el-col>-->
              <!--<el-col class="people pic" :style="{'backgroundImage': 'url(' + processImgurl(item.imageUrl) + ')'}"></el-col>-->
              <!--<el-col class="people info">-->
                <!--<el-col style="overflow: hidden;white-space:nowrap;text-overflow: ellipsis;">{{$t('imagemanagement.labelName')}}:{{item.name}}</el-col>-->
                <!--<el-col style="overflow: hidden;white-space:nowrap;text-overflow: ellipsis;">{{item.ID}}</el-col>-->
                <!--<el-col v-show="showSelect" class="check"><el-checkbox class="chess" :label="item.targetId" :key="item.targetId"></el-checkbox></el-col>-->
              <!--</el-col>-->
            <!--</el-checkbox-group>-->
          <div v-for="(item,index) in dataList" :key="index" class="wrap">
            <el-checkbox-group v-model="picList" @change="handleCheckedChange">
              <el-checkbox v-show="showSelect" class="chess" :label="item.bulkToolPublicId" :key="item.bulkToolPublicId"></el-checkbox>
              <el-tooltip placement="bottom-start">
                <div slot="content">
                  <!--文件名-->
                  {{$t('imagemanagement.contFileName')}}: {{item.fileName}}<br/>
                  <!--上传时间-->
                  {{$t('imagemanagement.contUploadTime')}}: {{item.createTime}} <br/>
                  <!--失败原因-->
                  {{$t('imagemanagement.contFailReason.Title')}}:{{item.tips}}
                </div>
                  <div class="box">
                    <div class="pic">
                      <img style="width: 100%;height: 100%;" :src="item.failPicUrl?processImgurl(item.failPicUrl):avatar + '/images/noPerson.svg'">
                    </div>
                  </div>
              </el-tooltip>
            </el-checkbox-group>
          </div>
            <!--暂无数据-->
            <div style="width: 100%;height: 336px;text-align: center;line-height: 336px;font-size: 20px" v-show="noData">{{$t('imagemanagement.contNoData')}}</div>
      </div>
        <!--图片-->
      </div>
      <!--分页-->
      <el-row class="pages" >
        <el-pagination
          v-show="!noData"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange"
                       :current-page="pageNum"
                       :page-sizes="[10, 20, 30, 50,100]"
                       :page-size="pageSize"
                       layout="total, sizes, prev, pager, next, jumper"
                       :total="total">
        </el-pagination>
      </el-row>
      <!--分页-->
      <span slot="footer" class="dialog-footer">
        <!--确定-->
        <el-button type="primary" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonOK')}}</el-button>
        <!--取 消-->
      <el-button class="cancel" type="info" @click="dialogShowVisible = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--导出人像弹框-->

    <!--删除人像弹框-->
    <el-dialog
      :title="deleteTitle"
      :visible.sync="deleteDialog"
      width="30%">
      <div class="content">
        {{deleteContent}}
      </div>
      <span slot="footer" class="dialog-footer">
        <!--确定-->
        <el-button type="danger" @click="deleteChoosePics()">{{$t('imagemanagement.buttonOK')}}</el-button>
        <!--取 消-->
      <el-button class="cancel" type="info" @click="deleteDialog = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>

    <!--导出人像组件-->
    <portraitUpFailOut :dialogVisible="showOut" :time="times" :total="total" :libraryType="libraryType" :libraryId="libraryId" @closePortraitOut="closePortraitOut"></portraitUpFailOut>
    <!--导出人像组件-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {PortraitModule} from '@/store/modules/portrait';
  import portraitUpFailOut from './portraitUpFailOut.vue';
  import { LoginModule } from '@/store/modules/login';
  import {processImgurl} from '@/utils/image.ts';

  @Component({
    components:{
      portraitUpFailOut
    }
  })
  export default class portraitUpFail extends Vue {
    get avatar() {
      return LoginModule.avatar;
    }

    @Prop(Boolean) btnShow!: any;
    @Prop(Number) failCount!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;

    processImgurl:any = processImgurl;
    showOut = false;
    pageSize = 20;
    pageNum = 1;
    dialogShowVisible = false;
    value4 = null as any;
    times = null as any;
    noData = false as any;
    total = 0 as any;
    host = window.globalConfig.host  + '/' as any;
    // token = '' as any;
    dataList = [

    ] as any;
    isClearAll = false;
    isIndeterminate = false;
    checkAll = false;
    showSelect = false;
    picList = [] as any;
    deletePicArr = [] as any;//批量删除储存图片id
    deleteDialog = false;//删除提示
    deleteTitle = '';
    deleteContent = '';
    deleteType = null as any;
    @Prop(Number) libraryId!: any;
    @Prop(Number) libraryType!: any;
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      this.value4 = null;
      this.times = null;
      this.find2();
      this.findProtraitUpFailCount();
    }
    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.pageNum = 1;
        this.pageSize = 20;
        this.showSelect = false;
        this.init();
        this.$emit("closePortraitFail");
      }
    }
    @Watch('pageNum')
    onPageNumChange(val: any) {
      this.picList =  [];
      this.checkAll = false;
    }
    //分码大小处理
    handleSizeChange(val){
      console.log(val)
      this.pageSize = val;
      if (this.value4&&this.value4[0] && this.value4[1]){
        this.find(0);
      } else{
        this.find2();
      }

    }
    //当前页变动处理
    handleCurrentChange(val){
      console.log(val)
      this.pageNum = val;
      if (this.value4&&this.value4[0] && this.value4[1]){
        this.find(0);
      } else{
        this.find2();
      }
    }
    //按时间查询
    find(num){
      // if (!this.value4){
      //   this.$message({
      //     message:'请先选择时间',
      //     type:'error'
      //   })
      //   return;
      // }
      if (num == 1){
        this.pageNum = 1;
      }
      this.times = this.value4;
      let params = {} as any;
      params.page = this.pageNum;
      params.size = this.pageSize;
      params.startTime  = this.value4?this.value4[0]:null;
      params.endTime = this.value4?this.value4[1]:null;
      params.libraryId = this.libraryId;//选滔接口
      params.libraryType = this.libraryType;//选滔接口
      // PortraitModule.protraitQueryDateTimeList(params).then((data : any)=>{
      //   console.log(data)
      //   // this.detailsData = data.dataList;
      // })

      // 选滔接口
      PortraitModule.protraitUpFailList(params).then((data : any)=>{
        console.log(data)
        // this.token = JSON.parse((localStorage as any).getItem("accessToken")).value;
        this.total = data.total;
        for(let i = 0;i < data.data.length;i++){
          if(data.data[i].failPicUrl){
            // data.data[i].failPicUrl = this.host + data.data[i].failPicUrl
          }else{
            // data.data[i].failPicUrl = '@public'
          }
          let that = this as any;
          if (data.data[i].failReasonType == 1){
            // data.data[i].tips = '图片尺寸过大'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.Oversize')
          }else if (data.data[i].failReasonType == 2){
            // data.data[i].tips = '图片格式不正确'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.WrongType')
          }else if (data.data[i].failReasonType == 3){
            // data.data[i].tips = 'id只能是数字和字母或两者组合'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 4){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 5){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 6){
            // data.data[i].tips = '人像库容量已达上限'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.UpperLimit')
          }else if (data.data[i].failReasonType == 7){
            // data.data[i].tips = '系统已存在该ID的人像'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.DuplicateID')
          }else if (data.data[i].failReasonType == 8){
            // data.data[i].tips = '图片地址异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.AddressException')
          }else if (data.data[i].failReasonType == 9){
            // data.data[i].tips = '提取人像特征失败'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.FailFeature')
          }else if (data.data[i].failReasonType == 10){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 11){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 12){
            // data.data[i].tips = '图片质量分数过低'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.lowQuality')
          }else if (data.data[i].failReasonType == 13){
            // data.data[i].tips = '图片尺寸过小'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.littleSize')
          }else if (data.data[i].failReasonType == 14){
            // data.data[i].tips = '检测到多个人脸'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.MultipleFace')
          }else if (data.data[i].failReasonType == 15){
            // data.data[i].tips = '检测不到人脸'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.NoFace')
          }else if (data.data[i].failReasonType == 16){
            // data.data[i].tips = '文件命名不符合规范'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.nonstandard')
          }else if (data.data[i].failReasonType == 18){
            // data.data[i].tips = '提取前端特征失败'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.feature')
          }
        }
        this.dataList = data.data;
        if (data.data.length == 0){
          this.noData = true;
        } else{
          this.noData = false
        }
      })
    }
    //页数查询
    find2(){
      let params = {} as any;
      //params.taskId = PortraitModule.taskId//雅敏接口
      params.libraryId = this.libraryId;//选滔接口
      params.libraryType = this.libraryType;//选滔接口
      params.page = this.pageNum;
      params.size = this.pageSize;
      // PortraitModule.protraitQueryTaskList(params).then((data : any)=>{
      //   console.log(data)
      //   // this.detailsData = data.dataList;
      // })

      //选滔接口
      PortraitModule.protraitUpFailList(params).then((data : any)=>{
        // this.token = JSON.parse((localStorage as any).getItem("accessToken")).value;
        console.log(data)
        this.total = data.total;
        for(let i = 0;i < data.data.length;i++){
          // if(data.data[i].failPicUrl){
          //   data.data[i].failPicUrl = this.host + data.data[i].failPicUrl
          // }else{
          //   // data.data[i].failPicUrl
          // }
          let that = this as any;
          if (data.data[i].failReasonType == 1){
            // data.data[i].tips = '图片尺寸过大'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.Oversize')
          }else if (data.data[i].failReasonType == 2){
            // data.data[i].tips = '图片格式不正确'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.WrongType')
          }else if (data.data[i].failReasonType == 3){
            // data.data[i].tips = 'id只能是数字和字母或两者组合'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 4){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 5){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 6){
            // data.data[i].tips = '人像库容量已达上限'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.UpperLimit')
          }else if (data.data[i].failReasonType == 7){
            // data.data[i].tips = '系统已存在该ID的人像'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.DuplicateID')
          }else if (data.data[i].failReasonType == 8){
            // data.data[i].tips = '图片地址异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.AddressException')
          }else if (data.data[i].failReasonType == 9){
            // data.data[i].tips = '提取人像特征失败'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.FailFeature')
          }else if (data.data[i].failReasonType == 10){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 11){
            // data.data[i].tips = '系统异常'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.SystemException')
          }else if (data.data[i].failReasonType == 12){
            // data.data[i].tips = '图片质量分数过低'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.lowQuality')
          }else if (data.data[i].failReasonType == 13){
            // data.data[i].tips = '图片尺寸过小'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.littleSize')
          }else if (data.data[i].failReasonType == 14){
            // data.data[i].tips = '检测到多个人脸'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.MultipleFace')
          }else if (data.data[i].failReasonType == 15){
            // data.data[i].tips = '检测不到人脸'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.NoFace')
          }else if (data.data[i].failReasonType == 16){
            // data.data[i].tips = '文件命名不符合规范'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.nonstandard')
          }else if (data.data[i].failReasonType == 18){
            // data.data[i].tips = '提取前端特征失败'
            data.data[i].tips = that.$t('imagemanagement.contFailReason.feature')
          }
        }
        this.dataList = data.data;
        if (data.data.length == 0){
          this.noData = true;
        } else{
          this.noData = false
        }
      })
    }
    //查询上传失败数量
    findProtraitUpFailCount(){
      let params = {
        libraryId:this.libraryId?this.libraryId:null,
        libraryType :this.libraryType,
      } as any;
      PortraitModule.protraitUpFailCount(params).then((data:any)=>{
        console.log(data);
        this.total = data.failTargetCount
      })
    }
    //导出
    exportPic(){
      this.showOut = true;
    }
    //关闭导出
    closePortraitOut(){
      this.showOut = false;
    }

    //一键清空
    clearAllPics(){
      let that = this as any;
      this.isClearAll = true;
      let params = {
        libraryId:this.libraryId?this.libraryId:null,
        libraryType:this.libraryType
      }
      PortraitModule.removeAllFailPicture(params).then((data)=>{
        console.log(data);
        // this.$message({
        //   message: "一键清空成功",
        //   // message:this.$t('globaltip.tipmsgBatchUpload'),
        //   type: 'success'
        // });
        that.$message({
          showClose: true,
          // message: "一键清空成功",
          message:this.$t('globaltip.tipmsgDeleteImage'),
          type: 'success'
        });
        this.init();
        this.$emit('init');
      }).finally(()=>{
        this.isClearAll = false;
      })
    }

    init(){
      this.pageSize = 20;
      this.pageNum = 1;
      this.checkAll = false;
      this.isIndeterminate = false;
      this.deletePicArr = [];
      this.picList = [];
      this.value4 = null;
      this.find2();
    }

    // 删除分类
    chooseDelete(num){
      let that = this as any;
      this.deleteDialog = true;
      this.deleteType = num;
      if (num === 1){
        // this.deleteTitle = '删除';
        this.deleteTitle = that.$t('imagemanagement.listDelete');
        // this.deleteContent = '人像删除后将无法恢复。';
        this.deleteContent = that.$t('imagemanagement.deleteTips1');
      }else if (num === 2){
        // this.deleteTitle = '一键清空';
        this.deleteTitle = that.$t('imagemanagement.Empty');
        // this.deleteContent = '所有上传失败的人像将被清空，将无法恢复。';
        this.deleteContent = that.$t('imagemanagement.deleteTips2');
      }
    }
    deleteChoosePics(){
      this.deleteDialog = false;
      if (this.deleteType === 1){
        this.picsDelete();
      }else if (this.deleteType === 2){
        this.clearAllPics();
      }
    }

    //全选操作
    handleCheckAllChange(val) {
      if (val){
        let targetIds = [] as any;
        this.dataList.forEach((item)=>{
          targetIds.push(item.bulkToolPublicId);
        })
        console.log(targetIds)
        this.picList = val ? targetIds : [];
        this.isIndeterminate = false;
      } else{
        this.picList =  [];
      }
      this.deletePicArr = this.picList;

    }

    //单选操作
    handleCheckedChange(value) {
      // console.log(value);
      let checkedCount = value.length;
      this.checkAll = checkedCount === this.dataList.length;
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.dataList.length;
      this.deletePicArr = this.picList;
    }

    comeHome(){
      // this.showBtn = true;
      this.showSelect = false;
      this.init();
    }

    //批量删除图片
    picsDelete(){
      let that = this as any;
      let arr = this.deletePicArr;
      if (arr.length === 0){
        that.$message({
          showClose: true,
          // message: '请选择要删除的人像',
          message: that.$t('form.texterrSelectImage'),
          type: 'error'
        });
        return;
      }
      let params = {
        bulkToolPublicIds:arr
      }
      PortraitModule.BatchRemoveFailPicture(params).then((data)=>{
        console.log(data);
        that.$message({
          showClose: true,
          // message: "一键清空成功",
          message:this.$t('globaltip.tipmsgDeleteImage'),
          type: 'success'
        });
        this.init();
        this.$emit('init');
      })
    }

  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  // ::v-deep .el-dialog__body {
  //   //padding: 0 0 20px 0 !important;
  // }
  ::v-deep .el-range-editor.el-input__inner{
    height: 32px;
  }
  ::v-deep .el-range__close-icon{
    line-height: 26px;
  }
  ::v-deep .el-date-editor .el-range-separator{
    height: 32px;
  }
  .title-wrap{
    display: flex;
    padding: 0 24px;
  }
  .title{
    line-height: 32px;
    text-align: right;
  }
  .time{
    padding-left: 20px;
  }
  .content{
    display: flex;
    flex-wrap: wrap;
  }
  .pic{
    height: 144px;
    /*background:url("https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3727379540,3698536131&fm=27&gp=0.jpg") no-repeat center;*/
    background-size:100%;
  }
  .wrap{
    height: 144px;
    margin-top: 24px;
    position: relative;
  }
  .box{
    width: 108px;
    margin-left: 24px;
  }
  .btn-list{
    display: flex;
    justify-content: right;
    align-items: center;
    margin-left: auto;
  }

  .pages{
     text-align: center;
    background-color: #fff;
  }
  .el-pagination{
    margin-top: 20px;
  }
  .chess{
    position: absolute;
    right: 2px;
    top: 0;
    margin-right: 0;
  }
  .chess ::v-deep .el-checkbox__label{
    display: none;
  }

</style>
