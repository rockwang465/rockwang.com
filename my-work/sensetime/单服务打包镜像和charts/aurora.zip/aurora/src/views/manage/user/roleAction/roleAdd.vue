<template>
  <div v-if="dialogShowVisible">
    <el-dialog class="isroll" :title="form.roleId ? $t('rolemanagement.buttonOperationEdit') : $t('rolemanagement.buttonRoleAdd')"
               :visible.sync="dialogShowVisible" :width="language == 'en' ? '720px' : '620px'">
               <div class="scrollable">
      <el-form :rules="rules" ref="dataForm" :model="form" label-position="right" @submit.native.prevent>
        <el-form-item :label="$t('rolemanagement.contRoleName')" :label-width="language == 'en' ? '200px' : '140px'"
                      prop="name"><!--角色名称-->
          <el-input v-model.trim="form.name" autocomplete="off" maxlength="40"></el-input>
        </el-form-item>
        <el-form-item :label="$t('rolemanagement.contPermission')" :label-width="language == 'en' ? '200px' : '140px'">
          <!--$t('rolemanagement.contSelectAll')-->
          <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">
            {{$t('rolemanagement.contSelectAll')}}
          </el-checkbox>
        </el-form-item>
        <div class="role-permission">
          <el-form-item v-for="item in editObjectData.permissionOptions" :label="item.moduleName" :key="item.moduleCode"
                        :label-width="language == 'en' ? '200px' : '140px'">
            <el-checkbox-group v-model="checkedData">
              <el-checkbox v-for="i in item.moduleArray" :label="i.onlyCode" :key="i.onlyCode"
                           @change="handleCheckedChange($event,i.onlyCode)"
                           :disabled="isInArray(i.onlyCode,mustCheckFill)">
                {{i.typeName}}
              </el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </div>
      </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :loading="isSubmit" @click="handleConfirm">{{$t('rolemanagement.buttonOK')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('rolemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {RoleModule} from '@/store/modules/role';
  import {isEmpty} from '@/utils/validate';
  import {AppModule} from '@/store/modules/app';
  let vm = null as any

  @Component({

  })
  export default class RoleAdd extends Vue {
    isSubmit = false;
    get language() {
      return AppModule.language;
    }

    requiredTip = (rule, value, callback) => {
      if (value === '') {
        callback(new Error(vm.$t('rolemanagement.validateRoleName')))
      } else {
        callback()
      }
    }

    rules = {
      name: [{required: true, trigger: 'blur', validator: this.requiredTip}],
    };
    @Prop(Object) editObjectData!: any[];
    @Prop(Object) checkRelate!: any[];
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    isIndeterminate = false;
    dialogShowVisible = false;
    checkedData = [] as any;//选择的数组
    checkAll = false;
    formLabelWidth = this.language == 'en' ? '200px' : '140px';
    form = {
      name: '',
      roleId: ''
    };
    mustCheckFill = ['1-1', '2-1', '2-3'];
    /*checkRelate = {
      '9-2': ['9-1', '8-1', '13-1'],//设备新增 -> 设备查看 地图查看 用户查看
      '9-3': ['9-1', '8-1', '13-1'],//设备修改 -> 设备查看 地图查看 用户查看
      '13-1': ['12-1'],
    }*///权限之间的依赖

    created(){
      vm = this as any;
    }

    handleCheckAllChange(val) {
      let data = this.editObjectData as any;
      this.checkedData = val ? data.allCheckedData : this.mustCheckFill;
      this.isIndeterminate = false;
    }

    handleCheckedChange(value, cod) {
      //当为true的时候，需要重新勾选
      if (value) {
        this.relateChecked(cod)
      } else {
        this.relateNoChecked(cod)
      }
      let data = this.editObjectData as any;
      let checkedCount = data.allCheckedData.length;
      this.checkAll = checkedCount === this.checkedData.length;
      // this.isIndeterminate = (checkedCount > 0) && (checkedCount > this.checkedData.length);
    }

    subInArray(array, value) {
      if (!isEmpty(array) && array.length != 0) {
        for (let i = 0; i < array.length; i++) {
          if (value == array[i]) {
            array.splice(i, 1)
          }
        }
      }
    }

    relateNoChecked(code) {
      let that = this as any;
      //首先获取当前code关联的所有checkMap
      let relateMap = that.checkRelate as any
      let againArray = [] as any;
      //遍历所有的模块
      if (!isEmpty(relateMap)) {
        for (let key in relateMap) {
          //获取当前遍历的模块依赖的模块组
          let array = relateMap[key];
          if (!isEmpty(array)) {
            //如果当前取消的模块被这个key依赖，需要取消这个key
            if (that.isInArray(code, array) && that.isInArray(key, that.checkedData)) {
              that.subInArray(that.checkedData, key)
              //将依赖的添加到数组中，可能依赖的还有依赖
              if (!that.isInArray(key, againArray)) {
                againArray.push(key)
              }
            }
          }
        }
      }
      if (againArray.length != 0) {
        for (let i = 0; i < againArray.length; i++) {
          //if (that.isInArray(againArray[i], that.checkedData)) {
          that.relateNoChecked(againArray[i])
          //}
        }
      }
    }

    relateChecked(code) {
      let that = this as any;
      //首先获取当前code关联的所有check
      let relateArray = that.checkRelate[code]
      let againArray = [] as any;
      //遍历所有的模块
      if (!isEmpty(relateArray)) {
        for (let i = 0; i < relateArray.length; i++) {
          //判断是否被选中，如果没有则添加
          if (!that.isInArray(relateArray[i], that.checkedData)) {
            that.checkedData.push(relateArray[i])
            //将依赖的添加到数组中，可能依赖的还有依赖
            if (!that.isInArray(relateArray[i], againArray)) {
              againArray.push(relateArray[i])
            }
          }
        }
      }
      //
      if (againArray.length != 0) {
        for (let i = 0; i < againArray.length; i++) {
          that.relateChecked(againArray[i])
        }
      }
    }

    isInArray(value, array) {
      for (let i = 0; i < array.length; i++) {
        if (value == array[i]) {
          return true
        }
      }
      return false
    }

    handleConfirm() {
      let that = this as any;
      (that.$refs['dataForm'] as any).validate((valid) => {
        if (valid) {
          that.isSubmit = true;
          let params = {} as any;
          params.roleName = that.form.name;
          // params.permissionCodes = that.getPermission();19-12-23,字段由code改为id
          params.modulePermissionIds = that.getPermission();
          if (isEmpty(that.form.roleId)) {
            //添加
            RoleModule.AddRole(params).then((data: any) => {
              that.dialogShowVisible = false
              that.$emit("refreshData")
              that.$emit("closeRoleAdd")
              that.$message({
                showClose: true,
                message: that.$t('rolemanagement.roleAddSuccess'),
                type: 'success'
              });
              that.isSubmit = false;
            }).catch((err) => {
              console.log(err)
              that.isSubmit = false;
            });
          } else {
            //修改
            RoleModule.UpdateRole({params: params, id: that.form.roleId}).then((data: any) => {
              that.dialogShowVisible = false
              that.$emit("refreshData")
              that.$emit("closeRoleAdd");
              that.isSubmit = false;
            }).catch((err) => {
              console.log(err)
              that.isSubmit = false;
            });
          }
        }

      })
    }

    getPermission() {
      let dataObj = this.editObjectData as any;
      let array = [] as any;
      let a = this.checkedData;
      console.log(this.checkedData)
      console.log(dataObj)
      // debugger
      for (let i = 0; i < this.checkedData.length; i++) {
        if(dataObj.selectParams[this.checkedData[i]]){
          var data = (dataObj.selectParams[this.checkedData[i]] as any).split(",");
          for (let j = 0; j < data.length; j++) {
            array.push(data[j])
          }
        }
      }
      return array;
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      let data = this.editObjectData as any;
      this.checkAll = data.allCheckedData.length == data.checkedArray.length
      if (val) {
        if (!isEmpty(data.roleId)) {
          this.form.name = data.name;
          this.form.roleId = data.roleId;
          this.checkedData = data.checkedArray
        } else {
          this.form.name = '';
          this.form.roleId = '';
          this.checkedData = data.checkedArray
        }
      }
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeRoleAdd")
      }
    }


  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  .content {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }

  .content > div {
    width: 45%;
  }

  .content > div span {
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }

  .outNum {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .outNum span {
    margin-right: 10px;
  }

  .outNum .xian {
    margin-left: 10px;
  }

  .outNum ::v-deep .el-input {
    width: 25%;
  }

  .el-list ::v-deep .el-input__suffix {
    right: 10px !important;
    top: 3px !important;
  }

  .right-name ::v-deep .el-input {
    width: 75%;
  }

  .upFile {
    color: #2a5af5;
  }

  ::v-deep .el-dialog__footer {
    text-align: center !important;
  }

  ::v-deep .el-input__inner {
    height: 32px !important;
  }

  .role-permission ::v-deep .el-form-item__label{
    font-weight: 400;
  }
</style>
