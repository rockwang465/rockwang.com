<template>
  <div>
    <!--添加弹框-->
    <!-- 添加用户 -->
    <el-dialog class="isroll" :width="formLabelWidth2" :title="$t('usermanagement.buttonAddUser')" :visible.sync="dialogShowVisible" v-if="dialogShowVisible">
      <div class="scrollable">
      <el-form
        :rules="rulesList"
        label-position="right"
        style="margin-left: -15px;"
        ref="dataForm" :model="form">
        <div class="wrap">
          <div class="line">
            <!--账户-->
            <el-form-item :label="$t('usermanagement.labelUsername')" prop="username" :label-width="formLabelWidth">
              <!--<el-input size="small" @input="form.username=form.username.replace(/\s+/g,'')" v-model="form.username" autocomplete="off" maxlength="40"></el-input>-->
              <el-input size="small" @input="form.username=form.username.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]|\s+/g,'')" v-model="form.username" autocomplete="off" maxlength="40" :placeholder="$t('usermanagement.contUsernameTips')"></el-input>
            </el-form-item>
          </div>
          <div class="line">
            <!--姓名-->
            <el-form-item :label="$t('usermanagement.contRealname')" prop="realname" :label-width="formLabelWidth">
              <el-input
                @input="inputName"
                size="small" v-model="form.realname" autocomplete="off" maxlength="40"></el-input>
            </el-form-item>
          </div>
          <div class="line">
            <!--密码-->
            <el-form-item :label="$t('usermanagement.contPassword')" prop="password" :label-width="formLabelWidth">
              <el-input size="small" :disabled="true" v-model="form.password" autocomplete="off"></el-input>
            </el-form-item>
          </div>
          <div class="line" style="position: relative;">
            <!--角色-->
            <el-form-item :label="$t('usermanagement.contRole')" prop="roleId" :label-width="formLabelWidth">
              <el-select v-model="form.roleId" @change="selectRole" size="small" class="el-list">
                <el-option
                  v-for="item in selectPerson"
                  :key="item.roleId"
                  :label="item.name"
                  :value="item.roleId">
                </el-option>
                </el-select>
            </el-form-item>
            <div style="position: absolute;top: 8px;right: -20px;">
              <el-popover
                placement="bottom-start"
                width="271"
                trigger="hover">
                <div class="content">
                  {{$t('usermanagement.roleTips')}}
                </div>
                <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
              </el-popover>
            </div>
          </div>
          <div class="line">
            <!--设备分配-->
            <el-form-item :label="$t('usermanagement.contAssignedDevice')" :label-width="formLabelWidth">
              <TreeSelect size="small" :data="treeData"
                          :isAdmin="isAdmin"
                          @selected="handleSelected"
                          show-checkbox
                        :dataObj="dataUserIdsObj"/>
            </el-form-item>
          </div>
        </div>
        <div class="wrap2">
          <div class="line">
            <!--属性-->
            <el-row class="option">{{$t('usermanagement.contOtherInfo')}}</el-row>
          </div>
          <div class="line">
            <!--性别-->
            <el-form-item :label="$t('usermanagement.contGender')" :label-width="formLabelWidth">
              <!--男-->
              <el-radio v-model="form.gender" :label="1">{{$t('imagemanagement.contMale')}}</el-radio>
              <!--女-->
              <el-radio v-model="form.gender" :label="2">{{$t('imagemanagement.contFemale')}}</el-radio>
            </el-form-item>
          </div><div class="line">
          <!--激活状态-->
          <el-form-item :label="$t('devicemanagement.labelActiveStatus')" prop="state" :label-width="formLabelWidth">
            <el-select v-model="form.state" @change="selectPortrait" size="small" class="el-list">
              <el-option
                v-for="item in selectData"
                :key="item.id"
                :label="item.label"
                :value="item.id">
              </el-option>
            </el-select>
            <!--<el-input size="small" v-model="form.state" autocomplete="off" maxlength="40"></el-input>-->
          </el-form-item>
          <!--ID-->
          <el-form-item :label="$t('usermanagement.contID')" :label-width="formLabelWidth">
            <el-input
              :placeholder="$t('form.texterrPersonIDPolicy')"
              size="small" v-model.trim="form.ID" autocomplete="off" maxlength="64"></el-input>
          </el-form-item>
          <!--年龄-->
          <el-form-item :label="$t('usermanagement.contAge')" :label-width="formLabelWidth">
            <!--placeholder="请输入0-150之间的数字"-->
            <el-input
              @input="inputAgeNum"
              :placeholder="$t('form.texterrAgePolicy')"
              size="small" v-model="form.age"  autocomplete="off" maxlength="3"></el-input>
          </el-form-item>
          <!--公司-->
          <el-form-item :label="$t('usermanagement.contCompany')" :label-width="formLabelWidth">
            <el-input size="small" v-model="form.company" autocomplete="off" maxlength="40"></el-input>
          </el-form-item>
          <!--部门-->
          <el-form-item :label="$t('usermanagement.contDepartment')" :label-width="formLabelWidth">
            <!--<el-input size="small" v-model="form.dept" autocomplete="off" maxlength="40"></el-input>-->
            <EditAddGroup style="width: 100%" ref="editaddgroup" size="small" :selectGroupObj="selectGroupObj"
                          @selected="handleEditAddGroup"/>
          </el-form-item>
          <!--联系方式-->
          <el-form-item :label="$t('usermanagement.contContact')" :label-width="formLabelWidth">
            <el-input size="small" v-model="form.telephone" autocomplete="off" maxlength="40"></el-input>
          </el-form-item>
          <!--住址-->
          <el-form-item :label="$t('usermanagement.contAddress')" :label-width="formLabelWidth">
            <el-input size="small" v-model="form.address" autocomplete="off" maxlength="40"></el-input>
          </el-form-item>
        </div>
        </div>
      </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="okDisabled" @click="subInfo">{{$t('usermanagement.buttonOK')}}</el-button>
        <el-button type="info" class="cancel" @click="cancel">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--添加弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch , Prop} from 'vue-property-decorator';
  import {UserModule} from '@/store/modules/user';
  import {RoleModule} from '@/store/modules/role';
  import TreeSelect from "@/components/userDeviceAdd/index.vue";
  import {DeviceModule} from '@/store/modules/device';
  import {isEmpty} from '@/utils/validate';
  import {AppModule} from '@/store/modules/app';
  import EditAddGroup from "@/components/deviceUserAdd/editAddGroup.vue";

  let vm = null as any;

  const requiredTip = (rule, value = '', callback) => {
    // debugger
    if (value === ''|| value === null) {
      // debugger
      callback(new Error("请输入非空内容"))
    } else {
      callback()
    }
  }
  const realNameTip = (rule, value = '', callback) => {
    if (value.length === 0) {
      // debugger
      callback(new Error(vm.$t('form.texterrEnterName')))
    } else {
      callback()
    }
  }
  const userNameTip = (rule, value = '', callback) => {
    if (value.length === 0) {
      // debugger
      callback(new Error(vm.$t('form.texterrEnterUsername')))
    } else {
      callback()
    }
  }
  const idTip = (rule, value = '', callback) => {
    if (value === ''|| value === null) {
      callback(new Error("请输入非空内容"))
    }

    // let re = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{1,40}$/ as any
    let re =/^[0-9a-zA-Z]+$/
    if (re.test(value)) {
      callback()
    }else{
      callback(new Error(vm.$t('form.texterrPersonIDPolicy')))
    }
  }

  const permissionOptions = [
    {
      id:"1",
      name:"监控",
      permissions:[
        {id:"1",text:'查看',disabled:false},
        {id:"2",text:'添加',disabled:true},
        {id:"3",text:'删除',disabled:false},
        {id:"4",text:'修改',disabled:false},
        {id:"5",text:'导出',disabled:false}
      ]
    },
    {
      id:"2",
      name:"检索",
      permissions:[
        {id:"1",text:'查看',disabled:false},
        {id:"2",text:'添加',disabled:false},
        {id:"3",text:'删除',disabled:false},
        {id:"4",text:'修改',disabled:false},
        {id:"5",text:'导出',disabled:false}
      ]
    }
  ];
  @Component({
    components: {
      TreeSelect,
      EditAddGroup
    },
    computed: {
      rulesList: function () {
        let that = this as any;
        return that.rules1
      },
      selectData:function () {
        let that = this as any;
        return [{
          id: 1,
          label: that.$t('usermanagement.buttonEnable'),
        }, {
          id: 0,
          label: that.$t('usermanagement.listStatusDisabled'),
        }]
      },
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '150px' : '90px';
      },
      formLabelWidth2: function () {
        let that = this as any;
        return that.language == 'en' ? '684px' : '584px';
      }
    },
  })
  export default class userAdd extends Vue {
    get language() {
      return AppModule.language;
    }
    isAdmin=false;
    okDisabled = false as any;
    //添加的表单里的值
    dialogShowVisible = false;
    checkAll= false;
    isIndeterminate= true;
    checkedCities= [];
    cities= permissionOptions;
    checkedPermissions:any = [];
    rules1 = {
      username: [{required: true, trigger: 'blur', validator: userNameTip}],
      realname: [{required: true, trigger: 'blur', validator: realNameTip}],
      password: [{required: true, trigger: 'blur', validator: requiredTip}],
      address: [{required: true, trigger: 'blur', validator: requiredTip}],
      roleId: [{required: true, trigger: 'blur', validator: requiredTip}],
      state: [{required: true, trigger: 'change', validator: requiredTip}],
    };
    // formLabelWidth= '90px';
    form = {
      ID: "",
      address: "",
      age: null,
      company: "",
      dept: "",
      deviceIds: [],
      gender: 1,
      orgId: 1,
      password: "888888",
      realname: "",
      remark: "",
      roleId: null,
      state: 1,
      telephone: "",
      username: ""
    } as any;
    selectPerson = [] as any;
    page = 1;
    size = 100000;
    sort = 'DESC';
    treeData = [] as any;
    dataUserIdsObj = {
      userIds: [],
      defaultIds: []
    } as any;
    selectGroupObj = {} as any;
    @Prop(Array) roleList!:any;
    @Prop(Object) dataObj!:any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    @Prop({required: true, default: false}) id!: number;

    created(){
      vm = this as any;
    }

    @Watch('form.age')
    onFormChange(val: any) {
      if (val - 0 > 150){
        this.form.age = 150;
      }
      if (val < 0){
        this.form.age = 0;
      }
    }
    @Watch('form.roleId')
    onFormRoleIdChange(val: any) {
      if (val == 1){
        this.isAdmin = true;
      } else{
        this.isAdmin = false;
      }
    }
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
    }
    @Watch('id')
    onIdChange(val: any) {
      this.form.orgId = val;
      this.getUserGroup();
    }
    @Watch('roleList')
    onRoleListChange(val: any) {
      this.form.roleId = val[0].roleId;
    }
    @Watch('dataObj')
    onDataObjChange(val: any) {
      let that = this as any;
      this.getUserGroup();
      that.selectGroupObj.checked = val.id+','+val.name;
      that.selectGroupObj.checkedLabel = val.name;
      if (this.$refs.editaddgroup) {
        (this.$refs.editaddgroup as any).checkedLabelV = that.dataObj.name;
      }
      that.form.dept = val.name;
    }
    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      let that = this as any;
      if (!val) {
        that.$refs['dataForm'].resetFields();
        that.selectGroupObj.checked = that.dataObj.id+','+that.dataObj.name;
        that.selectGroupObj.checkedLabel = that.dataObj.name;
        this.$emit("closeUserAdd");
      }
    }
    @Watch('form.deviceIds')
    onFormDeviceIdsChange(val: any) {
      let that = this as any;
      let va = that.$refs['dataForm'] as any
      va.validate()
    }
    @Watch('form.ID')
    onFormIdChange(val: any) {
      let that = this as any;
      let va = that.$refs['dataForm'] as any
      va.validate()
    }

    //输入验证
    inputAgeNum(val){
      if(this.verifySize(val)){
        this.form.age = val
      }else{
        this.form.age = '';
      }

    }
    //输入验证
    verifySize(val){
      // let reg = /^\d*$/
      let reg = /^([1-9]{1})\d*$/
      if(reg.test(val)|| val==""){
        return true;
      }else{
        return false;
      }
    }
    //输入验证
    inputName(val){
      if(this.verifySize2(val)){
        this.form.realname = val
      }else{
        this.form.realname = '';
      }

    }
    //输入验证
    verifySize2(val){
      // let reg = /^\d*$/
      let reg = /^\S+/
      if(reg.test(val)){
        return true;
      }else{
        return false;
      }
    }


    //获取角色列表
    getRoleList(){
      let that = this as any;
      let params = {
        page: that.page,
        size: that.size,
        sort: that.sort,
        state: that.state
      };
      RoleModule.GetRoleList(params).then((data: any) => {
        console.log("角色列表",data);
        this.selectPerson = data.data;
        this.form.roleId = this.selectPerson[0].roleId;
      }).catch((err) => {
        console.log(err);
      });
    }

    //获取部门分组
    getUserGroup(){
      let params = {} as any;
      let that = this as any;
      UserModule.GetUserGroup(params).then((data: any) => {
        console.log('分组数据',data);
        that.selectGroupObj.treeData = data.data;
      }).catch((err) => {

      });
    }


    //初始化设备树
    initGroupTree() {
      let that = this as any;
      DeviceModule.getDevicesTree({}).then((data: any) => {
        console.log('设备分组',data.data);
        that.treeData = data.data;
      }).catch((err) => {
        console.log(err)
      });
    }

    handleEditAddGroup(id, name) {
      this.selectGroupObj.checked = id + ',' + name;
      this.selectGroupObj.checkedLabel = name;
      // this.form.groupId = id;
      this.form.orgId = id;
      this.form.dept = name;
    }


    //激活状态
    selectPortrait(){
      console.log(this.form.state)
    }
    mounted(){
      permissionOptions.map(item =>{
        item.permissions.map(i =>{
          let checkedItem = item.id + i.text;
          this.checkedPermissions.push("checkedItem");
        })
      })
      this.getRoleList();
      this.initGroupTree();
      this.getUserGroup();
    }
    handleSelected(obj) {
      console.log(obj);
      this.form.deviceIds = obj.userIds;
      this.dataUserIdsObj = obj;
    }
    subInfo(){
      this.okDisabled = true;
      setTimeout(()=>{
        this.okDisabled = false;
      },2000)
      let that = this as any;
      (that.$refs.dataForm as any).validate((valid) => {
        if (valid) {
          let params = {} as any;
          params.username = this.form.username;
          params.address = this.form.address;
          params.age = this.form.age;
          params.company = this.form.company;
          params.dept = this.form.dept;
          params.deviceIds = this.form.deviceIds;
          params.gender = this.form.gender;
          params.ID = this.form.ID;
          params.orgId = this.form.orgId;
          params.password = this.form.password;
          params.telephone = this.form.telephone;
          params.realname = this.form.realname;
          params.state = this.form.state;
          params.remark = "string";

          if(this.form.roleId){
            params.roleId = this.form.roleId;
          }else{
            params.roleId = 1;
          }
          UserModule.UserAdd(params).then((data: any) => {
            console.log("添加成功",data);
            this.$message({
              showClose: true,
              // message: "添加用户成功",
              message: that.$t('globaltip.tipmsgAddUser'),
              type: 'success'
            });
            this.clear();
            this.$emit("inIt");
            this.dialogShowVisible = false;
          }).catch((err) => {

          });
        }
      })

   }
    handleCheckAllChange(val) {
      this.checkedCities = val ? this.checkedPermissions : [];
      this.isIndeterminate = false;
    }
    handleCheckedCitiesChange(value:any) {
      let checkedCount = value.length;
      this.checkAll = checkedCount === this.cities.length;
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
    }
    //清空表单
    clear(){
      let roleId = this.roleList[0].roleId
      let orgId = this.form.orgId;
      this.form = {
        ID: "",
        address: "",
        age: null,
        company: "",
        dept: "",
        deviceIds: [],
        gender: 1,
        orgId: orgId,
        password: "888888",
        realname: "",
        remark: "",
        roleId: roleId,
        state: 1,
        telephone: "",
        username: ""
      };
      this.dataUserIdsObj = {
        userIds: [],
        defaultIds: []
      } as any;
    }
    //取消按钮
    cancel(){
      this.clear();
      this.dialogShowVisible = false;
    }
    //选择角色
    selectRole(){
       if(this.form.roleId){

       }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  $bg: #2d3a4b;
  $light_gray: #eee;
.content{
  white-space: normal;
  word-break: break-word;
}
::v-deep .el-dialog__footer{
    text-align: center !important;
  }
::v-deep .el-dialog__body {
    padding: 0 0 20px 0 !important;
  }
::v-deep .el-input__inner{
    height: 32px;
  }
  .row{
    display: flex;
    justify-content: center;
    margin-top: 10px;
  }
  .el-col{
    line-height: 32px;
  }
  .sx{
    padding-left: 23%;
  }
  .active{
    color:#fc3d1a;
  }
::v-deep .add-user-tree{
    width: 192px;
  }

  .wrap{
    padding: 16px 0;
    /*border-top: solid 1px #8e99aa;*/
    border-bottom: solid 1px #8e99aa;
  }
  .wrap2{
    padding: 24px 0 0;
  }
  .option{
    font-weight: bolder;
    margin-bottom: 15px;
  }
  .wrap .line ::v-deep.el-input__inner,::v-deep.wrap .line .add-user-tree{
    width: 250px;
  }
::v-deep.add-user-tree{
    width: 250px!important;
  }
</style>
