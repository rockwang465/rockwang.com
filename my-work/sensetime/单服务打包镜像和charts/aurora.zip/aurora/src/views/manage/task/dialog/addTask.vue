<template>
    <el-dialog
    :title="$t('task.titleCreateTask')"
    :visible.sync="visible"
    custom-class="task-addtask"
    width="30%"
    :close-on-click-modal="false"
    :before-close="handleClose">
    <div class="task-addtask-flex" >
        <el-form ref="form" :model="form" label-position="right" :label-width="labelWidth" :rules="rule"
            :style="{width:language == 'en' && (form.taskType == 'pc' || form.taskType == 'pai' || form.taskType == 'vpi')?'425px':''}">
            <br/>
            <!-- 0:门禁;1:监控,2:行人区域入侵告警,3:行人越线 ,4:车辆违停,5:人群,6:人体静止-->
            <el-form-item :label="$tc('task.taskType')" prop="taskType">
                <el-select v-model="form.taskType" @change="taskTypeChange" style="width:100%" >
                    <el-option
                    v-for="ty in taskType"
                    :key="ty.id"
                    :label="ty.label"
                    :value="ty.name">
                    </el-option>
                </el-select>
            </el-form-item>
        </el-form>
    </div>
    <AddTaskTD :visible="form.taskType == 'td'" :label-width="labelWidth" ref="addtasktd" />
    <AddTaskAC :visible="form.taskType == 'ac'" :label-width="labelWidth"  ref="addtaskac" />
    <AddTaskPC :visible="form.taskType == 'pc'" :label-width="labelWidth" ref="addtaskpc" />
    <AddTaskPAI :visible="form.taskType == 'pai'" :label-width="labelWidth" ref="addtaskpai" />
    <AddTaskVPI :visible="form.taskType == 'vpi'" :label-width="labelWidth" ref="addtaskvpi" />
    <AddTaskCs :visible="form.taskType == 'cs'" :label-width="labelWidth" ref="addtaskcs" />
    <AddTaskHb :visible="form.taskType == 'hb'" :label-width="labelWidth" ref="addtaskhb" />
    <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="ensure" :loading="btnLoading">{{$t('task.buttonOK')}}</el-button>
        <el-button @click="hide()">{{$t('task.buttonCancel')}}</el-button>
    </span>
    </el-dialog>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {taskType} from '@/utils/constants.ts';
import i18n from '@/lang/index';
import {trim} from 'lodash';
import AddTaskTD from '../components/form/addTask-td.vue';
import AddTaskAC from '../components/form/addTask-ac.vue';
import AddTaskPC from '../components/form/addTask-pc.vue';
import AddTaskPAI from '../components/form/addTask-pai.vue';
import AddTaskVPI from '../components/form/addTask-vpi.vue';
import AddTaskCs from '../components/form/addTask-cs.vue';
import AddTaskHb from '../components/form/addTask-hb.vue';
import { AppModule } from '@/store/modules/app';
@Component({
    components: {
        AddTaskTD,
        AddTaskAC,
        AddTaskPC,
        AddTaskPAI,
        AddTaskVPI,
        AddTaskCs,
        AddTaskHb
    },
})
export default class AddTask extends Vue {
    /* props */
    @Prop({default:false}) visible!: boolean;
    @Prop({required:true }) currentModel!: string;
    /* watch */
    @Watch('visible',{ immediate: true})
    onVisibleChange(n,o){
        n && this.initData();
        !n && this.destoryData();
    }
    get language() {
        return AppModule.language;
    }
    /* data */
    labelWidth:string='155px';
    enFormWidth:any='';
    $refs!:{
        form:HTMLFormElement,
        addtasktd:HTMLFormElement,
        addtaskac:HTMLFormElement,
        addtaskpc:HTMLFormElement,
        addtaskpai:HTMLFormElement,
        addtaskvpi:HTMLFormElement,
        addtaskcs:HTMLFormElement,
        addtaskhb:HTMLFormElement,
    }
    form:any={
        taskType:this.currentModel,
    };
    rule:any={
        taskType:[
            { required: true, trigger: 'blur' },
        ],
    };
    taskType:any[]=taskType;
    showTDForm:boolean=true;
    btnLoading:boolean=false;
    /* methods */
    mounted(){

    }
    initData(){
        this.form.taskType = this.currentModel;
    }
    destoryData(){
        this.form.taskType = '';
    }
    handleClose(){
        this.hide();
    }
    hide(){
        this.$emit('hide');
        this.destoryData();
    }
    ensure(){
        this.form.taskType == 'td' && this.$refs.addtasktd.ensure(()=>{//start
            this.btnLoading = true;
        },()=>{//success
            this.hide();
            this.$emit('refreshTableData');
            this.btnLoading = false;
        },(err)=>{//error
            this.btnLoading = false;
        });
        this.form.taskType == 'ac' && this.$refs.addtaskac.submitData(()=>{//start
            this.btnLoading = true;
        },()=>{//success
            this.hide();
            this.$emit('refreshTableData');
            this.btnLoading = false;
        },(err)=>{//error
            this.btnLoading = false;
        });
        this.form.taskType == 'pc' && this.$refs.addtaskpc.submitData(()=>{//start
            this.btnLoading = true;
        },()=>{//success
            this.hide();
            this.$emit('refreshTableData');
            this.btnLoading = false;
        },(err)=>{//error
            this.btnLoading = false;
        });
        this.form.taskType == 'pai' && this.$refs.addtaskpai.submitData(()=>{//start
            this.btnLoading = true;
        },()=>{//success
            this.hide();
            this.$emit('refreshTableData');
            this.btnLoading = false;
        },(err)=>{//error
            this.btnLoading = false;
        });
        this.form.taskType == 'vpi' && this.$refs.addtaskvpi.submitData(()=>{//start
            this.btnLoading = true;
        },()=>{//success
            this.hide();
            this.$emit('refreshTableData');
            this.btnLoading = false;
        },(err)=>{//error
            this.btnLoading = false;
        });
        this.form.taskType == 'cs' && this.$refs.addtaskcs.submitData(()=>{//start
          this.btnLoading = true;
        },()=>{//success
          this.hide();
          this.$emit('refreshTableData');
          this.btnLoading = false;
        },(err)=>{//error
          this.btnLoading = false;
        });
        this.form.taskType == 'hb' && this.$refs.addtaskhb.submitData(()=>{//start
          this.btnLoading = true;
        },()=>{//success
          this.hide();
          this.$emit('refreshTableData');
          this.btnLoading = false;
        },(err)=>{//error
          this.btnLoading = false;
        });
    }

    taskTypeChange(v){

    }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.task-addtask-flex{
    display: flex;
    flex-direction: column;
    align-items: center;
}
::v-deep .task-addtask .el-dialog__body{
    display: block;
    max-height: 65vh;
    overflow-y: auto;
}
</style>
