<template>
    <div class="task-table-container">
        <div class="task-table-header">
            <div>
                <div v-if="!multipleModel" >
                    <el-button type="primary" @click="showAddDialog=true" v-if="getAddPermission()"> <i class="iconfont icon-add"  ></i> {{$t('task.taskMenuNewTask')}} </el-button>
                    <el-button type="primary" @click="showAddMultipleDialog=true" v-show="currentModel === 'td' && $permission('006318')" > <i class="iconfont icon-add" ></i> {{$t('task.taskMenuNewTaskBatch')}} </el-button>
                    <el-button type="primary" @click="multipleModel=true"
                     v-if="getMulDeletePermission() || getMulStartPermission() || getMulStopPermission()"
                     > <i class="iconfont icon-batch-handle" ></i> {{$t('task.taskMenuBatch')}} </el-button>
                </div>
                <div v-else>
                    <el-button type="text" @click="multipleBack"> <i class="iconfont icon-fanhui task-table-header-back" ></i></el-button>
                    <el-button type="danger" v-if="getMulDeletePermission()"  @click="deleteTasksBatch" :disabled="!$refs.tables || $refs.tables.selectedTasks.length ==0 "> <i class="iconfont icon-delete" ></i> {{$t('rule.buttonBatchDelete')}} </el-button>
                    <el-button type="primary" @click="startTasksBatch" v-if="getMulStartPermission()" :disabled="!$refs.tables || $refs.tables.selectedTasks.length ==0 "> <i class="iconfont icon-on-off" ></i> {{$t('rule.buttonBatchEnable')}} </el-button>
                    <el-button type="primary" @click="stopTasksBatch" v-if="getMulStopPermission()" :disabled="!$refs.tables || $refs.tables.selectedTasks.length ==0 "> <i class="iconfont icon-disable" ></i> {{$t('rule.buttonBatchDisable')}} </el-button>
                </div>
            </div>
            <div>
                {{$t('task.titleTotalTaskNumber')}} {{total}} | {{$t('task.titleActiveTaskNumber')}} {{enableTasks}}
            </div>
            <div>
                <el-input
                    :clearable="true"
                    :placeholder="$t('rule.textboxRulesetSearch')"
                    @keydown.native="keydown"
                    @clear="clear"
                    v-model="searchValue">
                    <i
                    style="cursor:pointer;"
                    class="el-input__icon el-icon-search"
                    slot="suffix"
                    @click="()=>inputKeywordChange(searchValue)">
                    </i>
                </el-input>
            </div>
        </div>
        <div class="task-table-contents" ref="tablecontents" >
            <Tables ref="tables" :showSelection="multipleModel" :tableData="tableData"
                :tableHeight="tableHeight"
                :currentModel="currentModel" :loading="tableLoading" @refreshTableData="refreshTableData"  />
            <el-pagination
            style="display:flex;justify-content: center;margin-top:8px"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="paginationPageSizes"
            :page-size="currentPageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
            </el-pagination>
        </div>
        <AddTask :visible="showAddDialog" @hide="showAddDialog = false" :currentModel="currentModel" @refreshTableData="refreshTableData" />
        <AddTaskMultiple :visible="showAddMultipleDialog" @hide="showAddMultipleDialog = false" @refreshTableData="refreshTableData" />
        <!-- messageBox delete -->
        <el-dialog
        :visible="showBatchDeleteDialog"
        :before-close="()=>this.showBatchDeleteDialog = false"
        width="400px">
            <p style="max-width:350px;text-align:center;line-height:20px;word-break: break-word;">{{$t('rule.popmsgRulesetDelete')}}</p>
            <div slot="title" >
                <span>{{$t('rule.listDelete')}}</span>
            </div>
            <span slot="footer">
                <el-button type="danger" @click="ensureDelete" :loading="deleteLoading">{{$t('rule.buttonOperationDelete')}}</el-button>
                <el-button @click="showBatchDeleteDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
            </span>
        </el-dialog>
        <!-- messageBox change status -->
        <el-dialog
        :visible="showBatchStatusDialog"
        :before-close="()=>this.showBatchStatusDialog = false"
        width="400px">
            <p style="max-width:350px;text-align:center;line-height:20px;">{{$tc('task.propChangeStatus')}}</p>
            <div slot="title" >
                <span>{{$t('rule.titleReminder')}}</span>
            </div>
            <span slot="footer">
                <el-button type="primary" @click="ensureChangeStatus" :loading="statusLoading">{{$t('rule.buttonOK')}}</el-button>
                <el-button @click="showBatchStatusDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch ,Prop} from 'vue-property-decorator';
import Tables from './components/tables.vue';
import {paginationPageSizes} from '@/utils/constants.ts';
import AddTask from './dialog/addTask.vue';
import AddTaskMultiple from './dialog/addTask-multiple.vue';
import {getTDTasks,getACTasks,getPAITasks,getPCTasks,getVPITasks,getCSTasks} from '@/api/task';
@Component({
    components: {
        Tables,
        AddTask,
        AddTaskMultiple
    },
})
export default class TaskTable extends Vue {
    /* props */
    @Prop({required:true }) currentModel!: string;

    /* watch */
    @Watch('currentModel')
    onVideoUrlChange(n,o){
        if(this.$refs.tables && this.$refs.tables.filterCondition) this.$refs.tables.filterCondition = {}; //reset filter
        this.searchValue = '';//reset filter
        this.currentPage = 1;//reset currentPage
        this.getTasks()
    }
    /* data */
    $refs !:{
        tables:HTMLFormElement
        tablecontents:HTMLFormElement
    };
    multipleModel:boolean=false;
    searchValue:string='';
    tableData:any[]= [];
    tableLoading:boolean=false;
    //pagination
    paginationPageSizes:number[] = paginationPageSizes;
    currentPage:number=1;
    currentPageSize:number = paginationPageSizes[0];
    total:number = 0;
    //menu
    // totalTasks:number=0;
    enableTasks:number = 0;
    //dialog
    showAddDialog:boolean=false;
    showAddMultipleDialog:boolean=false;
    showBatchDeleteDialog:boolean=false;
    showBatchStatusDialog:boolean=false;
    deleteLoading:boolean=false;
    statusLoading:boolean=false;
    batchStuts:string='';
    statusText:string='更改状态？';
    tableHeight:any=null;
    /* methods */
    mounted(){
        this.getTasks();
        let c_h = this.$refs.tablecontents.clientHeight - 50;
        c_h > 0 && (this.tableHeight = c_h);
    }
    multipleBack(){
        this.$refs.tables && this.$refs.tables.clearSelection();
        this.multipleModel=false;

    }
    getAddPermission(){
        return this.$permission('006301') || this.$permission('006314') || this.$permission('006327') || this.$permission('006328') || this.$permission('006329');
    }
    getMulDeletePermission(){
        let isShow = false;
        switch (this.currentModel) {
            case 'td':
                this.$permission('006417') && (isShow = true);
                break;
            case 'ac':
                this.$permission('006430') && (isShow = true);
                break;
            case 'pc':
                this.$permission('006426') && (isShow = true);
                break;
            case 'pai':
                this.$permission('006428') && (isShow = true);
                break;
            case 'vpi':
                this.$permission('006424') && (isShow = true);
            break;
            case 'cs':
                //暂时使用pc的权限，等待后端配置
                this.$permission('006426') && (isShow = true);
            break;
            default:
                break;
        }
        return isShow;
    }
    getMulStartPermission(){
        let isShow = false;
        switch (this.currentModel) {
            case 'td':
                this.$permission('006324') && (isShow = true);
                break;
            case 'ac':
                this.$permission('006348') && (isShow = true);
                break;
            case 'pc':
                this.$permission('006334') && (isShow = true);
                break;
            case 'pai':
                this.$permission('006338') && (isShow = true);
                break;
            case 'vpi':
                this.$permission('006330') && (isShow = true);
            break;
            case 'cs':
                //暂时使用pc的权限，等待后端配置
                this.$permission('006334') && (isShow = true);
            break;
            default:
                break;
        }
        return isShow;
    }
    getMulStopPermission(){
        let isShow = false;
        switch (this.currentModel) {
            case 'td':
                this.$permission('006325') && (isShow = true);
                break;
            case 'ac':
                this.$permission('006349') && (isShow = true);
                break;
            case 'pc':
                this.$permission('006335') && (isShow = true);
                break;
            case 'pai':
                this.$permission('006339') && (isShow = true);
                break;
            case 'vpi':
                this.$permission('006331') && (isShow = true);
            break;
            case 'cs':
                //暂时使用pc的权限，等待后端配置
                this.$permission('006335') && (isShow = true);
            break;
            default:
                break;
        }
        return isShow;
    }
    deleteTasksBatch(){
        this.showBatchDeleteDialog = true;
    }
    ensureDelete(){
        this.$refs.tables && this.$refs.tables.ensureBatchDeleteTasks(()=>{
            this.deleteLoading = true;
        },(res)=>{
            this.showBatchDeleteDialog = false;
            this.deleteLoading = false;
            this.getTasks()
        },(err)=>{
            this.showBatchDeleteDialog = false;
            this.deleteLoading = false;
        });
    }
    startTasksBatch(){
        this.batchStuts = 'start';
        this.showBatchStatusDialog = true;
    }
    stopTasksBatch(){
        this.batchStuts = 'stop';
        this.showBatchStatusDialog = true;
    }
    ensureChangeStatus(){
        this.$refs.tables && this.$refs.tables.ensureBatchChangeStatus(this.batchStuts,()=>{
          this.statusLoading = true;
        },(res)=>{
          this.showBatchStatusDialog = false;
          this.statusLoading = false;
          this.getTasks();
          //结构化 批量启动 部分失败提示语 //&& (this.currentModel === 'pc' || this.currentModel === 'pai' || this.currentModel === 'vpi')
          if(this.batchStuts === 'start' && res){
            res.failedList && res.failedList.length>0 && this.$message.error({showClose:true,message:this.$tc('task.messageErrorDevice')});
          }
        },(err)=>{
          this.showBatchStatusDialog = false;
          this.statusLoading = false;
        });
    }
    clear(){
        this.inputKeywordChange('');
    }
    keydown(e){
        e.keyCode == '13' && this.inputKeywordChange(this.searchValue);
    }
    inputKeywordChange(v){
        this.getTasks()
    }
    handleSizeChange(v){
        this.currentPageSize = v;
        this.getTasks();
    }
    handleCurrentChange(v){
        this.currentPage = v;
        this.getTasks();
    }
    getTasks(){
        let type = this.currentModel;
        this.tableLoading=true;
        this.tableData = [];
        switch (type) {
            case 'td':
                getTDTasks({page:this.currentPage,num:this.currentPageSize,...this.$refs.tables.filterCondition,keyWord:this.searchValue}).then((res:any)=>{
                    if(this.currentModel === 'td'){
                        res && res.list && (this.tableData = this.formatData(type,res.list)) && this.reloadingTaskData(res.list);
                        this.total = res.total;
                        this.enableTasks = res.enabledTaskNum;
                    }
                }).catch((err)=>{this.errorTableData()}).finally(()=>{this.tableLoading=false;});
                break;
            case 'ac':
                getACTasks({page:this.currentPage,num:this.currentPageSize,...this.$refs.tables.filterCondition,keyWord:this.searchValue}).then((res:any)=>{
                    if(this.currentModel === 'ac'){
                        res && res.list && (this.tableData = this.formatData(type,res.list)) && this.reloadingTaskData(res.list);
                        this.total = res.total;
                        this.enableTasks = res.enabledTaskNum;
                    }
                }).catch((err)=>{this.errorTableData()}).finally(()=>{this.tableLoading=false;});
                break;
            case 'pc':
                getPCTasks({page:this.currentPage,num:this.currentPageSize,...this.$refs.tables.filterCondition,keyWord:this.searchValue}).then((res:any)=>{
                    if(this.currentModel === 'pc'){
                        res && res.taskListVOList && (this.tableData = this.formatData(type,res.taskListVOList)) && this.reloadingTaskData(res.taskListVOList);
                        this.total = res.total;
                        this.enableTasks = res.enabledTaskNum;
                    }
                }).catch((err)=>{this.errorTableData()}).finally(()=>{this.tableLoading=false;});
                break;
            case 'pai':
                getPAITasks({page:this.currentPage,num:this.currentPageSize,...this.$refs.tables.filterCondition,keyWord:this.searchValue}).then((res:any)=>{
                    if(this.currentModel === 'pai'){
                        res && res.taskListVOList && (this.tableData = this.formatData(type,res.taskListVOList)) && this.reloadingTaskData(res.taskListVOList);
                        this.total = res.total;
                        this.enableTasks = res.enabledTaskNum;
                    }
                }).catch((err)=>{this.errorTableData()}).finally(()=>{this.tableLoading=false;});
                break;
            case 'vpi':
                getVPITasks({page:this.currentPage,num:this.currentPageSize,...this.$refs.tables.filterCondition,keyWord:this.searchValue}).then((res:any)=>{
                    if(this.currentModel === 'vpi'){
                        res && res.taskListVOList && (this.tableData = this.formatData(type,res.taskListVOList)) && this.reloadingTaskData(res.taskListVOList);
                        this.total = res.total;
                        this.enableTasks = res.enabledTaskNum;
                    }
                }).catch((err)=>{this.errorTableData()}).finally(()=>{this.tableLoading=false;});
            break;
          case 'cs':
            getCSTasks({page:this.currentPage,num:this.currentPageSize,...this.$refs.tables.filterCondition,keyWord:this.searchValue}).then((res:any)=>{
              if(this.currentModel === 'cs'){
                res && res.taskListVOList && (this.tableData = this.formatData(type,res.taskListVOList)) && this.reloadingTaskData(res.taskListVOList);
                this.total = res.total;
                this.enableTasks = res.enabledTaskNum;
              }
            }).catch((err)=>{this.errorTableData()}).finally(()=>{this.tableLoading=false;});
            break;
            default:
                break;
        }
    }
    reloadingTaskData(list){
        if(this.currentPage>1 && list.length ==0){
            this.currentPage --;
            this.currentPage>=1 && this.getTasks();
        }
    }
    errorTableData(){
        this.tableData = [];
        this.enableTasks = 0;
    }
    formatData(type,list){
        let arr:any[]=[];
        list.length>0 && list.map(item=>{
            type == 'td' && arr.push({
                taskId:item.taskId,
                taskName:item.taskName,
                device:item.deviceVo?item.deviceVo.deviceName:'',
                deviceGroup: item.deviceVo?this.formatGroupName(item.deviceVo.deviceGroupList):'',
                specialAttribute:this.formatSpecialAttribute(item.taskAttributeVos),
                libNumber:item.libraryNum,
                threshold:item.threshold || 0,
                enableStatus:item.taskStatus,
                backgroundImage:item.backgroundImage||''
            })
            type == 'ac' && arr.push({
                taskId:item.taskId,
                taskName: item.taskName,
                device: item.deviceVo.deviceName,
                deviceGroup: this.formatGroupName(item.deviceVo.deviceGroupList),
                specialAttribute:this.formatSpecialAttribute(item.taskAttributeVos),
                timezoneNumber:item.timeZoneNum,
                libNumber:item.libraryNum,
                threshold:item.threshold,
                enableStatus:item.taskStatus
            })
            type == 'pc' && arr.push({
                taskId:item.taskId,
                taskName: item.taskName,
                device: item.deviceVo.deviceName,
                deviceGroup: this.formatGroupName(item.deviceVo.deviceGroupList),
                specialAttribute:this.formatSpecialAttribute(item.taskAttributeVos),
                enableStatus:item.taskStatus
            })
            type == 'pai' && arr.push({
                taskId:item.taskId,
                taskName: item.taskName,
                device: item.deviceVo.deviceName,
                deviceGroup: this.formatGroupName(item.deviceVo.deviceGroupList),
                specialAttribute:this.formatSpecialAttribute(item.taskAttributeVos),
                enableStatus:item.taskStatus
            })
            type == 'vpi' && arr.push({
                taskId:item.taskId,
                taskName: item.taskName,
                device: item.deviceVo.deviceName,
                deviceGroup: this.formatGroupName(item.deviceVo.deviceGroupList),
                timeLimit:item.violateStopTime,
                specialAttribute:this.formatSpecialAttribute(item.taskAttributeVos),
                enableStatus:item.taskStatus
            })
            type == 'cs' && arr.push({
              taskId:item.taskId,
              taskName: item.taskName,
              device: item.deviceVo.deviceName,
              deviceGroup: this.formatGroupName(item.deviceVo.deviceGroupList),
              threshold:item.threshold,
              // duration:item.duration,
              enableStatus:item.taskStatus,
              thresholdUnit:item.thresholdUnit,
              // durationUnit:item.durationUnit
              // timeLimit:item.violateStopTime,
              // enableStatus:item.taskStatus
            })
        })
        return arr;
    }
    formatGroupName(deviceGroupList){
        let groupName:string='',groupNames:string='',len = deviceGroupList.length;
        groupName = deviceGroupList[len-1].name;
        deviceGroupList.map((item,itemIndex)=>{
        groupNames+=item.name+(itemIndex == (len -1)?'':' > ');
        });
        return {groupName,groupNames};
    }
    formatSpecialAttribute(attrs){
        let str = '';
        attrs && attrs.map(item=>{
        str= str+' '+this.$tc(`rule.${item.taskAttributeName}`);
        });
        return str;
    }
    refreshTableData(filterConditionChange?:false){
        filterConditionChange && (this.currentPage = 1);
        this.getTasks()
    }


}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
    .task-table-container{
        width: calc(100% - 312px);
        height: 100%;
        padding-bottom: 24px;
        padding-right: 16px;
        .task-table-header{
            padding-top: 16px;
            padding-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            .task-table-header-back{
                color: $--color-black;
                font-weight: 600;
            }
        }
        .task-table-contents{
            height: calc(100% - 65px);
            @include shadowBox();
            .tables-container{
                height: calc(100% - 48px);
            }
        }

    }
    // ::v-deep .el-input__suffix-inner{
    //     display: flex;
    //     flex-direction: row-reverse;
    //     align-items: center;
    //     .el-input__icon.el-input__clear{
    //         position: static;
    //     }
    // }
</style>
