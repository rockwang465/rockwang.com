<template>
  <div>
    <!--人像详情弹框-->
    <el-dialog
      :title="$t('devicemanagement.titleDetail')"
      :visible.sync="dialogShowVisible"
      class="isroll"
      :width="formLabelWidth">
      <div class="content">
        <div class="bianji">
          <el-button v-if="$permission('008209')" type="primary" @click="showEdit"><i class="iconfont icon-bianji"></i>{{$t('devicemanagement.titleEdit')}}</el-button>
          <!--编辑按钮-->
        </div>
        <div class="showId">
          <div v-if="!isShowId" @click="idShowOrHid('show')"><i class="iconfont icon-eye" style="font-size:14px;color:#2A5AF5"></i></div>
          <div v-else @click="idShowOrHid('hide')"><i class="iconfont icon-eye" style="font-size:14px;"></i></div>
        </div>
        <div class="top">
          <div class="avatar">
            <img :src="processImgurl(detailsInfo.imageUrl)">
          </div>
          <div class="person">
            <div class="personList">
              <span :class="formLabelWidth2">{{$t('imagemanagement.contName')}}</span>
              <el-tooltip class="item" v-if="detailsInfo.name&&detailsInfo.name.length>10" effect="dark" :content="detailsInfo.name" placement="top">
                <span class="right">{{detailsInfo.name?detailsInfo.name:' '}}</span>
              </el-tooltip>
              <span class="right" v-else>{{detailsInfo.name?detailsInfo.name:' '}}</span>
            </div>
            <div class="personList">
              <span :class="formLabelWidth2">{{$t('imagemanagement.contAlias')}}</span>
              <el-tooltip class="item" v-if="detailsInfo.aliasName&&detailsInfo.aliasName.length>10" effect="dark" :content="detailsInfo.aliasName" placement="top">
                <span class="right">{{detailsInfo.aliasName?detailsInfo.aliasName:' '}}</span>
              </el-tooltip>
              <span class="right" v-else>{{detailsInfo.aliasName?detailsInfo.aliasName:' '}}</span>
            </div>
            <div class="personList">
              <span :class="formLabelWidth2">{{$t('imagemanagement.contID')}}</span>
              <el-tooltip class="item" v-if="detailsInfo.ID&&detailsInfo.ID.length>10" effect="dark" :content="detailsInfo.ID" placement="top">
                <span class="right">{{detailsInfo.ID?detailsInfo.ID:' '}}</span>
              </el-tooltip>
              <span class="right" v-else>{{detailsInfo.ID?detailsInfo.ID:' '}}</span>
            </div>
            <div class="personList">
              <span :class="formLabelWidth2" style="height: 60px;">{{$t('imagemanagement.contImageLibrary')}}</span>
              <span class="right" style="height: 60px; overflow: auto;">
                <div style="position: absolute;top: 0;">
                  <span class="detailsLibraryName" style="display: block;position: relative;height: 100%;" v-for="(item,index) in detailsInfo.libraryVos" :key="index">
                     <el-tooltip class="item" v-if="item.name&&item.name.length>16" effect="dark" :content="item.name" placement="top">
                       <span>{{item.name ? item.name : " "}}</span>
                     </el-tooltip>
                    <span v-else>{{item.name ? item.name : " "}}</span>
                </span>
                </div>
              </span>
            </div>
          </div>
        </div>
        <div class="mid">
          <div class="title">{{$t('imagemanagement.contOtherInfo')}}</div>
          <div class="midcontent">
            <div class="mid-left">
              <div class="personList">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contGender')}}</span>
                <span class="right" v-show="detailsInfo.gender== 1">{{$t('imagemanagement.contMale')}}</span>
                <span class="right" v-show="detailsInfo.gender== 2">{{$t('imagemanagement.contFemale')}}</span>
                <!--未知-->
                <span class="right" v-show="detailsInfo.gender== 3">{{$t('imagemanagement.contUnknown')}}</span>
              </div>
              <!--公司-->
              <div class="personList">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contCompany')}}</span>
                <el-tooltip class="item" v-if="detailsInfo.company&&detailsInfo.company.length>10" effect="dark" :content="detailsInfo.company" placement="top">
                  <span class="right">{{detailsInfo.company?detailsInfo.company:' '}}</span>
                </el-tooltip>
                <span class="right" v-else>{{detailsInfo.company?detailsInfo.company:' '}}</span>
              </div>
              <!--联系方式-->
              <div class="personList" style="width: 180%;">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contContact')}}</span>
                <el-tooltip class="item" v-if="detailsInfo.phone&&detailsInfo.phone.length>10" effect="dark" :content="detailsInfo.phone" placement="top">
                  <span class="right">{{detailsInfo.phone?detailsInfo.phone:' '}}</span>
                </el-tooltip>
                <span class="right right2" v-else>{{detailsInfo.phone?detailsInfo.phone:' '}}</span>
              </div>
              <!--住址-->
              <div class="personList" style="width: 180%;">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contAddress')}}</span>
                <el-tooltip class="item" v-if="detailsInfo.address&&detailsInfo.address.length>10" effect="dark" :content="detailsInfo.address" placement="top">
                  <span class="right">{{detailsInfo.address?detailsInfo.address:' '}}</span>
                </el-tooltip>
                <span class="right right2" v-else>{{detailsInfo.address?detailsInfo.address:' '}}</span>
              </div>
              <!--启用/禁用-->
              <div class="personList" v-show="worb">
                <span :class="formLabelWidth2">{{$t('imagemanagement.EnabledAndDisabled')}}</span>
                <span class="right">{{detailsInfo.enableState == 1?$t('rule.buttonRuleStausEnabled'):$t('rule.buttonRuleStausDisabled')}}</span>
              </div>
              <div class="personList" v-show="worb">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contTimeActivation')}}</span>
                <span class="right">{{detailsInfo.activationTime?detailsInfo.activationTime:' '}}</span>
              </div>
              <div class="personList" v-show="worb">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contTimeExpiration')}}</span>
                <span class="right">{{detailsInfo.expirationTime?detailsInfo.expirationTime:' '}}</span>
              </div>
            </div>
            <div class="mid-right">
              <div class="personList">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contAge')}}</span>
                <span class="right">{{detailsInfo.age}}</span>
              </div>
              <!--部门-->
              <div class="personList">
                <span :class="formLabelWidth2">{{$t('imagemanagement.contDepartment')}}</span>
                <el-tooltip class="item" v-if="detailsInfo.dept&&detailsInfo.dept.length>10" effect="dark" :content="detailsInfo.dept" placement="top">
                  <span class="right">{{detailsInfo.dept?detailsInfo.dept:' '}}</span>
                </el-tooltip>
                <span class="right" v-else>{{detailsInfo.dept?detailsInfo.dept:' '}}</span>
              </div>
              <!--车牌号-->
              <div class="personList">
                <span :class="formLabelWidth2">{{$t('visitor.visitorlist.labelCarNumber')}}</span>
                <span class="right">{{detailsInfo.vehiclePlateNumber}}</span>
              </div>
            </div>
          </div>
        </div>

      </div>
      <span slot="footer" class="dialog-footer">
        <!--复制到分组-->
        <el-button v-if="$permission('008312')" type="primary" @click="copyPortraitGroup"><i class="iconfont icon-fuzhi"></i>{{$t('imagemanagement.CopyToGroup')}}</el-button>
        <el-button v-if="$permission('008410')" type="danger" class="deleteBtn" @click="portraitDelete">{{$t('imagemanagement.buttonDelete')}}</el-button>
      <el-button @click="dialogShowVisible = false" type="info" class="cancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>

<!--    输入密码显示id弹窗-->
    <el-dialog
      :title="$t('imagemanagement.importPassWord')"
      :visible.sync="isShowIdVisible"
      >
      <el-form :model="pwd" :rules="ruleList" ref="pwdForm" label-width="150px" @submit.native.prevent>
        <el-form-item :label="$t('imagemanagement.userPassWord')" prop="password">
          <el-input type="password" v-model="pwd.password"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="deleteBtn" @click="showIdFn">{{$t('imagemanagement.buttonOK')}}</el-button>
        <el-button @click="isShowIdVisible = false" type="info" class="cancel">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--人像详情弹框-->
    <!--人像编辑组件-->
    <portraitEdit :dialogVisible="showPortraitEdit" @showPortraitList="getDetails" :libraryId="libraryId" :libraryType="libraryType" :treeData="treeList" :dataObj="detailsInfo" @closePortraitEdit="closePortraitEdit"></portraitEdit>
    <!--人像编辑组件-->
    <!--人像删除组件-->
    <portraitDelete :dialogVisible="showPortraitDelete" :libraryId="libraryId" :dataObj="detailsInfo" @handleDeletePortrait="handleDeletePortrait" @closePortraitDelete="closePortraitDelete"></portraitDelete>
    <!--人像删除组件-->
    <!--添加人像分组组件-->
    <AddPersonGroup :dialogVisible="showPortraitGroup" :type="libraryType" :propTreeData="treeList" :idArr="idArr" :dataObj="treeData" @closeEdit="closeAddGroup" @handleActive="handleAddGroup"></AddPersonGroup>
    <!--添加人像分组组件-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';

  import portraitEdit from './portraitEdit.vue';

  import portraitDelete from './portraitDelete.vue';

  import AddPersonGroup from '@/components/addPersonGroup/index.vue'

  import {PortraitModule} from '@/store/modules/portrait';

  import {UserModule} from '@/store/modules/user';

  import {AppModule} from '@/store/modules/app';

  import {processImgurl} from '@/utils/image.ts';

  import {encryption} from '@/utils/encryption.ts';

  import { Form as ElForm } from 'element-ui';
  import i18n from "@/lang";

  @Component({
    components:{
      portraitEdit,  //人像详情编辑
      portraitDelete, //人像删除
      AddPersonGroup       //添加人像分组
    },
    computed:{
      formLabelWidth: function () {
        let that = this as any;
        return that.language == 'en' ? '684px' : '584px';
      },
      formLabelWidth2: function () {
        let that = this as any;
        return that.language == 'en' ? 'left2' : 'left';
      }
    }
  })
  export default class portraitDetails extends Vue {
    get language() {
      return AppModule.language;
    }
    get vm(){
      return this;
    }
    dialogShowVisible:boolean = false;
    showPortraitDelete = false;
    showPortraitGroup = false;
    showPortraitEdit = false;
    processImgurl:any=processImgurl;
    idArr = [] as any;
    worb = true;
    isShowId:boolean = false;
    isShowIdVisible:boolean = false;
    pwd = {
      password: ''
    };
    ruleList = {
      password:[
        { required: true, message: i18n.t('imagemanagement.passWordImport')+"", trigger: 'blur' }
      ]
    };
    addGroupObj = {
      title: '添加',
      treeData: [] as any
    };
    detailsInfo = {} as any;
    idStr:string = '';
    type = 1;
    encryption = encryption;
    @Prop(Number) targetId!: any;
    @Prop(Number) libraryId!: any;
    @Prop(Object) treeData!: any;
    @Prop(Array) treeList!: any;
    @Prop(Number) libraryType!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    @Prop({required: true, default: false}) portraitInfo!: object;
    //点击人像详情的复制分组
    copyPortraitGroup(){
      this.showPortraitGroup = true;
    }
    //点击人像详情的删除按钮
     portraitDelete(){
      this.showPortraitDelete = true;

    }
    //关闭删除按钮
    closePortraitDelete(){
      this.showPortraitDelete = false;
    }

    @Watch('isShowIdVisible')
    onIsShowIdVisibleChange(val: any) {
      this.$nextTick(()=>{
        (this.$refs.pwdForm as ElForm).clearValidate();
      })
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      console.log(this)
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closePortraitDetails")
      }
    }
    @Watch('portraitInfo')
    onPortraitInfoChange(val: any) {
      this.detailsInfo = val;
      this.idStr = val.ID
      console.log(this.detailsInfo);
    }
    @Watch('targetId')
    onTargetIdChange(val: any) {
      this.idArr = [val];
      console.log(this.idArr);
    }
    @Watch('libraryType')
    onLibraryTypeChange(val: any) {
      if (val == 2){
        this.worb = false
      }
    }
    //点击打开编辑
    showEdit(){
      this.showPortraitEdit = true;
    }
    //关闭编辑
    closePortraitEdit(){
       this.showPortraitEdit = false;
    }
    //操作分组
    handleAddGroup(data) {
      console.log(data)
    }
    //人像信息更改后再次请求人像详情接口
    getDetails(){
      this.$emit('getPortraitDetails');
      this.$emit("inIt");
    }
    //删除人像
    handleDeletePortrait(deleteObj : any){
      let dataObj = {} as any;
      if(deleteObj.title == "分组删除"){
        this.type = 1;
      }
      if(deleteObj.title == "人像库删除"){
        this.type = 2;
      }
      dataObj.params = {
        libraryId: this.libraryId,
        type: this.type
      };
      dataObj.id = this.targetId;
      let that = this as any;
      PortraitModule.ProtraitDelete(dataObj).then((data: any) => {
        console.log("列表数据",data);
        this.$message({
          showClose: true,
          // message: "删除人像成功",
          message:that.$t('globaltip.tipmsgDeleteImage'),
          type: 'success'
        })
        this.dialogShowVisible = false;
        this.$emit("inIt");
      }).catch((err) => {

      });
    }
    //关闭分组
    closeAddGroup() {
      this.showPortraitGroup = false;
    }

    //id的展示加密与隐藏加密
    idShowOrHid(str:string){
      if (str === 'show'){
        // this.isShowId = true;
        this.isShowIdVisible = true;
      }else if(str === 'hide'){
        this.isShowId = false;
        this.detailsInfo.ID = this.idStr;
      }
    }
    showIdFn(){
      (this.$refs.pwdForm as ElForm).validate((valid) => {
        if (valid) {
          let params = {
            password:'',
            secret:''
          };
          params.password = this.pwd.password;
          params.secret = this.detailsInfo.cipherText;
          UserModule.getPortraitId(params).then((res)=>{
            this.detailsInfo.ID = (res as any).decryptStr;
            this.isShowId = true;
          }).finally(()=>{
            this.isShowIdVisible = false;
            this.pwd.password = '';
          })
        }else {
          return false;
        }
      });
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  /*.content>div{*/
    /*width: 45%;*/
  /*}*/
  /*.content>div span{*/
    /*width: 100%;*/
    /*display: flex;*/
    /*line-height: 16px;*/
    /*margin-top: 10px;*/
  /*}*/
  .content{
    margin: 0 auto;
    position: relative;
    width: 94%;
  }
  .bianji{
    position: absolute;
    right: -5px;
    top: 35px;
  }
  .showId{
    width:80px;
    position: absolute;
    right: -5px;
    top: 100px;
    div{
      cursor: pointer;
      user-select: none;
    }
  }
  .content .top{
    width: 520px;
    height: 224px;
    padding:32px 0;
    box-sizing: border-box;
    display: flex;
  }
  .top .avatar{
    width: 120px;
    height: 160px;
    margin: 0 40px;
  }
  .top .avatar img{
    width: 100%;
    height: 100%;
  }
  .content .top .person{
    height: 160px;
  }
  .content .personList{
    height: 20px;
    padding: 6px 0;
    box-sizing: content-box;
    display: flex;
    position: relative;
    .detailsLibraryName{
      width: 140px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }
  .content .left{
    font-weight: 800;
    display: block;
    /*display: inline-block;*/
    text-align: right;
    width: 72px;
    margin-right: 10px;
    height: 100%;
  }
  .content .left2{
    text-align: right;
    margin-right: 10px;
    font-weight: 800;
    display: block;
    /*display: inline-block;*/
    width: 155px;
    height: 100%;
  }
  .content .right{
    display: block;
    /*display: inline-block;*/
    color: #28354d;
    opacity: 0.8;
    position: relative;
    width: 142px;
    height: 100%;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  // .content .right2{
  //   /*width: 80%;*/
  // }
  .content .mid{
    /*width: 93%;*/
    border-top: solid 1px #8e99aa;
    padding:32px 0;
    box-sizing: border-box;
  }
  .content .mid .title{
    height: 32px;
    margin-left: 40px;
    font-weight: 800;
    text-align: left;
  }
  .content .mid .midcontent{
    width: 100%;
    margin: 17px 0 0 40px;
    display: flex;
  }
  .midcontent .mid-left{
    width: 50%;
  }
  .midcontent .mid-right{
    width: 50%;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  .content .personInfo{
    width: 100%;
  }
  .personPic{
    height: 160px;
    width: 120px;
    background-size:cover;
    background-repeat: no-repeat;
    background-position:center;
  }
  .personInfo-key>div{
    line-height: 24px;
    color: #28354d;
  }
  .personInfo-value>div{
    line-height: 24px;
    color:rgba(162,176,199,0.8);
  }
  .ku{
    width: 100px;
  }
  .content > .middle{
    width: 100%;
    height: 1px;
    background-color:#ccc;
    margin: 30px 0 20px 0;
  }
  .content .property{
    width: 100%;
    margin-bottom: 24px;
  }
  .content .list{
    width: 100%;
  }
  .list div{
    line-height: 24px;
  }
  .deleteBtn{
    margin: 0 0 0 72px !important;
  }
  ::v-deep .cancel{
    background-color:rgba(162,176,199,0.3) !important;
  }
  .content .title{
    width: 100%;
    text-align: center;
    line-height: 24px;
  }
  .content .tree ::v-deep .filter-tree{
    border: none !important;
    height: 155px;
  }
</style>
