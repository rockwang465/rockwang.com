<template>
  <div>
    <el-dialog :title="$t('rolemanagement.buttonOperationView')" :visible.sync="dialogShowVisible"
               :width="language == 'en' ? '700px' : '584px'">
      <el-form label-position="right" style="padding-top: 20px;height: calc(100% - 100px);max-height: 600px;min-height: 200px;">
        <el-form-item :label="$t('rolemanagement.contRoleName')" :label-width="language == 'en' ? '200px' : '140px'">
          <!--角色名称-->
          {{localObject.name}}
        </el-form-item>
        <div class="role-permission">
          <el-form-item v-for="item in localObject.permissionOptions" :label="item.moduleName" :key="item.moduleCode"
                        :label-width="language == 'en' ? '200px' : '140px'">
            <el-checkbox-group v-model="localObject.checkedArray">
              <el-checkbox v-for="i in item.moduleArray" :label="i.onlyCode" :key="i.onlyCode" disabled>
                {{i.typeName}}
              </el-checkbox>
            </el-checkbox-group>
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" v-if="$permission('002211')" @click="toRoleEdit">{{$t('rolemanagement.buttonOperationEdit')}}</el-button>
        <el-button type="info" @click="dialogShowVisible = false">{{$t('rolemanagement.buttonCancel')}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch, Prop} from 'vue-property-decorator';
  import {AppModule} from '@/store/modules/app';


  @Component({

  })
  export default class RoleAdd extends Vue {
    get language() {
      return AppModule.language;
    }

    @Prop(Object) localObject!: any[];
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    dialogShowVisible = false;
    formLabelWidth = this.language == 'en' ? '200px' : '140px';
    checkedData = []

    toRoleEdit() {
      let that = this as any;
      that.dialogShowVisible = false;
      this.$emit("detailToEditRole",that.localObject)
    }

    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      console.log(this.localObject)
      this.dialogShowVisible = val;
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeRoleDetail")
      }
    }


  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  ::v-deep .el-dialog__footer {
    text-align: center !important;
  }

  ::v-deep .el-input__inner {
    height: 32px !important;
  }

  .role-permission ::v-deep .el-form-item__label{
    font-weight: 400;
  }
</style>
