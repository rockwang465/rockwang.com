<template>
  <div>
    <!--人像详情点击删除弹框-->
    <el-dialog
      :title="$t('imagemanagement.buttonDelete')"
      :visible.sync="dialogShowVisible"
      width="30%">
      <div class="content">
        <el-row class="title">{{$t('imagemanagement.popmsgImageDelete1')}}</el-row>
        <el-row class="title">{{$t('imagemanagement.popmsgImageDelete2')}}</el-row>
        <el-row class="title">{{$t('imagemanagement.popmsgImageDelete3')}}</el-row>
        <!--<el-row class="title">从当前分组删除，所选人像在黑/白名单其他分组中仍可找到</el-row>-->
        <!--<el-row class="title">从人像库删除，所选人像将不再存在于黑/白名单中</el-row>-->
      </div>
      <span slot="footer" class="dialog-footer" style="display: flex;justify-content: center">
        <!--仅从组中删除-->
        <el-button type="danger" v-show="libraryId" @click="deleteOne">{{$t('imagemanagement.buttonPicDeleteGroup')}}</el-button>
        <!--从人像库中删除-->
        <el-button type="danger" @click="portraitDelete">{{$t('imagemanagement.buttonPicDeleteLibrary')}}</el-button>
      <el-button class="cancel" type="info" @click="dialogShowVisible  = false">{{$t('imagemanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
    <!--人像详情点击删除弹框-->
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';

  @Component({

  })
  export default class portraitDetails extends Vue {
    dialogShowVisible = false;
    showPortraitDelete = false;
    @Prop(Object) dataObj!: any;
    @Prop(Number) libraryId!: any;
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    //点击人像详情的删除按钮
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      console.log(this.dataObj);
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closePortraitDelete")
      }
    }
    //分组删除
    deleteOne(){
      this.dialogShowVisible = false;
      this.dataObj.title = "分组删除";
      this.$emit("handleDeletePortrait",this.dataObj);
      console.log(this.dataObj);
    }
    portraitDelete(){
      this.dialogShowVisible = false;
      this.dataObj.title = "人像库删除";
      this.$emit("handleDeletePortrait",this.dataObj);
    }
  }


</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  $bg: #2d3a4b;
  $light_gray: #eee;
  .content>div{
    width: 45%;
  }
  .content>div span{
    width: 100%;
    display: flex;
    line-height: 16px;
    margin-top: 10px;
  }
  .content .left span{
    padding-left: 70%;
    font-weight: 600;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  .content .personInfo{
    width: 100%;
  }
  .personPic{
    height: 160px;
    width: 120px;
    background:url("https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3727379540,3698536131&fm=27&gp=0.jpg") no-repeat center;
    background-size:100%;
    margin:0 auto;
  }
  .personInfo-key>div{
    line-height: 24px;
    color: #28354d;
  }
  .personInfo-value>div{
    line-height: 24px;
    color:rgba(162,176,199,0.8);
  }
  .content > .middle{
    width: 100%;
    height: 1px;
    background-color:#ccc;
    margin: 30px 0 20px 0;
  }
  .content .property{
    width: 100%;
    margin-bottom: 24px;
  }
  .content .list{
    width: 100%;
  }
  .list div{
    line-height: 24px;
  }
  ::v-deep .delete{
    margin: 0 36px !important;
  }
  ::v-deep .cancel{
    background-color:rgba(162,176,199,0.3) !important;
  }
  .content .title{
    width: 100%;
    text-align: center;
    line-height: 24px;
  }
  .content .tree ::v-deep .filter-tree{
    border: none !important;
    height: 155px;
  }
</style>
