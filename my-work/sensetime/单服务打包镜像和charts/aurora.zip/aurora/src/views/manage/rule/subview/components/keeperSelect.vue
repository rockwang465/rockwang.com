<template>
  <div class="rule-components-keeperselect" >
    <!-- input -->
    <div :class="['rule-components-keeperselect-input',isFocus?'is-focus':'']" v-clickoutside="handleClickOutside" @click="handleClickInputBox" >
      <span class="rule-components-keeperselect-input-text" > {{ checkedDevices.length>0 ? $t('rule.textboxNumberSelected',{number:checkedDevices.length}):$t('rule.contPleaseSelect')}} </span>
      <span class="rule-components-keeperselect-input-suffix">
        <i :class="['el-icon-arrow-down', ariaExpanded?'is-reverse':'']"></i>
      </span>
      <!-- popover -->
      <transition name="slide-fade">
        <div class="rule-components-keeperselect-popover" v-show="ariaExpanded" @mouseenter="hoverInterPopover = true" @mouseleave="hoverInterPopover = false" >
          <div class="rule-components-keeperselect-popover-popper__arrow" ></div>
          <div class="rule-components-keeperselect-popover-popper__keepercontent" >
            <div class="rule-components-keeperselect-devicelist" >
              <div class="rule-components-keeperselect-listtile devicetitle" >{{$t('rule.contAssociatedKeeper')}}</div>
              <el-tree
                :props="{disabled:nodeDisabled}"
                class="rule-components-keeperselect-content"
                @check-change="checkChange"
                ref="tree"
                :data="devices"
                node-key="id"
                :default-checked-keys="checkedDevices"
                :show-checkbox="true"
                @node-click="clickDeviceTreeNode"
                :render-content="renderDeviceTreeContent">
              </el-tree>
            </div>
            <div class="rule-components-keeperselect-timeslist" >
              <div class="rule-components-keeperselect-listtile timeslisttitle" >{{$t('rule.labelTimezoneList')}}</div>
              <ul class="rule-components-keeperselect-content">
                <li v-if="timzonesList.length == 0" style="text-align:center;">No Data</li>
                <li v-for="(timezone,timemezoneIndex) in timzonesList" :class="['rule-components-keeperselect-datalist',timezone.isCurrent?'is-current':'']" :key="timemezoneIndex" @click="clickTimezone(timezone)" >
                  <span class="rule-components-keeperselect-text" :title="timezone.name">{{timezone.name}}</span>
                  <span class="icon-box" >
                    <i v-show="timezone.isCurrent" class="icon-font el-icon-caret-right" ></i>
                  </span>
                </li>
              </ul>
            </div>
            <div class="rule-components-keeperselect-libslist" >
              <div class="rule-components-keeperselect-listtile libslisttitle" >{{$t('rule.labelImageLibraryList')}}</div>
              <ul class="rule-components-keeperselect-content">
                <li v-if="libsList.length == 0" style="text-align:center;">No Data</li>
                <li v-for="(lib,libIndex) in libsList" class="rule-components-keeperselect-datalist" :key="libIndex" >{{lib.libraryName}}</li>
              </ul>
            </div>
          </div>
        </div>
      </transition>
    </div>

  </div>
</template>

<script lang="tsx">
import { Component, Vue,Watch ,Prop} from 'vue-property-decorator';
import {EventBus} from '@/utils/eventbus';
import Clickoutside from 'element-ui/src/utils/clickoutside';
import {getRuleListByKeepers} from '@/api/rule';

@Component({
  components: {

  },
  directives:{
    Clickoutside
  }
})

export default class KeeperSelect extends Vue {

  /* props */
  @Prop({default:[],required:false}) devices!: any;
  @Prop({default:[],required:false}) checkedDevices!: any;
  @Prop({default:'',required:false}) type!: string;

  /* watch */

  /* data */
  $refs !:{
    tree:HTMLFormElement
  }
  ariaExpanded:boolean=false;
  isFocus:boolean=false;
  hoverInterPopover:boolean=false;
  timzonesList:any[]=[];
  libsList:any[]=[];
  /* methods */
  mounted() {

  }
  destroyed() {

  }
  handleClickInputBox(){
    if (this.hoverInterPopover) return false;
    this.ariaExpanded = !this.ariaExpanded;
    this.isFocus = true;
  }
  handleClickOutside(e){
    this.ariaExpanded = false;
    this.isFocus = false;
    this.$emit('blur',e)
  }
  renderDeviceTreeContent(h, { node, data, store }){//type=0 ->group  type=1 -> device
    node.isLeaf = data.type == 1;
    return (
      <div style="display:flex;flex-wrap:nowrap;flex-direction:row;">
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width: 94px;" title={data.name}>{data.name}</span>
        {node.isCurrent && node.isLeaf && <span style="position:absolute;left:140px;background-color: #E8EBF5;"> <i class="icon-font el-icon-caret-right" ></i> </span>}
      </div>
    );
  }
  nodeDisabled(data,node){
    return this.type === 'view';
  }
  clickDeviceTreeNode(data,node,self){
    this.timzonesList=[];
    this.libsList = [];
    if(!data.type) {
      return false;
    };
    this.$refs.tree.setCurrentKey(data.id);
    if(data.type == 1 && data.id){
      getRuleListByKeepers([data.id]).then((res:any)=>{
        let ac_task_list = res.list,arr:any[]=[];
        ac_task_list && ac_task_list.map(item=>{
          if(item.timezoneLibraryRelation) arr = arr.concat(item.timezoneLibraryRelation);
        });
        ac_task_list && this.transformTimezoneLibraryRelation(arr);
      })
    }
  }
  transformTimezoneLibraryRelation(timezoneLibraryRelation:any[]){
    timezoneLibraryRelation.map((relation:any)=>{
      relation.timezoneVo && this.timzonesList.push({
        id:relation.timezoneVo.timeZoneId,
        name:relation.timezoneVo.timeZoneName,
        children:relation.libraryVos,//libs -> [{libraryId:1,libraryName:'libraryName',libraryType:1}]
        isCurrent:false
      });
    })
  }
  clickTimezone(timezone){
    this.libsList = [];
    this.libsList = timezone.children;
    //current
    this.timzonesList.map(item=>{
      if(timezone.id == item.id) {
        item.isCurrent = true;
      }else{
        item.isCurrent = false;
      }
    })
  }
  checkChange(data,check,checkChild){
    let checkedKeys = this.$refs.tree.getCheckedKeys(true);
    data.type == 1 && this.$emit('selecte',checkedKeys);
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.rule-components-keeperselect{

  cursor: pointer;
  .rule-components-keeperselect-input{
    position: relative;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    border:1px solid #c2cad8;
    color: #606266;
    border-radius: 2px;
    box-sizing: border-box;
    justify-content: space-between;
    &.is-focus{
      border-color: #2a5af5;
    }
    .rule-components-keeperselect-input-text{
      padding: 0 15px;
      height: 30px;
    }
    .rule-components-keeperselect-input-suffix{
      padding: 0 10px;
      color: #c0c4cc;
      .el-icon-arrow-down{
        transition: transform .3s;
      }
      .is-reverse{
        transform: rotate(180deg);
      }
    }
    .rule-components-keeperselect-popover{
      width: 520px;
      margin-top: 16px;
      position: absolute;
      z-index: 1;
      top: 35px;
      left: -250px;
      // padding: 18px 20px;
      color: #606266;
      border-radius: 4px;
      border: 1px solid #e4e7ed;
      background: #fff;
      box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
      .rule-components-keeperselect-popover-popper__arrow{
        position: absolute;
        display: block;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
        left: 250px;
        top: -6px;
        margin-right: 5px;
        border-bottom-color: #ebeef5;
        border-width: 6px;
        filter: drop-shadow(0 2px 12px rgba(0,0,0,.03));
        border-top-width: 0;
        &::after{
          position: absolute;
          display: block;
          width: 0;
          height: 0;
          border-color: transparent;
          border-style: solid;
          top: 1px;
          margin-left: -6px;
          border-bottom-color: #fff;
          content: " ";
          border-width: 6px;
          border-top-width: 0;
        }
      }
      .rule-components-keeperselect-popover-popper__keepercontent{
        display: flex;
        flex-direction: row ;
        flex-wrap: nowrap;
        & div.rule-components-keeperselect-content{
          max-height: 200px;
          overflow-y: auto;
        }
        .rule-components-keeperselect-timeslist,.rule-components-keeperselect-devicelist{
          width: 160px;
          border-right: 1px solid #B3C1D2;
        }
        .rule-components-keeperselect-timeslist{
          .rule-components-keeperselect-datalist{
            padding-left:8px;
            display: flex;
            flex-wrap: nowrap;
            flex-direction: row;
            overflow:hidden;
            text-overflow:ellipsis;
            white-space:nowrap;
            &.is-current{
              background-color: #E8EBF5;
            }
            &>span.rule-components-keeperselect-text{
              width:calc(100% - 15px);
              overflow:hidden;
              text-overflow:ellipsis;
              white-space:nowrap;
            }
            & > span.icon-box{
              line-height: 32px;
            }
          }
        }
        .rule-components-keeperselect-libslist{
          width: 200px;
          .rule-components-keeperselect-datalist{
            background-color: #E8EBF5;
            padding-left:8px;
            overflow:hidden;
            text-overflow:ellipsis;
            white-space:nowrap;
          }
        }

        .rule-components-keeperselect-listtile{
          padding: 0 8px;
          height: 24px;
          line-height: 24px;
          color: white;
          position: relative;

          &.devicetitle{
            background-color: #2a5af5;
            left: -1px;
            width: calc(100% + 1px);
            border-radius: 4px 0 0 0;
          }
          &.timeslisttitle{
            background-color: #B7CBF4;
          }
          &.libslisttitle{
            background-color: #D2DBEA;
            width: calc(100% + 1px);
            border-radius: 0 4px 0 0;
          }
        }
      }
    }
    .slide-fade-enter-active {
      transition: all .3s ease;
    }
    .slide-fade-leave-active {
      transition: all .3s ease;
    }
    .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
      transform: translateY(10px);
      // opacity: 0;
    }
  }
}
::v-deep .el-tree-node.is-current.is-focusable {
  & > .el-tree-node__content{
    background-color: #E8EBF5;
  }
}
::v-deep .el-tree-node__content {
  height: 32px;
  overflow-x: auto;
}
::v-deep .el-tree{
  position: relative;
}
</style>
