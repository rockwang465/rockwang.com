<template>
    <el-dialog
    :title="$tc('task.titleDetailTask')"
    :visible.sync="visible"
    width="30%"
    class="isroll"
    :before-close="handleClose">
    <div v-if="visible" style="display:flex;flex-direction: column;align-items: center;max-height: 65vh;">
        <el-form ref="form" :model="form" label-position="right" :label-width="labelWidth">
            <el-form-item :label="$tc('task.taskType')" prop="taskType">
                {{taskType.filter(ta=>ta.id == 4)[0].label}}
            </el-form-item>
            <el-form-item :label="$t('task.contTaskName')" prop="taskName">
                {{form.taskName}}
            </el-form-item>
            <el-form-item prop="defaultDevices" :label="$t('rule.labelDevice')">
                {{form.defaultDevices}}
            </el-form-item>
            <el-form-item :label="$t('task.labelSnapStrategy')">
                {{snapModelOptions[form.snapStrategy+'']}}
            </el-form-item>
            <el-form-item v-if="form.snapStrategy>0" :label="$t('task.labelQuickresponsetime')">
                {{form.quickresponsetime}} 秒
            </el-form-item>
            <el-form-item prop="time" :label="$t('task.contTimezone')">
                {{form.time}}
            </el-form-item>
            <el-form-item prop="specialAttribute" :label="$t('rule.contAttribute')">
                {{form.specialAttribute}}
            </el-form-item>
            <el-form-item prop="" :label="$t('task.contMinPersionSize')">
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneWidth')" :label-width="subLabelWidth">
                        {{miniNumber.width}}
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneHeight')" :label-width="subLabelWidth">
                        {{miniNumber.height}}
                    </el-form-item>
                </el-col>
            </el-form-item>
            <el-form-item prop="" :label="$t('task.contMaxPersionSize')">
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneWidth')" :label-width="subLabelWidth">
                        {{maxNumber.width}}
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item prop="" :label="$tc('task.contZoneHeight')" :label-width="subLabelWidth">
                        {{maxNumber.height}}
                    </el-form-item>
                </el-col>
            </el-form-item>
            <el-form-item prop="" :label="$tc('task.contSetZone')">
                <span style="color:#ccc;"> {{polygonsPointsList.length>0?$tc('task.contAlreadyZone'):$tc('task.contYetZone')}}</span>
            </el-form-item>
        </el-form>
        <div class="addTaskPC-btns addTaskPC-btns-polygons" v-if="polygonsPointsList && polygonsPointsList.length>0">
            <div v-for="(polygon,polygonIndex) in polygonsPointsList" :key="polygonIndex" class="addTaskPC-btns-btn"
            @mouseenter="(e)=>enterBtns(polygonIndex)" @mouseleave="(e)=>leaveBtns(polygonIndex)">
                {{`${$tc('task.contZoneNum')}${polygonIndex+1}`}}
            </div>
        </div>
        <div class="addTaskPC-video" style="position:relative;width:532px;"  >
            <MediaPlayer v-if="videoUrl" :showControl="false" type="1" name="test" :url="videoUrl" @loadedmetadata="initDrawer" />
            <DrawPolygons ref="drawPolygons"
                :style="{position:'absolute',left:0,top:0}"
                :width="sketchpadWidth"
                :height="sketchpadHeight"
                :drawModel="false"  />
        </div>
    </div>
    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="hide(true)" v-if="$permission('006218')">{{$t('rule.buttonOperationEdit')}}</el-button>
      <el-button @click="hide(false)" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
    </el-dialog>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {getPAITaskDetail} from '@/api/task';
import i18n from '@/lang/index';
import MediaPlayer from '@/components/media-player/index.vue';
import DrawPolygons from '../../components/drawPolygons.vue';
import {cloneDeep,trim} from 'lodash';
import {taskType} from '@/utils/constants.ts';
import { AppModule } from '@/store/modules/app';

const defaultMiniMax = {//default value
    miniNumber:{width:0,height:0},
    maxNumber:{width:0,height:0}
};

@Component({
    components: {
        // TreeSelectRadio,
        MediaPlayer,
        DrawPolygons
    },
})
export default class ViewTaskPAI extends Vue {
    /* props */
    @Prop({default:false}) visible!: boolean;
    @Prop({required:true}) taskId!: string;

    /* watch */
    @Watch('visible',{ immediate: true})
    onVisibleChange(n,o){
        n && this.initData();
    }
    get language() {
        return AppModule.language;
    }

    get subLabelWidth(){
        return AppModule.language === 'en'?'48px':'20px';
    }
    /* data */
    $refs !:{
        drawPolygons:HTMLFormElement,
        form:HTMLFormElement
    }
    form:{
        taskName:string;
        defaultDevices:string,
        time:any,
        specialAttribute:string,
        alarmLine:any[],
        lineDirect:any,
        quickresponsetime:number,
        snapStrategy:number,
    }={
        taskName:'',
        defaultDevices:'',
        time:'',
        specialAttribute:'',
        alarmLine:[],
        lineDirect:'',
        quickresponsetime:4,
        snapStrategy:1,
    };
    miniNumber:any={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
    maxNumber:any={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
    lineDirectionOptions:any[]=[];
    videoUrl:string='';
    sketchpadWidth:number=0;
    sketchpadHeight:number=this.sketchpadWidth*1080/1920;
    scale:any={x:1,y:1};
    drawModel:boolean=false;
    polygonsPointsList:any[]=[];
    labelWidth:string='155px';
    taskType:any=taskType;
    snapModelOptions:any={
        '1': '定时模式',
        '0': '实时模式',
        '-1':'精准模式',
    };
    /* methods */
    mounted(){

    }

    initDefaultMiniMax(){
        this.miniNumber={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
        this.maxNumber={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
    }
    initData(){
        this.initDefaultMiniMax();
        this.lineDirectionOptions=[];
        this.videoUrl='';
        this.sketchpadWidth=0;
        this.sketchpadHeight=this.sketchpadWidth*1080/1920;
        this.scale={x:1,y:1};
        this.drawModel = false;
        //init form
        this.form={
            taskName:'',
            defaultDevices:'',
            time:'',
            specialAttribute:'',
            alarmLine:[],
            lineDirect:'',
            quickresponsetime:4,
            snapStrategy:1,
        };
        //get data
        this.form.lineDirect = 1;//设置默认方向
        this.taskId && getPAITaskDetail(this.taskId).then((res:any)=>{
            res && res.taskId && this.setDataForDetail(res);
        })
    }
    setDataForDetail(res){
        this.form.taskName = res.taskName || '';
        this.form.defaultDevices = res.deviceName;
        this.form.quickresponsetime = res.quickResponseTime;
        this.setSnapStrategyValue(res.quickResponseTime);
        this.form.time = res.timeZoneName || '';
        this.form.specialAttribute = res.taskAttributeVoList && this.formatAttrsText(res.taskAttributeVoList);
        this.formatTargetSize(res.vertices);
        this.videoUrl = res.videoPath || '';
        this.polygonsPointsList = res.vertices && res.vertices.pointVoList;
    }
    setSnapStrategyValue(v){
        if(v>0){
        this.form.snapStrategy = 1;
        }else{
        this.form.snapStrategy = v;
        }
    }
    formatAttrsText(taskAttributeVos){
        let arr:any=[];
        taskAttributeVos.map(item=>{
        // item.taskAttributeId == 5 && (this.showWelcome = true);
            arr.push(this.$tc(`rule.${item.taskAttributeName}`))
        });
        let str = '';
        if(arr.length>0){
            str = arr.join(',');
        }
        return str;
    }
    formatTargetSize(vertices){
        this.maxNumber = vertices.maxTarget;
        this.miniNumber = vertices.minTarget;
        // vertices.pointVoList && vertices.pointVoList.length>0 && this.$refs.drawLine.drawLine(vertices.pointVoList[0],vertices.pointVoList[1],'red');
    }
    initDrawer(video){
        let origin_w = video.target.videoWidth,origin_h = video.target.videoHeight;
        let client_w = video.target.clientWidth,client_h = video.target.clientHeight;
        //set canvas
        this.sketchpadWidth  = client_w;
        this.sketchpadHeight = client_h;
        //set line
        if(this.polygonsPointsList.length>0){
            let arr :any[]=[];
            this.polygonsPointsList.map(poly=>{
                arr.push(this.setScaleForCoordinate(poly));
            });
            this.$nextTick(()=>{
                arr.length>0 && this.$refs.drawPolygons.drawPolygonsMethod(arr);
            })
        }

    }
    enterBtns(polygonIndex){
        this.$refs.drawPolygons.showCurrentPolygon(polygonIndex)
    }
    leaveBtns(polygonIndex){
        this.$refs.drawPolygons.hideCurrentPolygon(polygonIndex)
    }
    setScaleForCoordinate(list){
        let arr = [], _w = this.sketchpadWidth, _h = this.sketchpadHeight;
        if(_w > 0 && _h > 0 && list && list.length > 0){
            arr = list.map(item =>{
                let x = item.x*_w , y = item.y*_h;
                return {x,y}
            })
        }
        return arr.length>0?arr:list;
    }
    handleClose(){
        this.$emit('hide')
    }
    hide(isEdit){
        this.$emit('hide',isEdit)
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.tables-container{
    .task-list-operation-item{
        cursor: pointer;
        margin-right: 8px;
        i.iconfont{
            font-size:19px;
        }
    }
}
::v-deep .el-select__tags .el-tag--info {
    color: #28354d;
}

.el-input{
    ::v-deep input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }
}
.addTaskPC-linkbtn{
    display: inline-block;
    color: #2A5AF5;
    cursor: pointer;
    text-decoration: underline ;
}
.addTaskPC-video{
    position: relative;
    width: 532px;
}
.addTaskPC-btns{
    display: flex;
    justify-content: flex-start;
    width: 532px;
    padding-bottom: 8px;
    &>div{
        cursor: pointer;
        &:active{
            color: #2A5AF5;
        }
    }
}
.addTaskPC-btns-btn{
    padding: 8px 16px;
    border:1px solid #7E7E9A;
    border-radius: 4px;
    margin-right: 16px;
    position: relative;
    &:hover{
        background-color: #1989FA;
        color: white;
    }
}
</style>
