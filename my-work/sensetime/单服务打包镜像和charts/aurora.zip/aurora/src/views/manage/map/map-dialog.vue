<template>
  <div>
    <p>
      {{ type }}
    </p>
    {{ text }}
  </div>
</template>
<script>

export default {
  name: 'GeoJson2Popup',
  props: {
    type: {
      type: String,
      default: ''
    },
    text: {
      type: String,
      default: ''
    }
  }
};
</script>
