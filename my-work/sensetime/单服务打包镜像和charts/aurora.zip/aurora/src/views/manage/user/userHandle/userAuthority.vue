<template>
  <!--批量修改角色-->
  <div>
    <el-dialog :title="$t('usermanagement.buttonEditRole')" :visible.sync="dialogShowVisible" width="584px">
      <br>
      <el-input
        style="width:296px"
        size="medium"
        suffix-icon="el-icon-search"
        v-model="filterText">
      </el-input>
      <br>
      <div style="height: 150px;overflow: auto;width: 296px;">
        <el-tree
          ref="tree"
          :data="dataObj.roleList"
          :props="defaultProps"
          :filter-node-method="filterNode"
          node-key="roleId"
          :render-content="renderContent"
        />
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="subInfo">{{$t('usermanagement.buttonOK')}}</el-button>
          <el-button type="info" class="cancel" @click="dialogShowVisible = false">{{$t('usermanagement.buttonCancel')}}</el-button>
     </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import {Component, Vue, Watch,Prop} from 'vue-property-decorator';
  import {isEmpty} from '@/utils/validate';
  import {UserModule} from '@/store/modules/user';
  @Component({

  })
  export default class userAuthority extends Vue {
    //编辑的表单里的值
    dialogShowVisible = false;
    filterText = "";
    checkLabel = '';
    defaultProps = {
      label: 'name',
      children:'children'
    };
    @Prop(Object) dataObj!: any[];
    @Prop({required: true, default: false}) dialogVisible!: boolean;
    @Watch('dialogVisible')
    onDialogVisibleChange(val: any) {
      this.dialogShowVisible = val;
      console.log(this.dataObj);
    }

    @Watch('dialogShowVisible')
    onDialogShowVisibleChange(val: any) {
      if (!val) {
        this.$emit("closeUserAuthority")
      }
    }

    //监听搜索框的值,检索
    @Watch('filterText')
    onFilterTextChange(val: string) {
      (this.$refs.tree as any).filter(val);
    }

    //根据值过滤掉不匹配的分支
    filterNode(value: string, data: any) {
      if (!value) {
        return true;
      }
      return data.name.indexOf(value) !== -1;
    }

    subInfo(){
      let that = this as any;
      if (isEmpty(this.checkLabel)) {
        this.$message({
          showClose: true,
          // message: "请选择角色",
          message: that.$t('form.texterrSelectRole'),
          type: 'error'
        });
        this.dialogShowVisible = false;
        return
      }
      let userArr = [] as any;
      (this.dataObj as any).checkList.forEach((item)=>{
        userArr.push(item.userId);
      });
      let params = {
        userIds:userArr,
        roleId:this.checkLabel
      } as any;
      UserModule.BatchUpdataRole(params).then((data: any) => {
        this.$message({
          showClose: true,
          // message: '所选用户修改角色成功',
          message: that.$t('globaltip.tipmsgEditUser'),
          type: 'success'
        });
        this.dialogShowVisible = false;
        this.$emit('inIt')
      }).catch((err) => {
        console.log(err)
      });
    }
    renderContent(h, {node, data, store}) {
      let that = this as any;
            return h('div', {
              style: {
                width: '100%'
              },
            }, [
              h("el-radio", {
                on: {
                  input: function (event) {
                    that.checkLabel = event
                  }
                },
                props: {
                  value: that.checkLabel,
                  label: data.roleId,
                  key: data.roleId
                },
              }, data.name)
            ]);
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .timezone-timezone-footer {
    text-align: center;
    padding: 20px;
  }
  ::v-deep .el-dialog__footer{
    text-align: center !important;
  }
  ::v-deep .el-dialog__body {
    padding: 0 0 20px 0 !important;
  }
  ::v-deep .el-input__inner{
    height: 32px;
  }
  .inp{
     display: flex;
     justify-content: center;
  }
  .checkList{
    margin-top: 10px;
  }
  .check{
    padding-left: 25%;
    line-height: 24px;
  }
  .inp-search{
    position: relative;
  }
  .icon-search{
    position: absolute;
    top: 5px;
    right: 10px;
    font-size: 20px;
    color: #000;
  }
</style>
