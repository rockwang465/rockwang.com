<template>
    <el-dialog
    :title="$tc('imagemanagement.contAsyncFail')"
    :visible="dialogVisible"
    width="70%"
    ref="dialog"
    :before-close="handleClose">
    <div class="portraitasync-box" >
        <el-row v-loading="loading">
            <el-col :span="18" style="margin-bottom:8px">
                <div class="portraitasync-header-text" >
                    <i class="el-icon-message-solid" ></i>
                    <span>{{$tc('imagemanagement.contAsyncWarn')}}</span>
                </div>

            </el-col>
            <el-col :span="6">
                <el-button type="primary" size="medium" v-if="$permission('008319')" icon="el-icon-upload2" @click="exportFail" :disabled="!imagesList.length>0" >{{$tc('imagemanagement.btnExportAsyncFail')}}</el-button>
            </el-col>
            <el-col :span="24" class="portraitasync-imageslist" v-if="imagesList.length>0" >
                <PortraitImage v-for="(targetImage,targetImageIndex) in imagesList" :key="targetImageIndex" :data="targetImage" />
            </el-col>
            <el-col :span="24" v-if="imagesList.length>0">
                <el-pagination
                style="display:flex;justify-content: center;margin-top:8px"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="paginationPageSizes"
                :page-size="currentPageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total">
                </el-pagination>
            </el-col>
            <el-col :span="24" v-else style="text-align:center;height:350px;line-height: 350px;">
                {{$t('imagemanagement.contNoData')}}
            </el-col>
        </el-row>
        <!-- messageBox export ensure -->
        <el-dialog
        :class="{diablogAnimation:true,hidden:isHide}"
        :append-to-body="true"
        :visible="showExportDialog"
        :before-close="()=>this.showExportDialog = false"
        width="400px">
        <p style="max-width:350px;text-align:center;line-height:20px;word-break: break-word;">{{$tc('imagemanagement.contExportAll')}}</p>
        <div slot="title" >
            <span>{{$tc('imagemanagement.titleExport')}}</span>
        </div>
        <span slot="footer">
            <el-button type="primary" @click="ensureExport" :loading="exportLoading">{{$t('rule.buttonOK')}}</el-button>
            <el-button @click="showExportDialog = false" type="info">{{$t('rule.buttonCancel')}}</el-button>
        </span>
        </el-dialog>
    </div>
    <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleClose">{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="handleClose" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>

    </el-dialog>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import PortraitImage from '../components/portraitImage.vue';
import {paginationPageSizes} from '@/utils/constants.ts';
import api from '@/api/portrait';

@Component({
    components: {
        PortraitImage
    },
})
export default class PortraitAsync extends Vue {
    /* props */
    @Prop({required:true }) dialogVisible!: boolean;

    /* watch */
    @Watch('dialogVisible',{ immediate: true})
    onVisibleChange(n,o){
        n && this.initData();
    }
    /* data */
    $refs !:{
        dialog:HTMLFormElement
    }
    imagesList:any[]=[];
    currentPage:number=1;
    paginationPageSizes:any=paginationPageSizes;
    currentPageSize:number = paginationPageSizes[1];//默认20条
    total:number=0;
    showExportDialog:boolean=false;
    exportLoading:boolean=false;
    isHide:boolean=false;
    loading:boolean=false;
    /* methods */
    initData(){
        this.imagesList = [];
        this.currentPage=1;
        this.paginationPageSizes=paginationPageSizes;
        this.currentPageSize = paginationPageSizes[1];//默认20条
        this.total=0;
        this.showExportDialog=false;
        this.exportLoading=false;
        this.isHide=false;
        this.loading=false;
        this.getData();
    }
    exportFail(){
        this.showExportDialog=true;
    }
    getData(){
        this.loading=true;
        api.getPortraitAsyncImages({page:this.currentPage,size:this.currentPageSize}).then((res:any)=>{
            this.loading=false;
            res && this.formatData(res);
        }).finally(()=>{
            this.loading=false;
        })
    }
    formatData(res){
        this.imagesList = [];
        this.total = res.total;
        res.data && res.data.length>0 && res.data.forEach(person => {
            this.imagesList.push({
                url:person.picUrl,
                name:person.name,
                identity:person. identity,
                failReason:this.getReason(person.failState),
                libraryNames:this.getLibraryNames(person.libraryNames),
                uploadTime:person.createTime
            })
        });
    }
    getReason(key){
        switch (key) {
            case 1:
                return this.$t('imagemanagement.createSynchronizationPerson');
            case 2:
                return this.$t('imagemanagement.editSynchronizationPerson');
            case 3:
                return this.$t('imagemanagement.delSynchronizationPerson');

            default:
                return this.$t('SynchronizationPersonFail');
        }
    }
    getLibraryNames(list){
        if(list && list.length>0){
            return list.join(',')
        }else{
            return ''
        }
    }
    handleClose(){
        this.$emit('close')
    }
    handleSizeChange(v){
        this.currentPageSize = v;
        this.getData();
    }
    handleCurrentChange(v){
        this.currentPage = v;
        this.getData();
    }
    ensureExport(){
        this.exportLoading=true;
        api.exportAsyncFailTargets().then(res=>{
            this.$message({
                showClose: true,
                message:this.$tc('log.exportSuccess'),
                type: 'success'
            });
            this.showExportDialog=false;
            this.isHide = true;
            setTimeout(()=>{
                this.isHide = false;
            },1010)
        }).finally(()=>{
            this.exportLoading=false;
        })
    }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.portraitasync-box{
    width: 100%;
    .portraitasync-header-text{
        color: red;
        padding: 10px;
    }
    .portraitasync-imageslist{
        height: 460px;
        overflow-y: auto;
    }
}
::v-deep .el-pagination__sizes{
    width: 100px;
}

.diablogAnimation{
    width: 100%;
    height: 100%;
}
.hidden {
    transition: all 1s;
    overflow: hidden;
    display: block !important;
    position: fixed;
    top: -10%;
    bottom: 110%;
    right: 5%;
    left: 95%;
    width: 0;
    height: 0;
    opacity: 0;
    ::v-deep .el-dialog {
      min-width: 30%;
      min-width: 30%;
      height: 30%;
      overflow: hidden;

    }
  }
  ::v-deep .el-dialog__footer{
      padding-top:40px;
  }
</style>
