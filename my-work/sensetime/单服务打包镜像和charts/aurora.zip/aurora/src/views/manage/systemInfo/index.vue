<template>
  <div class="info-container">
    <!--左侧-->
    <div class="title-one" style="margin-right: 2%">
      <el-col :span="4" style="width: 256px;margin:32px 0 16px -50px;" class="el-breadcrumb-top">
        <h2 class="side-title" style="font-size: 16px;margin: 4px;padding: 0;">
          <i class="iconfont icon-info-msg"></i><span>{{$t('systeminfo.titleSystemInfo')}}</span>
        </h2>
      </el-col>
      <el-col class="title">
        <el-row>
          <!--基本信息-->
          <el-col
            :span="12"
            class="xin"
          ><span class="circle"></span>{{$t('systeminfo.labelBasicInfo')}}</el-col>
        </el-row>
        <el-row class="info">
          <!--当前版本-->
          <el-col class="info-title">{{$t('systeminfo.contVersion')}}</el-col>
          <el-col class="info-msg">{{systemNameVersion}}</el-col>
        </el-row>
        <el-row class="info">
          <!--授权期限-->
          <el-col class="info-title">{{$t('systeminfo.contLicenseExpiration')}}</el-col>
          <el-col class="info-msg">{{systemInfo.license}}</el-col>
        </el-row>
        <el-row class="info">
          <!--运维管理-->
          <el-col class="info-title operationYunwei" style="width: 32.5%;" >
             <a :href="getOperation" :target="disableInfo ? '' : '_blank'" style="text-decoration:none;color:#FFF;opacity: 1;">
                <el-button
                  type="primary"
                  size="small"
                  icon="iconfont icon-Toconfigure"
                  :disabled="disableInfo"
                >
                  {{$t('systeminfo.operation')}}
                </el-button>
            </a>
            <!--<el-button-->
              <!--type="primary"-->
              <!--size="small"-->
              <!--icon="iconfont icon-Toconfigure"-->
              <!--:disabled="disableInfo"-->
            <!--&gt;-->
              <!--<el-link href="getOperation" :target="disableInfo ? '' : '_blank'" :underline="false" :disabled="disableInfo"-->
                       <!--style="text-decoration:none;color: #ffffff;"-->
              <!--&gt;{{$t('systeminfo.operation')}}</el-link>-->
            <!--</el-button>-->
          </el-col>
        </el-row>
        <!--<el-row class="info">-->
        <!--&lt;!&ndash;运维信息&ndash;&gt;-->
        <!--<el-col class="info-title">{{$t('systeminfo.contMaintenanceInfo')}}</el-col>-->
        <!--&lt;!&ndash;运维系统入口&ndash;&gt;-->
        <!--<el-col class="info-msg"><a :href="systemInfo.safeguard" target="_Blank">{{$t('systeminfo.contMaintenanceVisit')}}</a></el-col>-->
        <!--</el-row>-->
        <!--换行-->
        <div style="height: 3vh;"></div>


        <!--换行-->
        <div style="height: 3vh;"></div>
        <el-row>
          <!--其他信息-->
          <el-col :span="12" class="xin"><span class="circle"></span>{{$t('systeminfo.labelOtherInfo')}}</el-col>
        </el-row>
        <el-row class="info-two">
          <!--系统Logo-->
          <el-col class="cc">{{$t('systeminfo.contLogo')}}</el-col>
          <el-col class="c2 img-wrapper"><img
              id="selected"
              style="vertical-align: middle;background-color: #28354d"
              height="24px"
              :src="systemInfo.logo"
              alt=""
            ></el-col>
          <el-col class="c3">
            <!--更换标志-->
            <label
              for="inp"
              class="upload"
            ></label>
            <el-button
              v-if="$permission('003302')"
              class="btn"
              type="primary"
              size="small"
              icon="iconfont icon-edit"
            >{{$t('systeminfo.buttonLogoModify')}}</el-button>
            <input
              v-if="$permission('003302')"
              id="inp"
              type="file"
              accept="image/*"
              @change="upImage($event)"
            />
          </el-col>
        </el-row>
        <el-row class="info-two">
          <!--系统标题-->
          <el-col class="cc">{{$t('systeminfo.contSystemTitle')}}</el-col>
          <el-col class="c2">{{language == 'en' ? systemInfo.systemName : systemInfo.systemNameZh}}</el-col>
          <!--更换标题-->
          <el-col class="c3">
            <el-button
              v-if="$permission('003302')"
              class="btn"
              type="primary"
              @click="showTitle(1)"
              size="small"
              icon="iconfont icon-edit"
            >{{$t('systeminfo.buttonSystemTitleModify')}}</el-button>
          </el-col>
        </el-row>
        <el-row class="info-two">
          <!--系统描述-->
          <el-col class="cc">{{$t('systeminfo.systeminfoDescription')}}</el-col>
          <el-tooltip v-if="describe.length>10" :content="describe" placement="top">
            <el-col class="c2">{{describe}}</el-col>
          </el-tooltip>
          <el-col v-else class="c2">{{describe}}</el-col>
          <!--更换描述-->
          <el-col class="c3">
            <el-button
              v-if="$permission('003302')"
              class="btn"
              type="primary"
              @click="showTitle(5)"
              size="small"
              icon="iconfont icon-xtms"
            >{{$t('systeminfo.descriptionChange')}}</el-button>
          </el-col>
        </el-row>
        <!--<el-row class="info-two">-->
        <!--<el-col class="cc">语言类型</el-col>-->
        <!--<el-col class="c2">{{systemInfo.language == 0?'中文':'英文'}}</el-col>-->
        <!--<el-col class="c3"><el-button  @click="showTitle(2)" class="btn" type="primary" size="small" icon="el-icon-upload2">更换语言</el-button></el-col>-->
        <!--</el-row>-->
        <el-row class="info-two">
          <!--忘记密码提示语-->
          <el-col class="cc">{{$t('systeminfo.contForgetPassword')}}</el-col>
          <el-col class="c2">{{prompt}}</el-col>
          <!--更换提示-->
          <el-col class="c3">
            <el-button
              v-if="$permission('003302')"
              class="btn"
              @click="showTitle(3)"
              type="primary"
              size="small"
              icon="iconfont icon-lang-set"
            >{{$t('systeminfo.buttonForgetPasswordReminder')}}</el-button>
          </el-col>
        </el-row>
        <el-row class="info-two">
          <!--陌生人比中-->
          <el-col class="cc">{{$t('systeminfo.strangerPhoto')}}</el-col>
          <el-col class="c2"></el-col>
          <el-col class="c3">
            <el-switch
              v-model="strangerRatioSwitch"
              :disabled="!$permission('003302')"
              active-color="#13ce66"
              class="strangerSwitch"
              @change="changeStrangerPhoto"
              active-value="1"
              inactive-value="0"
              :active-text="$tc('systeminfo.strangerShow')"
              :inactive-text="$tc('systeminfo.strangerHide')"
              inactive-color="#C2CAD8">
            </el-switch>
          </el-col>
        </el-row>
        <el-row class="info-two">
          <!--口罩检测-->
          <el-col class="cc">{{$t('systeminfo.respiratorSwitch')}}</el-col>
          <el-col class="c2"></el-col>
          <el-col class="c3">
            <el-switch
              v-model="respiratorSwitch"
              @change="respiratorSwitchChange"
              :disabled="!$permission('003302')"
              active-color="#13ce66"
              class="strangerSwitch"
              active-value="1"
              inactive-value="0"
              :active-text="$tc('systeminfo.strangerShow')"
              :inactive-text="$tc('systeminfo.strangerHide')"
              inactive-color="#C2CAD8">
            </el-switch>
          </el-col>
        </el-row>
        <el-row class="info-two">
          <!--安全帽检测-->
          <el-col class="cc">{{$t('systeminfo.helmetSwitch')}}</el-col>
          <el-col class="c2"></el-col>
          <el-col class="c3">
            <el-switch
              v-model="helmetSwitch"
              @change="helmetSwitchChange"
              :disabled="!$permission('003302')"
              active-color="#13ce66"
              class="strangerSwitch"
              active-value="1"
              inactive-value="0"
              :active-text="$tc('systeminfo.strangerShow')"
              :inactive-text="$tc('systeminfo.strangerHide')"
              inactive-color="#C2CAD8">
            </el-switch>
          </el-col>
        </el-row>
<!--        <el-row class="info-two">-->
<!--          <el-col class="cc" :style="{marginLeft: language == 'en' ? '-80px' : '0'}">{{$t('systeminfo.TemporaryVisitors')}}</el-col>-->
<!--          <el-col class="c2"></el-col>-->
<!--          <el-col class="c3">-->
<!--            <el-switch-->
<!--              v-model="recognition"-->
<!--              :disabled="!$permission('003302')"-->
<!--              active-color="#13ce66"-->
<!--              class="strangerSwitch"-->
<!--              @change="updateGuestInterimLibraryExtract"-->
<!--              active-value="0"-->
<!--              inactive-value="1"-->
<!--              :active-text="$tc('systeminfo.Frontend')"-->
<!--              :inactive-text="$tc('systeminfo.Backend')"-->
<!--              inactive-color="#C2CAD8">-->
<!--            </el-switch>-->
<!--          </el-col>-->
<!--        </el-row>-->

<!--        20.02.24,产品与后端讨论，去掉前端第三方接入信息功能的展示-->
<!--        <el-row>-->
<!--          &lt;!&ndash;第三方接入信息&ndash;&gt;-->
<!--          <el-col :span="12" class="xin"><span class="circle"></span>{{$t('systeminfo.thirdPartyInfo')}}</el-col>-->
<!--        </el-row>-->
<!--        <el-row class="info-two">-->
<!--          <el-col class="cc">{{$t('systeminfo.isAlarmPush')}}</el-col>-->
<!--          <el-col class="c2"></el-col>-->
<!--          <el-col class="c3">-->
<!--            <el-switch-->
<!--              v-model="isAlarm"-->
<!--              active-color="#13ce66"-->
<!--              class="strangerSwitch"-->
<!--              :disabled="!$permission('003302')"-->
<!--              @change="switchAlarm"-->
<!--              active-value="1"-->
<!--              inactive-value="0"-->
<!--              :active-text="$tc('systeminfo.alarmPushTrue')"-->
<!--              :inactive-text="$tc('systeminfo.alarmPushFalse')"-->
<!--              inactive-color="#C2CAD8">-->
<!--            </el-switch>-->
<!--          </el-col>-->
<!--        </el-row>-->
<!--        <el-row class="info-two">-->
<!--          <el-col class="cc">{{$t('systeminfo.alarmPushUrl')}}</el-col>-->
<!--          <el-col class="c2">{{alarmUrl}}</el-col>-->
<!--          <el-col class="c3">-->
<!--            <el-button-->
<!--              class="btn"-->
<!--              type="primary"-->
<!--              :disabled="!$permission('003302')"-->
<!--              size="small"-->
<!--              @click="showTitle(4)"-->
<!--              icon="iconfont icon-edit1"-->
<!--            >{{$t('systeminfo.setAlarmPushUrl')}}</el-button>-->
<!--          </el-col>-->
<!--        </el-row>-->
      </el-col>
    </div>
    <!--右侧-->
    <div class="title-one title-one-right">
      <el-col :span="4" style="width: 256px;margin:32px 0 16px -50px;" class="el-breadcrumb-top">
        <h2 class="side-title" style="font-size: 16px;margin: 4px;padding: 0;">
          <i class="iconfont icon-info-msg"></i><span>{{$t('systeminfo.License')}}</span>
        </h2>
      </el-col>
      <el-col class="title">
        <el-row>
          <!--人脸授权-->
          <el-col
            :span="12"
            class="xin"
          ><span class="circle"></span>{{$t('systeminfo.FaceLicense')}}</el-col>
        </el-row>
        <el-row class="info info-all">
          <!--总路数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''"></el-col>
          <el-col class="c2"></el-col>
          <el-col
            class="c3"
            style="font-size: 8px"
          >{{$t('systeminfo.titleUsed')}}</el-col>
        </el-row>
        <el-row class="info">
          <!--图片流接入数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.imageStreamAccessNumber')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.imageStreamAccessNumber/systemInfo.maxImageStreamAccessNumber)*100>100?100:(systemInfo.imageStreamAccessNumber/systemInfo.maxImageStreamAccessNumber)*100 || 0"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.imageStreamAccessNumber}} </span> / {{systemInfo.maxImageStreamAccessNumber}}</el-col>
        </el-row>
        <el-row class="info">
          <!--视频流接入数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.videoStreamAccessNumber')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.videoStreamAccessNumber/systemInfo.maxVideoStreamAccessNumber)*100>100?100:(systemInfo.videoStreamAccessNumber/systemInfo.maxVideoStreamAccessNumber)*100 || 0"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.videoStreamAccessNumber}} </span> / {{systemInfo.maxVideoStreamAccessNumber}}</el-col>
        </el-row>
        <el-row class="info">
          <!--前端设备接入数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.frontEndDeviceAccessNumber')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.frontEndDeviceAccessNumber/systemInfo.maxFrontEndDeviceAccessNumber)*100>100?100:(systemInfo.frontEndDeviceAccessNumber/systemInfo.maxFrontEndDeviceAccessNumber)*100 || 0"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.frontEndDeviceAccessNumber}} </span> / {{systemInfo.maxFrontEndDeviceAccessNumber}}</el-col>
        </el-row>

        <el-row>
          <!--人群授权项目-->
          <el-col
            :span="12"
            class="xin"
          ><span class="circle"></span>{{$t('systeminfo.crowdDetectionAccess')}}</el-col>
        </el-row>
        <el-row class="info info-all">
          <!--总路数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''"></el-col>
          <el-col class="c2"></el-col>
          <el-col
            class="c3"
            style="font-size: 8px"
          >{{$t('systeminfo.titleUsed')}}</el-col>
        </el-row>
        <el-row class="info">
        <!--人群视频流接入授权数-->
        <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.crowdDetectionAccessNumber')}}</el-col>
        <el-col class="c2">
          <el-progress
            style="margin-top: 10px"
            :percentage="(systemInfo.crowdDetectionAccessNumber/systemInfo.maxCrowdDetectionAccessNumber)*100>100?100:(systemInfo.crowdDetectionAccessNumber/systemInfo.maxCrowdDetectionAccessNumber)*100"
            color="#2a5af5"
          ></el-progress>
        </el-col>
        <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.crowdDetectionAccessNumber}} </span> / {{systemInfo.maxCrowdDetectionAccessNumber}}</el-col>
      </el-row>

        <el-row>
          <!--库容授权-->
          <el-col
            :span="12"
            class="xin"
          ><span class="circle"></span>{{$t('systeminfo.storageCapacityLicense')}}</el-col>
        </el-row>
        <el-row class="info  info-all">
          <!--总路数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''"></el-col>
          <el-col class="c2"></el-col>
          <el-col
            class="c3"
            style="font-size: 8px"
          >{{$t('systeminfo.titleUsed')}}</el-col>
        </el-row>
        <el-row class="info">
          <!--抓拍库容量-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.CaptureImageLibrary')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.useSnapNumber/systemInfo.snapCapacity)*100>100?100:(systemInfo.useSnapNumber/systemInfo.snapCapacity)*100"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.useSnapNumber}} </span> / {{systemInfo.snapCapacity}}</el-col>
        </el-row>
          <!--人体库容量-->
        <el-row class="info">
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.usePedestrianSnapNumber')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.usePedestrianSnapNumber/systemInfo.pedestrianSnapCapacity)*100>100?100:(systemInfo.usePedestrianSnapNumber/systemInfo.pedestrianSnapCapacity)*100"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.usePedestrianSnapNumber}} </span> / {{systemInfo.pedestrianSnapCapacity}}</el-col>
        </el-row>
        <el-row class="info">
          <!--白名单分组数量-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.WhitelistGroup')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.useWhiteGroupNumber/systemInfo.whiteGroupCapaity)*100>100?100:(systemInfo.useWhiteGroupNumber/systemInfo.whiteGroupCapaity)*100"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.useWhiteGroupNumber}} </span> / {{systemInfo.whiteGroupCapaity}}</el-col>
        </el-row>
        <el-row class="info">
          <!--白名单容量-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.Whitelist')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.useWhiteNumber/systemInfo.whiteCpacity)*100>100?100:(systemInfo.useWhiteNumber/systemInfo.whiteCpacity)*100"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.useWhiteNumber}} </span> / {{systemInfo.whiteCpacity}}</el-col>
        </el-row>
        <el-row class="info">
          <!--黑名单分组数量-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.BlacklistGroup')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.useBlackGroupNumber/systemInfo.blackGroupCapaity)*100>100?100:(systemInfo.useBlackGroupNumber/systemInfo.blackGroupCapaity)*100"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.useBlackGroupNumber}} </span> / {{systemInfo.blackGroupCapaity}}</el-col>
        </el-row>
        <el-row class="info">
          <!--黑名单容量-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.Blacklist')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.useBlackNumber/systemInfo.blackCpacity)*100>100?100:(systemInfo.useBlackNumber/systemInfo.blackCpacity)*100"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.useBlackNumber}} </span> / {{systemInfo.blackCpacity}}</el-col>
        </el-row>
        <el-row>
          <!--结构化视频流接入数-->
          <el-col
            :span="12"
            class="xin"
          ><span class="circle"></span>{{$t('systeminfo.structuringLicense')}}</el-col>
        </el-row>
        <el-row class="info info-all">
          <!--总路数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''"></el-col>
          <el-col class="c2"></el-col>
          <el-col
            class="c3"
            style="font-size: 8px"
          >{{$t('systeminfo.titleUsed')}}</el-col>
        </el-row>
        <el-row class="info">
          <!--结构化视频流接入数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.structuredVideo')}}</el-col>
          <el-col class="c2">
            <el-progress
              style="margin-top: 10px"
              :percentage="(systemInfo.structuringDeviceAccessNumber/systemInfo.maxStructuringDeviceAccessNumber)*100>100?100:(systemInfo.structuringDeviceAccessNumber/systemInfo.maxStructuringDeviceAccessNumber)*100"
              color="#2a5af5"
            ></el-progress>
          </el-col>
          <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.structuringDeviceAccessNumber}} </span> / {{systemInfo.maxStructuringDeviceAccessNumber}}</el-col>
        </el-row>
        <el-row>
          <!--用户授权-->
          <el-col
            :span="12"
            class="xin"
          ><span class="circle"></span>{{$t('systeminfo.userLicense')}}</el-col>
        </el-row>
        <el-row class="info info-all">
          <!--总路数-->
          <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''"></el-col>
          <el-col class="c2"></el-col>
          <el-col
            class="c3"
            style="font-size: 8px"
          >{{$t('systeminfo.titleUsed')}}</el-col>
        </el-row>
        <el-row class="info">
        <!--用户数量-->
        <el-col class="cc" :class="language === 'en' ? 'cc-en' : ''">{{$t('systeminfo.Users')}}</el-col>
        <el-col class="c2">
          <el-progress
            style="margin-top: 10px"
            :percentage="(systemInfo.useNumber/systemInfo.limitCapacity)*100>100?100:(systemInfo.useNumber/systemInfo.limitCapacity)*100"
            color="#2a5af5"
          ></el-progress>
        </el-col>
        <el-col class="c3"><span style="color: #2a5af5;">{{systemInfo.useNumber}} </span> / {{systemInfo.limitCapacity}}</el-col>
      </el-row>
      </el-col>
    </div>
    <!--更换标题-->
    <el-dialog
      :title="titleData"
      :visible.sync="dialogShowVisible"
      width="584px"
    >
      <div class="descripetion" v-show="descripetionChange">{{titleName}}</div>

      <el-form v-if="systemRules.required" :model="systemForm" ref="systemForm" style="width:80%" @submit.native.prevent>
        <el-form-item :label="titleName" :label-width="formLabelWidth" prop="valueData" :rules="systemRules">
          <el-input size="small" v-model="systemForm.valueData" maxlength="50"></el-input>
        </el-form-item>
      </el-form>
      <div class="content" :style="{height: descripetionChange?'140px':'90px'}" v-else>
        <span class="left-name" v-show="!descripetionChange">{{titleName}}</span>
        <span class="right-name">
          <el-input
            size="small"
            :type="descripetionChange?'textarea':'text'"
            resize="none"
            rows="5"
            v-model="valueData"
            maxlength="48"
          ></el-input>
        </span>
      </div>
      <span
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          type="primary"
          :disabled="!valueData"
          @click="updataSystem"
        >{{$t('systeminfo.buttonOK')}}</el-button>
        <el-button
          class="cancel"
          @click="cancelUpdata"
        >{{$t('systeminfo.buttonCancel')}}</el-button>
      </span>
    </el-dialog>
    <!--更换标题-->
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator'
import { getSystem } from '@/store/modules/system'
import { Form as ElForm } from 'element-ui';
import { fileValidate } from '@/utils/validate'
import { AppModule } from '@/store/modules/app'
import { processImgurl } from '@/utils/image.ts'
import request from "@/api/system";
import {Cache} from '@/utils/cache';

@Component({
  components: {}
})
export default class SystemInfo extends Vue {
  get language() {
    return AppModule.language
  }
  systemForm:any = {
    valueData:''
  }
  formLabelWidth = "120px";
  isSubmit = false;
  systemRules:any = {}
  dialogShowVisible = false
  valueData = '' as any
  titleData = ''
  titleName = ''
  type = ''
  // token = null as any
  processImgurl: any = processImgurl
  host = window.globalConfig.host as any
  langObj = [
    {
      id: 0,
      name: '中文'
    },
    {
      id: 1,
      name: '英文'
    }
  ] as any
  systemInfo = {
    systemNameVersion: '',
    systemName: '',
    describe:'',
    license: '',
    language: '',
    logo: '',
    prompt: '',
    safeguard: '',
    blackCpacity: 1,
    blackGroupCapaity: 1,
    keepDeviceCapacity: 1,
    limitCapacity: 1,
    monitorDeviceCapacity: 1,
    snapCapacity: 1,
    totalDeviceCapacity: 1,
    maxStructuringDeviceAccessNumber:1,
    structuringDeviceAccessNumber:0,
    useBlackGroupNumber: 0,
    useBlackNumber: 0,
    useDeviceNumber: 0,
    useKeepDeviceNumber: 0,
    useNumber: 0,
    useSnapNumber: 0,
    useWhiteGroupNumber: 0,
    useWhiteNumber: 0,
    userMonitorDeviceNumber: 0,
    whiteCpacity: 1,
    whiteGroupCapaity: 1
  } as any
  systemNameVersion = '' as any
  prompt = '' as any
  describe = '';
  conditions = { file: null } as any //添加文件
  strangerRatioSwitch = '0';
  // helmetSwitch = '0';
  // respiratorSwitch = '0';
  recognition = '1';//默认是后端比对
  recognitionCopy = '1';//默认是后端比对
  isStrangerShow=''
  isAlarm = '0';
  alarmUrl = '';
  isAlarmDiglog = false;
  descripetionChange:boolean = false;//决定是否展示更换描述页面的布尔值
  respiratorSwitch= '0' //口罩检测
  helmetSwitch= '0' //安全帽检测

  // @Watch('dialogShowVisible')
  // onDialogShowVisibleChange(val: any) {
  //   this.valueData = ''
  // }

  @Watch('language')
  onLanguageChange(val: any) {
    if (val == 'en') {
      this.prompt = this.systemInfo.promptEn
      this.systemNameVersion = this.systemInfo.systemNameVersionEn
      this.describe = this.systemInfo.describeEn
    } else {
      this.prompt = this.systemInfo.promptZh
      this.systemNameVersion = this.systemInfo.systemNameVersionZh
      this.describe = this.systemInfo.describeZh
    }
  }

  get disableInfo() {
    // console.log(localStorage.getItem('userInfo'));
    let userInfo =localStorage.getItem('userInfo') as any
    let id = JSON.parse(userInfo).value.roles
    return !id.includes(1)
  }
  get getOperation() {
    // window.open()
    let url = (window.origin as any).split('//')[1]
    return this.disableInfo ? 'javascript:;':`http://${url}:8000`
  }
  mounted() {
    this.getStrangerPhoto();
    this.getAllEventSwitchInfo();
    // this.getUpdateGuestInterimLibraryExtract();
  }
  // 获取陌生人比中开关信息
  getStrangerPhoto(){
    request.getStrangerPhoto().then((resp:any)=>{
      this.strangerRatioSwitch = resp.strangerRatioSwitch;
      Cache.localSet('strangerRatioSwitch',this.strangerRatioSwitch)
    })
  }
  getAllEventSwitchInfo(){
    request.getAllEventSwitchInfo().then((resp:any)=>{
      // console.log(resp);
      this.respiratorSwitch = resp.respiratorSwitch
      this.helmetSwitch = resp.helmetSwitch
      Cache.localSet('respiratorSwitch',this.respiratorSwitch)
      Cache.localSet('helmetSwitch',this.helmetSwitch)
    })
  }
  changeStrangerPhoto(val){
    let params = {
      strangerRatioSwitch:val
    }
    request.setStrangerPhoto(params).then((resp:any)=>{
      if(resp){
        this.getStrangerPhoto()
      }
    })
  }
  changeRespiratorSwitch(){

  }
  changeHelmetSwitch(){

  }

  respiratorSwitchChange(val) {
    request.setBaseEventsSwitch('3',val).then((resp:any)=>{
       if(resp) {
          this.getAllEventSwitchInfo()
       }
    })
  }

  helmetSwitchChange(val) {
    request.setBaseEventsSwitch('4',val).then((resp:any)=>{
       if(resp) {
          this.getAllEventSwitchInfo()
       }
    })
  }

  //获取第三方推送数据
  getAlarmUrlInfo(){
    request.getAlarmUrlInfo().then((resp:any)=>{
      console.log('获取第三方推送数据',resp)
      this.isAlarm = resp.switchController+'';
      this.alarmUrl = resp.pushRecordUrl;
    })
  }

  //设置推送开关
  switchAlarm(val){
    let that = this as any;
    let params = {
      switchController:val
    }
    console.log(val)
    this.isAlarm = '0'
    request.switchAlarm(params).then((resp:any)=>{
      console.log('设置推送',resp)
      if(resp){
        this.getAlarmUrlInfo();
        if(resp.switchController == '0'){
          this.$message({
            message: that.$t('systeminfo.alarmPushFalseTip'),
            type: 'success',
            // duration:0,
            showClose:true
          })
        }else{
          this.$message({
            showClose: true,
            message: that.$t('systeminfo.alarmPushTrueTip'),
            type: 'success',
            //  duration:0,
          })
        }
      }
    })
  }

  //设置推送地址
  updateAlarmUrl(){
    let _this = this;
    let params = {
      pushRecordUrl:this.systemForm.valueData
    }
    request.updateAlarmUrl(params).then((resp:any)=>{
      if(resp){

        _this.$message({
          showClose: true,
          message: _this.$tc('systeminfo.alarmPushUrlUpdateTips'),
          type: 'success'
        });

        _this.getAlarmUrlInfo();
        _this.cancelUpdata();
      }

    })
  }

  updateGuestInterimLibraryExtract(val){
    let params = {
      extract:val
    }
    getSystem.updateGuestInterimLibraryExtract(params).then((res)=>{
      console.log(res);
      this.recognition  = (res as any).extract + '';
      this.recognitionCopy  = (res as any).extract + '';
      console.log(this.recognition);
    }).catch((err)=>{
      this.recognition = this.recognitionCopy;
      console.log(err);
    })
  }
  getUpdateGuestInterimLibraryExtract(){
    getSystem.getUpdateGuestInterimLibraryExtract().then((res)=>{
      console.log(res);
      this.recognition  = (res as any).extract + '';
      this.recognitionCopy  = (res as any).extract + '';
    })
  }

  //展示修改标题
  showTitle(num) {
    let that = this as any
    this.descripetionChange = false;
    this.dialogShowVisible = true;
    this.isAlarmDiglog = false;
    this.systemRules = {}
    if (num === 1) {
      this.titleData = that.$t('systeminfo.buttonSystemTitleModify') //"更改标题";
      this.titleName = that.$t('systeminfo.contSystemTitle') //"系统标题";
      this.type = 'name'
      this.valueData = (this.language == 'en' ? this.systemInfo.systemName : this.systemInfo.systemNameZh)
    } else if (num === 2) {
      this.titleData = that.$t('systeminfo.titleLanguageSwitch') //"切换语言";
      this.titleName = that.$t('systeminfo.titleLanguageSwitch') //"语言类型";
      this.type = 'language'
    } else if (num === 3) {
      this.titleData = that.$t('systeminfo.titleReminderModify') //"更换提示";
      this.titleName = that.$t('systeminfo.contForgetPassword') //"忘记密码提示语";
      this.type = 'prompt'
      this.valueData = this.prompt
    } else if (num === 4) {
      this.isAlarmDiglog = true;
      this.titleData = that.$t('systeminfo.setAlarmPushUrl') //第三方接入;
      this.titleName = that.$t('systeminfo.alarmPushUrl') //第三方接入;
      this.type = 'alarmUrl'
      this.systemForm.valueData = this.alarmUrl
      this.systemRules = { required: true, type:'url',message:that.$tc('systeminfo.alarmPushUrlErrorTips'), trigger: 'blur', }
      console.log(this.systemForm.valueData)

    }else if (num === 5){
      this.descripetionChange = true;
      this.titleData = that.$t('systeminfo.descriptionChange') //"更换描述";
      // this.titleData = "更换描述";
      this.titleName = that.$t('systeminfo.systeminfoDescription') //"系统描述";
      // this.titleName = "系统描述";
      this.type = 'describe'//此参数为后端保存数据的key值
      this.valueData = this.describe;
    }
  }
  //上传图片前端展示
  upImage(e) {
    let vm = this
    vm.type = 'logo'
    let a = e.target.files as any
    this.conditions.file = a[0]
    let bool = vm.beforePicUpload(a[0])
    if (bool == false) {
      return
    }
    let reader = new FileReader() as any
    //将文件以Data URL形式读入页面
    reader.readAsDataURL(this.conditions.file)
    reader.onload = function() {
      //显示文件
      let selected = document.getElementById('selected') as any
      selected.setAttribute('src', this.result)
      // console.log(this.result);
      vm.valueData = this.result
      vm.updataSystem()
    }
  }
  //图片验证
  beforePicUpload(file) {
    let that = this as any
    let isFile = fileValidate(file, ['png', 'jpg', 'jpeg', 'bmp'], 16)
    if (!isFile.type) {
      this.$message.error({showClose: true,message:that.$t('imagemanagement.tipsPicType')})
      return false
    }
    if (!isFile.size) {
      this.$message.error({showClose: true,message:that.$t('imagemanagement.tipsOversize')})
      return false
    }
  }
  //更改设置
  updataSystem() {
    if(this.isAlarmDiglog){
      (this.$refs.systemForm as ElForm).validate((valid:boolean) => {
        console.log(valid)
        if(valid){
          this.updateAlarmUrl()
        }else{
          this.isSubmit = false;
        }
      })

      return false;
    }
    let num = 1
    if (this.language == 'en') {
      num = 2
    } else {
      num = 1
    }
    let params = {} as any
    params[this.type] = this.valueData
    params.language = num
    let that = this as any
    getSystem
      .updateSystemInfo(params)
      .then((data: any) => {
        if (this.type == 'name') {
          this.$message({
            // message: '更换标题成功',
            showClose: true,
            message: that.$t('globaltip.tipmsgChangeTitle'),
            type: 'success'
          })
        }
        if (this.type == 'logo') {
          this.$message({
            // message: '更换标志成功',
            showClose: true,
            message: that.$t('globaltip.tipmsgChangeLogo'),
            type: 'success'
          })
        }
        if (this.type == 'prompt') {
          this.$message({
            // message: '更换忘记密码提示语成功',
            showClose: true,
            message: that.$t('systeminfo.titleSwitchTips'),
            type: 'success'
          })
        }
        this.init()
        this.dialogShowVisible = false
        this.valueData = null
      })
      .catch(err => {})
  }
  cancelUpdata() {
    this.dialogShowVisible = false
  }
  init() {
    getSystem
      .getSystemInfo()
      .then((data: any) => {
        this.systemInfo = data
        if (data.logo !== null) {
          let logo = this.systemInfo.logo
          if (logo.indexOf('/') == 0) {
            logo = logo.slice(1)
          }
          this.systemInfo.logo =  processImgurl(logo)
        } else {
          this.systemInfo.logo = '/images/logo.png'
        }

        if (this.language == 'en') {
          this.prompt = data.promptEn
          this.systemNameVersion = data.systemNameVersionEn
          this.describe = this.systemInfo.describeEn
        } else {
          this.prompt = data.promptZh
          this.systemNameVersion = data.systemNameVersionZh
          this.describe = this.systemInfo.describeZh
        }
        getSystem.SET_LOGO(this.systemInfo.logo)
      })
      .catch(err => {})
  }

  created() {
    this.init()
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.info-container {
  height: 100%;
  display: flex;
  justify-content: center;
  // overflow: auto;
}
.paddl30{padding-left: 60px;}

.circle {
  display: block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: #011c50;
  position: absolute;
  top: 13px;
  left: -20px;
}
.title-one {
  width: 42%;
  height: 90%;
  background:rgba(255,255,255,1);
  border:1px solid rgba(223,223,224,1);
  box-shadow:0px 3px 6px rgba(0,0,0,0.16);
  opacity:1;
  border-radius:4px;
  padding: 0 10%;
  margin-top: 40px;

}
.title-one-right{
  padding: 0 2% 0 4%;
  .cc{
    width: 30%;
  }
  .c2{
    width: 21%;
  }
  .c3{
    width: 24%;
  }
  ::v-deep .el-progress-bar{
    padding-right: 10px;
  }
  .cc-en{
    width: 35%;
  }
}
.title {
  /*width: 40%;*/
  font-family: 'Hiragino Sans GB';
  color: #28354d;
}
.icon-user {
  color: #b3c1d2;
  font-size: 20px;
  vertical-align: middle;
}
.xin {
  line-height: 32px;
  color: #28354d;
  font-size: 20px;
  font-family: 'Hiragino Sans GB';
  white-space: nowrap;
}
.btn {
  height: 32px;
  width: 158px;
}
.info {
  width: 140%;
  display: flex;
}
.info-all{
  height: 14px;
  .c3{
    line-height: 14px;
  }
}
.info-title,
.info-msg {
  width: 70%;
  font-size: 14px;
  color: #28354d;
}
.info-title {
  color: #28354d;
  width: 30%;
  text-align: right;
  margin-right: 10px;
  a {
    opacity: 1;
    &:link {
      background: #011c53;
    }
  }
}
.info-msg {
  color: #2a5af5;
  opacity: 0.8;
}
.info-two {
  width: 125%;
  margin: 15px 0;
  display: flex;
}
.cc {
  text-align: right;
  padding-right: 10px;
  width: 50%;
  font-size: 14px;
}
.c2 {
  width: 75%;
  color: #2a5af5;
  opacity: 0.8;
  font-size: 14px;
  overflow: hidden;
  text-overflow:ellipsis;
  white-space: nowrap;
}
.c3 {
  width: 60%;
  text-align: left;
  position: relative;
}
.el-col {
  line-height: 36px;
}
a {
  color: #2a5af5;
  opacity: 0.8;
  text-decoration: underline;
}
.descripetion{
  width: 50%;
  font-weight: bolder;
  font-size: 18px;
}
.content {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  padding: 20px 0;
  width: 100%;
}
.content > div {
  width: 45%;
}
.content > div span {
  width: 100%;
  display: flex;
  line-height: 16px;
  margin-top: 10px;
}
::v-deep .el-dialog__footer {
  text-align: center !important;
}
.content > span {
  width: 50%;
  line-height: 32px;
  margin-top: 10px;
}
.content .left-name {
  margin-right: 10px;
  width: 30%;
  text-align: right;
}
.content .right-name {
  width: 50%;
}
.el-select {
  width: 100%;
}

.el-list ::v-deep .el-input__suffix {
  right: 10px !important;
  top: 3px !important;
}
/*.right-name ::v-deep .el-input {*/
/*  width: 75%;*/
/*}*/
.upFile {
  color: #2a5af5;
}
.left-name {
  font-size: 14px;
  font-weight: normal;
  font-stretch: normal;
  line-height: 16px;
  letter-spacing: 0px;
  color: #28354d;
}
.upload {
  position: absolute;
  width: 150px;
  height: 32px;
  cursor: pointer;
}
.img-wrapper{
  display: flex;
  justify-content: center;
  align-items: center;
}
#inp {
  display: none;
}
::v-deep .el-progress-bar__outer {
  background-color: #c2cad8;
}
.info-container {
  ::v-deep.el-progress__text {
    display: none;
  }
}
.info-container ::v-deep .strangerSwitch .el-switch__label{
  left: 40px;
  width: 180px;
}

.operationYunwei {
  margin-left: 41px;
}

</style>
