<template>
    <el-dialog
    :title="$t('task.titleEditTask')"
    :visible="visible"
    width="30%"
    class="isroll"
    :before-close="handleClose">
    <div v-if="visible" style="display:flex;flex-direction: column;align-items: center;padding-top:16px;max-height: 65vh;">
        <el-form ref="form" :model="form" :rules="rules" label-position="right" :label-width="labelWidth">
            <el-form-item :label="$t('task.contTaskName')" prop="taskName">
                <el-input v-model="form.taskName" placeholder=""></el-input>
            </el-form-item>
            <el-form-item prop="defaultDevices" :label="$t('rule.labelDevice')">
                {{form.defaultDevices}}
            </el-form-item>
            <el-form-item prop="snapStrategy" :label="$t('task.labelSnapStrategy')">
                <el-select
                v-model="form.snapStrategy"
                @change="snapStrategyChange"
                default-first-option>
                <el-option :label="'定时模式'" :value="1"></el-option>
                <el-option :label="'实时模式'" :value="0"></el-option>
                <el-option :label="'精准模式'" :value="-1"></el-option>
                </el-select>
                <el-popover
                 class="right-tips"
                  placement="bottom-start"
                  width="400"
                  trigger="hover"
                  >
                  <div class="moudle-tips" v-html="$t('task.moudleTips')"></div>
                  <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
                </el-popover>
            </el-form-item>
            <el-form-item prop="quickresponsetime" v-if="form.snapStrategy>0" :label="$t('task.labelQuickresponsetime')">
                <el-input-number style="width:217px" v-model="form.quickresponsetime" :min="1" step-strictly :step="1" ></el-input-number>
                <span class="right-tips">{{$t("pedestrian.sec")}}</span>
            </el-form-item>
            <el-form-item prop="time" :label="$t('task.contTimezone')">
                <el-select v-model="form.time" placeholder="" clearable>
                    <el-option
                    v-for="(timezone,timezoneIndex) in timezoneList"
                    :key="timezoneIndex"
                    :label="timezone.label"
                    :value="timezone.id">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item prop="specialAttribute" :label="$t('rule.contAttribute')">
                <el-select
                multiple
                collapse-tags
                v-model="form.specialAttribute"
                :placeholder="$t('rule.listAttributeNone')">
                <el-option
                    v-for="(item,itemIndex) in specialAttributeOptions"
                    :key="itemIndex"
                    :label="item.name"
                    :value="item.id">
                </el-option>
                </el-select>
            </el-form-item>
            <el-form-item prop="" :label="$t('task.contMinPersionSize')">
              <el-col :span="12">
                <el-form-item prop="" :label="$tc('task.contZoneWidth')" :label-width="subLabelWidth">
                  <el-input :disabled="!isLoadedVideo" @keydown.native="inputLimit" v-model="miniNumber.width" :class="minwidthError?'form-number-error':''"  @input="(v)=>handleInputWidthSize(v,'min')" type="number" style="width:60px"></el-input>
                </el-form-item>
                <span class="tips-gray">{{$t('rule.contmini')}}({{miniLimit.width}})</span><br>
                <el-button type="text" :disabled="!isLoadedVideo || minwidthError || minheightError" @click="showOnVideo('mini')">{{$t('task.contPreviewDraw')}}</el-button>
              </el-col>
              <el-col :span="12">
                <el-form-item prop="" :label="$tc('task.contZoneHeight')" :label-width="subLabelWidth">
                  <el-input :disabled="!isLoadedVideo" @keydown.native="inputLimit" v-model="miniNumber.height" :class="minheightError?'form-number-error':''" @input="(v)=>handleInputHeightSize(v,'min')" type="number"  style="width:60px"></el-input>
                </el-form-item>
                <span class="tips-gray">{{$t('rule.contmini')}}({{miniLimit.height}})</span><br>
                <el-button :disabled="!isLoadedVideo" type="text" @click="setDefault('mini')" :style="{'margin-left':language =='en'?'32px':'8px'}" >{{$tc('task.contResetDefault')}}</el-button>
              </el-col>
            </el-form-item>
            <el-form-item prop="" :label="$t('task.contMaxPersionSize')">
              <el-col :span="12">
                <el-form-item prop="" :label="$tc('task.contZoneWidth')" :label-width="subLabelWidth">
                  <el-input :disabled="!isLoadedVideo" @keydown.native="inputLimit" v-model="maxNumber.width" :class="maxwidthError?'form-number-error':''" @input="(v)=>handleInputWidthSize(v,'max')" type="number" style="width:60px"></el-input>
                </el-form-item>
                <span class="tips-gray">{{$t('rule.contLimit')}}({{maxLimit.width}})</span><br>
                <el-button type="text" :disabled="!isLoadedVideo || maxwidthError || maxheightError" @click="showOnVideo('max')">{{$t('task.contPreviewDraw')}}</el-button>
              </el-col>
              <el-col :span="12">
                <el-form-item prop="" :label="$tc('task.contZoneHeight')" :label-width="subLabelWidth">
                  <el-input :disabled="!isLoadedVideo" @keydown.native="inputLimit" v-model="maxNumber.height" :class="maxheightError?'form-number-error':''" @input="(v)=>handleInputHeightSize(v,'max')" type="number"  style="width:60px"></el-input>
                </el-form-item>
                <span class="tips-gray">{{$t('rule.contLimit')}}({{maxLimit.height}})</span><br>
                <el-button :disabled="!isLoadedVideo" type="text" @click="setDefault('max')" :style="{'margin-left':language =='en'?'32px':'8px'}" >{{$tc('task.contResetDefault')}}</el-button>
              </el-col>
            </el-form-item>
            <el-form-item prop="alarmLine" :label="$tc('task.contWarnLine')">
              <span style="color:#ccc;">{{linePointsList.length>0?$tc('task.contAlreadyWarnLine'):$tc('task.contYetWarnLine')}}</span>
            </el-form-item>
            <el-form-item prop="bodyPart" :label="$tc('task.contBodyPart')">
              <el-select v-model="form.bodyPart" >
                  <el-option
                  v-for="(part,partIndex) in bodyParts"
                  :key="partIndex"
                  :label="part.label"
                  :value="part.value">
                  </el-option>
              </el-select>
            </el-form-item>
            <el-form-item prop="lineDirect" :label="$tc('task.contLineDirection')">
              <el-select v-model="form.lineDirect" :disabled="linePointsList.length>0?false:true"
                    placeholder="">
                  <el-option
                  v-for="(line,lineIndex) in lineDirectionOptions"
                  :key="lineIndex"
                  :label="line.label"
                  :value="line.id">
                  </el-option>
              </el-select>
            </el-form-item>
        </el-form>
        <div class="addTaskPC-btns" v-if="videoPath">
            <div @click="beginDrawLine" >
                <i class="iconfont icon-edit1" ></i>{{$tc('task.contClickSetLine')}}
            </div>
            <div @click="restoreLine" >
                <i class="iconfont icon-restore" ></i>{{$tc('task.contResetDefault')}}
            </div>
        </div>
        <div class="addTaskPC-video" style="position:relative;width:532px;"  >
            <MediaPlayer v-if="videoPath" :showControl="false" type="1" name="test" :url="videoPath" @loadedmetadata="initDrawer" />
            <DrawLine ref="drawLine"
                @end="handleDrwaEnd"
                :style="{position:'absolute',left:0,top:0}"
                :width="sketchpadWidth"
                :height="sketchpadHeight"
                :drawModel="drawModel"  />
        </div>
    </div>
        <!-- footer -->
        <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitData" :loading="loading">{{$t('rule.buttonOK')}}</el-button>
        <el-button @click="handleClose" type="info">{{$t('rule.buttonCancel')}}</el-button>
        </span>
    </el-dialog>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from 'vue-property-decorator';
import {getTimezoneWithIntervals,getDevicesTreeData,getSpecialAttrs} from '@/api/rule';
import {getPCTaskDetail,editPCTask} from '@/api/task';
import TreeSelectRadio from "../../components/treeSelectRadio.vue";
import i18n from '@/lang/index';
import MediaPlayer from '@/components/media-player/index.vue';
import DrawLine from '../../components/drawLine.vue';
import {cloneDeep,trim} from 'lodash';
import {calculateClockDirection} from '@/utils/polygons.ts';
import { AppModule } from '@/store/modules/app';

const defaultMiniMax = {//default value
    miniLimit:{width:30,height:30},
    miniNumber:{width:30,height:30},
    maxNumber :{width:500,height:500},
    maxLimit  :{width:1920,height:1080}
};

@Component({
    components: {
        TreeSelectRadio,
        MediaPlayer,
        DrawLine
    },
})
export default class EditTaskPC extends Vue {
    /* props */
    @Prop({default:false}) visible!: boolean;
    @Prop({required:true}) taskId!: string;

    /* watch */
    @Watch('visible',{ immediate: true})
    onVisibleChange(n,o){
        n && this.initData();
    }
    @Watch('linePointsList',{ immediate: true})
    onLinePointsListChange(n,o){
        n && (this.form.alarmLine = n);
    }
    get language() {
        return AppModule.language;
    }

    get subLabelWidth(){
        return AppModule.language === 'en'?'48px':'20px';
    }
    /* data */
    $refs !:{
        drawLine,
        form:HTMLFormElement
    }
    form:{
        taskName:string;
        defaultDevices:string,
        time:any,
        specialAttribute:any[],
        alarmLine:any[],
        lineDirect:any,
        quickresponsetime:number,
        snapStrategy:number,
        bodyPart:string
    }={
        taskName:'',
        defaultDevices:'',
        time:'',
        specialAttribute:[],
        alarmLine:[],
        lineDirect:'',
        quickresponsetime:4,
        snapStrategy:1,
        bodyPart:'0.8,0'
    };
    rules={
        taskName:[
            { required: true,validator:this.validateTaskName, trigger: 'blur' },
        ],
        time:[
            { required: false},
        ],
        specialAttribute:[
            { required: false},
        ],
        alarmLine:[
            { required: true, message: i18n.tc('task.formSetWarnLine')},
        ],
        lineDirect:[
            { required: true, message: i18n.tc('task.formSetLineDirection')},
        ],
        quickresponsetime:[
            { required: true,message: i18n.t('form.texterrQuickresponsetime') },
        ],
        snapStrategy:[
            { required: true,message: '' },
        ],
        bodyPart:[
            { required: true,message: '' },
        ],
    };
    labelWidth:string="155px"
    treeData:any[]=[];
    timezoneList:any[]=[];
    specialAttributeOptions:any[]=[];
    miniLimit:any={width:defaultMiniMax.miniLimit.width,height:defaultMiniMax.miniLimit.height};
    miniNumber:any={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
    maxNumber:any={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
    maxLimit:any={width:defaultMiniMax.maxLimit.width,height:defaultMiniMax.maxLimit.height};
    lineDirectionOptions:any[]=[];
    bodyParts:any[]=[{label:'头部',value:'0,0.8'},{label:'脚部',value:'0.8,0'}]
    videoUrl:string='';
    sketchpadWidth:number=0;
    sketchpadHeight:number=this.sketchpadWidth*1080/1920;
    scale:any={x:1,y:1};
    drawModel:boolean=false;
    linePointsList:any[]=[];
    loading:boolean=false;
    deviceId:any=null;
    videoPath:string='';
    defaultData:any=null;

    minwidthError:boolean=false;
    maxwidthError:boolean=false;
    minheightError:boolean=false;
    maxheightError:boolean=false;
    isLoadedVideo:boolean=false;
    /* methods */
    mounted(){

    }
    //validate
    validateTaskName(rule, value, callback){
        let str = value;
        if (str === '') {
        callback(new Error(i18n.tc('task.texterrEnterTaskName')));
        } else {
            //去除两头空格:
            let regx = /^\s+|\s+$/g;
            while (regx.test(str)) {
                str   =  trim(str);
            };
            str   =  trim(str);
            if(str && str.length<=40){
                callback();
            }else{
                callback(new Error(i18n.tc('task.texterrEnterTaskName')));
            }
        }
    }
    initDefaultMiniMax(){
        this.miniLimit={width:defaultMiniMax.miniLimit.width,height:defaultMiniMax.miniLimit.height};
        this.miniNumber={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height};
        this.maxNumber={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height};
        this.maxLimit={width:defaultMiniMax.maxLimit.width,height:defaultMiniMax.maxLimit.height};
    }
    initData(){
        this.treeData=[];
        this.timezoneList=[];
        this.specialAttributeOptions=[];
        this.initDefaultMiniMax();
        this.lineDirectionOptions=[];
        this.videoUrl='';
        this.sketchpadWidth=0;
        this.sketchpadHeight=this.sketchpadWidth*1080/1920;
        this.scale={x:1,y:1};
        this.drawModel = false;
        this.loading=false;
        this.deviceId=null;
        this.videoPath='';
        this.defaultData=null;
        this.lineDirectionOptions = [
            {id:'AtoB',label:this.$tc('task.optionsLineDirectionAtoB')},
            {id:'BtoA',label:this.$tc('task.optionsLineDirectionBtoA')},
            {id:'AB',label:this.$tc('task.optionsLineDirectionAB')},
        ];
        //init form
        this.minwidthError=false;
        this.maxwidthError=false;
        this.minheightError=false;
        this.maxheightError=false;

        this.form={
            taskName:'',
            defaultDevices:'',
            time:'',
            specialAttribute:[],
            alarmLine:[],
            lineDirect:'',
            snapStrategy:1,
            quickresponsetime:4,
            bodyPart:'0.8,0'
        };
        this.isLoadedVideo = false;
        //get data
        this.getDevices();
        this.getTimezoneList();
        this.getSpecialAttrs();

        getPCTaskDetail(this.taskId).then((res:any)=>{
            res && this.formatDetailData(res);
            res && (this.defaultData = res)
        })
    }
    formatDetailData(res){
        this.deviceId = res.deviceId;
        this.form.taskName = res.taskName || '';
        this.form.quickresponsetime=res.quickResponseTime;
        this.setSnapStrategyValue(res.quickResponseTime);
        this.form.bodyPart = res.rectCut?(res.rectCut.x+','+res.rectCut.y):'';
        this.form.defaultDevices = res.deviceName || '';
        this.form.time = res.timeZoneId || '';
        this.form.specialAttribute = this.formatAttrs(res.taskAttributeVoList);
        res.vertices && res.vertices.minTarget && (this.miniNumber = res.vertices.minTarget);
        res.vertices && res.vertices.maxTarget && (this.maxNumber  = res.vertices.maxTarget);
        this.videoPath = res.videoPath;
        this.linePointsList = res.vertices && res.vertices.pointVoList &&  res.vertices.pointVoList.length > 0?res.vertices.pointVoList[0]:[];
        res.direction  && this.setDefaultLineDircet(res.direction);
    }
    setDefaultLineDircet(direction){
        let start = this.linePointsList[0],end=this.linePointsList[1];
        let d_obj = {AtoB:{x:0,y:0},BtoA:{x:0,y:0},AB:{x:0,y:0}};
        if(start.x == end.x){
                d_obj = {AtoB:{x:1,y:0},BtoA:{x:-1,y:0},AB:{x:0,y:0}};
        }else{
            let k = (start.y - end.y)/(start.x - end.x) ;
            if(k === 0){
                d_obj = {AtoB:{x:0,y:1},BtoA:{x:0,y:-1},AB:{x:0,y:0}};
            };
            if(k > 0){
                d_obj = {AtoB:{x:1,y:-1},BtoA:{x:-1,y:1},AB:{x:0,y:0}};
            };
            if(k < 0){
                d_obj = {AtoB:{x:1,y:1},BtoA:{x:-1,y:-1},AB:{x:0,y:0}};
            };
        }
        let k_ = '';
        Object.keys(d_obj).forEach(key=>{
            if(d_obj[key].x == direction.x && d_obj[key].y == direction.y) k_ = key;
        });
        this.form.lineDirect = k_;
    }
    setSnapStrategyValue(v){
        if(v>0){
        this.form.snapStrategy = 1;
        }else {
        this.form.snapStrategy = v;
        }
    }
    snapStrategyChange(v){
        v <= 0 && (this.form.quickresponsetime = v);
    }
    formatAttrs(attrs){
        let arr:any[]=[];
        attrs && attrs.length>0 && attrs.map(att=>{
            arr.push(att.taskAttributeId)
        });
        return arr;
    }
    deviceSlected(v){
        v && (this.form.defaultDevices = v);
    }
    getDevices(){
        let deviceType = 14;
        let filter = 0;
        getDevicesTreeData({deviceType,filter}).then(res=>{
            res && res.data && (this.treeData = res.data);
        })
    }
    getTimezoneList(){
        this.timezoneList = [];
        getTimezoneWithIntervals().then((res:any)=>{
            res && this.formatTimezoneList(res.data);
        })
    }
    formatTimezoneList(timezoneList){
        timezoneList && timezoneList.map((item,itemIndex)=>{
            this.timezoneList.push({
                id:item.timeZoneId,
                label:item.timeZoneName
            })
        })
    }
    getSpecialAttrs(){
        getSpecialAttrs(3).then((res:any)=>{
        res && res.list.map(item=>{
            this.specialAttributeOptions.push({
            id:item.taskAttributeId,
            name:this.$tc(`rule.${item.taskAttributeName}`),
            disabled:false
            })
        })
        })
    }
    inputLimit(e){
      let key = e.key;
      if (key === 'e' || key === '.') {
        e.returnValue = false
        return false
      }
      return true
    }
    handleInputWidthSize(val,type){
      //console.log(v)

      val = parseInt(val);
      console.log(val)
        if(type === 'min'){
          this.miniNumber.width = val
            if(val >= defaultMiniMax.miniLimit.width && val <= this.maxNumber.width && val<=defaultMiniMax.maxLimit.width){
                this.minwidthError = false;
                //this.maxwidthError = false;
            }else{
                this.minwidthError = true;
            }
            if(this.maxNumber.width >= defaultMiniMax.miniLimit.width && this.maxNumber.width >= val && this.maxNumber.width<=defaultMiniMax.maxLimit.width){
                //this.minwidthError = false;
                this.maxwidthError = false;
            }else{
                this.maxwidthError = true;
            }
        }
        if(type === 'max'){
          this.maxNumber.width = val
            if(val >= defaultMiniMax.miniLimit.width && val >= this.miniNumber.width && val<=defaultMiniMax.maxLimit.width){
                this.maxwidthError = false;
            }else{
                this.maxwidthError = true;
            }
            //if(40>=30 && 2000 >= 40 && 40< 1920)

            if(this.miniNumber.width >= defaultMiniMax.miniLimit.width && val >= this.miniNumber.width && this.miniNumber.width<=defaultMiniMax.maxLimit.width){
                this.minwidthError = false;
            }else{
                this.minwidthError = true;
            }
        }
    }
    handleInputHeightSize(v,type){
        let val = parseInt(v);
        if(type === 'min'){
          this.miniNumber.height = val

            if(val >= defaultMiniMax.miniLimit.height && val <= this.maxNumber.height && val<=defaultMiniMax.maxLimit.height){
                this.minheightError = false;
                //this.maxheightError = false;
            }else{
                this.minheightError = true;
            }
            if(this.maxNumber.height >= defaultMiniMax.miniLimit.height && this.maxNumber.height >= val && this.maxNumber.height<=defaultMiniMax.maxLimit.height){
                //this.minwidthError = false;
                this.maxheightError = false;
            }else{
                this.maxheightError = true;
            }
        }
        if(type === 'max'){
          this.maxNumber.height = val
            if(val >= defaultMiniMax.miniLimit.height && val >= this.miniNumber.height && val<=defaultMiniMax.maxLimit.height){
                //this.minheightError = false;
                this.maxheightError = false;
            }else{
                this.maxheightError = true;
            }

            if(this.miniNumber.height >= defaultMiniMax.miniLimit.height && val >= this.miniNumber.height && this.miniNumber.height<=defaultMiniMax.maxLimit.height){
                //this.minwidthError = false;
                this.minheightError = false;
            }else{
                this.minheightError = true;
            }
        }
    }
    initDrawer(video){
      this.isLoadedVideo = true;

        let origin_w = video.target.videoWidth,origin_h = video.target.videoHeight;
        let client_w = video.target.clientWidth,client_h = video.target.clientHeight;
        //set canvas
        this.sketchpadWidth  = client_w;
        this.sketchpadHeight = client_h;
        //set scale
        this.scale.x = client_w/origin_w;
        this.scale.y = client_h/origin_h;
        //set defaultt
        if(this.linePointsList.length>0){
            let arr = this.getOriginScaleForCoordinate(this.linePointsList);
            this.$nextTick(()=>{
                arr && arr.length == 2 && this.$refs.drawLine.drawLineAndMark(arr[0],arr[1]);
            })
        }
    }
    showOnVideo(type){
        if(this.$refs.drawLine){
            this.$refs.drawLine.clearAll();
            type == 'mini' && this.$refs.drawLine.drawRectangle(this.centerCoordinate(this.miniNumber));
            type == 'max' && this.$refs.drawLine.drawRectangle(this.centerCoordinate(this.maxNumber));
        }
    }
    setDefault(type){
      if(type == 'mini'){
        this.minwidthError=false;
        this.minheightError=false;
        this.miniNumber={width:defaultMiniMax.miniNumber.width,height:defaultMiniMax.miniNumber.height}
      }
      if(type == 'max'){
        this.maxwidthError=false;
        this.maxheightError=false;
        this.maxNumber={width:defaultMiniMax.maxNumber.width,height:defaultMiniMax.maxNumber.height}
      }
      this.showOnVideo(type);
    }
    centerCoordinate(size){
        let size_copy = cloneDeep(size);
        size_copy.width  = size_copy.width*this.scale.x;
        size_copy.height = size_copy.height*this.scale.y;
        let centerCoordinate = {x:this.sketchpadWidth/2,y:this.sketchpadHeight/2};
        let start = {x:centerCoordinate.x-(size_copy.width/2),y:centerCoordinate.y-(size_copy.height/2)};
        let end   = {x:centerCoordinate.x+(size_copy.width/2),y:centerCoordinate.y+(size_copy.height/2)};
        return [start,end];
    }
    beginDrawLine(){
        this.$refs.drawLine && this.$refs.drawLine.clearAll();
        this.linePointsList = [];
        this.form.lineDirect = '';
        this.drawModel = true;
    }
    restoreLine(){
        this.$refs.drawLine && this.$refs.drawLine.clearAll();
        this.linePointsList = [];
        this.form.lineDirect = '';
        this.drawModel = false;
    }
    handleDrwaEnd(data){
        this.linePointsList = this.setScaleForCoordinate(data);
        this.form.lineDirect = 'AB';
        this.drawModel = false;
    }
    translateDirection(lineDirect){
        if(this.linePointsList.length>0){
            let start = this.linePointsList[0],end=this.linePointsList[1];
            let d_obj = {AtoB:{x:0,y:0},BtoA:{x:0,y:0},AB:{x:0,y:0}};
            if(start.x == end.x){
                d_obj = {AtoB:{x:1,y:0},BtoA:{x:-1,y:0},AB:{x:0,y:0}};
            }else{
                let k = (start.y - end.y)/(start.x - end.x) ;
                if(k === 0){
                    d_obj = {AtoB:{x:0,y:1},BtoA:{x:0,y:-1},AB:{x:0,y:0}};
                };
                if(k > 0){
                    d_obj = {AtoB:{x:1,y:-1},BtoA:{x:-1,y:1},AB:{x:0,y:0}};
                };
                if(k < 0){
                    d_obj = {AtoB:{x:1,y:1},BtoA:{x:-1,y:-1},AB:{x:0,y:0}};
                };
            }
            return d_obj[lineDirect]
        }
        return null;
    }
    setScaleForCoordinate(list){
        let arr = [], _w = this.sketchpadWidth, _h = this.sketchpadHeight;
        if(_w > 0 && _h > 0 && list && list.length > 0){
            arr = list.map(item =>{
                let x = item.x/_w , y = item.y/_h;
                return {x,y}
            })
        }
        return arr.length>0?arr:list;
    }
    getOriginScaleForCoordinate(list){
        let arr = [], _w = this.sketchpadWidth, _h = this.sketchpadHeight;
        if(_w > 0 && _h > 0 && list && list.length > 0){
            arr = list.map(item =>{
                let x = item.x*_w , y = item.y*_h;
                return {x,y}
            })
        }
        return arr.length>0?arr:list;
    }
    handleClose(){
        this.$emit('hide')
    }
    submitData(){
        let data = {
            "taskId":this.taskId,
            "deviceId": this.deviceId,
            "direction": this.translateDirection(this.form.lineDirect),
            "taskAttributeIds": this.form.specialAttribute,
            "taskName": this.form.taskName,
            "taskType": 3,//行人越线
            "timeZoneId": this.form.time,
            "vertices": {
                "maxTarget": {
                    "height": this.maxNumber.height,
                    "width": this.maxNumber.width
                },
                "minTarget": {
                    "height": this.miniNumber.height,
                    "width": this.miniNumber.width
                },
                "pointVoList": [this.linePointsList]
            },
            "quickResponseTime":this.form.quickresponsetime,
            "rectCut":{x:this.form.bodyPart.split(',')[0],y:this.form.bodyPart.split(',')[1]},
        };
        if(data.vertices.pointVoList.length>0){
            data.vertices.pointVoList.map(arr=>{
                if(!calculateClockDirection(arr)) arr.reverse();
            })
        }
        (!this.minwidthError && !this.minheightError && !this.maxwidthError && !this.maxheightError) && this.deviceId && this.$refs.form.validate((isvalidate)=>{
            isvalidate && (this.loading = true);
            isvalidate && editPCTask(data).then(res=>{
                this.loading = false;
                this.$emit('successcal','pc');
                this.$emit('hide');
            }).catch(err=>{
                this.loading = false;
                this.$emit('errorcal','pc');
                this.$emit('hide');
            })
        })

    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.tables-container{
    .task-list-operation-item{
        cursor: pointer;
        margin-right: 8px;
        i.iconfont{
            font-size:19px;
        }
    }
}
::v-deep .el-select__tags .el-tag--info {
    color: #28354d;
}

.el-input{
    ::v-deep input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }
}
.addTaskPC-linkbtn{
    display: inline-block;
    color: #2A5AF5;
    cursor: pointer;
    text-decoration: underline ;
}
.addTaskPC-video{
    position: relative;
    width: 532px;
}
.addTaskPC-btns{
    display: flex;
    justify-content: space-between;
    width: 532px;
    padding-bottom: 8px;
    &>div{
        cursor: pointer;
        &:active{
            color: #2A5AF5;
        }
    }
}
::v-deep .el-select{
  width: 100%;
}
::v-deep .el-input.form-number-error .el-input__inner{
    border-color: #db4436;
}
</style>
