<template>
    <div>
        <canvas :class="['draw-line',drawModel && 'draw-line-draw']" 
            @mousedown="handleMousedown"
            @mousemove="e=>myDebounce(e)"
            @mouseenter="handleMouseenter"
            @mouseleave="handleMouseleave" ref="cvs" :width="width" :height="height"></canvas>
        <div v-show="drawModel && showPromt" class="draw-line-text" :style="{top:promptTop - 10 +'px',left:promptLeft+20+'px'}" >{{promtText}}</div>    
    </div>
</template>

<script lang="tsx">
import { Component, Vue,Watch ,Prop} from 'vue-property-decorator';
import {debounce,cloneDeep} from "lodash";
import i18n from '@/lang/index';
const POINTER_R = 7;
const POINTER_COLOR_BEGIN = '#FAA51E';
const POINTER_COLOR_END = '#DA5A34';
const PROMT_START_TEXT = i18n.tc('task.drawStart');
const PROMT_END_TEXT = i18n.tc('task.drawEnd');
const PROMT_MARK_DISTANCE = 16;

@Component({
    components: {

    },
    directives:{

    }
})

export default class DrawLine extends Vue {

    /* props */
    @Prop({required:true}) width !: number;
    @Prop({required:true}) height !: number;
    @Prop({required:true}) drawModel !: number;

    /* watch */

    /* data */
    $refs !:{
        cvs:HTMLCanvasElement
    };
    ctx:any=null;
    promptTop:number=0;
    promptLeft:number=0;
    promtText:string=i18n.tc('task.drawStart');
    showPromt:boolean=false;
    myDebounce:any = debounce((e)=>{ this.handleMouseMove(e) }, 30, {maxWait: 30});
    coordinateList:any[]=[];
    /* methods */
    mounted(){
        this.ctx = this.$refs.cvs.getContext('2d');
    }
    drawRectangle(rectangle:[{x:number,y:number},{x:number,y:number}]){
        rectangle && rectangle.length>0 && this.canvasRectangle(rectangle)
    }
    canvasRectangle(rectangle){
        let start = rectangle[0],
            end   = rectangle[1];
        this.ctx.beginPath(start.x,start.y);
        this.ctx.moveTo(start.x,end.y);
        this.ctx.lineTo(end.x,end.y);
        this.ctx.lineTo(end.x,start.y);
        this.ctx.lineTo(start.x,start.y);
        this.ctx.closePath();
        //style
        this.ctx.strokeStyle='#fff';
        this.ctx.stroke();
        this.ctx.fillStyle = 'rgba(255,255,255,.3)';
        this.ctx.fill();
    }
    clearAll(){
        this.coordinateList = [];
        this.ctx.clearRect(0, 0, this.width, this.height);
    }   
    handleMouseenter(){
        this.showPromt = true;
        if(this.coordinateList.length == 0) this.promtText = PROMT_START_TEXT;
    }
    handleMouseMove(e){
        if(!this.drawModel) return ;
        let x = e.offsetX,y = e.offsetY;
        this.promptTop  = y;
        this.promptLeft = x;
        if(this.coordinateList.length == 1){
            this.drawing(x,y);
        }
        
    }
    handleMouseleave(){
        if(!this.drawModel) return ;
        this.showPromt = false;
    }
    drawing(x,y){
        let start  = this.coordinateList[0];
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.drawArc(start.x,start.y,POINTER_COLOR_BEGIN);
        this.drawLine(start,{x,y},POINTER_COLOR_BEGIN);
    }
    handleMousedown(e){
        if(!this.drawModel) return ;
        let len = this.coordinateList.length;
        if(len >=2) return;
        let x = e.offsetX,y=e.offsetY;
        this.coordinateList.push({x,y});
        if(this.coordinateList.length == 1){//start
            this.drawArc(x,y,POINTER_COLOR_BEGIN)
            this.promtText = PROMT_END_TEXT
        }
        if(this.coordinateList.length == 2){//end
            this.toEndDrawLine();
            this.drawArc(this.coordinateList[0].x,this.coordinateList[0].y,POINTER_COLOR_END)
            this.drawArc(x,y,POINTER_COLOR_END)
        }
       
    }
    toEndDrawLine(){
        if(this.coordinateList.length == 2){
            let data = cloneDeep(this.coordinateList);
            this.showPromt = false;
            this.setLineDirectionMark();
            let start  = this.coordinateList[0],
            end    = this.coordinateList[1];
            this.drawLine(start,end,POINTER_COLOR_END);
            this.$emit('end',this.coordinateList)    
        }
    }
    drawArc(x,y,color){
        this.ctx.beginPath();
        this.ctx.arc(x,y,POINTER_R,0,2*Math.PI);
        this.ctx.fillStyle = color;
        this.ctx.fill();
        this.ctx.lineWidth = 1;
        this.ctx.strokeStyle = color;
        this.ctx.stroke();
        this.ctx.closePath();
    }
    drawLine(start,end,color){
        this.ctx.beginPath();
        this.ctx.moveTo(start.x,start.y);
        this.ctx.lineTo(end.x,end.y);
        this.ctx.closePath();
        //style
        this.ctx.lineWidth = 1;
        this.ctx.strokeStyle = color;
        this.ctx.stroke();
    }
    setLineDirectionMark(){
        let start  = this.coordinateList[0],
            end    = this.coordinateList[1],
            x1 = start.x,
            y1 = start.y,
            x2 = end.x,
            y2 = end.y;
        let cal_res = this.calculationAB(x1,y1,x2,y2);
        let setA   = cal_res.set_A;
        let setB   = cal_res.set_B;
        this.ctx.fillStyle = 'black';
        this.ctx.font = 'bold 18px verdana, sans-serif ';
        this.ctx.fillText('A',setA.x,setA.y,20);
        this.ctx.fillText('B',setB.x,setB.y,20);
    }
    calculationAB(x1,y1,x2,y2){// left -> A  top -> A 
        let A  = y2 - y1,B = x1 - x2,C = x2*y1 - x1*y2;
        let x0 = (x1 + x2)/2,y0 = (y1 + y2)/2;
        let d  = 25;//distance
        let x3 = 0,y3=0,x4=0,y4=0;
        if(x1 == x2){
            x3 = x0 - d;
            y3 = y0;
            x4 = x0 + d;
            y4 = y0;
        }else if(y1 == y2){
            x3 = x0;
            y3 = y0 - d;
            x4 = x0;
            y4 = y0 + d;
        }else if(x1 == x2 && y1 == y2){
            x3 = x0;
            y3 = y0;
            x4 = x0;
            y4 = y0;
        }else{
            let x3_ =  A*d/Math.sqrt(Math.pow(A,2) + Math.pow(B,2)) - A*C/(Math.pow(A,2) + Math.pow(B,2)) -(A*B*y0 - x0*Math.pow(B,2))/(Math.pow(A,2) + Math.pow(B,2));
            let x4_ = -A*d/Math.sqrt(Math.pow(A,2) + Math.pow(B,2)) - A*C/(Math.pow(A,2) + Math.pow(B,2)) -(A*B*y0 - x0*Math.pow(B,2))/(Math.pow(A,2) + Math.pow(B,2));
            x3 = Math.min(x3_,x4_);
            y3 = B/A*x3 + y0 - B*x0/A;
            x4 = Math.max(x3_,x4_);
            y4 = B/A*x4 + y0 - B*x0/A;
        }
        let set_A = {x:x3,y:y3},set_B = {x:x4,y:y4};
        return {set_A,set_B};
    }
    drawLineAndMark(start,end){
        this.ctx.beginPath();
        this.ctx.moveTo(start.x,start.y);
        this.ctx.lineTo(end.x,end.y);
        this.ctx.lineWidth = 1;
        this.ctx.strokeStyle = POINTER_COLOR_END;
        this.ctx.stroke();
        this.ctx.closePath();
        //point
        this.drawArc(start.x,start.y,POINTER_COLOR_END);
        this.drawArc(end.x,end.y,POINTER_COLOR_END);
        //mark
        this.coordinateList[0] = start;
        this.coordinateList[1] = end;
        this.setLineDirectionMark();
        
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.draw-line-draw,.draw-line-text{
    cursor: url("/images/positting.svg") 16 16, default ;
}
.draw-line-text{
    position: absolute;
    background-color: rgba($color: #000000, $alpha: .5);
    padding: 4px;
    color: white;
    border-radius: 2px;
}
</style>
