<template>
  <el-dialog
  :title="$t('rolemanagement.titleReminder')"
  :visible.sync="visible"
  width="30%"
  custom-class="view-rule-td-dialog-container"
  :center="true"
  :before-close="handleClose">
  <!-- title -->
  <p slot="title" style="text-align:left" >{{$t('rule.titleSurveillanceView')}}</p>
  <!-- content -->
  <div style="max-height:calc(70vh - 106px);overflow:auto;">
    <el-form ref="form" :model="form" label-position="left">
      <br/>
      <el-form-item :label-width="labelWidth" :label="$t('rule.contRulesetName')">
        {{form.ruleGroupName}}
      </el-form-item>
      <el-form-item :label-width="labelWidth" :label="$t('rule.labelRuleName')">
        {{form.ruleName}}
      </el-form-item>
      <el-form-item :label-width="labelWidth" :label="$t('rule.contDevice')">
          {{form.device}}
      </el-form-item>
       <el-form-item :label-width="labelWidth" :label="$t('rule.labelDeviceGroup')">
          {{form.deviceGroupName}}
      </el-form-item>
      <el-form-item :label-width="labelWidth" :label="$t('rule.labelAttribute')">
        {{form.specialAttribute}}
      </el-form-item>
      <el-form-item v-show="showKeeperSelect" :label-width="labelWidth" :label="$t('rule.labelAssociatedKeeper')">
        <KeeperSelect :devices="treeDataKeepers" :checkedDevices="defaultCheckedKeepers" type="view" />
      </el-form-item>
    </el-form>

    <el-row style="width:62%;margin:0 auto;">

        <el-col :span="24" v-show="!showKeeperSelect && showLibrary" >
          <div class="view-rule-td-libs" >
            <header class="view-rule-td-libsheader view-rule-td-libsheader-libs">
              <b>{{$t('rule.labelOnlistLibrary')}}：</b>
              <span>{{this.$t('rule.contSelected',{number:selsectedLibs.length})}}</span>
            </header>
            <div  class="view-rule-td-libs-scrollbox">
              <el-tree :data="libsList" node-key="id" ref="treeLibs"></el-tree>
            </div>
          </div>
        </el-col>
        <el-col :span="24" >
          <el-form ref="form2" :model="form2" label-position="left">
            <el-form-item label-width="70px" :label="$t('rule.contThreshold')">
              {{Number(form2.threshold*100).toFixed(1)}}%
            </el-form-item>
            <el-form-item :label-width="labelWidth" prop="welcome" :label="$t('rule.contWelcone')" v-if="showWelcome">
              <el-collapse >
                <el-collapse-item v-for="item in form2.welcome" :title="item.libraryName" :name="item.libraryId" :key="item.libraryId" >
                  <div>{{item.welcomingRemarks}}</div>
                </el-collapse-item>
              </el-collapse>
            </el-form-item>
            <el-form-item :label-width="labelWidth" prop="welcomebg" :label="$t('rule.contWelconebg')" v-if="showWelcome">
              <el-image :src="processImgurl(form2.welcomebg)">
                <div slot="error" class="image-slot">
                  <i class="el-icon-picture-outline"></i>
                </div>
              </el-image>
            </el-form-item>
          </el-form>
        </el-col>
    </el-row>

    <el-row>
      <el-col :span="24" >
        {{$t('rule.contOtherSetting')}}
      </el-col>
      <el-col :span="24" style="padding-top:20px;">
        <div class="sapce-border" ></div>
      </el-col>
      <el-col :span="24">
        <el-row>
          <el-col class="view-rule-td-other-header" >
            <div class="view-rule-td-other-header-label" >{{$t('rule.contMinFaceSize')}}</div>
            <div class="view-rule-td-other-header-input" >
              <span>{{minFace.width}}*{{minFace.height}}</span>
            </div>
          </el-col>
          <el-col class="view-rule-td-other-header" >
            <div class="view-rule-td-other-header-label" >{{$t('rule.contMaxFaceSize')}}</div>
            <div class="view-rule-td-other-header-input" >
              <span>{{maxFace.width}}*{{maxFace.height}}</span>
            </div>
          </el-col>
          <el-col class="view-rule-td-other-header" >
            <div class="view-rule-td-other-header-label" >{{$t('rule.contRecognitionArea')}}</div>
            <div class="view-rule-td-other-header-input" >
              <span >{{hotZone.length>0?$t('rule.contDrawn'):$t('rule.contNone')}}</span>
            </div>
          </el-col>
          <el-col :span="24" class="view-rule-td-videodrawer" v-if="currentCamera && currentCamera.videoPath" >
            <PolygonDrawer
              v-if="currentCamera && currentCamera.videoPath"
              :videoUrl="currentCamera?currentCamera.videoPath:''"
              :rects="[]"
              :polygons="polygonsData"
              @finish="drawerPolygonsFinsh"
              :drawingPolygon="drawingPolygon"
              :drawingRect="drawingRect" />
          </el-col>
        </el-row>
      </el-col>
    </el-row>
  </div>

    <!-- footer -->
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="hide(true)">{{$t('rule.buttonOperationEdit')}}</el-button>
      <el-button @click="hide(false)" type="info">{{$t('rule.buttonCancel')}}</el-button>
    </span>
  </el-dialog>
</template>

<script lang="ts">
import { Component, Vue , Watch, Prop} from 'vue-property-decorator';
import TreeSelect from '@/components/tree-select/index.vue';
import {cloneDeep} from 'lodash';
import PolygonDrawer from '../../components/polygon-drawer.vue';
import {addTDRule,getSpecialAttrs,getDevices,getRuleListByKeepers,getRuleTDDetail,getDevicesTreeData} from '@/api/rule';
import KeeperSelect from '../../components/keeperSelect.vue';
import {processImgurl} from '@/utils/image';

@Component({
  components: {
    TreeSelect,
    PolygonDrawer,
    KeeperSelect
  },
})
export default class ViewRuleTD extends Vue {
  /* props */
  @Prop({default:false}) visible!: boolean;
  @Prop({default:''}) ruleId!: string;
  @Prop({default:''}) backgroundImage!: string;
  /* watch */
  @Watch('visible')
  onVisibleChange(n,o){
    n && this.initData();
  }
  @Watch('backgroundImage')
  onbackgroundImageChange(n,o){
    n && (this.form2.welcomebg = n);
  }
  /* data */
  $refs!:{
    treeLibs:HTMLFormElement
  };
  processImgurl:any=processImgurl;
  labelWidth:string='145px';
  form:any={
    ruleGroupName:"",
    ruleName:'',
    device:"",
    deviceGroupName:'',
    specialAttribute:'',
  };
  form2:any={
    threshold:0,
    welcome:[],
    welcomebg:''
  };
  timeCheckListModel:any[]=[];
  libsCheckListModel:any[]=[];
  libsList:any[]=[{id:-1,label:"",children:[]},{id:0,label:"",children:[]}];

  treeDataCameras:any[] = [];
  treeDataKeepers:any[] = [];
  defaultCheckedCameras:any[] = [];
  defaultCheckedKeepers:any[] = [];
  props:any=this.$props;

  selectedSenseKeeperList:any[]=[];
  selectedSenseKeeperRuleIds:any[]=[];
  selectedTimesList:any[]=[];
  selectedLibsList:any[]=[];

  hotZoneInput:string="";
  minFace:any={width:50,height:50};
  maxFace:any={width:100,height:100};
  hotZone:any=[];

  currentCamera:any={};

  polygonsData:any[] = [];
  rectsData:any[]=[];
  drawPolygonsFinistData:any[]=[];
  drawingPolygon:boolean = false;
  drawingRect:boolean = false;

  showDrawer:boolean=false;
  currentEditType:string="";

  showVideo:boolean=false;
  keepersTimezoneLibsRelation:any[]=[];

  selsectedLibs:any[]=[];

  showKeeperSelect:boolean=false;
  showWelcome:boolean=false;
  showLibrary:boolean=true;

  /* methods */
  initData(){
    this.treeDataCameras= [];
    this.treeDataKeepers= [];
    this.defaultCheckedCameras = [];
    this.defaultCheckedKeepers = [];
    this.currentCamera = {};
    this.form.specialAttribute = '';
    this.form2.threshold = 0;
    this.form2.welcome = [];

    this.selectedSenseKeeperList=[];
    this.selectedSenseKeeperRuleIds=[];
    this.selectedTimesList=[];
    this.selectedLibsList=[];
    this.libsList = [{id:-1,label:this.$tc('rule.contWhitelist'),children:[]},{id:0,label:this.$tc('rule.contBlacklist'),children:[]}];

    this.hotZoneInput=this.$tc('rule.contNone');
    this.minFace={width:50,height:50};
    this.maxFace={width:100,height:100};
    this.hotZone=[];

    this.showDrawer = false;
    this.polygonsData = [];

    this.getDevices(1);//camera
    this.getDevices(2);//keeper
    //detail
    this.getRuleDetail();

    this.selsectedLibs = [];
    this.showWelcome=false;
    this.showLibrary = true;
  }
  getRuleDetail(){
    //set checked keeper
    getDevicesTreeData({deviceType:2}).then(tree=>{
      this.treeDataKeepers = tree.data;
      getRuleTDDetail(this.ruleId).then((res:any)=>{
        this.form.ruleGroupName = res.taskGroupVo.taskGroupName;
        this.form.device = res.deviceVo.deviceName;
        this.form.deviceGroupName = res.deviceVo?this.formatGroupName(res.deviceVo.deviceGroupList).groupName:'';

        this.form.ruleName = res.taskName;
        this.form.specialAttribute = this.formatAttrsText(res.taskAttributeVos);
        if(res.taskAttributeVos && res.taskAttributeVos.some(item=>item.taskAttributeId == 3)){
          this.showKeeperSelect = true;
        }else{
          this.showKeeperSelect = false;
        }

        if(res.taskAttributeVos){
          this.showLibrary = !res.taskAttributeVos.some(item=>item.taskAttributeId == 5);
        }
        this.formatLibs({blacklists:res.blackLibraries,whitelists:res.whiteLibraries});
        this.form2.threshold = res.threshold;
        this.form2.welcome = res.welcomeRemarkList;
        // this.form2.welcomebg = res.backgroundImage;
        this.minFace = res.hotRegionVo?res.hotRegionVo.minFace:{width:50,height:50};
        this.maxFace = res.hotRegionVo?res.hotRegionVo.maxFace:{width:100,height:100};
        this.hotZone = res.hotRegionVo?res.hotRegionVo.hotRegionPoints:[];
        this.currentCamera = res.deviceVo;
        this.polygonsData=res.hotRegionVo?this.formatPolygonsData(res.hotRegionVo.hotRegionPoints):[];
        //set defaut keeper list
        let defaultKeeperIds = this.formatOnlyKeepersIds(res.bindAcTasks);
        this.setDefaultSelectedKeeperList(res.bindAcTasks);
        this.getRuelIdsBykeepersIds(defaultKeeperIds);
        this.defaultCheckedKeepers=defaultKeeperIds;
      });
    });

  }
  setDefaultSelectedKeeperList(bindAcTasks){
    if(bindAcTasks && bindAcTasks.length>0){
      bindAcTasks.map(item=>{
        this.selectedSenseKeeperList.push({
          id:item.deviceVo.deviceId,
          name:item.deviceVo.deviceName
        });
      });
      let firstKeeper = this.selectedSenseKeeperList[0];
      getRuleListByKeepers([firstKeeper.id]).then((res:any)=>{
        res && (this.keepersTimezoneLibsRelation = res.list);
        this.clickKeeperItem(this.selectedSenseKeeperList[0],0);
        this.selectedTimesList.length>0 && this.selectedTimesList[0] && this.clickTimezoneItem( this.selectedTimesList[0],0);
      });
    };
  }
  formatGroupName(deviceGroupList){
    let groupName:string='',groupNames:string='',len = deviceGroupList.length;
    groupName = deviceGroupList[len-1].name;
    deviceGroupList.map((item,itemIndex)=>{
      groupNames+=item.name+(itemIndex == (len -1)?'':'>');
    });
    return {groupName,groupNames};
  }
  formatPolygonsData(polygonsData){
    return polygonsData.length>0?[{points:polygonsData}]:[];
  }
  formatOnlyKeepersIds(bindAcTasks){
    let arr:any = [];
    bindAcTasks.map((item)=>{
      arr.push(item.deviceVo.deviceId)
    });
    return arr;
  }
  formatAttrsText(taskAttributeVos){
    let arr:any=[];
    taskAttributeVos.map(item=>{
      item.taskAttributeId == 5 && (this.showWelcome = true);
      arr.push(this.$tc(`rule.${item.taskAttributeName}`))
    });
    let str = '';
    if(arr.length>0){
      str = arr.join(',');
    }
    return str;
  }
  getDevices(type?){
    let deviceType = type?type:1;
    getDevices({deviceType,page:1,size:100,sort:'DESC'}).then(res=>{
      this.formatTreeData(res.data,type);
    })
  }
  formatTreeData(list,type){
    list.map(item=>{
      type == 1 && this.treeDataCameras.push({
        id:item.deviceId,
        label:item.deviceName,
        type:'camera',
        url:item.videoPath
      });
      type == 2 && this.treeDataKeepers.push({
        id:item.deviceId,
        label:item.deviceName,
        type:'keeper',
        url:item.videoPath
      });
    });
  }
  hide(isEdit:boolean){
    this.$emit('hideViewRuletdDialog',isEdit)
  }
  handleClose(){
    this.hide(false);
  }
  selectedKeeper(data){
    if(data && data.length>0){
      this.defaultCheckedKeepers = this.getOnlyKeeperIds(data);
      this.selectedSenseKeeperList = data;
      this.getRuelIdsBykeepersIds(this.getOnlyKeeperIds(data));
    }else{
      this.selectedSenseKeeperList = [];
      this.getRuelIdsBykeepersIds([]);
    }

  }
  getOnlyKeeperIds(list){
    let arr:any = [];
    list.map((item)=>{
      arr.push(item.id)
    })
    return arr;
  }
  setKeeperListActiveEmpty(){
    this.selectedSenseKeeperList && this.selectedSenseKeeperList.map((keeper,keeperIndex)=>{
      let keeper_clone = cloneDeep(keeper);
      keeper_clone['active'] = false;
      Vue.set(this.selectedSenseKeeperList,keeperIndex,keeper_clone);
    })
  }
  setTimezoneListActiveEmpty(){
    this.selectedTimesList && this.selectedTimesList.map((timezone,timezoneIndex)=>{
      let timezone_clone = cloneDeep(timezone);
      timezone_clone['active'] = false;
      Vue.set(this.selectedTimesList,timezoneIndex,timezone_clone);
    });
  }
  clickKeeperItem(keeper,keeperIndex){
    this.setKeeperListActiveEmpty();
    let keeper_clone = cloneDeep(keeper);
    keeper_clone['active'] = true;
    Vue.set(this.selectedSenseKeeperList,keeperIndex,keeper_clone);
    //点击keeper
    this.selectedTimesList = [];
    this.selectedTimesList = this.getTimezonesFromRelations(keeper.id);
  }
  clickTimezoneItem(timezone,timezoneIndex){
    this.setTimezoneListActiveEmpty();
    let timezone_clone = cloneDeep(timezone);
    timezone_clone['active'] = true;
    Vue.set(this.selectedTimesList,timezoneIndex,timezone_clone);
    //点击timezone
    this.selectedLibsList = [];
    this.selectedLibsList = timezone.libraryVos;
  }
  getTimezonesFromRelations(keeperid){
    let currentKeeperIndex = this.keepersTimezoneLibsRelation.findIndex(item=> item.deviceVo.deviceId == keeperid);
    let currentKeeper = this.keepersTimezoneLibsRelation[currentKeeperIndex];
    let currentTimezones = currentKeeper.timezoneLibraryRelation;
    return currentTimezones;
  }
  //libslist
  formatLibs(res){
    this.selsectedLibs = [];
    this.libsList = [{id:-1,label:this.$tc('rule.contWhitelist'),children:[]},{id:0,label:this.$tc('rule.contBlacklist'),children:[]}];
    res.whitelists && res.whitelists.map((item:any)=>{
      this.libsList[0].children.push({
        id:item.libraryId,
        label:item.libraryName
      });
      this.selsectedLibs.push(item)
    });
    res.blacklists && res.blacklists.map((item:any)=>{
      this.libsList[1].children.push({
        id:item.libraryId,
        label:item.libraryName
      });
      this.selsectedLibs.push(item)
    });
  }
  drawPreviewVideo(type){
    this.currentEditType = type;
    this.editTypeChange(type);
  }
  resetDraw(type:string){
    this.drawingRect = false;
    this.drawingPolygon = false;
    if(type === 'minFace'){
      this.rectsData = [];
      this.minFace = {width:50,height:50};
    };
    if(type === 'maxFace'){
      this.rectsData = [];
      this.maxFace = {width:100,height:100};
    };
    if(type === 'hot'){
      this.polygonsData = [];
      this.hotZone = [];
      this.hotZoneInput = this.$tc('rule.contNone');
    };
  }
  drawerPolygonsFinsh(data){
    this.drawPolygonsFinistData = data;
    if(this.currentEditType == 'hot' ){
      this.hotZone = data;
      this.hotZoneInput = this.$tc('rule.contDrawn');
    }else if(this.currentEditType == 'minFace') {
      this.minFace = this.calculationRect(data);
    }else if(this.currentEditType == 'maxFace'){
      this.maxFace = this.calculationRect(data);
    }
  }
  clearHotDraw(){
    this.drawingPolygon = false;
    this.drawingRect = false;
    this.polygonsData = [];
  }
  editTypeChange(type:string){
    if(type === 'minFace'){
      this.drawingPolygon = false;
      this.drawingRect = true;
    }
    if(type === 'maxFace'){
      this.drawingPolygon = false;
      this.drawingRect = true;
    }
    if(type === 'hot'){
      this.drawingPolygon = true;
      this.drawingRect = false;
    }
  }
  calculationRect(data){
    let w:number = data.rightBottom && data.leftTop? data.rightBottom.x -data.leftTop.x : 0;
    let h:number = data.rightBottom && data.leftTop? data.rightBottom.y -data.leftTop.y : 0;
    let obj = {width:Math.round(w),height:Math.round(h),pointVos:[data.leftTop,data.rightBottom]};
    return obj;
  }
  getRuelIdsBykeepersIds(keeperIds){
    let acTaskListRequest = keeperIds;
    acTaskListRequest && acTaskListRequest.length>0 && getRuleListByKeepers(acTaskListRequest).then((res:any)=>{
      this.selectedSenseKeeperRuleIds = [];
      res && (this.keepersTimezoneLibsRelation = res.list);
      res && (this.selectedSenseKeeperRuleIds = this.getOnlyRuleIds(res.list));
    })
  }
  getOnlyRuleIds(keepersTimezoneLibsRelation:any[]){
    let arr:any = [];
    keepersTimezoneLibsRelation.map((item)=>{
      arr.push(item.taskId)
    });
    return arr;
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .view-rule-td-threshold{
    width: 120px;
  }
  .view-rule-td-libs{
    // border-bottom: 1px solid $--border-color-form;
    padding-bottom: 20px;
    &>div{
      box-sizing:border-box;
    }
    .view-rule-td-border-left{
      border-left: 1px solid $--border-color-form;
    }
    .view-rule-td-libsheader{
      height: 24px;
      background-color: $--color-primary;
      line-height: 24px;
      color: $--color-white;
      text-indent: 8px;

    }
    .view-rule-td-libsheader-libs{
      background-color: $--color-white;
      color:$--color-black;
      display: flex;
      justify-content: space-between;
      padding-bottom: 30px;
    }
    .view-rule-td-libs-scrollbox{
      width: 100%;
      max-height: 225px;
      overflow: auto;
      min-height: 50px;
      .view-rule-td-listitem{
        padding:8px 5px;
        cursor: pointer;
      }
      .view-rule-td-listitem:hover{
        background-color: $--color-bg-3;
      }
      .view-rule-td-listitem-active{
        background-color: $--color-bg-3;
        position: relative;
        .view-rule-td-icon-right{
          position: absolute;
          right: 5px;
          top: calc(50% - 8px);
        }
      }
      .view-rule-td-listitem-text{
        display: inline-block;
        width: calc(100% - 20px);
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap
      }
    }


  }
  .view-rule-td-other-header{
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    .view-rule-td-other-header-label{
      line-height: 40px;
      width: 115px;
      margin-right: 10px;
      text-align: left;
    }
    .view-rule-td-other-header-input{
      width:242px;
      line-height: 40px;
      .view-rule-td-inputsnumber{
        width: 70px;
        text-align: center;
        display: inline-block;
        .el-input{
          ::v-deep input[type=number]::-webkit-inner-spin-button,
          input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
          }
        }

      }
    }
  }
  .view-rule-td-videodrawer{
    background-color: $--color-black;
    padding: 10px;
  }
  .sapce-border{
    width: 100%;
    height: 0px;
    border: solid 1px #8e99aa;
    opacity: 0.5;
    margin-bottom: 20px;
  }
::v-deep .el-form{
      max-width: 330px;
      margin: 0 auto;
    }
  .view-rule-td-keepertreeinput{
    width: 100%;
  }
::v-deep .view-rule-td-dialog-container{
    max-height: 70vh;
    min-width: 600px;
    //overflow: auto; // 避免弹出层两个滚动条
    & > .el-dialog__body{
      max-height: calc(70vh - 106px);
      overflow: auto;
    }
  }
// ::v-deep .el-form-item.is-required:not(.is-no-asterisk)>.el-form-item__label{
//     position: relative;
//     &:before {
//       position: absolute;
//       left: -8px;
//     }
//   }
  // ::v-deep .view-rule-td-libs-scrollbox .el-tree>.el-tree-node>.el-tree-node__content{
  //   background-color: #e8ebf5;
  //   color: #000;
  // }
  // ::v-deep .view-rule-td-libs-scrollbox .el-tree .el-tree-node .el-tree-node__content:hover{
  //   background-color:#e8ebf5;
  //   color: #2a5af5;
  // }
</style>
