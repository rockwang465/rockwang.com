<template>
    <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span style="font-size:18px">
        {{$t('messageCenter.statusNotice')}}
      </span>
      <span style="float: right; padding: 3px 0" type="text">{{reverseType(data.taskType)}}</span>
    </div>
    <div style="height:200px;overflow:scroll">
      <div v-for="(val,key) in data.userMsgCenterDataList" :key="key" class="text item">
        <div style="width:100%;margin-bottom:10px;">{{val.taskName}}</div>
        <el-progress
        v-if="val.taskStatus===3"
        :percentage="val.progress"
        class="progress"
        />
        <div v-else class="progress" >
          <Icon name="zip" size="30"/>
        </div>
        <div class="status">
          <span v-if="val.taskStatus===3 && data.taskType!=20" class="can-down" @click="cancelExport(val)">{{$t("messageCenter.clickCancel")}}</span>
          <span v-if="val.taskStatus===1 && data.taskType!=20" class="can-down" @click="doDownload(val)">{{$t("messageCenter.clickDownload")}}</span>
          <span v-if="val.taskStatus===2 && data.taskType!=20" @click="retry(val)" class="can-down">{{$t("messageCenter.clickRetry")}}</span>
          <Icon
            v-if="val.taskStatus==1"
            class="delete"
            type="ele"
            name="error"
            @click="cancelExport(val)"
          />

        </div>
      </div>
    </div>
  </el-card>
</template>

<script lang="ts">
  import { Component, Vue, Watch } from 'vue-property-decorator';
  import {exportDownload} from '@/api/message-center';
  import  Icon from '@/components/icon-wrap/index.vue';
  import  { messageCenter as store } from '@/store/modules/message-center';
  var download = window.globalConfig.download
  @Component({
    props: {
      data:{
        type:Object,
        default:{},
      }
    },
    components: {
      Icon,
    },
  })


export default class ExportBatch extends Vue {
  @Watch('data', { immediate: true, deep: true })
  ondataChanged(val, oldVal) {
    store.set_new_message("")
  }
  mounted(){
  }
  //下载
  doDownload(param){
    let data:any = {}
    data.taskId = param.taskId
    data.actionType = "2"
    let form = document.createElement('form');
    form.method = "POST";
    form.action = download;
    let input = document.createElement('input');
    input.type='hidden';
    input.name='taskId';
    input.value=param.taskId;
    form.appendChild(input)
    let input2 = document.createElement('input');
    input2.type='hidden';
    input2.name='actionType';
    input2.value='2';
    form.appendChild(input2)
    document.body.appendChild(form)
    form.submit()
  }
  //重试
  retry(param){
    let data:any = {}
    data.taskId = param.taskId
    data.actionType = "1"//重试
    this.doSubmit(data)
  }
  //取消
  cancelExport(param){
    let data:any = {}
    data.taskId = param.taskId
    data.actionType = "0"//重试
    this.doSubmit(data)
  }
  doSubmit(data){
     exportDownload(data).then((data)=>{

    })
  }
  reverseType(val){
    let type;
    switch (val) {
      case 10:
        type=this.$t("messageCenter.facialExport");
        break;
      case 11:
        type=this.$t("messageCenter.recordExport");
        break;
      case 12:
        type=this.$t("messageCenter.operationLogExport");
        break;
      case 13:
        type=this.$t("messageCenter.retrievalCaptureExport");
        break;
      case 14:
        type=this.$t("messageCenter.retrievalCaptureExport");
        break;
      case 15:
        type=this.$t("messageCenter.retrievalFacialExport");
        break;
      case 16:
        type=this.$t("messageCenter.userExport");
        break;
      case 17:
        type=this.$t("messageCenter.roleExport");
        break;
      case 18:
        type=this.$t("messageCenter.visitorExport");
        break;
      case 20:
        type=this.$t("messageCenter.facialInlibrary");
        break;
      case 21:
        type=this.$t("21");
        break;
      case 22:
        type=this.$t("messageCenter.upDataFail");
      break;
      case 101:
        type=this.$t("messageCenter.attendanceExportPrivate");
        break;
      case 102:
        type=this.$t("messageCenter.attendanceExportCompany");
        break;
      case 103:
        type=this.$t("messageCenter.deviceExportPrivate");
        break;
      default:
        type=val;
        break;
    }
    return type;
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .box-card{
    width: 45%;
    max-height: 350px;
    .item{
      display: flex;
      flex-wrap:wrap;
      background: $--color-reserved-4;
      padding: 10px 5px;
      margin: 10px 0;
      .progress{
        width: 80%;
        line-height: 30px;
        padding: 0 20px;
      }
      .status{
        width: 20%;
        text-align: center;
        .delete{
          cursor: pointer;
          color: #ddd;
          margin: 0 10px;
        }
      }
      .can-down{
        cursor: pointer;
        color: $--color-primary;
      }
    }
  }
</style>
