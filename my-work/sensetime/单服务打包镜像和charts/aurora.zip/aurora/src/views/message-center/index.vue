<template>
  <div class="message-center">
    <div class="export">
      <export-batch
        v-for="(item,key) in exportMessage"
        :key="key"
        :data="item"
      />
    </div>
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch } from 'vue-property-decorator';
  import ExportBatch from './export-batch/index.vue'
  import  { messageCenter as store } from '@/store/modules/message-center';
  @Component({
    components: {
      ExportBatch,
    }
  })
export default class MessageCenter extends Vue {
  //导出的卡片
  get exportMessage(){
    return store.exportMessage
  }
  //上传的卡片
  get uploadMessage(){
    return store.uploadMessage
  }
  mounted(){
    // store.reset_msg_count()
    // store.linkCenterMessage()
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.message-center{
  padding: 20px;
  display: flex;
  justify-content: flex-start;
  width: 100%;
  height: 100%;
  overflow: scroll;
  .export{
    width: 100%;
    margin: 10px 20px;
    display: flex;
    justify-content: flex-start;
    flex-wrap:wrap;
    justify-content:space-between;
  };
}
</style>
