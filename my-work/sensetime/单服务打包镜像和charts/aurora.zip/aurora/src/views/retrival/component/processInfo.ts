import i18n from '@/lang';

//处理列表数据
export function processInfo(items){
  let size = 5;
  let comparisonInfo = new Array();
  let i;
  items.forEach((v,k)=>{
    v["isFocus"]=false;//当前详情被点击
    if(k===0){
      i=0
      comparisonInfo[i]={showCompareDetail:false,data:[]}
    }else if(k%5===0){
      i++
      comparisonInfo[i]={showCompareDetail:false,data:[]}
    }
    comparisonInfo[i].data.push(v)
  })

  return comparisonInfo;
}

export function dressUpper(item , val) {
  let color = ''
  let style = ''

  let enumObj:any={
    color:[
      'coat_color',
      'trousers_color',
      'cap_color',
      'hair_color',
      'bag_color',
      'shoes_color',
      'umbrella_color',
      'respirator_color',
      //2.2.0字段
      'stcoatcolor',
      'sttrouserscolor',
      'sthaircolor',
      'stbagcolor',
      'stshoescolor',
      'sthatcolor'
    ],
    style:[
      'coat_style',
      'trousers_len',
      'cap_style',
      'hair_style',
      'bag_style',
      'shoes_style',
      'gender_code',
      'st_age',
      'st_pedestrian_angle',
      'st_coat_pattern',
      'st_trousers_pattern',
      'st_hold_object_in_front',
      //2.2.0字段
      'coatstyletype',
      'pantslengthtype',
      'hairstyletype',
      'bagstyletype',
      'shoesstyletype',
      'gendertype',
      'stagetype',
      'stangletype',
      'coatlengthtype',
      'hatstyletype'
    ]
  }
  item.forEach(ele => {
    // console.log(ele);
    Object.keys(ele).forEach(element => {

      // if(element.indexOf('color') != -1) {
      //   // console.log(element);
      //   color = ele[element]
      // } else {
      //   style = ele[element]
      // }

      if(enumObj.color.includes(element)) {
        // console.log(element);
        color = ele[element]
      } else if(enumObj.style.includes(element)){
        style = ele[element]
      }
    })
  });

  if(val == 'color') {
    return color.toLowerCase()
  }
  if(val == 'style'){
    // console.log(style);
    return style ? i18n.tc('pedestrian.'+style.toLowerCase()) : ''
  }
}

export function getSortAttributeInfoVos(val) {
  // console.log(val);
  let name = val.attrType
  let IconName = ''

    switch (name) {
    case  "coatstyletype-stcoatcolor":
      IconName = 'shangyi'
        // return '上衣' "coat_style-coat_color"
      break;
    case  "sttrouserscolor-pantslengthtype":
      IconName = 'kuzi'
        // return '裤子' "trousers_color-trousers_len"
      break;
    case "hairstyletype-sthaircolor":
      IconName = 'faxing'
        // return '发型' "hair_style-hair_color"
      break;
    case  "shoesstyletype-stshoescolor":
      IconName = 'xie'
        // return '鞋子' "shoes_style-shoes_color"
      break;
    case "gendertype":
      IconName = 'xingbie'
        // return '性别' "gender_code"
      break;
    case  "stangletype":
      IconName = 'jiaodu'
        // return '角度' "st_pedestrian_angle"
      break;
    case  "coatlengthtype-stcoatpattern":
      IconName = 'shangyi'
      //上衣 "coat_length-st_coat_pattern"
      break;
    case "pantslengthtype-sttrouserspattern":
      IconName = 'kuzi'
      //裤子 "trousers_len-st_trousers_pattern"
      break;
    case "st_hold_object_in_front":
      IconName = 'baowu'
      //胸前抱东西
      break;
    case "respirator_color":
      IconName = 'kouzhao'
        //口罩
      break;
    case  "bagstyletype-stbagcolor":
      IconName = 'xiangbao'
        //包 "bag_style-bag_color"
      break;
    case  "stagetype":
      IconName = 'nianling1'
        //年龄 "st_age"
      break;
    case  "stumbrellacolor":
      IconName = 'yusan'
        // 雨伞 "umbrella_color"
      break;
    case  "hatstyletype-sthatcolor":
      IconName = 'maozi'
        // 帽子 "cap_style-cap_color"
      break;
    default :
        return '假数据'
      break;
  }
  return IconName
}

export function getAttrvalueMore(param:[]) {
  let str = ''
  param.forEach((item:any,index)=>{
    // str +=  param.length-1 == index ? item: item+';'
    if(item != 'ST_BAG' && item != 'ST_RESPIRATOR')
    str += i18n.tc('pedestrian.' +item.toLowerCase()) + '/'
  })
  str = str.substring(0, str.length - 1) ;
  // console.log(str , param);
  // return this.changeGenduo(str)
  return str ? str :i18n.tc('pedestrian.no')
}