<template>
      <cardParticulars
        :items="items"
        :data="data"
        :display="display ? display : items.showCompareDetail "
        @collapse="hiddenDetail(items)"
        >
        <template slot="card" slot-scope='{currentCapture}'>
            <div class="detail">
            <div class="state"
            :style="[bgcStyle,bgcStyle.background = i18nCompareType(currentCapture.alertType).color]"
            >
              {{$t(i18nCompareType(currentCapture.alertType).compareType)}}
            </div>
                  <div class="image-cvs">
                    <el-image
                    :src="processImgurl(currentCapture.imgUrl)"
                    fit="fill">
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"
                      style="color: aliceblue;
                      position: absolute;
                      left: 50%;
                      top: 50%;
                      transform: translate(-50%,-50%);"
                      ></i>
                    </div>
                  </el-image>
                  <detailHotMap :hotMapList='currentCapture.hotspotHeadPosition' />
                  </div>
                <!-- {{currentCapture}} -->
                 <div class="detailText">
                    <ul class="">
                          <li>
                            <div><span>{{$t('pedestrian.crowdZone')}}:</span><span>{{currentCapture.hotspotQuantity}}{{$t('pedestrian.crowdUnit1')}}</span></div>
                          </li>
                          <li v-if="currentCapture.alertType == '24'">
                            <div><span>{{$t('pedestrian.timeDuration')}}:</span><span>{{getHSTime(currentCapture.lastTime)}}</span></div>
                          </li>
                          <li>
                            <div><span>{{$t('pedestrian.alarmThreshold')}}:</span>
                              <span>
                                {{currentCapture.crowAttribute.threshold}}{{currentCapture.crowAttribute.thresholdUnit == 1 ? $t('pedestrian.crowdUnit1') : $t('pedestrian.crowdUnit2')}}
                                </span></div>
                          </li>
                          <!-- <li>
                            <div><span>时间阈值:</span><span>
                              {{getTimeUnit(currentCapture.crowAttribute.duration,currentCapture.crowAttribute.durationUnit)}}
                              </span></div>
                          </li> -->
                          <li>
                            <div>
                              <span>{{$t('pedestrian.title')}}:</span>
                              <el-popover
                                placement="right-start"
                                width="200"
                                trigger="hover"
                                :content="currentCapture.deviceName"
                              >
                                <p slot="reference">{{currentCapture.deviceName}}</p>
                              </el-popover>
                              <!-- <p>{{currentCapture.deviceName}}</p> -->
                            </div>
                          </li>
                          <li>
                            <div>
                              <span>{{$t('pedestrian.site')}}:</span>
                              <el-popover
                                placement="right-start"
                                width="200"
                                trigger="hover"
                                :content="currentCapture.placeName"
                              >
                                <p slot="reference">{{currentCapture.placeName}}</p>
                              </el-popover>
                              <!-- <p>{{currentCapture.placeName}}</p> -->
                            </div>
                          </li>
                          <li>
                            <div><span>{{$t('pedestrian.time')}}:</span><span>{{currentCapture.captureTime}}</span></div>
                          </li>
                          <li>
                            <div><span>{{$t('pedestrian.mission')}}:</span><span>{{currentCapture.taskName}}</span></div>
                          </li>
                        </ul>
                 </div>
            </div>
        </template>
    </cardParticulars>
</template>

<script lang="ts">
    import { Component, Vue, Watch , Emit, Prop} from "vue-property-decorator";
    import cardParticulars from "../image-card/cardParticulars.vue";
    import { processImgurl } from "@/utils/image";
    import detailHotMap from "@/components/detailHotMap/index.vue";
    import { i18nCompareType ,getHSTime} from "@/utils/small-tool";
import log from "../../../../api/log";

   @Component({
    components:{
      cardParticulars,
      detailHotMap
    }
   })
   export default class crowdRetails extends Vue {
       @Prop({default(){return {}}}) data!:object;
       @Prop({default(){return {}}}) items!:object;
       @Prop({default:false}) display!:boolean;
       processImgurl=processImgurl;
       i18nCompareType = i18nCompareType;
       getHSTime =getHSTime ;
      bgcStyle  = {
        background :''
      } //告警颜色样式

      //收起详情
      @Emit('collapse')
      hiddenDetail(data) {
        // console.log('-----------------','收起详情');

         return data
      }

      getTimeUnit(time , unit) {
        let _this = this as any
        let str = ''
        switch (unit) {
          case 1:
            str = time + _this.$t('pedestrian.sec')
            break;
          case 2:
            str = Math.ceil(time/60) + _this.$t('pedestrian.min')
            break;
          case 3:
            str = Math.ceil(time/360) + _this.$t('pedestrian.hours')
            break;

          default:
            break;
        }
        return str
      }

      mounted() {
      //  console.log(this.getHSTime(236515614));

      }
   }
</script>

<style lang="scss" scoped>
    .detail {
      display: inline-block;
        width:305px;
        height:91%;
        background-color: #fff;
        border-radius:4px 0px 0px 4px;
        .state {
          width: 100%;
          height: 32px;
          border-radius:4px 0px 0px 0px;
          text-align: center;
          line-height: 32px;
          color: #fff;
        }
        .image-cvs {
          width: 220px;
          height: 124px;
          // border:1px solid rgba(112,112,112,1);
          position: relative;
          left: 50%;
          transform: translateX(-50%);
          margin-top: 20px;
          // background-color: #011C50;
          border: 1px dashed #CDE1FD;
          // background-color: #DFEAFC;
        }
        .el-image {
          width: 100%;
          height: 100%;
          // border:1px solid rgba(112,112,112,1);
          position: absolute;
          left: 0;
          top: 0;
          // transform: translateX(-50%);
          // margin-top: 20px;
          // background-color: #011C50;
          // border: 1px dashed #CDE1FD;
          background-color: #DFEAFC;
          z-index: 1;
        }
    }
    .detailText {
      width: 80%;
      margin-left: 14%;
      margin-top: 10px;

      ul {

        li {
              width: 80%;
              div {
                line-height: 35px;
                width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                -ms-text-overflow: ellipsis;
                white-space: nowrap;
                display: flex;

                span:first-child {
                  font-size:14px;
                  font-family:Source Han Sans CN;
                  font-weight:bold;
                  // line-height:14px;
                  color:rgba(40,53,77,1);
                  margin-right: 10px;
                }

                span:last-child {
                  max-width: 80%;
                  p {
                    // display: flex;
                    text-align: left;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    -ms-text-overflow: ellipsis;
                    white-space: nowrap;
                  }
                }

              }
            }
      }
    }

    ::v-deep .canvasHotMap canvas{
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0px;
      left: 0px;
      z-index: 2;
      background-color:transparent;
    }

    // ::v-deep .record-detail {
    //   width: 500px;
    // }
</style>
