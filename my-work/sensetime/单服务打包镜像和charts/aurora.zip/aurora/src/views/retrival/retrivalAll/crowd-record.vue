<template>
  <div class="crowdRecord">
    <vanScreen
      @reset-condition="resetCondition"
      @do-search="doSearch"
      @show-condition="showCondition"
      @hide-condition="hideCondition"
    >
      <div class="condition-detail-all" slot="option">
        <!-- 任务 -->
        <div class="condition-detail-item">
          <tree-input
            class="tree-input"
            @dropDown="getRuleName"
            @checkout="checkoutRuleNameTypes"
            :data="monitorRules"
            label="name"
            :name="$t('pedestrian.mission')"
            ref="ruleName_tree"
          />
        </div>

        <!-- 地点 -->
        <div class="condition-detail-item">
          <tree-input
            class="tree-input"
            @dropDown="fetchLocation"
            @checkout="checkoutLocation"
            :data="locationList"
            label="name"
            :name="$t('records.contLocation')"
            ref="location_tree"
          />
        </div>

        <!-- 时间 -->
        <div class="condition-detail-item">
          <span class="label">{{$t("records.contTime")}}</span>
          <el-date-picker
            class="input-field"
            size="small"
            v-model="timeRange"
            @change="handleDateChange"
            type="datetimerange"
            range-separator="-"
            :start-placeholder="$t('log.textboxTimeSet')"
            :end-placeholder="$t('log.textboxTimeSet')"
          ></el-date-picker>
        </div>

        <!-- 设备 -->
        <div class="condition-detail-item">
          <tree-input
            class="tree-input"
            @dropDown="fetchDevice"
            @checkout="checkoutDevice"
            :data="deviceList"
            label="name"
            :name="$t('records.contDevice')"
            ref="device_tree"
          />
        </div>
        <!-- 告警类型 -->
        <div class="condition-detail-item">
          <tree-input
            class="tree-input"
            @checkout="checkoutcompareType"
            :data="compareTypes"
            label="name"
            :name="$t('pedestrian.alarm')"
            ref="compareType_tree"
          />
        </div>
      </div>
    </vanScreen>
    <el-button
          v-if="$permission('015301')"
          type="primary"
          size="small"
          class="batch-export"
          @click="showExportDialog"
        >
          <i class="iconfont icon-upload"></i>
          {{$t("records.buttonExport")}}
      </el-button>
    <div class="crowdRecord-box list-img" v-loading="loading">
      <div style="position: relative;">
        <el-input
          size="small"
          style="width:300px; margin:0 0 12px 12px;"
          :placeholder="$t('pedestrian.search')"
          v-model="params.keyWord"
          @keyup.enter.native="searchKeyword"
        >
          <i
            slot="suffix"
            v-show="params.keyWord"
            @click="()=>{params.keyWord = '',searchKeyword()}"
            style="cursor: pointer;"
            class="el-input__icon el-icon-circle-close"
          ></i>
          <i
            class="iconfont icon-search1"
            slot="suffix"
            style="cursor: pointer;line-height: 32px;"
            @click="searchKeyword"
          />
          <!-- <el-button slot="append" icon="el-icon-search"></el-button> -->
        </el-input>
        <el-popover placement="bottom-start" trigger="hover">
          <div class="keyword-suggest" v-html="$t('records.hovmsgPedestrian')"></div>
          <i
            slot="reference"
            style="margin-left: 5px;color:#2a5af5;position: absolute;top: 8px;"
            class="el-icon-question"
          ></i>
        </el-popover>
      </div>
      <ImageList :lists="crowData" :collapse="true" :class="{isHeighten}">
        <crowdRecordCard
          slot-scope="{items, item }"
          :item="item"
          :items="items"
          slot="listCollapse"
          @view-detail="viewDetail"
        />
        <crowdRetails
          slot-scope="{items}"
          slot="detail"
          :items="items"
          :data="comparisonDetail"
          @collapse="hiddenDetail(items)"
        ></crowdRetails>
      </ImageList>
    </div>

    <div class="block">
      <el-pagination
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        :page-size="params.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="params.pageNum"
        :page-sizes="[15, 30, 45 , 60, 105]"
      ></el-pagination>
    </div>
    <batch-export
      :series="dialogTrigerNumber"
      @export="doExportRecord"
      :maxNum="total"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit } from "vue-property-decorator";
import filtrateNav from "../component/filtrate-nav.vue";
import cardDetails from "../component/card-details.vue";
import TreeInput from "@/components/tree-input/index.vue";
import ImageList from "@/components/image-list/index.vue";
import vehicleImageCard from "../component/image-card/vehicle-card.vue";
import request from "@/api/history-record";
import BatchExport from "../component/batch-export.vue";
import { Cache } from "@/utils/cache";
import vanScreen from "../component/van-screen.vue";
import crowdRecordCard from "../component/image-card/crowdRecord-card.vue";
import { processComparisonInfo } from "@/utils/small-tool";
// import cardParticulars from "../component/image-card/cardParticulars.vue";
import crowdRetails from "../component/allDetails/crowdRetails.vue";
import { EventBus } from "@/utils/eventbus";

var _ = require("lodash/lang");
@Component({
  components: {
    TreeInput,
    ImageList,
    vehicleImageCard,
    crowdRetails,
    vanScreen,
    crowdRecordCard,
    BatchExport
  }
})
export default class crowdRecord extends Vue {
  processComparisonInfo = processComparisonInfo;
  crowData: any = [];
  isHeighten = false;
  comparisonDetail = {};
  loading = false;
  keyWordOK = "";
  total = 0;
  dialogTrigerNumber = 0 ;
  params = {
    alertType: [],
    captureTimeEnd: "",
    captureTimeStart: "",
    deviceId: [],
    enableTimeSort: "",
    keyWord: "",
    objectId: "",
    pageNum: 1,
    pageSize: 15,
    placeId: [],
    taskId: []
  };

  //筛选数据
  monitorRules = [];
  locationList = [];
  timeRange: any = null;
  deviceList = [];

  get compareTypes() {
    return [
      // {id:"0",name:'未知'},
      { id: "23", name: this.$t("pedestrian.crowdAnalyze")},
      { id: "24", name: this.$t("pedestrian.crowdOvercrowding") },
    ];
  }

  //获取r任务列表
  getRuleName() {
    if (this.monitorRules.length == 0) {
      let state = { taskTypes: [5] };
      // console.log(state);

      request.getQueryTasksByType(state).then(data => {
        // console.log(data);

        this.monitorRules = (data as any).taskNameVOList;
        // console.log(this.monitorRules);
      });
    }
  }

  //获取位置列表
  fetchLocation(val) {
    if (!this.locationList.length) {
      request.fetchLocation().then(data => {
        console.log(data);

        this.locationList = data.data;
      });
    }
  }

  //选取地点
  checkoutLocation(ids) {
    // this.searchCondition.floorIds=ids
    this.params.placeId = ids;
  }

  //获取设备列表
  fetchDevice(val) {
    if (!this.deviceList.length) {
      request.fetchDevice().then(data => {
        this.deviceList = data.data;
      });
    }
  }

  //选取任务
  checkoutRuleNameTypes(ids) {
    this.params.taskId = ids;
    // console.log('111');
  }

  //选取设备
  checkoutDevice(ids) {
    // console.log(ids);
    this.params.deviceId = ids;
  }

  //选取时间
  handleDateChange(tms) {
    console.log(tms);
    // this.data
  }

  //选取告警
  checkoutcompareType(ids) {
    this.params.alertType = ids;
    // console.log('选取告警',ids);
  }
  //初始化时间
  initData() {
    this.timeRange = null;
  }

  resetCondition() {
    console.log("点击重置");
    this.initData(); //初始化时间
    // historyStore.reset_condition();//初始化检索条件
    // this.searchCondition = historyStore.condition;
    // (this.$refs.dept_tree as any).clearCheckout();
    (this.$refs.device_tree as any).clearCheckout();
    (this.$refs.location_tree as any).clearCheckout();
    // (this.$refs.watchlist_tree as any).clearCheckout();
    (this.$refs.compareType_tree as any).clearCheckout();
    (this.$refs.ruleName_tree as any).clearCheckout(); //任务
    // (this.$refs.operateStatus as any).clearCheckout();
    EventBus.$emit("clearAll", false); //重置全选
  }

  doSearch() {
    this.params.pageNum = 1;
    this.params.captureTimeStart = this.timeRange ? this.timeRange[0] : null;
    this.params.captureTimeEnd = this.timeRange ? this.timeRange[1] : null;
    this.getCrowData();
  }

  showCondition() {
    this.isHeighten = true;
  }

  hideCondition() {
    this.isHeighten = false;
  }

  mounted() {
    this.getCrowData();
  }

  getCrowData() {
    this.loading = true;
    request
      .getCrowData(this.params)
      .then(res => {
        console.log(res);
        // this.loading = false
        this.crowData = processComparisonInfo(
          res.data.list ? res.data.list : []
        );
        this.total = res.data.total;
        // console.log(this.crowData);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  //点击展开详情
  viewDetail(data, e) {
    // console.log(data);

    if (this.$permission("009304")) {
      // 查看详情涉及到修改状态权限，所以没有修改权限的用户点击不触发详情
      // this.triggerEle=e
      // 所有展开收缩
      this.crowData.forEach((val: any) => {
        val.showCompareDetail = false;
        // console.log(val);
        val.data.forEach(obj => {
          obj.isFocus = false;
        });
      });
      //当前展开
      // console.log(data,e);
      data.items.showCompareDetail = true;
      data.item.isFocus = true;
      this.comparisonDetail = data.item;
    }
  }

  //收起详情
  hiddenDetail(data) {
    //当前详情数据置空
    this.comparisonDetail = {};
    // console.log(data);
    data.showCompareDetail = false;
    data.data.forEach(val => {
      val.isFocus = false;
    });
  }

  //搜索关键字
  searchKeyword() {
    this.params.pageNum = 1;
    this.keyWordOK = this.params.keyWord;
    // console.log(this.data.keyword);
    this.getCrowData();
  }

  //分页
  handleSizeChange(val) {
    // console.log(val);
    // this.loading = true
    this.params.pageSize = val;
    this.getCrowData();
  }
  handleCurrentChange(val) {
    // this.loading = true
    this.params.pageNum = val;
    this.getCrowData();
  }

   //显示导出弹框
    showExportDialog(){
      this.dialogTrigerNumber = Math.random()
    }

    doExportRecord(start,end) {
        // console.log(this.params);
        let params :any = _.cloneDeep(this.params);
        params.from = start;
        params.to = end;
        params.keyWord = this.keyWordOK;
        params.userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";

        // console.log(params);

        request.exportCrowd(params).then(()=>{
          this.$message({
            showClose: true,
            message: this.$t("log.exportSuccess") as string,
            type: 'success',
            duration: 3 * 1000,
          });
        })
    }
}
</script>

<style lang="scss" scoped>
.crowdRecord {
  overflow: auto;
  height: 95%;
  margin-top: 12px;
  .list-img {
    min-height: 732px;
    .image-list-container {
      margin-top: 0px;
      transition: all 0.5s;
    }
    .isHeighten {
      margin-top: 22px;
    }
  }

  .batch-export {
    position: absolute;
    right: 35px;
    top: 5px;
  }
}

.condition-detail-all {
  display: flex;
  // height: 32px;
  .condition-detail-item {
    display: flex;
    // padding: 5px;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    line-height: 32px;
    height: 32px;
    .label {
      padding-right: 3px;
      padding-left: 10px;
      // display: inline-block;
      line-height: 32px;
      white-space: nowrap;
    }
  }
}

::v-deep .tree-input {
  display: flex;
  // align-items: center;
  align-items: flex-end;
  .title {
    line-height: 32px;
  }
}

.block .el-pagination {
  margin: 0 auto;
  width: 50%;
  text-align: center;
}

.keyword-suggest{
  //  display: flex;
  //  flex-wrap:wrap;
    :first-child{
        font-weight: 900;
    };
    :last-child{
        word-break:break-all;
    }
  }
</style>
