<template>
   <div class="crowdRecordCard" @click="viewDetail">
      <div class="pt-state"
        :style="[bgcStyle,bgcStyle.background = i18nCompareType(item.alertType).color]"
        >
        {{$t(i18nCompareType(item.alertType).compareType)}}
        </div>

        <div style="position: absolute;right: 15px;top: 6px;color: #b4b4b4;">
          {{$t(convertOperateType(item.confirmationInfo.confirmationStatus))}}
        </div>
      <div class="image-box">
         <el-image
         :src="processImgurl(item.imgUrl)"
            fit="contain">
            <div slot="error" class="image-slot">
               <i class="el-icon-picture-outline"
               style="color: aliceblue;
               position: absolute;
               left: 50%;
               top: 50%;
               transform: translate(-50%,-50%);"
               ></i>
            </div>
         </el-image>
         <div class="image-box-right">
            <ul>
               <li>{{$t('pedestrian.crowdZone')}}:{{item.hotspotQuantity}}{{$t('pedestrian.crowdUnit1')}}</li>
               <li v-if="item.alertType == '24'">{{$t('pedestrian.timeDuration')}}:{{getHSTime(item.lastTime)}}</li>
            </ul>
         </div>
      </div>
      <div class="corwd-content">
         <ul>
            <li>
               <div><span>{{$t('pedestrian.title')}}:</span>{{item.deviceName}}</div>
            </li>
            <li>
               <div><span>{{$t('pedestrian.site')}}:</span>{{item.placeName}}</div>
            </li>
            <li>
               <div><span>{{$t('pedestrian.time')}}:</span>{{item.captureTime}}</div>
            </li>
         </ul>
      </div>
   </div>
</template>

<script lang="ts">
   import { Component, Vue, Watch , Emit ,Prop} from "vue-property-decorator";
   import { processImgurl } from "@/utils/image";
   import { i18nCompareType ,getHSTime } from "@/utils/small-tool";
   import request from '@/api/history-record';

   @Component
   export default class crowdRecordCard extends Vue {
    @Prop({default(){return {}}}) item!:object;
    @Prop({default(){return {}}}) items!:object;
    processImgurl =processImgurl;
    i18nCompareType=i18nCompareType;
    getHSTime = getHSTime;
    bgcStyle  = {
        background :''
      } //告警颜色样式
    @Emit()
    viewDetail() {
      // console.log('点击了');
      if(this.$permission('009304') && (this.item as any).confirmationInfo.confirmationStatus == 0) {
        this.comfirmCompareStatus(this.item,1,4)
        ;(this.item as any).confirmationInfo.confirmationStatus = 1
      }
      // console.log({ items:this.items,item:this.item });
      return { items:this.items,item:this.item }
    }

    //更新查看状态
    comfirmCompareStatus(item,status,type){
      // item.confirmationInfo.confirmationStatus = 1
      let serialNumber = item.objectId;
      // console.log(item);

      let param = {id:item.objectId,confirmationStatus:status,type}
      request.checkCompareStatus(param).then(()=>{
        // item.confirmationStatus=status

      })
    }

    convertOperateType(val){
      switch(val){
       case 0:
       return "records.lsitOperationTypeUnread"
       case 1:
       return "records.lsitOperationTypeRead";
       case 2:
       return "records.lsitOperationTypeMatched";
       case 3:
       return "records.lsitOperationTypeUnmatched";
     }
    }

   }
</script>

<style lang="scss" scoped>
    .crowdRecordCard {
       width: 100%;
       height: 100%;
      // display: flex;
      // cursor:pointer;
      margin: 0.5%;
      background:rgba(255,255,255,1);
      border:1px solid rgba(223,223,224,1);
      box-shadow:0px 3px 6px rgba(0,0,0,0.16);
      opacity:1;
      border-radius:4px;
      overflow: hidden;
      padding:5px 15px;
      position: relative;
      font-size: 14px;
      cursor:pointer;

      .pt-state {
         position: absolute;
         width: 123px;
         height: 25px;
         text-align: center;
         line-height: 25px;
         // background-color: pink;
         color: #fff;
         border-radius: 4px 0 0 0 ;
         top: 0px;
         left: 0px;
        //  background: red;
      }

      .image-box {
         display: flex;
         margin-top: 26px;

         .image-box-right {
            display: flex;
            margin-left: 10px;
            ul {
               align-self: center;
               li {
                  line-height: 20px;
               }
            }
         }
      }

      .el-image {
         width:187px;
         height:105px;
         // background-color: #011C50;
         border: 1px dashed #CDE1FD;
         background-color: #DFEAFC;
      }

      .corwd-content {
         margin-top: 5px;
         ul {
            li {
               line-height: 20px;
            }
         }
      }
    }
</style>
