<template>
  <div class="history-record-container">
     <image-list
      class="img-list"
      :collapse="true"
      :lists="comparisonInfo"
     >
      <two-image
        slot-scope="{items, item }"
        slot="listCollapse"
        :item="item"
        :items="items"
        :percentage="toPercentage(item.score)"
        :originImg="item.picUrl"
        :targetImg="item.url"
        :id="item.id"
        :name="item.userName"
        :time="item.preCaptureDate?item.preCaptureDate:item.captureDate"
        :location="item.place"
        :percentageSize=14
        :cardType="convertCardType(item.confirmationStatus)"
        :compareType="item.compareType"
        :device="item.devicePlaceInfo.name"
        @cancel-success="cancelSuccess"
        @cancel-failed="cancelFailed"
        @success="handleSuccess"
        @failed="handleFailed"
        @view-detail="viewDetail"
        :loading="loading"
        />

        <RecordDetail
          :triggerEle="triggerEle"
          slot-scope="{items}"
          slot="detail"
          :display="items.showCompareDetail"
          @collapse="hiddenDetail(items)"
          :data="comparisonDetail"
          :captureList="captureList"
          @cancel-success="cancelSuccess"
          @cancel-failed="cancelFailed"
          @success="handleSuccess"
          @failed="handleFailed"
          @sort="captureSort"
          @export="exportDetail"
          @slide="viewCaptureMore"
          :totalCapture="totalCapture"
        />
     </image-list>
     <el-pagination

        class="pagination"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageNumber"
        :page-sizes="[15, 30, 45 , 60, 105]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="data.totalNumber">
     </el-pagination>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch ,Emit ,Prop} from 'vue-property-decorator';
import { scrollTo,scrollIntoView } from 'scroll-js';
import  TwoImage from '@/components/two-image/index.vue';
import  ImageList from '@/components/image-list/index.vue';
import  RecordDetail from './record-detail/index.vue';
import request from '@/api/history-record';
import { convertCardType, toPercentage } from '@/utils/small-tool';
import { Cache } from '@/utils/cache';

interface reqParameterHD{
  sdSort:any,
  timeSort:any,
  targetId:number,
  from?:number,
  to?:number,
  pageSize?:number,
  pageNumber?:number,
}

@Component({
  components: {
    TwoImage,
    RecordDetail,
    ImageList
  },
  //  props:{
  //   data:{
  //     type:Object,
  //     default(){
  //       return {};
  //     }
  //   },
  //   pageNumber:{
  //     type:Number,
  //     default:1,
  //   },
  //   pageSize:{
  //     type:Number,
  //     default:15,
  //   },

  // },
})
export default class HistoryRecord extends Vue {
  @Prop({default(){return {}}}) data!:object;
  @Prop({default:1}) pageNumber!:number;
  @Prop({default:15}) pageSize!:number;

  totalCapture=0;
  captureSize=16;
  captureIndex=1;
  maxIndex=1;
  triggerEle:any=null;
  viewState="";
  // pageNumber:any;
  // pageSize:any;
  // data:any;
  convertCardType=convertCardType;
  toPercentage=toPercentage;
  loading=false;
  captureList=[];
  reqParam:reqParameterHD={
    sdSort:null,
    timeSort:0,
    targetId:0,
    pageSize:this.captureSize,
    pageNumber:this.captureIndex,
  };
  comparisonInfo:any=[];
  showCompareDetail:boolean=false;
  comparisonDetail={};

  @Watch('data', { immediate: true, deep: false })
  onDataChanged(val, oldVal) {
    if(val.baseVOList){
       this.comparisonInfo = this.processComparisonInfo(val.baseVOList)
    }
   }
  mounted(){
    console.log(this.comparisonInfo)
  }

  //取消比中状态
  cancelSuccess(param){
    this.comfirmCompareStatus(param,1)
  }
  //取消未比中状态
  cancelFailed(param){
    this.comfirmCompareStatus(param,1)
  }
  //点击比中
  handleSuccess(param){
    this.comfirmCompareStatus(param,2)
  }
  //点击未比中
  handleFailed(param){
    this.comfirmCompareStatus(param,3)
  }

  //查看详情
  viewDetail(data,e){
    if(this.$permission('009304')){//查看详情涉及到修改状态权限，所以没有修改权限的用户点击不触发详情
      this.triggerEle=e
      //所有展开收缩
      this.comparisonInfo.forEach((val)=>{
        val.showCompareDetail=false;
        val.data.forEach((obj)=>{
          obj.isFocus=false
        })
      })
      //当前展开
        this.captureList = []; //重置轮播数据
        data.items.showCompareDetail = true;
        data.item.isFocus = true;
        this.comparisonDetail = data.item
        this.reqParam["targetId"]=data.item.targetId
        this.fetchRecordDetail(this.reqParam) //获取抓拍
        if(data.item.confirmationStatus===0){ //如果未查看，修改为查看状态
          this.cancelSuccess(data.item)
           console.log('-------查看详情-修改为查看状态--------');
        }
    }
  }
  //滑动加载更多
  viewCaptureMore(index){
    let pageNumber= index+1
    if(this.maxIndex<pageNumber){
      this.maxIndex=pageNumber
      this.reqParam.pageSize=(this.captureSize as number)/2;
      this.reqParam.pageNumber = this.maxIndex+1
      request.fetchRecordDetail(this.reqParam).then((data)=>{

          this.captureList = Array.prototype.concat.apply(this.captureList,data.data.baseVOList || []) as any;
      }).catch(()=>{
          // this.captureList=[]
      })
    }
  }
   // 获取详情的抓拍
  captureSort(param){
    this.captureList = [];
    this.reqParam["sdSort"]= param.similaritySort
    this.reqParam["timeSort"]= param.timeSort
    this.fetchRecordDetail(this.reqParam)
  }
  exportDetail(start,end){
    var param:any={}
    //  param.accessToken = Cache.sessionGet("accessToken"),
     param.from = start,
     param.to = end,
     param.sdSort = this.reqParam.sdSort,
     param.timeSort = this.reqParam.timeSort,
     param.targetId = this.reqParam.targetId,
     param.userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";
     request.exportHistoryDetail(param).then(()=>{
       this.$message({
         showClose: true,
          message: this.$t("log.exportSuccess") as string,
          type: 'success',
          duration: 3 * 1000,
       });
     })
  }
    //获取详情抓拍列表
  fetchRecordDetail(param){
    this.maxIndex=1; //重置滑动参数
    this.reqParam.pageSize=this.captureSize; //重置滑动参数
    this.reqParam.pageNumber = this.captureIndex; //重置滑动参数
    request.fetchRecordDetail(param).then((data)=>{
      this.totalCapture = data.data.totalNumber || 0;
      this.captureList = data.data.baseVOList || [];
    }).catch(()=>{
        this.captureList=[]
    })
  }

  //收起详情
  hiddenDetail(data){
    //当前详情数据置空
    this.comparisonDetail={}
    data.showCompareDetail=false
    data.data.forEach((val)=>{
      val.isFocus=false;
    })
  }
  @Emit("pageSizeChange")
  handleSizeChange(val) {
    return val;
  }
  @Emit("pageChange")
  handleCurrentChange(val) {
    return val;
  }

  //处理列表数据
  processComparisonInfo(items){
    let size = 5;
    let comparisonInfo = new Array();
    let i;
    items.forEach((v,k)=>{
      v["isFocus"]=false;//当前详情被点击
      if(k===0){
        i=0
        comparisonInfo[i]={showCompareDetail:false,data:[]}
      }else if(k%5===0){
        i++
        comparisonInfo[i]={showCompareDetail:false,data:[]}
      }
      comparisonInfo[i].data.push(v)
    })
    return comparisonInfo;
  }

  //更新操作状态
  comfirmCompareStatus(item,status){
    //匹配列表中的serialnumber,更新相应的状态
    let serialNumber = item.serialNumber;

    this.loading=true
    let param = {id:item.serialNumber,confirmationStatus:status}
    request.checkCompareStatus(param).then(()=>{
      item.confirmationStatus=status
      this.comparisonInfo.forEach((arr,key)=>{//修改当前更改的卡片数据
        arr.data.forEach((val,key)=>{
          if(val["serialNumber"]==serialNumber){
            val.confirmationStatus=status; //修改目标比对卡片
          }
        })
      })
      this.loading=false
    },(err)=>{
      this.loading=false
    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .history-record-container{
    .img-list{
      min-height: 700px;
    }
    .pagination{
      width:50%;
      text-align: center;
      margin: 15px auto;
    }
  }
</style>
