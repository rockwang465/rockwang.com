<template>
  <div>
      <el-dialog
        class="isroll"
        :visible.sync="showTrackDialog"
        v-if="showTrackDialog"
        :show-close="false"
        :append-to-body="true"
        :close-on-click-modal="false"
        :close-on-press-escape="false"
        width="60%">
        <div class="generate-track-header" slot="title">
          <div class="title">{{$t("records.buttonFootfall")}}</div>
          <div class="content">
            <!--<el-radio :value="filterOption" @input="selectFilterCondition"  label="1">{{$t("records.contSelectAll")}}</el-radio>-->
            <el-checkbox v-model="checkAll" @change="handleCheckAll">{{$t("records.contSelectAll")}}</el-checkbox>
            <el-radio :value="filterOption" @input="selectFilterCondition" label="2" class="threshold-box">
                    {{$t("records.contSelectbyThreshold",{number:this.numerToPercent(this.similar) })}}
                   <el-select size="mini" :value="similar" @input="selectSimilar" v-model="similar" >
                    <el-option
                      v-for="item in options"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                      >
                    </el-option>
                  </el-select>
            </el-radio>
            <el-radio :value="filterOption" @input="selectFilterCondition" label="3">{{$t("records.contSelectMatched")}}</el-radio>
          </div>
        </div>
        <div class="generate-track-content">
            <el-checkbox-group @change="handleCheckOne" v-model="trackIds">
            <el-checkbox v-for="info in captureList" :label="info.serialNumber" :key="info.serialNumber">
            <single-image
              :item="info"
              :percentage="info.score+''"
              :img="matchUrl(info)"
              class="img-container"
            />
            </el-checkbox>
          </el-checkbox-group>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="getTrackInfo">{{$t("records.buttonNext")}}</el-button>
          <el-button type="info" @click="cancel">{{$t("records.buttonCancel")}}</el-button>
        </span>
      </el-dialog>

       <!-- 地图轨迹 -->
      <el-dialog :title="$t('records.titleFootfall')" width="80%" height="800"
        :append-to-body="true"
        :visible.sync="isMapTrack"
        v-if="isMapTrack"
        :close-on-click-modal="false"
        :close-on-press-escape="false"
        :show-close="false"
         class="dialog-track isroll">
        <el-form :model="form" style="width:100%">
          <map-track ref="trackView" v-if="isMapTrack" :trackData="lineData" :key="trackKey"/>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="selectTrackInfo">{{$t('records.buttonBack')}}</el-button>
          <el-button type="primary" v-if="$permission('015306')" ref="exportFootfall" @click="exportTrackData">{{$tc('records.exportFootfall')}}</el-button>
          <el-button type="info" @click="isMapTrack = false">{{$t('records.buttonClose')}}</el-button>
        </div>
      </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import {Tree as ElTree} from 'element-ui';
import  SingleImage from '@/components/single-image/index.vue';
import  Icon from '@/components/icon-wrap/index.vue';
import request from '@/api/history-record';
import { Cache } from '@/utils/cache';
import { historyStore } from '@/store/modules/history-record';
import MapTrack from '../../manage/map/map-track.vue';
var _ = require('lodash/lang');

@Component({
  // props:{
  //   data:{
  //     type:Array,
  //     default(){
  //       return [];
  //     }
  //   },
  //   showTrackDialog:{
  //     type:Boolean,
  //     default:true
  //   },
  //   trackType:{
  //     type:String,//library为人像，capture为抓拍
  //     default:"",
  //   }
  // },
  components: {
    SingleImage,
    Icon,
    MapTrack
  },
})
export default class TrackSelect extends Vue {
  @Prop({default:true}) showTrackDialog!:boolean;
  @Prop({default(){return []}}) data!:any[];
  @Prop({default:""}) trackType!:string;

  checkAll=false;
  trackIds=[];
  // data:any;
  filterOption="";
  similar="0.6";
  trackKey = +new Date();
  isChecked=true;
  isMapTrack=false;
  uuidSerial:String = '';
  lineData:any=[{
    //trackPic:[],
    //trackLine:[
      // {
      //   id: 'p1',
      //   label: '2018/09/01 10:01:07 - 11:12:03',
      //   points: [[499,443],[422,519],[378,589],[353,662],[346,804],[326,947],[323,1012],[345,1163]],
      //   visible: true
      // },
      // {
      //   id: 'p2',
      //   label: '2018/09/01 10:01:07 - 11:12:03',
      //   points: [[499,443],[22,519],[499,443],[78,589],[499,443],[99,443],[33,662],[36,804],[326,947],[323,1012],[345,1163]],
      //   visible: true
      // }
    //]
  }];
  form={}
  // trackType:any;
  options= [{
          value: '0.6',
          label: '60%'
        },{
          value: '0.65',
          label: '65%'
        }, {
          value: '0.7',
          label: '70%'
        },{
          value: '0.75',
          label: '75%'
        },{
          value: '0.8',
          label: '80%'
        },{
          value: '0.85',
          label: '85%'
        },{
          value: '0.9',
          label: '90%'
        },{
          value: '0.95',
          label: '95%'
        }, {
          value: '1',
          label: '100%'
        }];
  captureList:any=[];
  exportPos:any;
  isRunning:boolean=false

  @Watch('data', { immediate: true, deep: true })
  onDataChanged(val, oldVal) {
    // console.log(this.data)
    this.captureList=_.cloneDeep(this.data).map((val)=>{
      val.isChecked=false
      return val;
    })
  }

  mounted(){
    // console.log(this.data)
    //console.log(this.$store.state.app.badgePos)
  }

  //全部选中
  handleCheckAll(val){
    if(val){
      this.trackIds=this.captureList.map((val)=>{
        return val.serialNumber
      })
      this.filterOption=""
      //取消其他选中
    }else{
      this.trackIds=[];
    }
  }
  //选择单个图片
  handleCheckOne(){
    this.checkAll = this.trackIds.length === this.captureList.length;
  }
   checkGtScore(list,score){
    this.trackIds = list.filter((obj)=>{
      return !(Number(obj.score)<Number(score))
    }).map((obj)=>{
      return obj.serialNumber
    });
  }
  //选择相识度
  selectSimilar(val){
    this.similar = val
    if(this.filterOption=="2"){
      this.checkGtScore(this.captureList,this.similar)
      this.handleCheckOne()
    }
  }

   //选择确认比中的
  checkMatched(list){
    this.trackIds = list.filter((obj)=>{
      return obj.confirmationStatus==2
    }).map((obj)=>{
      return obj.serialNumber
    });
  }

  numerToPercent(val){
    let num = Number(val);
    num=num*100;
    return (num+"%")
  }

  //条件过滤选择
  selectFilterCondition(val){
    //设置当前筛选条件
    this.filterOption=val

    if(val==1){
      // this.checkAll(this.captureList)
    }else if(val==2){
      this.checkGtScore(this.captureList,this.similar)
    }else if(val==3){
      this.checkMatched(this.captureList)
    }
    //验证是否全部选中
    this.handleCheckOne()
  }


  //获取轨迹信息
  getTrackInfo(){
    let _this = this;
    if(this.trackIds.length>0){
      historyStore.getLibraryTrack({ids:this.trackIds}).then((resp:any)=>{
        // this.uuidSerial = resp.uuidSerial;

        resp.data.map((item,i)=>{
          //console.log(item,i)
          item.id = i;
          item.label = item.dateTime;
          item.visible = true;

          // for(let n=0;n<item.trajectors.length;n++){
          //   //item.trajectors[n].devicePoints=[[499,443],[422,519],[499,443],[378,589],[499,443],[499,443],[353,662],[346,804],[326,947],[323,1012],[345,1163]]
          // }
        })
        _this.trackKey =+ new Date();
        this.lineData = resp.data;
        //console.log(resp)

      }).then((val)=>{
        _this.isMapTrack = true;

        this.$nextTick(function () {
          this.exportPos = (this.$refs.exportFootfall as ElTree).$el.getBoundingClientRect();

          // let x = menuPos.x;
          // let y = menuPos.y;
          // console.log(x,y,menuPos)
        })
      })
    }else{
      this.$message({
        showClose: true,
        message:this.$t("records.selectImgVoid") as any,
        type: 'error',
        duration: 3 * 1000,
      });
    }
    //this.cancel();
  }
  exportTrackData(){
    let targetPos = this.$store.state.app.badgePos;
    console.log(this.exportPos);
    (this.$refs as any).trackView.exportTrack();
  }
  cancel(){
    this.filterOption="";
    this.similar="0.6";
    this.$emit("cancel");

    // 点击取消，选中照片数据初始化
    this.checkAll = false;
    this.trackIds = [];
    //console.log(this.trackIds)
  }
  selectTrackInfo(){
    this.$emit('toSelectTrackInfo')
    this.isMapTrack = false;
  }
  matchUrl(item){
    if(item.portraitImage){
      return item.portraitImage;
    }else if(item.faceUrl){
      return item.faceUrl;
    }else if(item.url){
      return item.url;
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .generate-track-content{
    display: flex;
    flex-wrap:wrap;
    max-height: 600px;
    width: 100%;
    // overflow:scroll;
    .el-checkbox-group{
      width:100%;
    }
    .el-checkbox{
      width:9%;
      height:140px;
      position:relative;
      margin:10px;
      box-sizing:border-box;
      ::v-deep .el-checkbox__input{
        position:absolute;
        top:5px;
        left:5px;
      }
      ::v-deep .el-checkbox__label{
        width:100%;
        height:100%;
        padding:0;
        color: aliceblue;
      }
    }
    .img-container{
        height: 100%;
        width:100%;
        margin: 0;
      }
    // .img-warp{
    //   width: 12%;
    //   height: 150px;
    //   margin: 10px;
    //   .img-container{
    //     height: 100%;
    //     width:100%;
    //     margin: 0;
    //   }
    // }
  }
  .generate-track-header{
    display: flex;
    align-items:center;
    justify-content: space-between;
    color:$--color-white;
    .content{
      display: flex;
      align-items: center;
      .threshold-box{
        align-items: center;
        display: flex;
        color:$--color-white;
        div{
          width: 80px;
          display: inline-flex;
        }
      }
      ::v-deep .el-checkbox__label{
        // width:100%;
        // height:100%;
        // padding:0;
        color:$--color-white;
      }
      ::v-deep .el-radio__label{
        color:$--color-white;
      }
    }
  }

</style>
