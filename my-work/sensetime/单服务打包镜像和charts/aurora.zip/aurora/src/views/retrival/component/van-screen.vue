<template>
     <div class="filtrate-nav">
       <el-popover
          placement="bottom"
          trigger="click"
          @hide="hideCondition"
          @show="showCondition"
          popper-class="popover-reset"
          >
          <span slot="reference" class="screen" >
            {{$t('messageCenter.filter')}}
            <i class="el-icon-caret-bottom" :class="{conditionBoxVisible}"></i>
          </span>
          <div class="condition-box">
                  <!-- 选项 -->
                  <slot name="option" />
              <!-- 重置/筛选 -->
              <div class="operate">
                <div>
                  <el-button
                  size="mini"
                  type="primary"
                  icon="el-icon-refresh"
                  @click="resetCondition"
                  >
                  {{$t("records.contReset")}}
                  </el-button>
                </div>
                <div>
                  <el-button
                  icon="iconfont icon-filter"
                  size="mini"
                  type="primary"
                  @click="doSearch"
                  >
                  {{$t("records.contSearch")}}
                  </el-button>
                </div>
              </div>
            </div>
        </el-popover>
        <!-- <el-button style="display:none">批量导出</el-button> -->
   </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch , Emit} from "vue-property-decorator";


  @Component
  export default class vanScreen extends Vue{
    conditionBoxVisible = false

    @Emit()
    hideCondition() {
      this.conditionBoxVisible = false
      // console.log('hideCondition消失了');
    }

    @Emit()
    showCondition() {
      this.conditionBoxVisible = true
    }

    @Emit()
    doSearch() {
      return
    }
    //重置
    @Emit()
    resetCondition() {
        return
    }

  }
</script>

<style lang="scss" scoped>

  .filtrate-nav {
    position: absolute;
    width: 50%;
    top:0px;
    left: 50%;
    span{
      cursor:pointer;
    }

    .screen {
      // pointer-events: none;
      display: inline-block;
      width: 80px;
      height: 24px;
      text-align: center;
      // background: aqua;
      line-height: 24px;
      position: absolute;
      top: 21px;
      border: 1px solid;
      border-radius: 4px 4px 0 0;
      left: -40px;
      i {
        transform: rotate(0deg);
        transition: transform .5s ;
      }
      .conditionBoxVisible {

        transform: rotate(180deg);

      }
    }


  }

  .condition-box {
      // background-color: #fff;
      display: flex;
      justify-content: space-between;
      .condition-detail-all{
        display: flex;
        justify-content: space-between;
        height: 32px;
      }

      .operate{
        display: flex;
        justify-content: space-between;
        margin-left: 50px;
        button {
          margin-left:10px;
        }
      }
    }

  ::v-deep .icon-filter {
      margin-right: 4px !important;
  }
  .condition-detail-item {
    display: flex;
    justify-content: space-between;
    // padding: 5px;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        line-height: 32px;
        height: 32px;
    .label {
      padding-right: 3px;
      padding-left: 10px;
      // display: inline-block;
      line-height: 32px;
      white-space: nowrap;
    }

  }

  ::v-deep  .tree-input {
    display: flex;
    // align-items: center;
    align-items: flex-end;
      .title {
        line-height: 32px;
      }
    }

    .popover-reset {

    }

</style>
