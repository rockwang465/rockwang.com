<template>
   <div class="filtrate-nav">
       <el-popover
          placement="bottom"
          trigger="click"
          @hide="hideCondition"
          @show="showCondition"
          popper-class="popover-reset"
          v-model="isPoVisible"
          >
          <span slot="reference" class="screen" >
            {{$t('messageCenter.filter')}}
            <i class="el-icon-caret-bottom" :class="{conditionBoxVisible}"></i>
          </span>
          <div class="condition-box">
              <div class="condition-detail-all">
                  <!-- 任务 -->
                  <div class="condition-detail-item">
                    <tree-input
                      class="tree-input"
                      @dropDown="getRuleName"
                      @checkout="checkoutRuleNameTypes"
                      :data="monitorRules"
                      label="name"
                      :name="$t('pedestrian.mission')"
                      ref="ruleName_tree"
                    />
                    <!-- <div  class="tree-input tree-input" style="display: flex;">
                        <span
                          class="title"
                          style="padding-right: 3px;
                              padding-left: 10px;
                              display: inline-block;
                              white-space: nowrap;"
                              >
                          任务
                        </span>
                        <el-input
                          placeholder="已选0个"
                          :disabled="true">
                        </el-input>
                    </div> -->
                  </div>

                  <!-- 地点 -->
                  <div class="condition-detail-item">
                      <tree-input
                      class="tree-input"
                      @dropDown="fetchLocation"
                      @checkout="checkoutLocation"
                      :data="locationList"
                      label="name"
                      :name="$t('records.contLocation')"
                      ref="location_tree"
                    />
                  </div>

                  <!-- 时间 -->
                  <div class="condition-detail-item">
                    <span class="label">{{$t("records.contTime")}}</span>
                    <el-date-picker
                      class="input-field"
                      size="small"
                      v-model="timeRange"
                      @change="handleDateChange"
                      type="datetimerange"
                      range-separator="-"
                      :start-placeholder="$t('log.textboxTimeSet')"
                      :end-placeholder="$t('log.textboxTimeSet')">
                    </el-date-picker>
                  </div>

                  <!-- 设备 -->
                  <div class="condition-detail-item">
                     <tree-input
                      class="tree-input"
                      @dropDown="fetchDevice"
                      @checkout="checkoutDevice"
                      :data="deviceList"
                      label="name"
                      :name="$t('records.contDevice')"
                      ref="device_tree"
                    />
                  </div>
                  <!-- 告警类型 -->
                  <div class="condition-detail-item">
                     <tree-input
                      class="tree-input"
                      @checkout="checkoutcompareType"
                      :data="compareTypes"
                      label="name"
                      :name="$t('pedestrian.alarm')"
                      ref="compareType_tree"
                    />
                  </div>

                  <!-- 类型 -->
                  <div v-if="isImgSearch" class="condition-detail-item">
                      <div class="label">{{$t('pedestrian.similarity')}}</div>
                      <div style="width:133px">
                        <el-select v-model="similarity">
                          <el-option
                            v-for="item in thresholds"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                          </el-option>
                        </el-select>
                      </div>
                    </div>

              </div>
              <!-- 重置/筛选 -->
              <div class="operate">
                <div>
                  <el-button
                  size="mini"
                  type="primary"
                  icon="el-icon-refresh"
                  @click="resetCondition"
                  >
                  {{$t("records.contReset")}}
                  </el-button>
                </div>
                <div>
                  <el-button
                  icon="iconfont icon-filter"
                  size="mini"
                  type="primary"
                  @click="doSearch"
                  >
                  {{$t("records.contSearch")}}
                  </el-button>
                </div>
              </div>
            </div>
            <div class="attr-title">
              <div><span>{{$t('pedestrian.attributeSelection')}}</span></div>
              <div class="attributeBody">
                <div class="condition-detail-all">

                    <!-- 性别 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ this.data.pedestrianAttributeInfo.gender = ids }"
                        :data="genderType"
                        label="name"
                        :name="$t('pedestrianTo.gender_code')"
                        ref="tree_gender"
                        :valText="$t('pedestrianTo.gender')"
                      />
                    </div>

                    <!-- 年龄 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.ageClassify = ids}"
                        :data="ageClassifyType"
                        label="name"
                        :name="$t('pedestrianTo.st_age')"
                        ref="tree_ageClassify"
                        :valText="$t('pedestrianTo.scope')"
                      />
                    </div>

                    <!-- 上衣 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.coatColor = ids }"
                        :data="coatColorType"
                        label="name"
                        :name="$t('pedestrianTo.coat')"
                        ref="tree_coatColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.coatStyle = ids}"
                        :data="coatStyleType"
                        label="name"
                        name="- "
                        ref="tree_coatStyle"
                        :valText="$t('pedestrianTo.style')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.coatDecorate = ids}"
                        :data="coatDecorateType"
                        label="name"
                        name="- "
                        ref="tree_coatDecorate"
                        :valText="$t('pedestrianTo.pattern')"
                      />
                    </div>

                    <!-- 下衣 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.trousersColor = ids }"
                        :data="coatColorType"
                        label="name"
                        :name="$t('pedestrianTo.trousers')"
                        ref="tree_trousersColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.trousersStyle = ids }"
                        :data="trousersStyleType"
                        label="name"
                        name="- "
                        ref="tree_trousersStyle"
                        :valText="$t('pedestrianTo.style')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.trousersDecorate = ids }"
                        :data="trousersDecorateType"
                        label="name"
                        name="- "
                        ref="tree_trousersDecorate"
                        :valText="$t('pedestrianTo.pattern')"
                      />
                    </div>

                    <!-- 发型 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.hairStyle = ids }"
                        :data="hairStyleType"
                        label="name"
                        :name="$t('pedestrianTo.hair')"
                        ref="tree_hairStyle"
                        :valText="$t('pedestrianTo.style')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.hairColor = ids }"
                        :data="hairColorType"
                        label="name"
                        name="- "
                        ref="tree_hairColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>
                </div>


                <div class="condition-detail-all">
                    <!-- 帽子 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.capStyle = ids }"
                        :data="capStyleType"
                        label="name"
                        :name="$t('pedestrianTo.cap')"
                        ref="tree_capStyle"
                        :valText="$t('pedestrianTo.style')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.capColor = ids }"
                        :data="coatColorType"
                        label="name"
                        name="- "
                        ref="tree_capColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>

                    <!-- 鞋子 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.shoesStyle = ids }"
                        :data="shoesStyleType"
                        label="name"
                        :name="$t('pedestrianTo.shoes')"
                        ref="tree_shoesStyle"
                        :valText="$t('pedestrianTo.style')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.shoesColor = ids }"
                        :data="coatColorType"
                        label="name"
                        name="- "
                        ref="tree_shoesColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>

                    <!-- 包 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.bagStyle = ids }"
                        :data="bagStyleType"
                        label="name"
                        :name="$t('pedestrianTo.bag_style')"
                        ref="tree_bagStyle"
                        :valText="$t('pedestrianTo.style')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.bagColor = ids }"
                        :data="coatColorType"
                        label="name"
                        name="- "
                        ref="tree_bagColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>

                    <!-- 口罩 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.respiratorStyle = ids }"
                        :data="respiratorStyleType"
                        label="name"
                        :name="$t('pedestrian.respirator')"
                        ref="tree_respiratorStyle"
                        :valText="$t('pedestrianTo.state')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.respiratorColor = ids }"
                        :data="respiratorColorType"
                        label="name"
                        name="- "
                        ref="tree_respiratorColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>

                    <!-- 雨伞 -->
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.umbrella = ids }"
                        :data="umbrellaType"
                        label="name"
                        :name="$t('pedestrianTo.umbrella')"
                        ref="tree_umbrella"
                        :valText="$t('pedestrianTo.state')"
                      />
                    </div>
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="(ids)=>{ data.pedestrianAttributeInfo.umbrellaColor = ids }"
                        :data="umbrellaColorType"
                        label="name"
                        name="- "
                        ref="tree_umbrellaColor"
                        :valText="$t('pedestrianTo.color')"
                      />
                    </div>

                </div>
              </div>
            </div>
        </el-popover>
        <!-- <el-button style="display:none">批量导出</el-button> -->
   </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch,Emit, Prop } from "vue-property-decorator";
  import historyApi from '@/api/history-record';
  import TreeInput from '@/components/tree-input/index.vue';
  import Icon from '@/components/icon-wrap/index.vue';
  import {EventBus} from '@/utils/eventbus';
  var _ = require('lodash/lang');

  interface monitorRule {
    taskGroupId: number
    taskGroupName: string
  }
  @Component({
    components:{
      TreeInput,
      Icon
    }
  })
  export default class filtrateNav extends Vue{
    @Prop({default:false}) isImgSearch !:boolean ;
    // @Prop({default:false}) isPoVisible !:boolean ;
    isPoVisible = false
    conditionBoxVisible = false ;
    monitorRules =[];
    locationList = [];
    // compareTypes:[];
    timeRange:any=null;
    deviceList = [];
    data = {
      alertType: [], //告警
      deviceId: [], //设备
      captureTimeEnd: "", //结束时间
      placeId: [],  //地点
      captureTimeStart: "", //开始时间
      taskId: [], //任务
      pedestrianAttributeInfo: {
        ageClassify: [],
        umbrellaColor: [],
        umbrella: [],
        bagColor: [],
        bagStyle: [],
        capColor: [],
        capStyle: [],
        coatColor: [],
        coatDecorate: [],
        coatStyle: [],
        gender: [],
        hairColor: [],
        hairStyle: [],
        respiratorColor: [],
        respiratorStyle: [],
        shoesColor: [],
        shoesStyle: [],
        trousersColor: [],
        trousersDecorate: [],
        trousersStyle: []
      },
    }

  //相似度
  thresholds=[
    {value:"0",label:"0%"},
    {value:"0.2",label:"20%"},
    {value:"0.4",label:"40%"},
    {value:"0.6",label:"60%"},
    {value:"0.65",label:"65%"},
    {value:"0.7",label:"70%"},
    {value:"0.75",label:"75%"},
    {value:"0.80",label:"80%"},
    {value:"0.85",label:"85%"},
    {value:"0.90",label:"90%"},
    {value:"0.95",label:"95%"},
    {value:"1",label:"100%"},
  ];
  similarity='0.85';

    mounted() {
    //  console.log(1);

    }

    get compareTypes(){
      return [
        // {id:"0",name:'未知'},
        {id:"1",name:this.$t('pedestrian.pedestrianRecord')},
        {id:"10",name:this.$t('pedestrian.pedestrianCrossingWarning')},
        {id:"11",name:this.$t('pedestrian.pedestriansInvasion')},
      ];
    }
    get genderType(){
      return [
        {id:"male",name:this.$t('pedestrian.male')},
        {id:"female",name:this.$t('pedestrian.female')},
      ];
    }
    get ageClassifyType(){
      return [
        {id:"st_old",name:this.$t('pedestrian.st_old')},
        {id:"st_adult",name:this.$t('pedestrian.st_adult')},
        {id:"st_child",name:this.$t('pedestrian.st_child')},
      ];
    }
    get coatColorType(){
      return [
        {id:"black",name:this.$t('pedestrian.black')},
        {id:"white",name:this.$t('pedestrian.white')},
        {id:"gray",name:this.$t('pedestrian.gray')},
        {id:"red",name:this.$t('pedestrian.red')},
        {id:"yellow",name:this.$t('pedestrian.yellow')},
        {id:"blue",name:this.$t('pedestrian.blue')},
        {id:"green",name:this.$t('pedestrian.green')},
        {id:"purple",name:this.$t('pedestrian.purple')},
      ];
    }
    get coatStyleType(){
      return [
        {id:"jacket",name:this.$t('pedestrian.jacket')},
        {id:"sweater",name:this.$t('pedestrian.sweater')},
        {id:"long_coat",name:this.$t('pedestrian.long_coat')},
        {id:"t_shirt",name:this.$t('pedestrian.t_shirt')},
        {id:"shirt",name:this.$t('pedestrian.shirt')},
        {id:"dress",name:this.$t('pedestrian.dress')},
        {id:"business_suit",name:this.$t('pedestrian.business_suit')},
        {id:"others",name:this.$t('pedestrian.others')},
      ];
    }
    get coatDecorateType(){
      return [
        {id:"st_pure",name:this.$t('pedestrian.st_pure')},
        {id:"st_stripe",name:this.$t('pedestrian.st_stripe')},
        {id:"st_design",name:this.$t('pedestrian.st_design')},
        {id:"st_joint",name:this.$t('pedestrian.st_joint')},
        {id:"st_lattic",name:this.$t('pedestrian.st_lattic')},
      ];
    }

    get trousersStyleType(){
      return [
        {id:"trousers",name:this.$t('pedestrian.trousers')},
        {id:"shorts",name:this.$t('pedestrian.shorts')},
        {id:"st_skirt",name:this.$t('pedestrian.st_skirt')},
      ];
    }
    get trousersDecorateType(){
      return [
        {id:"st_pure",name:this.$t('pedestrian.st_pure')},
        {id:"st_stripe",name:this.$t('pedestrian.st_stripe')},
        {id:"st_design",name:this.$t('pedestrian.st_design')},
        {id:"st_joint",name:this.$t('pedestrian.st_joint')},
        {id:"st_lattic",name:this.$t('pedestrian.st_lattic')},
      ];
    }
    get hairStyleType(){
      return [
        {id:"st_short",name:this.$t('pedestrian.st_short')},
        {id:"long",name:this.$t('pedestrian.long')},
        {id:"bald",name:this.$t('pedestrian.bald')},
      ];
    }
    get hairColorType(){
      return [
        {id:"black",name:this.$t('pedestrian.black')},
        {id:"white",name:this.$t('pedestrian.white')},
        {id:"yellow",name:this.$t('pedestrian.yellow')},
      ];
    }
    get capStyleType(){
      return [
        {id:"hat_style_type_none",name:this.$t('pedestrian.hat_style_type_none')},
        {id:"bonnet",name:this.$t('pedestrian.bonnet')},
        {id:"cap",name:this.$t('pedestrian.cap')},
        {id:"bucket_hat",name:this.$t('pedestrian.bucket_hat')},
      ];
    }
    get shoesStyleType(){
      return [
        {id:"leather_shoes",name:this.$t('pedestrian.leather_shoes')},
        {id:"boots",name:this.$t('pedestrian.boots')},
        {id:"walking_shoes",name:this.$t('pedestrian.walking_shoes')},
        {id:"sandal",name:this.$t('pedestrian.sandal')},
      ];
    }
    get bagStyleType(){
      return [
        {id:"hand_bag",name:this.$t('pedestrian.hand_bag')},
        {id:"shoulder_bag",name:this.$t('pedestrian.shoulder_bag')},
        {id:"backpack",name:this.$t('pedestrian.backpack')},
        {id:"trolley",name:this.$t('pedestrian.trolley')},
        {id:"waist_pack",name:this.$t('pedestrian.waist_pack')},
        {id:"bag_style_type_none",name:this.$t('pedestrian.bag_style_type_none')},
      ];
    }
    get respiratorColorType(){
      return [
        {id:"white",name:this.$t('pedestrian.white')},
        {id:"gray",name:this.$t('pedestrian.gray')},
        {id:"blue",name:this.$t('pedestrian.blue')},
        {id:"black",name:this.$t('pedestrian.black')}
      ];
    }
    get umbrellaType(){
      return [
        {id:"st_umbrella",name:this.$t('pedestrian.withUmbrella')},
        {id:"none",name:this.$t('pedestrian.withoutUmbrella')},
      ];
    }
    get umbrellaColorType(){
      return [
        {id:"black",name:this.$t('pedestrian.black')},
        {id:"white",name:this.$t('pedestrian.white')},
        {id:"gray",name:this.$t('pedestrian.gray')},
        {id:"red",name:this.$t('pedestrian.red')},
        {id:"yellow",name:this.$t('pedestrian.yellow')},
        {id:"blue",name:this.$t('pedestrian.blue')},
        {id:"green",name:this.$t('pedestrian.green')},
        {id:"purple",name:this.$t('pedestrian.purple')},
        {id:"transparent",name:this.$t('pedestrian.transparent')},
      ];
    }


    get respiratorStyleType(){
      return [
        {id:"st_respirator",name:this.$t("records.ownMask")},
        {id:"color_type_none",name:this.$t("records.noMask")},
      ];
    }


    @Emit()
    hideCondition() {
      this.conditionBoxVisible = false
      // console.log('hideCondition消失了');
    }

    @Emit()
    showCondition() {
      this.conditionBoxVisible = true
    }

    //获取r任务列表
    getRuleName(){
      if(this.monitorRules.length==0){
        let state = {taskTypes:[2,3]}
        // console.log(state);

        historyApi.getQueryTasksByType(state).then((data)=>{
          console.log(data);

          this.monitorRules=(data as any).taskNameVOList
          console.log(this.monitorRules);

        })
      }
    }

    //获取位置列表
    fetchLocation(val){
      if(!this.locationList.length){
        historyApi.fetchLocation().then((data)=>{
          console.log(data);

          this.locationList = data.data
        })
      }
    }

    //选取地点
    checkoutLocation(ids){
      // this.searchCondition.floorIds=ids
      this.data.placeId = ids
    }

    //获取设备列表
    fetchDevice(val){
      if(!this.deviceList.length){
        historyApi.fetchDevice().then((data)=>{
          this.deviceList = data.data
        })
      }
    }

    //选取任务
    checkoutRuleNameTypes(ids){
      this.data.taskId = ids
      // console.log('111');

    }

    //选取设备
    checkoutDevice(ids){
      // console.log(ids);
      this.data.deviceId = ids
    }

    //选取时间
    handleDateChange(tms){
      console.log(tms);
      // this.data

    }

    //选取告警
    checkoutcompareType(ids){
      this.data.alertType = ids
      console.log('选取告警',ids);

    }

    //选择性别
    checkoutGendere(ids) {
      this.data.pedestrianAttributeInfo.gender = ids
    }
    //初始化时间
    initData() {
      this.timeRange = null
    }

    //筛选
    @Emit()
    doSearch() {
      this.data.captureTimeStart =this.timeRange? this.timeRange[0]:null;
      this.data.captureTimeEnd = this.timeRange? this.timeRange[1]:null;
      let param :any = _.cloneDeep(this.data)
      this.isImgSearch ? param.similarity = this.similarity : null;
        // console.log(this.data);
      return param
    }
    //重置
    @Emit()
    resetCondition() {
        // console.log(12312312312);

        this.initData();//初始化时间
        EventBus.$emit('clearAll' , false); //重置全选
        // historyStore.reset_condition();//初始化检索条件
        // this.searchCondition = historyStore.condition;
        // (this.$refs.dept_tree as any).clearCheckout();
        (this.$refs.device_tree as any).clearCheckout();
        (this.$refs.location_tree as any).clearCheckout();
        // (this.$refs.watchlist_tree as any).clearCheckout();
        (this.$refs.compareType_tree as any).clearCheckout();
        (this.$refs.ruleName_tree as any).clearCheckout();  //任务
        // (this.$refs.operateStatus as any).clearCheckout();
        // ↓属性筛选
        ;(this.$refs.tree_ageClassify as any).clearCheckout()
        ;(this.$refs.tree_umbrellaColor as any).clearCheckout()
        ;(this.$refs.tree_umbrella as any).clearCheckout()
        ;(this.$refs.tree_bagColor as any).clearCheckout()
        ;(this.$refs.tree_bagStyle as any).clearCheckout()
        ;(this.$refs.tree_capColor as any).clearCheckout()
        ;(this.$refs.tree_capStyle as any).clearCheckout()
        ;(this.$refs.tree_coatColor as any).clearCheckout()
        ;(this.$refs.tree_coatDecorate as any).clearCheckout()
        ;(this.$refs.tree_coatStyle as any).clearCheckout()
        ;(this.$refs.tree_gender as any).clearCheckout()
        ;(this.$refs.tree_hairColor as any).clearCheckout()
        ;(this.$refs.tree_hairStyle as any).clearCheckout()
        ;(this.$refs.tree_respiratorColor as any).clearCheckout()
        ;(this.$refs.tree_respiratorStyle as any).clearCheckout()
        ;(this.$refs.tree_shoesColor as any).clearCheckout()
        ;(this.$refs.tree_shoesStyle as any).clearCheckout()
        ;(this.$refs.tree_trousersColor as any).clearCheckout()
        ;(this.$refs.tree_trousersDecorate as any).clearCheckout()
        ;(this.$refs.tree_trousersStyle as any).clearCheckout()
        this.similarity = '0.85';
        return ''
    }
   }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "@/styles/variables.scss";

  .filtrate-nav {
    position: absolute;
    width: 50%;
    top:0px;
    left: 50%;
    span{
      cursor:pointer;
    }

    .screen {
      // pointer-events: none;
      display: inline-block;
      width: 80px;
      height: 24px;
      text-align: center;
      // background: aqua;
      line-height: 24px;
      position: absolute;
      top: 21px;
      border: 1px solid;
      border-radius: 4px 4px 0 0;
      left: -40px;
      i {
        transform: rotate(0deg);
        transition: transform .5s ;
      }
      .conditionBoxVisible {

        transform: rotate(180deg);

      }
    }


  }

  .condition-box {
      // background-color: #fff;
      display: flex;
      justify-content:space-between;
      .condition-detail-all{
        display: flex;
        justify-content:space-between;
        // height: 32px;
        align-content: center;
        align-items: center;
        .condition-detail-item {
          // margin-right: 20px;
        }
      }

      .operate{
        display: flex;
        justify-content:space-between;
        margin-left: 50px;
        button {
          margin-left:10px;
        }
      }
  }

  .attr-title {
    >div span{
      font-weight: 700;
      font-size: 14px;
      margin: 10px;
      display: block;
    }

    .attributeBody {
      .condition-detail-all {
        margin-bottom: 10px;
      }
    }
  }

  .attributeBody {
    >div {
      display: flex;
    }
  }
  ::v-deep .attributeBody {
    .el-dropdown {
      max-width: 110px;
    }
    .tree-input .title{
      padding-right: 10px;
    }
  }

  ::v-deep .icon-filter {
      margin-right: 4px !important;
  }
  .condition-detail-item {
    display: flex;
    justify-content:space-between;
       // padding: 5px;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        line-height: 32px;
        height: 32px;
    .label {
      padding-right: 3px;
      padding-left: 10px;
      // display: inline-block;
      line-height: 32px;
      white-space: nowrap;
    }

  }

  ::v-deep  .tree-input {
    display: flex;
    justify-content:space-between;
    align-items: flex-end;
      .title {
        line-height: 32px;
      }
    }
</style>
