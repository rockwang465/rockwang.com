<template>
  <div class="pedestrian" @mouseenter="doMouseenter" @drop="dragDropHandle"  @dragend="dragend" @dragstart="dragstartHandle" @drag="handleDrag" @dragenter="dragenter" @dragleave="dragleaveHandle">
    <filtrateNav
      @do-search="doSearch"
      @reset-condition='resetCondition'
      @show-condition='showCondition'
      @hide-condition='hideCondition'
      :isImgSearch='isImgSearch'
      ref="filtrateN"
      />
      <el-button
        v-if="$permission('015301')"
        type="primary"
        size="small"
        class="batch-export"
        @click="showExportDialog"
      >
        <i class="iconfont icon-upload"></i>
        {{$t("records.buttonExport")}}
      </el-button>
      <div class="img-search-layer">
        <image-search ref="imgSearch" @imgData="getImgParmas" @keyWord="getKeyWord" @cancel="cancelImgSearch" @sourceType="getSourceType"></image-search>

      <!-- <el-input size="small" style="width:300px; margin:0 0 12px 12px;"
        :placeholder="$t('pedestrian.search')"
        v-model="data.keyWord"
        @keyup.enter.native="searchKeyword"
        >
        <i slot="suffix" v-show="data.keyWord" @click="()=>{data.keyWord = '',searchKeyword()}" style="cursor: pointer;" class="el-input__icon el-icon-circle-close"></i>
        <i class="iconfont icon-search1"  slot="suffix"  style="cursor: pointer;line-height: 32px;" @click="searchKeyword"/>
      </el-input> -->
        <el-popover
          placement="bottom-start"
          trigger="hover"
        >
          <div class="keyword-suggest" v-html="$t('records.hovmsgPedestrian')"></div>
          <i slot="reference" style="margin-left: 5px;color:#2a5af5;position: absolute;top: 8px;" class="el-icon-question"></i>
        </el-popover>
        <!-- <img :src="imgCropData" alt="" style="border:1px solid #ccc"> -->
      </div>
    <div v-if="!isImgSearch" class="list-img-pt" v-loading="loading">
      <ImageList
        :lists='comparisonInfo'
        :collapse='true'
        :class="{isHeighten}"
        >
        <ptImage
         slot-scope="{items, item }"
         :item="item"
         :items="items"
         slot="listCollapse"
         @view-detail="viewDetail"
         />
        <cardDetails
          slot-scope="{items}"
          slot="detail"
          :items="items"
          :data="comparisonDetail"
          :display="items.showCompareDetail"
          @collapse="hiddenDetail(items)" />
          <!-- <div slot="card" slot-scope='{currentCapture}' /> -->
      </ImageList>
    </div>
    <div class="block">
      <el-pagination
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        :page-size='pageSize'
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageNum"
        :page-sizes="[15, 30, 45 , 60, 105]">
      </el-pagination>
    </div>
    <div v-if="isImgSearch" class="img-search-result-layer">
      <image-search-result :imgCropData="imgCropData" :sourceType="imgSourceType" :captureData='comparisonDetail' :parentParams="searchData"  @cancelBack="cancelImgSearch">
      </image-search-result>
    </div>

    <batch-export
      :series="dialogTrigerNumber"
      @export="doExportRecord"
      :maxNum="total"
    />


   </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch , Emit} from "vue-property-decorator";
  import ptImage from '@/components/pedestrian-image/index.vue';
  import filtrateNav from '../component/filtrate-nav.vue';
  import cardDetails from '../component/card-details.vue';
  import ImageList from '@/components/image-list/index.vue';
  import request from '@/api/history-record';
  import BatchExport from '../component/batch-export.vue';
  import { Cache } from '@/utils/cache';
  import ImageSearch from '@/components/image-search/index.vue';
  import ImageSearchResult from '../image-search-result/index.vue';

  import { processImgurl } from '@/utils/image';
  var _ = require('lodash/lang');

  @Component({
    components:{
      ptImage,
      filtrateNav,
      ImageList,
      cardDetails,
      BatchExport,
      ImageSearch,
      ImageSearchResult
    }
  })
  export default class pedestrian extends Vue {
    loading = true;
    isImgSearch = false;
    data = {
      alertType: [],
      deviceId: [],
      captureTimeEnd: "",
      placeId: [],
      captureTimeStart: "",
      taskId: [],
      keyWord:'',
      pedestrianAttributeInfo: {
        ageClassi: [],
        umbrellaColor: [],
        umbrella: [],
        bagColor: [],
        bagStyle: [],
        capColor: [],
        capStyle: [],
        coatColor: [],
        coatDecorate: [],
        coatStyle: [],
        gender: [],
        hairColor: [],
        hairStyle: [],
        respiratorColor: [],
        respiratorStyle: [],
        shoesColor: [],
        shoesStyle: [],
        trousersColor: [],
        trousersDecorate: [],
        trousersStyle: []
      },
    };
    searchData:any = {
      alertType: [],
      deviceId: [],
      captureTimeEnd: "",
      placeId: [],
      captureTimeStart: "",
      taskId: [],
      keyWord:'',
      similarity:'',
      pedestrianAttributeInfo: {
        ageClassi: [],
        umbrellaColor: [],
        umbrella: [],
        bagColor: [],
        bagStyle: [],
        capColor: [],
        capStyle: [],
        coatColor: [],
        coatDecorate: [],
        coatStyle: [],
        gender: [],
        hairColor: [],
        hairStyle: [],
        respiratorColor: [],
        respiratorStyle: [],
        shoesColor: [],
        shoesStyle: [],
        trousersColor: [],
        trousersDecorate: [],
        trousersStyle: []
      },
    };
    pageNum= 1;
    pageSize= 15;
    total = 0;
    dialogTrigerNumber = 0 ;
    keyWordOK = '';
    comparisonInfo =[];
    triggerEle :any;
    $refs!: {
      imgSearch: ImageSearch,
      filtrateN: filtrateNav
    }
    resultImgData=''
    cropInfo:any = {}
    imgSourceType = ''
    showCompareDetail:boolean = false;
    //传递的数据
    comparisonDetail ={};

    isHeighten = false;
    isImgLoad = false;
    imgCropData = ''
    imageSearchResultList = []

    @Watch('imgCropData', { immediate: false, deep: false })
    resultImgDataChanged(n,o) {
      //this.showImage=n?true:false;
      //console.log(n,o)
      //this.getCropInfo()
      //this.isImgSearch = true;
    }

    mounted() {
      // console.log(this.data);
      this.renderPedestrians()
    }
    getItemesData(item){
      console.log(item)
    }
    getImgParmas(e){
      //console.log(e)
      this.resultImgData = e;
      this.imgCropData = e;
      this.isImgSearch = true;
      this.searchData.imageBodyBase64 = e
      this.$set(this.searchData,'imageBodyBase64',e)
      // this.$refs.imgSearch.dragDrop(event,this.resultImgData)
    }
    getSourceType(e){
      this.imgSourceType = e;
    }
    getKeyWord(word){
      this.data.keyWord = word;
      this.keyWordOK = this.data.keyWord
      this.pageNum = 1
      this.renderPedestrians()
    }
    doMouseenter(){
      // this.dragBoxVisible = false;
    }
    dragstartHandle(event){
      //event.preventDefault();
      // let el = event.target || event.srcElement;
      this.getCropInfo(event)
      //console.log(event)
    }
    handleDrag(event){
      event.preventDefault();
    }
    getCropInfo(ev){
      let self = this;
      let el = ev.target || ev.srcElement;
      //console.log(el.dataset.imgcrop)
      if(el.dataset.imgcrop){
        //console.log(el.dataset)
        let currentCardInfo = JSON.parse(el.dataset.imgcrop)
        //console.log(currentCardInfo);
        this.comparisonDetail = currentCardInfo

        //console.log(JSON.parse(el.dataset.imgcrop.bigPicture))
        this.cropInfo = currentCardInfo.bigPicture
        //console.log(this.cropInfo)
        this.cropInfo.sx=this.cropInfo.portraitImageCoordinateInfo.startX,
        this.cropInfo.sy=this.cropInfo.portraitImageCoordinateInfo.startY,
        this.cropInfo.swidth=(this.cropInfo.portraitImageCoordinateInfo.endX - this.cropInfo.portraitImageCoordinateInfo.startX),
        this.cropInfo.sheight=(this.cropInfo.portraitImageCoordinateInfo.endY - this.cropInfo.portraitImageCoordinateInfo.startY)
      }
    }
    getCropImgData(event){
      //console.log(event,this.cropInfo)
      let self = this;
      let fileList = event.dataTransfer.files;
      //console.log(fileList)
      if(fileList.length > 0){
        self.$refs.imgSearch.dragDrop(event)
      }
      let canvas = document.createElement('canvas'),
          ctx    = canvas.getContext('2d');
        canvas.width = this.cropInfo.swidth;
        canvas.height = this.cropInfo.sheight;



      if(!this.cropInfo || !this.cropInfo.imgUrl){
        alert("暂不支持")
        self.isImgLoad = false;
        this.$refs.imgSearch.dragBoxVisible = false
        this.$refs.imgSearch.isDargLoading = false
        return false
      }
      let bigImg = new Image;
      this.$refs.imgSearch.identifying()
      bigImg.src = processImgurl(this.cropInfo.imgUrl);

      bigImg.onload= (e) =>{
        if(ctx){
          ctx.drawImage(bigImg,this.cropInfo.sx,this.cropInfo.sy,this.cropInfo.swidth,this.cropInfo.sheight,0,0,this.cropInfo.swidth,this.cropInfo.sheight);
          let cropResult = ctx.getImageData(0,0,this.cropInfo.swidth,this.cropInfo.sheight);//Uint8ClampedArray
          let toDataURL = canvas.toDataURL("image/png")
          this.imgCropData = toDataURL

          self.$refs.imgSearch.dragDrop(event,toDataURL)
          self.isImgLoad = false;
          self.isImgSearch = true;
          //console.log(`裁切后,宽度${this.cropInfo.swidth}，高度${this.cropInfo.sheight}`)
          //this.searchBodyByImage()
        }
      }
    }
    searchBodyByImage(){
      // let params = {
      //   imageBodyBase64:this.imgCropData
      // }
      // request.searchBodyByImage(params).then((resp:any)=>{
      //   console.log(resp)
      //   this.imageSearchResultList = resp.list
      // })
    }
    cancelImgSearch(){
      this.isImgSearch = false;
      this.$refs.imgSearch.hasImg = false;
      this.$refs.imgSearch.placeholderText = this.$t('records.textboxEnterKeywordT');
      this.comparisonDetail = {}

      //this.$refs.imgSearch.cancelImageSearch()
    }
    //父级拖拽到目标区域
    dragenter(event){
      event.preventDefault();
      let _self = this;
      let el = event.target || event.srcElement
      if(el.name === 'dropBox'){
        //console.log(event)
        //this.getCropImg(event)
        this.$refs.imgSearch.borderRun()
      }
      this.$refs.imgSearch.showDragBox()
      this.$refs.filtrateN.isPoVisible = false
    }
    dragleaveHandle(event){
      let el = event.target || event.srcElement;
      if(el.name === 'dropBox'){
        //console.log(event)
        //this.getCropImg(event)
        this.$refs.imgSearch.borderStop()
      }
    }
    //父级拖动结束时候触发
    dragend(event){
      event.preventDefault();
      if(!this.isImgLoad){
        this.$refs.imgSearch.hideDragBox()
      }
    }
    //父级拖拽上传图片搜索
    dragDropHandle(event){
      let el = event.target || event.srcElement;
      this.isImgLoad = true
      if(el.name === 'dropBox'){
        this.getCropInfo(event)
        this.getCropImgData(event)
      }
      event.preventDefault();
    }

    renderPedestrians() {
      this.loading = true
      let param :any = _.cloneDeep(this.data);
      param.pageNum = this.pageNum;
      param.pageSize = this.pageSize;
      request.getPedestrians(param).then((data)=>{
        this.comparisonInfo = this.processComparisonInfo(data.data.list?data.data.list : []) as any;
        //console.log(this.comparisonInfo)
        this.total = data.data.total as number;
      }).finally(()=>{
        this.loading = false
      });
    }

    //处理列表数据
    processComparisonInfo(items){
      let size = 5;
      let comparisonInfo = new Array();
      let i;
      items.forEach((v,k)=>{
        v["isFocus"]=false;//当前详情被点击
        if(k===0){
          i=0
          comparisonInfo[i]={showCompareDetail:false,data:[]}
        }else if(k%5===0){
          i++
          comparisonInfo[i]={showCompareDetail:false,data:[]}
        }
        comparisonInfo[i].data.push(v)
      })

      return comparisonInfo;
    }

    viewDetail(data,e) {

      if(this.$permission('009304')){//查看详情涉及到修改状态权限，所以没有修改权限的用户点击不触发详情
        this.triggerEle=e
        //所有展开收缩
        this.comparisonInfo.forEach((val :any)=>{
          val.showCompareDetail=false;
          console.log(val);
          val.data.forEach((obj)=>{
            obj.isFocus=false
          })
        })
        //当前展开
          console.log(data,e);
          data.items.showCompareDetail = true
          data.item.isFocus = true;
          this.comparisonDetail = data.item
          console.log(this.comparisonDetail)
          this.comfirmCompareStatus(data.item,1,1)
      }
    }

    //收起详情
    hiddenDetail(data){
      //当前详情数据置空
      this.comparisonDetail={}
      // console.log(data);
      data.showCompareDetail=false
      data.data.forEach((val)=>{
        val.isFocus=false;
      })
    }

    //筛选
    doSearch(val) {
      console.log('筛选',val);
      this.pageNum = 1;
      if(!this.isImgSearch) {
        this.data = val
        this.renderPedestrians()
      } else {
        this.searchData = val
        // console.log('搜图页',this.data);
        //this.$refs.imgSearch.getImageResultData()
      }
    }

    //重置
    resetCondition() {
      console.log('重置');

    }

    hideCondition() {
      console.log('hideCondition');
      this.isHeighten = false
    }
    showCondition() {
      console.log('showCondition');
      this.isHeighten = true
    }

    //分页
    handleSizeChange(val) {
      // console.log(val);
      this.pageSize = val;
      // this.pageNum = 1;
      this.loading = true
      this.renderPedestrians()
    }
    handleCurrentChange(val) {
      // console.log(val);
      this.loading = true
      this.pageNum = val
      this.renderPedestrians()
    }

    //搜索关键字
    searchKeyword() {
      this.pageNum = 1
      this.keyWordOK = this.data.keyWord
      // console.log(this.keyWordOK);
      this.renderPedestrians()
    }

    comfirmCompareStatus(item,status,type){

      let serialNumber = item.objectId;
      // console.log(item);

      let param = {id:item.objectId,confirmationStatus:status,type}
      request.checkCompareStatus(param).then(()=>{
        // item.confirmationStatus=status

      })
    }

    //显示导出弹框
    showExportDialog(){
      this.dialogTrigerNumber = Math.random()
    }

    //导出
    doExportRecord(start,end){
        let param :any = _.cloneDeep(this.data);
        param.from = start;
        param.to = end;
        param.keyWord = this.keyWordOK;
        param.userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";

        console.log(param);

        request.exportPedestrian(param).then(()=>{
          this.$message({
            showClose: true,
            message: this.$t("log.exportSuccess") as string,
            type: 'success',
            duration: 3 * 1000,
          });
        })

        //   this.$message({
        //     message: this.$t("log.exportSuccess") as string,
        //     type: 'success',
        //     duration: 3 * 1000,
        //  });
    }
  }
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .pedestrian{
    margin-top: 12px;
    height: 95%;
    overflow-y: auto;
    .list-img-pt {
      min-height: 700px;
      height: calc(100% - 250px);
      padding-top: 1px;
      overflow-y: auto;
      .image-list-container {
        transition: all .5s ;
      }
      .isHeighten {
        margin-top: 22px;
      }
    }
    .img-search-layer{
      width:400px;
      margin-bottom:12px;
      margin-left:12px;
      min-height:32px;
      background:#eff0ff;
      z-index: 9;
      position: relative;
    }
    .block .el-pagination{
      margin: 0 auto;
      width: 50%;
      text-align: center;
    }
    .batch-export {
      position: absolute;
      right: 35px;
      top: 5px;
    }
  }

  .keyword-suggest{
  //  display: flex;
  //  flex-wrap:wrap;
    :first-child{
      font-weight: 900;
    };
    :last-child{
      word-break:break-all;
    }
  }
  .img-search-result-layer{
    padding:6px 12px 0;
    height: calc(100% - 80px);
  }
</style>
