<template>
  <carousel
  :perPage="8"
  :navigationEnabled="true"
  :paginationEnabled="false"
  :mouseDrag="false"
  @pageChange="pageChange"
  >
    <slide
      v-for="(item,key) in data" :key="key">
        <single-image
        class="img-container"
        :percentage="item.score+''"
        :img="item.url || item.portraitImage ||item.faceUrl"
        :item="item"
        @viewDetail="viewCaptureDetail(item,key)"
      />
    </slide>
  </carousel>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import { Carousel, Slide } from 'vue-carousel';
import  SingleImage from '@/components/single-image/index.vue';

@Component({
  components:{
    Carousel,
    Slide,
    SingleImage,
  },
})
export default class Crousel extends Vue {
  @Prop({default(){return []}}) data!:any[];

  mounted(){

  }
  viewCaptureDetail(item, key){
    this.$emit("click",item,key)
  }
  pageChange(val){
    this.$emit("slide",val)
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
    .img-container{
      height: 150px;
      width: 80%;
     }
</style>
