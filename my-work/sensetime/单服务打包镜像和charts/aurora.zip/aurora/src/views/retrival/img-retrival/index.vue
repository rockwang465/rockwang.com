<template>
  <div class="img-retrival-container">
    <div class="img-compare">
      <div class="two-image">
        <div>
          <div class="img-box"><img :src="imgUrl" alt=""></div>
        </div>
        <div v-if="matchMsg">
          <span >{{toPercent(matchMsg.score)}}</span>
        </div>
        <div v-if="matchMsg">
          <div class="img-box">
              <img v-if="currentTab==='captureLib'" :src="processImgurl(matchMsg.portraitImage)" alt="">
              <img v-else :src="processImgurl(matchMsg.faceUrl)" alt="">
          </div>
        </div>
      </div>
      <div class="two-image-info">
        <div class="img-info-left">{{$t("records.contNoImage")}}</div>
        <div v-if="matchMsg" class="img-info-right">
          <div v-if="currentTab==='captureLib'">
            <div>
              <span>{{$t("records.contTime")}}:</span>
              <span>{{matchMsg.capturedTime}}</span>
            </div>
            <div>
              <span>{{$t("records.contDevice")}}:</span>
              <span>{{matchMsg.deviceName}}</span>
            </div>
            <div>
              <span>{{$t("pedestrian.mission")}}:</span>
              <span>{{matchMsg.taskName}}</span>
            </div>
          </div>
          <div v-else>
            <div>
              <span>{{$t("records.contName")}}:</span>
              <span>{{matchMsg.name}}</span>
            </div>
            <div>
              <span>{{$t('records.contID')}}</span>
              <span>{{matchMsg.id}}</span>
            </div>
            <div>
              <span>{{$t("records.contImageLibrary")}}:</span>
              <span>{{matchMsg.featureDbName}}</span>
            </div>
          </div>
        </div>
      </div>
      <div v-if="matchMsg" class="compare-type">
      </div>
    </div>
    <div class="img-list-container">
      <div class="btn-container">
        <span class="title">{{$t("records.searchResult")}}</span>
        <el-button
          class="tab-btn"
          :plain="currentTab!=='captureLib'"
          @click="changelib('captureLib')"
          size="mini"
          type="primary">
            {{$t("records.contCaptureLibrary")}}
        </el-button>
        <el-button
          :plain="currentTab!=='facialLib'"
          class="tab-btn"
          @click="changelib('facialLib')"
          size="mini"
          type="primary">
            {{$t("records.contImageLibrary")}}
        </el-button>
      </div>
      <capture-lib
        v-if="currentTab=='captureLib'"
        v-loading="isLoad"
        :data="captureLibList"
        @sort="handleCaptureSort"
        @click="viewCurrentCapture"
      />
      <facial-lib
        v-else
        v-loading="isLoad"
        :data="facialLibList"
        @sort="handleFacialSort"
        @click="viewCurrentFacial"
      />

    <!--
      <el-tabs v-model="activeTab" type="card" @tab-click="changelib">
        <el-tab-pane :label="$t('records.contCaptureLibrary')" name="captureLib">
          <capture-lib
            v-loading="isLoad"
            :data="captureLibList"
            @sort="handleCaptureSort"
            @click="viewCurrentCapture"
          />
        </el-tab-pane>
        <el-tab-pane :label="$t('records.contImageLibrary')" name="facialLib">

          <facial-lib
            v-loading="isLoad"
            :data="facialLibList"
            @sort="handleFacialSort"
            @click="viewCurrentFacial"
          />
        </el-tab-pane>
      </el-tabs>
      -->
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import  TwoImage from '@/components/two-image/index.vue';
import  CaptureLib from './capture-lib/index.vue';
import  FacialLib from './facial-lib/index.vue';
import { historyStore } from '@/store/modules/history-record';
import { toPercent } from '@/utils/small-tool';
import { processImgurl } from '@/utils/image';
import  Icon from '@/components/icon-wrap/index.vue';

@Component({
  components: {
    TwoImage,
    CaptureLib,
    FacialLib,
    Icon
  },

})
export default class ImageRetrival extends Vue {
  @Prop({default:"captureLib"}) currentTab!:string;
  @Prop({default:true}) isLoad!:boolean;
  @Prop({default(){return []}}) captureLibList!:any[];
  @Prop({default(){return []}}) facialLibList!:any[];
  @Prop({default:''}) imgUrl!:string;

  // currentTab:any; //接受父组件传
  activeTab:any=this.currentTab; //接受父组件传
  // activeTab="captureLib"; //当前tab页
  showCompareDetail:boolean=false;
  comparisonDetail={};
  // captureLibList:any;
  // facialLibList:any;
  matchMsg:any="";
  toPercent=toPercent;
  processImgurl=processImgurl

  //修复:BUG 重置修图照片消失
  // imgUrl :any;
  // get imgUrl(){
  //   return historyStore.condition.imageFaceBase64
  // }
  // @Watch('activeTab', { immediate: true, deep: true })
  // onTabChanged(val, oldVal) {
  //   if(val==="facialLib"){
  //     this.matchMsg = this.facialLibList[0]
  //   }else{
  //     this.matchMsg = this.captureLibList[0]
  //   }
  //  }
  //监听人像搜图列表
  @Watch('facialLibList', { immediate: true, deep: true })
  onfacialLibChanged(val, oldVal) {
    if(val){
      this.matchMsg = val[0]
    }
  }
  //监听抓拍搜图列表
   @Watch('captureLibList', { immediate: true, deep: true })
  oncaptureLibChanged(val, oldVal) {
    if(val){
    this.matchMsg = val[0]
    }
  }
  mounted(){
  }
  viewCurrentCapture(data){
    this.matchMsg=data
  }
  viewCurrentFacial(data){
    this.matchMsg=data
  }
  @Emit("changetab")
  changelib(activeTab){
    return activeTab
  }
  @Emit("sort")
  handleCaptureSort(data){
    return data;
  }
  @Emit("sort")
  handleFacialSort(data){
    return data;
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
@media screen and (max-width: 1366px) {
  .img-compare {
    width: 28% !important;
  }
  .img-list-container {
    width: 70% !important;
  }
}
  // .empty-box{
  //   height: 200px;
  //     div{
  //       text-align: center;
  //       margin: 100px auto;

  //       .icon{
  //         color: $--scrollbar-color;
  //         font-size: 80px !important;
  //       }
  //     }
  //   };
  .img-retrival-container{
    display: flex;
    align-items: stretch;
    height:90%;
    .img-compare{
      width: 25%;
      .two-image{
        display: flex;
        width: 350px;
        margin: 10px auto;

        >div:first-child{
          width: 45%;
          .img-box{
            width: 100%;
            height: 200px;
            img{
              height: 100%;
              width: 100%;
            }
          }

        }
        >div:nth-child(2){
          width: 10%;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          span {
            z-index: 1;
            position: absolute;
            background: $--color-reserved-5;
            width: 60px;
            height: 60px;
            border-radius:50%;
            text-align: center;
            line-height: 60px;
            color: #fff;
            font-size: 16px;
          }
        }
        >div:last-child{
          width: 45%;
          .img-box{
            width: 100%;
            height: 200px;
            img{
              height: 100%;
              width: 100%;
            }
          }
        }
      }
      .two-image-info{
        display: flex;
        justify-content: space-between;
        width: 350px;
        margin: 10px auto;
        .img-info-right{
          width: 50%;
        }

        .img-info-right{
          margin-top: 10px;
          width: 51%;
          div{
            >div{
              padding:5px 0;
              display: flex;
              word-wrap:break-word;
              span{
                word-wrap:break-word;
                padding: 3px;
                &:first-child{
                  white-space:nowrap;
                }
                &:last-child{
                  display: block;
                  width:80%;
                }
              }
            }
          }

        }
      }
     .compare-type{
      border-top: $--border-base;
      padding: 10px 0;
      div{
        padding: 5px 0;
      }
      }
    }
    .img-list-container{
      width: 75%;
      padding: 10px;
      .btn-container{
        border-bottom:1px solid $--color-primary;
        .title{
          font-size:16px;
          padding:0 10px;
        }
        .tab-btn{
          margin-left:0;
          border-radius:5px 5px 0 0;
        }
      }
    }
  }
</style>
