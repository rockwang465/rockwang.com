<template>
    <div class="pedestrianImage"  @click="viewDetail">
    <div class="pedestrianImage-left">
      <div class="pt-state"  :style="[bgcStyle]">{{$t(i18nCompareType(item.alertType))}}</div>
      <el-image
        :src="processImgurl(item.imgUrl)"
         fit="contain">
        <div slot="error" class="image-slot">
          <i class="el-icon-picture-outline"
          style="color: aliceblue;
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%,-50%);"
          ></i>
        </div>
      </el-image>
    </div>
    <div :class="['pedestrianImage-right',language ?'isEn':'']" >

      <ul>
        <li>
          <!-- <div><span>{{$t('pedestrian.carType')}}:</span><p style="text-align: center;" :class=" item.color ?item.color.toLowerCase() : 'white'">{{ $t('pedestrian.'+(item.type ? item.type.toLowerCase() : 'no'))}}</p></div> -->
        </li>
        <li>
          <!-- <div><span>{{$t('pedestrian.carModel')}}:</span><p>{{item.model || $t('pedestrian.no')}}</p></div> -->
        </li>
        <li>
          <div><span>{{$t('pedestrian.stayTimes2')}}:</span><p>{{toMin(item.stayTimes) || $t('pedestrian.no')}}</p></div>
        </li>
        <li>
          <!-- <div><span>{{$t('pedestrian.carNum')}}:</span><p>{{item.carNum || $t('pedestrian.no')}}</p></div> -->
        </li>
        <li>
          <div><span>{{$t('pedestrian.title')}}:</span><p>{{item.deviceName}}</p></div>
        </li>
        <li>
          <div><span>{{$t('pedestrian.site')}}:</span><p>{{item.placeName}}</p></div>
        </li>
        <li>
          <div><span>{{$t('pedestrian.time')}}:</span><p>{{item.captureTime}}</p></div>
        </li>
      </ul>
      <!-- <div class="pedestrianImage-bt">
      </div> -->
    </div>
  </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch , Emit,Prop} from "vue-property-decorator";
  import Icon from '@/components/icon-wrap/index.vue';
  import { processImgurl } from "@/utils/image";
  import request from '@/api/history-record';
  import { toMin } from '@/utils/small-tool';
  import { AppModule } from '@/store/modules/app';

  @Component({
    components:{
      Icon
    },
    // props: {
    //   items: {
    //     type: Object,
    //     default() {
    //       return [];
    //     }
    //   },
    //   item: {
    //     type: Object,
    //     default() {
    //       return [];
    //     }
    //   }
    // }
  })
  export default class vehicleImage extends Vue{
    @Prop({default(){return {}}}) item!:object;
    @Prop({default(){return {}}}) items!:object;

    processImgurl = processImgurl;
    toMin = toMin ;
    // item: any;
    // items: any;
    data = {}
    bgcStyle  = {
      background :''
    } //告警颜色样式
    // show = ''

    i18nCompareType(val) {
      let compareType = ""
     switch(val){
       case "0":
       compareType = 'pedestrian.unknown';
       this.bgcStyle.background = '#FF9800'
       break;
       case "1":
       compareType="pedestrian.pedestrianRecord"; //$t('pedestrian.search')
       this.bgcStyle.background = '#1989fa'
       break;
       case "2":
       compareType="pedestrian.vehicleRecord";
       this.bgcStyle.background = '#1989fa'
       break;
       case "3":
      //  compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
      //  compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
      //  compareType="records.listNotifyTypeBlacklist";
       break;
       case "10":
       compareType="pedestrian.pedestrianCrossingWarning";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "11":
       compareType="pedestrian.pedestriansInvasion";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "20":
       compareType="pedestrian.parkedVehicles";
       this.bgcStyle.background = '#ED3A33'
       break;
     }
     return compareType

    }

    mounted() {
      // this.bgcStyle.background = 'red'
      // console.log(this.item);

    }

    get language() {
      return AppModule.language == 'en';
    }


    @Emit() //点击图片查看详情
    viewDetail(){
      console.log('-------------点击图片查看详情--------');
      if(this.$permission('009304')) {
        this.comfirmCompareStatus(this.item,1,3)
      }
      return { items:this.items,item:this.item }
    }

    // toLowerCase(val:string) {
    //   // console.log((this.item.carColor));
    //   return val.toLowerCase()
    // }

    //更新查看状态
    comfirmCompareStatus(item,status,type){

      let serialNumber = item.objectId;
      // console.log(item);

      let param = {id:item.objectId,confirmationStatus:status,type}
      request.checkCompareStatus(param).then(()=>{
        // item.confirmationStatus=status

      })
    }

  }
</script>

<style lang="scss" scoped>
@media screen and (max-width: 1600px){
  .pedestrianImage-bt {
    span {
          max-width: 70% !important;
    }
  }
}

.pedestrianImage {
  width: 100%;
  height: 100%;
  // background-color: pink;
  // position: relative;
  display: flex;
  cursor:pointer;
  margin: 0.5%;
  display: flex;
  background:rgba(255,255,255,1);
  border:1px solid rgba(223,223,224,1);
  box-shadow:0px 3px 6px rgba(0,0,0,0.16);
  opacity:1;
  border-radius:4px;
  overflow: hidden;

  .pedestrianImage-left {
    height: 100%;
    width: 38%;
    background:rgba(242,246,253,1);
    padding: 10px;
    position: relative;
    padding-top: 30px;
    .pt-state {
      position: absolute;
      width: 100%;
      height: 20px;
      text-align: center;
      line-height: 20px;
      // background-color: pink;
      color: #fff;
      border-radius: 4px 0 0 0 ;
      top: 0px;
      left: 0px;
    }
    .el-image {
      width:113.95px;
      height:160px;
      // background-color: #011C50;
      border: 1px dashed #CDE1FD;
      background-color: #DFEAFC;
    }

  }

  .pedestrianImage-right {
    height: 100%;
    width: 62%;
    // background-color:skyblue;
    // padding: 30px 0px 0px 0px;
    &.isEn ul li div span {
      min-width: auto;
      margin-left: 5px;
    }
    ul {
      // display: flex;
      // flex-wrap: wrap;
      // height: 50%;
      // overflow: hidden;
      position: relative;
      top: 50%;
      transform: translateY(-50%);
      margin-left: 15px;

      li {
        display: flex;
        width: 100%;
        // height: 50%;
        overflow: hidden;
        text-align: center;
        line-height: 24px;

        div {
          width: 100%;
          display: flex;
          font-size: 14px;

          span{
            // min-width: 35%;
            font-size: 14px;
            // text-align: right;
            width: 33px;
            display: block;
            justify-content: flex-end;
            overflow: hidden;
            text-overflow: ellipsis;
            -ms-text-overflow: ellipsis;
            white-space:nowrap;
            margin-right: 5px;
          }
          p {
            flex: 1;
            border-radius: 4px;
            min-width: 63px;
            text-align: left;
            overflow: hidden;
            text-overflow: ellipsis;
            -ms-text-overflow: ellipsis;
            white-space:nowrap;
          }
        }


      }
    }
    .nullAttributes {
      div {
        border: 1px solid #DFDFE0;
      }
    }

    .pedestrianImage-bt {
      div {
        margin-top: 10px;
        display: flex;;
        span {
          margin-left: 3px;
          max-width: 75%;
          display: block;
          overflow: hidden;
          text-overflow: ellipsis;
          -ms-text-overflow: ellipsis;
          white-space: nowrap;

        }
      }
    }
  }


}
</style>
