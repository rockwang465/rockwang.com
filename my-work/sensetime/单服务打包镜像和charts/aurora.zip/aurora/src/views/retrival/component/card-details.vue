<template>
   <transition
    name="custom-classes-transition"
    enter-class="hidden"
    enter-to-class="show"
    leave-to-class="hidden"
    leave-class="show"
    v-on:enter="afterEnter"
   >
  <div ref="detail" v-if="display" class="record-detail">
      <Icon
        class="close-tab"
        type="ele"
        size="30"
        cursor="pointer"
        name="close"
        @click="collapseDetail"
      />
      <div class="detail-container">
        <div class="detail_xq">
          <div class="pt-state" :style="[bgcStyle]">{{$t(i18nCompareType(currentCapture.alertType))}}</div>
          <el-image
            :src="processImgurl(currentCapture.imgUrl)"
            :data-imgcrop="JSON.stringify(currentCapture)"
            fit="contain">
            <div slot="error" class="image-slot">
              <i class="el-icon-picture-outline"
              style="color: aliceblue;
              position: absolute;
              left: 50%;
              top: 50%;
              transform: translate(-50%,-50%);"
              ></i>
            </div>
            </el-image>

          <div class="pt-state-bt">
              <div class="pt-state-l">
                <ul v-if="currentCapture.attributes && currentCapture.attributes.length!= 0">
                  <li v-for="item in currentCapture.sortAttributeInfoVos.slice(0,4)" :key="item.key" :class="language == 'en' ? 'isEn' : ''">
                    <Icon type='icon' cursor="pointer" :name="getSortAttributeInfoVos(item)"/>
                    <div class="A" :class="dressUpper(item.attributeInfo , 'color')">{{dressUpper(item.attributeInfo , 'style')}}</div>
                  </li>
                </ul>
                <ul v-else class="nullAttributes">
                  <li>
                    <Icon type='icon' cursor="pointer" name='maozi' />
                    <div>{{$t('pedestrian.no')}}</div>
                  </li>
                  <li>
                    <Icon type='icon' cursor="pointer" name='shangyi'/>
                    <div>{{$t('pedestrian.no')}}</div>
                  </li>
                  <li>
                    <Icon type='icon' cursor="pointer" name='faxing'/>
                    <div>{{$t('pedestrian.no')}}</div>
                  </li>
                  <li>
                    <Icon type='icon' cursor="pointer" name='kuzi'/>
                    <div>{{$t('pedestrian.no')}}</div>
                  </li>
                </ul>
              </div>
              <div class="pt-state-r">
                <div>
                  <b>{{$t('pedestrian.title')}}:</b>
                  <el-popover
                          placement="right-start"
                          width="150"
                          trigger="hover"
                          :content="currentCapture.deviceName"
                        >
                          <p slot="reference">{{currentCapture.deviceName}}</p>
                        </el-popover>
                </div>
                <div>
                  <b>{{$t('pedestrian.site')}}:</b>
                  <el-popover
                          placement="right-start"
                          width="150"
                          trigger="hover"
                          :content="currentCapture.placeName"
                        >
                          <p slot="reference">{{currentCapture.placeName}}</p>
                        </el-popover>
                </div>
                <div><b>{{$t('pedestrian.time')}}:</b><span>{{currentCapture.captureTime}}</span></div>
                <div v-if="currentCapture.alertType != 1">
                  <b>{{$t('pedestrian.mission')}}:</b>
                  <el-popover
                          placement="right-start"
                          width="150"
                          trigger="hover"
                          :content="(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName ) ? currentCapture.taskInfo.task.taskName :$t('pedestrian.no')"
                          :disabled="!(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName )"
                        >
                      <p slot="reference">{{(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName ) ? currentCapture.taskInfo.task.taskName :$t('pedestrian.no')}}</p>
                    </el-popover>

                </div>
                <div v-if="currentCapture.attributes && currentCapture.attributes.length!= 0" style="font-size:12px;color:#2A5AF5">
                    <el-popover
                      placement="right-end"
                      trigger="hover"
                      width='200'
                    >
                       <ul>
                         <li v-for="item in currentCapture.detailSortAttributeInfoVos" :key="item.key">
                         <!-- <li v-for="item in newAttributes" :key="item.key" > -->
                           <!-- :class="item.key== item.value.toLowerCase() ? '0':'-1'" -->
                           <!-- <span>{{$t('pedestrianTo.'+item.key)}}:</span><span>{{changeGenduo(item.value)}}</span> -->
                           <p v-if="item.attrValues && item.attrValues.length">
                              <span>{{$t('pedestrianTo.'+item.attrClassify.toLowerCase())}}:</span><span >{{getAttrvalueMore(item.attrValues) }}</span>
                           </p>
                         </li>
                       </ul>
                      <b slot="reference" style="cursor: pointer;margin-left:0;">{{$t("records.moreAttr")}}</b>
                    </el-popover>
                     <i style="margin-left: 3px;font-size: 14px;line-height: 14px;" class="iconfont icon-gengduo"> </i>
                </div>
              </div>
          </div>
        </div>

        <div class="detail-list">
            <div v-if="currentCapture.bigPicture" class="capture-detail">
            <div class="capture-big-img">
              <div  class="capture-big-img-top">
                <span>{{$t("records.contDevice")}}:{{currentCapture.deviceName}}</span>
                <span>{{currentCapture.captureTime?currentCapture.captureTime:currentCapture.captureTime}}</span>
              </div>
              <div class="big-img-container">

                <canvas style="width: 100%;position: absolute;left: 0px;top: 50%;transform: translateY(-50%);" id="cvs" ref="cvs"></canvas>
                <div class="big-img-container-btn">
                    <el-button
                      size="mini"
                      type="primary"
                      @click="handleFullscreen"
                      >
                      <Icon  name="fullscreen"></Icon>
                      {{$t("records.buttonFullScreen")}}
                     </el-button>
                    <el-button size="mini" type="primary" @click="downloadBigImage(currentCapture)">
                     <Icon name="download"></Icon>{{$t("records.buttonPictureDownload")}}
                    </el-button>
                </div>
                <div v-if="isFullScreen" class="big-img-fullscreen">
                  <Icon
                    class="close-tab"
                    type="ele"
                    size="30"
                    cursor="pointer"
                    name="close"
                    style="color:#fff"
                    @click="cancelFullscreen"
                  />
                  <transition
                    name="custom-classes-transition"
                    enter-class="fadeIn"
                    enter-to-class="fadeIn"
                    leave-to-class="fadeOut"
                    leave-class="fadeOut"
                  >
                    <img :src="processImgurl(currentCapture.bigPicture.imgUrl)" alt="">
                  </transition>
                  <Icon
                    v-show="!isAutoPlay"
                    class="previous-page"
                    type="ele"
                    size="100"
                    cursor="pointer"
                    name="arrow-left"
                    @click="viewPreviousImage"
                  />
                   <Icon
                    v-show="!isAutoPlay"
                    class="next-page"
                    type="ele"
                    size="100"
                    cursor="pointer"
                    name="arrow-right"
                    @click="viewNextImage"
                  />
                  <Icon
                    v-if="isAutoPlay"
                    class="auto-play"
                    size="50"
                    cursor="pointer"
                    name="pause"
                    @click="handlePause"
                  />
                  <Icon
                    v-else
                    class="auto-play"
                    size="50"
                    cursor="pointer"
                    name="play"
                    @click="handleAutoPlay"
                  />
                </div>
              </div>
            </div>
            <div class="path-track">
              <div class="path-track-top">
                <span>{{$t("records.contMap")}}:</span>
                <span>{{currentCapture.placeName}}</span>
              </div>
               <div class="path-track-container">
                 <map-device handleType="view" :deviceInfo="[currentCapture.devicePlaceInfo]" :key="currentCapture.devicePlaceInfo.id"/>
              </div>
            </div>
         </div>
        </div>
      </div>
  </div>
</transition>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import { scrollTo, scrollIntoView  } from 'scroll-js';
import  TwoImage from '@/components/two-image/index.vue';
import  Icon from '@/components/icon-wrap/index.vue';
import  SnDialog from '@/components/sn-dialog/index.vue';
import { convertCardType, toPercentage } from '@/utils/small-tool';
import { Cache } from '@/utils/cache';
import   { historyStore }  from '@/store/modules/history-record';
import   TrackSelect  from './track-selected.vue';
import   Carousel  from './carousel.vue';
import BatchExport from './batch-export.vue';
import Sort from './sort.vue';
import { processImgurl } from '@/utils/image';
import MapDevice from '../../manage/map/map-device.vue';
import { clearInterval } from 'timers';
import dayjs from 'dayjs';
var _ = require('lodash/lang');
import currentCompare from '@/components/three-image/index.vue';
import { AppModule } from '@/store/modules/app';
import { dressUpper, getSortAttributeInfoVos, getAttrvalueMore } from './processInfo';

@Component({
  // props:{
    // display:{
    //   type:Boolean,
    //   default:false
    // },
    // data:{
    //   type:Object,
    //   default:()=>{
    //     return {};
    //   }
    // },
    // triggerEle:{
    //   type:MouseEvent,
    //   default(){
    //     return {};
    //   }
    // },
    //  captureList:{
    //   type:Array,
    //   default(){
    //     return [];
    //   }
    // },
    // totalCapture:{
    //   type:Number,
    //   default:0
    // }
  // },
  components: {
    TwoImage,
    Icon,
    SnDialog,
    Carousel,
    TrackSelect,
    BatchExport,
    MapDevice,
    Sort,
    currentCompare
  },
})
export default class RecordDetail extends Vue {
  @Prop({default:false}) display!:boolean;
  @Prop({default(){return {}}}) data!:object;
  @Prop({default(){return []}}) captureList!:any[];
  // @Prop({default:0}) totalCapture!:number;

  dialogTrigerNumber=0;
  timer:any = null;
  isAutoPlay=false;
  showImg=true;
  currentBigImgIndex:any=null;
  isFullScreen:boolean=false;
  // data:any;
  // triggerEle:any;
  convertCardType=convertCardType;
  toPercentage=toPercentage;
  // captureList:any;
  currentCapture:any={};
  showTrackDialog=false;
  processImgurl=processImgurl;
  dressUpper =dressUpper;
  getSortAttributeInfoVos = getSortAttributeInfoVos;
  getAttrvalueMore=getAttrvalueMore;
  // devicePlaceInfo=[{
  //   name:"5楼电梯",
  //   id:"1",
  //   floorId:216,
  //   position:{
  //     lng:this.$_.random(500,800),
  //     lat:400,
  //   }
  // }];
  username:string=Cache.sessionGet('userInfo').username || '';
  refs !:{
    cvs:HTMLFormElement
  }

  bgcStyle= {
      background :''
  }

  get language() {
    return AppModule.language;
  }


  i18nCompareType(val) {
      let compareType = ""
     switch(val){
       case "0":
       compareType = 'pedestrian.unknown';
       this.bgcStyle.background = '#FF9800'
       break;
       case "1":
       compareType="pedestrian.pedestrianRecord"; //$t('pedestrian.search')
       this.bgcStyle.background = '#1989fa'
       break;
       case "2":
       compareType="pedestrian.vehicleRecord";
       this.bgcStyle.background = '#1989fa'
       break;
       case "3":
      //  compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
      //  compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
      //  compareType="records.listNotifyTypeBlacklist";
       break;
       case "10":
       compareType="pedestrian.pedestrianCrossingWarning";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "11":
       compareType="pedestrian.pedestriansInvasion";
       this.bgcStyle.background = '#ED3A33'
       break;
       case "20":
       compareType="pedestrian.parkedVehicles";
       this.bgcStyle.background = '#ED3A33'
       break;
     }
     return compareType

  }

  getAttrvalue(param:[]) {
      let str = ''
      param.forEach((item:any,index)=>{
        // str +=  param.length-1 == index ? item: item+';'
        if(item != 'ST_BAG' && item != 'ST_RESPIRATOR')
        str += this.$t('pedestrian.' +item.toLowerCase()) + '/'
      })
      str = str.substring(0, str.length - 1) ;
      // console.log(str);
      // return this.changeGenduo(str)
      return str
  }

  mounted(){

    // console.log('---------------1-0',this.currentCapture);

  }

  // @Watch('triggerEle')
  // viewStateChanged(val: string, oldVal?: string) {
  // }
  @Watch("data", { immediate: true })
  collapseDetailChange(val,oldVal){
    this.currentCapture=val
    this.currentBigImgIndex=null;
  }
  @Watch("currentCapture", { immediate: true,deep:true })
  currentCaptureChange(val,oldVal){
    // console.log(val);
    if(val.bigPicture){
      this.drawImageFace(val.bigPicture, val.event)
    }
  }

  @Emit("sort")
  handleSort(param){
    return param
  }

  @Emit("collapse")
    collapseDetail(){ //详情
    // this.currentCapture={};
  }


    drawImageFace(pic,event){
      let img = new Image;
      img.src = processImgurl(pic.imgUrl);
      let attr = pic.portraitImageCoordinateInfo;
      Vue.nextTick(()=>{
        // let canvas:any = document.getElementById("cvs");
        let canvas:any = this.$refs.cvs;//fix bug
        let that = this;
        img.onload=function(){
          if(canvas){
            canvas.width = img.width;
            canvas.height = img.height;
            let ctx = canvas.getContext("2d");
            (ctx as any).drawImage(img, 0,0,img.width,img.height)
            ctx.strokeStyle = "#F00";
            ctx.setLineDash([4, 4]);
            ctx.lineWidth = 5;
            ctx.strokeRect(attr.startX, attr.startY, attr.endX-attr.startX, attr.endY-attr.startY);
            // console.log('-------------------',pic,event);

            if(event){

                let vertices = event.rule.roi.vertices
                if(vertices && vertices.length == 2){
                  ctx.beginPath()
                  vertices.forEach((e) => {
                    ctx.lineTo(e.x, e.y )
                  });
                  ctx.strokeStyle = 'RGB(255,0, 0)'
                  ctx.setLineDash([]) // 画实线
                  ctx.stroke()
                  ctx.closePath()
                }
                if(vertices && vertices.length > 2) {
                  ctx.beginPath()
                  vertices.forEach((e,index) => {
                    ctx.lineTo(e.x , e.y )
                    if(index== vertices.length-1){ //最后一个回到初始点位
                      ctx.lineTo(vertices[0].x , vertices[0].y)
                    }
                  });
                  ctx.strokeStyle = 'RGB(255, 0, 0)' //填充颜色
                  ctx.setLineDash([2,2]) //画虚线
                  ctx.fillStyle = 'RGBA(255, 0, 0, .5)' //线颜色
                  ctx.fill()
                  ctx.stroke()
                  ctx.closePath()
                }
            }
          }
        }
      })

    }

    convertOperateType(val){
      switch(val){
       case 0:
       return ""
       case 1:
       return "records.lsitOperationTypeRead";
       case 2:
       return "records.lsitOperationTypeMatched";
       case 3:
       return "records.lsitOperationTypeUnmatched";
     }
    }
    CompareTypeconvert(val){
      let compareType = ""
     switch(val){
       case "0":
       compareType="records.listNotifyTypeNormal"
       break;
       case "1":
       compareType="records.listNotifyTypeStranger";
       break;
       case "2":
       compareType="records.listNotifyTypeFaceSpoof";
       break;
       case "3":
       compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
       compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
       compareType="records.listNotifyTypeBlacklist";
       break;
     }
     return compareType
    }
    handlePause(){
      this.stopTimer()
    }
     handleAutoPlay(){
      this.isAutoPlay=true;
      this.timer = setInterval(()=>{
        this.viewNextImage()
      },1000)
    }
    //停止定时器
    stopTimer(){
      this.isAutoPlay=false;
      this.timer && window.clearInterval(this.timer)
    }
    //查看前一张大图
    viewPreviousImage(){
       if(this.currentBigImgIndex==null){
        this.currentBigImgIndex=0
      }else if(this.currentBigImgIndex>0){
        this.currentBigImgIndex--
      }
      this.currentCapture = this.captureList[this.currentBigImgIndex]?this.captureList[this.currentBigImgIndex]:this.currentCapture
    }
    //查看后一张大图
    viewNextImage(){
      if(this.currentBigImgIndex==null){
        this.currentBigImgIndex=0
      }else if(this.currentBigImgIndex<this.captureList.length-1){
        this.currentBigImgIndex++
      }
      this.currentCapture = this.captureList[this.currentBigImgIndex] ?this.captureList[this.currentBigImgIndex]:this.currentCapture
    }
    cancelFullscreen(){
      this.stopTimer()
      this.isFullScreen=false
    }
    handleFullscreen(){
      this.stopTimer()
      this.isFullScreen=true
    }
    downloadBigImage(obj){
      this.imgToBase64(processImgurl(obj.bigPicture.imgUrl)).then((base64)=>{
        let ele = document.createElement("a")
        let t= dayjs().format('YYYYMMDD_HHmmss')
        ele.setAttribute('download', 'Capture_Image_Big_'+t)
        ele.href  = base64 as string
        ele.click()
      })
    }

  imgToBase64(url){
   return  new Promise((resolve,reject)=>{
      let img = new Image;
      img.crossOrigin="Anonymous";
      img.src = url;
      let reg = /^data:image/
      let canvas = document.createElement("canvas");
      if(!reg.test(url)){
        let that = this;
        img.onload=function(){
          canvas.width = img.width;
          canvas.height = img.height;
          let ctx = canvas.getContext("2d");
          (ctx as any).drawImage(img, 0,0,img.width,img.height)
          resolve(canvas.toDataURL("image/jpeg"))
        }
      }else{
        resolve(url)
      }
    })

  }
  afterEnter(){
      // scrollTo(this.triggerEle.path[7], {top:this.triggerEle.path[5].offsetTop}).then(function() {
      // });
  }
  showExportDialog(){
    this.dialogTrigerNumber = Math.random()
  }
  doExportRecord(start,end){
    this.$emit("export",start,end)
  }
  viewCaptureMore(val){
    this.$emit("slide",val)
  }
  //点击图片查看详情
  viewCaptureDetail(data,key){
    this.currentBigImgIndex=key
    this.currentCapture=data;
  }
  //显示轨迹生成弹框
  generateTrack(){
    this.showTrackDialog=true;
  }
  //关闭轨迹生成弹窗
  cancelTrackDialog(){
    this.showTrackDialog=false;
  }
  showTrackMap(){

  }



  changeGenduo(item) {
    // if()
    let that = this as any
    let attrs = item
    let str = ''
    if(attrs.indexOf(';') != -1) {
      let arrAttrs  = attrs.split(';')
      arrAttrs.forEach(ele => {
        // console.log(ele);
          str += that.$t('pedestrian.' +ele.toLowerCase()) + '/'
          // console.log(str ,item.toLowerCase());
      })
      str = str.substring(0, str.length - 1) ;
    }else {
        str = that.$t('pedestrian.' +item.toLowerCase())

    }
    // let a = that.dressUpper(item.attributeInfo , 'style').toLowerCase()
    return str
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
@media screen and (max-width: 1366px){
  .record-detail {
    .detail-container {
      .detail_xq {
        .pt-state-bt {
            .pt-state-r{
              margin-top: 15px !important;
            }
          }
      }
    }
  }
}

  .fadeIn{
    opacity: 1;
    transition: all 1s;
  }
  .fadeOut{
    opacity: 0;
    transition: all 1s;
  }
  .hidden{
    height: 0 !important;
    opacity: 0;
    transition: all  .3s;
    overflow: hidden;
  }
  .show{
    height: 600px !important;
    opacity: 1;
    transition: all .3s;
    overflow: hidden;
  }
  .record-detail{
    margin-top: 12px;
    height: 590px;
    width: 99%;
    margin-left:4px;
    // overflow: scroll;
    // background: #495d83;
    background: rgba(242,246,253,1);
    // background: pink;
    padding: 0 160px ;
    // color: $--color-white;
    position: relative;
    padding-top:10px;
    box-sizing: border-box;
    border:1px solid rgba(223,223,224,1);
    // box-shadow:0px 3px 6px rgba(0,0,0,0.16);
    .can-click{
      cursor: pointer;
    };
    .close-tab{
      position: absolute;
      right: 10px;
      top:10px;
      height:20px;
    }
    .detail-container{
      display: flex;
      height:100%;

      .detail_xq {
        display: inline-block;
        width:408px;
        height:528px;
        background-color: #fff;
        border-radius:4px 0px 0px 4px;
        .pt-state {
          width: 100%;
          height: 32px;
          border-radius:4px 0px 0px 0px;
          text-align: center;
          line-height: 32px;
          color: #fff;
        }
        .el-image {
          width:227.9px;
          height:320px;
          // border:1px solid rgba(112,112,112,1);
          position: relative;
          left: 50%;
          transform: translateX(-50%);
          margin-top: 20px;
          // background-color: #011C50;
          border: 1px dashed #CDE1FD;
          background-color: #DFEAFC;
        }

        .pt-state-bt{
          display: flex;
          .pt-state-l {
            display: flex;
            flex: 1;
            ul {
              margin-top: 15px;
              margin-left: 55px;
              li{
                display: flex;
                line-height: 24px;
                text-align: center;
                margin-bottom: 8px;

                &.isEn {
                  div {
                    width: 90px;
                  }
                }
                div {
                  width: 64px;
                  height: 24px;
                  // background-color: pink;
                  margin-left: 15px;
                  // border: 1px solid #DFDFE0;
                  border-radius: 4px;
                }
              }
            }
            .nullAttributes {
              div {
                border: 1px solid #DFDFE0;
              }
            }
          }
          .pt-state-r {
            margin-top: 20px;
            flex: 1;
            div {
              display: flex;
              // line-height:
              font-weight: 700;
              margin-bottom: 10px;
              width: 100%;
              padding-right: 5px;
              b {
                min-width: 35px;
              }
              span {
                margin-left: 8px;
                font-weight: 400;
                max-width: 180px;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 1;
                word-wrap: break-word;

                // p {
                //   cursor: pointer;
                // }

              }
              i {
                font-weight: 400;
              }
              &:last-child span{
                  margin-left: 0px;;
              }

            }
          }
        }
      }
      .current-compare{
        //  height:100%;
         width: 14%;
         padding:20px 25px 0px;
         overflow: scroll;
        .two-Image{
          width: 400px;
          height: 240px;
          margin: 0 auto;
        }
        .current-compare-detail{
          width: 400px;
          margin: 0 auto;
          padding:10px 0;
          .detail-item{
            margin: 10px 5px;
            display: flex;
            p{
              display: flex;
              width:50%;
              word-wrap:break-word;
              b{
                word-wrap:break-word;
                padding: 3px;
                white-space:nowrap;
                font-weight: 600;
              }
              span{
                word-wrap:break-word;
                padding: 3px;
                display: block;
                width:80%;
                i{
                  font-style:normal;
                }

              }

            }
          }
        }
        .current-compare-detail-other{
          width: 400px;
          height:100px;
          margin: 0 auto;
          padding:10px 0;
          border-top: 2px solid #55678a;
          .detail-item{
            margin: 10px 5px;
            b{
              word-wrap:break-word;
              padding: 3px;
              white-space:nowrap;
              font-weight: 600;
            }
        }
        }
      }
     .detail-list{
        width: 73%;
        height: 528px;
        padding: 0 20px;
        box-sizing: border-box;
        .record-detail-top{
          display: flex;
          justify-content: space-between;
          margin: 5px;
          .record-detail-title{
            .title-main{
              font-size: $--font-size-card;
              // color: #fff;
            }
            span{
              padding-right: 10px;
              // color: #fff;
            }
          }
          .batch-export{
            margin-right: 50px;
            span{
              padding-left: 5px;
              padding-right:10px
            }

          }
        }
        .capture-list{
         min-height: 29%;
         margin: 10px 30px;
         background: rgba($menuBg,.2);
         .empty-notice{
           text-align: center;
           line-height: 150px;
         }
       }
      .capture-detail{
        display: flex;
        height:100%;
        .capture-big-img{
          // background-color: #000;
          // color: #fff;
          // padding: 10px;
          width: 50%;
          height: 100%;
          box-sizing: border-box;
          overflow: hidden;
          .capture-big-img-top{
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            height: 32px;
            background-color: #011C50;
            line-height: 32px;
            color: #fff;
            padding: 0 10px;
          }
          .big-img-container{
            height: 92%;
            width:100%;
            position: relative;
            text-align: center;
            background: #28354D;

            img {
              height: 100%;
              max-width: 100%;
            }
            .big-img-container-btn{
              position: absolute;
              bottom: 10px;
              left: 10px;
            }
            .big-img-fullscreen{
              position: fixed;
              top: 0;
              bottom: 0;
              right: 0;
              left: 0;
              z-index: 10000;
              background: #000;
              padding: 150px;
              text-align: center;
              .previous-page{
                position: absolute;
                display: inline-block;
                height: 100px;
                width: 100px;
                top: 40%;
                left: 10px;
              }
              .next-page{
                position: absolute;
                display: inline-block;
                height: 100px;
                width: 100px;
                top: 40%;
                right: 10px;

              }
              .auto-play{
                position: absolute;
                display: inline-block;
                height: 50px;
                width: 50px;
                bottom: 50px;
                right: 50%;
              }
            }
          }
        }
        .path-track{
          margin-left: 10px;
          width: 50%;
          height: 100%;
          // padding: 10px;
          box-sizing: border-box;
          border-radius: 0 4px 4px 0;
          overflow: hidden;
          .path-track-top{
            // display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            height: 32px;
            background-color: #011C50;
            line-height: 32px;
            color: #fff;
            padding: 0 10px;
          }
          .path-track-container{
            height: 92%;
            background: rgba($menuBg,.2);
            .empty-notice{
              text-align: center;
              line-height: 280px;
            }
          }
        }
      }
     }
    }
  }

  .textCompare{
    position: absolute;
    /* display: flex; */
    left: 9%;
    top: 20px;
    font-size: 16px;
    color: #fff;
  }

  ::v-deep .device-wrapper {
    padding: 0;
  }

  .purple {
    background-color: #673AB7;
    color: #fff;
  }
  .red {
    background-color: #ED3A33;
    color: #fff;
  }
  .brown {
    background-color: #795548;
    color: #fff;
  }
  .yellow {
    background-color: #FF9800;
    color: #fff;
  }
  .green {
    background-color: #8BC34A;
    color: #fff;
  }
  .blue {
    background-color: #1989FA;
    color: #fff;
  }
  .pink {
    background-color: #FFCDD2;
    color: #000;
  }
  .white {
    background-color: #FFFFFF;
    color: #000;
    border: 1px solid #DFDFE0;
  }
  .gray {
    background-color: #DFDFE0;
    color: #000;
  }
  .black {
    background-color: #2B2B2B;
    color: #fff;
  }

  ul {
    li p{
      display: flex;
      margin-bottom: 5px;
      span {
        // display: inline-block;
        width: 50%;
        // line-height: 25px;
        &:first-child {
          width: 40%;
          font-weight: 700;
          text-align: right;
        }
        &:last-child {
          margin-left: 10px;

        }
      }
    }
  }

</style>
