<template>
  <div class="retrival-container" @mouseenter="doMouseenter" @drop="dragDrop" @dragenter="dragenter" @dragend="dragend">

        <div class="filter-condition">
            <!-- <span class="title">
              <Icon
                name="record"
                size="18"
              />
              {{$t("records.contRecord")}}
            </span> -->
          <el-popover
            @show="showCondition"
            @hide="hideCondition"
            trigger="click"
            placement="bottom"
            style="width:100%;"
            popper-class="popover-reset"
            v-model="isPoVisible"
            >
            <span :class="{conditionBoxVisible}"  slot="reference" class="condition-title">
              <!-- {{$t("records.contFilter")}} -->
              {{$t('messageCenter.filter')}}
              <i class="el-icon-caret-bottom"></i>
            </span>
            <div class="condition-box">
              <div class="condition-detail">
                <div class="condition-detail-group">
                  <div class="condition-detail-item">
                    <span class="label">{{$t("records.contTime")}}</span>
                    <el-date-picker
                      class="input-field"
                      size="small"
                      v-model="timeRange"
                      @change="handleDateChange"
                      type="datetimerange"
                      range-separator="-"
                      :start-placeholder="$t('log.textboxTimeSet')"
                      :end-placeholder="$t('log.textboxTimeSet')">
                    </el-date-picker>
                  </div>
                  <div class="condition-detail-group-child">
                    <div class="condition-detail-item">
                      <div class="label"> {{$t("records.contThreshold")}}</div>
                      <div style="width:133px">
                        <el-select v-model="searchCondition.similarity" placeholder="请选择">
                          <el-option
                            v-for="item in thresholds"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                          </el-option>
                        </el-select>
                      </div>
                    </div>
                    <div class="condition-detail-item">
                      <!-- <div class="label"> {{$t("records.contNotifyType")}} </div>
                      <div class="input-field">
                        <el-select
                          multiple
                          collapse-tags
                          size="mini"
                          v-model="searchCondition.compareTypes"
                          :placeholder="$t('records.contPleaseSelect')">
                          <el-option
                            v-for="item in compareTypes"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                          </el-option>
                        </el-select>
                      </div> -->
                      <tree-input
                      class="tree-input"
                      @checkout="checkoutCompareTypes"
                      :data="compareTypes"
                      label="name"
                      :name="$t('records.contNotifyType')"
                      ref="compareType_tree"
                    />
                    </div>
                  </div>
                </div>



                <div class="condition-detail-group">
                  <div class="condition-detail-item">
                     <tree-input
                      class="tree-input"
                      @dropDown="fetchDevice"
                      @checkout="checkoutDevice"
                      :data="deviceList"
                      label="name"
                      :name="$t('records.contDevice')"
                      ref="device_tree"
                    />
                  </div>

                  <div class="condition-detail-item">
                      <tree-input
                      class="tree-input"
                      @dropDown="fetchLocation"
                      @checkout="checkoutLocation"
                      :data="locationList"
                      label="name"
                      :name="$t('records.contLocation')"
                      ref="location_tree"
                    />
                  </div>

                </div>


                <div class="condition-detail-group">
                  <div class="condition-detail-item">
                    <tree-input
                      class="tree-input"
                      @dropDown="fetchWatchList"
                      @checkout="checkoutWatchList"
                      :data="watchList"
                      label="libraryName"
                      :name="$t('records.contImageLibrary')"
                      ref="watchlist_tree"
                      nodeKey="libraryId"
                    />
                  </div>

                  <div class="condition-detail-item">
                    <tree-input
                      class="tree-input"
                      @dropDown="getRuleName"
                      @checkout="checkoutRuleNameTypes"
                      :data="monitorRules"
                      label="name"
                      nodeKey="id"
                      :name="$t('pedestrian.mission')"
                      ref="ruleName_tree"
                    />
                  </div>
                </div>


               <div class="condition-detail-group">
                 <div class="condition-detail-item">
                   <tree-input
                      class="tree-input"
                      @checkout="checkoutOperateStatus"
                      :data="matchTypes"
                      label="name"
                      :name="$t('records.contOperationType')"
                      ref="operateStatus"
                    />
                    <!-- <div> {{$t("records.contOperationType")}} </div>
                    <el-select
                      multiple
                      collapse-tags
                      size="mini"
                      v-model="searchCondition.operateStatus"
                      :placeholder="$t('records.contPleaseSelect')">
                      <el-option
                        v-for="item in matchTypes"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select> -->
                  </div>
                  <div class="condition-detail-item">
                    <tree-input
                      class="tree-input"
                      @dropDown="fetchDept"
                      @checkout="checkoutDept"
                      :data="deptList"
                      label="name"
                      :name="$t('records.contOperatorDep')"
                      ref="dept_tree"
                    />
                  </div>
               </div>

                <div class="condition-detail-group">
                    <div class="condition-detail-item">
                      <tree-input
                        class="tree-input"
                        @checkout="checkoutMask"
                        :data="haveMask"
                        label="name"
                        :name="$t('records.faceProperty')"
                        ref="mask_tree"
                      />
                    </div>
                </div>
              </div>
              <div class="operate">
                <div>
                  <el-button
                  size="mini"
                  type="primary"
                  icon="el-icon-refresh"
                  @click="resetCondition"
                  >
                  {{$t("records.contReset")}}
                  </el-button>
                </div>
                <div>
                  <el-button
                  icon="el-icon-search"
                  size="mini"
                  type="primary"
                  @click="doSearch"
                  >
                    {{$t("records.contSearch")}}
                  </el-button>
                </div>
              </div>
            </div>
          </el-popover>
          <el-button
            v-if="$permission('015301') && currentPage==='record'"

            type="primary"
            size="small"
            class="batch-export"
            @click="showExportDialog"
          >
           <i class="iconfont icon-upload"></i>
          {{$t("records.buttonExport")}}
          </el-button>
        </div>
      <div :class="{hiddenHeader:!headerVisible}" class="retrival-header">
        <div v-if="dragBoxVisible" class="drag-box">
          <textarea >
          </textarea>
          <div class="drag-icon">
            <Icon
              class="icon"
              type="ele"
              name="circle-plus-outline"
            />
            <p>{{this.$t("records.dragNotice")}}</p>
          </div>
        </div>
        <div v-if="!dragBoxVisible" class="search-box" >
          <el-input
            ref="searchInput"
            :placeholder="showSearchImage? '' :$t('records.textboxEnterKeywordT')"
            :value="keyWord"
            @input="inputKeyWord"
            @keyup.native.enter="doSearch"
            :maxlength='128'
          >
          <template v-if="showSearchImage" slot="prepend">
            <div class="prepend-img">
            <img :src="imageUrl" alt="">
            <Icon
              class="close-tab"
              name="error"
              type="ele"
              size="20"
              cursor="pointer"
              @click="cancelImageSearch"
            />
            </div>
          </template>
          <span class="suffix-icon" slot="suffix">
            <Icon
              v-if="keyWord"
              type="ele"
              size="15"
              cursor="pointer"
              name="circle-close"
              @click="clearKeyword"
            />
          <el-upload
            ref="imgUpload"
            class="choose-image"
            :on-change="handleImageChange"
            action="/"
            :show-file-list="false"
            :auto-upload="false"
            >
            <Icon
              type="icon"
              name="PictureSearch"
              size="16"
              cursor="pointer"
            />
          </el-upload>
            <Icon
              name="separator"
            />
            <Icon
              type="icon"
              size="16"
              cursor="pointer"
              name="search1"
              @click="doSearch"
            />
          </span>
          </el-input>
          <div style="position: absolute;top: 8px;right: -20px;color:#2a5af5">
            <el-popover
              placement="bottom-start"

              trigger="hover"
              >
                <div class="keyword-suggest" v-html="$t('records.hovmsgKeywordPolicy')"></div>
              <i slot="reference" style="margin-left: 5px;" class="el-icon-question"></i>
            </el-popover>
          </div>
        </div>

      </div>
      <div @scroll="handleScroll" class="retrival-body">
        <history-record
          v-if="currentPage==='record'"
          :data="historyRecordData"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
          :pageNumber="pageNumber"
          :pageSize="pageSize"
          v-loading="isLoadRecord"
          :class="{isHeighten}"
        />
        <image-retrival
          v-else-if="currentPage==='retrival'"
          :currentTab="retrivalTab"
          :isLoad="isLoadRetrival"
          :captureLibList="retrivalCaptureList"
          :facialLibList="retrivalFacialList"
          @changetab="changeDisplayLib"
          @sort="handleCaptureSort"
          :imgUrl='imgUrl'
        />
      </div>
      <batch-export
        :series="dialogTrigerNumber"
        @export="doExportRecord"
        :maxNum="this.historyRecordData?this.historyRecordData.totalNumber:0"
      />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import  Icon from '@/components/icon-wrap/index.vue';
import  HistoryRecord from '../history-record/index.vue';
import  ImageRetrival from '../img-retrival/index.vue';
import request from '@/api/history-record';
import {mapState, mapMutations } from 'vuex'
import { historyStore, searchCondition } from '@/store/modules/history-record';
import historyApi from '@/api/history-record';
import TreeInput from '@/components/tree-input/index.vue';
import BatchExport from '../component/batch-export.vue';
import { Cache } from '@/utils/cache';
import  { messageCenter } from '@/store/modules/message-center';
var _ = require('lodash/lang');
import {EventBus} from '@/utils/eventbus';
import log from '../../../api/log';

interface retrivalResItem {
  capturedTime: string,
  confirmStatus: number,
  deviceName: string,
  panoramicImage: string,
  portraitImage: string,
  score: number,
  total: number,
}

interface retrivalResList {
  code: string,
  data: retrivalResItem[],
  message: string,
  path: string,
  status: number,
}


interface monitorRule {
  taskGroupId: number
  taskGroupName: string
}


//查询条件
@Component({
  components: {
    Icon,
    HistoryRecord,
    ImageRetrival,
    TreeInput,
    BatchExport
  },
  name:"retrival",
})
export default class Retrival extends Vue {
  conditionBoxVisible=false;//设置条件框是否显示
  isDefaultDate=true; //是否为默认时间
  dialogTrigerNumber=0;
  trivalBody:any=null
  dragBoxVisible=false;//拖拽框是否显示
  headerVisible=true;//滑动 头部是否显示
  isLoadRetrival=true;
  isLoadRecord=true;
  // exportDialogVisible=false;
  keyWord="";
  keyWordOK="";
  scrollTop = 0;
  scrollTopRef = 0;
  searchCondition:searchCondition={
    deviceIds:[],
    captureTimeEnd:"",
    captureTimeStart:"",
    compareTypes:[],
    enabledSimilaritySoft: "",
    enabledTimeSoft: "",
    faceDatabases: [],
    floorIds: [],
    imageFaceBase64: "",
    operateStatus: [],
    operaterDeptIds: [],
    taskIds: [],
    similarity: "0",
    respiratorColors:[],
    wearStatus:["1", "1", "1", "1"]
  };
  retrivalCaptureList=[];
  retrivalFacialList=[];
  showSearchImage=false;
  imageUrl="";
  currentPage="record";//retrival
  retrivalTab:string="captureLib";//facialLib
  timeRange:any=null;
  location=[];
  condition:any={};
  historyRecordData={};
  pageNumber=1;
  pageSize=15;
  deviceList=[]; //设备
  watchList:any=[];//黑白名单人像库
  deptList=[];//部门
  locationList=[]//相机位置
  monitorRules:monitorRule[]=[];
   thresholds=[//相识度
    {value:"0",label:"0%"},
    {value:"0.2",label:"20%"},
    {value:"0.4",label:"40%"},
    {value:"0.6",label:"60%"},
    {value:"0.65",label:"65%"},
    {value:"0.7",label:"70%"},
    {value:"0.75",label:"75%"},
    {value:"0.80",label:"80%"},
    {value:"0.85",label:"85%"},
    {value:"0.90",label:"90%"},
    {value:"0.95",label:"95%"},
    {value:"1",label:"100%"},
  ];
  isHeighten = false ;
  isPoVisible = false;
  get haveMask () {
    return [
      {id:"0",name:this.$t("records.noMask")},
      {id:"1",name:this.$t("records.ownMask")},
      {id:"2",name:this.$t("records.noHelmet")},
      {id:"3",name:this.$t("records.ownHelmet")},
    ]
  }
  imgUrl = ''

  @Watch('dragBoxVisible')
  onchangeDragBoxVisible(val:any) {
    if(val) {
      this.isPoVisible = false
    }
  }

  get compareTypes(){
    // return [
    //   {value:"0",label:this.$t("records.listNotifyTypeNormal")},
    //   {value:"1",label:this.$t("records.listNotifyTypeStranger")},
    //   {value:"2",label:this.$t("records.listNotifyTypeFaceSpoof")},
    //   {value:"3",label:this.$t("records.listNotifyTypePassAttack")},
    //   {value:"4",label:this.$t("records.listNotifyTypeAbnormal")},
    //   {value:"9",label:this.$t("records.listNotifyTypeBlacklist")},
    // ];
    return [
      {id:"0",name:this.$t("records.listNotifyTypeNormal")},
      {id:"1",name:this.$t("records.listNotifyTypeStranger")},
      {id:"2",name:this.$t("records.listNotifyTypeFaceSpoof")},
      {id:"3",name:this.$t("records.listNotifyTypePassAttack")},
      {id:"4",name:this.$t("records.listNotifyTypeAbnormal")},
      {id:"9",name:this.$t("records.listNotifyTypeBlacklist")},
    ];
  }
  get matchTypes(){
    return [
      {id:"0",name:this.$t("records.lsitOperationTypeUnread")},
      {id:"1",name:this.$t("records.contRead")},
      {id:"2",name:this.$t("records.contMatched")},
      {id:"3",name:this.$t("records.contUnmatched")},
    ];
  }
  mounted (){
    this.initData()
    this.fetchHistoryRecord();
    EventBus.$emit('retrivalVanName','face');
  }
  //清除关键字
  clearKeyword(){
    this.keyWord=""
    this.keyWordOK="";
    this.doSearch()
  }
  showCondition(){
    this.conditionBoxVisible=true
    this.isHeighten = true
  }
  hideCondition(){
    this.conditionBoxVisible=false
    this.isHeighten = false
  }
  //用户选择时间
  handleDateChange(){
    this.isDefaultDate = false; //用户自定义时间
  }
  doMouseenter(){
    this.dragBoxVisible = false;
  }
  showHeader(){
    this.headerVisible=true
    this.trivalBody?this.trivalBody.target.style.height="90%":"";
  }
   handleScroll(e){
     let that = this;
     this.trivalBody = e
    if(this.scrollTopRef+10<=e.target.scrollTop && e.target.scrollTop>150){
        e.target.style.height="92%"
        if(!this.conditionBoxVisible){ //如果弹出框显示，不隐藏头部
          this.headerVisible=false
        }
        if(this.headerVisible) {
          e.target.style.height="95%"
        }


    }else if(this.scrollTopRef-10>e.target.scrollTop){
        this.showHeader()
    }

    setTimeout(function(){that.scrollTopRef=e.target.scrollTop},0);
  }
  //显示导出弹框
  showExportDialog(){
    this.dialogTrigerNumber = Math.random()
  }
  //导出
  doExportRecord(start,end){
    var condition = _.cloneDeep(historyStore.condition);
      // condition.accessToken = Cache.sessionGet("accessToken")
      condition.userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";
      // condition.websocketId=condition.accessToken
      condition.from=start
      condition.to=end
      condition.keyWord= this.keyWordOK
      let param={
        // subAds:'/topic/records/subscribe/'+condition.accessToken,
        sendAds:"/app/records/export",
        data:condition
      }
      //导出 websocket(TBD)
      // messageCenter.exportHistoryRecord(param)
      request.exportHistoryRecord(condition).then(()=>{
        this.$message({
          showClose: true,
          message: this.$t("log.exportSuccess") as string,
          type: 'success',
          duration: 3 * 1000,
       });
      })
    // this.exportDialogVisible = false
  }
  // //取消导出
  // cancelExportRecord(){
  //   this.exportDialogVisible = false
  // }

  inputKeyWord(val){
    this.keyWord=val
  }
  //初始化时间
  initData(){
    this.isDefaultDate = true;
    //默认时间 暂时不要删除
    // var end = new Date();
    // var time = end.getTime();
    // time-=7*24*3600*1000;
    // var start = new Date(time);
    // Vue.set(this.timeRange,0,start);
    // Vue.set(this.timeRange,1,end);
    this.timeRange = null
  }
   //重置搜索条件
  resetCondition(){
    this.initData()//初始化时间
    historyStore.reset_condition();//初始化检索条件
    this.searchCondition = historyStore.condition;
    (this.$refs.dept_tree as any).clearCheckout();
    (this.$refs.device_tree as any).clearCheckout();
    (this.$refs.location_tree as any).clearCheckout();
    (this.$refs.watchlist_tree as any).clearCheckout();
    (this.$refs.compareType_tree as any).clearCheckout();
    (this.$refs.ruleName_tree as any).clearCheckout();
    (this.$refs.operateStatus as any).clearCheckout();
    (this.$refs.mask_tree as any).clearCheckout();
    EventBus.$emit('clearAll' , false) //重置全选
  }
  //获取规则组列表
  getRuleName(state){
   if(this.monitorRules.length==0){
     let param = {taskTypes:[0,1]}
     historyApi.getQueryTasksByType(param).then((data)=>{
      this.monitorRules=(data as any).taskNameVOList
    })
   }
  }

  //获取部门列表
  fetchDept(val){
    if(!this.deptList.length){
      historyApi.fetchDepartment().then((data)=>{
        this.deptList = data.data
      })
    }
  }
   //筛选操作状态
  checkoutOperateStatus(ids){
    this.searchCondition.operateStatus=ids
  }
   //筛选记录操作人部门
  checkoutDept(ids){
    this.searchCondition.operaterDeptIds=ids
  }
  //获取设备列表
  fetchDevice(val){
    if(!this.deviceList.length){
      historyApi.fetchDevice().then((data)=>{
        this.deviceList = data.data
      })
    }
  }
  //获取位置列表
  fetchLocation(val){
    if(!this.locationList.length){
      historyApi.fetchLocation().then((data)=>{
        this.locationList = data.data
      })
    }
  }

    //选取比对类型
  checkoutRuleNameTypes(ids){
    console.log(ids);

    this.searchCondition.taskIds = ids
  }
    //选取比对类型
  checkoutCompareTypes(ids){
    this.searchCondition.compareTypes = ids
  }
   //选取设备
  checkoutDevice(ids){
    this.searchCondition.deviceIds=ids
  }
   //选取设备
  checkoutLocation(ids){
    this.searchCondition.floorIds=ids
  }
  //选取人像库
  checkoutWatchList(ids){
    this.searchCondition.faceDatabases=ids
  }
  //获取黑白名单人像库
  fetchWatchList(state){
      //state为true 展开，false 收缩
      if(this.watchList.length==0){
        historyApi.fetchLibrary().then((data)=>{
          let obj1={
            libraryName:this.$t("rule.contWhitelist"),
            libraryId:"g_1",
            children:(data as any).whitelists
          };
          let obj2={
            libraryName:this.$t("rule.contBlacklist"),
            libraryId:"g_2",
            children:(data as any).blacklists
          };
          this.$set(this.watchList,0,obj1)
          this.$set(this.watchList,1,obj2)
        })
      }
  }
  // 口罩筛选
  checkoutMask(ids) {
    // console.log(ids);
    let arr = ['0','0','0','0'];
    ids.map(item=>{
      arr[item] = '1'
    })
    this.searchCondition.wearStatus = arr
  }
  //验证图片类型
  verifyImgType(type){
    let reg = /^image\/(jpeg)|(png)|(bmp)$/
    if(!reg.test(type)){
      this.$message({
        showClose: true,
        message:this.$t("tools.errmsgImageType") as any,
        type: 'error',
        duration: 3 * 1000,
      });
      return false;
    }else{
      return true;
    }
  }
  //验证图片大小
  verifyImgSize(size){
    let targetSize = 16*1024*1024
    if(size>targetSize){
      this.$message({
        showClose: true,
        message:this.$t("tools.errmsgImageSize") as any,
        type: 'error',
        duration: 3 * 1000,
      });
      return false;
    }else{
      return true;
    }
  }
  //点击上传图片搜索
  handleImageChange(res,fileList){
    var file = new FileReader()
    // this.imageUrl = URL.createObjectURL(file[0].raw);
    file.readAsDataURL(res.raw)
    fileList.length=0
    if(this.verifyImgType(res.raw.type)&&this.verifyImgSize(res.raw.size)){
        file.onload=(e)=>{
        let imageUrl = (e.target as any).result
        this.imgToBase64(imageUrl).then((data)=>{
          this.imageUrl  = data as string
          this.retrivalImg()//开始以图搜图
        })
      }
    }
  }

  //取消以图搜图
  cancelImageSearch(file,fileList){
    (this.$refs.imgUpload as any).clearFiles()
    this.retrivalFacialList=[]; //检索人像库为空
    this.retrivalCaptureList=[];//检索抓拍库为空
    this.currentPage="record"   //当前页面置为检索记录
    this.retrivalTab="captureLib"　//当前以图搜图置为抓拍库　
    this.showSearchImage=false;  //搜索框图片消失
  }

  //拖拽上传图片搜索
  dragDrop(event){
      this.dragBoxVisible=false
      event.preventDefault();
      var fileList = event.dataTransfer.files;
      new Promise((resolve,reject)=>{
        if(fileList.length===0){ //拖拽web图片
          let img = event.dataTransfer.getData("text/html")
          var substr = img.match(/src="(\S*)"/);
          // this.imageUrl =substr[1]
          this.imgToBase64(substr[1]).then((base64)=>{
            resolve(base64)
          })
        }else{//拖拽本地资源
          var file = new FileReader()
          let fileReader = file.readAsDataURL(fileList[0])
          if(this.verifyImgType(fileList[0].type)&&this.verifyImgSize(fileList[0].size)){
            file.onload=(e)=>{
              let imageUrl = (e.target as any).result
              this.imgToBase64(imageUrl).then((data)=>{
                resolve(data)
              })
            }
          }
        }
      }).then((data)=>{
        (this.imageUrl as any)=data;
        this.retrivalImg()//开始以图搜图
      })
  }


dataURLtoBlob(dataurl) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
}
  //拖拽到目标区域
  dragenter(event){
    console.log(event)
    event.preventDefault();
    this.showHeader();
    this.dragBoxVisible=true
  }
  //拖动结束时候触发
  dragend(event){
      event.preventDefault();
    this.dragBoxVisible=false
  }
  //拖拽离目标区域
  dragleave(event){
  }

  //点击搜索
  doSearch(){
    this.keyWordOK = this.keyWord
    if(this.isDefaultDate){
      this.initData()
    }
    this.pageNumber=1;
    //如果是记录检索页面
    if(this.currentPage==="record"){
      this.fetchHistoryRecord()
    }else{//如果是以图搜图页面
    this.retrivalImg()
    }
  }

  //设置检索条件
   setSearchCondition(){
    this.searchCondition.captureTimeStart =this.timeRange? this.timeRange[0]:null;
    this.searchCondition.captureTimeEnd = this.timeRange? this.timeRange[1]:null;
    this.searchCondition.imageFaceBase64 = this.imageUrl;
    historyStore.set_condition(this.searchCondition)
  }
  //获取记录检索列表
  fetchHistoryRecord(){
    this.isLoadRecord=true;
    this.setSearchCondition()
    let condition = _.cloneDeep(historyStore.condition)
    condition.pageNumber = this.pageNumber
    condition.pageSize = this.pageSize
    condition.keyWord = this.keyWord
    request.fetchRecordList(condition).then((data)=>{
      this.historyRecordData = data.data
    },()=>{
      console.log("报错")
    }).finally(()=>{
      this.isLoadRecord = false
    });
  }
  //以图搜图
  async retrivalImg(param?){
    this.showSearchImage=true //搜索框显示图片
    this.currentPage="retrival"
    this.isLoadRetrival=true;
    this.keyWord=""//设置关键字为空
    this.setSearchCondition() //设置检索条件
    this.imgUrl = this.searchCondition.imageFaceBase64
    let condition = _.cloneDeep(historyStore.condition)

    if(this.retrivalTab==="facialLib"){ //搜索人像库
      //设置检索条件
      if(param){
        condition.similaritySort=param.similaritySort
      }else{
        condition.similaritySort=0;
      }
      try{
        var retrivalFacialList = await historyStore.searchFacialLib(condition)
        this.retrivalFacialList = retrivalFacialList.data || []
        this.isLoadRetrival=false;
      }catch(err){
        this.currentPage="record"
        this.showSearchImage=false
        throw err
      }
    }else{//搜索抓拍库
      //设置检索条件
      if(param){
        condition.similaritySort=param.similaritySort
        condition.timeSort=param.timeSort
      }else{
        condition.similaritySort=0;
        condition.timeSort=null;
      }
      try{
        let captureList = await historyStore.searchCaptureLib(condition);
        this.retrivalCaptureList = captureList.data || [];
        this.isLoadRetrival=false;
      }catch(err){
        this.showSearchImage=false
        this.currentPage="record"
        throw err
      }
    }
  }



  //切换查看抓拍库和人像库
  changeDisplayLib(lib){
    this.retrivalTab = lib
    this.retrivalImg()
  }

  //处理以图搜图抓拍库排序
  handleCaptureSort(data){
    this.retrivalImg(data)
  }
  pageChange(num){
    this.pageNumber=num
    this.fetchHistoryRecord()
  }
  pageSizeChange(num){
    this.pageSize = num
    this.fetchHistoryRecord()
  }

  //图片转化base64
  imgToBase64(url){
   return  new Promise((resolve,reject)=>{
      let img = new Image;
      img.crossOrigin="Anonymous";
      img.src = url;
      let reg = /^data:image/
      let canvas = document.createElement("canvas");
      // img.onload=function(){
      //   canvas.width = img.width;
      //   canvas.height = img.height;
      //   let ctx = canvas.getContext("2d");
      //   (ctx as any).drawImage(img, 0,0,img.width,img.height)
      //   resolve(canvas.toDataURL("image/jpeg"))
      // }
      if(!reg.test(url)){
        img.onload=function(){
          canvas.width = img.width;
          canvas.height = img.height;
          let ctx = canvas.getContext("2d");
          (ctx as any).drawImage(img, 0,0,img.width,img.height)
          resolve(canvas.toDataURL("image/jpeg"))
        }
      }else{
        resolve(url)
      }
    })

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";

   .keyword-suggest{
    //  display: flex;
    //  flex-wrap:wrap;
     :first-child{
        font-weight: 900;
     };
     :last-child{
        word-break:break-all;
     }
    }
  .retrival-container{
    // padding:12px;
    box-sizing: border-box;
    height:99%;
    width:100%;
    position: relative;

     .filter-condition{
       width: 50%;
       position: absolute;
       left: 50%;
      //  transform: translateX(-10%);
       top: -33px;
        .title{
          // font-weight: 200;
          font-size: 15px;
        }
        // position: relative;
        .condition-title{
          cursor: pointer;
          display: inline-block;
          // margin-left: 80px;
          height: 24px;
          width: 80px;
          text-align: center;
          line-height: 24px;
          outline:none;
          border: 1px solid;
          border-radius: 4px 4px 0 0 ;
          position: absolute;
          top: 10px;
          left: -40px;

          i {
            transform: rotate(0deg);
            transition: all .5s ;
          }
        };
        .conditionBoxVisible{
          color: $--color-primary;
          // transform-origin: center;
          i {
            transform: rotate(180deg);
          }
        }
        .batch-export{
          position: absolute;
          right: 25px;
          top: -6px;
        }

      }
    .hiddenHeader{
      height: 0 !important;
      min-height: 0 !important;
      overflow: hidden;
      div{
        display: none;
      }
    }
    .drag-box{
      height: 100px;
      background: #fff;
      width: 400px;
      border: 1px dashed #ddd;
      position: relative;
      textarea{
        width: 100%;
        height: 100%;
        opacity: 0;
        position: absolute;
        z-index: 2;
      }
      .drag-icon{
        position: absolute;
        top:50%;
        left: 50%;
        transform: translate(-50%,-50%);
        z-index: 1;
        width: 100px;
        height: 80px;
        color: #ddd;
        text-align: center;
        .icon{
          display: inline-block;
          height: 50px;
          width: 50px;
          font-size: 50px !important;
          color: #ddd;
        }
      }
    }
    .retrival-header{
      min-height: 5%;
      transition: all 1s;
      padding: 12px;
      .search-box{
        position: relative;
        width: 400px;
        .prepend-img{
          width: 60px;
          height: 30px;
          overflow: hidden;
          line-height: 34px;
          .close-tab{
            color: #aaa;
            position: absolute;
            z-index: 1;
            left: 53px;
            top: -2px;
          }
          img{
            height: 100%;
            width: 100%;
            object-fit: contain;
          }
        }
        .choose-image{
          display: inline-block;
          line-height: 32px
        }
        .suffix-icon{
          display: inline-block;
        }
      }


   }
    .retrival-body{
      height: 95%;
      overflow: auto;
      transition: height .2s;
    }

  }

 .condition-box{
    display: flex;
    justify-content:space-between;
    .condition-detail{
      display: flex;
      justify-content:space-between;
      .condition-detail-group{
        .condition-detail-group-child{
          display: flex;
          justify-content: space-between;
        }
       .condition-detail-item{
          display: flex;
          padding: 5px;
          justify-content:space-between;
          line-height: 32px;
          height: 42px;
          .label{
            padding-right: 5px;
            white-space:nowrap;
          }
          .tree-input{
            width: 100%;
            display: flex;
            justify-content:space-between;
          }
        }
        .tree-input{
          display: block;
        }
      }

    }
    .operate{
        display: flex;
        align-items:center;
        justify-content:flex-end;
        margin-left:50px;
        div{
          margin-right: 20px;
        }
    }
  }
  .history-record-container {
    margin-top: 0px;
    transition: all .5s ;
  }
  .isHeighten {
    margin-top: 75px;
  }

  ::v-deep .image-list-container .image-list .image-item {
    height: 215px;
  }

   ::v-deep .el-range-editor.el-input__inner{
    height: 32px;
    width: 100%;
  }

</style>
