<template>
   <div class="nonMotor">
     <vanScreen
      @reset-condition='resetCondition'
      @do-search="doSearch"
      @show-condition='showCondition'
      @hide-condition='hideCondition' >
       <div slot="option">
            <div class="condition-detail-all" slot="option" >
                <!-- 任务 -->
                <div class="condition-detail-item">
                  <!-- <tree-input
                    class="tree-input"
                    @dropDown="getRuleName"
                    @checkout="checkoutRuleNameTypes"
                    :data="monitorRules"
                    label="name"
                    name="任务"
                    ref="ruleName_tree"
                  /> -->
                  <div  class="tree-input tree-input" style="display: flex;">
                        <span
                          class="title"
                          style="padding-right: 3px;
                              padding-left: 10px;
                              display: inline-block;
                              white-space: nowrap;"
                              >
                          {{$t('pedestrian.mission')}}
                        </span>
                        <el-input
                          :placeholder="$t('pedestrian.no')"
                          :disabled="true">
                        </el-input>
                    </div>
                </div>

                <!-- 地点 -->
                <div class="condition-detail-item">
                    <tree-input
                    class="tree-input"
                    @dropDown="fetchLocation"
                    @checkout="checkoutLocation"
                    :data="locationList"
                    label="name"
                    :name="$t('records.contLocation')"
                    ref="location_tree"
                  />
                </div>

                <!-- 时间 -->
                <div class="condition-detail-item">
                  <span class="label">{{$t("records.contTime")}}</span>
                  <el-date-picker
                    class="input-field"
                    size="small"
                    v-model="timeRange"
                    @change="handleDateChange"
                    type="datetimerange"
                    range-separator="-"
                    :start-placeholder="$t('log.textboxTimeSet')"
                    :end-placeholder="$t('log.textboxTimeSet')">
                  </el-date-picker>
                </div>

                <!-- 设备 -->
                <div class="condition-detail-item">
                    <tree-input
                    class="tree-input"
                    @dropDown="fetchDevice"
                    @checkout="checkoutDevice"
                    :data="deviceList"
                    label="name"
                    :name="$t('records.contDevice')"
                    ref="device_tree"
                  />
                </div>
                <!-- 告警类型 -->
                <div class="condition-detail-item">
                    <tree-input
                    class="tree-input"
                    @checkout="checkoutcompareType"
                    :data="compareTypes"
                    label="name"
                    :name="$t('pedestrian.alarm')"
                    ref="compareType_tree"
                  />
                </div>

                <!-- 车辆类型 -->
                <div class="condition-detail-item">
                  <tree-input
                    class="tree-input"
                    @checkout="(ids)=>{ param.type = ids}"
                    :data="nonmonTypes"
                    label="name"
                    :name="$t('imagemanagement.contOtherInfo')"
                    ref="tree_nonmoTypes"
                    :valText="$t('pedestrianTo.carType')"
                  />
                </div>
                <div class="condition-detail-item">
                  <tree-input
                    class="tree-input"
                    @checkout="(ids)=>{ param.color = ids}"
                    :data='carColorTypes'
                    label="name"
                    name="- "
                    ref="tree_carColorTypes"
                    :valText="$t('pedestrianTo.color')"
                  />
                </div>
            </div>
       </div>
     </vanScreen>
      <el-button
          v-if="$permission('015301')"
          type="primary"
          size="small"
          class="batch-export"
          @click="showExportDialog"
        >
          <i class="iconfont icon-upload"></i>
          {{$t("records.buttonExport")}}
      </el-button>
     <div class='list-img'  v-loading="loading">
       <div style="position: relative;">
        <el-input
          size="small"
          style="width:300px; margin:0 0 12px 12px;"
          :placeholder="$t('pedestrian.search')"
          v-model="param.keyWord"
          @keyup.enter.native="searchKeyword"
          >
          <i
            slot="suffix"
            v-show="param.keyWord"
            @click="()=>{param.keyWord = '',searchKeyword()}"
            style="cursor: pointer;"
            class="el-input__icon el-icon-circle-close"
          ></i>
          <i class="iconfont icon-search1" slot="suffix" style="cursor: pointer;line-height: 32px;" @click="searchKeyword"/>
          <!-- <el-button slot="append" icon="el-icon-search"></el-button> -->
        </el-input>
          <el-popover
            placement="bottom-start"
            trigger="hover"
            >
              <div class="keyword-suggest" v-html="$t('records.hovmsgNonVehicle')"></div>
            <i slot="reference" style="margin-left: 5px;color:#2a5af5;position: absolute;top: 8px;" class="el-icon-question"></i>
          </el-popover>
       </div>
      <ImageList
      :lists="nonMotorInfo"
      :collapse="true"
      :class="{isHeighten}"
      >
        <nonMotorCard
          slot-scope="{items, item }"
          :item="item"
          :items="items"
          slot="listCollapse"
          @view-detail="viewDetail"
        />
        <cardParticulars
            slot-scope="{items}"
            slot="detail"
            :items="items"
            :data="comparisonDetail"
            :display="items.showCompareDetail"
            @collapse="hiddenDetail(items)" >
            <template slot="card" slot-scope='{currentCapture}'>
              <div style="">
                <div class="detail">
                  <div class="state" style="background:#1989FA;">{{$t('pedestrian.nonMotorRecords')}}</div>
                  <el-image
                    :src="processImgurl(currentCapture.imgUrl)"
                    fit="contain">
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"
                      style="color: aliceblue;
                      position: absolute;
                      left: 50%;
                      top: 50%;
                      transform: translate(-50%,-50%);"
                      ></i>
                    </div>
                  </el-image>
                <!-- {{currentCapture}} -->
                 <div class="detailText">
                    <ul class="">
                          <li>
                            <div>
                              <span>{{$t('pedestrian.title')}}:</span>
                              <el-popover
                                placement="right-start"
                                width="200"
                                trigger="hover"
                                :content="currentCapture.deviceName"
                              >
                                <p slot="reference">{{currentCapture.deviceName}}</p>
                              </el-popover>
                              <!-- <p>{{currentCapture.deviceName}}</p> -->
                            </div>
                          </li>
                          <li>
                            <div>
                              <span>{{$t('pedestrian.site')}}:</span>
                              <el-popover
                                placement="right-start"
                                width="200"
                                trigger="hover"
                                :content="currentCapture.placeName"
                              >
                                <p slot="reference">{{currentCapture.placeName}}</p>
                              </el-popover>
                              <!-- <p>{{currentCapture.placeName}}</p> -->
                            </div>
                          </li>
                          <li>
                            <div><span>{{$t('pedestrian.time')}}:</span><span>{{currentCapture.captureTime}}</span></div>
                          <li>
                            <div><span>{{$t('pedestrian.carType2')}}:</span><p style="border-radius: 4px;min-width: 63px;text-align: center;" :class="currentCapture.color ?currentCapture.color.toLowerCase() : 'white'">{{ $t('pedestrian.'+(currentCapture.type ? currentCapture.type.toLowerCase() : 'no') )}}</p></div>
                          </li>
                        </ul>
                 </div>

                </div>
              </div>
            </template>

        </cardParticulars>
      </ImageList>
    </div>

    <div class="block">

        <el-pagination
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          :page-size='pageSize'
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[15, 30, 45 , 60, 105]">
        </el-pagination>
     </div>
    <batch-export
      :series="dialogTrigerNumber"
      @export="doExportRecord"
      :maxNum="total"
    />
   </div>
</template>

<script lang="ts">
  import { Component, Vue, Watch , Emit} from "vue-property-decorator";
  import nonMotorCard from '../component/image-card/non-motor-card.vue';
  import vanScreen from '../component/van-screen.vue';
  import request from '@/api/history-record';
  import ImageList from "@/components/image-list/index.vue";
  import { processInfo } from "../component/processInfo";
  import cardParticulars from '../component/image-card/cardParticulars.vue';
  import { processImgurl } from "@/utils/image";
  import TreeInput from '@/components/tree-input/index.vue';
  import {EventBus} from '@/utils/eventbus';
  import BatchExport from '../component/batch-export.vue';
  import { Cache } from '@/utils/cache';
  var _ = require('lodash/lang');

  @Component({
    components:{
      nonMotorCard,
      vanScreen,
      ImageList,
      cardParticulars,
      TreeInput,
      BatchExport
    }
  })
  export default class nonMotor extends Vue{
    processImgurl = processImgurl;
    nonMotorData = {};
    nonMotorInfo = [];
    total = 0
    param = {
      alertType: [],
      captureTimeEnd: "",
      captureTimeStart: "",
      deviceId: [],
      enableTimeSort: "0",
      keyWord: "",
      objectId: "",
      placeId: [],
      taskId: [],
      type:[],
      color:[]
    };
    pageNum = 1;
    pageSize = 15;
    loading = false;
    comparisonDetail = {};
    // triggerEle :any;
    //筛选数据
    monitorRules =[];
    locationList = [];
    timeRange:any=null;
    deviceList = [];
    dialogTrigerNumber = 0 ;
    keyWordOK = '';
    isHeighten = false;

    mounted() {
      this.getNonMotorRecords();
    }

    getNonMotorRecords() {
      this.loading = true;
      let param :any = _.cloneDeep(this.param);
      param.pageNum = this.pageNum;
      param.pageSize = this.pageSize;
      request.getNonVehiclesRecords(param).then(data => {
        this.nonMotorInfo = processInfo(data.data.list ? data.data.list : []) as any;
        this.total = data.data.total
        // console.log(this.vehiclesInfo);
        // this.vehiclesData = data
      }).finally(()=>{
        this.loading = false;
      });
    }

    //以下筛选
    get compareTypes(){
      return [
        // {id:"0",name:'未知'},
        {id:"3",name:this.$t('pedestrian.nonMotorRecords')},
      ];
    }
    get nonmonTypes(){
      return [
        {id:"st_motor",name:this.$t('pedestrian.st_motor')},
        {id:"st_ebike",name:this.$t('pedestrian.st_ebike')},
        {id:"st_bicycle",name:this.$t('pedestrian.st_bicycle')},
        {id:"st_tricycle",name:this.$t('pedestrian.st_tricycle')},
      ];
    }
    get carColorTypes(){
      return [
        {id:"black",name:this.$t('pedestrian.black')},
        {id:"white",name:this.$t('pedestrian.white')},
        {id:"gray",name:this.$t('pedestrian.gray')},
        {id:"red",name:this.$t('pedestrian.red')},
        {id:"yellow",name:this.$t('pedestrian.yellow')},
        {id:"blue",name:this.$t('pedestrian.blue')},
        {id:"green",name:this.$t('pedestrian.green')},
        {id:"purple",name:this.$t('pedestrian.purple')},
        {id:"brown",name:this.$t('pedestrian.brown')},
        {id:"pink",name:this.$t('pedestrian.pink')},
      ];
    }
    //获取r任务列表
    getRuleName(){
      if(this.monitorRules.length==0){
        let state = {taskTypes:[4]}
        // console.log(state);

        request.getQueryTasksByType(state).then((data)=>{
          console.log(data);

          this.monitorRules=(data as any).taskNameVOList
          console.log(this.monitorRules);

        })
      }
    }

    //获取位置列表
    fetchLocation(val){
      if(!this.locationList.length){
        request.fetchLocation().then((data)=>{
          console.log(data);

          this.locationList = data.data
        })
      }
    }

    //选取地点
    checkoutLocation(ids){
      // this.searchCondition.floorIds=ids
      this.param.placeId = ids
    }

    //获取设备列表
    fetchDevice(val){
      if(!this.deviceList.length){
        request.fetchDevice().then((data)=>{
          this.deviceList = data.data
        })
      }
    }

    //选取任务
    checkoutRuleNameTypes(ids){
      this.param.taskId = ids
      // console.log('111');

    }

    //选取设备
    checkoutDevice(ids){
      // console.log(ids);
      this.param.deviceId = ids
    }

    //选取时间
    handleDateChange(tms){
      console.log(tms);
      // this.data

    }

    //选取告警
    checkoutcompareType(ids){
      this.param.alertType = ids
      // console.log('选取告警',ids);

    }
    //初始化时间
    initData() {
      this.timeRange = null
    }

    resetCondition() {
      console.log("点击重置");
        this.initData();//初始化时间
        // historyStore.reset_condition();//初始化检索条件
        // this.searchCondition = historyStore.condition;
        // (this.$refs.dept_tree as any).clearCheckout();
        (this.$refs.device_tree as any).clearCheckout();
        (this.$refs.location_tree as any).clearCheckout();
        // (this.$refs.watchlist_tree as any).clearCheckout();
        (this.$refs.compareType_tree as any).clearCheckout();
        (this.$refs.tree_nonmoTypes as any).clearCheckout();
        (this.$refs.tree_carColorTypes as any).clearCheckout();
        // (this.$refs.ruleName_tree as any).clearCheckout();  //任务
        // (this.$refs.operateStatus as any).clearCheckout();
        EventBus.$emit('clearAll' , false) //重置全选
    }
    doSearch() {
      console.log("点击筛选");
      this.pageNum=1;
      this.param.captureTimeStart =this.timeRange? this.timeRange[0]:null;
      this.param.captureTimeEnd = this.timeRange? this.timeRange[1]:null;
      this.getNonMotorRecords()
    }

  showCondition(){
    this.isHeighten = true
  }
  hideCondition(){
    this.isHeighten = false
  }

    //展开详情
    viewDetail(data, e) {
      console.log(data);

      if (this.$permission("009304")) {
        // 查看详情涉及到修改状态权限，所以没有修改权限的用户点击不触发详情
        // this.triggerEle=e
        // 所有展开收缩
        this.nonMotorInfo.forEach((val :any)=>{
          val.showCompareDetail=false;
          console.log(val);
          val.data.forEach((obj)=>{
            obj.isFocus=false
          })
        })
        //当前展开
          console.log(data,e);
          data.items.showCompareDetail = true
          data.item.isFocus = true;
          this.comparisonDetail = data.item
      }
    }

    //收起详情
    hiddenDetail(data){
      //当前详情数据置空
      this.comparisonDetail={}
      // console.log(data);
      data.showCompareDetail=false
      data.data.forEach((val)=>{
        val.isFocus=false;
      })
    }

    //分页
    handleSizeChange(val) {
      // console.log(val);
      this.pageSize = val;
      // this.pageNum = 1;
      this.loading = true
      this.getNonMotorRecords()
    }
    handleCurrentChange(val) {
      // console.log(val);
      this.loading = true
      this.pageNum = val
      this.getNonMotorRecords()
    }

    //搜索关键字
    searchKeyword() {
      this.pageNum = 1
      this.keyWordOK = this.param.keyWord
      // console.log(this.data.keyword);
      this.getNonMotorRecords()
    }
    // toLowerCase(val:string) {
    //   return val.toLowerCase()
    // }

    //显示导出弹框
    showExportDialog(){
      this.dialogTrigerNumber = Math.random()
    }

    //导出
    doExportRecord(start,end){
      console.log(this.param);
        let param :any = _.cloneDeep(this.param);
        param.from = start;
        param.to = end;
        param.keyWord = this.keyWordOK;
        param.userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";

        console.log(param);

        request.exportNonVehicles(param).then(()=>{
          this.$message({
            showClose: true,
            message: this.$t("log.exportSuccess") as string,
            type: 'success',
            duration: 3 * 1000,
          });
        })
    }
  }
</script>

<style lang="scss" scoped>
  .nonMotor{
    margin-top: 12px;
    overflow: auto;
    height: 95%;
    .list-img {
      min-height: 732px;
      .image-list-container {
        margin-top: 0px;
        transition: all .5s ;
      }
      .isHeighten {
        margin-top: 22px;
      }
    }
    .block .el-pagination{
      margin: 0 auto;
      width: 50%;
      text-align: center;
    }

    .detail {
      display: inline-block;
        width:408px;
        height:528px;
        background-color: #fff;
        border-radius:4px 0px 0px 4px;
        .state {
          width: 100%;
          height: 32px;
          border-radius:4px 0px 0px 0px;
          text-align: center;
          line-height: 32px;
          color: #fff;
        }
        .el-image {
          width: 227.9px;
          height: 320px;
          // border:1px solid rgba(112,112,112,1);
          position: relative;
          left: 50%;
          transform: translateX(-50%);
          margin-top: 20px;
          // background-color: #011C50;
          border: 1px dashed #CDE1FD;
          background-color: #DFEAFC;
        }
    }
    .detailText {
      width: 80%;
      margin-left: 21%;
      margin-top: 10px;

      ul {

        li {
              width: 80%;
              div {
                line-height: 25px;
                width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                -ms-text-overflow: ellipsis;
                white-space: nowrap;
                display: flex;

                span:first-child {
                  font-size:14px;
                  font-family:Source Han Sans CN;
                  font-weight:bold;
                  // line-height:14px;
                  color:rgba(40,53,77,1);
                  margin-right: 10px;
                }

                span:last-child {
                  max-width: 80%;
                  p {
                    // display: flex;
                    text-align: left;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    -ms-text-overflow: ellipsis;
                    white-space: nowrap;
                  }
                }

              }
            }
      }
    }

    .batch-export {
      position: absolute;
      right: 35px;
      top: 5px;
    }
  }

    .condition-detail-all{
        display: flex;
        // height: 32px;
        .condition-detail-item {
        display: flex;
        // display: flex;
    // padding: 5px;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        line-height: 32px;
        height: 32px;
        .label {
          padding-right: 3px;
          padding-left: 10px;
          // display: inline-block;
          line-height: 32px;
          white-space: nowrap;
        }

      }
    }

  ::v-deep  .tree-input {
    display: flex;
    // align-items: center;
    align-items: flex-end;
      .title {
        line-height: 32px;
      }
    }

  .keyword-suggest{
  //  display: flex;
  //  flex-wrap:wrap;
    :first-child{
        font-weight: 900;
    };
    :last-child{
        word-break:break-all;
    }
  }

</style>
