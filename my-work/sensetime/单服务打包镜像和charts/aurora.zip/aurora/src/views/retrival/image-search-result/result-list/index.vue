<template>
<div class="result-list-container">
  <div class="result-list-header">
    <div class="header-title">
      <i class="iconfont icon-device1"></i>
      相似结果
      <sort
        @onsort="handleSort"
        theme="dark"
        :isLike='true'
      />
    </div>
    <div class="batch-export">
      <el-button
        @click="generateTrack"
        size="mini"
        type="primary"
        icon="el-icon-locus"
      >{{$t("records.titleFootfall")}}
      </el-button>
      <el-button
        v-if="$permission('014304')"
        @click="showExportRecordDialog"
        size="mini"
        type="primary"
        icon="el-icon-batch-export"
      >{{$t("records.buttonExport")}}
      </el-button>
    </div>
  </div>
  <div class="result-list-body">
    <div v-if="!data || data.length == 0" class="no-data">
      【{{$t("records.contNoImage")}}】
    </div>
    <div v-else class="result-list">
      <ul>
        <li v-for="(item) in dataList" :key="item.index">
          <el-image :src="item.url" :fit="cover" lazy></el-image>
          <span class="label">80%</span>
        </li>
      </ul>
    </div>

    <div class="capture-detail">
      <div class="capture-big-img">
        <div class="capture-big-img-top">
          <span>{{$t("records.contDevice")}}: {{captureDetail?captureDetail.deviceName:""}}</span>
          <span> {{captureDetail?captureDetail.capturedTime:""}}</span>
        </div>
        <div
          v-if="captureDetail"
          class="big-img-container"
        >
          <img
            :src="processImgurl(captureDetail.panoramicImage)"
            alt=""
          >
          <div class="big-img-container-btn">
            <el-button
              size="mini"
              type="primary"
              @click="handleFullscreen"
            >
              {{$t("records.buttonFullScreen")}}
            </el-button>
            <el-button
              size="mini"
              type="primary"
              @click="downloadBigImage(processImgurl(captureDetail.panoramicImage))"
            >
            </el-button>
          </div>
          <big-image-view
            :isFullScreen="isFullScreen"
            :url="processImgurl(captureDetail.panoramicImage)"
            @close="cancelFullscreen"
            @previousImg="viewPreviousImg"
            @nextImg="viewNextImg"
            @currentCaptureIndex="currentCaptureIndex"
            @play="handleAutoPlay"
            @pause="handlePause"
          />
        </div>
        <div
          v-else
          class="big-img-container no-img"
        >
          【{{$t("records.contNoImage")}}】
        </div>
      </div>
      <div class="path-track">
        <div class="path-track-top">
          <span>{{$t("records.contLocation")}}:</span>
        </div>
        <div class="path-track-container">
          <map-device
            v-if="captureDetail && captureDetail.devicePlaceInfo"
            handleType="view"
            :deviceInfo="[captureDetail.devicePlaceInfo]"
            :key="captureDetail.devicePlaceInfo.id"
          />
        </div>
      </div>
    </div>

  </div>
  <track-select
    :data="data"
    :showTrackDialog="showTrackDialog"
    @cancel="cancelTrackDialog"
    @toSelectTrackInfo="generateTrack"
    trackType="capture"
  />
  <batch-export
    :series="dialogTrigerNumber"
    @export="doExportRecord"
    :maxNum="totalFacial"
  />
</div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator'
// import { Carousel, Slide } from 'vue-carousel';
import TwoImage from '@/components/two-image/index.vue'
import SingleImage from '@/components/single-image/index.vue'
import SgDialog from '@/components/sn-dialog/index.vue'
import request from '@/api/history-record'
import { Cache } from '@/utils/cache'
import { historyStore } from '@/store/modules/history-record'
// import  { messageCenter } from '@/store/modules/message-center';
import TrackSelect from '../../component/track-selected.vue'
import BatchExport from '../../component/batch-export.vue'
import { processImgurl } from '@/utils/image'
import MapDevice from '../../../manage/map/map-device.vue'
import Carousel from '../../component/carousel.vue'
import BigImageView from '../../component/big-image-view.vue'
import Sort from '../../component/sort.vue'
var _ = require('lodash/lang')

@Component({
  // props: {
  //   data: {
  //     type: Array,
  //     default() {
  //       return []
  //     }
  //   }
  // },
  components: {
    TwoImage,
    SingleImage,
    Carousel,
    // Slide,
    SgDialog,
    TrackSelect,
    BatchExport,
    MapDevice,
    BigImageView,
    Sort
  }
})
export default class ResultList extends Vue {
  @Prop({default(){return []}}) data!:any[];

  timer: any = null
  currentCaptureIndex = 0
  isFullScreen = false
  dialogTrigerNumber = 0
  // data: any
  startNum: number = 0
  endNum: number = 0
  showTrackDialog: boolean = false
  captureDetail = {}
  totalFacial = 0
  processImgurl = processImgurl
  sort = { similaritySort: 0, timeSort: null }
  dataList:any = []
  devicePlaceInfo = [
    {
      name: '5楼电梯',
      id: '',
      floorId: 216,
      position: {
        lng: this.$_.random(500, 800),
        lat: 400
      }
    }
  ]

  @Watch('data', { immediate: true, deep: true })
  onDataChanged(val, oldVal) {
    this.totalFacial = val.length
    this.captureDetail = val[0]
  }
  mounted() {
    this.dataList = this.data
  }
  @Emit('collapse')
  collapseDetail() {}

  @Emit('sort')
  handleSort(param) {
    // console.log(param);
    this.sort = param
    return param
  }
  imgToBase64(url) {
    return new Promise((resolve, reject) => {
      let img = new Image()
      img.crossOrigin = 'Anonymous'
      img.src = url
      let reg = /^data:image/
      let canvas = document.createElement('canvas')
      if (!reg.test(url)) {
        let that = this
        img.onload = function() {
          canvas.width = img.width
          canvas.height = img.height
          let ctx = canvas.getContext('2d')
          ;(ctx as any).drawImage(img, 0, 0, img.width, img.height)
          resolve(canvas.toDataURL('image/jpeg'))
        }
      } else {
        resolve(url)
      }
    })
  }
  downloadBigImage(url) {
    this.imgToBase64(url).then(base64 => {
      let ele = document.createElement('a')
      ele.setAttribute('download', 'download')
      ele.href = base64 as string
      ele.click()
    })
  }
  handlePause() {
    this.stopTimer()
  }
  handleAutoPlay() {
    this.stopTimer()
    this.timer = setInterval(() => {
      this.viewNextImg()
    }, 1000)
  }
  //停止定时器
  stopTimer() {
    this.timer && window.clearInterval(this.timer)
  }
  //查看上一张
  viewPreviousImg() {
    this.currentCaptureIndex--
    this.doView(this.currentCaptureIndex)
  }
  //查看下一张
  viewNextImg() {
    this.currentCaptureIndex++
    this.doView(this.currentCaptureIndex)
  }
  //查看
  doView(index) {
    let len = this.data.length
    if (index < 0) {
      this.currentCaptureIndex = 0
      return
    } else if (index > len - 1) {
      this.currentCaptureIndex = len - 1
      return
    }
    this.handleClick(
      this.data[this.currentCaptureIndex],
      this.currentCaptureIndex
    )
  }
  //取消大图全屏
  cancelFullscreen() {
    this.stopTimer()
    this.isFullScreen = false
  }
  //大图全屏
  handleFullscreen() {
    this.isFullScreen = true
  }

  showExportRecordDialog() {
    this.dialogTrigerNumber = Math.random()
  }

  doExportRecord(start, end) {
    var condition = _.cloneDeep(historyStore.condition)
    console.log(condition)

    // condition.accessToken = Cache.sessionGet("accessToken")
    condition.userId = Cache.sessionGet('userInfo').userId
    // condition.websocketId=condition.accessToken
    condition.from = start
    condition.to = end
    condition.similaritySort = this.sort.similaritySort
    condition.timeSort = this.sort.timeSort
    request.exportCapture(condition).then(() => {
      this.$message({
        showClose: true,
        message: this.$t('log.exportSuccess') as string,
        type: 'success',
        duration: 3 * 1000
      })
    })
  }

  handleClick(obj, key) {
    //当前抓拍图的下标
    this.currentCaptureIndex = key
    this.captureDetail = obj
    this.$emit('click', this.captureDetail)
  }
  //显示轨迹生成弹框
  generateTrack() {
    this.showTrackDialog = true
  }
  cancelTrackDialog() {
    this.showTrackDialog = false
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import '@/styles/variables.scss';
.result-list-header{
  display: flex;
  justify-content: space-between;
  padding: 8px;
  .header-title{
    display: flex;
    justify-content: space-between;
    width: 30%;
  }
}
.capture-list{
  li{
    position: relative;
    padding: 5px;
    .el-image{
      box-shadow: 0 5px 9px rgba(109, 124, 150, .5);
    }
    .label{
      position: absolute;
      display: inline-block;
      width: 100%;
      left: 0;
      bottom: 0;
      line-height: 1.8;
      background: rgba(109, 124, 150, .8);
      padding-left: 8px;
      z-index: 1;
      color: #fff;
      font-weight: bold;
    }
  }
}

.record-detail {
  background: $--color-white;
  position: relative;
  padding: 10px;
  .can-click {
    cursor: pointer;
  }
  .close-tab {
    position: absolute;
    right: 2px;
    top: 2px;
    height: 20px;
  }
  .detail-container {
    display: flex;
    width: 100%;
    .detail-list {
      width: 100%;
      .record-detail-top {
        display: flex;
        justify-content: space-between;
        .record-detail-title {
          span {
            padding-right: 10px;
          }
        }
        .batch-export {
          span {
            cursor: pointer;
            padding-left: 5px;
            padding-right: 10px;
          }
        }
      }
      .capture-list {
        min-height: 150px;
        margin: 10px 30px;
        .img-container {
          height: 150px;
        }
        .empty-notice {
          text-align: center;
          line-height: 150px;
          background: rgba($--color-reserved-6, 0.1);
        }
      }
      .capture-detail {
        display: flex;
        justify-content: center;
        padding-top: 10px;
        .capture-big-img {
          width: 48%;
          height: 360px;
          overflow: hidden;
          margin-right: 10px;

          .capture-big-img-top {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
          }
          .big-img-container {
            height: 333px;
            position: relative;
            background-color: black;

            .big-img-container-btn {
              position: absolute;
              bottom: 10px;
              left: 10px;
            }
          }
          .no-img {
            background: rgba($--color-reserved-6, 0.1);
            text-align: center;
            line-height: 300px;
          }
          img {
            // max-width: 100%;
            width: 100%;
            height: 100%;
            object-fit: contain;
          }
        }
        .path-track {
          width: 48%;
          margin-left: 10px;
          height: 360px;
          box-sizing: border-box;
          overflow: hidden;
          .path-track-top {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
          }
          .path-track-container {
            height: 333px;
            background: rgba($--color-reserved-6, 0.1);
            .empty-notice {
              text-align: center;
              line-height: 280px;
            }
          }
        }
      }
    }
  }
}

</style>
