<template>
  <div class="record-detail">
    <div>
      <div class="retrival-facial-container">
        <div class="detail-list">
          <div class="record-detail-top">
            <div class="record-detail-title">
              <span>
                 {{$t("records.contTotal")}}
                 <span style="font-size:16px;padding:5px">{{totalFacial}}</span>
                 {{$t("records.contRecords")}}</span>
                 <sort
                    @onsort="handlefacialSort"
                    :timeSortVisible="false"
                    theme="dark"
                 />
              <!-- <span class="can-click" :class="facialSortStyle" @click="handlefacialSort">
                <Icon
                  class="order-icon"
                  name="sort-similar"
                />
                {{$t("records.contSortbyThreshold")}}
                </span> -->
            </div>
            <div class="batch-export">
              <!-- <span class="can-click" @click="showExportFacialDialog">
                <Icon
                  name="batch-export"
                />
                批量导出
              </span> -->
              <el-button
               v-if="$permission('014305')"
               @click="showExportFacialDialog"
               size="mini"
               type="primary">
                <Icon
                    name="batch-export"
                  />
                  {{$t("records.buttonExport")}}
              </el-button>
            </div>
          </div>
          <div class="facial-list">
              <!-- <carousel
              :perPage="8"
              :navigationEnabled="true"
              :paginationEnabled="false"
              v-if="data.lengh!=0"
              >
                <slide
                 v-for="(item,key) in data" :key="key">
                   <single-image
                    class="img-container"
                    :item="item"
                    @viewDetail="handleFacialClick"
                    :percentage="item.score"
                    :img="item.faceUrl"
                  />
                </slide>
              </carousel> -->
              <carousel
              v-if="data.lengh!=0"
              :data="data"
              @click="handleFacialClick"
            />
              <div v-else class="empty-notice">
                【{{$t("records.contNoImage")}}】
              </div>
          </div>

          <div v-if="viewTop100" class="capture-list">
          <div class="capture-detail-top">
            <div class="capture-detail-title">
              <span class="title-main">{{$t("records.contRelatedRecord")}}</span>
              <span>
                {{$t("records.contTotal")}}
                 <span style="font-size:16px;padding:5px">{{totalCapture}}</span>
                 {{$t("records.contRecords")}}
               </span>
               <sort
                  @onsort="handleTop100Sort"
                />
              <!-- <span class="can-click" :class="timeStyle" @click="handletimeSort">
                <Icon
                  class="order-icon"
                  name="time-sort1"
                />
                {{$t("records.contSortbyTime")}}
                </span>
              <span class="can-click" :class="similarStyle" @click="handleSimilarSort">
                <Icon
                  class="order-icon"
                  name="sort-similar"
                />
                {{$t("records.contSortbyThreshold")}}
                </span> -->
            </div>
            <div class="batch-export">
              <el-button
               @click="generateTrack"
               size="mini"
               type="primary">
                <Icon
                    name="locus"
                  />
                  {{$t("records.titleFootfall")}}
              </el-button>
              <el-button
               v-if="$permission('014306')"
               @click="showExportTop100Dialog"
               size="mini"
               type="primary">
                <Icon
                    name="batch-export"
                  />
                  {{$t("records.buttonExport")}}
              </el-button>

            </div>
          </div>
          <div class="img-list" >
            <div class="img-list-item" v-for="(item,key) in CaptureList" :key="key">
              <single-image
                :percentage="item.score+''"
                :img="item.faceUrl"
                class="img-container"
              />
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
    <batch-export
      :series="dialogTrigerNumberFacial"
      @export="doExportFacial"
      :maxNum="totalFacial"
    />
    <batch-export
      :series="dialogTrigerNumberTop100"
      @export="doExportTop100"
      :maxNum="totalCapture"
    />
    <track-select
      :data="CaptureList"
      :showTrackDialog="showTrackDialog"
      @cancel="cancelTrackDialog"
      @toSelectTrackInfo = "generateTrack"
      trackType="library"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import  TwoImage from '@/components/two-image/index.vue';
import  SingleImage from '@/components/single-image/index.vue';
import  Icon from '@/components/icon-wrap/index.vue';
import { Cache } from '@/utils/cache';
import   { historyStore } from '@/store/modules/history-record';
// import  { messageCenter } from '@/store/modules/message-center';
import historyApi from '@/api/history-record';
import TrackSelect from '../../component/track-selected.vue';
import BatchExport from '../../component/batch-export.vue';
// import { Carousel, Slide } from 'vue-carousel';
import request from '@/api/history-record';
import   Carousel  from '../../component/carousel.vue';
import Sort from '../../component/sort.vue';
var _ = require('lodash/lang');
@Component({
  // props:{
  //   data:{
  //     type:Array,
  //     default(){
  //       return [];
  //     }
  //   }
  // },
  components: {
    TwoImage,
    SingleImage,
    Icon,
    TrackSelect,
    BatchExport,
    Carousel,
    Sort,
  },
})
export default class FacialLib extends Vue {
  @Prop({default(){return []}}) data!:any[];

  dialogTrigerNumberTop100=0;
  dialogTrigerNumberFacial=0;
  // data:any;
  showTrackDialog:boolean=false;
  CaptureList=[];
  similaritySort="";
  // similarStyle="";
  timeSort=0;
  // timeStyle=""
  // facialSort="";
  // facialSortStyle="";
  viewTop100=false;
  facialId="";
  totalCapture=0;
  totalFacial=0;
  getCaptureParam:any={};
  sort = {similaritySort: 0,timeSort: null};

  @Watch('data', { immediate: true, deep: true })
  onDataChanged(val, oldVal) {
    this.totalFacial= val.length
   }

  mounted(){

  }
  @Emit("sort")
  handlefacialSort(param){
    console.log(param);
    this.sort =param
    return param;
  };
  handleTop100Sort(param){
    this.similaritySort = param.similaritySort
    this.timeSort = param.timeSort
    this.getCaptureLib()
  }

  //显示导出人像的弹窗
  showExportFacialDialog(){
    this.dialogTrigerNumberFacial= Math.random()
  }
  //导出人像
  doExportFacial(start,end){
    var condition = _.cloneDeep(historyStore.condition);
    // condition.accessToken = Cache.sessionGet("accessToken")
    condition.userId = Cache.sessionGet("userInfo").userId;
    // condition.websocketId=condition.accessToken
    condition.from=start
    condition.to=end
    // console.log('以图搜图导出人像');
    condition.similaritySort=this.sort.similaritySort
    // condition.timeSort=this.sort.timeSort
    request.exportFacial(condition).then(()=>{
       this.$message({
         showClose: true,
          message: this.$t("log.exportSuccess") as string,
          type: 'success',
          duration: 3 * 1000,
       });
    })
  }

  //显示导出top100的弹窗
  showExportTop100Dialog(){
    this.dialogTrigerNumberTop100=Math.random()
  }
  //导出top100
  doExportTop100(start,end){
    var condition = _.cloneDeep(historyStore.condition);
    // condition.accessToken = Cache.sessionGet("accessToken")
    condition.userId = Cache.sessionGet("userInfo").userId;
    // condition.websocketId=condition.accessToken
    condition.from=start
    condition.to=end
    condition.targetId=this.facialId

     request.exportTop100(condition).then(()=>{
        this.$message({
          showClose: true,
          message: this.$t("log.exportSuccess") as string,
          type: 'success',
          duration: 3 * 1000,
       });
    })

  }
  handleFacialClick(data){
    this.$emit("click",data)
    this.getCaptureParam = data
    this.getCaptureLib()
  }
  //top获取
  getCaptureLib(){
    this.$emit("click",this.getCaptureParam)
    let condition = _.cloneDeep(historyStore.condition)
    delete condition.imageFaceBase64;
    this.facialId = this.getCaptureParam.id
    condition.targetId = this.getCaptureParam.id
    condition.similaritySort=this.similaritySort
    condition.timeSort=this.timeSort
    historyApi.fetchCaptureRecordTop100(condition).then((data)=>{
      this.CaptureList=(data.data as any)
      this.totalCapture = this.CaptureList.length;
      this.viewTop100=true;
    })
  }
  //生成轨迹弹窗
  generateTrack(){
    this.showTrackDialog=true;
  }
  //隐藏生成轨迹弹窗
  cancelTrackDialog(){
    this.showTrackDialog=false;
  }
  @Emit("collapse")
  collapseDetail(){
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .record-detail{
    background:$--color-white;
    position: relative;
    padding:10px;
    .can-click{
      cursor: pointer;
    }
    // .order{
    //   color: $--color-danger;
    // }
    // .invert-order{
    //   color: $--color-danger;
    //   .order-icon{
    //     transform:rotate(180deg);
    //     display: inline-block
    //   }

    // }
    .close-tab{
      position: absolute;
      right: 2px;
      top:2px;
      height:20px;
    }
    .retrival-facial-container{
      display: flex;
      width: 100%;
     .detail-list{
        width: 100%;
        .record-detail-top{
          display: flex;
          justify-content: space-between;
          .record-detail-title{
            span{
              padding-right: 10px;
            }
          }
          .batch-export{
            span{
              padding-left: 5px;
              padding-right:10px
            }
          }
        }
        .facial-list{
         min-height: 150px;
         margin: 10px 30px;
         .img-container{
          height: 150px;
         }
         .empty-notice{
              text-align: center;
              line-height: 150px;
              background: rgba($--color-reserved-6,.1);
          }
       }
      //  .facial-list{
      //    .facial-list-item{
      //      width: 10%;
      //      display: inline-block;
      //    }
      //  }
     .capture-list{
        width: 100%;
        padding: 10px;
        color: $--color-white;
        background: rgba($--color-top,.2);
        height: 400px;
        overflow:scroll;
        .capture-detail-top{
          display: flex;
          justify-content: space-between;
          .capture-detail-title{
            .title-main{
              font-size: $--font-size-card;
            }
            span{
              padding-right: 10px;
            }
          }
          .batch-export{
            span{
              padding-left: 5px;
              padding-right:10px
            }
            .exportRecord{
              cursor: pointer;
            }
          }
        }
       .img-list{
         .img-list-item{
           width: 10%;
           display: inline-block;
         }
       }
     }
     }
    }
    .input-container{
      width: 50%;
      margin: 0 auto;
      .start-num{
        display: inline-block;
        width: 45%;
      }
      .end-num{
        display: inline-block;
        width: 45%;
      }
    }
    .img-container{
      height: 150px;
      width: 85%;
    }
  }
</style>
