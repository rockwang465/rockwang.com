<template>
<div class="img-retrival-container" v-loading="isLoad">
  <div class="body-attribute">
    <div class="body-attribute-detail" v-if="showCard">
      <h4>{{$t("records.searchResult2")}}</h4>
      <div class="detail_xq">
        <el-image @mousedown="disableEvent" :src="currentCapture.imgUrl" fit="contain" :data-imgcrop="JSON.stringify(currentCapture)">
          <div class="image-mask"></div>
        </el-image>
        <div class="pt-state-bt">
          <div class="pt-state-l">
            <ul v-if="currentCapture.attributes && currentCapture.attributes.length!= 0">
              <li v-for="item in currentCapture.sortAttributeInfoVos.slice(0,4)" :key="item.key">
                <i class="iconfont" :class="'icon-'+getSortAttributeInfoVos(item)"></i>
                <span class="body-tag" :class="dressUpper(item.attributeInfo, 'color')">{{dressUpper(item.attributeInfo , 'style')}}</span>
              </li>
            </ul>
            <p v-else>
              {{$t("records.noAttribute")}}
            </p>
            <!-- <ul class="nullAttributes">
              <li>
                <i class="iconfont icon-maozi"></i>
                <div>{{$t('pedestrian.no')}}</div>
              </li>
              <li>
                <i class="iconfont icon-shangyi"></i>
                <div>{{$t('pedestrian.no')}}</div>
              </li>
              <li>
                <i class="iconfont icon-faxing"></i>
                <div>{{$t('pedestrian.no')}}</div>
              </li>
              <li>
                <i class="iconfont icon-kuzi"></i>
                <div>{{$t('pedestrian.no')}}</div>
              </li>
            </ul> -->
          </div>
          <div class="pt-state-r">
            <p v-if="currentCapture.deviceName">
              <b>{{$t('pedestrian.title')}}:</b>
              <el-popover
                placement="right-start"
                width="150"
                trigger="hover"
                :content="currentCapture.deviceName"
              >
                <span slot="reference">{{currentCapture.deviceName}}</span>
              </el-popover>
            </p>
            <p v-if="currentCapture.placeName">
              <b>{{$t('pedestrian.site')}}:</b>
              <el-popover
                placement="right-start"
                width="150"
                trigger="hover"
                :content="currentCapture.placeName"
              >
                <span slot="reference">{{currentCapture.placeName}}</span>
              </el-popover>
            </p>
            <p v-if="currentCapture.captureTime"><b>{{$t('pedestrian.time')}}:</b><span>{{currentCapture.captureTime}}</span></p>
            <!-- <p v-if="currentCapture.alertType != 1">
              <b>{{$t('pedestrian.mission')}}:</b>
              <el-popover
                placement="right-start"
                width="150"
                trigger="hover"
                :content="(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName ) ? currentCapture.taskInfo.task.taskName :$t('pedestrian.no')"
                :disabled="!(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName )"
              >
                <span slot="reference">{{(currentCapture.taskInfo && currentCapture.taskInfo.task && currentCapture.taskInfo.task.taskName ) ? currentCapture.taskInfo.task.taskName :$t('pedestrian.no')}}</span>
              </el-popover>
            </p> -->
            <p v-if="currentCapture.attributes && currentCapture.attributes.length!= 0" class="more-attr">
              <el-popover
                placement="right-end"
                trigger="hover"
                width='200'
              >
                <ul class="ul-more">
                  <li v-for="item in currentCapture.detailSortAttributeInfoVos" :key="item.key">
                  <!-- <li v-for="item in newAttributes" :key="item.key" > -->
                    <!-- :class="item.key== item.value.toLowerCase() ? '0':'-1'" -->
                    <!-- <span>{{$t('pedestrianTo.'+item.key)}}:</span><span>{{changeGenduo(item.value)}}</span> -->
                    <p v-if="item.attrValues && item.attrValues.length">
                      <strong>{{$t('pedestrianTo.'+item.attrClassify.toLowerCase())}}:</strong><span >{{getAttrvalueMore(item.attrValues) }}</span>
                    </p>
                  </li>
                </ul>
                <b slot="reference" style="cursor: pointer;margin-left:0;">{{$t("records.moreAttr")}}</b>
              </el-popover>
              <i style="margin-left: 3px;font-size: 12px;line-height: 11px;" class="iconfont icon-gengduo"> </i>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="img-list-container">
    <div class="result-list-header">
      <div class="header-title">
        <strong><i class="iconfont icon-device1"></i> {{$t("records.contSearchResult")}}</strong>
        <sort
          @onsort="handleSort"
          theme="dark"
          class="sortclass"
          :isLike='true'
        />
      </div>
      <div class="batch-export" v-show="hasResult">
        <el-button
          v-if="$permission('014308')"
          @click="showExportRecordDialog"
          size="mini"
          type="primary"
          icon="el-icon-upload2"
        >{{$t("records.buttonExport")}}
        </el-button>
        <el-button
          @click="generateTrack"
          v-if="$permission('012307')"
          size="mini"
          type="primary"
          icon="iconfont icon-locus"
        >{{$t("records.titleFootfall")}}
        </el-button>
      </div>
    </div>
    <div class="result-list-body" ref="resultListLayer">
      <div v-if="!imageSearchResultList || imageSearchResultList.length == 0" class="no-data">
        <span v-if="isLoad">Loading...</span>
        <span v-else>
          【{{$t("records.contNoImage")}}】
        </span>
      </div>
      <div v-else class="result-list">
        <!-- <ul>
          <li v-for="(item) in imageSearchResultList" :key="item.index" @click="showDetail(item)">
            <el-popover
              placement="bottom"
              popper-class="imgResultDetailpopover"
              trigger="click">
              <cardDetails
              :display="cardDetailShow"
              :data="cardDetailData"
              @collapse="hiddenDetail(item)"></cardDetails>
              <el-image :src="processImgurl(item.imgUrl)" fit="cover" lazy slot="reference">
                <div slot="error" class="image-slot">
                  <i class="iconfont icon-img_error"></i><br>
                  加载失败
                </div>
              </el-image>
            </el-popover>
            <span class="label">{{toPercent(item.score)}}</span>
          </li>
        </ul> -->
        <ImageResultList
          :lists='comparisonInfo'
          :collapse='true'
          :class="{isHeighten}"
          >
          <ImageItem
          slot-scope="{items, item }"
          :item="item"
          :items="items"
          slot="listCollapse"
          @view-detail="viewDetail"
          />
          <cardDetails
            class="result-paper-card-detail"
            slot-scope="{items}"
            slot="detail"
            :items="items"
            :data="comparisonDetail"
            :display="items.showCompareDetail"
            @collapse="hiddenDetail(items)" />
            <!-- <div slot="card" slot-scope='{currentCapture}' /> -->
        </ImageResultList>
        <el-pagination
          layout="total, sizes, prev, pager, next, jumper"
          :total="pager.total"
          :page-size='pager.pageSize'
          :current-page="pager.current"
          :page-sizes="pager.sizes"
          @size-change="sizeChangeHandle"
          @current-change="currentChangeHandle">
        </el-pagination>
      </div>
    </div>
  </div>
  <batch-export
    :series="dialogTrigerNumber"
    @export="doExportRecord"
    :maxNum="pager.total"
  ></batch-export>
  <locus-analysis v-if="locusVisible" :locusVisible="locusVisible" :imgCropData="imgCropData" :imgData="currentCapture.imgUrl" @closeLous="closeLous"></locus-analysis>
</div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import { toPercent } from '@/utils/small-tool';
import { processImgurl } from '@/utils/image';
import request from '@/api/history-record';
import currentCompare from '@/components/three-image/index.vue';
import Sort from '../component/sort.vue'
import ImageItem from '@/components/image-item/index.vue';
import ImageResultList from '@/components/image-result-list/index.vue';
import cardDetails from '../component/card-details.vue';
import BatchExport from '../component/batch-export.vue';
import LocusAnalysis from '../component/locus-analysis/index.vue';
import { Cache } from '@/utils/cache';
import { dressUpper, getSortAttributeInfoVos, getAttrvalueMore } from '../component/processInfo';
var _ = require('lodash/lang');



let perSize = 44
@Component({
  components: {
    BatchExport,
    cardDetails,
    ImageResultList,
    ImageItem,
    Sort,
    currentCompare,
    LocusAnalysis
  },
})
export default class ImageSearchResult extends Vue {
  @Prop({default:"captureLib"}) currentTab!:string;
  @Prop({default(){return []}}) captureLibList!:any[];
  @Prop({default:''}) imgUrl!:string;
  @Prop({default:''}) imgCropData!:string;
  @Prop() captureData!:any;
  @Prop() parentParams!:any;
  @Prop() sourceType!:string;

  locusVisible = false
  hasResult = false

  // currentTab:any; //接受父组件传
  activeTab:any=this.currentTab; //接受父组件传
  // activeTab="captureLib"; //当前tab页
  showCompareDetail:boolean=false;
  isExportShow = false
  comparisonDetail={};
  dialogTrigerNumber = new Date().getTime();
  pager:any = {
    current:1,
    sizes:[perSize,perSize*2,perSize*3,perSize*4],
    pageSize:perSize,
    total:perSize,
    queryKey:''
  }
  imgSearchParmas:any = {}
  isHeighten = false;
  sizeChangeHandle(val){
    this.isLoad = true
    this.pager.pageSize = val;
    this.getImageResultData()
  }
  currentChangeHandle(val){
    this.isLoad = true
    this.pager.current = val
    this.getImageResultData()
  }
  // captureLibList:any;
  matchMsg:any="";
  toPercent=toPercent;
  processImgurl=processImgurl
  dressUpper = dressUpper;
  getSortAttributeInfoVos = getSortAttributeInfoVos;
  getAttrvalueMore =getAttrvalueMore;
  imageSearchResultList:any = []
  isLoad = true
  timeSort = ''
  similaritySort = 0
  processCaptureData:any = {}
  showCard =false
  currentCapture:any ={}
  cardDetailData:any ={}
  cardDetailShow = false
  comparisonInfo = []
  triggerEle :any;
  @Emit("sort")
  handleSort(param){
    this.isLoad = true
    this.timeSort = param.timeSort
    this.similaritySort = param.similaritySort
    this.getImageResultData();
  }

  //父级参数变化
  @Watch("parentParams", { immediate: true,deep:true })
  parentParamsChanged(val,oldVal){
    //console.log("父级参数变化",val,oldVal)
    if(val && oldVal){
      this.isLoad = true
      this.getImageResultData();
    }
  }

  @Watch("imgCropData", { immediate: true,deep:true })
  imgCropDataChanged(val,oldVal){
    //console.log("裁切图发生变化")
    this.isLoad = true
    this.showCard = false;
    this.processData(this.captureData,val)
    this.getImageResultData(val);
  }
  @Watch("captureData",{immediate:true,deep:true})
  oncaptcaptureDataChanged(val,oldval){
    //this.showCard = false
    if(val){

    }
  }

  //监听抓拍搜图列表
  @Watch('captureLibList', { immediate: true, deep: true })
  oncaptureLibChanged(val, oldVal) {
    if(val){
      this.matchMsg = val[0]
    }
  }
  mounted(){
    this.processData(this.captureData,this.imgCropData)
    //this.getImageResultData()
  }
  disableEvent(e){
    e.preventDefault()
  }
  viewDetail(data,e) {
    if(this.$permission('009304')){//查看详情涉及到修改状态权限，所以没有修改权限的用户点击不触发详情
      this.triggerEle=e
      //所有展开收缩
      this.comparisonInfo.forEach((val :any)=>{
        val.showCompareDetail=false;
        //console.log(val);
        val.data.forEach((obj)=>{
          obj.isFocus=false
        })
      })
      //当前展开
      data.items.showCompareDetail = true
      data.item.isFocus = true;
      this.comparisonDetail = data.item
      console.log(this.comparisonDetail)
      //this.comfirmCompareStatus(data.item,1,1)
    }
  }
  //处理列表数据
  processComparisonInfo(items){
    let size = 5;
    let comparisonInfo = new Array();
    let i;
    items.forEach((v,k)=>{
      v["isFocus"]=false;//当前详情被点击
      if(k===0){
        i=0
        comparisonInfo[i]={showCompareDetail:false,data:[]}
      }else if(k%11===0){
        i++
        comparisonInfo[i]={showCompareDetail:false,data:[]}
      }
      comparisonInfo[i].data.push(v)
    })

    return comparisonInfo;
  }

  processData(cardInfoDetail,base64?){
    //console.log(cardInfoDetail , cardInfoDetail.imgUrl)

    if(cardInfoDetail && cardInfoDetail.imgUrl && this.sourceType !=='local'){
      this.currentCapture = cardInfoDetail;
      let urlStr = cardInfoDetail.imgUrl;

      if(urlStr[0] !== '/'){
        this.currentCapture.imgUrl = processImgurl(cardInfoDetail.imgUrl)
      }
      //console.log(cardInfoDetail.imgUrl)

    }else{
      this.currentCapture.imgUrl = base64
    }
    // this.processCaptureData.url = this.captureData.imgUrl;
    this.showCard = true
  }
  showDetail(item){
    console.log(item)
    this.cardDetailData = item
    this.cardDetailShow = true
  }
  //收起详情
  hiddenDetail(data){
    //当前详情数据置空
    this.comparisonDetail={}
    // console.log(data);
    data.showCompareDetail=false
    data.data.forEach((val)=>{
      val.isFocus=false;
    })
  }
  generateTrack(){
    this.locusVisible = true
    // let isShow = confirm('轨迹分析开发中，点击确定继续查看，点击取消留在本页。');
    // if(isShow == true){
    //   window.location.href = "/locus"
    // }else{

    // }
  }
  closeLous(){
    this.locusVisible = false
  }
  showExportRecordDialog(){
    this.dialogTrigerNumber = new Date().getTime();
    console.log(this.dialogTrigerNumber)
    this.isExportShow = true;
  }
  //导出
  doExportRecord(start,end){
    let exportParmas = Object.assign(this.imgSearchParmas,_.cloneDeep(this.parentParams))
      exportParmas.userId = Cache.sessionGet("userInfo")?Cache.sessionGet("userInfo").userId:"";
      exportParmas.from=start
      exportParmas.to=end

    request.exportImageSearchResultRecord(exportParmas).then(()=>{
      this.$message({
        showClose: true,
        message: this.$t("log.exportSuccess") as string,
        type: 'success',
        duration: 3 * 1000,
      });
    })
  }
  getImageResultData(newBase64?){
    this.hasResult = false
    let self = this
    let params = {
      imageBodyBase64:this.imgCropData,
      pageNum:this.pager.current,
      pageSize:this.pager.pageSize,
      timeSort:this.timeSort,
      similaritySort:this.similaritySort,
      queryKey:this.pager.queryKey
    }
    if(newBase64){
      params.imageBodyBase64 = newBase64
    }
    //console.log(params.imageBodyBase64)
    this.imgSearchParmas = params
    let bodySearchParmas = Object.assign(_.cloneDeep(this.parentParams),params)

    request.searchBodyByImage(bodySearchParmas).then((resp:any)=>{
      //console.log(resp)
      this.isLoad = false;
      this.showCard = true;
      if(resp.list && resp.list.length > 0){
        this.imageSearchResultList = resp.list
        this.imageSearchResultList.map((item)=>{
          item.showCompareDetail = false
        })
        this.comparisonInfo = this.processComparisonInfo(resp.list?resp.list : []) as any;
        this.pager.total = resp.total;
        this.pager.queryKey = resp.queryKey
        this.hasResult = true
      }else{
        this.imageSearchResultList = []
        this.hasResult = false
      }

    }).catch(error=>{
      self.cancelImageSearch()
    })
  }
  cancelImageSearch(){
    this.$emit('cancelBack')
  }
  viewCurrentCapture(data){
    this.matchMsg=data
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.img-retrival-container{
  display: flex;
  align-items: stretch;
  background: #fff;
  color:#011C50;
  @include shadowBox();
  height:100%;
  .body-attribute{
    width: 280px;
    height: 100%;
    overflow-y: auto;
    border-right: 1px solid #DFDFE0;
    display: flex;
    justify-content: center;
    h4{
      // margin: 0;
      // padding: 24px 24px 0;
      padding-top: 8px;
    }
    .current-compare{
      width: 90%;
      margin-left: 4%;
      margin-top: 0;
    }
  }
  .img-list-container{
    flex: 1;
    padding: 10px;
    .btn-container{
      border-bottom:1px solid $--color-primary;
      .title{
        font-size:16px;
        padding:0 10px;
      }
      .tab-btn{
        margin-left:0;
        border-radius:5px 5px 0 0;
      }
    }
  }
}
.result-list{
  height: 100%;
  .el-pagination{
    text-align: center;
    padding-top: 16px;
  }
}

.result-list-body{
  height: calc(100% - 50px);
  position: relative;
  .result-paper-card-detail{
    margin-left: 8px;
    width: calc(100% - 30px);
    padding: 16px 60px 0;
    height: 570px;
    .detail-container .detail-list .capture-detail{
      height: 99%;
    }
  }
}
.result-list ul{
  display: flex;
  height: calc(100% - 45px);
  padding-bottom: 8px;
  flex-wrap: wrap;
  justify-content:flex-start;
  overflow-y:auto;
  margin-right: -10px;
  li{
    height: 158px;
    position: relative;
    box-shadow: 0 5px 9px rgba(109, 124, 150, .5);
    margin: 8px;
    flex: 0 0 8%;
    .el-image{
      height: 100%;
      width: 100%;
    }
    .image-slot{
      width: 100%;
      display: flex;
      align-items: center;
      text-align: center;
    }
    .label{
      position: absolute;
      display: inline-block;
      width: 100%;
      left: 0;
      bottom: 0;
      line-height: 1.8;
      background: rgba(109, 124, 150, .7);
      padding-left: 8px;
      z-index: 1;
      color: #fff;
      font-weight: bold;
    }
  }

}
::v-deep .image-slot{
    width: 100%;
    height: 100%;
    display: flex;
    font-size: 12px;
    align-items: center;
    justify-content: center;
    text-align: center;
    flex-direction: column;
    color: rgba(109, 124, 150);
    background: rgba(109, 124, 150, 0.7);
    i{font-size: 28px;}
  }
.result-list-header{
  display: flex;
  justify-content: space-between;
  padding: 8px;

  .header-title{
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 32%;
    white-space:nowrap;
  }
}
.body-attribute-detail{
  width: 70%;


  h4{font-size: 15px;}
  .pt-state-bt{
    padding-top: 16px;
  }
  .el-image{
    width: 100%;
    max-height: 550px;
  }
  .pt-state-l{
    ul{
      display: flex;
      flex-wrap: wrap;
      justify-content:flex-start;
      li{
        width: 50%;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
      }
    }
    .iconfont{
      margin-right: 4px;
    }
    .body-tag{
      display: inline-block;
      border-radius: 3px;
      padding: 3px 5px;
      font-size: 12px;
      width: 60px;
      text-align: center;
    }
  }
  .pt-state-r{
    b{
      margin-right: 8px;
    }
    p{
      margin-bottom: 8px;
    }
    .more-attr{
      padding-top: 8px;
      font-size: 12px;
      color: #2A5AF5;
    }
  }
}
.ul-more{
  li{
    font-size: 12px;
    strong{
      display: inline-block;
      width: 55px;
      text-align: right;
      margin-right: 4px;

    }
    margin-bottom: 8px;
  }
}
.imgResultDetailpopover{
  background-color: #f2f6fd;
  .record-detail{
    height: 450px;
    padding: 0 80px;
  }
}
::v-deep .imgResultDetailpopover{
  width: 100%;
}
::v-deep .result-list-body{
  .image-list-container{
    .image-list{
      display: flex;
      flex-wrap:wrap;
      // justify-content: space-between;
      margin-bottom: 20px;
      .image-item{
        position: relative;
        // display:inline-block;
        // margin:0 0.55%;
        // margin-top:10px;
        // width: 18.5%;
        width: 8%;
        box-sizing: border-box;

        height:158px;
      }
    }
  }
  .result-paper-card-detail{
    .close-tab{
      font-size: 24px !important;
    }
  }
}
.no-data{height: 100%;}
</style>
