<template>
    <div :class="theme" class="sort-container">
      <span v-if="timeSortVisible" class="can-click" :class="timeStyle" @click="handletimeSort">
        <Icon
          class="order-icon"
          size="20"
          name="time-sort1"
        />
        <!-- {{$t("records.contSortbyTime")}} -->
        {{$t(textSort1)}}
      </span>
      <span v-if="similarSortVisible"  class="can-click" :class="similarStyle" @click="handleSimilarSort">
        <Icon
          class="order-icon"
          size="20"
          name="sort-similar"
        />
        <!-- {{$t("records.contSortbyThreshold")}} -->
        {{$t(textSort2)}}
      </span>
    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import  Icon from '@/components/icon-wrap/index.vue';

@Component({
  // props:{
  //   similarSortVisible:{
  //     type:Boolean,
  //     default:true,
  //   },
  //   timeSortVisible:{
  //     type:Boolean,
  //     default:true,
  //   },
  //   theme:{
  //     type:String,
  //     default:"",
  //   },
  //   isLike:{
  //     type:Boolean,
  //     default:false,
  //   }
  // },
  components:{
    Icon
  }
})
export default class Sort extends Vue {
  @Prop({default:true}) similarSortVisible!:boolean;
  @Prop({default:true}) timeSortVisible!:boolean;
  @Prop({default:""}) theme!:string;
  @Prop({default:false}) isLike!:boolean;

  // timeSortVisible:any;
  similaritySort:any=null; //0为顺序　１为倒序
  similarStyle="";
  timeSort:any=null;
  timeStyle="";
  // isLike;
  textSort1:string= 'records.contSortbyTimeDowm';
  textSort2:string= 'records.contSortbyThresholdDowm';
  mounted(){
    if(this.timeSortVisible){
      this.timeSort=0
      this.timeStyle="order"
    }else{
      this.similaritySort=0
      this.similarStyle="order"
    }
    if(this.isLike){
      this.timeSort=0
      this.similaritySort=0
      this.timeStyle=""
      this.similarStyle="order"
    }
  }
  @Emit("onsort")
   handletimeSort(){
      this.similaritySort=null
      this.similarStyle=""
      this.textSort2= 'records.contSortbyThresholdDowm';
    if(this.timeSort===null){
      this.timeSort=0
      this.timeStyle="order"
      this.textSort1= 'records.contSortbyTimeDowm';
    }else if(this.timeSort===0){
      this.timeSort=1
      this.timeStyle="invert-order"
      this.textSort1= 'records.contSortbyTimeUp';
    }else{
      this.timeSort=0
      this.timeStyle="order"
      this.textSort1= 'records.contSortbyTimeDowm';
    }
    return {timeSort:this.timeSort, similaritySort:this.similaritySort}
  }
  @Emit("onsort")
   handleSimilarSort(){
      this.timeSort=null
      this.timeStyle=""
      this.textSort1= 'records.contSortbyTimeDowm';
    if(this.similaritySort===null){
      this.similaritySort=0
      this.similarStyle="order"
      this.textSort2= 'records.contSortbyThresholdDowm';
    }else if(this.similaritySort===0){
      this.similaritySort=1
      this.similarStyle="invert-order"
      this.textSort2= 'records.contSortbyThresholdUp';
    }else{
      this.similaritySort=0
      this.similarStyle="order"
      this.textSort2= 'records.contSortbyThresholdDowm';
    }
     return {timeSort:this.timeSort, similaritySort:this.similaritySort}
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.sort-container{
  display: inline-flex;
  color: #a1aac5;
   .order{
      color: $--color-black;
    }
    .invert-order{
      color:$--color-black;
      .order-icon{
        transform:rotate(180deg);
        display: inline-block
      }

   }
  .can-click{
    cursor: pointer;
  };
  span{
    display: flex;
    align-items: center;
    justify-content: space-around;
    margin-right: 8px;
  }
}
.dark{
  .order{
    color: $--color-text-primary;
  }
  .invert-order{
    color:$--color-text-primary;
  }
}
</style>
