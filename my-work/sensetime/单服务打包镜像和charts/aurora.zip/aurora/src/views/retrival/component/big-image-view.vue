<template>
   <div v-if="isFullScreen" class="big-img-fullscreen">
      <Icon
        class="close-tab"
        type="ele"
        size="30"
        cursor="pointer"
        name="close"
        @click="cancelFullscreen"
      />
      <transition
        name="custom-classes-transition"
        enter-class="fadeIn"
        enter-to-class="fadeIn"
        leave-to-class="fadeOut"
        leave-class="fadeOut"
      >
        <img :src="url" alt="">
      </transition>
      <Icon
        v-show="!isAutoPlay"
        class="previous-page"
        type="ele"
        size="100"
        cursor="pointer"
        name="arrow-left"
        @click="viewPreviousImage"
      />
        <Icon
        v-show="!isAutoPlay"
        class="next-page"
        type="ele"
        size="100"
        cursor="pointer"
        name="arrow-right"
        @click="viewNextImage"
      />
      <Icon
        v-if="isAutoPlay"
        class="auto-play"
        size="50"
        cursor="pointer"
        name="pause"
        @click="handlePause"
      />
      <Icon
        v-else
        class="auto-play"
        size="50"
        cursor="pointer"
        name="play"
        @click="handleAutoPlay"
      />
    </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit,Prop } from 'vue-property-decorator';
import  Icon from '@/components/icon-wrap/index.vue';

@Component({
  components:{
    Icon
  },
})
export default class BigImageView extends Vue {
  @Prop({default:false}) isFullScreen!:boolean;
  @Prop({default:''}) url!:string;
  isAutoPlay=false;
  currentBigImgIndex:any=null;
  mounted(){

  }
  //暂停自动播放
  handlePause(){
    this.isAutoPlay=false;
    this.$emit("pause")
  }
  //取消查看大图
  cancelFullscreen(){
    this.$emit("close")
    this.isAutoPlay=false;
  }
  //开始自动播放
  handleAutoPlay(){
    this.isAutoPlay=true;
    this.$emit("play")
  }

  //查看前一张大图
  viewPreviousImage(){
    this.$emit("previousImg")
  }
  //查看后一张大图
  viewNextImage(){
    this.$emit("nextImg")
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
    .close-tab{
      position: absolute;
      right: 10px;
      top:10px;
      height:20px;
    }
    .big-img-fullscreen{
      position: fixed;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 10000;
      background: #000;
      padding: 150px;
      text-align: center;
      color: #fff;
      img {
        height: 100%;
        max-width: 100%;
      }
      .previous-page{
        position: absolute;
        display: inline-block;
        height: 100px;
        width: 100px;
        top: 40%;
        left: 10px;
      }
      .next-page{
        position: absolute;
        display: inline-block;
        height: 100px;
        width: 100px;
        top: 40%;
        right: 10px;
      }
      .auto-play{
        position: absolute;
        display: inline-block;
        height: 50px;
        width: 50px;
        bottom: 50px;
        right: 50%;
      }
    }
</style>
