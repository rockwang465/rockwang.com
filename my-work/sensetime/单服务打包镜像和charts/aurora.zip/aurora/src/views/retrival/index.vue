<template>
 <div class="retrivalAll">
    <!--  <el-menu

      class="el-menu-demo"
      mode="horizontal"
      text-color="#909399"
      active-text-color="#000"
      router
    >
      <el-menu-item index="face">人脸记录</el-menu-item>
      <el-menu-item index="pedestrian">行人记录</el-menu-item>
    </el-menu>
    <router-view></router-view>-->

    <el-tabs v-model="activeName" @tab-click="toRouter">
    <el-tab-pane :label="$t('messageCenter.face')" name="face">
    </el-tab-pane>
    <el-tab-pane :label="$t('messageCenter.pedestrian')" name="pedestrian">
    </el-tab-pane>
    <el-tab-pane :label="$t('messageCenter.vehicle')" name="vehicle">
    </el-tab-pane>
    <el-tab-pane :label="$t('messageCenter.nonMotor')" name="non-motor">
    </el-tab-pane>
    <el-tab-pane :label="$t('messageCenter.crowdRecord')" name="crowdRecord">
    </el-tab-pane>
  </el-tabs>
    <router-view></router-view>
 </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import {EventBus} from '@/utils/eventbus';

@Component
export default class retrivalAll extends Vue {
  activeName = "";

  mounted() {
    // console.log(window.location.pathname.split('/')[2]);

    this.activeName = window.location.pathname.split('/')[2];

    // console.log(this.activeName);

  }

  created() {
    EventBus.$on('retrivalVanName',data=>{
      // console.log(data);
      this.activeName = data
    })
  }

  toRouter(e :any) {

      // if(e.name == 'third') {
      //     this.$router.push({ path: 'pedestrian' })
      // }else if(){

      //   this.$router.push({ path: 'face' })
      // }
      let name = e.name
      switch (name) {
        case 'face':
          this.$router.push({ path: 'face' })
          break;
        case 'pedestrian':
          this.$router.push({ path: 'pedestrian' })
          break;
        case 'vehicle':
          this.$router.push({ path: 'vehicle' })
          break;
        case 'non-motor':
          this.$router.push({ path: 'non-motor' })
          break;
        case 'crowdRecord':
          this.$router.push({ path: 'crowdRecord' })
          break;
      }
  }

  handleSelect() {

  }
}

</script>

<style lang="scss" scoped>

.retrivalAll {
  height: 100%;
  // overflow: auto;
  padding: 10px;

  // .el-menu-demo{
  //   background: #fff !important;
  //   margin-left: 12px;
  //   li {
  //     height: 30px;
  //     line-height: 30px;
  //     background: #fff !important;
  //     &:hover {
  //       // background: #fff !important;
  //       color: #000 !important;
  //     }

  //   }
  //   .is-active::after{
  //     content: "";
  //     width: 100%;
  //     height: 2px;
  //     position: absolute;
  //     bottom: 0px;
  //     left: 0;
  //     border-radius: 3px 3px 0 0;
  //     background: #000;
  //   }
  // }


}
  ::v-deep  .big-img-container {
    background: #f5f7fc !important;
    border: 1px dashed #c2cad8;
  }
  ::v-deep .is-top{
    color: #909399;
    // padding-left: 6px;

    &:hover{
      color: #011C50
    }
    &.is-active {
      color: #011C50;
      font-weight:bold;
    }
    &.el-tabs__item  {
      height: 35px;
      // line-height: 30px;
      // font-size: 14px;
    }
  }

  ::v-deep .el-tabs__nav {
    // padding-left: 10px;
    margin-left: 20px;
    // transform: translateX(10px) !important;
  }

  ::v-deep .el-tabs__active-bar {
    // width: 76px !important;
    height: 3px;
    // transform: translateX(-5px)
    &::after {
      content:'';
      position: absolute;
      width: 10px;
      height: 3px;
      top: 0px;
      left: -10px;
      background-color: #011C50;
    }
    &::before {
      content:'';
      position: absolute;
      width: 10px;
      height: 3px;
      top: 0px;
      right: -10px;
      background-color: #011C50;
    }
  }

  ::v-deep .el-tabs__header {
    margin: 0px;
    padding: 0px 12px;
  }
  ::v-deep .el-tabs__nav-wrap::after {
    background-color:#000;
    height: 1px;
  }

  //tab忽然出现边框
  ::v-deep  .el-tabs__item:focus.is-active.is-focus:not(:active){
    -webkit-box-shadow: none ;
    box-shadow: none ;
  }
</style>
