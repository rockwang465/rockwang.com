<template>
  <el-dialog
    :class="{hidden:isHidden}"
    class="dialog-custom"
    :title="$t('records.buttonExport')"
    :visible.sync="visible"
    width="30%"
    :append-to-body="true"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    @close="cancelExport">
      <div class="input-container">
        <div class="export-label">{{this.$t("log.contQuantity")}}</div>
        <div class="start-num">
          <el-input
            @input="inputStartNum"
            :value="start"
            placeholder="">
          </el-input>
      </div>
       ~
      <div class="end-num">
        <el-input
          @input="inputEndNum"
          :value="end"
          placeholder="">
        </el-input>
      </div>
      </div>
      <div class="error-msg">{{errorMsg}}</div>
    <span slot="footer" class="dialog-footer">
      <el-button :disabled="disabled"  type="primary" @click="confirmExport">{{$t("records.buttonOK")}}</el-button>
      <el-button type="info" @click="cancelExport">{{$t("records.buttonCancel")}}</el-button>
    </span>
  </el-dialog>

</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import  Icon from '@/components/icon-wrap/index.vue';
import { setTimeout } from 'timers';

@Component({
  // props:{
  //   series:{
  //     type:Number,
  //     default:0
  //   },
  //   maxNum:{
  //     type:Number,
  //     default:1000
  //   },
  //   // handleExport:{
  //   //   type:Function,
  //   //   default:null,
  //   // }
  // }
})
export default class BatchExport extends Vue {
  @Prop({default:0}) series!:number;
  @Prop({default:1000}) maxNum!:number;
  @Prop({default:0}) isFaceNum !: number;
  // @Prop({default:null}) handleExport!:Function;
  isHidden=false;
  // handleExport:any;
  disabled=true;
  // maxNum:any;
  start="";
  end="";
  visible=false;
  errorMsg:any="";
  @Watch('series', {deep: true })
  onSeriesChanged(val, oldVal){
    if(val!==oldVal){
      this.visible=true;
    }
  }
  mounted(){
  }

  //输入验证
  inputStartNum(val){
    if(this.verifySize(val)){
      this.start = val
    }else{
      this.start = '';
    }
    this.disabled = this.varifyVoid() //设置按钮点击
  }
  //输入验证
  inputEndNum(val){
    if(this.verifySize(val)){
      this.end = val
    }else{
      this.end = '';
    }
    this.disabled = this.varifyVoid() //设置按钮点击

  }
  //验证是否为空
  varifyVoid(){
    if(this.start=="" || this.end==""){
      return true;
    }else{
      return false;
    }
  }
  //输入验证
  verifySize(val){
    // let reg = /^\d*$/
    let reg = /^([1-9]{1})\d*$/
    if(reg.test(val)|| val==""){
      this.errorMsg="";
      return true;
    }else{
      this.errorMsg= this.$t("records.exportError");
      this.disabled=true;
      setTimeout(()=>{
        this.errorMsg=""
      },2000)
      return false;
    }
  }

  //验证是否是有效数字
  verifyNumber(val){
    let reg = /^([1-9]{1})\d*$/
    if(reg.test(val)){
      this.errorMsg="";
      return true;
    }else{
      // this.errorMsg= this.$t('exportErrorMsg')
      this.errorMsg= this.$t("records.exportError")
      setTimeout(()=>{
        this.errorMsg=""
      },2000)
      return false;
    }
  }

  //提交 验证起始输入
  verifyInputStart(){
    if(!this.verifyNumber(this.start)){
      return false;
    }else{
       return true;
    }
  }
  //提交 验证结束输入
  verifyInputEnd(){
    if(!this.verifyNumber(this.end)){
      return false;
    }else if(Number(this.end)>this.maxNum){
      //验证是否大于总条数
      this.errorMsg= this.$t("log.exportError3",{number:this.maxNum});
      setTimeout(()=>{
        this.errorMsg=""
      },2000)
      return false;
    }else{
      return true;
    }
  }

  //提交验证,起始大于等于结束 结束减去起始大于999条
  verifyStartEnd(start,end){
    if(!this.verifyInputStart()){
      return false;
    } else if(!this.verifyInputEnd()){
      return false;
    }else if(start>end) {
      this.errorMsg =　this.$t("log.exportError2");
       setTimeout(()=>{
        this.errorMsg=""
      },2000)
      return false;
    }else if(end-start>999){
      if(!this.isFaceNum) {
        this.errorMsg =　this.$t('log.exportError5', {number: 1000});
        setTimeout(()=>{
          this.errorMsg=""
        },2000)
        return false;
      } else {
        if(end-start>this.isFaceNum-1) {
          this.errorMsg =　this.$t('log.exportError5', {number: this.isFaceNum});
          setTimeout(()=>{
            this.errorMsg=""
          },2000)
          return false;
        } else {
          return true;
        }
      }
    } else{
      return true;
    }
  }

  //开始导出
  confirmExport(){
    let start = Number(this.start)
    let end = Number(this.end)
    if(this.verifyStartEnd(start,end)){
      this.isHidden=true;
      setTimeout(()=>{
        this.isHidden=false;
      },1100)
      // //如果有处理函数
      //   if(this.handleExport){
      //     this.handleExport(start,end).then(()=>{
      //     this.$message({
      //       message: this.$t("log.exportSuccess") as string,
      //       type: 'success',
      //       duration: 3 * 1000,
      //   });
      //   })
      // }else{
      //    this.$emit("export",start,end)
      // }
      console.log(start,end);

      this.$emit("export",start,end)
      this.cancelExport()
    }
  }
  cancelExport(){
    this.$emit("cancel")
    this.visible=false;
    this.start="";
    this.end="";
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
.dialog-custom{
    // display:block !important;
    width:100%;
    height:100%;
  }
  .hidden {
    display:block !important;
    position:absolute;
    top:-10%;
    bottom:110%;
    right:5%;
    left:95%;
    width:0;
    height:0;
    overflow:hidden;
    transition:all 1s;
    ::v-deep .el-dialog{
      min-width:30%;
      height:30%;
      overflow:hidden;

    }
  }

 .input-container{
      width: 70%;
      margin: 0 auto;
      .export-label{
        display: inline-block;
        width: 20%;
        text-align: right;
        box-sizing: border-box;
        text-align: left;
      }
      .start-num{
        display: inline-block;
        width: 35%;
      }
      .end-num{
        display: inline-block;
        width: 35%;
      }
    }
    .error-msg{
      margin-top:5px;
      height: 20px;
      text-align:center;
      color: $--color-danger;
    }
</style>
