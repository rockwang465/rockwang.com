<template>
   <transition
    name="custom-classes-transition"
    enter-class="hidden"
    enter-to-class="show"
    leave-to-class="hidden"
    leave-class="show"
    v-on:enter="afterEnter"
   >
  <div ref="detail" v-if="display" class="record-detail">
      <Icon
        class="close-tab"
        type="ele"
        size="30"
        cursor="pointer"
        name="close"
        @click="collapseDetail"
      />
      <div class="detail-container">
        <!-- <div class="current-compare">
          <div class="two-Image">
            <two-image
              :percentage="toPercentage(currentCapture.score)"
              :originImg="data.picUrl"
              :targetImg="currentCapture.url"
              :cardType="convertCardType(currentCapture.confirmationStatus)"
              :compareType="currentCapture.compareType"
              :percentageSize=16
              :hasText="false"
              @cancel-success="cancelSuccess"
              @cancel-failed="cancelFailed"
              @success="handleSuccess"
              @failed="handleFailed"
            />
          </div>
          <div class="current-compare-detail">
          <div class="detail-item">
              <p>
                <b>{{$t("records.frequency")}}:</b>
                <span v-if="currentCapture.preCaptureDate">2</span>
                <span v-else="currentCapture.preCaptureDate">1</span>
              </p>
            </div>
            <div class="detail-item">
              <p>
                <b>{{$t("records.contTime")}}:</b>
                <span>
                <i v-if="currentCapture.preCaptureDate">
                  {{currentCapture.preCaptureDate}} <br/>
                </i>
                {{currentCapture.captureDate}}
                </br>

                </span>
              </p>
              <p>
                <b>ID:</b>
                <span>{{currentCapture.id}}</span>
              </p>
            </div>
            <div class="detail-item">
              <p>
                <b>{{$t("records.contDevice")}}:</b>
                <span>{{currentCapture.place}}</span>
              </p>

              <p>
                <b>{{$t("records.contName")}}:</b>
                <span>{{currentCapture.userName}}</span>
              </p>
            </div>
            <div class="detail-item">
              <p>
                <b>{{$t("records.contRuleSet")}}:</b>
                <span>{{currentCapture.ruleName}}</span>
              </p>
              <p>
                <b>{{$t("records.contImageLibrary")}}:</b>
                <span>{{currentCapture.targetLibraryName}}</span>
              </p>
            </div>
            <div v-if="currentCapture.faceAttributeInfo.age" class="detail-item">
              <p>
                <b>{{$t("records.moreAttr")}}</b>
                <el-popover
                  placement="right-start"
                  trigger="hover"
                >
                  <div>
                    <p>{{$t("records.age")}}：{{$t("records."+currentCapture.faceAttributeInfo.age)}}</p>
                    <p>{{$t("records.gender")}}：{{$t("records."+currentCapture.faceAttributeInfo.gender)}}</p>
                    <p>{{$t("records.color")}}：{{$t("records."+currentCapture.faceAttributeInfo.skinColor)}}</p>
                  </div>
                  <i slot="reference" style="margin-left: 5px;" class="iconfont icon-view"></i>
              </el-popover>
              </p>
            </div>
          </div>
          <div class="current-compare-detail-other">
            <div class="detail-item">
              <b>{{$t("records.contNotifyType")}}:</b>
              {{$t(CompareTypeconvert(currentCapture.compareType))}}
            </div>
            <div class="detail-item">
              <b>{{$t("records.contOperationType")}}:</b>
              {{$t(convertOperateType(currentCapture.confirmationStatus))}}
            </div>
            <div class="detail-item">
              <b>{{$t("records.operator")}}:</b>
              {{currentCapture.operatorName?currentCapture.operatorName:username}}
            </div>
          </div>
        </div> -->
          <span class="textCompare">
            <i class="iconfont icon-device-pes"></i>
          {{$t("records.captureRecords")}}
          </span>
        <currentCompare :capture='currentCapture'></currentCompare>
        <div class="detail-list">
          <div class="record-detail-top">
            <div class="record-detail-title">

                <i style="font-size:20px ; " class="iconfont icon-device-pes"></i>
              <span class="title-main">
                {{$t("records.contRelatedRecord")}}
              </span>
              <span>
                 {{$t("records.contTotal")}}
                 <span style="font-size:16px;padding:5px">{{totalCapture}}</span>
                 {{$t("records.contRecords")}}
              </span>
              <sort
                @onsort="handleSort"
              />
            </div>
            <div class="batch-export">
              <el-button
               @click="generateTrack"
               size="mini"
               type="primary">
                <Icon
                    name="locus"
                  />
                  {{$t("records.titleFootfall")}}
              </el-button>
              <el-button
                v-if="$permission('015305')"
               @click="showExportDialog"
               size="mini"
               type="primary">
                <Icon name="batch-export"/>
                  {{$t("records.buttonExport")}}
              </el-button>
            </div>
          </div>
          <div class="capture-list" >
            <div class="empty-notice" v-if="captureList.length==0">
              【{{$t("records.contNoImage")}}】
            </div>
            <carousel
              v-else
              :data="captureList"
              @click="viewCaptureDetail"
              @slide="viewCaptureMore"
            />
          </div>
          <div v-if="currentCapture.bigPicture" class="capture-detail">
            <div class="capture-big-img">
              <div  class="capture-big-img-top">
                <span>{{$t("records.contDevice")}}:
                  <!-- {{currentCapture.devicePlaceInfo.name}} -->
                  <!-- {{currentCapture.devicePlaceInfo.subDevice && currentCapture.devicePlaceInfo.subDevice.deviceName  ? currentCapture.devicePlaceInfo.subDevice.deviceName : currentCapture.devicePlaceInfo.name}} -->
                  {{ currentCapture.deviceInfo && currentCapture.deviceInfo.device && currentCapture.deviceInfo.device.subDevice && currentCapture.deviceInfo.device.subDevice.deviceName  ? currentCapture.deviceInfo.device.subDevice.deviceName : currentCapture.devicePlaceInfo.name}}
                  </span>
                <span>{{currentCapture.preCaptureDate?currentCapture.preCaptureDate:currentCapture.captureDate}}</span>
              </div>
              <div class="big-img-container">
                 <!--<img :src="processImgurl(currentCapture.bigPicture.imgUrl)" alt="">-->
                <canvas style="height:100%" id="cvs" ref="cvs"></canvas>
                <div class="big-img-container-btn">
                    <el-button
                      size="mini"
                      type="primary"
                      @click="handleFullscreen"
                      >
                      <Icon  name="fullscreen"></Icon>
                      {{$t("records.buttonFullScreen")}}
                     </el-button>
                    <el-button size="mini" type="primary" @click="downloadBigImage(currentCapture)">
                     <Icon name="download"></Icon>{{$t("records.buttonPictureDownload")}}
                    </el-button>
                </div>
                <div v-if="isFullScreen" class="big-img-fullscreen">
                  <Icon
                    class="close-tab"
                    type="ele"
                    size="30"
                    cursor="pointer"
                    name="close"
                    style="color:#fff"
                    @click="cancelFullscreen"
                  />
                  <transition
                    name="custom-classes-transition"
                    enter-class="fadeIn"
                    enter-to-class="fadeIn"
                    leave-to-class="fadeOut"
                    leave-class="fadeOut"
                  >
                    <img :src="processImgurl(currentCapture.bigPicture.imgUrl)" alt="">
                  </transition>
                  <Icon
                    v-show="!isAutoPlay"
                    class="previous-page"
                    type="ele"
                    size="100"
                    cursor="pointer"
                    name="arrow-left"
                    @click="viewPreviousImage"
                  />
                   <Icon
                    v-show="!isAutoPlay"
                    class="next-page"
                    type="ele"
                    size="100"
                    cursor="pointer"
                    name="arrow-right"
                    @click="viewNextImage"
                  />
                  <Icon
                    v-if="isAutoPlay"
                    class="auto-play"
                    size="50"
                    cursor="pointer"
                    name="pause"
                    @click="handlePause"
                  />
                  <Icon
                    v-else
                    class="auto-play"
                    size="50"
                    cursor="pointer"
                    name="play"
                    @click="handleAutoPlay"
                  />
                </div>
              </div>
            </div>
            <div class="path-track">
              <div class="path-track-top">
                <span>{{$t("records.contMap")}}:{{currentCapture.place}}</span>
              </div>
               <div class="path-track-container">
                 <map-device handleType="view" :deviceInfo="[currentCapture.devicePlaceInfo]" :key="currentCapture.devicePlaceInfo.id"/>
              </div>
            </div>
        </div>
        </div>
      </div>
    <track-select
      :data="captureList"
      :showTrackDialog="showTrackDialog"
      @cancel="cancelTrackDialog"
      @toSelectTrackInfo = "generateTrack"
      trackType="library"
    />
    <batch-export
      :series="dialogTrigerNumber"
      @export="doExportRecord"
      :maxNum="totalCapture"
    />
  </div>
</transition>
</template>

<script lang="ts">
import { Component, Vue, Watch, Emit ,Prop} from 'vue-property-decorator';
import { scrollTo, scrollIntoView  } from 'scroll-js';
import  TwoImage from '@/components/two-image/index.vue';
import  Icon from '@/components/icon-wrap/index.vue';
import  SnDialog from '@/components/sn-dialog/index.vue';
import { convertCardType, toPercentage } from '@/utils/small-tool';
import { Cache } from '@/utils/cache';
import   { historyStore }  from '@/store/modules/history-record';
import   TrackSelect  from '../../component/track-selected.vue';
import   Carousel  from '../../component/carousel.vue';
import BatchExport from '../../component/batch-export.vue';
import Sort from '../../component/sort.vue';
import { processImgurl } from '@/utils/image';
import MapDevice from '../../../manage/map/map-device.vue';
import { clearInterval } from 'timers';
import dayjs from 'dayjs';
var _ = require('lodash/lang');
import currentCompare from '@/components/three-image/index.vue';
import log from '../../../../api/log';

@Component({
  // props:{
  //   display:{
  //     type:Boolean,
  //     default:false
  //   },
  //   data:{
  //     type:Object,
  //     default(){
  //       return {};
  //     }
  //   },
  //   triggerEle:{
  //     type:MouseEvent,
  //     default(){
  //       return {};
  //     }
  //   },
  //    captureList:{
  //     type:Array,
  //     default(){
  //       return [];
  //     }
  //   },
  //   totalCapture:{
  //     type:Number,
  //     default:0
  //   }
  // },
  components: {
    TwoImage,
    Icon,
    SnDialog,
    Carousel,
    TrackSelect,
    BatchExport,
    MapDevice,
    Sort,
    currentCompare
  },
})
export default class RecordDetail extends Vue {
  @Prop({default:false}) display!:boolean;
  @Prop({default(){return {}}}) data!:object;
  @Prop({default(){return {}}}) triggerEle!:MouseEvent;
  @Prop({default(){return []}}) captureList!:any[];
  @Prop({default:0}) totalCapture!:number;

  dialogTrigerNumber=0;
  timer:any = null;
  isAutoPlay=false;
  showImg=true;
  currentBigImgIndex:any=null;
  isFullScreen:boolean=false;
  // data:any;
  // triggerEle:any;
  convertCardType=convertCardType;
  toPercentage=toPercentage;
  // captureList:any;
  currentCapture={}
  showTrackDialog=false;
  processImgurl=processImgurl;
  // devicePlaceInfo=[{
  //   name:"5楼电梯",
  //   id:"1",
  //   floorId:216,
  //   position:{
  //     lng:this.$_.random(500,800),
  //     lat:400,
  //   }
  // }];
  username:string=Cache.sessionGet('userInfo').username || '';
  refs !:{
    cvs:HTMLFormElement
  }
  mounted(){
    console.log(this.data)
  }
  @Watch('triggerEle')
  viewStateChanged(val: string, oldVal?: string) {
  }
  @Watch("data", { immediate: true })
  collapseDetailChange(val,oldVal){
    this.currentCapture=val
    this.currentBigImgIndex=null;
  }
  @Watch("currentCapture", { immediate: true,deep:true })
  currentCaptureChange(val,oldVal){
    console.log(val)
    if(val.bigPicture){
      this.drawImageFace(val.bigPicture)
    }
  }
  @Watch("display", { immediate: true,deep:true })//fix bug # v-if=display the canvas will be destory and when show the data not change and method will be not emit
  displayChange(val,oldVal){
    val && this.currentCapture && (this.currentCapture as any).bigPicture && this.drawImageFace((this.currentCapture as any).bigPicture);
  }

  @Emit("sort")
  handleSort(param){
    return param
  }


  @Emit("collapse")
    collapseDetail(){ //详情
    // this.currentCapture={};
  }

   @Emit()//点击取消比中
    cancelSuccess(){
      return this.currentCapture
    }

    @Emit() //点击取消未比中
    cancelFailed(){
      return this.currentCapture
    }

    @Emit("success") //点击比中
    handleSuccess(){
     return this.currentCapture
    }

    @Emit("failed") //点击未比中
    handleFailed(){
      return this.currentCapture
    }

    drawImageFace(pic){
      let img = new Image;
      img.src = processImgurl(pic.imgUrl);
      let attr = pic.portraitImageCoordinateInfo;
      Vue.nextTick(()=>{
        // let canvas:any = document.getElementById("cvs");
        let canvas:any = this.$refs.cvs;//fix bug
        let that = this;
        img.onload=function(){
          if(canvas){
            canvas.width = img.width;
            canvas.height = img.height;
            let ctx = canvas.getContext("2d");
            (ctx as any).drawImage(img, 0,0,img.width,img.height)
            ctx.strokeStyle = "#F00";
            ctx.setLineDash([4, 4]);
            ctx.lineWidth = 5;
            ctx.strokeRect(attr.startX, attr.startY, attr.endX-attr.startX, attr.endY-attr.startY);
          }
        }
      })

    }

    convertOperateType(val){
      switch(val){
       case 0:
       return ""
       case 1:
       return "records.lsitOperationTypeRead";
       case 2:
       return "records.lsitOperationTypeMatched";
       case 3:
       return "records.lsitOperationTypeUnmatched";
     }
    }
    CompareTypeconvert(val){
      let compareType = ""
     switch(val){
       case "0":
       compareType="records.listNotifyTypeNormal"
       break;
       case "1":
       compareType="records.listNotifyTypeStranger";
       break;
       case "2":
       compareType="records.listNotifyTypeFaceSpoof";
       break;
       case "3":
       compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
       compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
       compareType="records.listNotifyTypeBlacklist";
       break;
     }
     return compareType
    }
    handlePause(){
      this.stopTimer()
    }
     handleAutoPlay(){
      this.isAutoPlay=true;
      this.timer = setInterval(()=>{
        this.viewNextImage()
      },1000)
    }
    //停止定时器
    stopTimer(){
      this.isAutoPlay=false;
      this.timer && window.clearInterval(this.timer)
    }
    //查看前一张大图
    viewPreviousImage(){
       if(this.currentBigImgIndex==null){
        this.currentBigImgIndex=0
      }else if(this.currentBigImgIndex>0){
        this.currentBigImgIndex--
      }
      this.currentCapture = this.captureList[this.currentBigImgIndex]?this.captureList[this.currentBigImgIndex]:this.currentCapture
    }
    //查看后一张大图
    viewNextImage(){
      if(this.currentBigImgIndex==null){
        this.currentBigImgIndex=0
      }else if(this.currentBigImgIndex<this.captureList.length-1){
        this.currentBigImgIndex++
      }
      this.currentCapture = this.captureList[this.currentBigImgIndex] ?this.captureList[this.currentBigImgIndex]:this.currentCapture
    }
    cancelFullscreen(){
      this.stopTimer()
      this.isFullScreen=false
    }
    handleFullscreen(){
      this.stopTimer()
      this.isFullScreen=true
    }
    downloadBigImage(obj){
      this.imgToBase64(processImgurl(obj.bigPicture.imgUrl)).then((base64)=>{
        let ele = document.createElement("a")
        let t= dayjs().format('YYYYMMDD_HHmmss')
        ele.setAttribute('download', 'Capture_Image_Big_'+t)
        ele.href  = base64 as string
        ele.click()
      })
    }

  imgToBase64(url){
   return  new Promise((resolve,reject)=>{
      let img = new Image;
      img.crossOrigin="Anonymous";
      img.src = url;
      let reg = /^data:image/
      let canvas = document.createElement("canvas");
      if(!reg.test(url)){
        let that = this;
        img.onload=function(){
          canvas.width = img.width;
          canvas.height = img.height;
          let ctx = canvas.getContext("2d");
          (ctx as any).drawImage(img, 0,0,img.width,img.height)
          resolve(canvas.toDataURL("image/jpeg"))
        }
      }else{
        resolve(url)
      }
    })

  }
  afterEnter(){
      // scrollTo(this.triggerEle.path[7], {top:this.triggerEle.path[5].offsetTop}).then(function() {
      // });
  }
  showExportDialog(){
    this.dialogTrigerNumber = Math.random()
  }
  doExportRecord(start,end){
    this.$emit("export",start,end)
  }
  viewCaptureMore(val){
    this.$emit("slide",val)
  }
  //点击图片查看详情
  viewCaptureDetail(data,key){
    this.currentBigImgIndex=key
    this.currentCapture=data;
  }
  //显示轨迹生成弹框
  generateTrack(){
    this.showTrackDialog=true;
  }
  //关闭轨迹生成弹窗
  cancelTrackDialog(){
    this.showTrackDialog=false;
  }
  showTrackMap(){

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
  .fadeIn{
    opacity: 1;
    transition: all 1s;
  }
  .fadeOut{
    opacity: 0;
    transition: all 1s;
  }
  .hidden{
    height: 0 !important;
    opacity: 0;
    transition: all  .3s;
    overflow: hidden;
  }
  .show{
    height: 600px !important;
    opacity: 1;
    transition: all .3s;
    overflow: hidden;
  }
  .record-detail{
    margin-top: 12px;
    height: 630px;
    width: 99%;
    margin-left:4px;
    // overflow: scroll;
    // background: #495d83;
    background: rgba(242,246,253,1);
    // color: $--color-white;
    position: relative;
    padding-top:10px;
    box-sizing: border-box;
    border:1px solid rgba(223,223,224,1);
    // box-shadow:0px 3px 6px rgba(0,0,0,0.16);
    .can-click{
      cursor: pointer;
    };
    .close-tab{
      position: absolute;
      right: 10px;
      top:10px;
      height:20px;
    }
    .detail-container{
      display: flex;
      height:100%;
      .current-compare{
        //  height:100%;
         width: 14%;
         padding:20px 25px 0px;
         overflow: scroll;
        .two-Image{
          width: 400px;
          height: 240px;
          margin: 0 auto;
        }
        .current-compare-detail{
          width: 400px;
          margin: 0 auto;
          padding:10px 0;
          .detail-item{
            margin: 10px 5px;
            display: flex;
            p{
              display: flex;
              width:50%;
              word-wrap:break-word;
              b{
                word-wrap:break-word;
                padding: 3px;
                white-space:nowrap;
                font-weight: 600;
              }
              span{
                word-wrap:break-word;
                padding: 3px;
                display: block;
                width:80%;
                i{
                  font-style:normal;
                }

              }

            }
          }
        }
        .current-compare-detail-other{
          width: 400px;
          height:100px;
          margin: 0 auto;
          padding:10px 0;
          border-top: 2px solid #55678a;
          .detail-item{
            margin: 10px 5px;
            b{
              word-wrap:break-word;
              padding: 3px;
              white-space:nowrap;
              font-weight: 600;
            }
        }
        }
      }
     .detail-list{
        width: 70%;
        height: 100%;
        padding: 0 20px;
        box-sizing: border-box;
        .record-detail-top{
          display: flex;
          justify-content: space-between;
          margin: 5px;
          padding-left: 5px;
          .record-detail-title{
            .title-main{
              font-size: $--font-size-card;
              font-weight: 700;
              // color: #fff;
            }
            span{
              padding-right: 10px;
              // color: #fff;
            }
          }
          .batch-export{
            margin-right: 50px;
            span{
              padding-left: 5px;
              padding-right:10px
            }

          }
        }
        .capture-list{
         min-height: 29%;
         margin: 10px 30px;
         background: rgba($menuBg,.2);
         .empty-notice{
           text-align: center;
           line-height: 150px;
         }
       }
      .capture-detail{
        display: flex;
        height:58%;
        .capture-big-img{
          // background-color: #000;
          // color: #fff;
          padding: 10px;
          width: 50%;
          height: 100%;
          box-sizing: border-box;
          overflow: hidden;
          .capture-big-img-top{
            display: flex;
            justify-content: space-between;
            // margin-bottom: 10px;
            background-color: #011C50;
            line-height: 28px;
            color: #fff;
            padding: 0 20px 0 10px;
          }
          .big-img-container{
            height: 93%;
            width:100%;
            position: relative;
            text-align: center;
            background: #28354D;

            img {
              height: 100%;
              max-width: 100%;
            }
            .big-img-container-btn{
              position: absolute;
              bottom: 10px;
              left: 10px;
            }
            .big-img-fullscreen{
              position: fixed;
              top: 0;
              bottom: 0;
              right: 0;
              left: 0;
              z-index: 10000;
              background: #000;
              padding: 150px;
              text-align: center;
              .previous-page{
                position: absolute;
                display: inline-block;
                height: 100px;
                width: 100px;
                top: 40%;
                left: 10px;
              }
              .next-page{
                position: absolute;
                display: inline-block;
                height: 100px;
                width: 100px;
                top: 40%;
                right: 10px;

              }
              .auto-play{
                position: absolute;
                display: inline-block;
                height: 50px;
                width: 50px;
                bottom: 50px;
                right: 50%;
              }
            }
          }
        }
        .path-track{
          width: 50%;
          height: 100%;
          padding: 10px;
          box-sizing: border-box;
          overflow: hidden;
          .path-track-top{
            display: flex;
            justify-content: space-between;
            // margin-bottom: 10px;
            height: 28px;
            background-color: #011c50;
            line-height: 28px;
            color: #fff;
            padding: 0 10px;
          }
          .path-track-container{
            height: 93%;
            // background: rgba($menuBg,.2);
            .empty-notice{
              text-align: center;
              line-height: 280px;
            }
          }
        }
      }
     }
    }
  }

  .textCompare{
    position: absolute;
    /* display: flex; */
    left: 9%;
    top: 20px;
    font-size: 16px;
    color: #fff;
  }

  ::v-deep .device-wrapper{
    padding: 0px;
  }
</style>
