<template>
  <div ref="fullScreenElement" class="dashboard-container" :class="{'box-shadow-inner':!isFullScreen}">
    <div class="page-header" ref="dashboardHeader">
      <h1 class="page-title">SenseNebula-G 智能安防一体机</h1>
    </div>
    <div class="charts">

      <div class="chart-grid">
        <div class="chart-item">
          <!-- 地图 -->
          <!-- <h2 class="item-title">
            此区域待定
            {{$tc('dashboard.map.title')}}
          </h2> -->
          <div class="map">
            <map-layer></map-layer>
          </div>
        </div>
        <div class="chart-item">
          <!-- 今日抓拍 -->
          <h2 class="item-title">
            {{$tc('dashboard.today.title')}}
            <!-- $permission('006345') -->
            <router-link v-if="hasRouterPermission('monitor')" class="more-right title-right" to="/monitor"> <i class="arr-right el-icon-r"></i> {{$t('dashboard.viewMoreMonitor')}}</router-link>
          </h2>
          <ul class="torus item-content">
            <li v-for='item in captureList' :key='item.id'>
              <svg width="90%" height="90%" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="borderlinear">
                    <stop offset="0%" stop-color="#0F4C81"/>
                    <stop offset="80%" stop-color="#4C8EC9"/>
                  </linearGradient>
                </defs>
                <circle v-if="item.percent && item.percent>0" class="circle-progress" :stroke-dasharray="item.percent + '% 300%'" cx="50%" cy="50%" r="46%" />
                <circle ref="circlePath" class="circle-bg" cx="50%" cy="50%" r="46%" />
              </svg>
              <div class="flex">
                <number-slide :growValue="item.count"></number-slide>
              </div>
              <!-- <span>{{item.count}}</span> -->
              <em>{{$t('dashboard.captureTypes')[item.captureType-1]}}</em>
            </li>
          </ul>
        </div>
      </div>

      <div class="chart-grid">
        <div class="chart-item device-chart">
          <!-- 设备 -->
          <h2 class="item-title">
            {{$tc('dashboard.device.title')}}
            <!--$permission('007107')-->
            <router-link v-if="hasRouterPermission('device')" class="more-right title-right" to="/manage/device"> <i class="arr-right el-icon-r"></i> {{$t('dashboard.viewMore')}}</router-link>
          </h2>
          <div class="ve-device">
            <ve-pie :settings="pieSettings" :resize-delay="200" :colors="pieColors" :extend="pieExtend" height="100%" width="100%"></ve-pie>
          </div>
          <div class="device-statistics">
            <dl class="right-line">
              <dt>{{$t('dashboard.device.deviceTotal')}}</dt>
              <dd>{{deviceData.total}}</dd>
            </dl>
            <dl class="right-line">
              <dt>{{$t('dashboard.device.deviceOnline')}}</dt>
              <dd>{{deviceData.online}}</dd>
            </dl>
            <dl>
              <dt>{{$t('dashboard.device.deviceOffline')}}</dt>
              <dd>{{deviceData.offline}}</dd>
            </dl>
          </div>

        </div>
        <div class="chart-item">
          <h2 class="item-title">{{$t('dashboard.portraitLibrary.title')}}</h2>
          <div class="item-content">
            <div class="item-center">
              <dl class="progress-dl" v-for="item in capacityData" :key="item.id">
                <dt>
                  {{$t('dashboard.capacityTypes')[item.capacityType-1]}}
                  <!-- {{capacityName[item.capacityType]}} -->
                  <span class="more-right numbers">{{item.used}} / {{item.total/1000+'k'}}</span>
                </dt>
                <dd class="progress-dashed">
                  <span :style="'width:' + (item.used/item.total)*100 + '%'"></span>
                </dd>

              </dl>
              <!-- <dl class="progress-dl">
                <dt>{{$tc('dashboard.portraitLibrary.whiteList')}}</dt>
                <dd class="progress-dashed"></dd>
                <dd class="numbers">130.5k/200k</dd>
              </dl>
              <dl class="progress-dl">
                <dt>{{$tc('dashboard.portraitLibrary.snapshotList')}}</dt>
                <dd class="progress-dashed"></dd>
                <dd class="numbers">130.5k/200k</dd>
              </dl> -->
            </div>
          </div>
        </div>
      </div>

      <div class="chart-grid">
        <div class="chart-item event-chart-layer">
          <!-- 事件告警 -->
          <h2 class="item-title">
            {{$tc('dashboard.event.title')}}
            <!-- $permission('009301') -->
            <router-link v-if="hasRouterPermission('retrival')" class="more-right title-right" to="/retrival"> <i class="arr-right el-icon-r"></i> {{$t('dashboard.viewMore')}}</router-link>
          </h2>
          <div class="event-chart">
            <div class="event-chart-head">
              <div class="event-legend">
                <em>{{$t('dashboard.event.viewed')}}</em>
                <em>{{$t('dashboard.event.noView')}}</em>
              </div>
              <div class="select-date">
                <em @click="selectDate(index)" v-for="(index,item) in dayLabel" :class="{current:index==currentIndex}" :key="item.id">
                  {{$t('dashboard.dayTypes')[index-1]}}
                  <!-- {{item}} -->
                </em>
              </div>
            </div>

            <div class="event-data-list" v-loading="loading" element-loading-background="rgba(30,28,72,.2)">
              <dl v-for="item in eventData" :key="item.id">
                <dt :class="{opacity:item.totalCount == 0}">{{$t('dashboard.eventTypes')[item.eventType-1]}} <span class="more-right">{{item.checkCount}} / {{item.notCheckCount}}</span> </dt>
                <dd class="progress-bg">
                  <span :style="'width:' + (item.checkCount/item.totalCount)*100 + '%'" class="progress-inner-left"></span>
                  <span :style="'width:' + (item.notCheckCount/item.totalCount)*100 + '%'" class="progress-inner-right"></span>
                </dd>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="btn-full-screen" @click="toggleFullScreen">
      <template v-if="!isFullScreen">
        <i class="iconfont icon-to-fullscreen"></i>
        <span class="to-full">全屏</span>
      </template>
      <template v-else>
        <i class="iconfont icon-exit-fullscreen"></i>
        <span class="exit-full">退出</span>
      </template>
    </div>
    <div class="date-panel" v-if="isFullScreen">
      <strong class="time">{{dateObj.time}}</strong>
      <p class="date">{{dateObj.date}} {{dateObj.week}}</p>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import {VePie} from 'v-charts';
import mapLayer from '@/components/mapLayer/index.vue';
import { AppModule } from '@/store/modules/app';
import dayjs from "dayjs";
import {deviceType,passDeviceType} from '@/utils/constants';
import i18n from '@/lang/index'
import Api from '@/api/dashboard';
// import screenfull from 'screenfull';
// console.log(screenfull)

import NumberSlide from '@/components/numberSlide/index.vue'
import {roleModulesCode} from '@/router/moduleCode';
//console.log(roleModulesCode)

interface DeviceItem {
  value: number;
  name:string;
}
enum captureTypes {
  '人脸'=1,
  '行人'=2,
  '车辆'=3,
  '非机动车'=4
}

// enum deviceTypes {
//   Camera=1,
//   SenseKeeper=2,
//   'SenseNebula-M' =3,
//   SenseDLC =4,
//   SenseID =5,
//   PASS = 6
// }
enum capacityTypes {
  '白名单库容'=1,
  '黑名单库容'=2,
  '抓拍库容'=3
}

enum eventTypes {
  '白名单比中'=1,
  '陌生人告警'=2,
  '非活体攻击'=3,
  '密码攻击'=4,
  '白名单异常'=5,
  '黑名单告警'=6,
  '行人通行'=7,
  '行人越线'=8,
  '行人区域入侵'=9,
  '机动车通行'=10,
  '机动车违停'=11,
  '非机动车通行'=12,
}
enum dayTypes {
  '本月'='1',
  '本周'='2',
  '本日'='3'
}
//console.log(typeof i18n.tc('deviceType.Camera'))
//let SenseKeeper22 = i18n.t('deviceType');
//console.log(SenseKeeper22)
enum deviceEnum {

}
//
//console.log(deviceEnum)

@Component({
  components: {
    VePie,
    mapLayer,
    NumberSlide
  }
})
export default class Dashboard extends Vue {
  loading = true;
  dateObj:any = {}
  pieSettings = {
    level: []
  }
  //pieColors = ['#01B4B7','#E084A9','#4C8EC9','#FFB592']
  // pieColors = ['#08BDFF','#4D6EC6','#FFB592','#4B779F','#E084A9','#01B4B7','#9D588A','#4d6ec6','#08bdff','#ffffff','#c4ccd3']
pieColors = [
'#08BDFF',
'#4D6EC6',
'#FFB592',
'#4B779F',
'#E084A9',
'#01B4B7',
'#9D588A',
'#FFFFFF',
'#4139A2',
'#FF654A',
'#08BDFF',
'#CED1A8']
  pieExtend = {
    // title: {
    //   text: '设备图表',
    //   top: 'center',
    //   left: 'center'
    // },
    legend: {
      type: 'scroll',
      textStyle: {
        color: "#fff",
        lineHeight:20
      },
      orient: 'vertical',
      left: '3%',
      bottom:'5%',//解决英文最下边一行设备名称与设备统计重叠
      itemWidth: 12,
      itemHeight: 12,
      icon:'rect',
      data:[],
      height:110,
      pageTextStyle:{
        color:'white'
      },
      pageIconInactiveColor:'#2f4554',
      pageIconColor:'#aaa'
    },
    series: [
      {
        radius:[69.3,70],
        type:'pie',
        center: ['50%', '40%'],
        label:{
          normal: {
            position: 'center',
            color:'#fff',
            formatter: '{c|{c}} \n {b|{b}}',
            rich: {
              c:{
                fontSize: 22,
                color:'#fff',
                lineHeight:30,
              }
            },
          },
        },
        itemStyle: {
          color:'#8d8ca2'
        },
        data:[
          {name:i18n.t('dashboard.device.deviceOnline'),value:0},
        ]
      },
      {
        name:'DeviceType',
        radius:[80,108],
        type:'pie',
        center: ['50%', '40%'],
        //avoidLabelOverlap: false,

        label:{
          normal:{
            formatter:(item)=>{
              if(item && item.data && item.data.name){
                let titleName = item.data.name;
                if(titleName.length > 20){
                  let tempArr = titleName.split('Machine');
                  let end = tempArr.slice(-1)
                  console.log(tempArr)
                  titleName = tempArr[0] +'\nMachine'+ end
                }
                let str = '{a|'+titleName + ': }{b|'+ item.data.value+'}'
                return str
              }
            },
            rich: {
              a:{
                align: 'left',
                verticalAlign:'middle',
                color:'white'
              },
              b:{
                fontSize: 22,
                color:'white'
              }
            }
          }
        },
        data:[
          // { label:'A',name: '设备类型A',  value: 1393 },
          // { label:'B',name: '设备类型B',  value: 3530 },
          // { label:'C',name: '设备类型C',  value: 2923 },
          // { label:'D',name: '设备类型D',  value: 1723 },
        ]
      }
    ]
  }
  isFullScreen:boolean = false;
  @Watch('isFullScreen')
  onFullScreenChanged(n, o) {
    //console.log('onFullScreenChanged=>isFullScreen:',n)
  };

  @Watch('headDisplay')
  onHeadDisplayChanged(n, o) {
    if(n == 'none' && this.isFullScreen){
      //console.log(n,this.isFullScreen,'执行 this.toggleFullScreen()')
      this.toggleFullScreen()
    }
  }

  captureName = captureTypes;
  captureList:any = [];
  captureValue = 0;
  captureTotal = 0;
  headDisplay:any = 'none';

  capacityName = capacityTypes;
  capacityData:any = []

  deviceName!:any;
  deviceData:any = {};

  eventName = eventTypes;
  eventData:any = []

  dayLabel = dayTypes;
  currentIndex = 0
  timerID:any = null;
  timer5s:any = null;
  timer5m:any = null;
  doc:any = document;
  //circlepathLength = 0
  created(){
    this.deviceName = [
      {value:1,name:this.$tc('deviceType.Camera')},
      {value:2,name:this.$tc('deviceType.SenseKeeper')},
      {value:4,name:this.$tc('deviceType.SenseDLC')},
      {value:5,name:this.$tc('deviceType.SenseID')},
      //{value:6,name:this.$tc('deviceType.SenseGate')},
      {value:601,name:this.$tc('deviceType.Pass')},
      {value:602,name:this.$tc('deviceType.PassPro')},
      {value:603,name:this.$tc('deviceType.Keeper')},
      {value:604,name:this.$tc('SenseGate-B')},
      {value:605,name:this.$tc('SensePassX')},
      {value:606,name:this.$tc('SensePassC')},
      {value:607,name:this.$tc('SenseAiKe')},
      {value:608,name:this.$tc('SenseThunder-E')},
      {value:609,name:this.$tc('SenseThunder-E-Mini')},
      {value:610,name:this.$tc('SenseGate-H')},
      {value:611,name:this.$tc('SenseID')},
      {value:612,name:this.$tc('SensePass Lite')},
      {value:613,name:this.$tc('SenseThunder-W')},
      {value:614,name:this.$tc('SenseThunder-M')},
      {value:615,name:this.$tc('SenseThunder-M-Mini')},
    ];
  }
  // get circlepathLength(){
  //   console.log(this)
  //   //return this.$refs.circlePath[0].getTotalLength()
  // }
  mounted(){
    let _this = this;
    this.getCaptureCount();
    this.getCapacityCount();

    this.getDeviceCount();
    this.selectDate(1);

    this.timer5s = setInterval(() => {
      _this.getCaptureCount();
    }, 5000);

    this.timer5m = setInterval(() => {
      _this.getCapacityCount();
      _this.getDeviceCount();
      _this.selectDate(_this.currentIndex);
    }, 300000);

    this.$nextTick(()=> {
      let _this = this;
      this.headDisplay = window.getComputedStyle(this.$refs.dashboardHeader as any).display;
      window.onresize = function(){
        _this.headDisplay = window.getComputedStyle(_this.$refs.dashboardHeader as any).display;
      }
    })
    //this.circlepathLength = this.$refs.circlepath[0].getTotalLength()

    //console.log(this.circlepathLength)
  }
  hasRouterPermission(name:string){
    if(roleModulesCode[name]){
      return true
    }else{
      return false
    }
  }
  destroyed() {
    //console.log('destroyed',this.isFullScreen)
  }
  beforeDestroy(){
    let _this = this;
    window.onresize = null;

    //组件切换销毁定时器
    clearInterval(_this.timer5s);
    clearInterval(_this.timer5m);
    clearInterval(_this.timerID);

    if(this.isFullScreen){
      //this.escScreen()
      this.toggleFullScreen()
    }
  }

  toggleFullScreen(){
    //console.log('toggleFullScreen(),isFullScreen=',this.isFullScreen)
    let fullElement = this.$refs.fullScreenElement as any;
    //console.log(fullElement)
    let _this = this;
    let rfs = fullElement.requestFullscreen || fullElement.msRequestFullscreen || fullElement.mozRequestFullscreen || fullElement.webkitRequestFullscreen;
    let exitFS = this.doc.exitFullscreen || this.doc.msExitFullscreen || this.doc.mozExitFullscreen || this.doc.webkitExitFullscreen;
    if(rfs && typeof rfs !== 'undefined'){
      this.isFullScreen = !this.isFullScreen;
      AppModule.ToggleFullScreen(false);
      if(this.isFullScreen){
        rfs.call(fullElement);
        _this.dateInit();
      }else if(this.doc.fullscreenElement || this.doc.webkitFullscreenElement || this.doc.mozFullScreenElement || this.doc.msFullscreenElement){
        exitFS.call(this.doc)
      }
    }
  }

  // escScreen(){
  //   let rfs = this.doc.documentElement.requestFullscreen || this.doc.documentElement.msRequestFullscreen;
  //   let exitFS = this.doc.exitFullscreen || this.doc.msExitFullscreen;
  //   if( typeof rfs !== 'undefined' && rfs){
  //     AppModule.ToggleFullScreen(false);
  //     this.isFullScreen = !this.isFullScreen;
  //     exitFS.call(this.doc)
  //   }
  // }

  //今日抓拍统计
  getCaptureCount(){
    let params ={}
    Api.captureCount(params).then((res:any)=>{
      //console.log('今日抓拍',res)
      this.captureList = res.list;
      this.captureValue = res.list[0].count;
      this.captureTotal = 0;
      this.captureList.map((it)=>{
        this.captureTotal += it.count;
      })

    }).then(()=>{
      //console.log(this.captureTotal,this.captureList)
      //console.log(this.captureTotal,this.captureList)
      if(this.captureTotal > 0){
        this.captureList.map(it=>{
          if(it.count>0){
            it.percent = ((it.count/this.captureTotal) * 2.9 *100).toFixed(2);
          }else{
            it.percent = 0
          }

          //console.log(it.count,it.percent)
        })
      }

    })
  }
  dateInit(){
    this.updateTime();
    this.timerID = setInterval(this.updateTime, 10000);
  }
  updateTime(){
    this.dateObj.time = dayjs().format('HH:mm')
    this.dateObj.date = dayjs().format('YYYY/MM/DD')

    let WEEK_i18n:any = this.$t('el.datepicker.weeks');
    let WEEK_DAYS:any = [];
    for(let item in WEEK_i18n){
      if(AppModule.language === 'zh'){
        WEEK_DAYS.push('星期'+WEEK_i18n[item]);
      }else{
        WEEK_DAYS.push(WEEK_i18n[item]);
      }
    }
    this.dateObj.week = WEEK_DAYS[dayjs().day()]
  }

  selectDate(index){
    this.currentIndex=index;
    this.getEventAlarmCount(index)
  }

  //事件告警
  getEventAlarmCount(dataValue:number){
    this.eventData = [];
    this.loading = true;
    let params ={dateType:dataValue}
    Api.eventAlarmCount(params).then((resp:any)=>{
      //console.log('事件',resp)
      if(resp){
        this.loading = false;
      }
      this.eventData = resp.list;
      this.eventData.map((item)=>{
        item.totalCount = item.notCheckCount + item.checkCount;
      })
    })
  }

  //库容统计
  getCapacityCount(){
    let params ={}
    Api.capacityCount(params).then((resp:any)=>{
      //console.log('库容统计',resp)
      this.capacityData = resp.list
    })
  }

  //设备统计
  getDeviceCount(){
    let _this = this;

    //在线设备数据
    Api.deviceCount({state: 1}).then((resp:any)=>{
      //console.log('设备统计',resp)
      _this.deviceData = resp;
      let legendLabelData:any = [];

      resp.list.map((item)=>{
        if(item.count > 0){

          this.deviceName.map((n)=>{
            if(item.deviceType == n.value && n.value !== 6){
              item.name = n.name;
              item.value = item.count;
            }
            legendLabelData.push(item.name);
          })
        }
      });
      _this.pieExtend.legend.data = legendLabelData;
      _this.pieExtend.series[0].data[0].value = resp.onlineCount;
      _this.pieExtend.series[1].data = resp.list;

      _this.deviceData.total   = resp.count;
      _this.deviceData.online  = resp.onlineCount;
      _this.deviceData.offline = resp.offlineCount;
    });

    //总体设备数量
    Api.deviceCount({}).then((resp:any)=>{
      // _this.deviceData.total = resp.count;
      // _this.deviceData.online = resp.onlineCount;
      // _this.deviceData.offline = resp.offlineCount;
    })

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
::v-deep .el-loading-spinner .path{
  stroke: #4c8ec9;
}
.box-shadow-inner{
  box-shadow: 0px 10px 10px -6px rgba(0,0,0,0.2) inset;
}
.dashboard-container{
  --boxBg:rgba(30,28,72,.7);
  --boxBorder:#0a3992;
  background: #161132;
  background:linear-gradient(180deg,rgba(16,77,130,1) 0%,rgba(38,56,96,1) 100%);
  color: #fff;
  width: 100%;
  height: 100%;
  position: relative;

  .date-panel{
    position: absolute;
    right: 36px;
    top: 20px;
    color: #F9FAFC;
    opacity: .8;
    text-align: right;
    display: none;
    strong{
      font-size: 28px
    }
  }
  dd{margin: 0;}
  em{font-style: normal;}
  .more-right{
    position: absolute;
    right: 0;
    color: #4c8ec9;
  }
  .right-line{
    &::after{
      content: '';
      position: absolute;
      width: 1px;
      height: 14px;
      right: 8px;
      background: #909090;
      top: 1px;
    }
  }
  .title-right{
    right: 16px;
    line-height: 16px;
    font-size: 14px;
    font-weight: normal;
    vertical-align: baseline;
    padding-left: 22px;
    display: inline-block;
    i{
      position: absolute;
      left: 0;
      top: 0;
      margin-right: 8px;
      font-size: 12px;
      display: block;
      width: 18px;
      height: 18px;
      &::before,
      &:after{
        display: block;
        width: 16px;
        height: 16px;
        position: absolute;
        line-height: 16px;
        transition: all .3s;
      }
      &::before{
        content: ' ';
        border: 1px solid #4c8ec9;
        border-radius: 50%;
        clip-path: polygon(8% 0, 50% 50%, 8% 100%, 100% 100%, 100% 0);
      }
      &:after{
        content: "\e6e9";
        left: -1px;
      }
    }
    &:hover{
      i{
        &::before{
          transform: rotate(180deg)
        }
        &::after{
          left: 8px;
        }
      }
    }
  }
  .page-header{
    overflow: hidden;
    height: 75px;
    display: none;
    h1.page-title{
      position: relative;
      text-align: center;
      margin: 0 auto;
      width: 72%;
      font-size: 24px;
      line-height: 66px;
      box-shadow:0 3px 4px rgba(0,0,0,0.2);
      &,
      &::before,
      &::after{
        height: 66px;
        background: linear-gradient(to bottom,#163869,#182957);
      }
      &::before,
      &::after{
        content: '';
        width: 100px;
        position: absolute;
        top: 0;
      }
      &::before{
        transform: skew(45deg);
        left: -33px;
        box-shadow:0 0px 3px rgba(0,0,0,0.26);
        clip-path: polygon(-40% -40%, 92% -40%, -23% 140%, -20% 140%);
      }
      &::after{
        transform: skew(-45deg);
        right: -33px;
        box-shadow:0 -3px 3px rgba(0,0,0,0.36);
        clip-path: polygon(33% 0%, 140% 0%, 120% 120%, 124% 140%);
      }
    }
  }
  &:fullscreen{
    .date-panel,
    .page-header{
      display: block;
    }
  }

  .device-statistics{
    position: absolute;
    right: 0;
    bottom: 2px;
    display: flex;
    dl{
      display: flex;
      position: relative;
    }
    dt{color: #ADADAD;}
    dd{
      font-weight: bold;
      font-size: 16px;
      padding: 0 17px 0 4px;
    }
  }
  .map{
    // height: calc(100% - 72px);
    height: 100%;
  }
  .device-chart{
    position: relative;
    .total-device{
      display: none;
      position:absolute;
      left: 50%;
      top: 52%;
      transform: translate(-50%,-50%);
      text-align: center;
      border:1px solid #ccc;
      border-radius: 50px;
    }
  }
  .event-chart-layer{
    height:86.7vh!important;
  }

  .event-chart{
    padding:0 24px;
    height: calc(100% - 56px);
    .event-chart-head{
      display: flex;
      height: 32px;
      justify-content: space-between;
    }
  }
  .select-date{
    text-align: right;
    em{
      color: #65698d;
      display: inline-block;
      padding: 3px 8px;
      cursor: pointer;
    }
    em.current{
      background: #38345f;
      color: #ffb592;
      border-radius: 25px;
    }
  }
  .event-legend{
    padding-top: 3px;
    em{
      position: relative;
      line-height: 14px;
      padding-left: 20px;
      margin-right: 20px;
      &::before{
        content: '';
        display: inline-block;
        width: 14px;
        height: 14px;
        position: absolute;
        left: 0;
        top: 1px;
      }
    }
    em:nth-child(1){
      &::before{
        background: linear-gradient(to right,#363df8, #615ffb);
      }
    }
    em:nth-child(2){
      &::before{
        background: linear-gradient(to right,#fcd5ac, #ae8c7e);
      }
    }
  }
  .event-data-list{
    position: relative;
    height: calc(100% - 56px);
    overflow-y: auto;
    dl{
      position: relative;
      dt{
        opacity: .8;
        .more-right{
          color: #fff;
        }
      }
      .opacity{
        opacity: .1;
      }
    }
  }

  .progress-bg{
    background:rgba(255, 255, 255, .1);
    height: 11px;
    border-radius: 6px;
    width: 100%;
    overflow: hidden;
    position: relative;
    margin: 7px 0 15px;
    display: flex;
    .progress-inner-left,
    .progress-inner-right{
      display: block;
      position: absolute;
      height: 100%;
      animation: growWith 1s ease;
    }
    .progress-inner-left{
      left: 0;
      background: linear-gradient(to right,#363df8, #615ffb);
    }
    .progress-inner-right{
      right: 0;
      background: linear-gradient(to right,#fcd5ac, #ae8c7e);
    }
  }

  .charts{
    display: flex;
    padding: 16px 24px;
    .chart-grid{
      flex:1;
      margin: 12px;
      .chart-item{
        height: 29vh;
        background-color: rgba(30,28,72,.7);//兼容ie11
        background-color: var(--boxBg);
        border-width: 1px;
        border-style: solid;
        border-color: rgba(30,28,72,.7);//兼容ie11
        border-color: var(--boxBg);
        border-radius: 4px;
        .progress-dl{
          margin: 0 0 .8rem;
          position: relative;
          padding: 0 1.1rem;
          dt{
            padding:0 0 .5rem .4rem;
          }
          dd{
            margin: 0;
            text-align: left;
          }
          .numbers{
            padding-right:1.2rem;
            text-align: right;
            color: #fff;
          }
        }
        .progress-dashed{
          flex: 5;
          height: 15px;
          position: relative;
          margin-bottom: 20px;
          background:-webkit-linear-gradient(left, transparent 4px, #4C4A6B 4px);
          &,span{
            background-size: 8px 8px;
          }
          span{
            height: 100%;
            position: absolute;
            display: block;
            animation: growWith 1s ease;
          }
        }
        @keyframes growWith{
          0%{
            width: 0;
          }
          100%{

          }
        }
        .progress-dl:nth-of-type(1) .progress-dashed{
          span{
            background-image:-webkit-linear-gradient(left, transparent 4px, #4c8ec9 4px);
          }
        }
        .progress-dl:nth-of-type(2) .progress-dashed{
          span{
            background-image:-webkit-linear-gradient(left, transparent 4px, #ae8c7e 4px);
          }
        }
        .progress-dl:nth-of-type(3) .progress-dashed{
          span{
            background-image:-webkit-linear-gradient(left, transparent 4px, #adc8d3 4px);
          }
        }
      }
      .chart-item:nth-child(1){
        height: 55vh;
        margin-bottom:2.7vh;
      }
      .item-title{
        font-size: 16px;
        padding: 0;
        height: 24px;
        margin: 24px 0;
        text-shadow:0px 3px 6px rgba(8,65,172,1);
        position: relative;
        &::before,&::after{
          content: '';
          display: inline-block;
          width: 73px;
          height: 7px;
          background: url('~@/assets/images/title-modify.png') no-repeat;
          background-size: 100%;
          margin: 0 8px;
        }
        &::before{
          transform: rotateY(180deg);
        }
      }
      .item-content{
        height: calc(100% - 72px);
        padding-top:2vh;
      }
    }
    .chart-grid:nth-child(1){
      flex:1.5;
    }

    .torus{
      display: flex;
      justify-content: space-around;
      padding: 0 1.7rem;
      li{
        position: relative;
        width: 8rem;
        height: 8rem;
        text-align: center;
        font-weight: bold;
        svg{
          position: absolute;
          left: 0;
          width: 100%;
          height: 100%;
          animation: rotate360 10s linear infinite;
          animation-delay: 3s;
        }
        circle{
          fill:transparent;
          stroke-width:8%;
          /* stroke-dasharray: 160px 377px; */
        }
        .circle-progress{
          //stroke-linecap:round;
          stroke:url(#borderlinear);
          animation:1s cicleRun ease-in-out forwards;
          animation-delay: 1s;
        }
        @keyframes cicleRun{
          0%{
            stroke-dasharray: 0 377px;
          }
          // 50%{
          //   stroke-dasharray: 377px 0;
          // }
        }
        .circle-bg{
          stroke:rgba(255, 255, 255, .1);
          stroke-dasharray: 377px 0;
        }
        .flex{
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100%;
          width: 100%;
        }
        // span{
        //   display: block;
        //   position: relative;
        //   left: .5rem;
        //   top: .5rem;
        //   width: 7rem;
        //   height: 7rem;
        //   line-height: 7rem;
        //   font-size: 1.3rem;
        //   background: #161132;
        //   border-radius: 50%;
        //   z-index: 1;
        //   display: flex;
        //   align-items: center;
        //   justify-content: center;
        // }
        em{
          position: absolute;
          display: inline-block;
          width: 100%;
          font-weight: normal;
          bottom: -24px;
          left: 0;
          text-align: center;
          white-space:nowrap;
        }
        // &::before,
        // &::after{
        //   content: '';
        //   display: block;
        //   position: absolute;
        //   left: 0;top: 0;
        //   width: 100%;
        //   height: 100%;
        //   border-radius: 50%;
        //   background-clip: padding-box;
        // }
        // &::before{
        //   border: 9px solid #292647;
        //   z-index: 0;
        // }
        // &::after{
        //   z-index: 0;
        //   clip-path: polygon(0 0, 0 40%, 50% 50%, 100% 44%, 100% 0);
        //   animation: rotate360 6s linear infinite;
        //   background: linear-gradient(to right,#0F4C81, #4C8EC9);
        // }
        @keyframes rotate360 {
          0%{}
          50%{
            transform: rotate(180deg);
          }
          100%{
            transform: rotate(360deg);
          }
        }
      }
    }
  }
  .btn-full-screen{
    position: fixed;
    right: 10px;
    bottom: 10px;
    width: 60px;
    height: 60px;
    line-height: 60px;
    text-align: center;
    background:radial-gradient(circle,rgba(10,92,165,1) 0%,rgba(34,67,141,1) 100%);
    box-shadow:0px 3px 12px rgba(0,0,0,0.3);
    border-radius: 30px;
    color: #fff;
    opacity: .8;
    cursor: Pointer;
    overflow: hidden;
    i,span{
      position: absolute;
      left: 0;
      top: 0;
      display: block;
      width: 100%;
      height: 100%;
      text-align: center;
      transition: all 0.3s ease-in-out;
      &::before{
        font-size: 26px;
        height: 100%;
        display: block;
        line-height: 60px;
      }
    }
    i{
      transform:scale(1);
      opacity: .6;
    }
    span{
      opacity: 0;
      visibility:hidden;
    }
    span.to-full{
      transform:scale(0);
    }

    //退出全屏
    span.exit-full{
      transform:scale(5);
    }
    &:hover{
      i{opacity: 0;}
      span{
        transform:scale(1);
        visibility:visible;
        opacity:1;
      }
      i.icon-to-fullscreen{
        transform:scale(5);
      }

      //退出全屏
      i.icon-exit-fullscreen{
        transform:scale(0);
      }
    }
  }
  .ve-device{
    height: calc(100% - 72px);
  }
  @media (max-width: 1440px){
    .date-panel{
      top: 13px;
    }
    .event-chart-layer{
      height:85.7vh!important;;
    }
    .page-header{
      height: 65px;
      h1.page-title{
        line-height: 60px;
        width: 70%;
        &,
        &::before,
        &::after{
          height: 60px;
          font-size: 20px;
          background: linear-gradient(to bottom,#163869,#182957);
        }
        &::before{
          left: -30px;
        }
        &::after{
          right: -30px;
        }
      }
    }
    .charts{
      padding: 8px 16px;
      .chart-grid{
        margin: 8px;
        .chart-item:nth-child(1){height: 54vh;}
        .item-title{
          margin: 14px 0 15px;
        }
        .torus{
          padding-top: 0;
        }
        .item-content{
          padding-top: 0;
          // .progress-dl{
          //   margin: 1.2rem 0;
          // }
          .progress-dashed{
            height: 12px;
          }
        }
        .ve-device{
          height: calc(100% - 56px);
        }
      }
    }
    .device-statistics dt{
      font-size: 12px;
      line-height: 18px;
    }
    .progress-bg{
      height: 9px;
    }
  }
}
</style>
