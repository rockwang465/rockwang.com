<template>
  <div class="welcome-list-container">
    <div class="welcome-header" >
        <h3 class="welcome-header-title"> <span class="welcome-header-title-core"><i class="iconfont icon-renqunfenlei" ></i></span>  {{$tc('welcome.listTileTask')}}</h3>
        <div class="welcome-header-poper" >{{$tc('welcome.listTitle1')}}<el-button :disabled="!$modulePermission(roleModulesCode['rule'])"  @click="link" style="color:#409eff;text-decoration:underline;" type="text">{{$tc('welcome.taskCenter')}}</el-button>{{$tc('welcome.listTitle2')}}</div>
    </div>
    <div class="welcome-list-content" ref="tablecontents">
        <el-table
            :data="tableData"
            :loading="tableLoading"
            :height="tableHeight||null"
            @filter-change="tableFilterChange"
            stripe
            header-row-class-name="welcome-header-tableheader"
            style="width: 100%">
            <el-table-column
                prop="welcomeName"
                :label="$tc('welcome.tableName')">
            </el-table-column>
            <el-table-column
                prop="deviceName"
                :label="$tc('welcome.tableDevice')">
            </el-table-column>
            <el-table-column
                prop="threshold"
                :label="$tc('welcome.tableThreshold')">
                <template slot-scope="scope">
                    <span v-show="scope.row.threshold">{{scope.row.threshold * 100 +'%'}}</span>
                </template>
            </el-table-column>
            <el-table-column
                prop="libNum"
                :label="$tc('welcome.contImageLibrary')">
            </el-table-column>
            <el-table-column
                :filter-multiple="false"
                :filters="[{text: $t('rule.buttonRuleStausEnabled'), value: 1}, {text: $t('rule.buttonRuleStausDisabled'), value: 0}]"
                column-key="runStatus"
                prop="enableStatus"
                :label="$tc('welcome.tableTaskStatus')">
                <template slot-scope="scope">
                    <el-switch
                    @change="(v)=>changeTaskStatus(v,scope.row)"
                    v-model="scope.row.enableStatus"
                    :disabled="scope.row.disabled"
                    :active-value="1"
                    :inactive-value="0"
                    active-color="#13ce66"
                    inactive-color="#ff4949">
                    </el-switch>
                </template>
            </el-table-column>
            <el-table-column
                prop=""
                :label="$tc('welcome.tableOperation')">
                <template slot-scope="scope">
                    <el-button type="primary" :disabled="!scope.row.enableStatus" @click="showWelcome(scope.row)">{{$tc('welcome.BtnEnterWelcome')}}</el-button>
                </template>
            </el-table-column>
            <div slot="empty" style="width:100%" >
                <img src="/images/task-nodata.png" alt="" srcset="">
                <div class="welcome-list-content-explain">
                    <p style="font-size:24px;color:#000;line-height:30px;">{{$tc('welcome.tableEmptyText1')}}<el-button :disabled="!$modulePermission(roleModulesCode['rule'])" @click="link" style="color:#409eff;text-decoration:underline;font-size:24px;" type="text">{{$tc('welcome.taskCenter')}}</el-button>{{$tc('welcome.tableEmptyText2')}}</p>
                    <p>{{$tc('welcome.tableEmptyText6')}}</p>
                    <p>{{$tc('welcome.tableEmptyText3')}}<el-button :disabled="!$modulePermission(roleModulesCode['rule'])" @click="link" style="color:#409eff;text-decoration:underline;" type="text">{{$tc('welcome.taskCenter')}}</el-button>{{$tc('welcome.tableEmptyText4')}}</p>
                    <p>{{$tc('welcome.tableEmptyText5')}}</p>
                </div>
                
                
            </div> 
        </el-table>
        <el-pagination
        style="display:flex;justify-content: center;margin-top:8px"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="paginationPageSizes"
        :page-size="currentPageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
        </el-pagination>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import {paginationPageSizes} from '@/utils/constants.ts';
import {getWelcomeList,startTDTask,stopTDTask} from '@/api/welcome.ts';
import {roleModulesCode} from '@/router/moduleCode.ts';

@Component({
  components: {
    
  },
})
export default class List extends Vue {
  

    /* props */

    /* watch */

    /* data */
  roleModulesCode:any=roleModulesCode;

    $refs !:{
        tablecontents:HTMLFormElement
    };
    tableData:any[]=[];
    tableLoading:boolean=false;
    paginationPageSizes:number[] = paginationPageSizes;
    currentPageSize:number = paginationPageSizes[0];
    currentPage:number=1;
    total:number = 0;
    tableHeight:any='';
    showStatusDialog:boolean=false;
    /* methods */
    mounted(){
        let h_ = this.$refs.tablecontents.clientHeight - 50;
        this.tableHeight = h_>0?h_:null;
        this.getTasks();
    }
    link(){
        this.$router.push({
            path:'/manage/task'
        })
    }
    changeTaskStatus(v,row){
        let taskId = row.taskId;
        taskId && this.setCurrentTaskDisabled(taskId,true);
        taskId && v == 1 && startTDTask(row.taskId).finally(()=>{
            this.getTasks();
            this.setCurrentTaskDisabled(taskId,false)
        });
        taskId && v == 0 && stopTDTask(row.taskId).finally(()=>{
            this.getTasks();
            this.setCurrentTaskDisabled(taskId,false)
        }); 
    }
    showWelcome(row){
        row.taskId && this.$emit('showpics',row)
    }
    getTasks(runStatus?){
        this.tableLoading = true;
        getWelcomeList({page :this.currentPage,num:this.currentPageSize,runStatus}).then(res=>{
            res && this.formatData(res);
        }).catch(err=>{
            this.tableData = [];
        }).finally(()=>{
            this.tableLoading = false;
        });
    }
    handleSizeChange(v){
        this.currentPageSize = v;
        this.getTasks();
    }
    handleCurrentChange(v){
        this.currentPage = v;
        this.getTasks();
    }
    tableFilterChange(filter){
        let runStatus = filter['runStatus'][0];
        this.getTasks(runStatus);

    }
    formatData(res){
        this.total = res.total;
        let arr:any[]=[];
        res.greetGuestsList && res.greetGuestsList.length>0 && res.greetGuestsList.map(guest=>{
            arr.push({
                welcomeName:guest.taskName || '',
                deviceName:guest.deviceName||'',
                threshold:guest.threshold||0,
                libNum:guest.libNum?guest.libNum+ "":0 ,
                enableStatus:guest.status,
                disabled:false,
                taskId:guest.taskId,
                backgroundImage:guest.backgroundImage,
                deviceId:guest.deviceId
            })
        });
        this.tableData = arr;
    }
    setCurrentTaskDisabled(taskId,disabledStatus){
        this.tableData.map(task=>{
            taskId == task.taskId && (task.disabled = disabledStatus)
        })
    }
    



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
h3{
    margin: 0;
    padding: 0;
}   
    .welcome-list-container{
        height: 100%;
    }
    .welcome-header{
        padding-bottom: 8px;
    }
    .welcome-header-title{
        border-bottom:1px solid $--color-top;
        display: inline-block;
        padding-bottom: 16px;
        padding-right: 200px;
        .welcome-header-title-core{
            display: inline-block;
            width: 20px;
            height: 20px;
            line-height: 20px;
            text-align: center;
            
            background-color: rgba($color: $--color-top, $alpha: 1.0) ;
            color: white;
            border-radius: 50%;
            i.iconfont{
                font-size: 14px;
            }
        }
    }
    .welcome-header-poper{
        display: inline-block;
        color: #9099B7;
        position: relative;
        bottom: -15px;
        padding-left: 8px;
    }
    .welcome-list-content{
        @include shadowBox();
        height: calc(100% - 58px);
        padding-bottom: 8px;
        .el-table{
            height: calc(100% - 48px);
        }
        .welcome-list-content-explain{
            text-align: left;
            padding-left: 40%;
            position: relative;
            left: -150px;
            p{
                font-size: 14px;
                line-height: 24px;
            }
        }
    }
    // ::v-deep .has-gutter .welcome-header-tableheader .cell{
    //     color: red;
    // }
</style>
