<template>
  <canvas class="welcome-transition-right-cav" ref="cav" ></canvas>
</template>

<script lang="tsx">
import { Component, Vue,Watch ,Prop} from 'vue-property-decorator';
import SockJS from "sockjs-client";
import { Stomp } from "stompjs/lib/stomp.min.js";
import {Cache} from '@/utils/cache';
import {processImgurl} from '@/utils/image';
import {getWelcomeGuestNumber} from '@/api/welcome.ts';
import { TweenMax,Power2 } from 'greensock';

const refreshTokenTime = window.globalConfig.refreshTokenTime;
const tdwsHost = window.globalConfig.tdwsHost;
@Component({
  components: {

  },
  directives:{

  }
})

export default class CanvasBg extends Vue {

    /* props */


    /* watch */
    /* data */
    $refs !:{
        cav:HTMLFormElement
    }
    //anmatetion
    canvas:any = null;
    context:any=null;
    canvasWidth = 0;
    canvasHeight = 0;
    particleLength = 250;
    particles:any[] = [];
    particleMaxRadius = 8;
    /* methods */
    mounted() {
        this.canvas = this.$refs.cav;
        this.context = this.canvas.getContext('2d');
        this.initialize();
        this.renderStart();
    }
    initialize() {
        this.resizeCanvas();
        for (let i = 0; i < this.particleLength; i++) {
            this.particles.push(this.createParticle(i));
        }
    }
    random(low, high) {
        return Math.random() * (high - low) + low;
    }

    handleMouseMove(e) {
        this.enlargeParticle(e.clientX, e.clientY);
    }

    handleClick(e) {
        this.burstParticle(e.clientX, e.clientY);
    }

    handleResize() {
        this.resizeCanvas();
    }

    resizeCanvas() {
        this.canvasWidth = document.body.offsetWidth;
        this.canvasHeight = document.body.offsetHeight;
        this.canvas.width = this.canvasWidth * window.devicePixelRatio;
        this.canvas.height = this.canvasHeight * window.devicePixelRatio;
        this.context = this.canvas.getContext('2d');
        this.context.scale(window.devicePixelRatio, window.devicePixelRatio);
    }

    createParticle(id:number, isRecreate?) {
        const radius = this.random(1, this.particleMaxRadius);
        const x = isRecreate ? -radius - this.random(0, this.canvasWidth) : this.random(0, this.canvasWidth);
        let y = this.random(this.canvasHeight / 2 - 250, this.canvasHeight / 2 + 250);
        y += this.random(-100, 100);
        const alpha = this.random(0.05, 1);

        return {
            id: id,
            x: x,
            y: y,
            startY: y,
            radius: radius,
            defaultRadius: radius,
            startAngle: 0,
            endAngle: Math.PI * 2,
            alpha: alpha,
            color: { r: this.random(0, 100), g: this.random(0, 100), b: 255 },
            speed: alpha + 1,
            amplitude: this.random(50, 200),
            isBurst: false
        };
    }

    drawParticles() {
        this.particles.forEach((particle:any) => {
        // 位置情報更新
        this.moveParticle(particle);

        // particle描画
        this.context.beginPath();
        this.context.fillStyle = `rgba(${particle.color.r}, ${particle.color.g}, ${particle.color.b}, ${particle.alpha})`;
        this.context.arc(particle.x, particle.y, particle.radius, particle.startAngle, particle.endAngle);
        this.context.fill();
        });
    }

    moveParticle(particle) {
        particle.x += particle.speed;
        particle.y = particle.startY + particle.amplitude * Math.sin(((particle.x / 5) * Math.PI) / 180);
    }

    enlargeParticle(clientX, clientY) {
        this.particles.forEach((particle:any) => {
        if (particle.isBurst) return;

        const distance = Math.hypot(particle.x - clientX, particle.y - clientY);

        if (distance <= 100) {
            const scaling = (100 - distance) / 1.5;
            TweenMax.to(particle, 0.5, {
            radius: particle.defaultRadius + scaling,
            ease: Power2.easeOut
            });
        } else {
            TweenMax.to(particle, 0.5, {
            radius: particle.defaultRadius,
            ease: Power2.easeOut
            });
        }
        });
    }

    burstParticle(clientX, clientY) {
        this.particles.forEach((particle:any) => {
        const distance = Math.hypot(particle.x - clientX, particle.y - clientY);

        if (distance <= 100) {
            particle.isBurst = true;
            TweenMax.to(particle, 0.5, {
            radius: particle.defaultRadius + 200,
            alpha: 0,
            ease: Power2.easeOut,
            onComplete: () => {
                this.particles[particle.id] = this.createParticle(particle.id, true);
            }
            });
        }
        });
    }

    renderStart(){
        // canvas初期化
        this.context.clearRect(0, 0, this.canvasWidth + this.particleMaxRadius * 2, this.canvasHeight);

        this.drawParticles();

        this.particles.forEach((particle:any) => {
        if (particle.x - particle.radius >= this.canvasWidth) {
            this.particles[particle.id] = this.createParticle(particle.id, true);
        }
        });

        requestAnimationFrame(this.renderStart.bind(this));
    }

}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.welcome-transition-right-cav{
    position: absolute;
    z-index: -1;
    width: 100%;
    height: 100%;
    left: 0;
    bottom: 0;
  }

</style>
