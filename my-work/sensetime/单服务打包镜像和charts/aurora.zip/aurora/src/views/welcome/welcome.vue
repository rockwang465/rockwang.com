<template>
  <transition name="fade">
    <div v-show="visible" :style="style" class="welcome-compomne-box">
      <div class="welcome-compomne-header" >
        <div>
         <i class="iconfont icon-HI" style="position:relative;top:-8px;font-size:28px;left:-8px;" ></i>
         <span >{{$tc('welcome.welcomeHeaderActualArrival')}} </span>
         <span style="color:#FFDD1F">{{actualVisitor}} </span>
         <span style="color:#3f3e3e">/ {{totalVisitor}}</span>
        </div>
        <div class="welcome-compomne-header-time" >
          <p>{{dayTime +" "+ weekTime}}</p>
          <h1 style="text-align:right;">{{time}}</h1>
        </div>
      </div>
      <div class="welcome-compomne-transition-left-box" :style="{height:dataArray.length?'calc(100% - 106px)':'0'}" >
        <div class="welcome-compomne-transition-left-box-bar welcome-compomne-transition-left-box-bar-top" ></div>
        <div class="welcome-compomne-transition-left-box-bar welcome-compomne-transition-left-box-bar-right welcome-compomne-transition-left-box-bar-delay" ></div>
        <div class="welcome-compomne-transition-left-box-bar welcome-compomne-transition-left-box-bar-bottom welcome-compomne-transition-left-box-bar-delay" ></div>
        <div class="welcome-compomne-transition-left-box-bar welcome-compomne-transition-left-box-bar-left" ></div>
        <transition-group name="list-complete" tag="div" class="welcome-compomne-transition welcome-compomne-transition-left" >
          <div :class="['welcome-compomne-card', documentVisibilityState?'list-complete-item':'']"  v-for="(item) in dataArray" :key="item.id">
            <div class="welcome-compomne-imgbox">
              <div class="welcome-compomne-img" :style="{backgroundImage:`url(${processImgurl(item.faceImage)})`}"></div>
            </div>
            <div class="welcome-compomne-text">
              <p class="welcome-compomne-name">{{item.name}}</p>
              <p class="welcome-compomne-msg">{{item.welcomeMsg}}</p>
            </div>
          </div>
        </transition-group>
      </div>
      <div class="welcome-compomne-transition-right-box" ref="welcometransitionrightbox" ></div>
      <CanvasBg ></CanvasBg>
      <i class="iconfont icon-exit welcome-compomne-exit-btn" style="position:absolute;bottom:20px;right:20px;cursor:pointer;z-index:999" @click="exit"></i>
    </div>

  </transition>
</template>

<script lang="tsx">
import { Component, Vue,Watch ,Prop} from 'vue-property-decorator';
import SockJS from "sockjs-client";
import { Stomp } from "stompjs/lib/stomp.min.js";
import {Cache} from '@/utils/cache';
import {processImgurl} from '@/utils/image';
import {getWelcomeGuestNumber,refreshToken} from '@/api/welcome.ts';
import CanvasBg from './components/canvasBg.vue';
import {cloneDeep} from 'lodash';
import { TweenLite } from 'greensock';

const refreshTokenTime = window.globalConfig.refreshTokenTime;
const tdwsHost = window.globalConfig.tdwsHost;
@Component({
  components: {
    CanvasBg
  },
  directives:{

  }
})

export default class WelcomePics extends Vue {

  get style(){
    let style = {
      "font-size":this.fontSizeNum+'px',
      "background-image":this.backgroundImage?`url(${processImgurl(this.backgroundImage)})`:'url(/images/welcomebg.png)'
    };
    return style;
  }

  get fontSizeNum(){
    return 14*this.clientWidth/1920;
  }

  /* props */
  @Prop({default: false,required:true }) visible!: boolean;
  @Prop({default: '',required:false }) backgroundImage!: string;
  @Prop({default: '',required:true }) deviceId!: string;
  @Prop({default: '',required:true }) taskId!: string;

  /* watch */
  @Watch('visible', { immediate: false, deep: false })
  onVisibleChanged(val: boolean, oldVal: boolean) {
    val && this.initData();
    !val && this.destoryData();
  }

  /* data */
  $refs !:{
    welcometransitionrightbox:HTMLFormElement
  }
  clientWidth:number=document.body.clientWidth;
  clientHeight:number=document.body.clientHeight;

  //ws
  sessionId:string='';
  socket:any=null;
  socketClient:any=null;

  //wsdata
  name:string='';
  faceImage:string='';
  welcomeMsg:string='';

  processImgurl:any=processImgurl;

  dataArray:any[]=[];
  dataArrayRight:any[]=[];

  timer:any=null;
  documentVisibilityState:boolean=true;

  leftLimitNum:number=10;
  rightLimitNum:number=8;
  refreshTimer:any=null;

  actualVisitor:number=0;
  totalVisitor:number=0;
  renderHTML:string='';

  dayTime:string='';
  weekTime:string="";
  time:string='';
  timeTimer:any=null;
  autoTimer:any=null;
  autoHideTime:number=30;
  autoHideStatusTime:number=10;
  delayTimer:any=null;
  /* methods */
  mounted() {
    document.addEventListener('visibilitychange',(e)=>{
      this.documentVisibilityState = document.visibilityState == 'visible'?true:false;
    })
  }
  initData(){
    this.actualVisitor = 0;
    this.totalVisitor = 0;
    document.body.appendChild(this.$el);
    this.documentVisibilityState = true;
    this.sessionId = '';
    this.socket = null;
    this.socketClient = null;
    this.name='';
    this.faceImage='';
    this.welcomeMsg='';
    this.dataArray = [];
    this.dataArrayRight=[];
    this.refreshTimer = null;
    this.clearChildNode();
    this.connect();
    this.getGuestNum();
    this.getNowTime();
    this.autoRemoveNode();
    this.refreshToken();
    console.log(this);
  }
  refreshToken(){
    if(this.refreshTimer) window.clearTimeout(this.refreshTimer);
    refreshToken()
    this.refreshTimer = setTimeout(()=>{
      this.refreshToken();
    },refreshTokenTime);
  }
  getNowTime(){
    let week = [this.$tc('welcome.Sunday'), this.$tc('welcome.Monday'), this.$tc('welcome.Tuesday'), this.$tc('welcome.Wednesday'), this.$tc('welcome.Thursday'), this.$tc('welcome.Friday'), this.$tc('welcome.Saturday')];
    if(this.timeTimer) window.clearInterval(this.timeTimer);
    this.timeTimer = setInterval(() => {
      this.dayTime = this.dateFormat('YYY/mm/dd',new Date());
      this.weekTime = week[new Date().getDay()];
      this.time = this.dateFormat('HH:MM',new Date())
    }, 100);
  }
  dateFormat(fmt, date) {
    let ret;
    let opt = {
        "Y+": date.getFullYear().toString(),        // 年
        "m+": (date.getMonth() + 1).toString(),     // 月
        "d+": date.getDate().toString(),            // 日
        "H+": date.getHours().toString(),           // 时
        "M+": date.getMinutes().toString(),         // 分
        "S+": date.getSeconds().toString()          // 秒
    };
    for (let k in opt) {
        ret = new RegExp("(" + k + ")").exec(fmt);
        if (ret) {
            fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
        };
    };
    return fmt;
  }
  exit(){
    this.close();
  }
  getGuestNum(){
    getWelcomeGuestNumber(this.taskId).then((res:any)=>{
      console.log(res)
      if(res){
        this.actualVisitor = res.actualVisitor;
        this.totalVisitor = res.totalVisitor;
      }
    }).catch(err=>{
      this.actualVisitor = 0;
      this.totalVisitor = 0;
    })
  }
  connect(){
    this.sessionId = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0,7);
    this.socket = new SockJS(`${tdwsHost}/senseguard-td-result-consume/stomp`,[], {
      sessionId: ()=>{
       return this.sessionId;
      }
    });
    this.socketClient = Stomp.over(this.socket);
    this.socketClient.debug = null;
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    this.socketClient.connect(
      {userId},
      (frame)=> {
        this.socketClient.subscribe(`/queue/${this.sessionId}`,  (res) =>{
          res = JSON.parse(res.body) ;
          console.log(res)

          if(res.welcome && res.recordDetail.taskId == this.taskId){
            this.parseMsg(res);
            this.parseMsgTrasition(res);
          }
        });
        this.delayTimer && window.clearTimeout(this.delayTimer);
        this.delayTimer = setTimeout(()=>{
          this.sendmsg()
        },200)
      },(error)=> {

      }
    );
  }
  sendmsg() {
    const userInfo = Cache.localGet("userInfo") || Cache.sessionGet("userInfo");
    const userId = userInfo.userId;
    const requestBody = JSON.stringify({
      sessionId:this.sessionId,
      deviceIds:[this.deviceId],
      compareTypes:[],
      ruleGroupIds:[],
      userId,
      ruleId:this.taskId
    });
    this.socketClient.send(`/app/filter_condition`,{},requestBody);
  }
  destoryData(){
    this.$el && this.$el.parentNode && this.$el.parentNode.removeChild(this.$el);
    this.clearChildNode();
    this.socket && this.socket.close();
    this.socket = null;
    this.socketClient = null;
    this.timer && window.clearTimeout(this.timer);
    this.autoTimer && window.clearInterval(this.autoTimer);
    this.delayTimer && window.clearTimeout(this.delayTimer);
    this.refreshTimer && window.clearTimeout(this.refreshTimer);
  }
  destroyed() {
    this.destoryData()
  }
  close(){
    this.$emit('close')
  }
  parseMsg(res){
    let faceImage = res.recordDetail.picUrl,//picUrl,url,bigPicture.imgUrl
    welcomeMsg = res.recordDetail.captureDate,
    name = res.recordDetail.userName || '',
    id=res.recordDetail.serialNumber,
    trackId=res.recordDetail.trackId,
    taskId=res.recordDetail.taskId,
    objectId=res.recordDetail.objectId;
    let alarm = {faceImage,welcomeMsg,name,id,trackId,taskId,objectId};
    //console.log('当前卡片',alarm)

    res.greetGuestsInfo.actualVisitor && (this.actualVisitor = res.greetGuestsInfo.actualVisitor);
    // res.greetGuestsInfo.visitTimes && (this.totalVisitor = res.greetGuestsInfo.visitTimes);

    if(this.dataArray.length > (this.leftLimitNum-1)){
      this.dataArray.splice(this.leftLimitNum-1,1);
    }

    //replace same trackId
    // if(res && res.recordDetail && res.recordDetail.trackId){
    //   console.log(this.dataArray)
    //   let isReplace = this.dataArray.some(item=>
    //   (item
    //   && item.trackId
    //   && item.trackId == res.recordDetail.trackId
    //   && item.objectId == res.recordDetail.objectId
    //   && item.taskId == res.recordDetail.taskId));

    //   if(isReplace){
    //     console.log('出现重复isReplace',isReplace)
    //     this.replaceSameAlarm(res);
    //     return false;
    //   }
    // };

    this.dataArray.unshift(alarm);

  }
  replaceSameAlarm(newCardInfo){
    newCardInfo.recordDetail
    && newCardInfo.recordDetail.trackId
    && newCardInfo.recordDetail.objectId
    && newCardInfo.recordDetail.taskId
    && this.dataArray.map((item,itenIndex)=>{
      if(item.recordDetail
        && item.recordDetail.trackId
        && item.recordDetail.trackId == newCardInfo.recordDetail.trackId
        && item.recordDetail.objectId == newCardInfo.recordDetail.objectId
        && item.recordDetail.taskId == newCardInfo.recordDetail.taskId
      ){
        let alarm_ = {
          showImage:false,//替换直接显示
          faceImage:newCardInfo.recordDetail.picUrl,
          welcomeMsg:newCardInfo.recordDetail.captureDate,
          name:newCardInfo.recordDetail.userName||'',
          score:newCardInfo.record.score,
          replace:true,
          id:newCardInfo.recordDetail.serialNumber,
          trackId:newCardInfo.recordDetail.trackId,
          taskId:newCardInfo.recordDetail.taskId,
          objectId:newCardInfo.recordDetail.objectId
        };
        item = alarm_;
        //this.loopIntervalAlarmIds[itenIndex] = alarm_.id;//handle loopIntervalAlarmIds
        this.$set(this.dataArray,itenIndex,alarm_);
      }
    });
  }

  parseMsgTrasition(res){
    let sideLength = {x:200,y:190}
    let faceImage = res.recordDetail.picUrl,
    welcomeMsg = res.welcomeRemarks.welcomeRemarks,
    name = res.recordDetail.userName || '',
    id=res.recordDetail.serialNumber,
    trackId=res.recordDetail.trackId,
    taskId=res.recordDetail.taskId,
    objectId=res.recordDetail.objectId,
    position=this.getRectPosition(sideLength);
    let alarm = {faceImage,welcomeMsg,name,id,position,trackId,taskId,objectId};

    if(this.dataArrayRight.length>(this.rightLimitNum-1)){
      this.hideChildNode(this.dataArrayRight.length);
    }
    if(this.dataArrayRight.length>(this.rightLimitNum-1+30)){
      this.removeFirstChildNode();
      this.dataArrayRight.splice(0,1);
    }

    //replace same trackId
    if(res && res.recordDetail && res.recordDetail.trackId){
      let isReplace = this.dataArrayRight.some(item=>
      (item
      && item.trackId
      && item.trackId == res.recordDetail.trackId
      && item.objectId == res.recordDetail.objectId
      && item.taskId == res.recordDetail.taskId));

      if(isReplace){
        console.log('右侧出现重复isReplace',isReplace)
        this.replaceRightSameAlarm(res);
        return false;
      }
    };

    this.dataArrayRight.push(alarm);
    this.appendChildNode(alarm);

  }
  replaceRightSameAlarm(newCardInfo){
    newCardInfo.recordDetail
    && newCardInfo.recordDetail.trackId
    && newCardInfo.recordDetail.objectId
    && newCardInfo.recordDetail.taskId
    && this.dataArrayRight.map((item,itenIndex)=>{
      if(item.recordDetail
        && item.recordDetail.trackId
        && item.recordDetail.trackId == newCardInfo.recordDetail.trackId
        && item.recordDetail.objectId == newCardInfo.recordDetail.objectId
        && item.recordDetail.taskId == newCardInfo.recordDetail.taskId
      ){
        let sideLength = {x:200,y:190}
        let alarm_ = {
          showImage:false,//替换直接显示
          replace:true,
          faceImage : newCardInfo.recordDetail.picUrl,
          welcomeMsg: newCardInfo.welcomeRemarks.welcomeRemarks,
          name      : newCardInfo.recordDetail.userName || '',
          id        : newCardInfo.recordDetail.serialNumber,
          trackId   : newCardInfo.recordDetail.trackId,
          taskId    : newCardInfo.recordDetail.taskId,
          objectId  : newCardInfo.recordDetail.objectId,
          position  : this.getRectPosition(sideLength)
        };
        item = alarm_;
        //this.loopIntervalAlarmIds[itenIndex] = alarm_.id;//handle loopIntervalAlarmIds
        this.$set(this.dataArrayRight,itenIndex,alarm_);
      }
    });
  }
  clearChildNode(){
    document.getElementsByClassName('welcome-compomne-transition-right-box')
    && document.getElementsByClassName('welcome-compomne-transition-right-box')[0]
    && (document.getElementsByClassName('welcome-compomne-transition-right-box')[0].innerHTML = '');
  }
  appendChildNode(alarm){
    document.getElementsByClassName('welcome-compomne-transition-right-box')[0].appendChild(this.createNewNode(alarm,true));
  }
  hideChildNode(length){
    if(length<this.rightLimitNum) return ;
    let remove_ele = document.getElementsByClassName('welcome-compomne-transition-right-card')[length-this.rightLimitNum];
    remove_ele.classList.remove("welcome-compomne-transition-right-card-show");
    remove_ele.classList.add("welcome-compomne-transition-right-card-hide");
  }
  autoRemoveNode(){
    this.autoTimer && window.clearInterval(this.autoTimer);
    this.autoTimer = setInterval(() => {
      if(this.dataArrayRight.length>0){
        let remove_eles = document.getElementsByClassName('welcome-compomne-transition-right-card');
        let now_time = new Date().getTime();
        for(let i=0;i< remove_eles.length;i++){
          let time = Number(remove_eles[i].getAttribute('data-time'));
          if(now_time - time >= this.autoHideStatusTime*1000){//status1
            this.chageOrderChildNodeStatus(i,1)
          }
          if(now_time - time >= this.autoHideStatusTime*2000){//status2
            this.chageOrderChildNodeStatus(i,2)
          }
          if(now_time - time >= this.autoHideStatusTime*2500){//status3
            this.chageOrderChildNodeStatus(i,3)
          }
          if(now_time - time >= this.autoHideTime*1000){
            this.hideOrderChildNode(i)
          }
        }
      }
    },500);
  }
  hideOrderChildNode(num){
    let remove_ele = document.getElementsByClassName('welcome-compomne-transition-right-card')[num];
    remove_ele.classList.remove("welcome-compomne-transition-right-card-show");
    // remove_ele.classList.remove("welcome-compomne-transition-right-card-show-status1");
    // remove_ele.classList.remove("welcome-compomne-transition-right-card-show-status2");
    // remove_ele.classList.remove("welcome-compomne-transition-right-card-show-status3");
    remove_ele.classList.add("welcome-compomne-transition-right-card-hide");
  }
  chageOrderChildNodeStatus(num,status){
    let remove_ele = document.getElementsByClassName('welcome-compomne-transition-right-card')[num];
    status == 1 && remove_ele.classList.add("welcome-compomne-transition-right-card-show-status1");
    status == 2 && remove_ele.classList.add("welcome-compomne-transition-right-card-show-status2");
    status == 3 && remove_ele.classList.add("welcome-compomne-transition-right-card-show-status3");
  }
  removeFirstChildNode(){
    let remove_ele = document.getElementsByClassName('welcome-compomne-transition-right-card')[0];
    document.getElementsByClassName('welcome-compomne-transition-right-box')[0].removeChild(remove_ele);
  }
  createNewNode(welcome,show){
    let ele = document.createElement('div');
    ele.setAttribute('data-time',new Date().getTime()+'');
    ele.setAttribute('data-id',welcome.id);
    ele.className = `welcome-compomne-transition-right-card ${show?'welcome-compomne-transition-right-card-show':'welcome-compomne-transition-right-card-hide'} `;
    ele.style.cssText = `left:${welcome.position.position.x}px;top:${welcome.position.position.y}px;height:${welcome.position.sideLength.y}px;width:${welcome.position.sideLength.x}px`;
    let innerCreateHTML = `<div class="welcome-compomne-img welcome-compomne-transition-img" style="background-image:url(${processImgurl(welcome.faceImage)})" >
              <div class="welcome-compomne-transition-img-ring1" ></div>
              <div class="welcome-compomne-transition-img-ring2" ></div>
              <div class="welcome-compomne-transition-img-ring3" ></div>
            </div>
           <div class="welcome-compomne-transition-text"  >
             <div class="welcome-compomne-transition-text-name" >${welcome.name}</div>
             ${welcome.welcomeMsg?`<div class="welcome-compomne-transition-text-msg"> ${welcome.welcomeMsg}</div>`:''}
           </div>`;
    ele.innerHTML = innerCreateHTML;
    return ele;
  }
  getRectPosition(sideLength){
    if(this.dataArrayRight.length === 0) return {position:this.getRandomNumber(sideLength),sideLength};
    let rect:any={position:{x:0,y:0},sideLength}
    let isOverlap = true;
    let whlie_num = 0;
    while (isOverlap) {
      whlie_num ++ ;
      rect.position = this.getRandomNumber(sideLength);
      isOverlap = false;
      let start_num = this.dataArrayRight.length>this.rightLimitNum?(this.dataArrayRight.length-this.rightLimitNum):0;
      let end_num   = this.dataArrayRight.length>this.rightLimitNum?(start_num+this.rightLimitNum):this.dataArrayRight.length;
      for(let i=start_num;i<end_num;i++){
        let item = this.dataArrayRight[i];
        if(this.isRectOverlap(rect,item.position)){
          isOverlap = true ;
          break;
        }
      }
      // isOverlap = this.dataArrayRight.some((item,itemIndex)=>this.isRectOverlap(rect,item.position));
      if(whlie_num>200){ console.log(whlie_num); break ;}
    }
    return rect;
  }
  getRandomNumber(sideLength){
    let width_max = this.$refs.welcometransitionrightbox.clientWidth;
    let height_max =  this.$refs.welcometransitionrightbox.clientHeight;
    let left = Math.random()*(width_max - sideLength.x),
        top = Math.random()*(height_max - sideLength.y);
    return {x:left,y:top};
  }
  isRectOverlap(RectA,RectB){
    let l1 = {x:RectA.position.x,y:RectA.position.y},r1={x: RectA.position.x+RectA.sideLength.x, y: RectA.position.y+RectA.sideLength.y};
    let l2 = {x:RectB.position.x,y:RectB.position.y},r2={x: RectB.position.x+RectB.sideLength.x, y: RectB.position.y+RectB.sideLength.y};
    const isOverlap = this.isTwoIntersect(l1,r1,l2,r2);
    return isOverlap;
  }
  isTwoIntersect(l1,r1,l2,r2){
    if(l1.x > r2.x || l2.x > r1.x || l1.y > r2.y || l2.y > r1.y){
      return false;
    }
    return true;
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" >
@import "@/styles/variables.scss";

.welcome-compomne-box{
  width:100%;
  height:100%;
  position:absolute;
  top:0;
  left:0;
  z-index:9999999;
  background-color:#b3c1d2;
  background-size: cover;
  overflow: hidden;
  padding-left: 40px;
}
.welcome-compomne-header{
  font-size: 24px;
  color: white;
  margin-top:40px;
  margin-bottom: 8px;
  position: relative;
  i{
    color: #2365CF;
  }
  .welcome-compomne-header-time{
    position: absolute;right: 24px;
    bottom: -100px;
  }
}
.welcome-compomne-transition-left-box{
  display: inline-block;
  padding: 8px;
  overflow: hidden;
  border:1px solid rgba($color: #282E71, $alpha: 1);
  border-radius: 4px;
  transition: height 0.5s;
  position: relative;
  box-sizing: border-box;

  .welcome-compomne-transition-left-box-bar {
    position: absolute;
    width: 50px;
    height: 2px;
    background-color: rgba($color: rgb(7, 3, 236), $alpha: 1);
    transition: all .5s linear;
    animation-duration: .5s;
    animation-fill-mode: both;
    animation-iteration-count: infinite;
    border-radius: 1px;
  }
  .welcome-compomne-transition-left-box.welcome-compomne-transition-left-box-bar-delay {
    animation-delay: 0.5s;
  }
  .welcome-compomne-transition-left-box-bar-top {
    top: 3px;
    left: 5px;
  }
  .welcome-compomne-transition-left-box-bar-right {
    top: 18px;
    right: -20px;
    transform: rotate(90deg);
  }
  .welcome-compomne-transition-left-box-bar-bottom {
    bottom: 2px;
    left: 5px;
  }
  .welcome-compomne-transition-left-box-bar-left {
    top: 18px;
    left: -21px;
    transform: rotate(90deg);
  }
  .welcome-compomne-transition-left-box-bar-top, .welcome-compomne-transition-left-box-bar-bottom {
	  animation-name: h-move;
  }
  .welcome-compomne-transition-left-box-bar-right, .welcome-compomne-transition-left-box-bar-left {
    animation-name: v-move;
  }

}
.welcome-compomne-transition-left{
  border:8px solid rgba($color: #282E71, $alpha: 0);
  height: 100%;
  display: inline-block;
  overflow: hidden;
  background-color: rgba($color: #282E71, $alpha: 0.6);
  border-radius: 4px;

}
.welcome-compomne-card{
  width: 26em;
  height: 8em;
  margin-bottom: 16px;
  border-radius: 4px;
  background:rgba($color: #282E71, $alpha: 0.7);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: center;
}
.welcome-compomne-imgbox{
  width: 6.64em;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.welcome-compomne-img{
  width: 5.1em;
  height: 5.1em;
  border-radius: 50%;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}
.welcome-compomne-text{
  display: flex;
  flex-wrap: wrap;
  padding-left: 4px;
  p{
    text-align: left;
    color: white;
    width: 100%;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  .welcome-compomne-name{
    font-size: 1.5em;
    line-height: 1.3em;
  }
  .welcome-compomne-msg{
    font-size: 1.3em;
    line-height: 1.6em;
  }
}
.welcome-compomne-transition-right-box{
  display: inline-block;
  height: calc(100% - 105px);
  width: calc(100% - 26em - 80px);
  position: relative;
  .welcome-compomne-transition-right-card{
    position: absolute;
    // border:1px solid red;
    padding-top: 20px;
    .welcome-compomne-transition-img{
      margin: 0 auto;
      width: 7em;
      height: 7em;
      position: relative;
      border:2px solid rgba($color: #FFDD1F, $alpha: 1);
      margin-bottom: 20px;
      &>div{
        border-radius: 50%;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%) rotate(0deg);

        animation-iteration-count: infinite;
      }
      .welcome-compomne-transition-img-ring1{
        width: 8em;
        height: 8em;
        background:linear-gradient(179deg,rgba(255,221,50,1) 0%,rgba(245,125,61,1) 100%);
        z-index: -1;
        animation-name: rotateaa;
        /*  Rotate  */
        animation-duration: 1.5s;

      }
      .welcome-compomne-transition-img-ring2{
        width: 9em;
        height: 9em;
        background:linear-gradient(179deg,rgba(255,221,30,.6) 0%,rgba(245,125,61,.6) 100%);
        z-index: -2;
        animation-name: rotateaa;
        /*  Rotate  */
        animation-duration: 1s;

      }
      .welcome-compomne-transition-img-ring3{
        width: 10em;
        height: 10em;
        background:linear-gradient(179deg,rgba(252,220,40,.1) 0%,rgba(245,125,61,.1) 100%);
        box-shadow:0px 6px 25px rgba(65,34,0,0.5);
        z-index: -3;
        /*  Rotate  */
        animation-duration: .5s;

      }
    }
    .welcome-compomne-transition-text{
      position: relative;
      .welcome-compomne-transition-text-name{
        position: relative;
        top: 8px;
        text-align: center;
        color: white;
        font-size: 18px;
        width: 100%;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
      }
      .welcome-compomne-transition-text-msg{
        padding: 8px 0;
        text-align: center;
        font-size: 14px;
        border-radius: 30px;
        background-color: rgba($color: #fff, $alpha: 0.1);
        color: white;
        word-wrap:break-word;
        width: 100%;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
      }
    }
  }
  .welcome-compomne-transition-right-card-show-status1{
    .welcome-compomne-transition-img{
      .welcome-compomne-transition-img-ring3{
        opacity: 0;
      }
    }
    .welcome-compomne-transition-text{
      .welcome-compomne-transition-text-msg{
        background-color: rgba($color: #fff, $alpha: 0.2);
      }
    }
  }
  .welcome-compomne-transition-right-card-show-status2{
    .welcome-compomne-transition-img{
      .welcome-compomne-transition-img-ring2{
        opacity: 0;
      }
    }
    .welcome-compomne-transition-text{
      .welcome-compomne-transition-text-msg{
        background-color: rgba($color: #fff, $alpha: 0.1);
      }
    }
  }
  .welcome-compomne-transition-right-card-show-status3{
    .welcome-compomne-transition-img{
      .welcome-compomne-transition-img-ring1{
        opacity: 0;
      }
    }
    .welcome-compomne-transition-text{
      .welcome-compomne-transition-text-msg{
        background-color: rgba($color: #fff, $alpha: 0);
      }
    }
  }
}
.welcome-compomne-exit-btn{
  color: #fff;
  // &:hover{
  //   color: #b3c1d2;
  // }
}
 @keyframes h-move {
  0% {
  left: -5px;
  }
  100% {
  left: 100%;
  }
}

 @keyframes v-move {
  0% {
  top: -5px;
  }
  100% {
  top:100%;
  }
}



//left
.list-complete-item {
  transition: all 1s;
}
.list-complete-enter, .list-complete-leave-to {
  opacity: 0;
}
.list-complete-enter{
  transform: translateX(300px) scale(1);
}
.list-complete-leave-to{
  transform: translate(-750px,450px) scale(.3);
}
.list-complete-leave-active {
  position: absolute;
}

//right
.welcome-compomne-transition-right-card{
  // animation: shake 3s infinite 2s;
}
.welcome-compomne-transition-right-card-show{
  animation: show 2s ,shake 3s infinite 2s;
  transition: all 2s;
  transform: scale(1);
  opacity: 1;
}
.welcome-compomne-transition-right-card-hide{
   animation: hide 2s;
  // transition: all 2s;
  transform: scale(0);
  opacity: 0;
}
@keyframes show {
  0%{opacity: 0;transform: scale(0)}
  50%{opacity: 1;transform: scale(1.2)}
  100%{opacity: 1;transform: scale(1)}
}
@keyframes rotateaa {
  0% {transform: translate(-50%, -50%) rotate(0deg);}
  100% {transform: translate(-50%, -50%) rotate(360deg);}
}
@keyframes shake {
  0% {transform:translateY(0%);}
  25% {transform:translateY(5%);}
  50% {transform:translateY(0%);}
  75% {transform:translateY(-5%);}
  100% {transform:translateY(0%);}
}
@keyframes hide {
  0%{opacity: 1;transform: scale(1)}
  100%{opacity: 0;transform: scale(0)}
}
</style>
