<template>
  <div class="welcome-container">
    <List @showpics="showPics" />
    <WelcomePics
      :visible="visible"
      :backgroundImage="backgroundImage"
      :deviceId="deviceId"
      :taskId="taskId"
      @close="hidePics" />
  </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import List from './list.vue';
import WelcomePics from './welcome.vue';

@Component({
  components: {
    List,
    WelcomePics
  },
})
export default class Welcome extends Vue {
  

    /* props */

    /* watch */

    /* data */
    visible:boolean=false;
    backgroundImage:string='';
    deviceId:string='';
    taskId:string='';
    /* methods */
    showPics(row){
      this.taskId = row.taskId;
      this.backgroundImage = row.backgroundImage;
      this.deviceId = row.deviceId;
      this.visible = true;
    }
    hidePics(){
      this.visible=false;
    }



}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "@/styles/variables.scss";
    .welcome-container{
        padding: 8px 24px;
        height: calc(100% - 16px);
    }
</style>
