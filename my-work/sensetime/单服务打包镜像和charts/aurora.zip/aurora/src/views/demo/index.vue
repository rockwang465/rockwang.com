<template>
  <div class="dashboard-container">
    <div>
      <h3>文字</h3>
      <span class="font-size-1"> 最大文字 </span>
      <span class="font-size-2"> 基础文字 </span>
      <span class="font-size-3"> 较小文字 </span>
    </div>
    <div>
      <h3>多选框</h3>
      <el-checkbox>默认按钮</el-checkbox>
      <el-checkbox :disabled="isDisable"/>
    </div>
    <div>
      <h3>按钮</h3>
      <div>
        <el-button>默认按钮</el-button>
        <el-button type="primary">主要按钮</el-button>
        <el-button type="success">成功按钮</el-button>
        <el-button type="info">信息按钮</el-button>
        <el-button type="warning">警告按钮</el-button>
        <el-button type="danger">危险按钮</el-button>
      </div>

      <h3>禁用</h3>
      <div>
        <el-button disabled>默认按钮</el-button>
        <el-button disabled type="primary">主要按钮</el-button>
        <el-button disabled type="success">成功按钮</el-button>
        <el-button disabled type="info">信息按钮</el-button>
        <el-button disabled type="warning">警告按钮</el-button>
        <el-button disabled type="danger">危险按钮</el-button>
      </div>
      <h3>大小</h3>
      <div>
        <el-button size="medium">大按钮</el-button>
        <el-button>默认按钮</el-button>
        <el-button size="small">小型按钮</el-button>
        <el-button size="mini">超小按钮</el-button>
      </div>
      <h3>输入框大小</h3>
      <div class="flex">
        <div class="item"><el-input placeholder="请输入内容" suffix-icon="el-icon-date"></el-input></div>
        <div class="item"><el-input size="medium" placeholder="请输入内容" suffix-icon="el-icon-date"></el-input></div>
        <div class="item"><el-input size="small" placeholder="请输入内容" suffix-icon="el-icon-date"></el-input></div>
        <div class="item"><el-input size="mini" placeholder="请输入内容" suffix-icon="el-icon-date"></el-input></div>
      </div>
      <h3>边框</h3>
      <div>
          <div class="border-1"> 边框一</div>
      </div>
      <div>
          <div class="border-2"> 边框颜色浅一点</div>
      </div>
      <div>
          <div class="border-3"> 边框颜色再浅一点</div>
      </div>
      <div>
          <div class="border-4"> 边框颜色特别浅</div>
      </div>
      <div>
          <div class="border-5"> 虚线边框</div>
      </div>
      <div>
          <div class="border-6"> 边框宽一点</div>
      </div>
      <div>
          <div class="border-7"> 边框再宽一点</div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { LoginModule } from '@/store/modules/login';
// import { Button,
//          Tag,
//          Checkbox,

//          } from 'element-ui';

@Component
export default class Dashboard extends Vue {
  isDisable=true
  get name() {
    return LoginModule.name;
  }

  get roles() {
    return LoginModule.roles;
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "src/styles/variables.scss";
  .dashboard {
    &-container {
      margin: 30px;
    }
    &-text {
      font-size: 30px;
      line-height: 46px;
    }
  }
  .font-size-1{
    font-size: $--font-size-large
  }
  .font-size-2{
    font-size: $--font-size-base
  }
  .font-size-3{
    font-size: $--font-size-small
  }
  .border-1{
    border: $--border-base;
    padding:20px;
    margin: 10px;
  }
  .border-2{
    border: $--border-width-base $--border-style-base $--border-color-light;
    padding:20px;
    margin: 10px;
  }
  .border-3{
    border: $--border-width-base $--border-style-base $--border-color-lighter;
    padding:20px;
    margin: 10px;
  }
  .border-4{
    border: $--border-width-base $--border-style-base $--border-color-extra-light;
    padding:20px;
    margin: 10px;
  }
  .border-5{
    border: $--border-width-base $--border-style-dashed $--border-color-base;
    padding:20px;
    margin: 10px;
  }
  .border-6{
    border: $--border-width-thick $--border-style-base $--border-color-base;
    padding:20px;
    margin: 10px;
  }
  .border-7{
    border: $--border-width-thicker $--border-style-base $--border-color-base;
    padding:20px;
    margin: 10px;
  }
  .flex{display: flex}
  .flex .item{margin-right: 15px;}
</style>
