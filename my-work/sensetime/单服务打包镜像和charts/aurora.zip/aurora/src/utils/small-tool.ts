import i18n from '@/lang/index' // Internationalization
class SnEvent {
    eventList:any;
    constructor() {
        this.eventList={}
    }
    on(event,callback){
        this.eventList[event] = callback
    }
    emit(terget,params){
        var param = [].slice.call(params,0)
        this.eventList[terget].apply(this,param)
    }
}

class Snbind extends SnEvent{
    constructor(){
        super()
    }
    then(fullfiledHandle,errorHandle?, progressHandle?){
        this.on("sucess", fullfiledHandle)
        this.on("error", errorHandle)
        this.on("progress", progressHandle)
        return this;
    }
    once(fullfiledHandle,errorHandle?){
        this.on("once", fullfiledHandle)
        this.on("error", errorHandle)
        return this;
    }
}

class SnDeferred{
    promise:any;
    status:any;
    constructor(fn){
        this.status="prepare"
        this.promise = new Snbind()
        fn(this.resolve.bind(this),this.emitOnce.bind(this),this.reject.bind(this))
    }
    resolve(){
        this.promise.emit("sucess",arguments)
    }
    emitOnce(){
        if(this.status==="prepare"){
            this.promise.emit("once",arguments);
            this.status="do"
        }
    }
    reject(){
        this.promise.emit("error",arguments)
    }
    progress(){
        this.promise.emit("progress",arguments)
    }
}

export var SnPromise = function(fn){
    var defer = new SnDeferred(fn)
    return defer.promise
}

export function convertCardType(num){
    switch(num){
      case  0:
      return "";
      case  1:
      return "viewed";
      case  2:
      return "success";
      case  3:
      return "failed";
      default:
    }
  }

  export function toPercent(num){
      if(!num){
        return '?';
      }else if(typeof num==="number"){
        if(num==0){
            return '?';
        }
       return (Math.floor(num*1000)/10).toFixed(1)+"%";
    }else if(typeof num==="string"){
        return (Math.floor(parseFloat(num)*1000)/10).toFixed(1)+"%"
    }
  }

    export function toMin(sec) {
      if(sec) {
        return (sec/60).toFixed() +i18n.t('pedestrian.min')
      } else {
        return false
      }
    }

    //计算分钟
    export function getHSTime(val){
      let _i18n = i18n as any;
       if(!val) return '0'+_i18n.t('pedestrian.sec');
       let s1 =  Math.round(val/1000);
       let s  =s1;
       let min ;
       let h ;
       if(s1 > 60) {
         s = (s1 % 60)
         min = (s1-s) /60
         if(min > 60) {
           let m2 = min
           min = min%60
           h = (m2-min)/60
         }
       }
       return `${h? h+ _i18n.t('pedestrian.hours'): ''}${min? min+ _i18n.t('pedestrian.min'): ''}${s ? s + _i18n.t('pedestrian.sec') : ''} `
   }

    //处理列表数据
    export function processComparisonInfo(items:any,size = 5){
      let comparisonInfo = new Array();
      let i;
      items.forEach((v,k)=>{
        v["isFocus"]=false;//当前详情被点击
        if(k===0){
          i=0
          comparisonInfo[i]={showCompareDetail:false,data:[]}
        }else if(k%size===0){
          i++
          comparisonInfo[i]={showCompareDetail:false,data:[]}
        }
        comparisonInfo[i].data.push(v)
      })
      return comparisonInfo;
    }


    export function  i18nCompareType(val) {
      let compareType = ""
      let color =''
      switch(val){
        case "0":
        compareType = 'pedestrian.unknown';
        color = '#FF9800'
        break;
        case "1":
        compareType="pedestrian.pedestrianRecord"; //$t('pedestrian.search')
        color = '#1989fa'
        break;
        case "2":
        compareType="pedestrian.vehicleRecord";
        color = '#1989fa'
        break;
        case "3":
        //  compareType="records.listNotifyTypePassAttack";
        break;
        case "4":
        case "6":
        case "8":
        //  compareType="records.listNotifyTypeAbnormal";
        break;
        case "9":
        //  compareType="records.listNotifyTypeBlacklist";
        break;
        case "10":
        compareType="pedestrian.pedestrianCrossingWarning";
        color = '#ED3A33'
        break;
        case "11":
        compareType="pedestrian.pedestriansInvasion";
        color = '#ED3A33'
        break;
        case "20":
        compareType="pedestrian.parkedVehicles";
        color = '#ED3A33'
        break;
        case "24":
        compareType="pedestrian.crowdOvercrowding";
        color = '#ED3A33'
        break;
        case "23":
        compareType="pedestrian.crowdAnalyze";
        color = '#1989fa'
        break;
      }
     return {compareType ,color}

    }

  //放回带百分百的数组 , 便于分割
  export function toPercentage(num:any) {
    let percentage: any;
    if (!num) {
      return ["0",""];
    } else if (typeof num === "number") {
      if (num == 0) {
        return ["0",""];
      }
      percentage = Math.floor(num * 1000) / 10 + "%";
      // console.log(percentage);
      if (percentage.indexOf(".") != -1) {
        return percentage.split(".");
      } else {
        return percentage.split("%");
      }
    } else if (typeof num === "string") {
      percentage = Math.floor(parseFloat(num) * 1000) / 10 + "%";
      // console.log(percentage);
      if (percentage.indexOf(".") != -1) {
        return percentage.split(".");
      } else {
        return percentage.split("%");
      }
    }
  }

