import enLocale from '../lang/en';
import zhLocale from '../lang/zh';
import elementEnLocale from "@/lang/elementUI_en";
import elementZhLocale from "@/lang/elementUI_zh-CN";
import Cookies from "@/lang";

const messages = {
  en: {
    ...enLocale,
    ...elementEnLocale,
  },
  zh: {
    ...zhLocale,
    ...elementZhLocale,
  }
}

export function isValidUsername(str: string) {
  // const validMap = ['admin', 'editor', 'test','test123'];
  // return validMap.indexOf(str.trim()) >= 0;
  if(str.trim().length > 0){
    return true;
  }else{
    return false;
  }

}

export function validPassword(str: string) {
  // const reg = /^(?![a-zA-Z]+$)(?![A-Z0-9]+$)(?![A-Z\\\\W_!@#$%^&*`~()-+=]+$)(?![a-z0-9]+$)(?![a-z\\\\W_!@#$%^&*`~()-+=]+$)(?![0-9\\\\W_!@#$%^&*`~()-+=]+$)[a-zA-Z0-9\\\\W_!@#$%^&*`~()-+=]{8,18}$/;
  //reg.test(str)
  if (str.trim().length > 0) {
    return true;
  } else {
    return false;
  }
}

export function isExternal(path: string) {
  return /^(https?:|mailto:|tel:)/.test(path);
}

export function validateLowerCase(str: string) {
  const reg = /^[a-z]+$/;
  return reg.test(str);
}

export function validateUpperCase(str: string) {
  const reg = /^[A-Z]+$/;
  return reg.test(str);
}

export function validatAlphabets(str: string) {
  const reg = /^[A-Za-z]+$/;
  return reg.test(str);
}

export function isEmpty(value: String) {
  if (typeof value == "undefined" || value == null || value == "") {
    return true;
  } else {
    return false;
  }
}

export function isEmptyNotZero(value: String) {
  if (typeof value == "undefined" || value == null || value === "") {
    return true;
  } else {
    return false;
  }
}

/**
 * Name fileValidate
 * @param file {Object} 表单文件
 * @param allowTypes {Array} 允许的文件格式
 * @param maxSize {Number}   允许文件大小
 */
export function fileValidate(file, allowTypes: Array<String>, maxSize?: Number) {
  if(!maxSize){
    maxSize=100;
  }

  allowTypes.push('jpeg')
  let theType = file.type.substring(file.type.lastIndexOf('/') + 1);
  let allowType: boolean = false;
  //type
  if (allowTypes.includes(theType)) {
    allowType = true;
  } else {
    allowType = false;
  }

  //size
  if(maxSize){

  }
  const allowSize = file.size / 1024 / 1024 < maxSize;

  //img width and height
  function getLen(){
    return new Promise((resolve, reject) => {
      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = function(event){
        let e:any = event || window.event;
        let image = new Image();
        image.src = e.target.result;
        image.onload=function(e){
          //console.log("file load");
          if(image.width < 100 || image.height < 100){
            //console.log("reject");
          	return resolve(false)
          }else{
            //console.log("resolve");
          	return resolve(true);
          }
        }
      }
    });
  }

  let allowLen = getLen();

  return {
    len: allowLen,
    type: allowType,
    size: allowSize,
  }
}

export const requiredTip = (rule, value = '', callback) => {
  if (value === '') {
    callback(new Error("请输入非空内容"))
  } else {
    callback()
  }
}

export const requiredPassword = (rule, value = '', callback) => {
  let regEnUp = /[A-Z]+/,//大写字母
    regEnLow = /[a-z]+/,//小写字母
    regNum = /[0-9]+/,//数字
    regEnSymbol = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,//英文特殊字符
    regCnSymbol = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im;//中文特殊字符
  if (value === '') {
    callback(new Error("请输入非空内容"))
  } else if (value.length < 8) {
    callback(new Error("请输入8位数以上的密码"))
  }
  let i = 0;
  if (regEnUp.test(value)) {
    i++;
  }
  if (regEnLow.test(value)) {
    i++;
  }
  if (regNum.test(value)) {
    i++;
  }
  if (regEnSymbol.test(value) || regCnSymbol.test(value)) {
    i++;
  }
  if (i < 3) {
    callback(new Error("密码必须包含下列形式中至少3种：大写字母、小写字母、数字、特殊字符。"))
  } else {
    callback()
  }
}



