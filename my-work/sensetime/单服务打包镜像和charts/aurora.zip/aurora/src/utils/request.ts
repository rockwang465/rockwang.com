import axios from 'axios';
import {Message, MessageBox} from 'element-ui';
// import { getToken } from '@/utils/auth';
import {Cache} from '@/utils/cache';
import i18n from '@/lang/index' // Internationalization
import {LoginModule} from '@/store/modules/login';
import {logout} from '@/store/modules/login';

var host = window.globalConfig;

// 创建axios实例
const service = axios.create({
  baseURL: process.env.VUE_APP_MOCK_API,
  timeout: 60000,
});

// request 拦截器
service.interceptors.request.use(
  (config) => {
    if (config.timeout == 0) {
      config.timeout = 5000
    }
    // if (Cache.sessionGet("accessToken")) {
    //   config.headers['accessToken'] = Cache.sessionGet("accessToken"); // 让每个请求携带自定义token 请根据实际情况自行修改
    // }
    if (config.params && config.params.language) {
      config.headers['language'] = config.params.language
    }
    return config;
  },
  (error) => {
    // Handle request error here
    Promise.reject(error);
  },
);

//避免重复报错
let isFlag: boolean = false

// respone 拦截器
service.interceptors.response.use(
  (response) => {
    const res = response.data;
    //http状态码为非200
    if (response.status !== 200 && response.status !== 201 && response.status !== 204) {
      Message({
        showClose: true,
        message: i18n.tc(res.code),
        type: 'error',
        duration: 5 * 1000,
      });

      return Promise.reject('error');
    } else {
      return response.data;
    }
  },
  (error) => {
    console.log(error)

    let data = error.response.data

    if (data) {
      if (data.code == '408006') {
        return data;
      }
      if(isFlag) {
        return
      }

      let messageCon:string;
      if(i18n.te(data.code)){
        if(data.code ==='401002'){
          messageCon = (i18n.t(data.code,{number:data.message})) as string;
        }else{
          messageCon = i18n.tc(data.code)
        }

      }else{
        messageCon = data.message
      }

      Message({
        showClose: true,
        message: messageCon,
        type: 'error',
        duration: 2 * 1000,
      });
      if (data.code == "401015" || data.code == "401005"|| data.code == "401014") {
        setTimeout(() => {
          //console.log(isFlag)
          //if(Cache.localGet('showdebug')){
          // let isLogout = confirm('token过期或无权限，点击确定退出，或点击取消查看退出原因。');
          // if(isLogout == true){
          //   logout()  //调试827bug
          // }else{

          // }
          //}

          logout()  //调试827bug
        }, 2000)
        isFlag = true
      }
      if (data.code == "408010"||data.code == "419002"){//为处理人像后台批量上传逻辑，需获取接口400情况下后端返回的数据
        return data;
      }
      return Promise.reject(error);
    } else {

      Message({
        showClose: true,
        message: error.message,
        type: 'error',
        duration: 5 * 1000,

      });
      return Promise.reject(error);
    }
  },
);

export default service;
