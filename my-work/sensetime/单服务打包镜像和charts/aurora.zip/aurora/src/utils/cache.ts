const formValueObj = (value:any) => ({ value });
const getRealVal = (obj:any) => obj ? obj.value:null;

export const Cache = {
  sessionGet(key:string) {
    let str_json = window.sessionStorage.getItem(key);
    return getRealVal(str_json && JSON.parse(str_json));
  },
  sessionGetOnce(key:string) {
    let str_json = window.sessionStorage.getItem(key);
    const data = getRealVal(str_json && JSON.parse( str_json));
    window.sessionStorage.removeItem(key);
    return data;
  },
  sessionSet(key:string, value:any) {
    window.sessionStorage.setItem(key, JSON.stringify(formValueObj(value)));
  },
  sessionRemove(key:string) {
    window.sessionStorage.removeItem(key);
  },
  sessionClear() {
    window.sessionStorage.clear();
  },
  localGet(key:string) {
    let str_json = window.localStorage.getItem(key);
    return getRealVal(str_json && JSON.parse(str_json));
  },
  localSet(key:string, value:any) {
    window.localStorage.setItem(key, JSON.stringify(formValueObj(value)));
  },
  localRemove(key:string) {
    window.localStorage.removeItem(key);
  },
  localClear() {
    window.localStorage.clear();
  }
};

export default Cache;
