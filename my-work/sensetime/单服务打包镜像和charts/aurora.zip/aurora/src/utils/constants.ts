import i18n from '@/lang/index';

export const ruleThresholdOptions = [0.95,0.9,0.85,0.8,0.75,0.7,0.65,0.6,0.55,0.5,0.45,0.4,0.35,0.3];
export const deviceThresholdOptions = [95,90,85,80,75,70,65,60,55,50,45,40,35,30];
export const visitorSelectData={
  1:i18n.t('visitor.senseid.optionInterview'),
  2:i18n.t('visitor.senseid.optionMeeting'),
  3:i18n.t('visitor.senseid.optionActivity'),
  4:i18n.t('visitor.senseid.optionParent'),
  5:i18n.t('visitor.senseid.optionOther'),
};
// console.log(visitorSelectData);
// export const visitorSelectData = ()=>{
//   return {
//     1:i18n.t('visitor.senseid.optionInterview'),
//     2:i18n.t('visitor.senseid.optionMeeting'),
//     3:i18n.t('visitor.senseid.optionActivity'),
//     4:i18n.t('visitor.senseid.optionParent'),
//     5:i18n.t('visitor.senseid.optionOther'),
//   }
// }

//console.log(visitorSelectData)

/*
配置项目设备类型
@overview ：1-Camera，2-SenseKeeper，4-SenseDLC,5-SenseID,其他未知
*/
export const deviceType = [
  { value: 1, name: i18n.t('deviceType.Camera') },
  { value: 2, name: i18n.t('deviceType.SenseKeeper') },
  { value: 4, name: i18n.t('deviceType.SenseDLC') },
  { value: 5, name: i18n.t('deviceType.SenseID') },
  { value: 6, name: i18n.t('deviceType.SenseGate')},//暂时屏蔽前端比对
  { value: 3, name: i18n.t('deviceType.SenseNebula') },
];

export const captureStrategyType = [
  { value: 1, name: i18n.t('captureStrategyType.accurate') },
  { value: 2, name: i18n.t('captureStrategyType.timing') },
  { value: 3, name: i18n.t('captureStrategyType.realTime') },
];
//非人脸过滤
export const noFaceType = [
  { value: 0, name: i18n.t('noFaceType.no') },
  { value: 1, name: i18n.t('noFaceType.yes') },
];

export const subsetDeviceType = [
  { value: 1, name: i18n.t('deviceType.Camera') },
  { value: 4, name: i18n.t('deviceType.SenseDLC') },
];

export const mDeviceType = [
  { value: 1, name: i18n.t('deviceType.standard') },
  { value: 2, name: i18n.t('deviceType.thermometry') },

  //TODO:核实设备类型
  // { value: 1, name: i18n.tc('deviceType.Camera') },
  // { value: 2, name: i18n.tc('deviceType.SenseKeeper') },
  // { value: 4, name: i18n.tc('deviceType.SenseDLC') },
  // { value: 5, name: i18n.tc('deviceType.SenseID') },
  // { value: 6, name: i18n.tc('deviceType.SenseGate')},//暂时屏蔽前端比对
  // { value: 61, name: i18n.t('deviceType.Pass')},//暂时屏蔽前端比对
  // { value: 62, name: i18n.t('deviceType.PassPro')},//暂时屏蔽前端比对
  // { value: 63, name: i18n.t('deviceType.Keeper')},//暂时屏蔽前端比对
  // { value: 64, name: i18n.t('deviceType.Gate')},//暂时屏蔽前端比对
];

export const passDeviceType = [
  { value: 1, name: i18n.tc('deviceType.Pass') ,code:'Pass' },
  { value: 2, name: i18n.tc('deviceType.PassPro') ,code:'PassPro' },
  { value: 3, name: i18n.tc('deviceType.Keeper') ,code:'Keeper' },
  { value: 4, name: i18n.tc('deviceType.SenseGateB'),code:'GateB' },
  { value: 5, name: i18n.tc('deviceType.SensePassX'),code:'PassX' },
  { value: 6, name: i18n.tc('deviceType.SensePassC'),code:'PassC' },
  { value: 7, name: i18n.tc('deviceType.SenseAiKe'),code:'AiKe' },
  { value: 8, name: i18n.tc('deviceType.FireGods'),code:'FireGods' },//火神
  { value: 9, name: i18n.tc('deviceType.FireGodsMini'),code:'FireGodsMini' },
  { value: 10, name: i18n.tc('deviceType.GateH'),code:'GateH' },
  { value: 11, name: i18n.tc('deviceType.SenseIDF'),code:'ID' },
  // { value: 12, name: i18n.tc('SensePassLite'),code:'PassLite' },
  { value: 13, name: i18n.tc('deviceType.WindGods'),code:'WindGods' },//风神
  // { value: 14, name: i18n.tc('SenseThunder-M雷神'),code:'ThunderGods' },
  // { value: 15, name: i18n.tc('SenseThunder-M雷神mini'),code:'ThunderGodsMini' },
  // { value: 4, name: i18n.tc('deviceType.Gate')},

];

// export const tempStatus = [
//   { value: 0, name: i18n.t('deviceType.standard') },
//   { value: 2, name: i18n.t('deviceType.thermometry') },
// ];

/**
 * 分页默认配置
 */
export let pagination = {
  currentPage:1,
  pageSize:13,
  pageSizes:[13, 8, 12 , 16],
  totalPage:40,
}

export const paginationPageSizes = [10,20,30,50,100];

export const alarmCompareTypeList = [
  {id:JSON.stringify({actd:1,link:1}),name:i18n.t('liveservice.listNotifyTypeNormal')},
  {id:JSON.stringify({actd:2,link:2}),name:i18n.t('liveservice.listNotifyTypeAbnormal')},
  {id:JSON.stringify({actd:3,link:3}),name:i18n.t('liveservice.listNotifyTypeBlacklist')},
  {id:JSON.stringify({actd:4,link:4}),name:i18n.t('liveservice.listNotifyTypeStranger')},
  {id:JSON.stringify({actd:5,link:5}),name:i18n.t('liveservice.listNotifyTypeFaceSpoof')},
  {id:JSON.stringify({actd:6,link:6}),name:i18n.t('liveservice.listNotifyTypePassAttack')},
  {id:JSON.stringify({struct:1,link:101}),name:i18n.t('task.eventTypeHumanSnapShot')},
  {id:JSON.stringify({struct:10,link:102}),name:i18n.t('task.eventTypeHumanCrosslineAlert')},
  {id:JSON.stringify({struct:11,link:103}),name:i18n.t('task.eventTypeHumanRegionBreakintoAlert')},
  {id:JSON.stringify({struct:20,link:104}),name:i18n.t('task.eventTypeVehicleStopAlert')},
  {id:JSON.stringify({struct:2,link:105}),name:i18n.t('task.eventTypeVehicleSnapShot')},
  {id:JSON.stringify({struct:3,link:106}),name:i18n.t('task.eventTypeNonMotorVehicleSnapShot')},
  {id:JSON.stringify({struct:23}),name:i18n.t('task.eventTypeCrowdDetectionRecord')},
  {id:JSON.stringify({struct:24}),name:i18n.t('task.eventTypeCrowdLimitWarning')},
];

//task type
export const taskType = [
  {id:1,name:'td',label:i18n.t('task.taskTypeFaceControl'),task_type:1},
  {id:2,name:'ac',label:i18n.t('task.taskTypePassControl'),task_type:0},
  {id:3,name:'pc',label:i18n.t('task.taskTypeTripDetection'),task_type:3},//Pedestrian crossing 行人越线
  {id:4,name:'pai',label:i18n.t('task.taskTypeRegionBreakDetection'),task_type:2},//Pedestrian area invasion 行人区域入侵
  {id:5,name:'vpi',label:i18n.t('task.taskTypeVehicleStopDetection'),task_type:4},//车辆违停
  {id:6,name:'cs',label:i18n.t('task.taskTypePeopleStranded'),task_type:5},//人群
  // {id:7,name:'hb',label:i18n.t('task.taskTypeHumanBodyStatic'),task_type:6},//人体静止
];

//人体大小线段默认数据
export const defaultBodySegments = [
  {
    name:"人体1",
    isActive:false,
    isClear:false,
    isDisabled:false,
    points:{
      start:{x:922,y:4},
      end  :{x:928,y:105}
    }
  },
  {
    name:"人体2",
    isActive:false,
    isClear:false,
    isDisabled:false,
    points:{
      start:{x:1022,y:141},
      end  :{x:1023,y:269}
    }
  },
  {
    name:"人体3",
    isActive:false,
    isClear:false,
    isDisabled:false,
    points:{
      start:{x:1604,y:408},
      end  :{x:1590,y:623}
    }
  },
  {
    name:"人体4",
    isActive:false,
    isClear:false,
    isDisabled:false,
    points:{
      start:{x:516,y:814},
      end  :{x:521,y:1071}
    }
  },
]
