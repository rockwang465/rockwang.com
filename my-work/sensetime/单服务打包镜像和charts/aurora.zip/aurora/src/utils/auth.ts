import Cookies from 'js-cookie';
import {Cache} from '@/utils/cache';
import {roleModulesCode} from '@/router/moduleCode';

const TokenKey = 'Admin-Token';

export function getToken() {
  //console.log(Cookies.get(TokenKey))
  return Cookies.get(TokenKey);
}

export function setToken(token: string) {
  return Cookies.set(TokenKey, token);
}

export function removeToken() {
  return Cookies.remove(TokenKey);
}

//check code in the permissionCode
export function permission(code?:String){
  let is_include:boolean = false;
  let moduleMap:string[]=[];
  Object.keys(roleModulesCode).map(modelName=>{
    moduleMap.push(roleModulesCode[modelName]);
  });
  let permissionCodes:any[]=[];
  let AllCodes = Cache.localGet("modulecodes") || Cache.sessionGet("modulecodes");
  AllCodes && Object.keys(AllCodes).forEach(item=>{
    if(moduleMap.includes(item)){
      permissionCodes = permissionCodes.concat(AllCodes[item]);
    }
  });
  is_include = permissionCodes.includes(code);
  return is_include;
}

export function modulePermission(moduleCode?:string){
  if(moduleCode){
    let AllCodes = Cache.localGet("modulecodes") || Cache.sessionGet("modulecodes");
    let modulecodes = AllCodes?Object.keys(AllCodes):[];
    return modulecodes.includes(moduleCode);
  }else{
    return false;
  }
}
