import { Cache } from '@/utils/cache';
var host = window.globalConfig.host;
// var dev_host = window.globalConfig.dev_host;
var dev_host = window.location.protocol+'//'+window.location.host
//获取图片尺寸
export function getImageSize(
  url: string
): Promise<{ width: number; height: number }> {
  const img = document.createElement("img");

  return new Promise<{ width: number; height: number }>((resolve, reject) => {
    img.onload = ev => {
      resolve({ width: img.naturalWidth, height: img.naturalHeight });
    };

    img.onerror = reject;
    img.src = url;
  });
}

//引入图片
export function processImgurl(part){
  //let tokenBase64 = window.btoa(Cache.localGet("accessToken") || Cache.sessionGet("accessToken"));
  //return part? host+"/"+part+"/"+tokenBase64:"";
  return part? host+"/"+part:"";
  // return part? host+"/"+part+"/"+Cache.sessionGet("accessToken"):""
}

export function processImgurlForVisitor(part){
  //let tokenBase64 = window.btoa(Cache.localGet("accessToken") || Cache.sessionGet("accessToken"));
  let node_env = process.env.NODE_ENV;
  if(node_env == 'development'){
    return part? dev_host+"/"+part:"";
  }
  return part? host+"/"+part:"";
}

export function transport(url){
  if(url){
    return url.substr(url.indexOf(":")+1);
  }
  return ''
}
