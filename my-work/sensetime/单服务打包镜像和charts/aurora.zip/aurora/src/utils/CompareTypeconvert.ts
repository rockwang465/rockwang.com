export function CompareTypeconvert (val :string){
  let compareType = ""
     switch(val){
       case "0":
       compareType="records.listNotifyTypeNormal"
       break;
       case "1":
       compareType="records.listNotifyTypeStranger";
       break;
       case "2":
       compareType="records.listNotifyTypeFaceSpoof";
       break;
       case "3":
       compareType="records.listNotifyTypePassAttack";
       break;
       case "4":
       case "6":
       case "8":
       compareType="records.listNotifyTypeAbnormal";
       break;
       case "9":
       compareType="records.listNotifyTypeBlacklist";
       break;
     }
     return compareType
}
