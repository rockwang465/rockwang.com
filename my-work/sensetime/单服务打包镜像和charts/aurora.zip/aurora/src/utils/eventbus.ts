import Vue from 'vue';
//定义全局事件时 请加上模块名称
export const EventBus = new Vue();