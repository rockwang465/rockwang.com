export function encryption(id:string){
  let str:string = '';
  let arr:string[] = id.split('');
  let len:number = arr.length;
  if (id.length < 4){
    for (let i = 0;i < id.length;i++){
      str += '*'
    }
  }else{
    let half:number = Math.floor(len/2);
    let quarter:number = Math.ceil(half/2);
    let end:number = quarter + half;
    // console.log(half,quarter,end);
    for(let i = quarter;i < end;i++){
      arr[i] = '*';
    }
    for (let j = 0;j < len;j++){
      str += arr[j];
    }
  }
  return str;
}
