import {cloneDeep} from "lodash";

// export function calculateClockDirection2(list:any[]){
//     let points = cloneDeep(list);
//     if(points.length>2){
//         let len = points.length;
//         if(points[0].x === points[len-1].x && points[0].y === points[len-1].y) points.splice(len-1,1);
//         len = points.length;
//         let count = 0,yTrans=-1,z=0;
//         for(let i=0;i<len;i++){
//             let j = (i + 1) % len,k = (i + 2) % len;
//             z = (points[j].x - points[i].x) * (points[k].y * yTrans - points[j].y * yTrans);
//             z -= (points[j].y * yTrans - points[i].y * yTrans) * (points[k].x - points[j].x);
//             if (z < 0){
//                 count--;
//             }else if (z > 0){
//                 count++;
//             }
//         }
//         return count<0?true:false;

//     }else{
//         return true;
//     }
// }


export function calculateClockDirection(list:any[]){
    let points = cloneDeep(list);
    if(points.length>2){
        let len = points.length;
        if(points[0].x === points[len-1].x && points[0].y === points[len-1].y) points.splice(len-1,1);
        len = points.length;
        let count = 0,yTrans=-1;
        for(let i=0;i<len;i++){
            if(i+1<len){
                count += points[i].x*points[i+1].y*yTrans - points[i+1].x*points[i].y*yTrans    
            }else if(i+1 == len){
                count += points[i].x*points[0].y*yTrans - points[0].x*points[i].y*yTrans 
            }
            
        }
        console.log(count)
        return count<0?true:false;

    }else{
        return true;
    }
}