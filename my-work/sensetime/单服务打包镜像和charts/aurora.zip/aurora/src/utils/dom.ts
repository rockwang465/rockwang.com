export const on = (
  element: HTMLElement | Element,
  event: string,
  handler: EventListenerOrEventListenerObject
) => {
  if (element && event && handler) {
    element.addEventListener(event, handler, false);
  }
};
export const off = (
  element: HTMLElement,
  event: string,
  handler: EventListenerOrEventListenerObject
) => {
  if (element && event) {
    element.removeEventListener(event, handler, false);
  }
};