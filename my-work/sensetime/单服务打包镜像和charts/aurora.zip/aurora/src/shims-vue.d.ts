
declare module '*.vue' {
  //import Vue from 'vue';
  import { Vue } from 'vue-property-decorator';
  export default Vue;
}

declare module '*.svg' {
  //import Vue from 'vue';
  import { Vue } from 'vue-property-decorator';
  export default Vue;
}

// declare function SockJS(a: string,b?:any,c?:any): void;
interface map {
  floor:string,
  region:string
}

//elementUI v2.9.1 bug
type PluginFunction<T> = (Vue: any, options?: T) => void;
interface PluginObject<T> {
  install: PluginFunction<T>;
  [key: string]: any;
}
interface Window {
  globalConfig:{
    host:string,
    streamedianHost:string,
    monitorVideoFrame:boolean,
    login:string,
    log:string,
    timezoneHost:string,
    acHost:string,
    acThreshold:number,
    deviceHost:string,
    portrait:string,
    device:string,
    role:string,
    record:string,
    tdConsume:string,
    tdwsHost:string,
    acwsHost:string,
    generateTrack:string,
    map:string,
    wsAlarmListNum:number,
    toolHost:string,
    visitor:string,
    visitorWS:string,
    dev_host:string,
    frontendCompare:string,
    refreshTokenTime:number,
    user:string,
    portraitExport:string,
    portraitUpdate:string,
    history:string,
    historyExport:string,
    download:string,
    retryExport:string,
    messageCenter:string,
    attendance:string,
    [propName: string]: string | number | boolean;
    alarmCheckFrequency:number;
    isCheckPushFrequency:boolean;
  },
  protobuf:any,
  Streamedian:any,
}
interface MyWindow extends Window {

}

