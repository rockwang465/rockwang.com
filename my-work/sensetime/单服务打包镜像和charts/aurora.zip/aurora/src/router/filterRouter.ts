import {routes} from './index'

/*通过meta.code判断是否与当前用户权限匹配*/
function hasPermission(modulecodes , route) {
  if (route.meta && route.meta.code) {
    //console.log(modulecodes,route.meta.code,modulecodes.includes(route.meta.code))
    return modulecodes.includes(route.meta.code) ;
  } else {
    return true
  }
}
/*递归过滤异步路由表，返回符合用户角色权限的路由表*/
function filterUserRouter(routes,modulecodes:string[]) {
  //console.log(modulecodes)
  let res:any = [];
  routes.forEach(route => {
    let tmp:any = { ...route };
    if (hasPermission(modulecodes,tmp)) {
      if (tmp.children) {tmp.children = filterUserRouter(tmp.children,modulecodes)};
      res.push(tmp)
    }
  });
  return res;
};

export function getUserRoutes(modulecodes){
  if(modulecodes){
    let userRoutes = filterUserRouter(routes,modulecodes);
    //console.log(userRoutes)
    return userRoutes;
  }else{
    return routes;
  }

}
