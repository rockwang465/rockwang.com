//import Vue from 'vue';
import {Vue} from 'vue-property-decorator';
import Router from 'vue-router';
import Layout from '@/views/layout/Layout.vue';
import {getUserRoutes} from './filterRouter';
import {Cache} from '@/utils/cache';
import {modulePermission} from '@/utils/auth';

//import i18n from '@/lang/index' // Internationalization
import {roleModulesCode} from './moduleCode';

Vue.use(Router)
// Vue.use(Router, i18n, {
//   i18n: (key: string, value: object) => i18n.t(key, value)
// });
//$t('route.nested')
/*
  redirect:                      if `redirect: noredirect`, it won't redirect if click on the breadcrumb
  meta: {
    title: 'title'               the name showed in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon showed in the sidebar
    hidden: true                 if `hidden: true`, this route will not show in the sidebar (default is false)
    alwaysShow: true             if set to true, it will always show the root menu
                                 if not set, only show with nested mode if there are more than one route under its children
  }
*/

export const routes = [
  {path: '/login', name: 'login', component: () => import(/* webpackChunkName: "login" */ '@/views/login/index.vue')},
  {path: '/404', name: '404', component: () => import(/* webpackChunkName: "404" */ '@/views/404.vue')},
  {path: '/locus', name: 'locus', component: () => import(/* webpackChunkName: "locus" */ '@/views/retrival/component/locus-analysis/index.vue')},
  {
    path: '/dashboard',
    component: Layout,
    name:'dashboard',
    children: [{
      path: '',
      name: 'dashboard-inner',
      component: () => import('@/views/dashboard/index.vue'),
      meta: {
        title: 'labelDashboard',
        code: roleModulesCode['dashboard'],
        icon: 'icon-dashboard'
      },
    }]
  },
  {
    path: '/',
    component: Layout,
    redirect: (to)=>{
      return modulePermission(roleModulesCode['monitor'])?'/monitor':"/center/personInfo";
    },
  },
  {
    path: '/monitor',
    component: Layout,
    redirect: 'monitor',
    name: 'monitor',
    meta: {
      title: 'labelLive',
      icon: 'icon-keep-eye',
      code: roleModulesCode['monitor'] ,
    },
    children: [{
      path: '',
      name: '',
      component: () => import('@/views/monitor/monitor.vue'),
      meta: {title: 'labelLive', icon: 'icon-keep-eye', code: roleModulesCode['monitor']}
    }],
  },
  // {
  //   path: '/',
  //   component: Layout,
  //   redirect: (to)=>{
  //     return modulePermission(roleModulesCode['monitor'])?'/monitor':"/center/personInfo";
  //   },
  //   name: 'monitor',
  //   meta: {
  //     title: 'labelLive',
  //     icon: 'icon-keep-eye',
  //     code: roleModulesCode['monitor'] ,
  //   },
  //   children: [
  //     // {
  //     //   path: '/monitor',
  //     //   name: 'monitor-map',
  //     //   component: () => import('@/views/monitor/monitor.vue'),
  //     //   meta: {title: 'labelMapView', icon: '', code: roleModulesCode['monitor']}
  //     // },
  //     {
  //       path: '/monitor',
  //       name: 'monitor-video',
  //       component: () => import('@/views/monitor/monitor.vue'),
  //       meta: {title: 'labelLive', icon: '', code: roleModulesCode['monitor']}
  //     }
  //   ],
  // },
  {
    path: '/visitor',
    component: Layout,
    redirect: '/visitor',
    name: 'visitor',
    meta: {
      title: 'visitor',
      code: roleModulesCode['visitor'] ,
    },
    children: [{
      path: '',
      name: 'visit',
      component: () => import('@/views/visitor/index.vue'),
      meta: {
        title: 'labelVisitor',
        code: roleModulesCode['visitor'],
        icon: 'icon-user'
      },
    }],
  },
  {
    path: '/attendance',
    component: Layout,
    redirect: 'attendance/list',
    name: 'attendance',
    meta: {
      title: 'attendance',
      code: roleModulesCode['attendance'] ,
    },
    children: [
      {
        path: '',
        name: 'attendanceSub',
        component: () => import('@/views/attendance/index.vue'),
        redirect: 'list',
        meta: {
          title: 'labelAttendance',
          code: roleModulesCode['attendance'],
          icon: 'icon-time-set',
          showLink:false,
          hidden: false,
        },
        children:[
          {
            path: 'list',
            name: 'AttendanceList',
            meta: {
              code: roleModulesCode['attendance'],
            },
            component: () => import('@/views/attendance/components/page-list.vue'),
          },
          {
            path: 'detail',
            name: 'AttendanceDetail',
            meta: {
              code: roleModulesCode['attendance'],
            },
            component: () => import('@/views/attendance/components/page-detail.vue'),
          },
          {
            path: 'homePage',
            name:'homePage',
            component: () => import('@/views/attendance/components/attendance-home-page.vue'),
            meta: {
              code: roleModulesCode['attendance'],
            },
          },
        ]
      },
    ],
  },
  {
    path: '/retrival',
    component: Layout,
    redirect: '/retrival',
    name: 'retrival',
    children: [{
      path: '',
      name: 'sub-retrival',
      redirect:'face',
      component: () => import('@/views/retrival/index.vue'),
      meta: {
        title: 'labelRetrieval',
        code: roleModulesCode['retrival'],
        icon: 'icon-portrait-search'
      },
      children:[
        {
          path: 'face', // vehicle 车辆 , pedestrian 行人 , non-motor 非机动车
          name: 'face',
          meta: {
            code: roleModulesCode['retrival'],
          },
          component: () => import('@/views/retrival/retrivalAll/face.vue'),
        },
        {
          path: 'pedestrian', // vehicle 车辆 , pedestrian 行人 , non-motor 非机动车
          name: 'pedestrian',
          meta: {
            code: roleModulesCode['retrival'],
          },
          component: () => import('@/views/retrival/retrivalAll/pedestrian.vue'),
        },
        {
          path: 'vehicle', // vehicle 车辆 , pedestrian 行人 , non-motor 非机动车
          name: 'vehicle',
          meta: {
            code: roleModulesCode['retrival'],
          },
          component: () => import('@/views/retrival/retrivalAll/vehicle.vue'),
        },
        {
          path: 'non-motor', // vehicle 车辆 , pedestrian 行人 , non-motor 非机动车
          name: 'non-motor',
          meta: {
            code: roleModulesCode['retrival'],
          },
          component: () => import('@/views/retrival/retrivalAll/non-motor.vue'),
        },
        {
          path: 'crowdRecord', // vehicle 车辆 , pedestrian 行人 , non-motor 非机动车
          name: 'crowdRecord',
          meta: {
            code: roleModulesCode['retrival'],
          },
          component: () => import('@/views/retrival/retrivalAll/crowd-record.vue'),
        },
      ]
    }],
  },
  {
    path: '/welcome',
    component: Layout,
    redirect: '/welcome',
    name: 'welcome',
    children: [{
      path: '',
      name: 'welcomeSub',
      component: () => import('@/views/welcome/index.vue'),
      meta: {
        title: 'labelWelcome',
        code: roleModulesCode['welcome'],
        icon: 'icon-yingbin'
      },
    }],
  },
  {
    path: '/manage',
    component: Layout,
    redirect: '/manage/map',
    name: 'manage',
    meta: {title: 'labelSettings', icon: 'icon-config-manage'},
    children: [
      {
        path: 'device',
        name: 'device',
        component: () => import('@/views/manage/device/index.vue'),
        meta: {title: 'listSettingsDevice', icon: 'icon-device-manage', code: roleModulesCode['device']},
      },
      {
        path: 'portrait',
        name: 'portrait',
        component: () => import('@/views/manage/portrait/index.vue'),
        meta: {title: 'listSettingsLibrary', icon: 'icon-portrait-manage', code: roleModulesCode['protrait']},
      },
      // {
      //   path: 'rule',
      //   name: 'rule',
      //   component: () => import('@/views/manage/rule/rule.vue'),
      //   meta: {title: 'listSettingsRule', icon: 'icon-rules', code: roleModulesCode['rule']}
      // },
      {
        path: 'task',
        name: 'task',
        component: () => import('@/views/manage/task/task.vue'),
        meta: {title: 'listSettingsTask', icon: 'icon-rules', code: roleModulesCode['rule']}
      },
      {
        path: 'user',
        name: 'user',
        component: () => import('@/views/manage/user/user.vue'),
        meta: {title: 'listSettingsUser', icon: 'icon-user-manage', code: roleModulesCode['user']}
      },
      {
        path: 'role',
        name: 'role',
        component: () => import('@/views/manage/user/role.vue'),
        meta: {title: 'listSettingsRole', icon: 'icon-user', code: roleModulesCode['role']}
      },
      {
        path: 'map',
        name: 'map',
        component: () => import('@/views/manage/map/index.vue'),
        meta: {title: 'listSettingsMap', icon: 'icon-map', code: roleModulesCode['map']}
      },
      {
        path: 'log',
        name: 'log',
        component: () => import('@/views/manage/log/index.vue'),
        meta: {title: 'listSettingsLog', icon: 'icon-log-manage', code: roleModulesCode['log']}
      },
      {
        path: 'message',
        name: 'message',
        component: () => import('@/views/message-center/index.vue'),
        meta: {title: 'labelMessage', icon: 'icon-news',hidden:true, code: roleModulesCode['message']}
      },
      {
        path: 'timezone',
        name: 'timezone',
        component: () => import('@/views/manage/timezone/timezone.vue'),
        meta: {title: 'labelTimezone', icon: 'icon-time', code: roleModulesCode['timezone']}
      }
    ],
  },
  {
    path: '/center',
    component: Layout,
    redirect: '/center/personInfo',
    name: 'center',
    meta: {title: '', icon: 'icon-config-manage',hidden:true,center:true},
    children: [
      {
        path: 'personInfo',
        name: '/center/personInfo',
        component: () => import('@/views/manage/personInfo/index.vue'),
        meta: {title: 'listProfile', icon: 'icon-user', code: roleModulesCode['personInfo']}
      },
      {
        path: 'systemInfo',
        name: '/center/systemInfo',
        component: () => import('@/views/manage/systemInfo/index.vue'),
        meta: {title: 'listSysinfo', icon: 'icon-user', code: roleModulesCode['systemInfo']}
      },
    ],

  },
  {
    path: '/heatMap',
    component: Layout,
    redirect: '/heatMap',
    name: 'heatMap',
    meta: {
      title: 'heatMap',
      code: roleModulesCode['heatMap'] ,
    },
    children: [{
      path: '',
      name: 'heatMap',
      component: () => import('@/views/heatMap/index.vue'),
      meta: {
        title: 'labelHeatMap',
        code: roleModulesCode['heatMap'],
        icon: 'icon-ditu2'
      },
    }],
  },
  {path: '*', redirect: '/404'},
];

let AllCodes = Cache.localGet("modulecodes") || Cache.sessionGet("modulecodes");
export default new Router({
  mode: 'history',
  scrollBehavior: () => ({x: 0, y: 0}),
  base: process.env.BASE_URL,
  routes:getUserRoutes(AllCodes?Object.keys(AllCodes).concat(roleModulesCode['message']):null)//message-center 不做权限限制
});
