// import Vue from 'vue';
import { Vue } from 'vue-property-decorator';
import lodash from 'lodash'

//import 'normalize.css';
import ElementUI from 'element-ui';

//import SvgIcon from 'vue-svgicon';
import '@/styles/index.scss';
//import '@/assets/icons';
import '@/permission';

import App from '@/App.vue';
import router from '@/router';
import store from '@/store';
//import '@/registerServiceWorker';

import {permission,modulePermission} from '@/utils/auth';

import i18n from '@/lang/index' // Internationalization

// 自动注册comoinents文件夹下所有组件为全局组件
import autoComponent from   '@/utils/aotuCerComponent'
Vue.use(autoComponent) 

Vue.use(ElementUI, {
  i18n: (key:string, value:object) => i18n.t(key+'', value)
})
//console.log(ElementUI.Message.prototype)
Vue.prototype.$ELEMENT = { showClose: true};
// ElementUI.Message.prototype.options = {
//   showClose:true
// }

import EXIF from 'exif-js'

import {roleModulesCode} from '@/router/moduleCode';

// Vue.use(SvgIcon, {
//   tagName: 'svg-icon',
//   defaultWidth: '1em',
//   defaultHeight: '1em',
// });

Vue.config.productionTip = false;
Vue.prototype.$permission = permission;
Vue.prototype.$modulePermission = modulePermission;
Vue.prototype.$_ = lodash;
Vue.prototype.EXIF = EXIF;

new Vue({
  //el:"#app",
  router,
  store,
  i18n,
  render: (h) => h(App),
}).$mount('#app');

router.beforeEach((to, from, next)=>{
  // (modulePermission(to.meta.code) || from.name === 'login' || to.name === 'message') && next();
  (modulePermission(to.meta.code) || from.meta.code === roleModulesCode['login'] || to.meta.code === roleModulesCode['message']) && next();
})
