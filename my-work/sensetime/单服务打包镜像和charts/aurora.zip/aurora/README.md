# SenseGuard v2.2.0

## v2.2.0分支说明： 
1、从长宁项目 https://gitlab.sz.sensetime.com/fe/aurora/commit/f1fabbc80b36b6e480eedb74b28a71433c728e83 拉取的分支

2、合并SenseLink的代码 https://gitlab.sz.sensetime.com/fe/aurora/commit/89024a1ef46b36715f2219157cfbd5f505742cee

3、包含了dev的最新代码

4、作为v2.2.0_Alphad的基础代码进行开发

5、开发v2.2.0相关需求


