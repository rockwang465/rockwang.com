

## 公用模块

### 目录树：tree
> 场景如：设备列表，
例:
 #<LeftTree :treeData="treeData" @clickVal="clickVal"
                  @showDetail="showDetail"
                  @addData="addData"
                  @updateData="updateData"
                  @deleteData="deleteData"></LeftTree>
数据来源: treeData 
方法: showDetail:详情,addData添加 updateData修改 deleteData 删除 接受参数:当前选中的树结构
- 支持多级
- 目视icon图标配置
- 增：增同级，增下级
- 删：有下级时不能删除
- 改：
- 查：搜索，同步/异步

### 人像对比块

> 场景如：监控模块，查询模块

### 图片列表

//### table数据列表

### header 区域及 顶部菜单+面包屑


### 视频叠框

### 地图


