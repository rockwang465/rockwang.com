//const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

let crossHost = 'https://10.151.3.103';

module.exports = {
  devServer: {
    disableHostCheck: true,
    //open: true, //浏览器自动打开页面
    host: "0.0.0.0", //如果是真机测试，就使用这个IP
    port: 8088,
    https: true,
    hotOnly: false, //热更新（webpack已实现了，这里false即可）
    proxy: { //配置跨域
      '/api': {
        target: crossHost,
        changOrigin: true,
        https: false,
        ws: true,
        pathRewrite: {
          '^/api': ''
        }
      },
      '/v1': {
        target: crossHost,
        changOrigin: true,
        https: false,
        ws: true,
        pathRewrite:{
          '^/v1':''
        }
      },
      '/stomp': {
        target: crossHost,
        changOrigin: true,
        https: false,
        ws: true,
        pathRewrite: {
          '^/stomp': ''
        }
      },
      '/senseguard-message-center': {
        target: crossHost,
        changOrigin: true,
        https: false,
        ws: true,
      },
      '/senseguard-guest-management': {
        target: crossHost,
        changOrigin: true,
        https: false,
        ws: true,
      },
      '/rtsp-over-ws': {
        target: crossHost,
        changOrigin: true,
        https: true,
        ws: true,
      },
      '/senseguard-struct-process-service': {
        target: crossHost,
        changOrigin: true,
        https: false,
        ws: true,
      },
      // '/senseguard-td-result-consume': {
      //   target: crossHost,
      //   changOrigin: true,
      //   https: false,
      //   ws: true,
      // },
      // '/senseguard-ac-result-consume': {
      //   target: crossHost,
      //   changOrigin: true,
      //   https: false,
      //   ws: true,
      // }
    }
  },
  //pwa: {},
  //是否为 Babel 或 TypeScript 使用 thread-loader
  parallel: require('os').cpus().length > 1,
  productionSourceMap: false,
  // configureWebpack: {
  //   optimization: {
  //     minimizer: [
  //       new UglifyJsPlugin({
  //         uglifyOptions: {
  //           compress: {
  //             warnings: false,
  //             drop_console: true,//移除console
  //             drop_debugger: true,//移除debugger
  //           }
  //         }
  //       })
  //     ]
  //   }
  // }
}
