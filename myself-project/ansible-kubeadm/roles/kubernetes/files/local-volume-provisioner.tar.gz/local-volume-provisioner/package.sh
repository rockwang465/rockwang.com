#!/bin/bash

# 生成版本号
VERSION=2.3.0
BUILD=`git rev-parse --short HEAD`
BRANCH=`git symbolic-ref --short -q HEAD`

CHART_TAG="${VERSION}-${BRANCH}-${BUILD}"
# 打包
helm package --version=$CHART_TAG .

# 推送到仓库
curl --data-binary "@local-volume-provisioner-${CHART_TAG}.tgz" http://10.5.6.10:8080/api/charts

# 删除本地文件
rm -f local-volume-provisioner-${CHART_TAG}.tgz